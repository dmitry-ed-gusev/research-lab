package info.jtrac.utils;

import org.apache.commons.lang3.StringUtils;

import javax.servlet.http.Cookie;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Common utility class for whole application. In this class accumulated all separated
 * utility classes from application.
 * 1. Methods that improve on the Spring ValidationUtils for inserting error messages for
 *    form object fields into the view "errors" object:
 *    - isAllUpperCase()
 *    - isValidLoginName()
 *    - isCamelDashCase()
 * 2. Date Formatting helper methods. Currently date formats are hard-coded for the entire app
 *    hence the use of static SimpleDateFormat instances, although they are known not to be synchronized.
 *    - format()
 *    - formatTimeStamp()
 * 3. Utility methods for http, web related stuff etc:
 *    - getDebugStringForCookie()
 *
 * @author Gusev Dmitry (Dmitry)
 * @version 1.0 (DATE: 10.03.14)
*/

public class JTracUtils {

    private static final Format DATE_FORMAT     = new SimpleDateFormat("yyyy-MM-dd");
    private static final Format DATETIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /** Method for improve on the Spring ValidationUtils. */
    public static boolean isAllUpperCase(String input) {
        return (!StringUtils.isBlank(input) && input.matches("[A-Z0-9]+"));
    }

    /** Method for improve on the Spring ValidationUtils. */
    public static boolean isValidLoginName(String input) {
        return (!StringUtils.isBlank(input) && input.matches("[\\w.@\\\\-]+"));
    }

    /** Only letters are allowed, not even numbers and CamelCase with dash as word separator. */
    public static boolean isCamelDashCase(String input) {
        return (!StringUtils.isBlank(input) && input.matches("[A-Z][a-z]+(-[A-Z][a-z]+)*"));
    }

    /***/
    public static String format(Date date) {
        return date == null ? "" : DATE_FORMAT.format(date);
    }

    /***/
    public static String formatTimeStamp(Date date) {
        return date == null ? "" : DATETIME_FORMAT.format(date);
    }

    /***/
    public static String getDebugStringForCookie(Cookie cookie) {
        return  "domain: '" + cookie.getDomain() + "', "
                + "name: '" + cookie.getName() + "', "
                + "path: '" + cookie.getPath() + "', "
                + "value: '" + cookie.getValue() + "', "
                + "secure: '" + cookie.getSecure() + "', "
                + "version: '" + cookie.getVersion() + "', "
                + "maxAge: '" + cookie.getMaxAge() + "', "
                + "comment: '" + cookie.getComment() + "'";
    }

}