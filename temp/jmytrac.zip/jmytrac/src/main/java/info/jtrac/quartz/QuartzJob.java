package info.jtrac.quartz;

import gusev.dmitry.jMailman.EMailClient;
import gusev.dmitry.jMailman.EMailClientConfig;
import gusev.dmitry.jMailman.EMailMessage;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.List;

/**
 * Quartz job for query mailbox and create tasks in bugtracker according to received emails.
 * @author Gusev Dmitry (Dmitry)
 * @version 1.0 (DATE: 06.01.14)
*/

// todo: initializing email client via spring beans
// todo: see -> http://stackoverflow.com/questions/12707383/data-retrival-using-quartz

public class QuartzJob implements Job {

    private Logger log = LoggerFactory.getLogger(QuartzJob.class);

    public QuartzJob() {
        log.debug("QuartzJob constructor() working.");
    }

    /***/
    //public void checkMail() {
    //    log.debug("QuartzJob.checkMail() working.");
    //}

    /***/
    public void execute(JobExecutionContext context) throws JobExecutionException {
        log.debug("QuartzJob.execute() working.");

        // get job context and associated data map
        //JobKey     key     = context.getJobDetail().getKey();
        JobDataMap dataMap = context.getJobDetail().getJobDataMap();
        // get job parameters from job context
        String protocol = dataMap.getString("protocol");
        String host     = dataMap.getString("host");
        String user     = dataMap.getString("user");
        String password = dataMap.getString("password");
        //System.out.println(protocol + "-" + host + "-" + user + "-" + password);

        // create email client config
        EMailClientConfig emailConfig = new EMailClientConfig.Builder(protocol, host, user, password)
                .mailFolderName("inbox").mailDomain("gmail.com").deleteMessages(true).build();
        // create email client instance
        EMailClient       emailClient = new EMailClient(emailConfig);
        try {
            // check emails
            List<EMailMessage> emailMessages = emailClient.getMessagesList();
            System.out.println("messages: " + emailMessages.size());

            // create and save tasks according to received emails
        } catch (MessagingException | IOException e) {
            log.error("Can't get email messages list!", e);
        }

        //this.checkMail();
    }

}