package info.jtrac.utils;

import junit.framework.TestCase;

/**
 * Complex test class for utility module (class JTracUtils).
 * @author Gusev Dmitry (Dmitry)
 * @version 1.0 (DATE: 10.03.14)
 */
public class JTracUtilsTest extends TestCase {

    //@Test  // junit 4+
    public void testUpperCase() {
        assertTrue(JTracUtils.isAllUpperCase("ABCD"));
        assertTrue(JTracUtils.isAllUpperCase("AB123CD"));
        assertFalse(JTracUtils.isAllUpperCase("ABCD-ABCD"));
        assertFalse(JTracUtils.isAllUpperCase("AB CD"));
    }

    //@Test  // junit 4+
    public void testValidLoginName() {
        assertTrue(JTracUtils.isValidLoginName("abcd"));
        assertTrue(JTracUtils.isValidLoginName("abcd123"));
        assertTrue(JTracUtils.isValidLoginName("ab-cd"));
        assertTrue(JTracUtils.isValidLoginName("ab.cd"));
        assertTrue(JTracUtils.isValidLoginName("ab_cd"));
        assertTrue(JTracUtils.isValidLoginName("Ab-Cd"));
        assertTrue(JTracUtils.isValidLoginName("ab@cd"));
        assertTrue(JTracUtils.isValidLoginName("AB\\cd"));
        assertTrue(JTracUtils.isValidLoginName("AB\\abc@def.com"));
        assertFalse(JTracUtils.isValidLoginName("ab%cd"));
        assertFalse(JTracUtils.isValidLoginName("ab:cd"));
        assertFalse(JTracUtils.isValidLoginName("ab cd"));
    }

    //@Test  // junit 4+
    public void testCamelDashCase() {
        assertTrue(JTracUtils.isCamelDashCase("Abcd"));
        assertTrue(JTracUtils.isCamelDashCase("Abcd-Efgh"));
        assertTrue(JTracUtils.isCamelDashCase("Abcd-Efgh-Hijk"));
        assertFalse(JTracUtils.isCamelDashCase("AbcdEfgh"));
        assertFalse(JTracUtils.isCamelDashCase("Abcd123"));
        assertFalse(JTracUtils.isCamelDashCase("8bcd"));
        assertFalse(JTracUtils.isCamelDashCase("Ab-cd"));
        assertFalse(JTracUtils.isCamelDashCase("Ab cd"));
    }

}