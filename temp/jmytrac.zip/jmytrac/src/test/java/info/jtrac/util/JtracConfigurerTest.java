package info.jtrac.util;

import junit.framework.TestCase;

public class JtracConfigurerTest extends TestCase {
    
    public void testUserDir() throws Exception {
        // TODO
    }
    
}
