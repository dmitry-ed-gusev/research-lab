package jdb.utils.helpers;

import jdb.config.connection.BaseDBConfig;
import org.junit.Before;
import org.junit.Test;

/**
 * @author Gusev Dmitry (����� �������)
 * @version 1.0 (DATE: 03.03.11)
 */
public class JdbcUrlHelperTest
 {
  private BaseDBConfig config;

  @Before
  public void instantiate()
   {
    config = new BaseDBConfig();
   }

  @Test
  public void testGetInformixJdbcUrl()
   {


   }

 }