package memorandum;

import javax.sql.DataSource;
import javax.naming.Context;
import javax.naming.InitialContext;

/**
 * Created by IntelliJ IDEA.
 * User: 019gus
 * Date: 02.10.2006
 * Time: 17:06:57
 * To change this template use File | Settings | File Templates.
 */
public class ServiceLocator
  {

   private ServiceLocator() {}

   public static DataSource getDataSource(String dataSourceJNDIName) throws Exception
    {
     DataSource dataSource = null;
     try
      {
       Context ctx = new InitialContext();
       dataSource  = (DataSource) ctx.lookup(dataSourceJNDIName);
      }
     catch (Exception e) {e.printStackTrace();}
     return dataSource;
    }

  }
