04.04.2014

This module is intended for:
 - mining (get) data from ARMs system - Paradox/dBase databases (working data)
 - mining data from Boss-Kadrovik system and from KZ Active Direcory (employees/departments data)