package ru.kzgroup.dataMiner.processors.directories;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.kzgroup.exceptions.InternalException;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

/**
 * Paradox databases aggregator module. It copies all nesessary paradox table into one database.
 * Nesessary tables - see configuration. Paradox table - a set of files with table name and different extensions:
 * DB - table, MB - memo/binary fields, F/F1-F14 - forms, R/R1-R14 - reports, SET - screen view settings,
 * VAL - data validation rules, PX - primary index (for primary key), X01/Y01-X99/Y99 - secondary indexes (two files
 * for one secondary index), SC - script (text), SC2 - script (compiled), G - graphics.
 *
 * 10.10.2014 Added multithreaded copy method.
 *
 * @author Gusev Dmitry (gusevd)
 * @version 2.0 (DATE: 10.10.2014)
*/

@Component
@Scope("singleton")
@Transactional
public class PdxDBCopier {

    private final static Log log = LogFactory.getLog(PdxDBCopier.class);

    @Value("${paradox.data.local}") private String                localDbPath;             // local paradox database
    // Mapping collection/map is not supported by @Inject or @Autowired annotation. However we can use @Resource annotation for map it.
    @Resource(name="pdxDataMap")    private Map<String, String[]> bases = new HashMap<>(); // all paradox databases list

    /***/
    public PdxDBCopier() {
        log.debug("PdxDBCopier constructor() working.");
    }

    /***/
    @PostConstruct
    public void postConstruct() {
        log.debug("PdxDBCopier.postConstruct() working.");
    }

    public Map<String, String[]> getBases() {
        return bases;
    }

    public void setBases(Map<String, String[]> bases) {
        this.bases = bases;
    }

    /***/
    public synchronized void aggregatePdxDb() throws InternalException {
        log.debug("PdxDBCopier.aggregatePdxDb() working.");
        File localDb = new File(localDbPath);
        if (!localDb.exists()) { // dir doesn't exist
            boolean result = localDb.mkdirs();
            log.debug(String.format("Local PDX dir [%s] doesn't exists. Created [%s].", localDbPath, result));
        } else if (!localDb.isDirectory()) { // dir exists - check is it dir?
            throw new InternalException(String.format("Local PDX dir [%s] exists but isn't a directory!", localDbPath));
        }

        FilenameFilter filter;
        for (Map.Entry<String, String[]> entry : bases.entrySet()) { // cycle for data copy
            for (final String currentTable : entry.getValue()) { // iterating over current db and copying
                filter = new FilenameFilter() { // filter for files in a directory
                    public boolean accept(File dir, String name) {
                        return name.startsWith(currentTable + ".");
                    }
                };
                // list of files in directory (filtered)
                File[] tableFiles = new File(entry.getKey()).listFiles(filter);
                for (File currentFile : tableFiles) { // copy files
                    //File sourceFile = new File(entry.getKey() + "/" + currentTable + "." + currentExt);
                    File destFile = new File(localDbPath + "/" + currentFile.getName());
                    try {
                        FileUtils.copyFile(currentFile, destFile);
                    } catch (IOException e) {
                        log.error(String.format("Can't copy file [%s] to [%s]! Reason->[%s].",
                                currentFile.getAbsolutePath(), destFile.getAbsolutePath(), e.getMessage()));
                    }
                }
            }
        } // end FOR - iterating over BASES map
        log.debug("Copy finished.");
    }

    /***/
    private static class CopyingThread implements Runnable {

        private String    destDirectory; // directory to copy files to
        private File[]    sourceFiles;   // files for copy to local directory
        private Semaphore semaphore;     // semaphore object for current thread

        /***/
        public CopyingThread(String destDirectory, File[] sourceFiles, Semaphore semaphore) {
            this.destDirectory = destDirectory;
            this.sourceFiles   = sourceFiles;
            this.semaphore     = semaphore;
        }

        @Override
        public void run() {

            try {
                this.semaphore.acquire(); // acquire semaphore permission

                for (File currentFile : this.sourceFiles) { // copy files
                    //File sourceFile = new File(entry.getKey() + "/" + currentTable + "." + currentExt);
                    File destFile = new File(this.destDirectory + "/" + currentFile.getName());
                    try {
                        FileUtils.copyFile(currentFile, destFile);
                    } catch (IOException e) {
                        log.error(String.format("Can't copy file [%s] to [%s]! Reason->[%s].",
                                currentFile.getAbsolutePath(), destFile.getAbsolutePath(), e.getMessage()));
                    }
                }

                this.semaphore.release(); // release permission, other thread can acquire released permission
            } catch (InterruptedException e) {
                log.error(String.format("Copying thread is interrupted! [%s]", e.getMessage()));
            }
        }

    }

    /***/
    public synchronized void aggregatePdxDb_MultiThreaded() throws InternalException {
        log.debug("PdxDBCopier.aggregatePdxDb_MultiThreaded() working.");

        final int THREADS_COUNT = 10;

        // check (and create if necessary) local temporary directory
        File localDb = new File(localDbPath);
        if (!localDb.exists()) { // dir doesn't exist
            boolean result = localDb.mkdirs();
            log.debug(String.format("Local PDX dir [%s] doesn't exists. Created [%s].", localDbPath, result));
        } else if (!localDb.isDirectory()) { // dir exists - check is it dir?
            throw new InternalException(String.format("Local PDX dir [%s] exists but isn't a directory!", localDbPath));
        }

        FilenameFilter filter;
        Thread copyingThread; // link to one thread
        ArrayList<Thread> copyingThreads = new ArrayList<>();

        for (Map.Entry<String, String[]> entry : bases.entrySet()) { // cycle for data copy
            for (final String currentTable : entry.getValue()) { // iterating over current db and copying
                filter = new FilenameFilter() { // filter for files in a directory
                    public boolean accept(File dir, String name) {
                        return name.startsWith(currentTable + ".");
                    }
                };

                // list of files in directory (filtered)
                File[] tableFiles = new File(entry.getKey()).listFiles(filter);
                Semaphore semaphore = new Semaphore(THREADS_COUNT);

                // creating copying threads array and start all threads
                copyingThread = new Thread(new CopyingThread(localDbPath, tableFiles, semaphore));
                copyingThread.start();
                copyingThreads.add(copyingThread);

            }
        } // end FOR - iterating over BASES map

        log.debug("All copying threads started. Waits for them to finish.");

        // main thread - join all threads (wait for all threads finish)
        for (Thread thread : copyingThreads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                log.error(String.format("Join operation interrupted! [%s]", e.getMessage()));
            }
        }

        log.debug("Copy finished.");
    }


}