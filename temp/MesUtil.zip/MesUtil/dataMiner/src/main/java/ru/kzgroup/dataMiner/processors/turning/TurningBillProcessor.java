package ru.kzgroup.dataMiner.processors.turning;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.dataProcessing.ProcessorInterface;

import static ru.kzgroup.MesUtilDefaults.*;

/**
 * Processing turning bills information ARMs->MES.
 * Turning data located in ARM system: //pst-fs/asu/USERS/new/spz/DATA
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 13.07.13)
*/

// todo: 13.02.2014 -> turning bills (shop160->shop750) processing is delayed. This class isn't work.

//@Component
//@Transactional
public final class TurningBillProcessor implements ProcessorInterface {

    private Log log = LogFactory.getLog(TurningBillProcessor.class);

    // processing records step for output debug information
    private final static int    COUNTER_DEBUG_STEP        = 1000;

    // paradox data tables
    //private final static String PDX_TABLE1                = ""; // paradox table1 - don't change
    //private final static String PDX_TABLE2                = "";   // paradox table2 = don't change
    // MES DB orders details table
    //private final static String MES_ORDER_DETAILS_TABLE   = "TB_SM_ORDDTL";

    // for oracle table primary key is composite: [PROD_YYMM + ORD_NO + ORD_POSITION]
    private final static String ORDERS_DETAILS_SELECT_SQL = "select PROD_YYMM, ORD_NO, ORD_POSITION, SECTION_CD from TB_SM_ORDDTL";
    // get data from paradox tables
    private final static String PARADOX_DATA_SELECT_SQL   = "select D1.\"Заказ от\", D1.\"Заказ до\", D1.БухЗаказ, D1.ГруппаУчета, D2.ГрЗакБух from " +
            "D00VZACH D1, D00GRP D2 where D1.\"Заказ от\" < ? and D1.\"Заказ до\" > ? and D1.КодПрофОт <= ? and D1.КодПрофДо >= ? and D1.ГруппаУчета = D2.ГруппаУчета";
    // prepared sql for updating data in MES DB
    private final static String ORA_UPDATE_SQL            = "update TB_SM_ORDDTL set FINANCE_ORD_NO = ?, " +
            "FINANCE_ORD_GP_NO = ?, MOD_DDTT = sysdate, MODIFIER = '" + DATAMINER_SERVICE_DBMODIFIER +
            "' where PROD_YYMM = ? and ORD_NO = ? and ORD_POSITION = ?";

    // internal object state
    //private String      paradoxPath;
    //private String      modifierName;

    //@Autowired @Qualifier("pdxJdbcTemplate_Turning")
    //private JdbcTemplate pdxJdbcTemplate;
    //@Autowired @Qualifier("oraJdbcTemplate_COMMON")
    //private JdbcTemplate oraJdbcTemplate;

    public TurningBillProcessor() {} // default constructor for frameworks compatibility

    /***/
    /*
    public TurningBillProcessor(String paradoxPath, OraDbConfig dbConfig, String modifierName) throws DataMinerException {
        //super(dbConfig);
        if (StringUtils.isBlank(paradoxPath) || !new File(paradoxPath).exists() || !new File(paradoxPath).isDirectory()) {
            throw new IllegalArgumentException("Invalid paradox path [" + paradoxPath + "] or empty MES DB config!");
        }
        this.paradoxPath = paradoxPath;
        //this.modifierName = modifierName;
    }
    */


    @Override
    @SuppressWarnings("JDBCResourceOpenedButNotSafelyClosed")
    public void process() {
        log.debug("TurningBillProcessor.process() working.");

        //Connection pdxConnection = null;
        //Connection oraConnection = null;
        try /*(Connection pdxConnection = DbConnFactory.getParadoxConnection(this.paradoxPath);    // Java 7 feature
             Connection oraConnection = DbConnFactory.getOracleConnection(this.getConfig()))*/ {

            // connecting to databases - paradox and oracle
            //pdxConnection = DbConnFactory.getParadoxConnection(this.paradoxPath);
            //oraConnection = DbConnFactory.getOracleConnection(this.getConfig());
            //oraConnection.setAutoCommit(false); // no auto commits
            //log.debug("Connected to MES DB.");

            /*

            // prepared statements
            PreparedStatement pdxPrepStmt   = pdxConnection.prepareStatement(PARADOX_DATA_SELECT_SQL);
            PreparedStatement oraPrepStmt   = oraConnection.prepareStatement(ORA_UPDATE_SQL);

            // receive all orders details (positions) from MES DB
            //ResultSet         ordersDetails = oraConnection.createStatement().executeQuery(ORDERS_DETAILS_SELECT_SQL);
            // get data (executing sql query)
            List<Map<String, Object>> ordersDetailsRows = this.oraJdbcTemplate.queryForList(ORDERS_DETAILS_SELECT_SQL, "");

            // batch update with Spring JDBC Template

            // temporary data
            String orderYYMM     = null;
            String orderNumber   = null;
            String orderPosition = null;
            String sectionCode   = null;

            // processing data cycle
            log.debug("Starting processing cycle.");
            int processedRecordsCount = 0;
            int allRecordsCount       = 0;
            //while (ordersDetails.next()) {
            for (Map oneRow : ordersDetailsRows) {
                // we use try-catch - not stop whole process on one error
                try {
                    // get data from oracle - order position info
                    orderYYMM     = (String) oneRow.get("PROD_YYMM");    //ordersDetails.getString("PROD_YYMM");
                    orderNumber   = (String) oneRow.get("ORD_NO");       //ordersDetails.getString("ORD_NO");
                    orderPosition = (String) oneRow.get("ORD_POSITION"); //ordersDetails.getString("ORD_POSITION");
                    sectionCode   = (String) oneRow.get("SECTION_CD");   //ordersDetails.getString("SECTION_CD");
                    // get info for current Oracle record from Paradox
                    pdxPrepStmt.setString(1, orderNumber);
                    pdxPrepStmt.setString(2, orderNumber);
                    pdxPrepStmt.setString(3, sectionCode);
                    pdxPrepStmt.setString(4, sectionCode);
                    // get data from paradox for current order position from MES DB
                    ResultSet pdxData = pdxPrepStmt.executeQuery();

                    // get data from paradox - two values
                    if (pdxData.next()) {
                        String accountingOrderNo = pdxData.getString("БухЗаказ");
                        if (accountingOrderNo.contains(".")) {
                            accountingOrderNo = accountingOrderNo.substring(0, accountingOrderNo.indexOf(".")); // cut trailing dot
                        }
                        String accountingOrderGroup = pdxData.getString("ГрЗакБух");
                        //log.info("-> " + accountingOrderNo + "  " + accountingOrderGroup);
                        oraPrepStmt.setObject(1, accountingOrderNo);
                        oraPrepStmt.setObject(2, accountingOrderGroup);
                        oraPrepStmt.setObject(3, orderYYMM);
                        oraPrepStmt.setObject(4, orderNumber);
                        oraPrepStmt.setObject(5, orderPosition);
                        // add query to batch
                        oraPrepStmt.addBatch();
                        // increment processed records counter - only if data is OK
                        processedRecordsCount++;
                    } else {
                        log.warn("TurningBills: no data in PDX for: ordYYMM=[" + orderYYMM + "], ordNumber=[" + orderNumber + "], " +
                                "ordPos=[" + orderPosition + "], sectionCode=[" + sectionCode + "].");
                    }
                    // increment all records counter
                    allRecordsCount++;

                    // some debug info
                    if (processedRecordsCount % COUNTER_DEBUG_STEP == 0) {
                        log.debug("Processed records -> " + processedRecordsCount);
                    }
                } catch (SQLException e) {
                    log.error("TurningBills: error data ordYYMM=[" + orderYYMM + "], ordNumber=[" + orderNumber + "], " +
                            "ordPosition=[" + orderPosition + "], sectionCode=[" + sectionCode + "].", e);
                }
            } // end of while

            log.debug("Processing cycle finished.");

            oraPrepStmt.executeBatch(); // execute batch
            oraConnection.commit();     // commit
            log.info("TurningBills: OK. All/processed records = [" + allRecordsCount + "/" + processedRecordsCount + "].");
         */
        } catch (/*SQLException e*/ Exception e) {
            log.error(e);
        } /*finally { // free resources

            if (oraConnection != null) { // close Oracle connection
                try {
                    oraConnection.close();
                } catch (SQLException e) {
                    log.error("Can't close Oracle connection! Reason: " + e.getMessage(), e);
                }
            }

            if (pdxConnection != null) { // close Paradox connection
                try {
                    pdxConnection.close();
                } catch (SQLException e) {
                    log.error("Can't close Paradox connection! Reason: " + e.getMessage(), e);
                }
            }

        } */
        log.debug("TurningBillProcessor finished.");
    }

}