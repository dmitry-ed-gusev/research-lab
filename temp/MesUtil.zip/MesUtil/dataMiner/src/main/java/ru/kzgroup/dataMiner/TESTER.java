package ru.kzgroup.dataMiner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import ru.kzgroup.dataMiner.processors.directories.PdxDBCopier;
import ru.kzgroup.dataMiner.processors.mailer.CustomersMailer;
import ru.kzgroup.exceptions.InternalException;

import java.util.Locale;

/**
 * Class-tester for other classes (test starts).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 03.07.2014)
 */

public class TESTER {

    /***/
    public static void main(String[] args) throws InternalException {
        Log log = LogFactory.getLog(CustomersMailer.class);
        log.info("TESTER starting.");

        /*
        try {
            Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
            while (nets.hasMoreElements()) {
                NetworkInterface iface = nets.nextElement();
                System.out.println("-> " + iface.getDisplayName() + " (" + iface.getName() + ")");
                Enumeration<InetAddress> addresses = iface.getInetAddresses();
                while(addresses.hasMoreElements()) {
                    InetAddress address = addresses.nextElement();
                    System.out.println("\t--> " + address.getHostAddress());
                }
            }
        } catch (SocketException e) {
            log.error(e);
        }

        try {
            System.out.println("-> " + InetAddress.getLocalHost());
        } catch(UnknownHostException e) {
            log.error(e);
        }

        String zzz = ":9090";
        String[] sss = zzz.split(":");

        System.out.println(Arrays.toString(sss) + " " + (StringUtils.isBlank(sss[0])));
        */

        //for (Map.Entry<String, String> entry : System.getenv().entrySet()) {
        //    System.out.println(entry.getKey() + "=" + entry.getValue());
        //}

        Locale.setDefault(Locale.US);
        AbstractApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"spring/DataMinerContext.xml"}, false);
        context.refresh();

        // customers mailer
        //CustomersMailer mailer = (CustomersMailer) context.getBean("customersMailer");
        //mailer.process();

        // -- personnel processor
        //PersonnelProcessor processor = (PersonnelProcessor) context.getBean("personnelProcessor");
        //processor.process();
        //System.exit(111);

        // -- directories processor
        //DirectoriesProcessor processor1 = (DirectoriesProcessor) context.getBean("directoriesProcessor");
        //processor1.process();
        //System.exit(111);

        // -- orders processor
        //DirectoriesProcessor processor2 = (DirectoriesProcessor) context.getBean("ordersProcessor");
        //processor2.process();
        //System.exit(222);

        // -- audit processor
        //DirectoriesProcessor processor = (DirectoriesProcessor) context.getBean("auditProcessor");
        //processor.process();
        //System.exit(333);

        // -- audit reporter
        //AuditReporter reporter = (AuditReporter) context.getBean("auditReporter");
        //reporter.process();
        //System.exit(444);

        // -- test processor
        //DirectoriesProcessor processor = (DirectoriesProcessor) context.getBean("testProcessor");
        //processor.process();
        //System.exit(555);

        // -- pdx data copier
        PdxDBCopier copier = (PdxDBCopier) context.getBean("pdxDBCopier");

        long startTime = System.nanoTime();
        //copier.aggregatePdxDb();
        copier.aggregatePdxDb_MultiThreaded();
        long endTime = System.nanoTime();
        long time = (endTime - startTime) / 1_000_000_000; // nanoseconds -> seconds
        System.out.printf("It takes %s second(s).\n", time);

        System.exit(777);

    }

}