package ru.kzgroup.dataMiner.processors.audit;

import gusev.dmitry.jtils.utils.CommonUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.kzgroup.components.report.reportTable.TextTable;
import ru.kzgroup.components.report.reportTable.TextTableModel;
import ru.kzgroup.dataMiner.processors.directories.DirectoriesProcessor;
import ru.kzgroup.dataProcessing.ProcessorInterface;
import ru.kzgroup.domain.dto.scrap.FurnaceChargeAuditDto;
import ru.kzgroup.domain.dto.scrap.FurnaceChargeDto;
import ru.kzgroup.exceptions.InternalException;
import ru.kzgroup.exceptions.MesException;
import ru.kzgroup.mail.EmailMessage;
import ru.kzgroup.mail.SendMail;

import javax.mail.MessagingException;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Generates and sends (via email) audit reports.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 06.08.2014)
*/

@Component
@Transactional
public class AuditReporter implements ProcessorInterface{

    private final Log log = LogFactory.getLog(AuditReporter.class);

    private final static String           TEMPORARY_DIR    = "c:/temp/auditReporter/";
    private final static SimpleDateFormat DATE_FORMAT      = new SimpleDateFormat("dd-MM-yyyy");
    private final static SimpleDateFormat DATETIME_FORMAT  = new SimpleDateFormat("HH:mm:ss dd-MM-yyyy");
    private final static String[]         REPORT_HEADER    = {"Номер плавки", "Действие", "Материал", "Вес", "Дата плавки", "Дата регистрации"};
    private final static String[]         REPORT_EMPTY_ROW = {"", "", "", "", ""};
    private final static String           EMAIL_SUBJECT    = "Фискальный отчет по металлозавалке с %s по %s.";
    private final static String           EMAIL_TEXT       = "Добрый день!\nВ прилагаемом файле содержится " +
            "отчет по металлозавалке с %s по %s.\n\nСистема MES.";

    @Autowired @Qualifier("oraSpringSessionFactory_COMMON") private SessionFactory oraSessionFactory;
    @Autowired @Qualifier("auditProcessor")                 private DirectoriesProcessor processor;
    @Value("${audit.reporter.mail.recipients}")             private String               mailRecipients;
    @Value("${audit.reporter.mail.smtp.host}")              private String               mailHost;
    @Value("${audit.reporter.mail.smtp.port}")              private int                  mailPort;
    @Value("${audit.reporter.mail.smtp.user}")              private String               mailUser;
    @Value("${audit.reporter.mail.smtp.pass}")              private String               mailPass;
    @Value("${audit.reporter.mail.back.address}")           private String               mailBackAddress;

    /***/
    private TextTable generateAuditReport(Pair<Date, Date> datesRange) throws InternalException {
        log.debug("AuditReporter.generateAuditReport() working [PRIVATE].");

        if (datesRange == null || datesRange.getLeft() == null || datesRange.getRight() == null) {
            throw new InternalException(String.format("Invalid dates range [%s]!", datesRange));
        }

        // working with DB - get data
        Session oraSession = oraSessionFactory.getCurrentSession();
        Query query = oraSession.createQuery("from FurnaceChargeDto fc where fc.meltDate between :startDate and :endDate " +
                "order by fc.meltDate, fc.id.meltNumber, fc.id.scrapCode");
        query.setParameter("startDate", datesRange.getLeft());
        query.setParameter("endDate",   datesRange.getRight());
        List chargesList = query.list();
        log.debug(String.format("Found %s charges.", chargesList.size()));

        // report model
        List<String[]> report          = new ArrayList<>();
        int            currentMelt     = 0; // counter
        Iterator       chargesIterator = chargesList.iterator(); // iterator
        // processing charges list
        while (chargesIterator.hasNext()) {
            FurnaceChargeDto charge = (FurnaceChargeDto) chargesIterator.next();
            String[] oneRow = new String[REPORT_HEADER.length]; // new row for report

            if (currentMelt != charge.getId().getMeltNumber() || !chargesIterator.hasNext()) { // add "deleted" records and/or switch to next melt
                // add DELETED records for current melt and add empty row before next melt (but not before first melt in report)
                if (currentMelt != 0) {
                    // adding DELETED records
                    Query deletedQuery = oraSession.createQuery("from FurnaceChargeAuditDto fca where fca.meltNumber = :meltNumber and " +
                            /*"fca.meltDate = :meltDate and */ "fca.action = 'УДАЛЕНО' order by fca.meltDate");
                    deletedQuery.setParameter("meltNumber", currentMelt);
                    //deletedQuery.setParameter("meltDate", charge.getMeltDate());
                    List auditObjects = deletedQuery.list();
                    for (Object auditObject : auditObjects) {
                        FurnaceChargeAuditDto audit = (FurnaceChargeAuditDto) auditObject;
                        String[] deletedRow = new String[REPORT_HEADER.length];
                        deletedRow[1] = audit.getAction();
                        deletedRow[2] = String.format("%s (%s)", audit.getMaterial().getName(), audit.getMaterial().getCode());
                        deletedRow[3] = String.valueOf(audit.getWeight());
                        deletedRow[4] = DATE_FORMAT.format(audit.getMeltDate());
                        deletedRow[5] = String.format("Рег: %s", (audit.getRegisterDate() == null ? "-" : DATETIME_FORMAT.format(audit.getRegisterDate())));
                        report.add(deletedRow); // add row to report
                    }
                    if (currentMelt != charge.getId().getMeltNumber()) { // add empty row
                        report.add(REPORT_EMPTY_ROW);
                    }
                } // end of "adding deleted" action

                if (currentMelt != charge.getId().getMeltNumber()) { // switch to next melt
                    currentMelt = charge.getId().getMeltNumber();
                    oneRow[0] = String.valueOf(currentMelt);
                }
            }

            // add data to one report row
            oneRow[1] = "------";
            oneRow[2] = String.format("%s (%s)", charge.getMaterial().getName(), charge.getMaterial().getCode());
            oneRow[3] = String.valueOf(charge.getWeight());
            oneRow[4] = DATE_FORMAT.format(charge.getMeltDate());
            String registerDate = (charge.getRegisterDate() == null ? "-" : DATETIME_FORMAT.format(charge.getRegisterDate()));
            String modifyDate   = (charge.getModifyDate() == null ? "-" : DATETIME_FORMAT.format(charge.getModifyDate()));
            oneRow[5] = String.format("Рег: %s; Мод: %s", registerDate, modifyDate);
            // add row to report
            report.add(oneRow);

            // add changes for current report row (one charge)
            Set<FurnaceChargeAuditDto> auditRecords = charge.getChanges();
            for (FurnaceChargeAuditDto auditRecord : auditRecords) {
                String[] auditRow = new String[REPORT_HEADER.length];
                auditRow[1] = auditRecord.getAction();
                auditRow[2] = String.format("%s (%s)", auditRecord.getMaterial().getName(), auditRecord.getMaterial().getCode());
                auditRow[3] = String.valueOf(auditRecord.getWeight());
                auditRow[4] = DATE_FORMAT.format(auditRecord.getMeltDate());
                auditRow[5] = String.format("Рег: %s", (auditRecord.getRegisterDate() == null ? "-" : DATETIME_FORMAT.format(auditRecord.getRegisterDate())));
                // add row to report
                report.add(auditRow);
            }

        } // end of WHILE - iteration over charges list

        // text table model and text table component creating
        TextTableModel model = new TextTableModel(REPORT_HEADER, report.toArray(new String[report.size()][]));
        return new TextTable(model);
    }

    /***/
    private void sendAuditReport(TextTable report, Pair<Date, Date> range) throws InternalException, MesException, IOException, MessagingException {
        log.debug("AuditReporter.sendAuditReport() working.");

        if (report == null) { // internal cjeck - is report object null or not?
            throw new InternalException("Empty audit report!");
        }

        // check temporary directory and create it (dir name includes current date and time)
        String tmpDirStr = TEMPORARY_DIR + new SimpleDateFormat("dd.MM.yyyy_HH-mm-ss").format(new Date());
        File tmpDir = new File(tmpDirStr);
        if (!tmpDir.exists()) { // dir doesn't exist
            boolean result = tmpDir.mkdirs();
            log.debug(String.format("Temporary dir [%s] doesn't exists. Created [%s].", TEMPORARY_DIR, result));
        } else if (!tmpDir.isDirectory()) { // dir exists - check is it dir?
            throw new InternalException(String.format("Temporary dir [%s] exists but isn't a directory!", TEMPORARY_DIR));
        }

        // SendMail object - used for customers mailing and for consolidated report
        SendMail sendMail = new SendMail(this.mailHost, this.mailPort, this.mailUser, this.mailPass, this.mailBackAddress);
        String auditReportFile = tmpDirStr + "/auditReport.xls";
        // export to excel
        report.exportToExcelFile(auditReportFile, "Отчет по металлозавалке");
        // creating email message
        EmailMessage message = new EmailMessage();
        message.setSubject(String.format(EMAIL_SUBJECT, DATETIME_FORMAT.format(range.getLeft()), DATETIME_FORMAT.format(range.getRight())));
        message.setText(String.format(EMAIL_TEXT, DATETIME_FORMAT.format(range.getLeft()), DATETIME_FORMAT.format(range.getRight())));
        // add attachements
        Map<String, File> attachments = new HashMap<>();
        attachments.put("audit_report", new File(auditReportFile));
        message.setFiles(attachments);
        // sending consolidated report
        sendMail.setMessage(message);
        sendMail.setRecipients(this.mailRecipients);
        sendMail.sendMessage();
    }

    @Override
    public void process() {
        log.debug("AuditReporter.process() working.");
        this.processor.process(); // copy data PDX->ORA with audit
        log.debug("Audit data updated (PDX->ORA).");
        // start and end dates of month (from first day of previous month till last day of current month)
        Pair<Date, Date> monthRange = CommonUtils.getMonthDateRange(-1, 0);
        try {
            // generate audit report
            TextTable report = this.generateAuditReport(monthRange);
            log.debug("Audit report generated.");
            this.sendAuditReport(report, monthRange);// generate report and send it
            log.debug("Audit report has been sent.");
        } catch (InternalException | IOException | MesException | MessagingException e) {
            log.error("Can't generate/send audit report: " + e.getMessage());
        }
    }


}