package ru.kzgroup.dataMiner.processors.personnel;

import com.healthmarketscience.jackcess.Database;
import com.healthmarketscience.jackcess.Table;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.domain.dao.personnel.ActiveDirectoryDao;
import ru.kzgroup.domain.dto.personnel.ADUserInfoDto;
import ru.kzgroup.domain.dto.personnel.DepartmentDto;
import ru.kzgroup.domain.dto.personnel.EmployeeDto;

import javax.naming.NamingException;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Utility class for work with Personnel DB (MS Access).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 25.02.14)
*/

public class PersonnelHelper {

    private static Log log = LogFactory.getLog(PersonnelHelper.class);

    // Date/time format for Personnel DB (Boss-Kadrovik, MS Access).
    private static final SimpleDateFormat PERSONNELDB_DATETIME_FORMAT = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.US);
    // tables (Personnel DB)
    private static final String TABLE_DEPTS = "Подразделения";
    private static final String TABLE_EMPLS = "Работники";
    // fields (Personnel DB, both depts/employees tables)
    private static final String FIELD_DEPT_ID             = "REG_DEPARTMENT_NO";
    private static final String FIELD_DEPT_CODE           = "DEPARTMENT_NO";
    private static final String FIELD_DEPT_NAME           = "DEPARTMENT_FULL_NAME";
    private static final String FIELD_DEPT_ACTION_DATE_TO = "ACTION_DATE_TO";
    private static final String FIELD_EMPL_ID             = "WORKER_ID";
    private static final String FIELD_EMPL_LAST_NAME      = "LAST_NAME";
    private static final String FIELD_EMPL_FIRST_NAME     = "FIRST_NAME";
    private static final String FIELD_EMPL_PATRONYMIC     = "PATRONYMIC";
    private static final String FIELD_EMPL_CLOCK_NO       = "CLOCK_NO";
    private static final String FIELD_EMPL_BIRTH_DATE     = "BIRTH_DATE";
    private static final String FIELD_EMPL_DISMISSAL_DATE = "DISMISSAL_DATE";

    /**
     * Method returns departments of plant in a map [dept id -> dept object] from personnal database (MS Access).
     * @param personnelFile String
     * @return Map[Integer, DepartmentDto]
     * @throws java.io.IOException
    */
    public static List<DepartmentDto> getDepartments(String personnelFile) throws IOException {
        log.debug("PersonnelHelper.getDepartments() working.");
        // we use TreeMap, bacuse it's sorted by keys in natural order
        List<DepartmentDto> departmentsList = new ArrayList<>();
        File personnelDbFile = new File(personnelFile); // read personnel db file
        Database personnelDb = null;
        try {
            // open MS ACCESS db and read tables (personnel and departments)
            personnelDb = Database.open(personnelDbFile);
            Table departmentsTable = personnelDb.getTable(TABLE_DEPTS);
            // current date for check: is current processing department alive?
            Date currentDate = new Date();
            for (Map<String, Object> departmentRow : departmentsTable) {
                try {
                    int deptId = Integer.parseInt(String.valueOf(departmentRow.get(FIELD_DEPT_ID)));
                    String deptCode = String.valueOf(departmentRow.get(FIELD_DEPT_CODE));
                    String deptName = String.valueOf(departmentRow.get(FIELD_DEPT_NAME));
                    // date of death (closing) for department, for alive depts it is in future
                    Date deptActionDateTo;
                    boolean isAlive;
                    try {
                        deptActionDateTo = PERSONNELDB_DATETIME_FORMAT.parse(String.valueOf(departmentRow.get(FIELD_DEPT_ACTION_DATE_TO)));
                        isAlive = deptActionDateTo.after(currentDate);
                    } catch (ParseException e) {
                        log.error("Can't parse department ACTION_DATE_TO value [" + String.valueOf(departmentRow.get(FIELD_DEPT_ACTION_DATE_TO)) + "]!", e);
                        isAlive = false;
                    }
                    // create deprtment object instance and put it into resulting map
                    DepartmentDto deptDto = new DepartmentDto();
                    deptDto.setId(deptId);
                    deptDto.setDeptCode(deptCode);
                    deptDto.setDeptName(deptName);
                    deptDto.setAlive((isAlive ? "Y" : "N"));
                    departmentsList.add(deptDto);
                } catch (NumberFormatException e) {
                    log.error(e);
                }
            } // end of while cycle -> searching for department name
        } finally { // we will try to release used resources
            if (personnelDb != null) { // close personnel db
                try {
                    personnelDb.close();
                } catch (IOException e) {
                    log.error(String.format("Can't close personnel db [%s]!", personnelFile), e);
                }
            }
        }
        return departmentsList;
    }

    /***/
    public static List<EmployeeDto> getEmployees(String personnelFile, ActiveDirectoryDao adDao) throws IOException, NamingException {
        log.debug("PersonnelHelper.getEmployees() working.");
        List<EmployeeDto> employeesList = new ArrayList<>();
        File personnelDbFile  = new File(personnelFile); // personnel db file
        Database personnelDb = null;
        try {
            personnelDb = Database.open(personnelDbFile); // open MS ACCESS db and read tables (personnel)
            Table employeesTable = personnelDb.getTable(TABLE_EMPLS);
            adDao.ldapConnect();           // open connection to Active Directory
            Date currentDate = new Date(); // current date for check: is current processing employee alive or fired?
            for(Map<String, Object> employeeRow : employeesTable) { // iterate trough rows and get data
                // try..catch - for catching parse exceptions, if it occurs, we will skip whole line
                try {
                    int    id       = Integer.parseInt(String.valueOf(employeeRow.get(FIELD_EMPL_ID)));
                    String fullName = String.format("%s %s %s", String.valueOf(employeeRow.get(FIELD_EMPL_LAST_NAME)),
                            String.valueOf(employeeRow.get(FIELD_EMPL_FIRST_NAME)), String.valueOf(employeeRow.get(FIELD_EMPL_PATRONYMIC)));
                    // search user login and email in Active Directory
                    ADUserInfoDto adInfo = adDao.getADUserInfo(fullName);
                    String login = (adInfo == null ? null : adInfo.getLogin());
                    String email = (adInfo == null ? null : adInfo.getEmail());
                    int deptId = Integer.parseInt(String.valueOf(employeeRow.get(FIELD_DEPT_ID))); // department id
                    String number = String.valueOf(employeeRow.get(FIELD_EMPL_CLOCK_NO));          // another data from personnel db
                    Date birthDate; // employeeDto birth date
                    try {
                        birthDate = PERSONNELDB_DATETIME_FORMAT.parse(String.valueOf(employeeRow.get(FIELD_EMPL_BIRTH_DATE)));
                    } catch (ParseException e) {
                        log.error("Can't parse birth date value [" + String.valueOf(employeeRow.get(FIELD_EMPL_BIRTH_DATE)) + "]!", e);
                        birthDate = null;
                    }
                    boolean isAlive; // is current employee alive or not?
                    try {
                        Date fireDate = PERSONNELDB_DATETIME_FORMAT.parse(String.valueOf(employeeRow.get(FIELD_EMPL_DISMISSAL_DATE)));
                        isAlive = fireDate.after(currentDate);
                    } catch (ParseException e) {
                        log.error("Can't parse employee DISMISSAL_DATE value [" + String.valueOf(employeeRow.get(FIELD_EMPL_DISMISSAL_DATE)) + "]!", e);
                        isAlive = false;
                    }
                    // creating new EmployeeDto object
                    EmployeeDto employeeDto = new EmployeeDto(id, fullName, deptId, null, null, number, birthDate, login, email, isAlive);
                    employeesList.add(employeeDto);
                } catch (NumberFormatException e) { // we will catch conversion errors and continue cycle
                    log.error(e);
                }
            } // end of FOR
        } finally { // we will try to release used resources
            if (adDao != null) { // close ldap connection
                try {
                    adDao.ldapDisconnect();
                } catch (NamingException e) {
                    log.error("Can't close LDAP connection!", e);
                }
            }
            if (personnelDb != null) { // close personnel db
                try {
                    personnelDb.close();
                } catch (IOException e) {
                    log.error("Can't close personnel db [" + personnelFile + "]!", e);
                }
            }

        }
        return employeesList;
    }

}