package ru.kzgroup.dataMiner.processors.mailer;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.kzgroup.exceptions.InternalException;
import ru.kzgroup.exceptions.MesException;
import ru.kzgroup.components.report.reportTable.TextTable;
import ru.kzgroup.components.report.reportTable.TextTableModel;
import ru.kzgroup.dataMiner.processors.directories.DirectoriesProcessor;
import ru.kzgroup.dataProcessing.ProcessorInterface;
import ru.kzgroup.domain.dto.customers.CustomerDto;
import ru.kzgroup.domain.dto.customers.CustomerEmailDto;
import ru.kzgroup.domain.dto.customers.report.CustomerReport;
import ru.kzgroup.domain.dto.customers.report.ReportPosition;
import ru.kzgroup.domain.dto.goods.FinishedGoodsItemDto;
import ru.kzgroup.mail.EmailMessage;
import ru.kzgroup.mail.SendMail;

import javax.mail.MessagingException;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Component for mailing customers - data about finished goods items on our warehouse.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 20.03.2014)
*/

@Component
@Transactional
public class CustomersMailer implements ProcessorInterface {

    private final Log log = LogFactory.getLog(CustomersMailer.class);

    //
    private static final String TEMPORARY_DIR = "c:/temp/customersMailer/";
    // email to customer - subject and text
    private static final String EMAIL_SUBJECT = "Отправка данных о наличии готовой продукции на складе " +
            "ЗАО \"Металлургический завод \"Петросталь\" по состоянию на %s.";
    private static final String EMAIL_TEXT = "Просим Вас обеспечивать вывоз готовой продукции не позднее 10 дней с " +
            "даты поступления на склад. Данное письмо сформировано автоматически и не требует ответа.";
    // control email - subject and text
    private static final String EMAIL_CONTROL_SUBJECT = "Контрольное письмо электронной почтовой рассылки клиентам. Режим [%s].";
    private static final String EMAIL_CONTROL_TEXT    = "Добрый день!\nВ прилагаемом файле содержится сводный " +
            "отчет о разосланных клиентам данных.\nРежим [%s].\n\nСистема MES.";
    // use this email for mailing (=1) or not (other) - sign in MES DB
    private static final String MAIL_TAKE_PART_IN_MAILING_SIGN = "1";

    @Autowired @Qualifier("directoriesProcessor")           private DirectoriesProcessor directoriesProcessor; // directories processor
    @Autowired @Qualifier("oraSpringSessionFactory_COMMON") private SessionFactory       oraSessionFactory;     // session factory for Oracle
    @Value("${customers.mailer.control.email}")             private String               controlEmail;          // email (if > 1 -> comma separated)
    @Value("${customers.mailer.smtp.host}")                 private String               mailHost;
    @Value("${customers.mailer.smtp.port}")                 private int                  mailPort;
    @Value("${customers.mailer.smtp.user}")                 private String               mailUser;
    @Value("${customers.mailer.smtp.pass}")                 private String               mailPass;
    @Value("${customers.mailer.back.address}")              private String               mailBackAddress;
    @Value("${customers.mailer.test.mode}")                 private boolean              isTestMode;
    @Value("${customers.mailer.update.dictionaries}")       private boolean              isUpdateDictionaries;

    /**
     * @return List[CustomerReport] - data ready for mailing.
    */
    private List<CustomerReport> getCustomersReports() {
        Session oraSession = oraSessionFactory.getCurrentSession();
        // Get data about finished goods in shop 180. This goods are awaiting for their customers to take. Result is ordered by
        // customer and by date. In report we will use this order (and preserve it) by using LinkedHashMap.
        // Выборка неотгруженной готовой продукции из Paradox (M149): select * from M149 where 'Дата отгр.цехом' is null and 'ДатаОтгрВЦех180' is not null
        List items = oraSession.createQuery("from FinishedGoodsItemDto fgi where fgi.fromShopShipmentDate is null and fgi.toShopShipmentDate is not null " +
                "order by fgi.customerCode, fgi.warehouseDate").list();
        // preparing data iteration cycle
        List<CustomerReport> reports = new ArrayList<>();
        int currentCustomerCode = -1;
        CustomerReport currentReport = null;
        // data iteration cycle
        for (Object object : items) {
            oraSession.refresh(object); // reload object from persistent storage
            FinishedGoodsItemDto item = (FinishedGoodsItemDto) object;

            if (currentCustomerCode != item.getCustomerCode()) { // next (new) customer
                currentCustomerCode = item.getCustomerCode(); // switch to next (new) customer
                // add previous report to list (if it isn't null)
                if (currentReport != null) {
                    reports.add(currentReport);
                }
                // creating new empty report for next (new) customer
                try {
                    currentReport = new CustomerReport(item.getCustomer());
                } catch (InternalException e) {
                    log.error(String.format("Can't create new CustomerReport object! " +
                            "FinishedGoodsItem customer code = %s. Error message->[%s].", item.getCustomerCode(), e.getMessage()));
                    currentReport = null;
                }

            } // end of IF section for next (new) customer

            try { // try to add new position to customer report
                if (currentReport != null) {
                    currentReport.addReportPosition(new ReportPosition(item.getOrderNumber(), item.getSteelGrade().getName(),
                            item.getSection().getName(), item.getSize1(), item.getSize2(), item.getWarehouseDate()), item.getWeight());
                } else {
                    log.warn("CustomerReport object is NULL!");
                }
            } catch (InternalException e) {
                log.error(String.format("Error adding report position: customer=%s.", item.getCustomer()), e);
            }
        } // end of FOR cycle -> customers reports creating

        if (currentReport != null) { // last created report
            reports.add(currentReport);
        }

        return reports;
    }

    /***/
    private void sendReports(List<CustomerReport> reports) throws InternalException {
        log.debug("CustomersMailer.sendReports() working.");

        if (this.isTestMode) { // test mode message
            log.warn("Test mode is [ON]! Only consolidated report will be sent!");
        }

        // check temporary directory and create it (dir name includes current date and time)
        String tmpDirStr = TEMPORARY_DIR + new SimpleDateFormat("dd.MM.yyyy_hh-mm-ss").format(new Date());
        File tmpDir = new File(tmpDirStr);
        if (!tmpDir.exists()) { // dir doesn't exist
            boolean result = tmpDir.mkdirs();
            log.debug(String.format("Temporary dir [%s] doesn't exists. Created [%s].", TEMPORARY_DIR, result));
        } else if (!tmpDir.isDirectory()) { // dir exists - check is it dir?
            throw new InternalException(String.format("Temporary dir [%s] exists but isn't a directory!", TEMPORARY_DIR));
        }

        try {
            // SendMail object - used for customers mailing and for consolidated report
            SendMail sendMail = new SendMail(this.mailHost, this.mailPort, this.mailUser, this.mailPass, this.mailBackAddress);
            // consolidated "big" report
            List<String[]> consolidated = new ArrayList<>();
            // current date
            String currentDate = new SimpleDateFormat("dd.MM.yyyy").format(new Date());
            for (CustomerReport report : reports) { // iterating over reports and processing its

                CustomerDto customer = report.getCustomer(); // customer for current report - should be present (not null) in any case!
                // add current report data matrix to consolidated model
                String[][] currentReportMatrix = report.getReportDataMatrix(true);
                Collections.addAll(consolidated, currentReportMatrix); // add data to consolidated report
                // status message for consolidated report
                StringBuilder status = new StringBuilder(String.format("Код заказчика: %s\n Emails: ", customer.getCode()));

                String currentCustomerReportXLS = tmpDirStr + "/" + customer.getCode() + ".xls";
                // table model and table component
                TextTableModel currentReportModel = new TextTableModel(CustomerReport.getReportHeader(), currentReportMatrix);
                TextTable      currentReportTable = new TextTable(currentReportModel);

                try { // export current customer report to excel and send it via email

                    // We export report to excel in any case - no matter, will we send it or not.
                    currentReportTable.exportToExcelFile(currentCustomerReportXLS, "Данные по наличию металла");

                    if (!this.isTestMode) { // if we are in 'real' mode - create email message
                        // creating email message
                        EmailMessage message = new EmailMessage();
                        message.setSubject(String.format(EMAIL_SUBJECT, currentDate));
                        message.setText(EMAIL_TEXT);
                        Map<String, File> attachments = new HashMap<>();
                        attachments.put("customerReport", new File(currentCustomerReportXLS));
                        message.setFiles(attachments);
                        // put message to send mail object
                        sendMail.setMessage(message);
                    }

                    // all preparation are done - send email if there is customer email and customer taking part in mailing (sign=1)
                    if (!customer.getEmails().isEmpty()) {
                        int counter = 1;
                        Set<CustomerEmailDto> emailsList = customer.getEmails();
                        for (CustomerEmailDto email : emailsList) { // iterating over customer emails list and send messages
                            if (!StringUtils.isBlank(email.getEmail()) && MAIL_TAKE_PART_IN_MAILING_SIGN.equals(email.getUseInMailing())) { // ok - sending
                                if (!this.isTestMode) { // set only in 'real' mode!
                                    sendMail.setRecipients(email.getEmail()); // set recipient - current customer email address
                                }
                                try {
                                    if (!this.isTestMode) { // send message only in 'real' mode!
                                        sendMail.sendMessage();
                                    }
                                    status.append(email.getEmail()).append((this.isTestMode ? " (test-not sent!)" : " (ok)"))
                                            .append(counter < emailsList.size() ? "\n" : "");
                                } catch (MessagingException e) {
                                    log.error(String.format("Can't send to address [%s]! Reason->[%s].", email.getEmail(), e.getMessage()));
                                    status.append(email.getEmail()).append(" (fail)").append(counter < emailsList.size() ? "\n" : "");
                                }

                            } else { // skip email for customer
                                log.info(String.format("Address skipped [%s].", email.getEmail()));
                                status.append(email.getEmail()).append(" (skipped)").append(counter < emailsList.size() ? "\n" : "");
                            }
                            counter++;
                        }
                    } else { // no emails for this customer or customer doesn't take part in mailing
                        status.append("-");
                    }
                } catch (IOException e) { // exception if we can't export data to excel
                    log.error(e);
                }
                // technical info to consolidated report
                consolidated.add(new String[] {"*****", status.toString(), "*****", "*****", "*****", "*****", "*****", "*****"});
            } // end of FOR cycle - reports processing

            // export consolidated report to excel and send it via email
            TextTableModel model = new TextTableModel(CustomerReport.getReportHeader(),
                    consolidated.toArray(new String[CustomerReport.getReportEmptyLine().length][consolidated.size()]));
            TextTable table = new TextTable(model);
            String consolidatedReportFile = tmpDirStr + "/consolidated.xls";
            try {
                // export to excel
                table.exportToExcelFile(consolidatedReportFile, "Данные по наличию металла (общие)");
                // creating email message
                EmailMessage message = new EmailMessage();
                // set subject and text for message - depending on mode
                String modeMessage = (this.isTestMode ? "тест, только контрольное письмо" : "реальная отправка заказчикам");
                message.setSubject(String.format(EMAIL_CONTROL_SUBJECT, modeMessage));
                message.setText(String.format(EMAIL_CONTROL_TEXT, modeMessage));
                // add attachements
                Map<String, File> attachments = new HashMap<>();
                attachments.put("consolidated", new File(consolidatedReportFile));
                message.setFiles(attachments);
                // sending consolidated report
                sendMail.setMessage(message);
                sendMail.setRecipients(this.controlEmail);
                sendMail.sendMessage();
            } catch (IOException | MessagingException e) {
                log.error(e);
            }
        } catch (MesException e) { // envelope MesEception->InternalException and rethrow
            throw new InternalException(e);
        }

    }

    /***/
    @Override
    public void process() {
        log.debug("CustomersMailer.process() working");
        // copy Paradox tables in local storage
        log.info(String.format("Updaing dictionaries mode [%s].", this.isUpdateDictionaries));
        if (this.isUpdateDictionaries) {
            this.directoriesProcessor.process(); // copy all directories PDX->ORA
        }
        // generate customers reports
        List<CustomerReport> reports = this.getCustomersReports(); // generate customers reports (finished goods on our warehouse)
        log.debug(String.format("All reports are built. Reports count [%s].", reports.size()));
        try { // try to mail all data
            this.sendReports(reports);
        } catch (InternalException e) {
            log.error(String.format("Can't send reports! Reason->[%s].", e.getMessage()));
        }
        log.info(String.format("Reports->%s.", reports.size()));
    }

}