package ru.kzgroup.dataMiner.processors.directories;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.CacheMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import ru.kzgroup.dataProcessing.ProcessorInterface;
import ru.kzgroup.domain.dto.BaseDto;
import ru.kzgroup.domain.dto.contracts.ContractDto;
import ru.kzgroup.domain.dto.directories.SectionDto;
import ru.kzgroup.domain.dto.orders.ora.OrderDtoORA;
import ru.kzgroup.domain.dto.orders.pdx.OrderDtoPDX;
import ru.kzgroup.domain.dto.rawTables.RK110.RK110Dto;
import ru.kzgroup.domain.dto.scrap.FurnaceChargeAuditDto;
import ru.kzgroup.domain.dto.scrap.FurnaceChargeDto;
import ru.kzgroup.domain.dto.scrap.FurnaceChargeDtoId;
import ru.kzgroup.exceptions.InternalException;

import java.math.BigDecimal;
import java.util.*;

import static ru.kzgroup.MesUtilDefaults.DATAMINER_SERVICE_DBMODIFIER;
import static ru.kzgroup.MesUtilDefaults.SESSION_FLUSH_STEP;
import static ru.kzgroup.MesUtilMessages.MSG_DIRECTORY_PROCESSED;

/**
 * Directories processor engine module - copy Hibernate mapped classes from Paradox to Oracle.
 * @author Gusev Dmitry (gusevd)
 * @version 2.0 (DATE: 16.07.14)
*/

// todo: points to FLUSH/CLEAR Oracle session - ???? check it!
// todo: use one reference to oracle session in class instance (share it within all methods)?

public class DirectoriesProcessor<T extends BaseDto> implements ProcessorInterface {

    private final Log log = LogFactory.getLog(DirectoriesProcessor.class);

    private Map<Class<T>, List<String>> classes;                   // classes map - classes for copy PDX->ORA
    private PdxDBCopier                 pdxDBCopier;               // copier module - copy PDX tables in one local database
    private SessionFactory              oraSessionFactory;         // Oracle DBMS Session Factory
    private SessionFactory              pdxSessionFactory;         // Paradox DBMS Session Factory
    private Map<String, String>         sectionsMap        = null; // implementation detail
    private boolean                     aggregatePdxTables = true; // internal value - aggregate PDX tables into local folder or not

    public SessionFactory getOraSessionFactory() {
        return oraSessionFactory;
    }

    public void setOraSessionFactory(SessionFactory oraSessionFactory) {
        this.oraSessionFactory = oraSessionFactory;
    }

    public SessionFactory getPdxSessionFactory() {
        return pdxSessionFactory;
    }

    public void setPdxSessionFactory(SessionFactory pdxSessionFactory) {
        this.pdxSessionFactory = pdxSessionFactory;
    }

    public Map<Class<T>, List<String>> getClasses() {
        return classes;
    }

    public void setClasses(Map<Class<T>, List<String>> classes) {
        this.classes = classes;
    }

    public PdxDBCopier getPdxDBCopier() {
        return pdxDBCopier;
    }

    public void setPdxDBCopier(PdxDBCopier pdxDBCopier) {
        this.pdxDBCopier = pdxDBCopier;
    }

    /***/
    private Map<String, String> getSectionsMap() {
        if (this.sectionsMap == null) { // field isn't initialized yet - initialize!
            Session oraSession = oraSessionFactory.getCurrentSession();
            List sections = oraSession.createQuery("from SectionDto").list();
            this.sectionsMap = new HashMap<>();
            for (Object object : sections) {
                SectionDto section = (SectionDto) object;
                this.sectionsMap.put(section.getCode(), section.getType());
            }
        }
        return this.sectionsMap; // return internal field
    }

    /***/
    private void preProcessing(Class<T> clazz) {
        log.debug("DirectoriesProcessor.preProcessing() working. Class = " + clazz.getName());

        Session oraSession = oraSessionFactory.getCurrentSession();
        String query;
        int    updatedRecords;
        if (clazz.getName().equals(OrderDtoPDX.class.getName())) { // for ORDERS processing is different (Paradox DB->OrderPDX->OrderORA->Oracle DB)
            query = "update OrderDtoORA set deleted = 1"; // update Orders headers
            updatedRecords = oraSession.createQuery(query).executeUpdate();
            log.debug(String.format("Class [OrderDtoORA]. Updated %s records.", updatedRecords));
            query = "update OrderPositionDtoORA set deleted = 1"; // update Orders positions
            updatedRecords = oraSession.createQuery(query).executeUpdate();
            log.debug(String.format("Class [OrderPositionDtoORA]. Updated %s records.", updatedRecords));
            query = "update OrderIngredientDtoORA set deleted = 1"; // update Orders ingredients
            updatedRecords = oraSession.createQuery(query).executeUpdate();
            log.debug(String.format("Class [OrderIngredientDtoORA]. Updated %s records.", updatedRecords));
            query = "update OrderExtraItemDtoORA set deleted = 1"; // update Orders extra items
            updatedRecords = oraSession.createQuery(query).executeUpdate();
            log.debug(String.format("Class [OrderExtraItemDtoORA]. Updated %s records.", updatedRecords));
        } else {
            query = String.format("update %s set deleted = 1", clazz.getName());
            updatedRecords = oraSession.createQuery(query).executeUpdate();
            log.debug(String.format("Class [%s]. Updated %s records.", clazz.getName(), updatedRecords));
        }
        // sych session with persistent storage (DBMS)
        oraSession.flush();
        oraSession.clear();
    }

    /***/
    private void postProcessing(Class<T> clazz) {
        log.debug("DirectoriesProcessor.postProcessing() working.");

        Session oraSession = oraSessionFactory.getCurrentSession(); // get current session

        if (clazz.getName().equals(OrderDtoPDX.class.getName())) { // post processing for Orders

            String query;
            int    deletedRecords;
            query = "delete from OrderDtoORA where deleted = 1"; // delete Orders headers deleted in ARMs
            deletedRecords = oraSession.createQuery(query).executeUpdate();
            log.debug(String.format("Class [OrderDtoORA]. Deleted %s records.", deletedRecords));
            query = "delete from OrderPositionDtoORA where deleted = 1"; // delete Orders positions deleted in ARMs
            deletedRecords = oraSession.createQuery(query).executeUpdate();
            log.debug(String.format("Class [OrderPositionDtoORA]. Deleted %s records.", deletedRecords));
            query = "delete from OrderIngredientDtoORA where deleted = 1"; // delete Orders ingredients deleted in ARMs
            deletedRecords = oraSession.createQuery(query).executeUpdate();
            log.debug(String.format("Class [OrderIngredientDtoORA]. Deleted %s records.", deletedRecords));
            query = "delete from OrderExtraItemDtoORA where deleted = 1"; // delete Orders extra items deleted in ARMs
            deletedRecords = oraSession.createQuery(query).executeUpdate();
            log.debug(String.format("Class [OrderExtraItemDtoORA]. Deleted %s records.", deletedRecords));

        } else if (clazz.getName().equals(FurnaceChargeDto.class.getName())) { // postprocessing for FurnaceChargeDto
            log.debug("Postprocessing for " + FurnaceChargeDto.class.getName());
            List deletedObjects = oraSession.createQuery("from FurnaceChargeDto where deleted = 1").list();
            log.debug(String.format("Deleted %s record(s).", deletedObjects.size()));
            Date registerDate = new Date();
            // record deleted data and delete it from data table
            for (Object deletedObject : deletedObjects) {
                FurnaceChargeDto furnaceChargeDto = (FurnaceChargeDto) deletedObject;
                FurnaceChargeAuditDto auditEntry = new FurnaceChargeAuditDto("УДАЛЕНО", furnaceChargeDto);
                auditEntry.setRegisterDate(registerDate);
                auditEntry.setRegisterUser(DATAMINER_SERVICE_DBMODIFIER);
                oraSession.save(auditEntry);      // save (insert) audit data
                oraSession.delete(deletedObject); // delete object from data table
            }
        } else {
            int deletedRecords = oraSession.createQuery(String.format("delete from %s where deleted = 1", clazz.getName())).executeUpdate();
            log.debug(String.format("Class [%s]. Deleted %s records.", clazz.getName(), deletedRecords));
        }
        // clear and flush - for every class
        oraSession.flush(); // force session to flush
        oraSession.clear(); // clear session
    }

    /***/
    private void copyDataPDXToORA() {
        log.debug("DirectoriesProcessor.copyDataPDXToORA() working.");
        Session pdxSession = null;
        Session oraSession = null;
        try {
            if (this.classes != null && !this.classes.isEmpty()) { // data is ok - there are classes
                log.debug("Set of classes is not empty - processing.");
                pdxSession = pdxSessionFactory.openSession();       // paradox session
                oraSession = oraSessionFactory.getCurrentSession(); // oracle session

                oraSession.setCacheMode(CacheMode.IGNORE);

                Date date = new Date();                             // one date for all processed records (modify/register date)

                Class<T> clazz;
                for (Map.Entry<Class<T>, List<String>> clazzEntry : this.classes.entrySet()) { // iterate over MAP
                    clazz = clazzEntry.getKey();   // class for querying DB (entity)

                    // preprocessing for current class
                    this.preProcessing(clazz);

                    List<String> hqlsList = clazzEntry.getValue(); // list of hql queries for entity class
                    if (hqlsList == null || hqlsList.isEmpty()) { // if hql queries not present - use default hql query
                        String hqlQuery = "from " + clazz.getName();
                        log.debug(String.format("No HQL queries - using default query [%s].", hqlQuery));
                        hqlsList = Arrays.asList(hqlQuery);
                    }

                    List     objects;       // objects loaded from source DB (entities)
                    Iterator iterator;      // iterator over collection of loaded entities
                    boolean  isMergeAction; // merge entity from PDX to ORA - do/don't
                    for (String query : hqlsList) { // iterating over hql queries for current entity class
                        log.debug(String.format("HQL query [%s].", query));
                        objects = pdxSession.createQuery(query).list();
                        if (objects != null && !objects.isEmpty()) { // if we receive non-empty list, we process it
                            log.debug(String.format("Processing [%s] upload to Oracle (MES). Paradox: found [%s] objects.", clazz.getSimpleName(), objects.size()));

                            int mergeCounter   = 0;                  // counter for real merge operations
                            int auditCounter   = 0;                  // counter for real audit records create operations
                            int objectsCounter = 0;                  // processed objects counter - for debug
                            int totalCounter   = objects.size();     // total objects counter
                            iterator           = objects.iterator(); // iterator over objects collection

                            // References to processing objects. If we define this regerences in loop body, we create new reference
                            // every iteration and eat all memory. If we define reference outside the loop - we reuse one reference
                            // and save resources and pandas! :)
                            Object  object;
                            BaseDto baseDto;
                            BigDecimal oraWeight;
                            BigDecimal pdxWeight;
                            while (iterator.hasNext()) { // data upload cycle
                                isMergeAction = true; // process merge (default value for current processing entity)
                                object = iterator.next();
                                try {
                                    // todo: use design pattern - Strategy, Command?
                                    // check - what is object type inside?
                                    if (object instanceof ContractDto) { // <----------------------------- ContractDto (special processing)
                                        ContractDto contract = (ContractDto) object;
                                        // remove all new line/line separator symbols from "subject" field
                                        String subject = contract.getSubject();
                                        if (!StringUtils.isBlank(subject)) {
                                            subject = subject.replaceAll("\\r|\\n", " ");
                                        }
                                        contract.setSubject(subject);
                                        contract.setModifyUser(DATAMINER_SERVICE_DBMODIFIER);
                                        contract.setModifyDate(date);
                                        //contract = null;
                                    } else if (object instanceof OrderDtoPDX) { // <----------------------------- OrderDtoPDX
                                        OrderDtoPDX orderPdx = (OrderDtoPDX) object;
                                        // create ORA object from PDX object and change pointer to new object (we will merge new object)
                                        object = new OrderDtoORA(orderPdx, this.getSectionsMap(), date, DATAMINER_SERVICE_DBMODIFIER);
                                        //orderPdx = null;
                                    } else if (object instanceof FurnaceChargeDto) { // <----------------------------- FurnaceChargeDto
                                        FurnaceChargeDto      furnaceCharge = (FurnaceChargeDto) object;
                                        FurnaceChargeAuditDto auditEntry    = null; // audit entity (one record)

                                        // get persisted object
                                        FurnaceChargeDtoId id = furnaceCharge.getId();
                                        FurnaceChargeDto persistedFurnaceCharge = (FurnaceChargeDto) oraSession.get(FurnaceChargeDto.class, id);

                                        if (persistedFurnaceCharge == null) { // persisted entity doesn't exist - INSERT

                                            // todo: we will not audit INSERTs
                                            // add audit entry (with new entity - inserted)
                                            //auditCounter++;
                                            //auditEntry = new FurnaceChargeAuditDto("INSERT", furnaceCharge);

                                            // set register date and user for FurnaceChargeDto
                                            furnaceCharge.setRegisterDate(date);
                                            furnaceCharge.setRegisterUser(DATAMINER_SERVICE_DBMODIFIER);
                                            furnaceCharge.setDeleted(0);
                                        } else { // persisted entity exist - UPDATE

                                            // Set right scale for weight - max for two scales - persisted to ORA entity and entity from PDX.
                                            // If one of scales is null - we will use weights 'as is' (entities will not be equals!)
                                            oraWeight = persistedFurnaceCharge.getWeight();
                                            pdxWeight = furnaceCharge.getWeight();
                                            if (oraWeight != null && pdxWeight != null) {
                                                int scale = Math.max(pdxWeight.scale(), oraWeight.scale());
                                                furnaceCharge.setWeight(furnaceCharge.getWeight().setScale(scale));
                                                persistedFurnaceCharge.setWeight(persistedFurnaceCharge.getWeight().setScale(scale));
                                            }

                                            // check for equality for two entities - from ora (persisted) and from pdx (new)
                                            if (furnaceCharge.equals(persistedFurnaceCharge)) { // we will skip merge - data is unchanged
                                                isMergeAction = false;                     // skip merge operation
                                                persistedFurnaceCharge.setDeleted(0);      // set DELETED status for persisted entity to 0 (zero)
                                                oraSession.update(persistedFurnaceCharge); // update persisted entity (it isn't deleted)
                                            } else {
                                                // add audit entry (with old entity - previous value/state)
                                                auditCounter++;
                                                auditEntry = new FurnaceChargeAuditDto("ИЗМЕНЕНИЕ", persistedFurnaceCharge);
                                                // set modify date and user for FurnaceChargeDto
                                                furnaceCharge.setModifyDate(date);
                                                furnaceCharge.setModifyUser(DATAMINER_SERVICE_DBMODIFIER);
                                                // keep previous data about register date and user
                                                furnaceCharge.setRegisterDate(persistedFurnaceCharge.getRegisterDate());
                                                furnaceCharge.setRegisterUser(persistedFurnaceCharge.getRegisterUser());
                                                // set DELETED status to 0 (zero)
                                                furnaceCharge.setDeleted(0);
                                            }
                                        }

                                        // save (persist) audit entry if it isn't null (there was action)
                                        if (auditEntry != null) {
                                            // audit entries will not be updated - just added and stored!
                                            auditEntry.setRegisterDate(date);
                                            auditEntry.setRegisterUser(DATAMINER_SERVICE_DBMODIFIER);
                                            oraSession.save(auditEntry);
                                        }

                                    } else if (object instanceof RK110Dto) { // <----------------------------- RK110Dto
                                        RK110Dto rk110Dto = (RK110Dto) object;
                                        // calculate surrogate field orderYearMonth
                                        String orderYear  = (rk110Dto.getOrderYear()  == null ? "" : String.valueOf(rk110Dto.getOrderYear()));
                                        String orderMonth = (rk110Dto.getOrderMonth() == null ? "" : String.valueOf(rk110Dto.getOrderMonth()));
                                        if (!StringUtils.isBlank(orderYear) && !StringUtils.isBlank(orderMonth)) {
                                            rk110Dto.setOrderYearMonth(orderYear + ("00" + orderMonth).substring(orderMonth.length()));
                                        }
                                        rk110Dto.setModifyUser(DATAMINER_SERVICE_DBMODIFIER);
                                        rk110Dto.setModifyDate(date);
                                    } else if (object instanceof BaseDto) { // <----------------------------- BaseDto
                                        //BaseDto baseDto = (BaseDto) object; // cast objects
                                        baseDto = (BaseDto) object; // cast objects
                                        baseDto.setModifyUser(DATAMINER_SERVICE_DBMODIFIER); // set modifier user and modification date
                                        baseDto.setModifyDate(date);
                                        //baseDto = null;
                                    } else {
                                        log.error(String.format("Unknown object class [%s]!", object.getClass().getName()));
                                    }

                                    if (isMergeAction) { // perform merge and counter increment only in real merge case
                                        oraSession.merge(object); // merge object to DB (save or update)
                                        mergeCounter++;           // increase processed objects counter
                                        if (/*mergeCounter > 0 && */ mergeCounter % SESSION_FLUSH_STEP == 0) { // step for flush and release
                                            oraSession.flush(); // may produce HibernateException
                                            oraSession.clear();
                                            log.debug("MERGE: processed records -> " + mergeCounter);
                                        }
                                    }

                                    // flush and clear session if there are many audit records created (inserted)
                                    if (auditCounter > 0 && auditCounter % SESSION_FLUSH_STEP == 0) {
                                        oraSession.flush(); // may produce HibernateException
                                        oraSession.clear();
                                        log.debug("AUDIT: processed records -> " + auditCounter);
                                    }

                                    // processed objects counter and debug info
                                    objectsCounter++;
                                    if (objectsCounter % SESSION_FLUSH_STEP == 0) { // step for debug info
                                        log.debug("processed objects -> " + objectsCounter);
                                    }

                                } catch (InternalException e) { // somethig goes wrong
                                    log.error(e);
                                }

                                iterator.remove(); // remove currently processed object from list (memory release)
                                //object = null;

                            } // end of WHILE cycle (iterating over objects collection)

                            oraSession.flush();
                            oraSession.clear();
                            pdxSession.clear();
                            //iterator = null;

                            log.info(String.format(MSG_DIRECTORY_PROCESSED, clazz.getSimpleName() + " (" + query + ")", mergeCounter, totalCounter));
                        } else { //nothing found
                            log.warn("Objects [" + clazz.getSimpleName() + "] not found in Paradox DB!");
                        }

                    } // end of FOR - iterating over all hql queries for one class

                    // post processing
                    this.postProcessing(clazz);

                    // Clear PARADOX session - remove objects (entities) related to processed table (type of entities).
                    // Here we just free resources (memory).
                    pdxSession.clear();

                } // end of FOR - all classes processing - MAP iterating

            } else { // set of classes is empty
                log.error("Empty set of classes - can't process!");
            }
        } finally {
            if (pdxSession != null) {
                pdxSession.close();
            }
        }
    }

    /***/
    @Override
    public void process() {
        log.debug("DirectoriesProcessor.process() working.");
        long start = System.currentTimeMillis();

        synchronized (this) { // lock PDX DB copier
            try {
                if (aggregatePdxTables) {
                    this.pdxDBCopier.aggregatePdxDb(); // copy PDX tables to local storage
                } else {
                    log.error("Paradox tables will not be aggregated into local folder (flag=false)! ");
                }
                log.debug("Paradox tables copied to local DB.");
                this.copyDataPDXToORA();           // copy data to Oracle
                log.debug("Paradox data copied to Oracle.");
            } catch(InternalException e) {
                log.error(e);
            }
        } // end of synchronized block

        // debug output - total taken time for porcessing
        log.debug(String.format("Total time: about %s seconds.", (System.currentTimeMillis() - start)/1000));
    }

}