package ru.kzgroup.dataMiner;

import gusev.dmitry.jtils.spring.CustomPropertySource;
import gusev.dmitry.jtils.utils.CommandLine;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.File;
import java.util.Locale;

import static ru.kzgroup.MesUtilDefaults.CUSTOM_PROPERTY_ORA_HOST;
import static ru.kzgroup.utils.CmdLineOptions.ORA_HOST;

/**
 * Main module (launcher) of DataMiner application.
 * @author Gusev Dmitry (gusevd)
 * @version 2.0 (DATE: 26.09.2014)
 */

public class DataMinerMain {

    private static final String SPRING_CONFIG_NAME = "spring/DataMinerContext.xml";
    private static final String LOCAL_PDX_DB       = "c:/temp/PdxLocalDb";

    /**
     * Main app method. Starting whole app cycle - load Spring/Hiber container and all resources, than finish main thread.
     * @param args String[] input command line parameters
    */
    public static void main(String[] args) {
        Log log = LogFactory.getLog(DataMinerMain.class);
        log.info("DataMiner started.");

        Locale.setDefault(Locale.US); // without this setting Oracle XE refuses connections (we have to set locale value).
        // processing command line arguments
        CommandLine cmdLine = new CommandLine(args); // read command line
        String      oraHost = cmdLine.optionValue(ORA_HOST.getOptionName()); // get value for -oraHost option
        try {
            boolean result;
            // check and create local PDX DB catalog
            File localDb = new File(LOCAL_PDX_DB);
            if (!localDb.exists()) { // dir doesn't exist - creating
                result = localDb.mkdirs();
                log.debug(String.format("Local PDX dir [%s] doesn't exist. Created [%s].", LOCAL_PDX_DB, result));
            } else if (localDb.isDirectory()) { // dir exists and is a directory (not a file!)
                log.debug(String.format("Local PDX dir [%s] exists and is directory. Processing next.", LOCAL_PDX_DB));
                result = true;
            } else { // dir exists - check is it dir?
                log.error(String.format("Local PDX dir [%s] exists but isn't a directory! Can't process!", LOCAL_PDX_DB));
                result = false;
            }

            if (result) { // all OK with local PDX DB catalog
                log.debug("Local PDX DB catalog Ok - processing next.");
                // if local catalog OK - checked/created - process next -> load spring context with changed property value
                AbstractApplicationContext context = new ClassPathXmlApplicationContext(new String[]{SPRING_CONFIG_NAME}, false);
                if (!StringUtils.isBlank(oraHost)) { // add new value for custom property
                    context.getEnvironment().getPropertySources().addLast(new CustomPropertySource("custom", CUSTOM_PROPERTY_ORA_HOST, oraHost));
                }
                context.refresh(); // refresh context (load it completely)
                log.debug("Application context initialized and loaded.");
            } else {
                log.error("Local PDX catalog problems - see log above! Can't process!");
            }

        } catch (BeansException e) { // context loading exception
            log.error(String.format("Can't load context from [%s]!", "DataMinerContext.xml"), e);
        }
        log.info("DataMiner MAIN THREAD finished.");
    }

}