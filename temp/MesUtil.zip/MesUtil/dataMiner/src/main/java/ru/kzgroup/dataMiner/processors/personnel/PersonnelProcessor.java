package ru.kzgroup.dataMiner.processors.personnel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.kzgroup.dataProcessing.ProcessorInterface;
import ru.kzgroup.domain.dao.personnel.ActiveDirectoryDao;
import ru.kzgroup.domain.dto.personnel.DepartmentDto;
import ru.kzgroup.domain.dto.personnel.EmployeeDto;

import javax.naming.NamingException;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import static ru.kzgroup.MesUtilDefaults.DATAMINER_SERVICE_DBMODIFIER;
import static ru.kzgroup.MesUtilDefaults.SESSION_FLUSH_STEP;

/**
 * Processor for updating departments/employees information personnel db -> mes db.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 27.07.13)
*/

@Component
@Transactional
public class PersonnelProcessor implements ProcessorInterface {

    private static Log log = LogFactory.getLog(PersonnelProcessor.class);

    @Value("${personnel.db.file}")
    private String             personnelDbFileName; // personnel MS Access DB file
    @Autowired @Qualifier("oraSpringSessionFactory_COMMON")
    private SessionFactory     oraSessionfactory;   // SessionFactory interacting with Oracle database (MES)
    @Autowired
    private ActiveDirectoryDao adDao;               // DAO component for working with AD

    /***/
    @Override
    public void process() {
        log.debug("PersonnelProcessor.process() working.");
        int deptsCounter     = 0;
        int employeesCounter = 0;
        try {
            Date currentDate = new Date(); // curretn date for field "modify date"
            // session for Oracle DB connection
            Session oraSession = oraSessionfactory.getCurrentSession();
            // get departments info
            List<DepartmentDto> deptsList = PersonnelHelper.getDepartments(this.personnelDbFileName);
            // put departments info into MES Oracle DB
            for (DepartmentDto department : deptsList) {
                deptsCounter++;
                department.setModifyDate(currentDate);
                department.setModifyUser(DATAMINER_SERVICE_DBMODIFIER);
                oraSession.merge(department);
                if (deptsCounter > 0 && deptsCounter % SESSION_FLUSH_STEP == 0) { // every step for flush and release
                    oraSession.flush();
                    oraSession.clear();
                    log.debug("Departments processed records -> " + deptsCounter);
                }
            }
            // get employees info
            List<EmployeeDto> employeesList = PersonnelHelper.getEmployees(this.personnelDbFileName, this.adDao);
            // put employees info into MES Oracle DB
            for (EmployeeDto employee : employeesList) {
                employeesCounter++;
                employee.setModifyDate(currentDate);
                employee.setModifyUser(DATAMINER_SERVICE_DBMODIFIER);
                oraSession.merge(employee);
                if (employeesCounter > 0 && employeesCounter % SESSION_FLUSH_STEP == 0) { // every step for flush and release
                    oraSession.flush();
                    oraSession.clear();
                    log.debug("Employees processed records -> " + employeesCounter);
                }
            }
        } catch (IOException | NamingException e) {
            log.error(e.getMessage(), e);
        }
        log.info(String.format("Personnel: [%s] depts and [%s] employees.", deptsCounter, employeesCounter));
    }

}