package ru.kzgroup.domain.dto.planning;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 17.07.2014)
*/

public class WorkProgram {
}