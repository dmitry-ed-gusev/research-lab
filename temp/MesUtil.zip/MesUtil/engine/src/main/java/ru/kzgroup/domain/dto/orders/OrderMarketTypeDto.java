package ru.kzgroup.domain.dto.orders;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * MARKET TYPE FOR ORDER - domain object, related to orders. ARM - M123, MES - TB_DICT_ORDER_MARKET_TYPES.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 01.08.2014)
*/

public class OrderMarketTypeDto extends BaseDto {

    private int    id;
    private String name;
    private String shortName;
    private int    stringNumber;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public int getStringNumber() {
        return stringNumber;
    }

    public void setStringNumber(int stringNumber) {
        this.stringNumber = stringNumber;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("name", name)
                .append("shortName", shortName)
                .append("stringNumber", stringNumber)
                .toString();
    }
}