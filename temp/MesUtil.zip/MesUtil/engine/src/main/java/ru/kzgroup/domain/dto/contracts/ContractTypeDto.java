package ru.kzgroup.domain.dto.contracts;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 10.01.14)
*/

public class ContractTypeDto extends BaseDto { // (PDX -> N27003)

    private int    id;
    private String shortValue;
    private String fullValue;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getShortValue() {
        return shortValue;
    }

    public void setShortValue(String shortValue) {
        this.shortValue = shortValue;
    }

    public String getFullValue() {
        return fullValue;
    }

    public void setFullValue(String fullValue) {
        this.fullValue = fullValue;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("shortValue", shortValue)
                .append("fullValue", fullValue)
                .toString();
    }

}