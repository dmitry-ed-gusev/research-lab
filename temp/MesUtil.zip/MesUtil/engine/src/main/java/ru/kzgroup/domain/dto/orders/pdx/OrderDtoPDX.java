package ru.kzgroup.domain.dto.orders.pdx;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.orders.AbstractOrder;

import java.util.HashSet;
import java.util.Set;

/**
 * ORDER - domain object (Paradox version). Contains NOTE object for ORDER - from
 * another table (ARM: ORDER->D869151, NOTE->D0502002).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 02.06.2014)
*/

public class OrderDtoPDX extends AbstractOrder {

    private OrderDtoIdPDX            id;                              // composite primary key
    private Set<OrderD0502002PDX>    notesForOrder = new HashSet<>(); // notes for order (link to -> D0502002), should be unique!
    private Set<OrderPositionDtoPDX> positions     = new HashSet<>(); // order positions (table D8609152)
    private OrderContractDtoPDX      contract;                        // contract data for current order

    public OrderDtoIdPDX getId() {
        return id;
    }

    public void setId(OrderDtoIdPDX id) {
        this.id = id;
    }

    public Set<OrderD0502002PDX> getNotesForOrder() {
        return notesForOrder;
    }

    public void setNotesForOrder(Set<OrderD0502002PDX> notesForOrder) {
        this.notesForOrder = notesForOrder;
    }

    public Set<OrderPositionDtoPDX> getPositions() {
        return positions;
    }

    public void setPositions(Set<OrderPositionDtoPDX> positions) {
        this.positions = positions;
    }

    public OrderContractDtoPDX getContract() {
        return contract;
    }

    public void setContract(OrderContractDtoPDX contract) {
        this.contract = contract;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("order", super.toString())
                .append("notesForOrder", notesForOrder)
                .append("positions", positions)
                .append("contract", contract)
                .toString();
    }

}