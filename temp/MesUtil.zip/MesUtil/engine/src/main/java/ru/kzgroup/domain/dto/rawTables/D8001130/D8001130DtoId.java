package ru.kzgroup.domain.dto.rawTables.D8001130;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for RAW ARM table - D8001130.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 13.08.2014)
*/

public class D8001130DtoId implements Serializable {

    private static final long serialVersionUID = 1L;

    private int year;
    private int month;
    private int attCompar;
    private int groupMarkCode;
    private int clauseCode;

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getAttCompar() {
        return attCompar;
    }

    public void setAttCompar(int attCompar) {
        this.attCompar = attCompar;
    }

    public int getGroupMarkCode() {
        return groupMarkCode;
    }

    public void setGroupMarkCode(int groupMarkCode) {
        this.groupMarkCode = groupMarkCode;
    }

    public int getClauseCode() {
        return clauseCode;
    }

    public void setClauseCode(int clauseCode) {
        this.clauseCode = clauseCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        D8001130DtoId that = (D8001130DtoId) o;

        if (attCompar != that.attCompar) return false;
        if (clauseCode != that.clauseCode) return false;
        if (groupMarkCode != that.groupMarkCode) return false;
        if (month != that.month) return false;
        if (year != that.year) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = year;
        result = 31 * result + month;
        result = 31 * result + attCompar;
        result = 31 * result + groupMarkCode;
        result = 31 * result + clauseCode;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("year", year)
                .append("month", month)
                .append("attCompar", attCompar)
                .append("groupMarkCode", groupMarkCode)
                .append("clauseCode", clauseCode)
                .toString();
    }

}