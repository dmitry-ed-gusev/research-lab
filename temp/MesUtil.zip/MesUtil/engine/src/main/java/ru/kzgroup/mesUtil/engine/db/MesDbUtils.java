package ru.kzgroup.mesUtil.engine.db;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.MesUtilDefaults;
import ru.kzgroup.exceptions.MesException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;

import static ru.kzgroup.MesUtilDefaults.DBOBJECT_TYPE;

/**
 * Utility class for work with MES database.
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 28.05.13)
 */

public class MesDbUtils {

    private static Log log = LogFactory.getLog(MesDbUtils.class);

    /**
     * Method returns unmodifiable map - list of db objects. In case of errors - it will throw MesException.
     */
    public Map<String, DBOBJECT_TYPE> loadDbObjectsList(String fileName) throws MesException, IOException {
        log.debug("AbstractDbFileAnalizer.loadDbObjectsList() working.");
        Map<String, DBOBJECT_TYPE> result = new TreeMap<String, MesUtilDefaults.DBOBJECT_TYPE>();

        BufferedReader bReader = null;
        FileReader fReader = null;
        try {
            fReader = new FileReader(fileName);
            bReader = new BufferedReader(fReader);
            String line;
            while ((line = bReader.readLine()) != null) {
                String[] values = line.split("=");
                if (values.length != 2) {
                    throw new MesException("Invalid format of MES DB file! File = [" + fileName + "].");
                } else {
                    String dbObjectName = values[0];
                    DBOBJECT_TYPE dbObjectType = DBOBJECT_TYPE.getObjectType(values[1]);
                    result.put(dbObjectName, dbObjectType);
                }
            }
        } finally {
            if (bReader != null) { // close buffered reader
                try {
                    bReader.close();
                } catch (IOException e) {
                    log.error("Can't close BufferedReader! Reason: " + e.getMessage(), e);
                }
            }
            if (fReader != null) { // close file reader
                try {
                    fReader.close();
                } catch (IOException e) {
                    log.error("Can't close FileReader! Reason: " + e.getMessage(), e);
                }
            }
        }
        // returns a non modifiable map
        return Collections.unmodifiableMap(result);
    }
}