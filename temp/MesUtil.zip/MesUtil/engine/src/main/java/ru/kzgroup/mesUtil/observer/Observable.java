package ru.kzgroup.mesUtil.observer;

/**
 * Interface for observable objects. If object implement this interface it can
 * provide info to many observers (classes).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 08.05.13)
 */

public interface Observable {

    /**
     * Adds observer to observable object.
    */
    public void addObserver(Observer observer);

    /**
     * Remove observer from observable object.
    */
    public void removeObserver(Observer observer);

    /**
     * Calls all handleEvent methods for every observer in list.
    */
    public void notifyObservers();

}