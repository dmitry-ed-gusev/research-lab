package ru.kzgroup.domain.dto.orders.ora;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for ORDER domain object (for Oracle).
 * Warning: in MES and in ARM system primary keys are different!
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 02.06.2014)
*/

public class OrderDtoIdORA implements Serializable {

    private static final long serialVersionUID = 1L;

    private String orderYearMonth; // D8609151->OrderYear+OrderMonth, TB_SM_ORDCOMM->PROD_YYMM (pos 1)
    private String orderNumber;    // D8609151->OrderNo,              TB_SM_ORDCOMM->ORD_NO (pos 2)

    public String getOrderYearMonth() {
        return orderYearMonth;
    }

    public void setOrderYearMonth(String orderYearMonth) {
        this.orderYearMonth = orderYearMonth;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement", "QuestionableName"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        OrderDtoIdORA that = (OrderDtoIdORA) obj;

        if (!orderNumber.equals(that.orderNumber)) return false;
        if (!orderYearMonth.equals(that.orderYearMonth)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = orderYearMonth.hashCode();
        result = 31 * result + orderNumber.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("orderYearMonth", orderYearMonth)
                .append("orderNumber", orderNumber)
                .toString();
    }

}