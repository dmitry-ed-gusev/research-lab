package ru.kzgroup.domain.dto.directories.characteristics;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composity primary key for domain object - technical characteristics for order.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 09.06.2014)
*/

public class TechCharacteristicDtoId implements Serializable {

    private static final long serialVersionUID = 1L;

    private int productionCode;
    private int characteristicCode;

    public int getProductionCode() {
        return productionCode;
    }

    public void setProductionCode(int productionCode) {
        this.productionCode = productionCode;
    }

    public int getCharacteristicCode() {
        return characteristicCode;
    }

    public void setCharacteristicCode(int characteristicCode) {
        this.characteristicCode = characteristicCode;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement", "QuestionableName"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        TechCharacteristicDtoId that = (TechCharacteristicDtoId) obj;

        if (characteristicCode != that.characteristicCode) return false;
        if (productionCode != that.productionCode) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = productionCode;
        result = 31 * result + characteristicCode;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("productionCode", productionCode)
                .append("characteristicCode", characteristicCode)
                .toString();
    }

}