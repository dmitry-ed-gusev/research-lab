package ru.kzgroup.domain.dto.orders.pdx;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * Simple contract domain object - contract data for order.
 * This object is used for purpose - get contract inbox number (table N27001->ВходНомер).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 23.06.2014)
*/

public class OrderContractDtoPDX extends BaseDto {

    private int    registryNumber;
    private String inboxNumber;

    public int getRegistryNumber() {
        return registryNumber;
    }

    public void setRegistryNumber(int registryNumber) {
        this.registryNumber = registryNumber;
    }

    public String getInboxNumber() {
        return inboxNumber;
    }

    public void setInboxNumber(String inboxNumber) {
        this.inboxNumber = inboxNumber;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("registryNumber", registryNumber)
                .append("inboxNumber", inboxNumber)
                .toString();
    }

}