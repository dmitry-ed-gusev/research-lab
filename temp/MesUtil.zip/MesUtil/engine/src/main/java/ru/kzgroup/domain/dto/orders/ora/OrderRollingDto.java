package ru.kzgroup.domain.dto.orders.ora;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Rolling data for order position. Entity based on MES table TB_ARM_RK110 (ARM->RK110).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 22.08.2014)
*/

public class OrderRollingDto extends BaseDto {

    private OrderRollingDtoId id;
    private String            orderYearMonth;
    private String            orderNumber;
    private Integer           orderPosition;
    private BigDecimal        rollingWeight;
    private String            meltNumber;
    private Date              workCardDate;
    private BigDecimal        acceptanceWeightAD;
    private Date              acceptanceDateAD;
    private BigDecimal        otkWeight;

    public OrderRollingDtoId getId() {
        return id;
    }

    public void setId(OrderRollingDtoId id) {
        this.id = id;
    }

    public String getOrderYearMonth() {
        return orderYearMonth;
    }

    public void setOrderYearMonth(String orderYearMonth) {
        this.orderYearMonth = orderYearMonth;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public Integer getOrderPosition() {
        return orderPosition;
    }

    public void setOrderPosition(Integer orderPosition) {
        this.orderPosition = orderPosition;
    }

    public BigDecimal getRollingWeight() {
        return rollingWeight;
    }

    public void setRollingWeight(BigDecimal rollingWeight) {
        this.rollingWeight = rollingWeight;
    }

    public String getMeltNumber() {
        return meltNumber;
    }

    public void setMeltNumber(String meltNumber) {
        this.meltNumber = meltNumber;
    }

    public Date getWorkCardDate() {
        return workCardDate;
    }

    public void setWorkCardDate(Date workCardDate) {
        this.workCardDate = workCardDate;
    }

    public BigDecimal getAcceptanceWeightAD() {
        return acceptanceWeightAD;
    }

    public void setAcceptanceWeightAD(BigDecimal acceptanceWeightAD) {
        this.acceptanceWeightAD = acceptanceWeightAD;
    }

    public Date getAcceptanceDateAD() {
        return acceptanceDateAD;
    }

    public void setAcceptanceDateAD(Date acceptanceDateAD) {
        this.acceptanceDateAD = acceptanceDateAD;
    }

    public BigDecimal getOtkWeight() {
        return otkWeight;
    }

    public void setOtkWeight(BigDecimal otkWeight) {
        this.otkWeight = otkWeight;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("orderYearMonth", orderYearMonth)
                .append("orderNumber", orderNumber)
                .append("orderPosition", orderPosition)
                .append("rollingWeight", rollingWeight)
                .append("meltNumber", meltNumber)
                .append("workCardDate", workCardDate)
                .append("acceptanceWeightAD", acceptanceWeightAD)
                .append("acceptanceDateAD", acceptanceDateAD)
                .append("otkWeight", otkWeight)
                .toString();
    }

}