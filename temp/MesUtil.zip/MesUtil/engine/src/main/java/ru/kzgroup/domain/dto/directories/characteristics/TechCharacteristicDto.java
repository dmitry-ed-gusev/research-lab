package ru.kzgroup.domain.dto.directories.characteristics;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;
import ru.kzgroup.domain.dto.directories.requirements.ExtraRequirementDto;

/**
 * TECHNICAL CHARACTERISTIC - domain object. Used for ORDER object.
 * Paradox table for this object - M115. Paradox table for ExtraRequirementDto object - M116.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 09.06.2014)
*/

public class TechCharacteristicDto extends BaseDto {

    private TechCharacteristicDtoId id;
    private ExtraRequirementDto     requirement1;
    private ExtraRequirementDto     requirement2;
    private ExtraRequirementDto     requirement3;
    private ExtraRequirementDto     requirement4;

    public TechCharacteristicDtoId getId() {
        return id;
    }

    public void setId(TechCharacteristicDtoId id) {
        this.id = id;
    }

    public ExtraRequirementDto getRequirement1() {
        return requirement1;
    }

    public void setRequirement1(ExtraRequirementDto requirement1) {
        this.requirement1 = requirement1;
    }

    public ExtraRequirementDto getRequirement2() {
        return requirement2;
    }

    public void setRequirement2(ExtraRequirementDto requirement2) {
        this.requirement2 = requirement2;
    }

    public ExtraRequirementDto getRequirement3() {
        return requirement3;
    }

    public void setRequirement3(ExtraRequirementDto requirement3) {
        this.requirement3 = requirement3;
    }

    public ExtraRequirementDto getRequirement4() {
        return requirement4;
    }

    public void setRequirement4(ExtraRequirementDto requirement4) {
        this.requirement4 = requirement4;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("requirement1", requirement1)
                .append("requirement2", requirement2)
                .append("requirement3", requirement3)
                .append("requirement4", requirement4)
                .toString();
    }

}