package ru.kzgroup.domain.dto.personnel;

import ru.kzgroup.domain.dto.BaseDto;

/**
 * Domain object from ARMs - one department. Table //pst-fs/users/new/otep/nsi/N270102.
 * This table (and object) should be retired.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 01.04.2014)
*/

public class DepartmentN270102Dto extends BaseDto {

    private DepartmentN270102DtoId id;         // composite primary key
    private int                    deptNumber; // (N270102->DepNo)
    private int                    shopNumber; // (N270102->ShopNo)
    private String                 fullName;   // (N270102->NameDepF)
    private String                 shortName;  // (N270102->NameDepB)

    public DepartmentN270102DtoId getId() {
        return id;
    }

    public void setId(DepartmentN270102DtoId id) {
        this.id = id;
    }

    public int getDeptNumber() {
        return deptNumber;
    }

    public void setDeptNumber(int deptNumber) {
        this.deptNumber = deptNumber;
    }

    public int getShopNumber() {
        return shopNumber;
    }

    public void setShopNumber(int shopNumber) {
        this.shopNumber = shopNumber;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

}