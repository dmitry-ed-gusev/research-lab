package ru.kzgroup.domain.dto.orders.ora;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.exceptions.InternalException;
import ru.kzgroup.domain.dto.directories.*;
import ru.kzgroup.domain.dto.directories.requirements.ExtraRequirementChemistryDto;
import ru.kzgroup.domain.dto.directories.requirements.ExtraRequirementDto;
import ru.kzgroup.domain.dto.laboratory.Element;
import ru.kzgroup.domain.dto.orders.AbstractOrderPosition;
import ru.kzgroup.domain.dto.orders.OrderMarketTypeDto;
import ru.kzgroup.domain.dto.orders.OrdersHelper;
import ru.kzgroup.domain.dto.orders.pdx.OrderExtraParameterDtoPDX;
import ru.kzgroup.domain.dto.orders.pdx.OrderPositionDtoPDX;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static ru.kzgroup.domain.dto.orders.OrdersHelper.ORDER_SDF;

/**
 * ORDER POSITION - domain object for Oracle (MES) database, table TB_SM_ORDDTL.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 24.06.2014)
*/

// todo: try to map one object field to two or more DB table fields (for example steelGradeCodeFrom -> STLGRADE_CD and STLGRADE_CD_FR) <- for ORACLE!
// todo: all "magic" strings/constants/numbers move to module/project constants

public class OrderPositionDtoORA extends AbstractOrderPosition {

    private static final Log log = LogFactory.getLog(OrderPositionDtoORA.class);

    private OrderPositionDtoIdORA      id;
    private OrderMarketTypeDto         orderIndex;                  // value from table D8609151 (orders headers - from current order header)
    private String                     orderProgressCode;           // calculated field (from Paradox)
    private SteelGradeDto              steelGrade;                  //
    private String                     sectionType;                 //
    private Integer                    sectionSize1;                //
    private Integer                    sectionSize2;                //
    private BigDecimal                 goodsLengthToleranceMin;     //
    private BigDecimal                 goodsLengthToleranceMax;     //
    private BigDecimal                 shortLengthMin;              //
    private BigDecimal                 shortLengthAllowedRate;      //
    private BigDecimal                 orderShortLengthMin;         //
    private BigDecimal                 orderShortLengthAllowedRate; //
    private String                     heatTreat;                   // heat treat Y/N (высокий отпуск/термообработка)
    private String                     surfaceStatus;               //
    private String                     surfaceTreatGroup;           //
    private BigDecimal                 bundleMinWeight;             // TB_SM_ORDDTL->BUNDLE_MIN_WT
    private BigDecimal                 bundleMaxWeight;             // TB_SM_ORDDTL->BUNDLE_MAX_WT
    private Integer                    bindingCount;                // bundle binding count (число мест увязки пакета)
    private String                     b2b5Standard;                // roll presicion standard (группа точности прокатки)
    private String                     grinding;                    // grinding Y/N (снятие фасок да/нет)
    private String                     customerDeliveryDate;        //
    private String                     deliveryDate;                //
    private String                     deliveryTermName;            //
    private MarkingDto                 marking;                     // TB_SM_ORDDTL->MARKING_CD (link -> TB_SM_MARKING)
    // source for mill 900 (из чего катаем на стане 900 данную позицию заказа)
    private String                     r680SectionType;                //
    private BigDecimal                 r680SectionSizeT;               //
    private BigDecimal                 r680SectionSizeW;               //
    // source for mill 350 (из чего катаем на стане 350 данную позицию заказа)
    private String                     r350SectionType;                //
    private BigDecimal                 r350SectionSizeT;               //
    private BigDecimal                 r350SectionSizeW;               //
    private Integer                    deliveryToleranceMin;           //
    private Integer                    deliveryToleranceMax;           //
    // chemical ingredients - addition info
    private String                     ingredientSpec1;                //
    private String                     ingredientSpec2;                //
    private String                     ingredientSpec3;                //
    private String                     ingredientSpec4;                //
    private String                     ingredientSpec5;                //
    private BigDecimal                 rollSectionSizeT;               //
    private BigDecimal                 rollSectionSizeT1;              //
    private BigDecimal                 rollSectionSizeT2;              //
    private BigDecimal                 rollSectionSizeT3;              //
    private String                     mill900350CommonSize;           // Y/N
    // chemical ingredients detailed info (link to table TB_SM_ORD_INGR)
    private Set<OrderIngredientDtoORA> ingredients = new HashSet<>(0); //
    // extra items (requirements) detailed info (link to table TB_SM_ORD_EXTRA_ITEM)
    private Set<OrderExtraItemDtoORA>  extraItems  = new HashSet<>(0); //
    // rolling data for current order position
    private Set<OrderRollingDto>       rollingItems = new HashSet<>(0);

    /** Default constructor (with no parameters), used by Hibernate. */
    public OrderPositionDtoORA() {}

    /** Copying constructor - copies object OrderPositionDtoPDX state into current object. */
    public OrderPositionDtoORA(OrderPositionDtoPDX pdxPosition, Map<String, String> sectionsMap,
                               Map<OrderIngredientDtoIdORA, OrderIngredientDtoORA> allIngredientsMap,
                               Map<OrderExtraItemDtoIdORA, OrderExtraItemDtoORA> allExtraItemsMap,
                               Date currentDate, String modifier) throws InternalException {
        if (pdxPosition == null) {
            throw new InternalException("Paradox ORDER POSITION is NULL!");
        }

        // create ID
        OrderPositionDtoIdORA id = new OrderPositionDtoIdORA();
        id.setOrderNumber(pdxPosition.getId().getOrderNumber());
        id.setOrderPosition(pdxPosition.getId().getOrderPosition());

        // year-month field. we have to append a leading zero to a month value - month should be two digits long (1->01)
        String strMonth = String.valueOf(pdxPosition.getId().getOrderMonth());
        String orderYearMonth = String.valueOf(pdxPosition.getId().getOrderYear()) + ("00" + strMonth).substring(strMonth.length());
        id.setOrderYearMonth(orderYearMonth);
        this.id = id;

        // presence sign, weight, order progress code, mill group
        int presenceSign  = pdxPosition.getPresenceSign();
        BigDecimal weight = pdxPosition.getWeight().multiply(new BigDecimal(1000));
        this.setWeight(weight);             // TB_SM_ORDDTL -> ORD_WT
        this.setPresenceSign(presenceSign); // TB_SM_ORDDTL -> SALE_GP
        this.orderProgressCode = (presenceSign == 1 || BigDecimal.ONE.equals(weight) ? "E" : "B"); // TB_SM_ORDDTL -> ORD_PROG_CD
        this.setMillCode(Integer.parseInt(String.valueOf(pdxPosition.getMillCode()).substring(0, 1))); // mill code: 9 -> mill900/680, 3 -> mill350 (one digit!)

        // section (profile) data
        SectionDto pdxSection = pdxPosition.getSection(); // get section object from PDX order position
        if (pdxSection != null) { // section object from PDX not null
            // we get MAP<id, [section type]> from Oracle for sections types data (this data doesn't exist in PDX)
            if (sectionsMap != null && !sectionsMap.isEmpty() && sectionsMap.containsKey(pdxSection.getCode())) {
                String sectionType = sectionsMap.get(pdxSection.getCode());
                pdxSection.setType(sectionType);
                this.sectionType = sectionType;
            } else { // sections map from Oracle is empty/null/doesn't contain key
                this.sectionType = null;
                log.error(String.format("No section/profile type info for order position [%s]!", this.id));
            }
            //this.setSection(new SectionDto(pdxSection)); // copy not-null section object in any case
            this.setSection(pdxSection); // copy not-null section object in any case
            // data for mills 900/350
            if (this.getMillCode() == 9) {
                this.r680SectionType = this.sectionType;
            } else {
                this.r350SectionType = this.sectionType;
            }
        } else { // section object from PDX is NULL!
            log.error(String.format("Empty (NULL) section/profile object for order position [%s]!", this.id));
            this.setSection(null);
            this.sectionType     = null;
            this.r680SectionType = null;
            this.r350SectionType = null;
        }

        // standards: steel grade and profile
        //this.setSteelGradeStandard(pdxPosition.getSteelGradeStandard() == null ? null : new StandardDto(pdxPosition.getSteelGradeStandard()));
        //this.setProfileStandard(pdxPosition.getProfileStandard() == null ? null : new StandardDto(pdxPosition.getProfileStandard()));
        this.setSteelGradeStandard(pdxPosition.getSteelGradeStandard() == null ? null : pdxPosition.getSteelGradeStandard());
        this.setProfileStandard(pdxPosition.getProfileStandard() == null ? null : pdxPosition.getProfileStandard());

        // steel grade data
        SteelGradeDto gradeFrom = pdxPosition.getSteelGradeFrom();
        SteelGradeDto gradeTo   = pdxPosition.getSteelGradeTo();
        //this.steelGrade = (gradeFrom == null ? null : new SteelGradeDto(gradeFrom));
        //this.setSteelGradeFrom(gradeFrom == null ? null : new SteelGradeDto(gradeFrom));
        //this.setSteelGradeTo(gradeTo == null ? null : new SteelGradeDto(gradeTo));
        this.steelGrade = (gradeFrom == null ? null : gradeFrom);
        this.setSteelGradeFrom(gradeFrom == null ? null : gradeFrom);
        this.setSteelGradeTo(gradeTo == null ? null : gradeTo);

        // section (profile) size data
        this.sectionSize1 = pdxPosition.getSectionSize1From();
        this.sectionSize2 = pdxPosition.getSectionSize2From();
        this.setSectionSize1From(pdxPosition.getSectionSize1From());
        this.setSectionSize1To(pdxPosition.getSectionSize1To());
        // check/set section size 2 (width) data (see algorithm in stored procedure)
        int sectionSize2From = (pdxPosition.getSectionSize2From() == null ? 0 : pdxPosition.getSectionSize2From());
        this.setSectionSize2From(sectionSize2From == 0 ? pdxPosition.getSectionSize1From() : sectionSize2From);
        int sectionSize2To = (pdxPosition.getSectionSize2To() == null ? 0 : pdxPosition.getSectionSize2To());
        this.setSectionSize2To(sectionSize2To == 0 ? pdxPosition.getSectionSize1To() : sectionSize2To);

        // length data
        this.setLengthFrom(pdxPosition.getLengthFrom());
        this.setLengthTo(pdxPosition.getLengthTo());

        // extra requirements for length - processing and assigning to fields
        BigDecimal[] extraParameters = {BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO};
        Set<OrderExtraParameterDtoPDX> parameters = pdxPosition.getExtraParameters();
        if (parameters != null && !parameters.isEmpty()) { // processing extra parameters only if they present
            for (OrderExtraParameterDtoPDX parameter : parameters) { // get extra parameters into array by one cycle iteration
                int        paramNumber = parameter.getId().getExtraParameterNumber();
                BigDecimal paramValue  = parameter.getExtraParameterValue();
                if (paramNumber <= 4 &&  paramValue != null) {
                    extraParameters[paramNumber - 1] = paramValue;
                } else {
                    log.debug(String.format("More than 4 extra parameters for order position [%s]!", this.id));
                }
            }
        }
        // assign values
        this.goodsLengthToleranceMax     = extraParameters[0];
        this.goodsLengthToleranceMin     = extraParameters[1];
        this.shortLengthMin              = extraParameters[2];
        this.shortLengthAllowedRate      = extraParameters[3];
        this.orderShortLengthMin         = this.shortLengthMin;          // BigDecimal is immutable
        this.orderShortLengthAllowedRate = this.shortLengthAllowedRate;  // BigDecimal is immutable
        // some calculations for lengths (see stored procudure SP_SM_100_ORDIF)
        if (this.getLengthFrom() < this.getLengthTo()) {
            this.shortLengthMin          = new BigDecimal(0); // SHORT_LEN_MIN
            this.shortLengthAllowedRate  = new BigDecimal(0); // SHORT_LEN_ALLOW_RATE
            this.goodsLengthToleranceMin = new BigDecimal(0); // GOODS_LEN_TOL_MIN
            this.goodsLengthToleranceMax = new BigDecimal(0); // GOODS_LEN_TOL_MAX
        } else if (this.getLengthFrom() == this.getLengthTo() &&
                this.goodsLengthToleranceMin.compareTo(BigDecimal.ZERO) == 0 &&
                this.goodsLengthToleranceMax.compareTo(BigDecimal.ZERO) == 0) {
            this.goodsLengthToleranceMax = new BigDecimal(50);
        }
        // another calculations (see stored procudure SP_SM_100_ORDIF)
        if (this.shortLengthAllowedRate.compareTo(BigDecimal.ZERO) > 0 && this.shortLengthMin.compareTo(BigDecimal.ZERO) == 0) {
            this.shortLengthMin = new BigDecimal(2500);
        }

        // extra requirements data for current position
        Map<Integer, ExtraRequirementDto> extraRequirementsMap = OrdersHelper.getRequirementsMap(pdxPosition);

        // extra requirements items - table TB_SM_ORD_EXTRA_ITEM
        for (ExtraRequirementDto extraRequirement : extraRequirementsMap.values()) {
            // create extra item object
            OrderExtraItemDtoIdORA extraItemId = new OrderExtraItemDtoIdORA(this.id.getOrderYearMonth(), this.id.getOrderNumber(),
                    this.id.getOrderPosition(), extraRequirement.getReqCode());
            // we have to be sure, that there is only one unique object OrderExtraItemDtoORA in memory - because
            // we will store it in database (in database may be just only unique row for every object, one row can't be
            // mapped to more than one object in memory!)
            OrderExtraItemDtoORA   extraItem;
            if (allExtraItemsMap.containsKey(extraItemId)) {
                extraItem = allExtraItemsMap.get(extraItemId);
            } else {
                extraItem = new OrderExtraItemDtoORA(extraItemId, extraRequirement.getReqFullName());
                extraItem.setModifyDate(currentDate);
                extraItem.setModifyUser(modifier);
                allExtraItemsMap.put(extraItemId, extraItem);
            }
            // add extra item to SET
            this.extraItems.add(extraItem);
        }

        // fields, that depends on extra requirements (see requirements descriptions by codes - table M116)
        this.heatTreat = (extraRequirementsMap.containsKey(9) ? "Y" : "N");

        // Surface status (статус/группа поверхности). Группы поверхностей бывают:
        //  * 1 ГП — без дополнительной обработки поверхности;
        //  * 2 ГП — требуется горячая обработка давлением для предания необходимых характеристик;
        //  * 3 ГП — для холодной механической обработки механизмами.
        // группы используются в основном для кругов и квадратов
        this.surfaceStatus = (extraRequirementsMap.containsKey(31) ? "W" : "B"); // 31 - whitening (светление), if present => W (white), otherwise B (black)
        // surface treat (требование обработки поверхности) - see Arm86_09 for details
        if (this.getSection() != null && "1177".equals(this.getSection().getCode())) { // 1177 - круг обточной
            this.surfaceTreatGroup = "1"; // 1ГП или обточка (определяем по коду профиля)
        } else if (extraRequirementsMap.containsKey(14) || extraRequirementsMap.containsKey(34) || extraRequirementsMap.containsKey(634)) {
            this.surfaceTreatGroup = "2"; // 2ГП (14 - г/о, 34 - 2 ГП, 634 - 2 ГП) - see table M116
        } else if (extraRequirementsMap.containsKey(15) || extraRequirementsMap.containsKey(35) || extraRequirementsMap.containsKey(635)) {
            this.surfaceTreatGroup = "3"; // 3ГП (15 - х/о, 35 3 ГП, 635 - 3 ГП) - see M116 (possible -> 636, 601)
        }

        // package/bundle weight (вес пакета). If not present - we will use BundleWeightStd enumeration (data table TB_PM_BUNDLING_WEIGHT_STD)
        // todo: hardcoded data (BundleWeightStd) from table!
        Pair<BigDecimal, BigDecimal> extraReqWeight = OrdersHelper.getExtraRequirementWeight(pdxPosition);
        if (extraReqWeight != null) {
            Pair<Integer, Integer> bundleWeightStd = BundleWeightStd.getBundleWeight(this.sectionType, this.getSectionSize1From());
            this.bundleMinWeight = (extraReqWeight.getLeft()  == null ?
                    (bundleWeightStd != null ? new BigDecimal(bundleWeightStd.getLeft()) : null) : extraReqWeight.getLeft());
            this.bundleMaxWeight = (extraReqWeight.getRight() == null ?
                    (bundleWeightStd != null ? new BigDecimal(bundleWeightStd.getRight()) : null) : extraReqWeight.getRight());
        }

        // bundle binding count (число мест увязки пакета - возможно есть другие)
        // todo: hardcoded data from table!
        if (extraRequirementsMap.containsKey(421)) {
            this.bindingCount = 3; // extra requirement (M116) 421 -> 3 places for binding
        } else if (extraRequirementsMap.containsKey(484) || extraRequirementsMap.containsKey(513)) {
            this.bindingCount = 4; // extra requirements (M116) 484 -> 4 places binding, 513 -> 4 places binding in 3 threads
        } else if (2000 < this.getLengthTo() && this.getLengthTo() <= 5000) {
            this.bindingCount = 3; // data from table TB_PM_BUNDLE_BINDING_COUNT ((MES screen: Order->Standard->[1018] Bundle Weight&Binding))
        } else if (5000 < this.getLengthTo() && this.getLengthTo() <= 9999) {
            this.bindingCount = 4; // data from table TB_PM_BUNDLE_BINDING_COUNT ((MES screen: Order->Standard->[1018] Bundle Weight&Binding))
        }

        // B5 standard (extra requirements) - точность прокатки. see table M116
        // B1, B2, B3, B4, B5 - обычная точность прокатки
        if (extraRequirementsMap.containsKey(549)) {
            this.b2b5Standard = "B";  // extra requirement 549 - точность прокатки B
        } else if (extraRequirementsMap.containsKey(808)) {
            this.b2b5Standard = "B1"; // extra requirement 808 - точность прокатки B1
        } else if (extraRequirementsMap.containsKey(845)) {
            this.b2b5Standard = "B2"; // extra requirement 845 - точность прокатки B2
        } else if (extraRequirementsMap.containsKey(836)) {
            this.b2b5Standard = "B5"; // extra requirement 836 - точность прокатки B5
        }

        // extra requirement - grinding Y/N (снятие фасок) (extra requirement 21 - see table M116)
        this.grinding = (extraRequirementsMap.containsKey(21) ? "Y" : "N");

        // delivery dates
        if (pdxPosition.getShipmentDate() != null) {
            this.customerDeliveryDate = ORDER_SDF.format(pdxPosition.getShipmentDate());
            this.deliveryDate         = this.customerDeliveryDate;
        }

        // delivery terms (special)
        DeliveryTermDto deliveryTerm = pdxPosition.getDeliveryTerm();
        if (deliveryTerm != null) {
            //this.setDeliveryTerm(new DeliveryTermDto(deliveryTerm));
            this.setDeliveryTerm(deliveryTerm);
            this.deliveryTermName = deliveryTerm.getTermName();
        }

        // Source for mills 900/350 (из чего катаем на станах 900/350 данную позицию заказа).
        // This algorithm is from stored procedure SP_SM_100_ORDIF.
        // Если прокат надо обтачивать, то размеры проката (результата) для обоих станов должны быть чуть больше,
        // в среднем обточка "съедает" 2мм - соотв. добавляем 2мм к размерам (case 1 - if->true).
        // Если же прокат обтачивать НЕ надо - размеры НЕ добавляем, используем исходные.
        // Для соответствий размеров по обточке (результат после обточки <-> до обточки) есть таблица TB_QM_TURNING_B5_MILL_SIZE -
        // как она пополняется/обновляется неизвестно, откуда данные - неизвестно.
        if ("1".equals(this.surfaceTreatGroup) /* 1ГП */ || "B5".equals(this.b2b5Standard) /* точность прокатки B5 */) { // turning/B5
            BigDecimal r680and350size = new BigDecimal(this.getSectionSize1From() + 2);
            if (this.getMillCode() == 9) {  // mill900
                this.r680SectionSizeT = r680and350size;
                this.r680SectionSizeW = r680and350size;
            } else { // mill350
                this.r350SectionSizeT = r680and350size;
                this.r350SectionSizeW = r680and350size;
            }
        } else { // not turning
            if (this.getMillCode() == 9) {  // mill900
                this.r680SectionSizeT = (this.getSectionSize1From() == null ? BigDecimal.ZERO : new BigDecimal(this.getSectionSize1From()));
                this.r680SectionSizeW = (this.getSectionSize2From() == null ? BigDecimal.ZERO : new BigDecimal(this.getSectionSize2From()));
            } else { // mill350
                this.r350SectionSizeT = (this.getSectionSize1From() == null ? BigDecimal.ZERO : new BigDecimal(this.getSectionSize1From()));
                this.r350SectionSizeT = (this.getSectionSize2From() == null ? BigDecimal.ZERO : new BigDecimal(this.getSectionSize2From()));
            }
        }

        // chemistry (химия для данной позиции)
        int      reqCounter            = 0;
        String[] chemistryRequirements = new String[5];
        for (ExtraRequirementDto requirement : extraRequirementsMap.values()) {
            if (requirement.getReqGroup() == 10) { // group 10 - chemistry (M116->Group)
                // ingredients data for order position (TB_SM_ORDDTL)
                if (reqCounter < chemistryRequirements.length) { // ingridients counter less than 5
                    chemistryRequirements[reqCounter] = requirement.getReqFullName();
                } else { // ingredients counter greater than 5 -> error?
                    log.debug(String.format("More than 5 chemistry requirements for order position [%s]!", this.id));
                }
                // detailed ingredients data for order position (TB_SM_ORD_INGR)
                Set<ExtraRequirementChemistryDto> extraChemReqs = requirement.getExtraReqChemistry();
                if (extraChemReqs != null && !extraChemReqs.isEmpty()) {
                    for (ExtraRequirementChemistryDto extraChemReq : extraChemReqs) {

                        // order position chemical ingredient (special data)
                        OrderIngredientDtoIdORA ingredientId = new OrderIngredientDtoIdORA(this.id.getOrderYearMonth(), this.id.getOrderNumber(),
                                this.id.getOrderPosition(), Element.getLatinNameByCode(extraChemReq.getId().getElementCode()));
                        OrderIngredientDtoORA ingredient;

                        // we have to be sure, that there is only one unique object OrderIngredientDtoORA in memory - because
                        // we will store it in database (in database may be just only unique row for every object, one row can't be
                        // mapped to more than one object in memory!)
                        if (allIngredientsMap.containsKey(ingredientId)) {
                            ingredient = allIngredientsMap.get(ingredientId);
                        } else {
                            ingredient = new OrderIngredientDtoORA(ingredientId, extraChemReq.getMinValue(), extraChemReq.getMaxValue());
                            ingredient.setModifyDate(currentDate);
                            ingredient.setModifyUser(modifier);
                            allIngredientsMap.put(ingredientId, ingredient);
                        }
                        // add ingredient to SET
                        this.ingredients.add(ingredient);

                    }
                } else {
                    // todo: too much output
                    //log.warn(String.format("Extra ingredients data (M11601) for order position [%s] not present!", this.id));
                }
            }
        } // end of FOR -> chemistry

        // chemical ingredients specification for current order position
        this.ingredientSpec1 = chemistryRequirements[0];
        this.ingredientSpec2 = chemistryRequirements[1];
        this.ingredientSpec3 = chemistryRequirements[2];
        this.ingredientSpec4 = chemistryRequirements[3];
        this.ingredientSpec5 = chemistryRequirements[4];
        // financial info
        this.setPrice(pdxPosition.getPrice());
        this.setCurrency(pdxPosition.getCurrency());
        // other info
        this.setPlanRollingDate(pdxPosition.getPlanRollingDate());
        this.setPreviousMonth(pdxPosition.getPreviousMonth());
        // technical data
        this.setTechnicalCharCode(pdxPosition.getTechnicalCharCode());
        this.setProductCode(pdxPosition.getProductCode());
        this.setPlannedPrice(pdxPosition.getPlannedPrice());
        // data and modifier
        this.setModifyDate(currentDate);
        this.setModifyUser(modifier);

    } // end of copying constructor for ORDER POSITION

    public OrderPositionDtoIdORA getId() {
        return id;
    }

    public void setId(OrderPositionDtoIdORA id) {
        this.id = id;
    }

    public OrderMarketTypeDto getOrderIndex() {
        return orderIndex;
    }

    public void setOrderIndex(OrderMarketTypeDto orderIndex) {
        this.orderIndex = orderIndex;
    }

    public String getOrderProgressCode() {
        return orderProgressCode;
    }

    public void setOrderProgressCode(String orderProgressCode) {
        this.orderProgressCode = orderProgressCode;
    }

    public SteelGradeDto getSteelGrade() {
        return steelGrade;
    }

    public void setSteelGrade(SteelGradeDto steelGrade) {
        this.steelGrade = steelGrade;
    }

    public String getSectionType() {
        return sectionType;
    }

    public void setSectionType(String sectionType) {
        this.sectionType = sectionType;
    }

    public Integer getSectionSize1() {
        return sectionSize1;
    }

    public void setSectionSize1(Integer sectionSize1) {
        this.sectionSize1 = sectionSize1;
    }

    public Integer getSectionSize2() {
        return sectionSize2;
    }

    public void setSectionSize2(Integer sectionSize2) {
        this.sectionSize2 = sectionSize2;
    }

    public BigDecimal getGoodsLengthToleranceMin() {
        return goodsLengthToleranceMin;
    }

    public void setGoodsLengthToleranceMin(BigDecimal goodsLengthToleranceMin) {
        this.goodsLengthToleranceMin = goodsLengthToleranceMin;
    }

    public BigDecimal getGoodsLengthToleranceMax() {
        return goodsLengthToleranceMax;
    }

    public void setGoodsLengthToleranceMax(BigDecimal goodsLengthToleranceMax) {
        this.goodsLengthToleranceMax = goodsLengthToleranceMax;
    }

    public BigDecimal getShortLengthMin() {
        return shortLengthMin;
    }

    public void setShortLengthMin(BigDecimal shortLengthMin) {
        this.shortLengthMin = shortLengthMin;
    }

    public BigDecimal getShortLengthAllowedRate() {
        return shortLengthAllowedRate;
    }

    public void setShortLengthAllowedRate(BigDecimal shortLengthAllowedRate) {
        this.shortLengthAllowedRate = shortLengthAllowedRate;
    }

    public BigDecimal getOrderShortLengthMin() {
        return orderShortLengthMin;
    }

    public void setOrderShortLengthMin(BigDecimal orderShortLengthMin) {
        this.orderShortLengthMin = orderShortLengthMin;
    }

    public BigDecimal getOrderShortLengthAllowedRate() {
        return orderShortLengthAllowedRate;
    }

    @SuppressWarnings("MethodParameterNamingConvention")
    public void setOrderShortLengthAllowedRate(BigDecimal orderShortLengthAllowedRate) {
        this.orderShortLengthAllowedRate = orderShortLengthAllowedRate;
    }

    public String getHeatTreat() {
        return heatTreat;
    }

    public void setHeatTreat(String heatTreat) {
        this.heatTreat = heatTreat;
    }

    public String getSurfaceStatus() {
        return surfaceStatus;
    }

    public void setSurfaceStatus(String surfaceStatus) {
        this.surfaceStatus = surfaceStatus;
    }

    public String getSurfaceTreatGroup() {
        return surfaceTreatGroup;
    }

    public void setSurfaceTreatGroup(String surfaceTreatGroup) {
        this.surfaceTreatGroup = surfaceTreatGroup;
    }

    public BigDecimal getBundleMinWeight() {
        return bundleMinWeight;
    }

    public void setBundleMinWeight(BigDecimal bundleMinWeight) {
        this.bundleMinWeight = bundleMinWeight;
    }

    public BigDecimal getBundleMaxWeight() {
        return bundleMaxWeight;
    }

    public void setBundleMaxWeight(BigDecimal bundleMaxWeight) {
        this.bundleMaxWeight = bundleMaxWeight;
    }

    public Integer getBindingCount() {
        return bindingCount;
    }

    public void setBindingCount(Integer bindingCount) {
        this.bindingCount = bindingCount;
    }

    public String getB2b5Standard() {
        return b2b5Standard;
    }

    public void setB2b5Standard(String b2b5Standard) {
        this.b2b5Standard = b2b5Standard;
    }

    public String getGrinding() {
        return grinding;
    }

    public void setGrinding(String grinding) {
        this.grinding = grinding;
    }

    public String getCustomerDeliveryDate() {
        return customerDeliveryDate;
    }

    public void setCustomerDeliveryDate(String customerDeliveryDate) {
        this.customerDeliveryDate = customerDeliveryDate;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public String getDeliveryTermName() {
        return deliveryTermName;
    }

    public void setDeliveryTermName(String deliveryTermName) {
        this.deliveryTermName = deliveryTermName;
    }

    public String getR680SectionType() {
        return r680SectionType;
    }

    public void setR680SectionType(String r680SectionType) {
        this.r680SectionType = r680SectionType;
    }

    public String getR350SectionType() {
        return r350SectionType;
    }

    public void setR350SectionType(String r350SectionType) {
        this.r350SectionType = r350SectionType;
    }

    public BigDecimal getR680SectionSizeT() {
        return r680SectionSizeT;
    }

    public void setR680SectionSizeT(BigDecimal r680SectionSizeT) {
        this.r680SectionSizeT = r680SectionSizeT;
    }

    public BigDecimal getR680SectionSizeW() {
        return r680SectionSizeW;
    }

    public void setR680SectionSizeW(BigDecimal r680SectionSizeW) {
        this.r680SectionSizeW = r680SectionSizeW;
    }

    public BigDecimal getR350SectionSizeT() {
        return r350SectionSizeT;
    }

    public void setR350SectionSizeT(BigDecimal r350SectionSizeT) {
        this.r350SectionSizeT = r350SectionSizeT;
    }

    public BigDecimal getR350SectionSizeW() {
        return r350SectionSizeW;
    }

    public void setR350SectionSizeW(BigDecimal r350SectionSizeW) {
        this.r350SectionSizeW = r350SectionSizeW;
    }

    public Integer getDeliveryToleranceMin() {
        return deliveryToleranceMin;
    }

    public void setDeliveryToleranceMin(Integer deliveryToleranceMin) {
        this.deliveryToleranceMin = deliveryToleranceMin;
    }

    public Integer getDeliveryToleranceMax() {
        return deliveryToleranceMax;
    }

    public void setDeliveryToleranceMax(Integer deliveryToleranceMax) {
        this.deliveryToleranceMax = deliveryToleranceMax;
    }

    public String getIngredientSpec1() {
        return ingredientSpec1;
    }

    public void setIngredientSpec1(String ingredientSpec1) {
        this.ingredientSpec1 = ingredientSpec1;
    }

    public String getIngredientSpec2() {
        return ingredientSpec2;
    }

    public void setIngredientSpec2(String ingredientSpec2) {
        this.ingredientSpec2 = ingredientSpec2;
    }

    public String getIngredientSpec3() {
        return ingredientSpec3;
    }

    public void setIngredientSpec3(String ingredientSpec3) {
        this.ingredientSpec3 = ingredientSpec3;
    }

    public String getIngredientSpec4() {
        return ingredientSpec4;
    }

    public void setIngredientSpec4(String ingredientSpec4) {
        this.ingredientSpec4 = ingredientSpec4;
    }

    public String getIngredientSpec5() {
        return ingredientSpec5;
    }

    public void setIngredientSpec5(String ingredientSpec5) {
        this.ingredientSpec5 = ingredientSpec5;
    }

    public Set<OrderIngredientDtoORA> getIngredients() {
        return ingredients;
    }

    public void setIngredients(Set<OrderIngredientDtoORA> ingredients) {
        this.ingredients = ingredients;
    }

    public Set<OrderExtraItemDtoORA> getExtraItems() {
        return extraItems;
    }

    public void setExtraItems(Set<OrderExtraItemDtoORA> extraItems) {
        this.extraItems = extraItems;
    }

    public MarkingDto getMarking() {
        return marking;
    }

    public void setMarking(MarkingDto marking) {
        this.marking = marking;
    }

    public BigDecimal getRollSectionSizeT() {
        return rollSectionSizeT;
    }

    public void setRollSectionSizeT(BigDecimal rollSectionSizeT) {
        this.rollSectionSizeT = rollSectionSizeT;
    }

    public BigDecimal getRollSectionSizeT1() {
        return rollSectionSizeT1;
    }

    public void setRollSectionSizeT1(BigDecimal rollSectionSizeT1) {
        this.rollSectionSizeT1 = rollSectionSizeT1;
    }

    public BigDecimal getRollSectionSizeT2() {
        return rollSectionSizeT2;
    }

    public void setRollSectionSizeT2(BigDecimal rollSectionSizeT2) {
        this.rollSectionSizeT2 = rollSectionSizeT2;
    }

    public BigDecimal getRollSectionSizeT3() {
        return rollSectionSizeT3;
    }

    public void setRollSectionSizeT3(BigDecimal rollSectionSizeT3) {
        this.rollSectionSizeT3 = rollSectionSizeT3;
    }

    public String getMill900350CommonSize() {
        return mill900350CommonSize;
    }

    public void setMill900350CommonSize(String mill900350CommonSize) {
        this.mill900350CommonSize = mill900350CommonSize;
    }

    public Set<OrderRollingDto> getRollingItems() {
        return rollingItems;
    }

    public void setRollingItems(Set<OrderRollingDto> rollingItems) {
        this.rollingItems = rollingItems;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("orderPosition", super.toString())
                .append("orderIndex", orderIndex)
                .append("orderProgressCode", orderProgressCode)
                .append("steelGrade", steelGrade)
                .append("sectionType", sectionType)
                .append("sectionSize1", sectionSize1)
                .append("sectionSize2", sectionSize2)
                .append("goodsLengthToleranceMin", goodsLengthToleranceMin)
                .append("goodsLengthToleranceMax", goodsLengthToleranceMax)
                .append("shortLengthMin", shortLengthMin)
                .append("shortLengthAllowedRate", shortLengthAllowedRate)
                .append("orderShortLengthMin", orderShortLengthMin)
                .append("orderShortLengthAllowedRate", orderShortLengthAllowedRate)
                .append("surfaceStatus", surfaceStatus)
                .append("surfaceTreatGroup", surfaceTreatGroup)
                .append("bundleMinWeight", bundleMinWeight)
                .append("bundleMaxWeight", bundleMaxWeight)
                .append("bindingCount", bindingCount)
                .append("b2b5Standard", b2b5Standard)
                .append("grinding", grinding)
                .append("customerDeliveryDate", customerDeliveryDate)
                .append("deliveryDate", deliveryDate)
                .append("deliveryTermName", deliveryTermName)
                .append("marking", marking)
                .append("r680SectionType", r680SectionType)
                .append("r680SectionSizeT", r680SectionSizeT)
                .append("r680SectionSizeW", r680SectionSizeW)
                .append("r350SectionType", r350SectionType)
                .append("r350SectionSizeT", r350SectionSizeT)
                .append("r350SectionSizeW", r350SectionSizeW)
                .append("deliveryToleranceMin", deliveryToleranceMin)
                .append("deliveryToleranceMax", deliveryToleranceMax)
                .append("ingredientSpec1", ingredientSpec1)
                .append("ingredientSpec2", ingredientSpec2)
                .append("ingredientSpec3", ingredientSpec3)
                .append("ingredientSpec4", ingredientSpec4)
                .append("ingredientSpec5", ingredientSpec5)
                .append("rollSectionSizeT", rollSectionSizeT)
                .append("rollSectionSizeT1", rollSectionSizeT1)
                .append("rollSectionSizeT2", rollSectionSizeT2)
                .append("rollSectionSizeT3", rollSectionSizeT3)
                .append("mill900350CommonSize", mill900350CommonSize)
                .append("ingredients", ingredients)
                .append("extraItems", extraItems)
                .append("rollingItems", rollingItems)
                .toString();
    }

}