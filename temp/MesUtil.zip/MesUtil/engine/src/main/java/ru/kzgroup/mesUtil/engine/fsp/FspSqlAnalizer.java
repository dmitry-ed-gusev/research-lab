package ru.kzgroup.mesUtil.engine.fsp;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.mesUtil.engine.db.AbstractDbAnalizer;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * FSP server sql queries analizer. In constructor you should specify path to FSP server root folder
 * (including [fsp] directory) - folder with subfolders: [conf], [logs], [sqlmap].
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 07.05.13)
*/

public class FspSqlAnalizer {

    private Log log = LogFactory.getLog(FspSqlAnalizer.class);

    private String             fspRoot;
    private AbstractDbAnalizer dbAnalizer;

    /***/
    public FspSqlAnalizer(String fspRoot, AbstractDbAnalizer dbAnalizer) {
        this.fspRoot = fspRoot;
        this.dbAnalizer = dbAnalizer;
    }

    /***/
    private boolean checkFspRootFolder() {
        return false;
    }

    /***/
    public List<FspSqlModel> analize(String fspRoot) {
        log.debug("FspSqlAnalizer.analize() working.");
        List<FspSqlModel> modelsList = new ArrayList<FspSqlModel>();

        // check fsp root folder
        if (!StringUtils.isBlank(fspRoot)) { // method is public - we need full check incoming parameters
            // we need to fix path to FSP server root folder. We replace all \ symbols with / and
            // add one symbol / at the end of path (if there is no such symbol).
            String fspRootFixed = (fspRoot.endsWith("/") || fspRoot.endsWith("\\") ? fspRoot : fspRoot + "/").replace("\\", "/");
            File fspRootFile = new File(fspRootFixed);
            if (fspRootFile.exists() && fspRootFile.isDirectory()) {

                log.debug("FSP server root folder [" + fspRoot + "] is OK! Processing.");
                modelsList = this.recursiveProcessor(fspRootFixed + "sqlmap/", fspRootFixed + "sqlmap/");
            } else { // root folder doesn't exist or not a folder
                log.error("FSP root folder [" + fspRoot + "] doesn't exists or not a folder!");
            }
        } else { // empty root folder
            log.error("FSP server root folder [" + fspRoot + "] is invalid!");
        }

        return modelsList;
    }

    /***/
    private List<FspSqlModel> recursiveProcessor(String fspRoot, String startFolder) {
        //log.debug("FspSqlAnalizer.recursiveProcessor() working. PRIVATE METHOD.");
        List<FspSqlModel> modelsList = new ArrayList<FspSqlModel>();

        // Fix start folder - replace symbols \ with /.
        String startFolderFixed = (startFolder.endsWith("/") || startFolder.endsWith("\\") ? startFolder : startFolder + "/").replace("\\", "/");
        // processing folders recursively
        File startFolderFile = new File(startFolderFixed);
        if (startFolderFile.exists() && startFolderFile.isDirectory()) {
            String[] fileNames = startFolderFile.list(); // all files list (in current dir)
            if (fileNames != null) {
                // recursive processing folders
                for (String fileName : fileNames) {
                    File file = new File(startFolderFile.getPath(), fileName);
                    // recursive call
                    if (file.isDirectory()) {
                        modelsList.addAll(this.recursiveProcessor(fspRoot, file.getPath()));
                    } else if (file.isFile()) { // if we found a file - we will process it
                        // check file extension
                        String extension = fileName.substring(fileName.lastIndexOf(".") + 1);
                        //log.debug(extension);
                        if ("xml".equals(extension)) {
                            // Get fsp sqlmodel prefix - relative catalog (not absolute!)
                            // We substract 1 from second index for removing trailing / symbol.
                            String sqlModelPrefix = startFolderFixed.substring(startFolderFixed.indexOf(fspRoot) + fspRoot.length(), startFolderFixed.length() - 1);
                            //log.debug("----> " + fspRoot + "\n ----> " + startFolderFixed + "\n ----> " + sqlModelPrefix);
                            log.debug("---> " + (startFolderFixed + fileName));
                            // create full name for sqlmodel name -> [catalog:file-without-extension]
                            FspSqlModel sqlModel = new FspSqlModel(sqlModelPrefix + ":" + fileName.substring(0, fileName.lastIndexOf(".")),
                                    (startFolderFixed + fileName), null);
                            modelsList.add(sqlModel);
                        }

                    } // end of section with found file
                }
            }
        } else { // start folder doesn't exist or not a folder
            log.error("Invalid start folder [" + startFolder + "]! Folder doesn't exist or not a folder!");
        }

        return modelsList;
    }

    public static void main(String[] args) {
        Log log = LogFactory.getLog(FspSqlAnalizer.class);
        log.info("FspSqlAnalizer main starting...");

        //List<FspSqlModel> modelsList = FspSqlAnalizer.analize("D:/MyDocs\\Projects/PMES\\WebContent/WEB-INF/fsp");
        /*
        List<FspSqlModel> modelsList = FspSqlAnalizer.analize("c:\\temp\\PMES\\WebContent\\WEB-INF\\fsp\\");
        log.info("Found [" + modelsList.size() + "] sqlmaps.");
        for (FspSqlModel model : modelsList) {
            log.info("-> " + model);
        }
        */


    }

}