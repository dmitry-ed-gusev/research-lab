package ru.kzgroup.mesUtil;

import gusev.dmitry.jtils.db.OraDbConfig;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.exceptions.MesException;

import java.io.File;

/**
 * Configuration class for MES system (source code folder + MES DB connection config).
 * Class is immutable (related class OraDbConfig immutable too).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 13.05.13)
*/

public class MesConfig {

    private Log log = LogFactory.getLog(MesConfig.class);

    private String      mesRoot;
    private OraDbConfig oraDbConfig;

    /**
     * Constructor guarantees, that mesRoot folder exists and is folder, otherwise it throws exception.
     * Config for dbms connection may be empty.
    */
    public MesConfig(String mesRoot, OraDbConfig oraDbConfig) throws MesException {
        if (!StringUtils.isBlank(mesRoot) && new File(mesRoot).exists() && new File(mesRoot).isDirectory()) {
            this.mesRoot  = mesRoot;
            this.oraDbConfig = oraDbConfig;
        } else {
            throw new MesException("Specified MES root folder doesn't exist or not a folder!");
        }
    }

    public String getMesRoot() {
        return mesRoot;
    }

    public OraDbConfig getOraDbConfig() {
        return oraDbConfig;
    }

}