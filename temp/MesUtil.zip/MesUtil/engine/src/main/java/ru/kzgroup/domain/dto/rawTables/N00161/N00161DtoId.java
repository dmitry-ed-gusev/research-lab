package ru.kzgroup.domain.dto.rawTables.N00161;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for raw ARM table N00161.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 13.08.2014)
*/

public class N00161DtoId implements Serializable {

    private static final long serialVersionUID = 1L;

    private int year;
    private int month;
    private int codePlan;
    private int codeParameter;

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getCodePlan() {
        return codePlan;
    }

    public void setCodePlan(int codePlan) {
        this.codePlan = codePlan;
    }

    public int getCodeParameter() {
        return codeParameter;
    }

    public void setCodeParameter(int codeParameter) {
        this.codeParameter = codeParameter;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        N00161DtoId that = (N00161DtoId) o;

        if (codeParameter != that.codeParameter) return false;
        if (codePlan != that.codePlan) return false;
        if (month != that.month) return false;
        if (year != that.year) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = year;
        result = 31 * result + month;
        result = 31 * result + codePlan;
        result = 31 * result + codeParameter;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("year", year)
                .append("month", month)
                .append("codePlan", codePlan)
                .append("codeParameter", codeParameter)
                .toString();
    }

}