package ru.kzgroup;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import ru.kzgroup.exceptions.InternalException;
import ru.kzgroup.reporting.OrdersReportingEngine;

import java.util.Locale;

/**
 * Class-tester for other classes (test starts).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 03.07.2014)
 */

public class EngineTESTER {

    /***/
    public static void main(String[] args) throws InternalException {
        Log log = LogFactory.getLog(EngineTESTER.class);
        log.info("TESTER starting.");

        Locale.setDefault(Locale.US);
        AbstractApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"EngineContext.xml"}, false);
        context.refresh();

        // --
        OrdersReportingEngine engine = (OrdersReportingEngine) context.getBean("ordersReportingEngine");
        engine.zzz();
        System.exit(777);

    }

}