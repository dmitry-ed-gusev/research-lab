package ru.kzgroup.domain.dto.directories;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * SHIPMENT TYPE - domain object. ARM - table new/c160/nsi/M110, MES -
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 31.07.2014)
*/

public class ShipmentTypeDto extends BaseDto {

    private int    id;
    private String name;
    private String shortName;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("name", name)
                .append("shortName", shortName)
                .toString();
    }

}