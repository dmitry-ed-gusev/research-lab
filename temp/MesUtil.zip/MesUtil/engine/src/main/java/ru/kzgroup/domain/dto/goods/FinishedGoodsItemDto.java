package ru.kzgroup.domain.dto.goods;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.domain.dto.BaseDto;
import ru.kzgroup.domain.dto.customers.CustomerDto;
import ru.kzgroup.domain.dto.directories.SectionDto;
import ru.kzgroup.domain.dto.directories.SteelGradeDto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * FINISHED GOODS ITEM - domain object.
 * ARM->M149, MES->TB_FINISHED_GOODS_ITEMS
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 20.03.2014)
*/

// todo: remove all codes, leave just objects (example: remove customerCode, leave CustomerDto (customer))

public class FinishedGoodsItemDto extends BaseDto {

    private FinishedGoodsItemDtoId id;                   // M149->[ГодРК, РК, Накладная]compisite primary key
    private Integer                orderYear;            // M149->OrderYear
    private Integer                orderMonth;           // M149->OrderMonth
    private Integer                position;             // M149->Позиция
    private Integer                sizeFrom;             // M149->Длина от
    private Integer                sizeTo;               // M149->Длина до
    private BigDecimal             amountWithAdd;        // M149->Сумма с припл.
    private BigDecimal             priceWithoutAdd;      // M149->Цена без припл.
    private BigDecimal             wagon;                // M149->Вагон
    private Integer                requirementNumber;    // M149->N требования
    private Integer                requirementNumber2;   // M149->НомТреб2
    private Date                   requirementDate;      // M149->Дата треб.
    private BigDecimal             requirementAmount;    // M149->Сумма по треб.
    private Integer                additionalCode1;      // M149->Доп.код 1
    private Integer                additionalCode2;      // M149->Доп.код 2
    private Integer                payerCode;            // M149->Код плательщика
    private BigDecimal             billAmount1;          // M149->СуммаСчет1
    private Date                   exchangeRateDate;     // M149->ExchangeRateDate
    private BigDecimal             currencyPrice;        // M149->CurrencyPrice
    private Integer                customerCode;         // M149->Код Грузопол., customer code (nullable)
    private String                 orderNumber;          // M149->Заказ, order number
    private Integer                steelGradeCode;       // M149->Код марки, steel grade (nullable)
    private Integer                sectionCode;          // M149->Код профиля, section (профиль) (nullable)
    private Integer                size1;                // M149->Длина 1 (nullable)
    private Integer                size2;                // M149->Длина 2 (nullable)
    private Date                   warehouseDate;        // M149->'Дата ОТК', date of warehouse receiving (дата поступления на склад)
    private Date                   fromShopShipmentDate; // M149->'Дата отгр.цехом', from shop shipment date (дата отгрузки цехом ?заказчику?)
    private Date                   toShopShipmentDate;   // M149->'ДатаОтгрВЦех180', to shop shipment date (дата отгрузки в цех 180 - ?из ц160?)
    private BigDecimal             weight;               // M149->Вес по накл., item weight
    private BigDecimal             railwayRate;          // M149->Ж/Д тариф
    private Integer                shopSender;           // M149->ЦехОтпр
    private Date                   storageDate;          // M149->Дата хранения
    private Date                   railwayShipmentDate;  // M149->Дата отгр.ж/д
    // object fields - related to other entities/tables
    private CustomerDto            customer;             // customer information
    private SteelGradeDto          steelGrade;           // steel grade info
    private SectionDto             section;              // section info

    /** Default constructor (for Hibernate etc) */
    public FinishedGoodsItemDto() {}

    /** Copying constructor. */
    public FinishedGoodsItemDto(FinishedGoodsItemDto finishedGoodsItem) {
        if (finishedGoodsItem != null) {
            this.id                   = new FinishedGoodsItemDtoId(finishedGoodsItem.getId());
            this.orderYear            = finishedGoodsItem.getOrderYear();
            this.orderMonth           = finishedGoodsItem.getOrderMonth();
            this.position             = finishedGoodsItem.getPosition();
            this.sizeFrom             = finishedGoodsItem.getSizeFrom();
            this.sizeTo               = finishedGoodsItem.getSizeTo();
            this.amountWithAdd        = finishedGoodsItem.getAmountWithAdd();
            this.priceWithoutAdd      = finishedGoodsItem.getPriceWithoutAdd();
            this.wagon                = finishedGoodsItem.getWagon();
            this.requirementNumber    = finishedGoodsItem.getRequirementNumber();
            this.requirementNumber2   = finishedGoodsItem.getRequirementNumber2();
            this.requirementDate      = finishedGoodsItem.getRequirementDate();
            this.requirementAmount    = finishedGoodsItem.getRequirementAmount();
            this.additionalCode1      = finishedGoodsItem.getAdditionalCode1();
            this.additionalCode2      = finishedGoodsItem.getAdditionalCode2();
            this.payerCode            = finishedGoodsItem.getPayerCode();
            this.billAmount1          = finishedGoodsItem.getBillAmount1();
            this.exchangeRateDate     = finishedGoodsItem.getExchangeRateDate();
            this.currencyPrice        = finishedGoodsItem.getCurrencyPrice();
            this.customerCode         = finishedGoodsItem.getCustomerCode();
            this.orderNumber          = finishedGoodsItem.getOrderNumber();
            this.steelGradeCode       = finishedGoodsItem.getSteelGradeCode();
            this.sectionCode          = finishedGoodsItem.getSectionCode();
            this.size1                = finishedGoodsItem.getSize1();
            this.size2                = finishedGoodsItem.getSize2();
            this.warehouseDate        = new Date(finishedGoodsItem.getWarehouseDate().getTime());
            this.fromShopShipmentDate = new Date(finishedGoodsItem.getFromShopShipmentDate().getTime());
            this.toShopShipmentDate   = new Date(finishedGoodsItem.getToShopShipmentDate().getTime());
            this.weight               = finishedGoodsItem.getWeight();
            this.customer             = new CustomerDto(finishedGoodsItem.getCustomer(), false);
            this.steelGrade           = new SteelGradeDto(finishedGoodsItem.getSteelGrade());
            this.section              = new SectionDto(finishedGoodsItem.getSection());
        } else {
            LogFactory.getLog(FinishedGoodsItemDto.class).warn(String.format("Copy NULL object [%s]!", FinishedGoodsItemDto.class));
        }
    }

    public FinishedGoodsItemDtoId getId() {
        return id;
    }

    public void setId(FinishedGoodsItemDtoId id) {
        this.id = id;
    }

    public Integer getOrderYear() {
        return orderYear;
    }

    public void setOrderYear(Integer orderYear) {
        this.orderYear = orderYear;
    }

    public Integer getOrderMonth() {
        return orderMonth;
    }

    public void setOrderMonth(Integer orderMonth) {
        this.orderMonth = orderMonth;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public Integer getSizeFrom() {
        return sizeFrom;
    }

    public void setSizeFrom(Integer sizeFrom) {
        this.sizeFrom = sizeFrom;
    }

    public Integer getSizeTo() {
        return sizeTo;
    }

    public void setSizeTo(Integer sizeTo) {
        this.sizeTo = sizeTo;
    }

    public BigDecimal getAmountWithAdd() {
        return amountWithAdd;
    }

    public void setAmountWithAdd(BigDecimal amountWithAdd) {
        this.amountWithAdd = amountWithAdd;
    }

    public BigDecimal getPriceWithoutAdd() {
        return priceWithoutAdd;
    }

    public void setPriceWithoutAdd(BigDecimal priceWithoutAdd) {
        this.priceWithoutAdd = priceWithoutAdd;
    }

    public BigDecimal getWagon() {
        return wagon;
    }

    public void setWagon(BigDecimal wagon) {
        this.wagon = wagon;
    }

    public Integer getRequirementNumber() {
        return requirementNumber;
    }

    public void setRequirementNumber(Integer requirementNumber) {
        this.requirementNumber = requirementNumber;
    }

    public Integer getRequirementNumber2() {
        return requirementNumber2;
    }

    public void setRequirementNumber2(Integer requirementNumber2) {
        this.requirementNumber2 = requirementNumber2;
    }

    public Date getRequirementDate() {
        return requirementDate;
    }

    public void setRequirementDate(Date requirementDate) {
        this.requirementDate = requirementDate;
    }

    public BigDecimal getRequirementAmount() {
        return requirementAmount;
    }

    public void setRequirementAmount(BigDecimal requirementAmount) {
        this.requirementAmount = requirementAmount;
    }

    public Integer getAdditionalCode1() {
        return additionalCode1;
    }

    public void setAdditionalCode1(Integer additionalCode1) {
        this.additionalCode1 = additionalCode1;
    }

    public Integer getAdditionalCode2() {
        return additionalCode2;
    }

    public void setAdditionalCode2(Integer additionalCode2) {
        this.additionalCode2 = additionalCode2;
    }

    public Integer getPayerCode() {
        return payerCode;
    }

    public void setPayerCode(Integer payerCode) {
        this.payerCode = payerCode;
    }

    public BigDecimal getBillAmount1() {
        return billAmount1;
    }

    public void setBillAmount1(BigDecimal billAmount1) {
        this.billAmount1 = billAmount1;
    }

    public Date getExchangeRateDate() {
        return exchangeRateDate;
    }

    public void setExchangeRateDate(Date exchangeRateDate) {
        this.exchangeRateDate = exchangeRateDate;
    }

    public BigDecimal getCurrencyPrice() {
        return currencyPrice;
    }

    public void setCurrencyPrice(BigDecimal currencyPrice) {
        this.currencyPrice = currencyPrice;
    }

    public Integer getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(Integer customerCode) {
        this.customerCode = customerCode;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public Integer getSteelGradeCode() {
        return steelGradeCode;
    }

    public void setSteelGradeCode(Integer steelGradeCode) {
        this.steelGradeCode = steelGradeCode;
    }

    public Integer getSectionCode() {
        return sectionCode;
    }

    public void setSectionCode(Integer sectionCode) {
        this.sectionCode = sectionCode;
    }

    public Integer getSize1() {
        return size1;
    }

    public void setSize1(Integer size1) {
        this.size1 = size1;
    }

    public Integer getSize2() {
        return size2;
    }

    public void setSize2(Integer size2) {
        this.size2 = size2;
    }

    public Date getWarehouseDate() {
        return warehouseDate;
    }

    public void setWarehouseDate(Date warehouseDate) {
        this.warehouseDate = warehouseDate;
    }

    public Date getFromShopShipmentDate() {
        return fromShopShipmentDate;
    }

    public void setFromShopShipmentDate(Date fromShopShipmentDate) {
        this.fromShopShipmentDate = fromShopShipmentDate;
    }

    public Date getToShopShipmentDate() {
        return toShopShipmentDate;
    }

    public void setToShopShipmentDate(Date toShopShipmentDate) {
        this.toShopShipmentDate = toShopShipmentDate;
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    public CustomerDto getCustomer() {
        return customer;
    }

    public void setCustomer(CustomerDto customer) {
        this.customer = customer;
    }

    public SteelGradeDto getSteelGrade() {
        return steelGrade;
    }

    public void setSteelGrade(SteelGradeDto steelGrade) {
        this.steelGrade = steelGrade;
    }

    public SectionDto getSection() {
        return section;
    }

    public void setSection(SectionDto section) {
        this.section = section;
    }

    public BigDecimal getRailwayRate() {
        return railwayRate;
    }

    public void setRailwayRate(BigDecimal railwayRate) {
        this.railwayRate = railwayRate;
    }

    public Integer getShopSender() {
        return shopSender;
    }

    public void setShopSender(Integer shopSender) {
        this.shopSender = shopSender;
    }

    public Date getStorageDate() {
        return storageDate;
    }

    public void setStorageDate(Date storageDate) {
        this.storageDate = storageDate;
    }

    public Date getRailwayShipmentDate() {
        return railwayShipmentDate;
    }

    public void setRailwayShipmentDate(Date railwayShipmentDate) {
        this.railwayShipmentDate = railwayShipmentDate;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("orderYear", orderYear)
                .append("orderMonth", orderMonth)
                .append("position", position)
                .append("sizeFrom", sizeFrom)
                .append("sizeTo", sizeTo)
                .append("amountWithAdd", amountWithAdd)
                .append("priceWithoutAdd", priceWithoutAdd)
                .append("wagon", wagon)
                .append("requirementNumber", requirementNumber)
                .append("requirementNumber2", requirementNumber2)
                .append("requirementDate", requirementDate)
                .append("requirementAmount", requirementAmount)
                .append("additionalCode1", additionalCode1)
                .append("additionalCode2", additionalCode2)
                .append("payerCode", payerCode)
                .append("billAmount1", billAmount1)
                .append("exchangeRateDate", exchangeRateDate)
                .append("currencyPrice", currencyPrice)
                .append("customerCode", customerCode)
                .append("orderNumber", orderNumber)
                .append("steelGradeCode", steelGradeCode)
                .append("sectionCode", sectionCode)
                .append("size1", size1)
                .append("size2", size2)
                .append("warehouseDate", warehouseDate)
                .append("fromShopShipmentDate", fromShopShipmentDate)
                .append("toShopShipmentDate", toShopShipmentDate)
                .append("weight", weight)
                .append("railwayRate", railwayRate)
                .append("shopSender", shopSender)
                .append("storageDate", storageDate)
                .append("railwayShipmentDate", railwayShipmentDate)
                .append("customer", customer)
                .append("steelGrade", steelGrade)
                .append("section", section)
                .toString();
    }

}