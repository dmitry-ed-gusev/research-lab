package ru.kzgroup.domain.dto.customers;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.domain.dto.BaseDto;
import ru.kzgroup.domain.dto.directories.CountryDto;
import ru.kzgroup.domain.dto.goods.FinishedGoodsItemDto;

import java.util.HashSet;
import java.util.Set;

/**
 * CUSTOMER - domain object.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 18.02.14)
*/

// todo: replace codes with objects (region, city, railway station)

public class CustomerDto extends BaseDto {

    private int        code;               // primary key
    private int        juridicalPhysical;  //
    private int        ownerTypeCode;      //
    private String     abbreviation;       //
    private String     name;               //
    private String     nameEnglish;        //
    private String     zipCode;            //
    private String     orderGroup;         //
    private CountryDto country;            // country (link to other object)
    private int        regionCode;         //
    private String     regionName;         //
    private int        cityCode;           //
    private String     cityName;           //
    private String     cityAddress;        //
    private String     cityAddressEnglish; //
    private String     fullAddress;        //
    private String     fullAddressEnglish; //
    private String     railwayStation;     //
    private String     numberINN;          //
    private String     numberOKPO;         //
    private String     numberOKONH;        //
    private String     numberOGRN;         //
    private String     numberKPP;          //
    private Integer    statusCode;         // nullable in PDX (use object type)

    // finished goods items for this customer (one-to-many relation)
//    private Set<FinishedGoodsItemDto> finishedGoods = new HashSet<>(0); // todo: possibe circle: customer->goods->customer->goods.... etc!!!!!
    // email addresses for this customer (one-to-many relation)
    private Set<CustomerEmailDto>     emails        = new HashSet<>(0);

    /** Default constructor (for Hibernate etc) */
    public CustomerDto() {}

    /**
     * Copying constructor.
     * @param copyFinishedGoods boolean copy (true) or not (false) finished goods set of object. We need this parameter for
     *        prevent cycle links: CustomerDto->Set of FinishedGoodsItemDto, FinishedGoodsItemDto->CustomerDto etc. If we
     *        put false as value set of finished goods items will not be copyed.
    */
    public CustomerDto(CustomerDto customer, boolean copyFinishedGoods) {
        if (customer != null) {
            this.code               = customer.getCode();
            this.juridicalPhysical  = customer.getJuridicalPhysical();
            this.ownerTypeCode      = customer.getOwnerTypeCode();
            this.abbreviation       = customer.getAbbreviation();
            this.name               = customer.getName();
            this.nameEnglish        = customer.getNameEnglish();
            this.zipCode            = customer.getZipCode();
            this.orderGroup         = customer.getOrderGroup();
            this.country            = new CountryDto(customer.getCountry());
            this.regionCode         = customer.getRegionCode();
            this.regionName         = customer.getRegionName();
            this.cityCode           = customer.getCityCode();
            this.cityName           = customer.getCityName();
            this.cityAddress        = customer.getCityAddress();
            this.cityAddressEnglish = customer.getCityAddressEnglish();
            this.fullAddress        = customer.getFullAddress();
            this.fullAddressEnglish = customer.getFullAddressEnglish();
            this.railwayStation     = customer.getRailwayStation();
            this.numberINN          = customer.getNumberINN();
            this.numberOKPO         = customer.getNumberOKPO();
            this.numberOKONH        = customer.getNumberOKONH();
            this.numberOGRN         = customer.getNumberOGRN();
            this.numberKPP          = customer.getNumberKPP();
            this.statusCode         = customer.getStatusCode();

            // finished goods items set
            /*
            if (copyFinishedGoods) {
                Set<FinishedGoodsItemDto> goods = customer.getFinishedGoods();
                if (goods != null && !goods.isEmpty()) { // there are finished goods for current customer
                    this.finishedGoods = new HashSet<>();
                    for (FinishedGoodsItemDto goodsItem : goods) {
                        this.finishedGoods.add(new FinishedGoodsItemDto(goodsItem));
                    }
                } else { // no finished goods for current customer
                    this.finishedGoods = null;
                }
            } else { // don't copy finished goods set
                this.finishedGoods = null;
            }
            */

            // current customer emails set
            Set<CustomerEmailDto> emails = customer.getEmails();
            if (emails != null && !emails.isEmpty()) { // there are emails for current customer
                this.emails = new HashSet<>();
                for (CustomerEmailDto email : emails) {
                    this.emails.add(new CustomerEmailDto(email));
                }
            } else { // no email for customer
                this.emails = null;
            }

        } else { // input object is empty (NULL)
            LogFactory.getLog(CustomerDto.class).warn(String.format("Copy NULL object [%s]!", CustomerDto.class));
            this.code               = 0;
            this.juridicalPhysical  = 0;
            this.ownerTypeCode      = 0;
            this.abbreviation       = null;
            this.name               = null;
            this.nameEnglish        = null;
            this.zipCode            = null;
            this.orderGroup         = null;
            this.country            = null;
            this.regionCode         = 0;
            this.regionName         = null;
            this.cityCode           = 0;
            this.cityName           = null;
            this.cityAddress        = null;
            this.cityAddressEnglish = null;
            this.fullAddress        = null;
            this.fullAddressEnglish = null;
            this.railwayStation     = null;
            this.numberINN          = null;
            this.numberOKPO         = null;
            this.numberOKONH        = null;
            this.numberOGRN         = null;
            this.numberKPP          = null;
            this.statusCode         = null;
            //this.finishedGoods      = null;
            this.emails             = null;
        }
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public int getJuridicalPhysical() {
        return juridicalPhysical;
    }

    public void setJuridicalPhysical(int juridicalPhysical) {
        this.juridicalPhysical = juridicalPhysical;
    }

    public int getOwnerTypeCode() {
        return ownerTypeCode;
    }

    public void setOwnerTypeCode(int ownerTypeCode) {
        this.ownerTypeCode = ownerTypeCode;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameEnglish() {
        return nameEnglish;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getOrderGroup() {
        return orderGroup;
    }

    public void setOrderGroup(String orderGroup) {
        this.orderGroup = orderGroup;
    }

    public CountryDto getCountry() {
        return country;
    }

    public void setCountry(CountryDto country) {
        this.country = country;
    }

    public int getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(int regionCode) {
        this.regionCode = regionCode;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public int getCityCode() {
        return cityCode;
    }

    public void setCityCode(int cityCode) {
        this.cityCode = cityCode;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCityAddress() {
        return cityAddress;
    }

    public void setCityAddress(String cityAddress) {
        this.cityAddress = cityAddress;
    }

    public String getCityAddressEnglish() {
        return cityAddressEnglish;
    }

    public void setCityAddressEnglish(String cityAddressEnglish) {
        this.cityAddressEnglish = cityAddressEnglish;
    }

    public String getFullAddress() {
        return fullAddress;
    }

    public void setFullAddress(String fullAddress) {
        this.fullAddress = fullAddress;
    }

    public String getFullAddressEnglish() {
        return fullAddressEnglish;
    }

    public void setFullAddressEnglish(String fullAddressEnglish) {
        this.fullAddressEnglish = fullAddressEnglish;
    }

    public String getRailwayStation() {
        return railwayStation;
    }

    public void setRailwayStation(String railwayStation) {
        this.railwayStation = railwayStation;
    }

    public String getNumberINN() {
        return numberINN;
    }

    public void setNumberINN(String numberINN) {
        this.numberINN = numberINN;
    }

    public String getNumberOKPO() {
        return numberOKPO;
    }

    public void setNumberOKPO(String numberOKPO) {
        this.numberOKPO = numberOKPO;
    }

    public String getNumberOKONH() {
        return numberOKONH;
    }

    public void setNumberOKONH(String numberOKONH) {
        this.numberOKONH = numberOKONH;
    }

    public String getNumberOGRN() {
        return numberOGRN;
    }

    public void setNumberOGRN(String numberOGRN) {
        this.numberOGRN = numberOGRN;
    }

    public String getNumberKPP() {
        return numberKPP;
    }

    public void setNumberKPP(String numberKPP) {
        this.numberKPP = numberKPP;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    /*
    public Set<FinishedGoodsItemDto> getFinishedGoods() {
        return finishedGoods;
    }

    public void setFinishedGoods(Set<FinishedGoodsItemDto> finishedGoods) {
        this.finishedGoods = finishedGoods;
    }
    */

    public Set<CustomerEmailDto> getEmails() {
        return emails;
    }

    public void setEmails(Set<CustomerEmailDto> emails) {
        this.emails = emails;
    }

    /***/
    /*
    public String csvEmailsList() {
        StringBuilder csvList = new StringBuilder();
        if (!this.emails.isEmpty()) {
            int counter = 1;
            for (CustomerEmailDto email : this.emails) {
                csvList.append(email.getEmail());
                if (counter < this.emails.size()) {
                    csvList.append(", ");
                }
                counter++;
            }
        }
        return csvList.toString();
    }
    */

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("code", code)
                .append("juridicalPhysical", juridicalPhysical)
                .append("ownerTypeCode", ownerTypeCode)
                .append("abbreviation", abbreviation)
                .append("name", name)
                .append("nameEnglish", nameEnglish)
                .append("zipCode", zipCode)
                .append("orderGroup", orderGroup)
                .append("country", country)
                .append("regionCode", regionCode)
                .append("regionName", regionName)
                .append("cityCode", cityCode)
                .append("cityName", cityName)
                .append("cityAddress", cityAddress)
                .append("cityAddressEnglish", cityAddressEnglish)
                .append("fullAddress", fullAddress)
                .append("fullAddressEnglish", fullAddressEnglish)
                .append("railwayStation", railwayStation)
                .append("numberINN", numberINN)
                .append("numberOKPO", numberOKPO)
                .append("numberOKONH", numberOKONH)
                .append("numberOGRN", numberOGRN)
                .append("numberKPP", numberKPP)
                .append("statusCode", statusCode)
                //.append("finishedGoods", finishedGoods)
                .append("emails", emails)
                .toString();
    }

}