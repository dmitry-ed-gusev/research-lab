package ru.kzgroup.domain.dto.orders.pdx;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for domain object - NOTE for ORDER.
 * ARM: D0502002, MES - orders table TB_SM_ORDCOMM.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 05.06.2014)
*/

public class OrderD0502002IdPDX implements Serializable {

    private static final long serialVersionUID = 1L;

    private int contractCode;
    private int addendumCode;
    private int stringNo;

    public int getContractCode() {
        return contractCode;
    }

    public void setContractCode(int contractCode) {
        this.contractCode = contractCode;
    }

    public int getAddendumCode() {
        return addendumCode;
    }

    public void setAddendumCode(int addendumCode) {
        this.addendumCode = addendumCode;
    }

    public int getStringNo() {
        return stringNo;
    }

    public void setStringNo(int stringNo) {
        this.stringNo = stringNo;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement", "QuestionableName"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        OrderD0502002IdPDX that = (OrderD0502002IdPDX) obj;

        if (addendumCode != that.addendumCode) return false;
        if (contractCode != that.contractCode) return false;
        if (stringNo != that.stringNo) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = contractCode;
        result = 31 * result + addendumCode;
        result = 31 * result + stringNo;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("contractCode", contractCode)
                .append("addendumCode", addendumCode)
                .append("stringNo", stringNo)
                .toString();
    }

}