package ru.kzgroup.mesUtil.observer;

/**
 * Interface for observer module.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 08.05.13)
 */

public interface Observer {

    /**
     * Handling event from observable object. Event hold info about that object.
    */
    public void handleEvent(EventInfo eventInfo);

}