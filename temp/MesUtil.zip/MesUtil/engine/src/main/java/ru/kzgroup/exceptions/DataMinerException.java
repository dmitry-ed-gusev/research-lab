package ru.kzgroup.exceptions;

/**
 * Common exception for data miner application.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 02.08.13)
*/

public class DataMinerException extends Exception {

    public DataMinerException(String message) {
        super(message);
    }

    public DataMinerException(Throwable cause) {
        super(cause);
    }

    public DataMinerException(String message, Throwable cause) {
        super(message, cause);
    }

}