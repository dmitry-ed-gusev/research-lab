package ru.kzgroup.domain.dto.rawTables.m160;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Domain object - raw table M160.
 * Field ID can't be null. If its null -> NPE!
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 08.05.2014)
*/

@SuppressWarnings({"ClassWithTooManyMethods", "OverlyComplexClass"})
public class M160 implements Serializable {

    private static final long serialVersionUID = 1L;

    private M160Id     id;                // composite primary key
    private String     meltNumber;        // Плавка
    private Integer    lengthFrom;        // Дл_от
    private Integer    lengthTo;          // Дл_до
    private Integer    packageCount;      // Кол_пак
    private Integer    piecesCount;       // Кол_шт
    private BigDecimal weight;            // Вес_тн
    private Date       rollingDate;       // ДатаПроката
    private Date       otkDate;           // ДатаОТК
    private Integer    otkYear;           // ГодОТК
    private BigDecimal waybillAmount;     // СуммаНакл
    private BigDecimal claimWeight;       // ВесРекл
    private BigDecimal claimAmount;       // СуммаРекл
    private Integer    claimPieces;       // PieceClaim
    private Date       dateOut;           // DateOut
    private Integer    deliveryTermsCode; // DeliveryTermsCode
    private BigDecimal percentNDS;        // NDSPercent
    private Integer    waybillStr;        // WayBillStr
    private Date       wtDate;            // WTDate
    private String     isArc;             // IsArc

    public M160Id getId() {
        return id;
    }

    public void setId(M160Id id) {
        this.id = id;
    }

    public String getMeltNumber() {
        return meltNumber;
    }

    public void setMeltNumber(String meltNumber) {
        this.meltNumber = meltNumber;
    }

    public Integer getLengthFrom() {
        return lengthFrom;
    }

    public void setLengthFrom(Integer lengthFrom) {
        this.lengthFrom = lengthFrom;
    }

    public Integer getLengthTo() {
        return lengthTo;
    }

    public void setLengthTo(Integer lengthTo) {
        this.lengthTo = lengthTo;
    }

    public Integer getPackageCount() {
        return packageCount;
    }

    public void setPackageCount(Integer packageCount) {
        this.packageCount = packageCount;
    }

    public Integer getPiecesCount() {
        return piecesCount;
    }

    public void setPiecesCount(Integer piecesCount) {
        this.piecesCount = piecesCount;
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    public Date getRollingDate() {
        return rollingDate;
    }

    public void setRollingDate(Date rollingDate) {
        this.rollingDate = rollingDate;
    }

    public Date getOtkDate() {
        return otkDate;
    }

    public void setOtkDate(Date otkDate) {
        this.otkDate = otkDate;
    }

    public Integer getOtkYear() {
        return otkYear;
    }

    public void setOtkYear(Integer otkYear) {
        this.otkYear = otkYear;
    }

    public BigDecimal getWaybillAmount() {
        return waybillAmount;
    }

    public void setWaybillAmount(BigDecimal waybillAmount) {
        this.waybillAmount = waybillAmount;
    }

    public BigDecimal getClaimWeight() {
        return claimWeight;
    }

    public void setClaimWeight(BigDecimal claimWeight) {
        this.claimWeight = claimWeight;
    }

    public BigDecimal getClaimAmount() {
        return claimAmount;
    }

    public void setClaimAmount(BigDecimal claimAmount) {
        this.claimAmount = claimAmount;
    }

    public Integer getClaimPieces() {
        return claimPieces;
    }

    public void setClaimPieces(Integer claimPieces) {
        this.claimPieces = claimPieces;
    }

    public Date getDateOut() {
        return dateOut;
    }

    public void setDateOut(Date dateOut) {
        this.dateOut = dateOut;
    }

    public Integer getDeliveryTermsCode() {
        return deliveryTermsCode;
    }

    public void setDeliveryTermsCode(Integer deliveryTermsCode) {
        this.deliveryTermsCode = deliveryTermsCode;
    }

    public BigDecimal getPercentNDS() {
        return percentNDS;
    }

    public void setPercentNDS(BigDecimal percentNDS) {
        this.percentNDS = percentNDS;
    }

    public Integer getWaybillStr() {
        return waybillStr;
    }

    public void setWaybillStr(Integer waybillStr) {
        this.waybillStr = waybillStr;
    }

    public Date getWtDate() {
        return wtDate;
    }

    public void setWtDate(Date wtDate) {
        this.wtDate = wtDate;
    }

    public String getIsArc() {
        return isArc;
    }

    public void setIsArc(String isArc) {
        this.isArc = isArc;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        M160 m160 = (M160) obj;

        if (claimAmount != null ? !claimAmount.equals(m160.claimAmount) : m160.claimAmount != null) return false;
        if (claimPieces != null ? !claimPieces.equals(m160.claimPieces) : m160.claimPieces != null) return false;
        if (claimWeight != null ? !claimWeight.equals(m160.claimWeight) : m160.claimWeight != null) return false;
        if (dateOut != null ? !dateOut.equals(m160.dateOut) : m160.dateOut != null) return false;
        if (deliveryTermsCode != null ? !deliveryTermsCode.equals(m160.deliveryTermsCode) : m160.deliveryTermsCode != null)
            return false;
        if (!id.equals(m160.id)) return false; // ID can't be null. If its null -> NPE!
        if (isArc != null ? !isArc.equals(m160.isArc) : m160.isArc != null) return false;
        if (lengthFrom != null ? !lengthFrom.equals(m160.lengthFrom) : m160.lengthFrom != null) return false;
        if (lengthTo != null ? !lengthTo.equals(m160.lengthTo) : m160.lengthTo != null) return false;
        if (meltNumber != null ? !meltNumber.equals(m160.meltNumber) : m160.meltNumber != null) return false;
        if (otkDate != null ? !otkDate.equals(m160.otkDate) : m160.otkDate != null) return false;
        if (otkYear != null ? !otkYear.equals(m160.otkYear) : m160.otkYear != null) return false;
        if (packageCount != null ? !packageCount.equals(m160.packageCount) : m160.packageCount != null) return false;
        if (percentNDS != null ? !percentNDS.equals(m160.percentNDS) : m160.percentNDS != null) return false;
        if (piecesCount != null ? !piecesCount.equals(m160.piecesCount) : m160.piecesCount != null) return false;
        if (rollingDate != null ? !rollingDate.equals(m160.rollingDate) : m160.rollingDate != null) return false;
        if (waybillAmount != null ? !waybillAmount.equals(m160.waybillAmount) : m160.waybillAmount != null)
            return false;
        if (waybillStr != null ? !waybillStr.equals(m160.waybillStr) : m160.waybillStr != null) return false;
        if (weight != null ? !weight.equals(m160.weight) : m160.weight != null) return false;
        if (wtDate != null ? !wtDate.equals(m160.wtDate) : m160.wtDate != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id.hashCode();
        result = 31 * result + (meltNumber != null ? meltNumber.hashCode() : 0);
        result = 31 * result + (lengthFrom != null ? lengthFrom.hashCode() : 0);
        result = 31 * result + (lengthTo != null ? lengthTo.hashCode() : 0);
        result = 31 * result + (packageCount != null ? packageCount.hashCode() : 0);
        result = 31 * result + (piecesCount != null ? piecesCount.hashCode() : 0);
        result = 31 * result + (weight != null ? weight.hashCode() : 0);
        result = 31 * result + (rollingDate != null ? rollingDate.hashCode() : 0);
        result = 31 * result + (otkDate != null ? otkDate.hashCode() : 0);
        result = 31 * result + (otkYear != null ? otkYear.hashCode() : 0);
        result = 31 * result + (waybillAmount != null ? waybillAmount.hashCode() : 0);
        result = 31 * result + (claimWeight != null ? claimWeight.hashCode() : 0);
        result = 31 * result + (claimAmount != null ? claimAmount.hashCode() : 0);
        result = 31 * result + (claimPieces != null ? claimPieces.hashCode() : 0);
        result = 31 * result + (dateOut != null ? dateOut.hashCode() : 0);
        result = 31 * result + (deliveryTermsCode != null ? deliveryTermsCode.hashCode() : 0);
        result = 31 * result + (percentNDS != null ? percentNDS.hashCode() : 0);
        result = 31 * result + (waybillStr != null ? waybillStr.hashCode() : 0);
        result = 31 * result + (wtDate != null ? wtDate.hashCode() : 0);
        result = 31 * result + (isArc != null ? isArc.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("meltNumber", meltNumber)
                .append("lengthFrom", lengthFrom)
                .append("lengthTo", lengthTo)
                .append("packageCount", packageCount)
                .append("piecesCount", piecesCount)
                .append("weight", weight)
                .append("rollingDate", rollingDate)
                .append("otkDate", otkDate)
                .append("otkYear", otkYear)
                .append("waybillAmount", waybillAmount)
                .append("claimWeight", claimWeight)
                .append("claimAmount", claimAmount)
                .append("claimPieces", claimPieces)
                .append("dateOut", dateOut)
                .append("deliveryTermsCode", deliveryTermsCode)
                .append("percentNDS", percentNDS)
                .append("waybillStr", waybillStr)
                .append("wtDate", wtDate)
                .append("isArc", isArc)
                .toString();
    }

}