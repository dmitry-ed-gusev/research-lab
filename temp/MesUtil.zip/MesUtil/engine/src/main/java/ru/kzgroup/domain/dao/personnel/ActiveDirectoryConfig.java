package ru.kzgroup.domain.dao.personnel;

import org.apache.commons.lang3.StringUtils;
import ru.kzgroup.exceptions.MesException;

/**
 * Configuration for Active Directory DAO module.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 11.10.13)
*/

public final class ActiveDirectoryConfig {

    private String address;  // address of AD server host:port
    private String username; // user
    private String password; // password

    /***/
    public ActiveDirectoryConfig(String address, String username, String password) throws MesException {
        if (StringUtils.isBlank(address) || StringUtils.isBlank(username) || StringUtils.isBlank(password)) {
            throw new MesException(String.format("Can't create ActiveDirectoryConfig object! Empty parameter(s) " +
                    "in config [address=%s, user=%s, pass=%s]!", address, username, password));
        }
        this.address  = StringUtils.trimToEmpty(address);
        this.username = StringUtils.trimToEmpty(username);
        this.password = StringUtils.trimToEmpty(password);
    }

    public String getAddress() {
        return address;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

}