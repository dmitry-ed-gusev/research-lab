package ru.kzgroup.domain.dto.orders.ora;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for ORDER EXTRA ITEM (extra data in MES (Oracle)). Oracle -> TB_SM_ORD_EXTRA_ITEM.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 08.07.2014)
*/

public class OrderExtraItemDtoIdORA implements Serializable {

    private static final long serialVersionUID = 1L;

    private String orderYearMonth;
    private String orderNumber;
    private int    orderPosition;
    private int    itemCode;

    /** Default constructor */
    public OrderExtraItemDtoIdORA() {}

    /***/
    public OrderExtraItemDtoIdORA(String orderYearMonth, String orderNumber, int orderPosition, int itemCode) {
        this.orderYearMonth = orderYearMonth;
        this.orderNumber = orderNumber;
        this.orderPosition = orderPosition;
        this.itemCode = itemCode;
    }

    public String getOrderYearMonth() {
        return orderYearMonth;
    }

    public void setOrderYearMonth(String orderYearMonth) {
        this.orderYearMonth = orderYearMonth;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public int getOrderPosition() {
        return orderPosition;
    }

    public void setOrderPosition(int orderPosition) {
        this.orderPosition = orderPosition;
    }

    public int getItemCode() {
        return itemCode;
    }

    public void setItemCode(int itemCode) {
        this.itemCode = itemCode;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement", "QuestionableName"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        OrderExtraItemDtoIdORA that = (OrderExtraItemDtoIdORA) obj;

        if (itemCode != that.itemCode) return false;
        if (orderPosition != that.orderPosition) return false;
        if (!orderNumber.equals(that.orderNumber)) return false;
        if (!orderYearMonth.equals(that.orderYearMonth)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = orderYearMonth.hashCode();
        result = 31 * result + orderNumber.hashCode();
        result = 31 * result + orderPosition;
        result = 31 * result + itemCode;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("orderYearMonth", orderYearMonth)
                .append("orderNumber", orderNumber)
                .append("orderPosition", orderPosition)
                .append("itemCode", itemCode)
                .toString();
    }

}