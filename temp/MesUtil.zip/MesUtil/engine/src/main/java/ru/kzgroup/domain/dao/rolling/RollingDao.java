package ru.kzgroup.domain.dao.rolling;

import gusev.dmitry.jtils.utils.CommonUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import ru.kzgroup.domain.dto.rolling.RollingCard;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static ru.kzgroup.MesUtilDefaults.*;

/**
 * DAO component for Rolling work cards (both MES/ARMs). This component is Spring-oriented - it uses JdbcTemplates for
 * interacting with both databases - MES/ARM.
 *
 * Important! Component is immutable.
 * @author Gusev Dmitry (GusevD)
 * @version 1.0 (DATE: 18.07.13)
*/

// todo: sticky concrete instance to data type (RAM/MES) -> put data type into constructor???

public final class RollingDao {

    private static Log log = LogFactory.getLog(RollingDao.class);  // log for static/non-static members

    // todo: maybe use [to_date('20130801', 'yyyyMMdd')] for MES queries?
    private static final String           MES_WORK_CARDS_SQL =
            "select pon as ponNumber, count(pon) as ponPositionsCount, mill_gp as millGroup, mill_date as millDate," +
                    " prod_yy as productionYear, sum(nvl(input_wt, 0)) as inputWeight," +
                    " sum(case when length(rtrim(ltrim(nvl(PON, '')))) = 5 then nvl(prod_wt, 0) end) as outputPureGradeWeight," +
                    " sum(case when length(rtrim(ltrim(nvl(PON, '')))) = 4 then nvl(prod_wt, 0) end) as outputBlankWeight" +
                    " from tb_po_mill_pon_result " +
                    " where mill_date >= '%1$s' and mill_date <= '%2$s'" +
                    " group by pon, mill_date, prod_yy, mill_gp" +
                    " order by ponNumber";
    private static final String           ARM_WORK_CARDS_SQL =
            "select \"Раб.карта\" as ponNumber, count(WorkTicketStringNo) as ponPositionsCount, Стан as millGroup," +
                    " \"Дата_пр.\" as millDate, ГодРК as productionYear, sum(nvl(\"Вес_заг.\", 0)) as inputWeight," +
                    " sum(nvl(\"Прокат_вес_ч/с\", 0)) as outputPureGradeWeight," +
                    " sum(nvl(\"Прокат_вес_кв.заг.\", 0)) as outputBlankWeight" +
                    " from f110 where millDate >= '%1$s' and millDate <= '%2$s'" +
                    " group by ponNumber, millDate, productionYear, millGroup" +
                    " order by ponNumber, millDate";

    private JdbcTemplate pdxTemplate; // JdbcTemplate for Paradox DB
    private JdbcTemplate oraTemplate; // JdbcTemplate for MES DB

    /***/
    public RollingDao(DataSource pdxDataSource, DataSource oraDataSource) {
        this.pdxTemplate = new JdbcTemplate(pdxDataSource);
        this.oraTemplate = new JdbcTemplate(oraDataSource);
    }

    /** Implementation detail. Springs RowMapper - creating objects from rows of ResultSet. */
    private static final class RollingCardMapper implements RowMapper<RollingCard> {

        private DATATYPE         dataType;
        private SimpleDateFormat dateFormat;

        private RollingCardMapper(DATATYPE dataType) {
            this.dataType = dataType;
            switch (this.dataType) {
                case MES: this.dateFormat = MES_MILL_DATE_FORMAT; break;
                case ARM: this.dateFormat = ARM_MILL_DATE_FORMAT; break;
                default:  this.dateFormat = null; log.error("Invalid DATATYPE [" + dataType + "]!");
            }
        }

        public RollingCard mapRow(ResultSet rs, int rowNum) throws SQLException {
            // mill date -> conversion to Date value
            Date millDate;
            try {
                millDate = (this.dateFormat == null ? null : this.dateFormat.parse(rs.getString("millDate")));
            } catch (ParseException e) {
                millDate = null;
                log.error(e);
            }
            // create work card object and return it
            return new RollingCard.Builder()
                    .cardType(dataType)
                    .ponNumber(String.valueOf(rs.getInt("ponNumber"))).ponPositionsCount(rs.getInt("ponPositionsCount"))
                    .millGroup(MILL_GROUP.getMillGroup(rs.getString("millGroup"))).millDate(millDate)
                    .productionYear(rs.getString("productionYear")).inputWeight(rs.getInt("inputWeight"))
                    .outputPureGradeWeight(rs.getInt("outputPureGradeWeight"))
                    .outputBlankWeight(rs.getInt("outputBlankWeight"))
                    .build();
        }
    }

    /***/
    @SuppressWarnings("JDBCResourceOpenedButNotSafelyClosed")
    public List<RollingCard> getWorkCards(Date date, int deltaDays, DATATYPE type) {
        log.debug("RollingDao.getWorkCardsList() working.");
        List<RollingCard> workCards;

        if (date != null && type != null) {
            Pair<Date, Date> dateRange = CommonUtils.getDateRange(date, deltaDays); // date range

            // select parameters for query according to DATATYPE
            SimpleDateFormat dateFormat;
            String           sqlTemplate;
            JdbcTemplate     jdbcTemplate;
            switch (type) {
                case MES:
                    dateFormat   = MES_MILL_DATE_FORMAT;
                    sqlTemplate  = MES_WORK_CARDS_SQL;
                    jdbcTemplate = this.oraTemplate;
                    break;
                case ARM:
                    dateFormat   = ARM_MILL_DATE_FORMAT;
                    sqlTemplate  = ARM_WORK_CARDS_SQL;
                    jdbcTemplate = this.pdxTemplate;
                    break;
                default: // something wrong!!!
                    dateFormat   = null;
                    sqlTemplate  = null;
                    jdbcTemplate = null;
            }

            // todo: "bulletproof code" - do we need it?
            if (dateFormat != null && sqlTemplate != null && jdbcTemplate != null) { // all variables have proper values
                // formatting dates from dates range
                String startDate = dateFormat.format(dateRange.getLeft());
                String endDate   = dateFormat.format(dateRange.getRight());
                // format sql query
                String sql = String.format(sqlTemplate, startDate, endDate);
                log.debug("Sql query -> [" + sql + "]"); // for debug only!
                // executing sql query
                workCards = jdbcTemplate.query(sql, new RollingCardMapper(type));
            } else { // one/many of variables has wrong value(s)
                workCards = Collections.emptyList();
            }

        } else { // if something wrong with input data we will return empty collection
            workCards = Collections.emptyList();
        }
        // return result
        return workCards;
    }

    /***/
    public static void main(String[] args) throws SQLException, ParseException {
        Log log = LogFactory.getLog(RollingDao.class);
        PropertyConfigurator.configure("log4j.properties");

        log.info("RollingDao starting.");

        //OraDbConfig oracleDbConfig  = new OraDbConfig("172.16.0.81:1521", "PMES", "pmes", "pmes1234");
        //String      f110Path        = "//pst-fs/asu/USERS/new/spz/DATA";

        //RollingDao rDao = new RollingDao(/*oracleDbConfig, f110Path*/);
        //List<RollingCard> mesCards = rDao.getWorkCards(MES_MILL_SDF.parse("20130828"), 0, DATATYPE.MES);
        //log.debug("MES data received.");
        //List<RollingCard> armCards = rDao.getWorkCards(MES_MILL_SDF.parse("20130828"), 0, DATATYPE.ARM);
        //log.debug("ARM data received.");

        //int maxLength = Math.max(mesCards.size(), armCards.size());
        //log.info(String.format("MES list size = [%s], ARM list size = [%s].", mesCards.size(), armCards.size()));

        // generating differences report
        //StringBuilder report = new StringBuilder();
        //report.append("Differences report: \n")
        //        .append(String.format("Cards: [%s] MES cards, [%s] ARM cards.\n", mesCards.size(), armCards.size()));

    }

}