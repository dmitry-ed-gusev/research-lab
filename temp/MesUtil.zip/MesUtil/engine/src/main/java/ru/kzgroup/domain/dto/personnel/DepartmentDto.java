package ru.kzgroup.domain.dto.personnel;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * Class represents one department of plant - domain object.
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 12.10.13)
*/

public final class DepartmentDto extends BaseDto {

    private int    id;       // department id (unique, not null)
    private String deptCode; // department inner code (not null)
    private String deptName; // department name
    private String alive;    // is this department alive or not (Y/N)

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getAlive() {
        return alive;
    }

    public void setAlive(String alive) {
        this.alive = alive;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("deptCode", deptCode)
                .append("deptName", deptName)
                .append("alive", alive)
                .toString();
    }

}