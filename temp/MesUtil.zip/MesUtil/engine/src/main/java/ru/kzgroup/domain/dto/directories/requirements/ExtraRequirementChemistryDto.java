package ru.kzgroup.domain.dto.directories.requirements;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

import java.math.BigDecimal;

/**
 * EXTRA REQUIREMENT BY CHEMISTRY - selection (manual) from all extra requirements by chemistry.
 * Paradox table M11601, Oracle table TB_DICT_EXTRA_REQS_CHEMISTRY.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 30.06.2014)
*/

public class ExtraRequirementChemistryDto extends BaseDto {

    private ExtraRequirementChemistryDtoId id;
    private BigDecimal                     minValue;
    private BigDecimal                     maxValue;

    public ExtraRequirementChemistryDtoId getId() {
        return id;
    }

    public void setId(ExtraRequirementChemistryDtoId id) {
        this.id = id;
    }

    public BigDecimal getMinValue() {
        return minValue;
    }

    public void setMinValue(BigDecimal minValue) {
        this.minValue = minValue;
    }

    public BigDecimal getMaxValue() {
        return maxValue;
    }

    public void setMaxValue(BigDecimal maxValue) {
        this.maxValue = maxValue;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("minValue", minValue)
                .append("maxValue", maxValue)
                .toString();
    }

}