package ru.kzgroup.domain.dto.rawTables.f110;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.Date;

/**
 * Composite primary key for table f110. No one of fields can be null (empty), otherwise -
  * result is unknown (NPE or data inconsistency).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 10.05.2014)
*/

public class F110Id implements Serializable {

    private static final long serialVersionUID = 1L;

    private int  year;             // "ГодРК"->"SMALLINT"
    private int  workCardNumber;   // "Раб.карта"->"DOUBLE"
    private int  workCardPosition; // "WorkTicketStringNo"->"SMALLINT"
    private Date rollingDate;      // "Дата_пр."->"DATE"
    private int  shift;            // "Смена"->"SMALLINT"

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getWorkCardNumber() {
        return workCardNumber;
    }

    public void setWorkCardNumber(int workCardNumber) {
        this.workCardNumber = workCardNumber;
    }

    public int getWorkCardPosition() {
        return workCardPosition;
    }

    public void setWorkCardPosition(int workCardPosition) {
        this.workCardPosition = workCardPosition;
    }

    public Date getRollingDate() {
        return rollingDate;
    }

    public void setRollingDate(Date rollingDate) {
        this.rollingDate = rollingDate;
    }

    public int getShift() {
        return shift;
    }

    public void setShift(int shift) {
        this.shift = shift;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        F110Id f110Id = (F110Id) obj;

        if (shift != f110Id.shift) return false;
        if (workCardNumber != f110Id.workCardNumber) return false;
        if (workCardPosition != f110Id.workCardPosition) return false;
        if (year != f110Id.year) return false;
        if (!rollingDate.equals(f110Id.rollingDate)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = year;
        result = 31 * result + workCardNumber;
        result = 31 * result + workCardPosition;
        result = 31 * result + rollingDate.hashCode();
        result = 31 * result + shift;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("year", year)
                .append("workCardNumber", workCardNumber)
                .append("workCardPosition", workCardPosition)
                .append("rollingDate", rollingDate)
                .append("shift", shift)
                .toString();
    }

}