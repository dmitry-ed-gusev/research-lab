package ru.kzgroup.mesUtil.engine;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.exceptions.MesException;
import ru.kzgroup.mesUtil.engine.db.MesDbAnalizer;
import ru.kzgroup.mesUtil.engine.fsp.FspSqlAnalizer;
import ru.kzgroup.mesUtil.engine.xui.XUIAnalizer;

import java.io.File;

/**
 * Analizer engine for whole MES project.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 06.05.13)
*/

public class MesAnalizer {

    // module logger
    private Log log = LogFactory.getLog(MesAnalizer.class);

    // root folder for MES system source code
    private String         mesRootFolder;
    // MES db analizer
    private MesDbAnalizer  dbAnalizer;
    // MES - FSP server analizer
    private FspSqlAnalizer fspSqlAnalizer;
    // MES - XPlatform UI (XUI) analizer
    private XUIAnalizer    xuiAnalizer;

    /***/
    public MesAnalizer(String mesRootFolder) throws MesException {
        log.debug("MesAnalizer constructor() working.");
        if (!StringUtils.isBlank(mesRootFolder) && new File(mesRootFolder).exists() &&
                new File(mesRootFolder).isFile()) {
            log.debug("MES root folder [" + mesRootFolder + "] is OK. Processing.");
            this.mesRootFolder = mesRootFolder;
        } else {
            throw new MesException("Invalid MES root folder [" + mesRootFolder + "]! ");
        }
    }

    public void analize() {
        log.debug("MesAnalizer.analize() working.");
    }

    /** Method main for rough testing. */
    public static void main(String[] args) {
        Log log = LogFactory.getLog(MesAnalizer.class);
        log.info("Starting MesAnalizer.");
        MesAnalizer analizer = null;
        try {
            analizer = new MesAnalizer("c:/temp/pmes");
            analizer.analize();
        } catch (MesException e) {
            log.error(e.getMessage());
        }
    }

}
