package ru.kzgroup.db.tables;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * Config for database tables. It reads data about tables (name, fields list, key fields count, path to table - for
 * Paradox tables, description) from .properties config file. And this module reads link information between two tables
 * from config file too. Module used for directories migration Paradox (ARMs) -> Oracle (MES), but can be used for
 * other purpose.
 *
 * 14.08.2013
 * Links are stored in map, where key is source table name (usually Paradox) and value is a
 * destination table name (usually Oracle - MES DB).
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 09.07.13)
*/

// todo: key for key fields count
// todo: move constants to separate class (class with constants!)???

public final class TablesConfig {

    private Log log = LogFactory.getLog(TablesConfig.class);

    // max tables count for reading from .properties file
    // todo: BUG! tables links numbers ant tables numbers. Check after read config or check in process of reading???
    private final static int    MAX_TABLES_COUNT           = 1000;

    // fields value string split symbol
    private final static String FIELDS_VALUES_SPLIT_SYMBOL = ",";
    // symbol for splitting tables links values
    private final static String LINK_VALUES_SPLIT_SYMBOL   = "->";
    // one table keys for .properties file
    private final static String KEY_TABLE_NAME             = "table%d.name";
    private final static String KEY_TABLE_PATH             = "table%d.path";
    private final static String KEY_TABLE_FIELDS           = "table%d.fields";
    //private final static String KEY_TABLE_KEY_FIELDS       = "table%d.key.fields";
    private final static String KEY_TABLE_DESC             = "table%d.desc";
    // one tables link key for .properties file
    private final static String KEY_TABLES_LINK            = "tables.link%d";

    // internal object state
    private Map<String, TableObject> tables;     // map name-table of all tables
    private Map<String, String>      links;      // map of all links between tables
    //private String                   configFile; // config .properties file

    /***/
    public TablesConfig(String configFile) throws IOException {
        // check config file
        if (StringUtils.isBlank(configFile) || !new File(configFile).exists() || !new File(configFile).isFile()) {
            throw new IllegalArgumentException("Invalid tables config file [" + configFile + "]!");
        }
        // init internal state
        //this.configFile = configFile;
        //this.loadTables(this.configFile);
        this.loadTables(configFile);
    }

    /***/
    private static String[] splitTrim(String stringToSplit, String splitSymbol) {
        String[] result;
        // splitting string
        if (!StringUtils.isBlank(stringToSplit) && !StringUtils.isBlank(splitSymbol)) {
            List<String> tmpList = new ArrayList<String>();
            // process array and eliminate empty elements
            for (String element : stringToSplit.split(splitSymbol)) {
                if (!StringUtils.isBlank(element)) {
                    tmpList.add(StringUtils.trimToNull(element));
                }
            } // end of for
            result = tmpList.toArray(new String[tmpList.size()]);
        } else {
            result = new String[0]; // empty output array if input data is empty
        }
        // return string array
        return result;
    }

    /***/
    private static Pair<String, String> getTablesLink(String linkValueString) {
        Pair<String, String> link;
        String[] tmpArray = TablesConfig.splitTrim(linkValueString, LINK_VALUES_SPLIT_SYMBOL);
        // check data and create resulting pair
        if (tmpArray != null && tmpArray.length == 2) {
            link = new ImmutablePair<String, String>(tmpArray[0], tmpArray[1]);
        } else {
            link = null;
        }

        return link;
    }

    /***/
    private void loadTables(String configFile) throws IOException {
        log.debug("TablesConfig.loadTables() working.");

        // init fields
        this.tables = new HashMap<String, TableObject>();
        // we use HashMap because one table can be mapped to many others - more, than one
        this.links  = new HashMap<String, String>();

        // loading config from .properties file
        Properties props = new Properties();
        FileReader reader = null;
        try {
            reader = new FileReader(configFile);
            //InputStreamReader in = new InputStreamReader(this.getClass().getClassLoader().getResourceAsStream(configFile), "UTF-8");
            //props.load(in);
            props.load(reader);
            log.debug("Properties has been loaded from file [" + configFile + "].");

            // loading tables from Properties config
            for (int i = 1; i <= MAX_TABLES_COUNT; i++) {

                // read one table data
                String   tableName           = StringUtils.trimToEmpty(props.getProperty(String.format(KEY_TABLE_NAME, i), null));
                String   tablePath           = StringUtils.trimToEmpty(props.getProperty(String.format(KEY_TABLE_PATH, i), null));
                String[] tableFields         = TablesConfig.splitTrim(StringUtils.trimToEmpty(
                        props.getProperty(String.format(KEY_TABLE_FIELDS, i),null)), FIELDS_VALUES_SPLIT_SYMBOL);
                String   tableDesc           = StringUtils.trimToEmpty(props.getProperty(String.format(KEY_TABLE_DESC, i), null));

                /*
                int      tableKeyFieldsCount;
                try {
                    tableKeyFieldsCount = Integer.parseInt(props.getProperty(String.format(KEY_TABLE_KEY_FIELDS, i), "1"));
                } catch (NumberFormatException e) {
                    tableKeyFieldsCount = 1;
                    log.warn(e);
                }
                */

                // check mandatory fields and create table object
                if (!StringUtils.isBlank(tableName) && tableFields != null && tableFields.length > 0) {
                    log.debug(String.format("Table -> table=[%s], path=[%s], fields=[%s], desc=[%s].",
                            tableName, tablePath, Arrays.deepToString(tableFields), tableDesc));
                    // Creating table object
                    TableObject table = new TableObject(tableName, tablePath, tableFields, tableDesc);
                    // adding table object to list
                    this.tables.put(tableName, table);
                }

                // read link data
                Pair<String, String> link = TablesConfig.getTablesLink(props.getProperty(String.format(KEY_TABLES_LINK, i), null));
                // link is Ok if it isn't null
                if (link != null) {
                    log.debug("Link: " + link.getLeft() + "->" + link.getRight());
                    this.links.put(link.getLeft(), link.getRight());
                }

            } // end of for cycle



        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    log.error("Can't close tables descriptor FileReader! Reason: " + e.getMessage());
                }
            }
        }

    }

    /***/
    public TableObject getTableByName(String tableName) {
        TableObject table;
        if (!StringUtils.isBlank(tableName) && this.tables != null && !this.tables.isEmpty()) {
            table = this.tables.get(tableName);
        } else {
            table = null;
        }
        return table;
    }

    /***/
    public Map<String, String> getLinks() {
        // our object should be immutable - we use unmodifiable map for returning internal links map
        return Collections.unmodifiableMap(this.links);
    }

    /** Method just for test. */
    public static void main(String[] args) throws IOException {
        Log log = LogFactory.getLog(TablesConfig.class);
        PropertyConfigurator.configure("log4j.properties");

        log.info("Tables engine starting.");

        TablesConfig tablesConfig = new TablesConfig("tables.properties");
        log.info("Config loaded.");

        log.info(tablesConfig.getTableByName("M106"));
        log.info("-> " + tablesConfig.getLinks());
        //tEngine.loadTablesList();

    }

}