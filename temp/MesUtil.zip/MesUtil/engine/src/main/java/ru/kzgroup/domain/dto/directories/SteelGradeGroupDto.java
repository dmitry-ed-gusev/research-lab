package ru.kzgroup.domain.dto.directories;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

import java.math.BigDecimal;

/**
 * STEEL GRADE GROUP - domain object. Paradox table - F10004, MES - TB_QM_STL_GRADE_GRP.
 * @author Gusev Dmitry (gusevd)
 * @version 2.0 (DATE: 03.09.2014)
*/

public class SteelGradeGroupDto extends BaseDto {

    private String     code;
    private String     name;
    private BigDecimal factor350;
    private BigDecimal factor900;
    private BigDecimal factor;
    private Integer    salesGroupCode;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getFactor350() {
        return factor350;
    }

    public void setFactor350(BigDecimal factor350) {
        this.factor350 = factor350;
    }

    public BigDecimal getFactor900() {
        return factor900;
    }

    public void setFactor900(BigDecimal factor900) {
        this.factor900 = factor900;
    }

    public BigDecimal getFactor() {
        return factor;
    }

    public void setFactor(BigDecimal factor) {
        this.factor = factor;
    }

    public Integer getSalesGroupCode() {
        return salesGroupCode;
    }

    public void setSalesGroupCode(Integer salesGroupCode) {
        this.salesGroupCode = salesGroupCode;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("code", code)
                .append("name", name)
                .append("factor350", factor350)
                .append("factor900", factor900)
                .append("factor", factor)
                .append("salesGroupCode", salesGroupCode)
                .toString();
    }

}