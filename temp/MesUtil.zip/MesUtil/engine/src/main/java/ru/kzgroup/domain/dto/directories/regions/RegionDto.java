package ru.kzgroup.domain.dto.directories.regions;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * Domain object - one region.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 24.02.14)
*/

public class RegionDto extends BaseDto {

    private RegionDtoId id;           // composite PromaryKey object
    private String      name;         // name of region (RegionName in N0004006)
    private String      capitalName;  // capital of region
    private boolean     useInAddress; //
    private Integer     statusCode;   //

    public RegionDtoId getId() {
        return id;
    }

    public void setId(RegionDtoId id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCapitalName() {
        return capitalName;
    }

    public void setCapitalName(String capitalName) {
        this.capitalName = capitalName;
    }

    public boolean isUseInAddress() {
        return useInAddress;
    }

    public void setUseInAddress(boolean useInAddress) {
        this.useInAddress = useInAddress;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "ParameterNameDiffersFromOverriddenParameter", "RedundantIfStatement"})
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RegionDto)) return false;

        RegionDto regionDto = (RegionDto) o;

        if (useInAddress != regionDto.useInAddress) return false;
        if (capitalName != null ? !capitalName.equals(regionDto.capitalName) : regionDto.capitalName != null)
            return false;
        if (id != null ? !id.equals(regionDto.id) : regionDto.id != null) return false;
        if (name != null ? !name.equals(regionDto.name) : regionDto.name != null) return false;
        if (statusCode != null ? !statusCode.equals(regionDto.statusCode) : regionDto.statusCode != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (capitalName != null ? capitalName.hashCode() : 0);
        result = 31 * result + (useInAddress ? 1 : 0);
        result = 31 * result + (statusCode != null ? statusCode.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("name", name)
                .append("capitalName", capitalName)
                .append("useInAddress", useInAddress)
                .append("statusCode", statusCode)
                .toString();
    }

}