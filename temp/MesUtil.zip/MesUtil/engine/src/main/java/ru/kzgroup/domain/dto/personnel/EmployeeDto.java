package ru.kzgroup.domain.dto.personnel;

import gusev.dmitry.jtils.utils.CommonUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.lang3.tuple.Pair;
import ru.kzgroup.domain.dto.BaseDto;

import java.util.Date;

/**
 * Class represents one virtual employee (user).
 * First of all class is used for get data from exported personnel database (personnel database
 * every day is exported from system 'Босс-Кадровик' to MS Access file).
 *
 * Class is immutable.
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 05.10.13)
*/

public final class EmployeeDto extends BaseDto {

    private static final String EMPTY_SHOP_NUMBER = "-";

    // --- internal state - common fields
    private int    id;        // field WORKER_ID in Boss-Kadrovik exported database (table 'Работники')
    private String fullName;  // merged LAST_NAME+FIRST_NAME+PATRONYMIC fields (table 'Работники')
    private int    deptId;    // department identity code - field REG_DEPARTMENT_NO (table 'Работники')
    private String deptCode;  // depatment inner code (table 'Подразделения')
    private String deptName;  // deprartment name (table 'Подразделения')
    private Date   birthDate; // field BIRTH_DATE in Boss-Kadrovik exported database
    private String login;     // user login (Active Directory)
    private String email;     // user email (Active Directory)
    private String alive;     // is employee alive or fired (for current date/time) - Y/N
    // --- internal state - derivable (вычисляемые) fields
    private String shortRusName; // derived field (from fullName)
    private String shortEngName; // derived field (translit from shortRusName)
    private String number;       // 'табельный номер' - derived field - last four symbols of field CLOCK_NO (table 'Работники')
    // 'номер цеха' - derived field - first symbols except last four of field CLOCK_NO (table 'Работники')
    private String shopNumber = EMPTY_SHOP_NUMBER;

    /***/
    public EmployeeDto() {} // for Spring framework

    /***/
    public EmployeeDto(int id, String fullName, int deptId, String deptCode, String deptName, String number, Date birthDate,
                       String login, String email, boolean alive) {
        this.id = id; // employee id from personnel database
        // calculating full name and derived fields
        if (!StringUtils.isBlank(fullName)) {
            this.fullName  = fullName;
            Pair<String, String> shortRuEn = CommonUtils.getShortAndTranslit(this.fullName);
            this.shortRusName = shortRuEn.getLeft();
            this.shortEngName = shortRuEn.getRight();
        } else {
            this.fullName     = null;
            this.shortRusName = null;
            this.shortEngName = null;
        }
        // calculating shop number and clock number (табельный номер)
        if (!StringUtils.isBlank(number)) { // input parameter isn't empty
            String trimmedNumber = StringUtils.trimToEmpty(number);
            // last four symbols - clock number
            if (trimmedNumber.length() >= 4) { // length >= 4 - we will calculate clock no
                this.number = StringUtils.right(trimmedNumber, 4);
                // first symbols except last four -> shop number
                String tmpShopNumber = trimmedNumber.substring(0, trimmedNumber.length() - 4);
                this.shopNumber = (StringUtils.isBlank(tmpShopNumber) ? EMPTY_SHOP_NUMBER : tmpShopNumber);
            } else { // length < 4 - all symbols will be treaten as clock number, shop number is null
                this.number     = trimmedNumber;
                this.shopNumber = EMPTY_SHOP_NUMBER;/*null;*/
            }
        } else { // input parameter is empty
            this.number     = null;
            this.shopNumber = EMPTY_SHOP_NUMBER;/*null;*/
        }
        this.deptId    = deptId;   // department ID
        this.deptCode  = deptCode; // department code
        this.deptName  = deptName; // department name
        //this.birthDate = new Date(birthDate.getTime()); // birthday info (defensive copy)
        this.birthDate = birthDate;
        this.login     = login;    // user login info (Active Directory)
        this.email     = email;    // user email info (Active Directory)
        this.alive     = (alive ? "Y" : "N");    // user alive info
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public Date getBirthDate() {
        //return new Date(this.birthDate.getTime()); // defensive code, it creates and returns new Date object
        return this.birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getShortRusName() {
        return shortRusName;
    }

    public void setShortRusName(String shortRusName) {
        this.shortRusName = shortRusName;
    }

    public String getShortEngName() {
        return shortEngName;
    }

    public void setShortEngName(String shortEngName) {
        this.shortEngName = shortEngName;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getShopNumber() {
        return shopNumber;
    }

    public void setShopNumber(String shopNumber) {
        this.shopNumber = shopNumber;
    }

    public String getAlive() {
        return alive;
    }

    public void setAlive(String alive) {
        this.alive = alive;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("fullName", fullName)
                .append("deptId", deptId)
                .append("deptCode", deptCode)
                .append("deptName", deptName)
                .append("birthDate", birthDate)
                .append("login", login)
                .append("email", email)
                .append("alive", alive)
                .append("shortRusName", shortRusName)
                .append("shortEngName", shortEngName)
                .append("number", number)
                .append("shopNumber", shopNumber)
                .toString();
    }

}