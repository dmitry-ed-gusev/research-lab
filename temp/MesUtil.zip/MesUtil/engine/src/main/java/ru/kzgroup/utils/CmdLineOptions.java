package ru.kzgroup.utils;

/**
 * Command line options for applications: dataMiner, socketService, telegramService, etc.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 10.02.14)
*/

public enum CmdLineOptions {

    ORA_HOST("-oraHost"), TC_LIST("-tcList"), SERVICE_HOST("-serviceHost"), SERVICE_PORT("-servicePort"),
    IO1_TC_LIST("-tcListIO1"), IO2_TC_LIST("-tcListIO2"), IO3_TC_LIST("-tcListIO3");

    CmdLineOptions(String optionName) {
        this.optionName = optionName;
    }

    private String optionName;

    public String getOptionName() {
        return optionName;
    }

}