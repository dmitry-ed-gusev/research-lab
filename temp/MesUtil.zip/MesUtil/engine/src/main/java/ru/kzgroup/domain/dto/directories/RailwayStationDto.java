package ru.kzgroup.domain.dto.directories;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * Domain object - Railway Station.
 *
 * MES: TB_DICT_RAILWAY_STATIONS, ARM: M120 (f:/users/new/spz/nsi)
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 02.06.2014)
*/

public class RailwayStationDto extends BaseDto {

    private int     stationCode;
    private String  stationName;
    private int     railwayCode;
    private Integer distanceTo;

    public int getStationCode() {
        return stationCode;
    }

    public void setStationCode(int stationCode) {
        this.stationCode = stationCode;
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public int getRailwayCode() {
        return railwayCode;
    }

    public void setRailwayCode(int railwayCode) {
        this.railwayCode = railwayCode;
    }

    public Integer getDistanceTo() {
        return distanceTo;
    }

    public void setDistanceTo(Integer distanceTo) {
        this.distanceTo = distanceTo;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("stationCode", stationCode)
                .append("stationName", stationName)
                .append("railwayCode", railwayCode)
                .append("distanceTo", distanceTo)
                .toString();
    }

}