package ru.kzgroup.domain.dto.directories;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * COUNTRY - domain object. Paradox table F96124 (//pst-fs/users/new/omis/nsi/exp)
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 18.02.14)
*/

public class CountryDto extends BaseDto {

    private int     code;             // primary key
    private String  name;             //
    private String  nameEnglish;      //
    private String  nameTwoLetter;    //
    private Integer customsUnionSign; // признак таможенного союза
    private String  useSign;          // use this object or no Y/N

    /** Default constructor. Used by Hibernate. */
    public CountryDto() {}

    /** Copying constructor. */
    public CountryDto(CountryDto country) {
        if (country != null) {
            this.code             = country.getCode();
            this.name             = country.getName();
            this.nameEnglish      = country.getNameEnglish();
            this.nameTwoLetter    = country.getNameTwoLetter();
            this.customsUnionSign = country.getCustomsUnionSign();
            this.useSign          = country.getUseSign();
        } else {
            LogFactory.getLog(CountryDto.class).warn(String.format("Copy NULL object [%s]!", CountryDto.class));
            this.code             = 0;
            this.name             = null;
            this.nameEnglish      = null;
            this.nameTwoLetter    = null;
            this.customsUnionSign = null;
            this.useSign          = null;
        }
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameEnglish() {
        return nameEnglish;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public String getNameTwoLetter() {
        return nameTwoLetter;
    }

    public void setNameTwoLetter(String nameTwoLetter) {
        this.nameTwoLetter = nameTwoLetter;
    }

    public Integer getCustomsUnionSign() {
        return customsUnionSign;
    }

    public void setCustomsUnionSign(Integer customsUnionSign) {
        this.customsUnionSign = customsUnionSign;
    }

    public String getUseSign() {
        return useSign;
    }

    public void setUseSign(String useSign) {
        this.useSign = useSign;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("code", code)
                .append("name", name)
                .append("nameEnglish", nameEnglish)
                .append("nameTwoLetter", nameTwoLetter)
                .append("customsUnionSign", customsUnionSign)
                .append("useSign", useSign)
                .toString();
    }

}