package ru.kzgroup.exceptions;

/**
 * Special exception for MesUtil engine. For checked exceptions from this module.
 * @author Gusev Dmitry (Дмитрий)
 * @version 1.0 (DATE: 10.05.13)
*/

public class MesException extends Exception {

    public MesException(String message) {
        super(message);
    }

    public MesException(Throwable cause) {
        super(cause);
    }

}