package ru.kzgroup.domain.dto.rolling;

import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.Date;

import static ru.kzgroup.MesUtilDefaults.*;

/**
 * Work card object for rolling (рабочая карта проката). Used with both databases - ARM's database
 * (Paradox) and MES database (Oracle).
 *
 * Important! Class is immutable.
 *
 * @author Gusev Dmitry (GusevD)
 * @version 1.0 (DATE: 19.07.13)
*/

public class RollingCard {

    private DATATYPE   cardType;              // work card type -> ARM/MES
    private String     ponNumber;             // (key) work card number
    private int        ponPositionsCount;     // work card positions number
    private MILL_GROUP millGroup;             // (key) mill group -> 900/350
    private Date       millDate;              // (key) mill date
    private String     productionYear;        // (key) year of production
    private int        inputWeight;           // weight of input steel
    private int        outputPureGradeWeight; // weight of output pure grade steel
    private int        outputBlankWeight;     // weight of output blank steel (заготовка)

    /** Builder class for this object. */
    public static class Builder {
        private DATATYPE   cardType              = DATATYPE.UNKNOWN;
        private String     ponNumber             = null;
        private int        ponPositionsCount     = 0;
        private MILL_GROUP millGroup             = MILL_GROUP.UNKNOWN;
        private Date       millDate              = null;
        private String     productionYear        = null;
        private int        inputWeight           = 0;
        private int        outputPureGradeWeight = 0;
        private int        outputBlankWeight     = 0;

        public Builder cardType(DATATYPE value) {
            if (value != null) {
                this.cardType = value;
            } else {
                this.cardType = DATATYPE.UNKNOWN;
            }
            return this;
        }

        public Builder ponNumber(String value) {
            this.ponNumber = value;
            return this;
        }

        public Builder ponPositionsCount(int value) {
            this.ponPositionsCount = value;
            return this;
        }

        public Builder millGroup(MILL_GROUP value) {
            if (value != null) {
                this.millGroup = value;
            } else {
                this.millGroup = MILL_GROUP.UNKNOWN;
            }
            return this;
        }

        public Builder millDate(Date value) {
            this.millDate = value;
            return this;
        }

        public Builder productionYear(String value) {
            this.productionYear = value;
            return this;
        }

        public Builder inputWeight(int value) {
            this.inputWeight = value;
            return this;
        }

        public Builder outputPureGradeWeight(int value) {
            this.outputPureGradeWeight = value;
            return this;
        }

        public Builder outputBlankWeight(int value) {
            this.outputBlankWeight = value;
            return this;
        }

        public RollingCard build() {
            return new RollingCard(this);
        }

    }

    /** Private constructor - only inner class Builder cam create IMMUTABLE instance of this class (RollingCard). */
    private RollingCard(Builder builder) {
        this.cardType              = builder.cardType;
        this.ponNumber             = builder.ponNumber;
        this.ponPositionsCount     = builder.ponPositionsCount;
        this.millGroup             = builder.millGroup;
        this.millDate              = builder.millDate;
        this.productionYear        = builder.productionYear;
        this.inputWeight           = builder.inputWeight;
        this.outputPureGradeWeight = builder.outputPureGradeWeight;
        this.outputBlankWeight     = builder.outputBlankWeight;
    }

    public DATATYPE getCardType() {
        return cardType;
    }

    public String getPonNumber() {
        return ponNumber;
    }

    public int getPonPositionsCount() {
        return ponPositionsCount;
    }

    public MILL_GROUP getMillGroup() {
        return millGroup;
    }

    public Date getMillDate() {
        return (this.millDate == null ? null : new Date(this.millDate.getTime()));
    }

    public String getProductionYear() {
        return productionYear;
    }

    public int getInputWeight() {
        return inputWeight;
    }

    public int getOutputPureGradeWeight() {
        return outputPureGradeWeight;
    }

    public int getOutputBlankWeight() {
        return outputBlankWeight;
    }

    /**
     * We don't include field cardType in equals method!
    */
    @Override
    @SuppressWarnings("RedundantIfStatement")
    public boolean equals(Object obj) {

        boolean result; // = false;

        if (this == obj) {     // same object check
            result = true;
        } else if (obj == null || getClass() != obj.getClass()) { // check for null-value and class type
            result = false;
        } else {

            // foreign object is object of same class - converting to our class and check fields
            RollingCard foreign = (RollingCard) obj;
            // check objects field-by-field
            if (inputWeight != foreign.inputWeight) {
                result = false;
            } else if (outputBlankWeight != foreign.outputBlankWeight) {
                result = false;
            } else if (outputPureGradeWeight != foreign.outputPureGradeWeight) {
                result = false;
            } else if (ponPositionsCount != foreign.ponPositionsCount) {
                result = false;
            } else if (millDate != null ? !millDate.equals(foreign.millDate) : foreign.millDate != null) {
                result = false;
            } else if (millGroup != foreign.millGroup) {
                result = false;
            } else if (ponNumber != null ? !ponNumber.equals(foreign.ponNumber) : foreign.ponNumber != null) {
                result = false;
            } else if (productionYear != null ? !productionYear.equals(foreign.productionYear) : foreign.productionYear != null) {
                result = false;
            } else {
                result = true;
            }
        }

        return result;
    }

    @Override
    public int hashCode() {
        int result = ponNumber != null ? ponNumber.hashCode() : 0;
        result = 31 * result + ponPositionsCount;
        result = 31 * result + (millGroup != null ? millGroup.hashCode() : 0);
        result = 31 * result + (millDate != null ? millDate.hashCode() : 0);
        result = 31 * result + (productionYear != null ? productionYear.hashCode() : 0);
        result = 31 * result + inputWeight;
        result = 31 * result + outputPureGradeWeight;
        result = 31 * result + outputBlankWeight;
        return result;
    }

    /**
     * Are two cards equals by key: [ponNumber, millGroup, millDate, productionYear] or not. This method is used for
     * identifying equality of two cards from MES and ARM when weights on cards are different.
     * Method is copletly different from classic .equals() method!
     * @param foreignCard RollingCard work card for equality test.
    */
    @SuppressWarnings("RedundantIfStatement")
    public boolean equalsByKey(RollingCard foreignCard) {
        boolean result;

        // check two cards keys field-by-field
        if (millDate != null ? !millDate.equals(foreignCard.millDate) : foreignCard.millDate != null) {
            result = false;
        } else if (millGroup != foreignCard.millGroup) {
            result = false;
        } else if (ponNumber != null ? !ponNumber.equals(foreignCard.ponNumber) : foreignCard.ponNumber != null) {
            result = false;
        } else if (productionYear != null ? !productionYear.equals(foreignCard.productionYear) : foreignCard.productionYear != null) {
            result = false;
        } else {
            result = true;
        }

        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("cardType", cardType)
                .append("ponNumber", ponNumber)
                .append("ponPositionsCount", ponPositionsCount)
                .append("millGroup", millGroup)
                .append("millDate", millDate)
                .append("productionYear", productionYear)
                .append("inputWeight", inputWeight)
                .append("outputPureGradeWeight", outputPureGradeWeight)
                .append("outputBlankWeight", outputBlankWeight)
                .toString();
    }

}