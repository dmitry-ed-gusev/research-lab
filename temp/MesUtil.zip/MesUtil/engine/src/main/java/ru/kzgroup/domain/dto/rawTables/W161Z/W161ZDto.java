package ru.kzgroup.domain.dto.rawTables.W161Z;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

import java.math.BigDecimal;

/**
 * Raw ARM table - W161Z.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 13.08.2014)
*/

public class W161ZDto extends BaseDto {

    private W161ZDtoId id;
    private int        year;
    private String     orderNumber;
    private int        period;
    private int        position;
    private int        groupMRT;
    private BigDecimal accountFactor;
    private BigDecimal weight;
    private BigDecimal amountFrachtbrief;
    private BigDecimal price;
    private BigDecimal costPriceExtraCosts1;
    private BigDecimal costPriceRepairEquipment;
    private BigDecimal costPriceFactoryExpenses;

    public W161ZDtoId getId() {
        return id;
    }

    public void setId(W161ZDtoId id) {
        this.id = id;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public int getPeriod() {
        return period;
    }

    public void setPeriod(int period) {
        this.period = period;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public int getGroupMRT() {
        return groupMRT;
    }

    public void setGroupMRT(int groupMRT) {
        this.groupMRT = groupMRT;
    }

    public BigDecimal getAccountFactor() {
        return accountFactor;
    }

    public void setAccountFactor(BigDecimal accountFactor) {
        this.accountFactor = accountFactor;
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    public BigDecimal getAmountFrachtbrief() {
        return amountFrachtbrief;
    }

    public void setAmountFrachtbrief(BigDecimal amountFrachtbrief) {
        this.amountFrachtbrief = amountFrachtbrief;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getCostPriceExtraCosts1() {
        return costPriceExtraCosts1;
    }

    public void setCostPriceExtraCosts1(BigDecimal costPriceExtraCosts1) {
        this.costPriceExtraCosts1 = costPriceExtraCosts1;
    }

    public BigDecimal getCostPriceRepairEquipment() {
        return costPriceRepairEquipment;
    }

    public void setCostPriceRepairEquipment(BigDecimal costPriceRepairEquipment) {
        this.costPriceRepairEquipment = costPriceRepairEquipment;
    }

    public BigDecimal getCostPriceFactoryExpenses() {
        return costPriceFactoryExpenses;
    }

    public void setCostPriceFactoryExpenses(BigDecimal costPriceFactoryExpenses) {
        this.costPriceFactoryExpenses = costPriceFactoryExpenses;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("year", year)
                .append("orderNumber", orderNumber)
                .append("period", period)
                .append("position", position)
                .append("groupMRT", groupMRT)
                .append("accountFactor", accountFactor)
                .append("weight", weight)
                .append("amountFrachtbrief", amountFrachtbrief)
                .append("price", price)
                .append("costPriceExtraCosts1", costPriceExtraCosts1)
                .append("costPriceRepairEquipment", costPriceRepairEquipment)
                .append("costPriceFactoryExpenses", costPriceFactoryExpenses)
                .toString();
    }

}