package ru.kzgroup.domain.dto.scrap;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * ONE FURNACE CHARGE - domain object (одна металлозавалка). Abstract class - base class for domian object and
 * audit object for this entity.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 04.08.2014)
*/

// todo: merge in one class with FurnaceChargeDto
public abstract class AbstractFurnaceChargeDto extends BaseDto {

    private String     shift;               //
    private Integer    clockNumber;         // nullable (ARM)
    private BigDecimal weight;              //
    private int        steelGradeGroupCode; //
    private int        akos;                //
    private Date       meltDate;            //

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    public Integer getClockNumber() {
        return clockNumber;
    }

    public void setClockNumber(Integer clockNumber) {
        this.clockNumber = clockNumber;
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    public int getSteelGradeGroupCode() {
        return steelGradeGroupCode;
    }

    public void setSteelGradeGroupCode(int steelGradeGroupCode) {
        this.steelGradeGroupCode = steelGradeGroupCode;
    }

    public int getAkos() {
        return akos;
    }

    public void setAkos(int akos) {
        this.akos = akos;
    }

    public Date getMeltDate() {
        return meltDate;
    }

    public void setMeltDate(Date meltDate) {
        this.meltDate = meltDate;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        // if (o == null || getClass() != o.getClass()) return false; // <- (getClass - don't accept subclasses, instanceof - accept)
        if (!(o instanceof AbstractFurnaceChargeDto)) return false; // <- (getClass - don't accept subclasses, instanceof - accept)

        AbstractFurnaceChargeDto that = (AbstractFurnaceChargeDto) o;

        if (akos != that.akos) return false;
        if (steelGradeGroupCode != that.steelGradeGroupCode) return false;
        if (clockNumber != null ? !clockNumber.equals(that.clockNumber) : that.clockNumber != null) return false;
        if (!meltDate.equals(that.meltDate)) return false;
        if (shift != null ? !shift.equals(that.shift) : that.shift != null) return false;

        if (!weight.equals(that.weight)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = shift != null ? shift.hashCode() : 0;
        result = 31 * result + (clockNumber != null ? clockNumber.hashCode() : 0);
        result = 31 * result + weight.hashCode();
        result = 31 * result + steelGradeGroupCode;
        result = 31 * result + akos;
        result = 31 * result + meltDate.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .appendSuper(super.toString())
                .append("shift", shift)
                .append("clockNumber", clockNumber)
                .append("weight", weight)
                .append("steelGradeGroupCode", steelGradeGroupCode)
                .append("akos", akos)
                .append("meltDate", meltDate)
                .toString();
    }

}