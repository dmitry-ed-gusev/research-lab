package ru.kzgroup.mesUtil.engine.fsp;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import static ru.kzgroup.MesUtilDefaults.DBOBJECT_TYPE;

/**
 * Model for one FSP named sql query.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 07.05.13)
*/

public class FspSqlModel {

    /** Sql query type enumeration. */
    //public static enum QueryType {INSERT, UPDATE, DELETE, SELECT, UNKNOWN}

    // module logger
    private Log log = LogFactory.getLog(FspSqlModel.class);

    // XPath value for
    //private static final String XPATH_MODEL_STATEMENT = "//query/statement/text()";

    private String    sqlModelName;   // modele name
    private String    sqlModelPath;   // model file path
    //private QueryType queryType      = null;      // model query type
    //private String    warningMessage = null; // if there are possible warnings in model - put them here
    //private String[]  assignedTables = null;
    //private String[]  assignedSPs    = null;

    // DB objects (tables, sp's, functions, that are related to this named sql object.
    // This instance variable should never take null value.
    private Map<String, DBOBJECT_TYPE> dbObjects = new TreeMap<String, DBOBJECT_TYPE>();

    public FspSqlModel(String sqlModelName, String sqlModelPath, Map<String, DBOBJECT_TYPE> dbObjects) {
        this.sqlModelName = sqlModelName;
        this.sqlModelPath = sqlModelPath;
        this.buildModel(dbObjects);
    }

    /**
     * Recursive processing nodes list and extracting all values into one StringBuilder object.
     * I don't use logging here, because method is recursive (too many log messages - it will slow down module).
     * @param nodeList NodeList list of nodes for processing.
     * @return always returns a non-null StringBuilder object.
    */
    private StringBuilder processNodes(NodeList nodeList) {
        StringBuilder result = new StringBuilder();
        if (nodeList != null && nodeList.getLength() > 0) {
            for (int i = 0; i < nodeList.getLength(); i++) {
                if (nodeList.item(i).hasChildNodes()) {
                    result.append(processNodes(nodeList.item(i).getChildNodes()));
                } else {
                    String value = StringUtils.trimToNull(nodeList.item(i).getNodeValue());
                    if (value != null) {
                        result.append(value).append(" ");
                    }
                }
            }
        }
        return result;
    }

    /***/
    private void fillInDbObjects(String sql, Map<String, DBOBJECT_TYPE> dbObjects) {
        log.debug("FspSqlModel.fillInDbObjects() working (PRIVATE).");
        if (!StringUtils.isBlank(sql) && dbObjects != null && !dbObjects.isEmpty()) {
            log.debug("Sql string and db objects map is OK. Processing.");
            // processing
            String upperCaseSql = sql.toUpperCase();
            for (Map.Entry entry : dbObjects.entrySet()) {
                String dbObjectName = (String) entry.getKey();
                if (upperCaseSql.contains(dbObjectName.toUpperCase())) {
                    this.dbObjects.put(dbObjectName, (DBOBJECT_TYPE) entry.getValue());
                }
            } // end of for
        } else {
            log.error("Empty sql string or db oibjects map!");
        }
    }

    /***/
    private void buildModel(Map<String, DBOBJECT_TYPE> dbObjects) {
        File sqlModelFile = new File(sqlModelPath);
        if (sqlModelFile.exists() && sqlModelFile.isFile()) {
            // parsing xml and reading data
            try {
                // parse xml document
                DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
                //domFactory.setNamespaceAware(true);
                DocumentBuilder builder = domFactory.newDocumentBuilder();
                Document doc = builder.parse(sqlModelPath);
                XPath xpath = XPathFactory.newInstance().newXPath();
                // get value
                //String value = StringUtils.trimToNull(xpath.evaluate(XPATH_MODEL_STATEMENT, doc));

                //log.debug("statement value -> " + value);

                // get all nodes (NodeList object) from specified location
                NodeList nodeList = (NodeList) xpath.compile("//query/statement").evaluate(doc, XPathConstants.NODESET);
                // recursively process nodes list and extract all text info into one String object
                String value = processNodes(nodeList).toString();
                // fill list of related db objects
                this.fillInDbObjects(value, dbObjects);
                //System.out.println("****************\n" + value);

                /**
                for (int i = 0; i < nodeList.getLength(); i++) {
                    System.out.println("-> " + nodeList.item(i).getChildNodes().getLength());
                    NodeList childNodesList = nodeList.item(i).getChildNodes();
                    for (int j = 0; j < childNodesList.getLength(); j++) {
                        System.out.println("   -> " + childNodesList.item(j).getNodeValue());
                        System.out.println(childNodesList.item(j).hasChildNodes());
                    }
                }
                */
                /**
                if (value != null) { // there is a value

                    if (value.startsWith("SELECT")) {
                        this.queryType = QueryType.SELECT;

                        log.debug("[" + sqlModelName + "] --> start = " + (value.indexOf("FROM") + 4));
                        log.debug("[" + sqlModelName + "] --> end = " + (value.contains("WHERE") ? value.indexOf("WHERE") - 5 : value.length()));

                        this.assignedTables = value.substring(value.indexOf("FROM"),
                                (value.contains("WHERE") ? value.indexOf("WHERE") - 5 : value.length())).split(",");
                    }

                } else { // there is no value
                    log.error("No statement value for query model [" + sqlModelName + "]!");
                    this.queryType = QueryType.UNKNOWN;
                    this.warningMessage = "No statement value!";
                }
                */

                //System.out.println("*** ->\n" + value);


                // XPath Query for showing all nodes value
                /*
                XPathExpression expr = xpath.compile("//query/statement/text()");
                Object result = expr.evaluate(doc, XPathConstants.NODESET);
                NodeList nodes = (NodeList) result;
                System.out.println("***" + nodes.getLength());
                for (int i = 0; i < nodes.getLength(); i++) {
                 System.out.println("value -> " + nodes.item(i).getNodeValue().trim());
                }
                */

            } catch (ParserConfigurationException e) {
                log.error(e.getMessage());
            } catch (SAXException e) {
                log.error(e.getMessage());
            } catch (XPathExpressionException e) {
                log.error(e.getMessage());
            } catch (IOException e) {
                log.error(e.getMessage());
            }

        } else { // invalid file
            log.error("FSP sql model file [" + sqlModelPath + "] is invalid!");
        }
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("sqlModelName", sqlModelName)
                .append("sqlModelPath", sqlModelPath)
                .append("dbObjects", dbObjects)
                .toString();
    }

    public static void main(String[] args) {
        Log log = LogFactory.getLog(FspSqlModel.class);
        log.info("FspSqlModel main starting...");

        FspSqlModel sqlModel = new FspSqlModel("zzzz", "c:/temp/123456789/1.xml", null);
        //System.out.println(sqlModel);
    }

}