package ru.kzgroup.domain.dto.directories.regions;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Primary key (composite) for domain object - RegionDto
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 24.02.14)
*/

public class RegionDtoId implements Serializable {

    private static final long serialVersionUID = 1L;

    private int countryCode; // code of country (CountryCode in N0004006) - part of PrimaryKey
    private int regionCode;  // code of region (RegionCode in N0004006) - part of PrimaryKey

    public int getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(int countryCode) {
        this.countryCode = countryCode;
    }

    public int getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(int regionCode) {
        this.regionCode = regionCode;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "ParameterNameDiffersFromOverriddenParameter", "RedundantIfStatement", "QuestionableName"})
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RegionDtoId)) return false;

        RegionDtoId that = (RegionDtoId) o;

        if (countryCode != that.countryCode) return false;
        if (regionCode != that.regionCode) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = countryCode;
        result = 31 * result + regionCode;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("countryCode", countryCode)
                .append("regionCode", regionCode)
                .toString();
    }

}