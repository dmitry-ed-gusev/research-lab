package ru.kzgroup.domain.dto.directories;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * STEEL GRADE GROUP TYPE - domain object. Paradox table - N86019, MES - TB_QM_STL_GRADE_GRP_TYPE.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 03.09.2014)
*/

public class SteelGradeGroupTypeDto extends BaseDto {

    private int     groupTypeCode;
    private String  groupTypeName;
    private Integer groupTypeCodeCommon;
    private String  groupTypeNameCommon;

    public int getGroupTypeCode() {
        return groupTypeCode;
    }

    public void setGroupTypeCode(int groupTypeCode) {
        this.groupTypeCode = groupTypeCode;
    }

    public String getGroupTypeName() {
        return groupTypeName;
    }

    public void setGroupTypeName(String groupTypeName) {
        this.groupTypeName = groupTypeName;
    }

    public Integer getGroupTypeCodeCommon() {
        return groupTypeCodeCommon;
    }

    public void setGroupTypeCodeCommon(Integer groupTypeCodeCommon) {
        this.groupTypeCodeCommon = groupTypeCodeCommon;
    }

    public String getGroupTypeNameCommon() {
        return groupTypeNameCommon;
    }

    public void setGroupTypeNameCommon(String groupTypeNameCommon) {
        this.groupTypeNameCommon = groupTypeNameCommon;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("groupTypeCode", groupTypeCode)
                .append("groupTypeName", groupTypeName)
                .append("groupTypeCodeCommon", groupTypeCodeCommon)
                .append("groupTypeNameCommon", groupTypeNameCommon)
                .toString();
    }

}