package ru.kzgroup.mesUtil.engine.db;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.exceptions.MesException;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;

import static ru.kzgroup.MesUtilDefaults.DBOBJECT_TYPE;

/**
 * Common abstract class for all MES DB analizers modules. Includes common functionality -
 * saving/loading db objects to/from file.
 * @author Gusev Dmitry
 * @version 1.0 (DATE: 14.05.13)
*/

public abstract class AbstractDbAnalizer {

    private Log log = LogFactory.getLog(AbstractDbAnalizer.class);

    /**
     * Method returns objects list from database/exported file/db file. If something is wrong -
     * method will throw MesUtilEngineException (all other exceptions will be casted to it).
     */
    public abstract Map<String, DBOBJECT_TYPE> getDbObjects() throws MesException;

    /***/
    public void saveDBObjectsList(String fileName) throws IOException, MesException {
        log.debug("AbstractDbAnalizer.saveDBObjectsList() working.");
        if (!StringUtils.isBlank(fileName)) {
            BufferedWriter bWriter = null;
            FileWriter fWriter = null;
            try {
                fWriter = new FileWriter(fileName);
                bWriter = new BufferedWriter(fWriter);
                Map<String, DBOBJECT_TYPE> dbObjects = this.getDbObjects();
                for (Map.Entry entry : dbObjects.entrySet()) {
                    String str = entry.getKey() + "=" + entry.getValue() + "\n";
                    bWriter.write(str);
                }
            } finally { // free resources
                if (bWriter != null) {
                    try {
                        bWriter.close();
                    } catch (IOException e) {
                        log.error("Can't close BufferedWriter! Reason: " + e.getMessage(), e);
                    }
                }

                if (fWriter != null) {
                    try {
                        fWriter.close();
                    } catch (IOException e) {
                        log.error("Can't close FileWriter! Reason: " + e.getMessage(), e);
                    }
                }
            }
        } else { //
            throw new IllegalArgumentException("Empty file name for storing DB objects list!");
        }
    }

}