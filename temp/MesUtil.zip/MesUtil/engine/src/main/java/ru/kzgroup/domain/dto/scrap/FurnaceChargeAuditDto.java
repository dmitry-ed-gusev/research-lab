package ru.kzgroup.domain.dto.scrap;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;
import ru.kzgroup.domain.dto.directories.MaterialDto;
import ru.kzgroup.domain.dto.directories.SteelGradeDto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * ONE FURNACE CHARGE AUDIT ENTRY - audit domain object (объект (запись)
 * аудита одного изменения металлозавалки). Concrete class.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 05.08.2014)
*/

public class FurnaceChargeAuditDto extends BaseDto {

    private long       id;                  // identity - sequence used
    private String     action;              // action - INSERT, UPDATE, DELETE
    private int        meltNumber;          // D8015009->MeltNo
    private int        scrapTypeCode;       // D8015009->MatKindCode

    //private int        scrapCode;           // D8015009->MatCode
    private MaterialDto material; // D8015009->MatCode
    //private int        steelGradeCode;      // D8015009->MarkCode
    private SteelGradeDto steelGrade; // D8015009->MarkCode

    private int        stringCode;          // D8015009->StringNo
    private String     shift;               // D8015009->
    private Integer    clockNumber;         // D8015009-> (nullable (ARM))
    private BigDecimal weight;              // D8015009->
    private int        steelGradeGroupCode; // D8015009->
    private int        akos;                // D8015009->
    private Date       meltDate;            // D8015009->
    private int        deleted;             // is entity deleted from source (PDX) or not?

    /* Default constructor (for Hibernate etc) */
    public FurnaceChargeAuditDto() {}

    /***/
    // todo: NPE if furnaceChargeDto is NULL
    public FurnaceChargeAuditDto(String action, FurnaceChargeDto furnaceChargeDto) {
        this.action              = action;
        this.meltNumber          = furnaceChargeDto.getId().getMeltNumber();
        this.scrapTypeCode       = furnaceChargeDto.getId().getScrapTypeCode();

        //this.scrapCode           = furnaceChargeDto.getId().getScrapCode();
        //this.steelGradeCode      = furnaceChargeDto.getId().getSteelGradeCode();
        // object field - scrap type (material)
        MaterialDto material = new MaterialDto();
        material.setCode(furnaceChargeDto.getId().getScrapCode());
        this.material = material;
        // object field - steel grade
        SteelGradeDto steelGrade = new SteelGradeDto();
        steelGrade.setCode(furnaceChargeDto.getId().getSteelGradeCode());
        this.steelGrade = steelGrade;

        this.stringCode          = furnaceChargeDto.getId().getStringCode();
        this.shift               = furnaceChargeDto.getShift();
        this.clockNumber         = furnaceChargeDto.getClockNumber();
        this.weight              = furnaceChargeDto.getWeight();
        this.steelGradeGroupCode = furnaceChargeDto.getSteelGradeGroupCode();
        this.akos                = furnaceChargeDto.getAkos();
        this.meltDate            = furnaceChargeDto.getMeltDate();
        this.deleted             = furnaceChargeDto.getDeleted();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public int getMeltNumber() {
        return meltNumber;
    }

    public void setMeltNumber(int meltNumber) {
        this.meltNumber = meltNumber;
    }

    public int getScrapTypeCode() {
        return scrapTypeCode;
    }

    public void setScrapTypeCode(int scrapTypeCode) {
        this.scrapTypeCode = scrapTypeCode;
    }

    /*
    public int getScrapCode() {
        return scrapCode;
    }

    public void setScrapCode(int scrapCode) {
        this.scrapCode = scrapCode;
    }

    public int getSteelGradeCode() {
        return steelGradeCode;
    }

    public void setSteelGradeCode(int steelGradeCode) {
        this.steelGradeCode = steelGradeCode;
    }
    */

    public MaterialDto getMaterial() {
        return material;
    }

    public void setMaterial(MaterialDto material) {
        this.material = material;
    }

    public SteelGradeDto getSteelGrade() {
        return steelGrade;
    }

    public void setSteelGrade(SteelGradeDto steelGrade) {
        this.steelGrade = steelGrade;
    }

    public int getStringCode() {
        return stringCode;
    }

    public void setStringCode(int stringCode) {
        this.stringCode = stringCode;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    public Integer getClockNumber() {
        return clockNumber;
    }

    public void setClockNumber(Integer clockNumber) {
        this.clockNumber = clockNumber;
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    public int getSteelGradeGroupCode() {
        return steelGradeGroupCode;
    }

    public void setSteelGradeGroupCode(int steelGradeGroupCode) {
        this.steelGradeGroupCode = steelGradeGroupCode;
    }

    public int getAkos() {
        return akos;
    }

    public void setAkos(int akos) {
        this.akos = akos;
    }

    public Date getMeltDate() {
        return meltDate;
    }

    public void setMeltDate(Date meltDate) {
        this.meltDate = meltDate;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("action", action)
                .append("meltNumber", meltNumber)
                .append("scrapTypeCode", scrapTypeCode)
                //.append("scrapCode", scrapCode)
                //.append("steelGradeCode", steelGradeCode)
                .append("material", material)
                .append("steelGrade", steelGrade)
                .append("stringCode", stringCode)
                .append("shift", shift)
                .append("clockNumber", clockNumber)
                .append("weight", weight)
                .append("steelGradeGroupCode", steelGradeGroupCode)
                .append("akos", akos)
                .append("meltDate", meltDate)
                .append("deleted", deleted)
                .toString();
    }

}