package ru.kzgroup.domain.dto.orders.pdx;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.directories.characteristics.TechCharacteristicDto;
import ru.kzgroup.domain.dto.directories.requirements.ExtraRequirementDto;
import ru.kzgroup.domain.dto.orders.AbstractOrderPosition;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Domain object - one order position (from Paradox database).
 * Some notes for this object:
 *  - field D8609152->StGrdSeparator usage: "-" -> all steel grades from StGrdCodeA to StGrdCodeB,
 *    "," -> just two marks StGrdCodeA and StGrdCodeB, null/empty -> use just StGrdCodeA (all fields from table D8609152)
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 12.02.14)
*/

public class OrderPositionDtoPDX extends AbstractOrderPosition {

    private OrderPositionDtoIdPDX          id;                                // composite primary key for object
    private Set<OrderExtraParameterDtoPDX> extraParameters = new HashSet<>(); // extra parameters for order position (D8609PAR)
    private ExtraRequirementDto            requirementA;                      // Object from M116 (D8609152->ExtraRequirementCodeA)
    private ExtraRequirementDto            requirementB;                      // Object from M116 (D8609152->ExtraRequirementCodeB)
    private ExtraRequirementDto            requirementC;                      // Object from M116 (D8609152->ExtraRequirementCodeC)
    private ExtraRequirementDto            requirementD;                      // Object from M116 (D8609152->ExtraRequirementCodeD)
    private TechCharacteristicDto          techCharacteristic;                // Extra requirements (tech characteristic)->M115(codes) (desc - M116)
    private Date                           shipmentDate;                      // D8609152->PlanShipmentDate

    public OrderPositionDtoIdPDX getId() {
        return id;
    }

    public void setId(OrderPositionDtoIdPDX id) {
        this.id = id;
    }

    public Set<OrderExtraParameterDtoPDX> getExtraParameters() {
        return extraParameters;
    }

    public void setExtraParameters(Set<OrderExtraParameterDtoPDX> extraParameters) {
        this.extraParameters = extraParameters;
    }

    public TechCharacteristicDto getTechCharacteristic() {
        return techCharacteristic;
    }

    public void setTechCharacteristic(TechCharacteristicDto extraRequirement) {
        this.techCharacteristic = extraRequirement;
    }

    public Date getShipmentDate() {
        return shipmentDate;
    }

    public void setShipmentDate(Date shipmentDate) {
        this.shipmentDate = shipmentDate;
    }

    public ExtraRequirementDto getRequirementA() {
        return requirementA;
    }

    public void setRequirementA(ExtraRequirementDto requirementA) {
        this.requirementA = requirementA;
    }

    public ExtraRequirementDto getRequirementB() {
        return requirementB;
    }

    public void setRequirementB(ExtraRequirementDto requirementB) {
        this.requirementB = requirementB;
    }

    public ExtraRequirementDto getRequirementC() {
        return requirementC;
    }

    public void setRequirementC(ExtraRequirementDto requirementC) {
        this.requirementC = requirementC;
    }

    public ExtraRequirementDto getRequirementD() {
        return requirementD;
    }

    public void setRequirementD(ExtraRequirementDto requirementD) {
        this.requirementD = requirementD;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("orderPosition", super.toString())
                .append("extraParameters", extraParameters)
                .append("requirementA", requirementA)
                .append("requirementB", requirementB)
                .append("requirementC", requirementC)
                .append("requirementD", requirementD)
                .append("techCharacteristic", techCharacteristic)
                .append("shipmentDate", shipmentDate)
                .toString();
    }

}