package ru.kzgroup.domain.dto.directories.requirements;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for EXTRA REQUIREMENT BY CHEMISTRY domain object.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 30.06.2014)
*/

public class ExtraRequirementChemistryDtoId implements Serializable {

    private static final long serialVersionUID = 1L;

    private int reqCode;
    private int elementCode;

    public int getReqCode() {
        return reqCode;
    }

    public void setReqCode(int reqCode) {
        this.reqCode = reqCode;
    }

    public int getElementCode() {
        return elementCode;
    }

    public void setElementCode(int elementCode) {
        this.elementCode = elementCode;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "ParameterNameDiffersFromOverriddenParameter", "RedundantIfStatement", "QuestionableName"})
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ExtraRequirementChemistryDtoId that = (ExtraRequirementChemistryDtoId) o;

        if (elementCode != that.elementCode) return false;
        if (reqCode != that.reqCode) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = reqCode;
        result = 31 * result + elementCode;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("reqCode", reqCode)
                .append("elementCode", elementCode)
                .toString();
    }

}