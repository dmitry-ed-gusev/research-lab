package ru.kzgroup.reporting;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.kzgroup.domain.dto.orders.ora.OrderDtoORA;
import ru.kzgroup.domain.dto.orders.ora.OrderPositionDtoORA;
import ru.kzgroup.domain.dto.orders.ora.OrderRollingDto;

import java.util.List;
import java.util.Set;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 25.08.2014)
*/

@Component
@Transactional
public class OrdersReportingEngine {

    private static final Log log = LogFactory.getLog(OrdersReportingEngine.class);

    @Autowired(required = false) @Qualifier("commonMESSessionFactory")
    private SessionFactory oraSessionFactory;

    public SessionFactory getOraSessionFactory() {
        return oraSessionFactory;
    }

    public void setOraSessionFactory(SessionFactory oraSessionFactory) {
        this.oraSessionFactory = oraSessionFactory;
    }

    public void zzz() {
        log.debug("OrdersReportingEngine.zzz() working.");
        Session oraSession = oraSessionFactory.getCurrentSession();
        List orders = oraSession.createQuery("from OrderDtoORA o where o.id.orderNumber = '3500781'").list();

        if (orders != null && !orders.isEmpty()) {
            for (Object object : orders) {
                OrderDtoORA order = (OrderDtoORA) object;
                //System.out.println("-> " + order);
                Set<OrderPositionDtoORA> positions = order.getPositions();

                if (positions != null && !positions.isEmpty()) {
                    for (OrderPositionDtoORA position : positions) {

                        Set<OrderRollingDto> rollingItems = position.getRollingItems();
                        if (rollingItems != null && !rollingItems.isEmpty()) {
                            for (OrderRollingDto item : rollingItems) {
                                System.out.println("-> " + item);
                            }
                            System.out.println("-----------------------------------------------------------");
                        }

                    } // end of for (positions)

                }

            }
        }
    }

}