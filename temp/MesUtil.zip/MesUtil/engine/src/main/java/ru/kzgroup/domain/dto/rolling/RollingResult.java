package ru.kzgroup.domain.dto.rolling;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.text.SimpleDateFormat;
import java.util.Date;

import static ru.kzgroup.MesUtilDefaults.*;
/**
 * Rilling result for concrete date. All weights are in kilograms.
 * @deprecated don't use
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 26.08.13)
*/

public class RollingResult {

    private Log log = LogFactory.getLog(RollingResult.class);

    // [коэффициент годного - стан 900] Calculated as melt weight (3390kg) divided by ok melt weight (2970kg).
    // This ratio - for our own melts (self made). We melts, that we bought - other values!
    private final static double           MILL900_OK_RATIO     = 1.14;
    // [коэффициент годного - стан 350] Calculated experimental.
    private final static double           MILL350_OK_RATIO     = 1.06;
    //
    private final static SimpleDateFormat DATE_FORMAT  = new SimpleDateFormat("dd-MM-yyyy");
    // column width for report
    private final static int              COLUMN_WIDTH = 20;

    // fields with values from database
    private Date        rollingDate;       // date of rolling
    //private Set<String> workCards;         // list of work cards numbers for this day
    private int         inputBlankWeight;  //
    private int         pureGradeWeight;   //
    private int         resultBlankWeight; //
    private String      resultType;        // type of result -> ARM/MES
    private String      millNumber;        // number of mill -> 900/350
    // calculated fields
    private int         inputOkWeight;     // input blank weight divided by OK_RATIO (вес годного)
    private int         weightLoss;        // inputOk - (pureGrade + resultBlank)

    /***/
    public RollingResult(Date rollingDate, int inputBlankWeight, int pureGradeWeight, int resultBlankWeight,
                         String millNumber, String type) {
        this.rollingDate       = rollingDate;
        this.inputBlankWeight  = inputBlankWeight;
        this.pureGradeWeight   = pureGradeWeight;
        this.resultBlankWeight = resultBlankWeight;
        this.resultType        = type;
        this.millNumber        = millNumber;

        // calculate some data
        if (MILL900.equals(this.millNumber)) {// calculate other fields (for mill 900)
            this.inputOkWeight     = (int) (this.inputBlankWeight/MILL900_OK_RATIO);
            this.weightLoss        = this.inputOkWeight - this.pureGradeWeight - this.resultBlankWeight;
        } else if (MILL350.equals(this.millNumber)) { // calculate other fields (for mill 350)
            //this.inputOkWeight     = (int) (this.inputBlankWeight/MILL350_OK_RATIO);
            //this.weightLoss        = this.inputOkWeight - this.pureGradeWeight - this.resultBlankWeight;
            this.inputOkWeight     = this.inputBlankWeight;
            this.weightLoss        = this.inputBlankWeight - this.pureGradeWeight - this.resultBlankWeight;

        } else {
            log.warn("Wrong mill number [" + this.millNumber + "]!");
            this.inputOkWeight = 0;
            this.weightLoss    = 0;
        }

    }

    public Date getRollingDate() {
        return new Date(rollingDate.getTime()); // defensive style, we just copy value
    }

    public int getInputBlankWeight() {
        return inputBlankWeight;
    }

    public int getPureGradeWeight() {
        return pureGradeWeight;
    }

    public int getResultBlankWeight() {
        return resultBlankWeight;
    }

    public String getResultType() {
        return resultType;
    }

    public String getMillNumber() {
        return millNumber;
    }

    public int getInputOkWeight() {
        return inputOkWeight;
    }

    public int getWeightLoss() {
        return weightLoss;
    }

    /***/
    public String getReport() {
        log.debug("RollingResult.getReport() working.");
        StringBuilder report = new StringBuilder();
        // 5 -> is a fields count
        String horizontalLine = StringUtils.repeat("-", COLUMN_WIDTH * 5 + 5 + 1) + "\n";
        // header info
        report.append("Report: ").append(DATE_FORMAT.format(this.rollingDate)).append(" Mill: ").append(this.millNumber)
                .append(" Type: ").append(this.resultType).append("\n");
        report.append(horizontalLine);
        // header columns
        report.append("|").append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center("Заготовка (вход)", COLUMN_WIDTH)));
        report.append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center("Чистый сорт", COLUMN_WIDTH)));
        report.append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center("Заготовка (выход)", COLUMN_WIDTH)));
        report.append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center("Вес годного", COLUMN_WIDTH)));
        report.append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center("Потери", COLUMN_WIDTH)));
        report.append("\n").append(horizontalLine);
        // data
        report.append("|").append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center(String.valueOf(this.inputBlankWeight), COLUMN_WIDTH)));
        report.append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center(String.valueOf(this.pureGradeWeight), COLUMN_WIDTH)));
        report.append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center(String.valueOf(this.resultBlankWeight), COLUMN_WIDTH)));
        report.append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center(String.valueOf(this.inputOkWeight), COLUMN_WIDTH)));
        report.append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center(String.valueOf(this.weightLoss), COLUMN_WIDTH)));
        report.append("\n").append(horizontalLine);
        // return string report
        return report.toString();
    }

}