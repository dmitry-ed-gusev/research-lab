package ru.kzgroup.domain.dto.directories;

import ru.kzgroup.domain.dto.BaseDto;

/**
 * Dictionary - domain object DELIVERY TERMS.
 * MES: TB_DICT_DELIVERY_TERMS, ARM: M117 (new/spz/nsi)
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 07.06.2014)
*/

public class DeliveryTermDto extends BaseDto {

    private int    lengthCode;
    private String termName;
    private int    lengthFromFrom;
    private int    lengthFromTo;
    private int    lengthToFrom;
    private int    lengthToTo;

    /** Default constructor - for Hibernate. */
    public DeliveryTermDto() {}

    /** Copying constructor. */
    public DeliveryTermDto(DeliveryTermDto deliveryTerm) {
        this.lengthCode     = deliveryTerm.getLengthCode();
        this.termName       = deliveryTerm.getTermName();
        this.lengthFromFrom = deliveryTerm.getLengthFromFrom();
        this.lengthFromTo   = deliveryTerm.getLengthFromTo();
        this.lengthToFrom   = deliveryTerm.getLengthToFrom();
        this.lengthToTo     = deliveryTerm.getLengthToTo();
    }

    public int getLengthCode() {
        return lengthCode;
    }

    public void setLengthCode(int lengthCode) {
        this.lengthCode = lengthCode;
    }

    public String getTermName() {
        return termName;
    }

    public void setTermName(String termName) {
        this.termName = termName;
    }

    public int getLengthFromFrom() {
        return lengthFromFrom;
    }

    public void setLengthFromFrom(int lengthFromFrom) {
        this.lengthFromFrom = lengthFromFrom;
    }

    public int getLengthFromTo() {
        return lengthFromTo;
    }

    public void setLengthFromTo(int lengthFromTo) {
        this.lengthFromTo = lengthFromTo;
    }

    public int getLengthToFrom() {
        return lengthToFrom;
    }

    public void setLengthToFrom(int lengthToFrom) {
        this.lengthToFrom = lengthToFrom;
    }

    public int getLengthToTo() {
        return lengthToTo;
    }

    public void setLengthToTo(int lengthToTo) {
        this.lengthToTo = lengthToTo;
    }

}