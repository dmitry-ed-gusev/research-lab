package ru.kzgroup.domain.dto.rawTables.D8001130;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

import java.math.BigDecimal;

/**
 * RAW ARM table - D8001130.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 13.08.2014)
*/

public class D8001130Dto extends BaseDto {

    private D8001130DtoId id;
    private BigDecimal    planTonn;
    private BigDecimal    priceTonn;
    private BigDecimal    clauseAmount;

    public D8001130DtoId getId() {
        return id;
    }

    public void setId(D8001130DtoId id) {
        this.id = id;
    }

    public BigDecimal getPlanTonn() {
        return planTonn;
    }

    public void setPlanTonn(BigDecimal planTonn) {
        this.planTonn = planTonn;
    }

    public BigDecimal getPriceTonn() {
        return priceTonn;
    }

    public void setPriceTonn(BigDecimal priceTonn) {
        this.priceTonn = priceTonn;
    }

    public BigDecimal getClauseAmount() {
        return clauseAmount;
    }

    public void setClauseAmount(BigDecimal clauseAmount) {
        this.clauseAmount = clauseAmount;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("planTonn", planTonn)
                .append("priceTonn", priceTonn)
                .append("clauseAmount", clauseAmount)
                .toString();
    }

}