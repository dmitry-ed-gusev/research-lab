package ru.kzgroup;

import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;

/**
 * All constants from this system.
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 15.05.13)
 */

public interface MesUtilDefaults {

    /**
     * Types of objects in database.
     */
    public static enum DBOBJECT_TYPE {
        TABLE, PROCEDURE, FUNCTION, UNKNOWN;

        /**
         * Returns DBOBJECT_TYPE by string representation.
         */
        public static DBOBJECT_TYPE getObjectType(String objectTypeString) {
            DBOBJECT_TYPE result = UNKNOWN;
            if (!StringUtils.isBlank(objectTypeString)) { // if parameter is OK - process it
                boolean found = false;
                int counter = 0;
                DBOBJECT_TYPE[] typesList = DBOBJECT_TYPE.values();
                while (!found && counter < typesList.length) {
                    if (typesList[counter].toString().equals(StringUtils.trim(objectTypeString).toUpperCase())) {
                        result = typesList[counter];
                        found = true;
                    }
                    counter++;
                }
            }
            return result;
        }

    } // end of DBOBJECT_TYPE enum

    // Custom Spring properties (for socketService, telegramService)
    public static final String CUSTOM_PROPERTY_ORA_HOST             = "oracle.jdbc.url.host";   // common prop for different apps
    //public static final String CUST_PROP_SOCKSRV_TC_LIST      = "service.telegrams.list"; // custom prop for socketService
    //public static final String CUST_PROP_SOCKSRV_SERVICE_HOST = "service.host";           // custom prop for socketService
    //public static final String CUST_PROP_SOCKSRV_SERVICE_PORT = "service.port";           // custom prop for socketService

    // keys for mills 900/350
    public static final String MILL900 = "900";
    public static final String MILL350 = "350";

    // common date format
    //public static final SimpleDateFormat COMMON_DATE_FORMAT = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
    public static final String COMMON_DATE_FORMAT = "dd-MM-yyyy HH:mm:ss";

    // source date format in lab 100 data file
    public static final SimpleDateFormat LAB100_SOURCE_DATE_FORMAT = new SimpleDateFormat("ddMMyyHHmmss");

    // common: telegrams table name, names for some telegrams
    public static final String TELEGRAMS_TABLE_NAME = "TB_PO_LEVEL2_INTERFACE";
    public static final String SCRAP_TELEGRAM_NAME  = "D1TR001";
    public static final String LAB100_TELEGRAM_NAME = "D1TR002";

    // common: telegram ID column in telegrams table
    //public static final String DATA_TABLE_TELEGRAMID_COLUMN = "TC_ID";
    // params for scrap weighing: telegram name, datetime column name
    //public static final String SCRAP_DATETIME_COLUMN = "ITEM_9";
    // params for lab 100: telegram name, datetime column name
    //public static final String LAB100_DATETIME_COLUMN = "ITEM_3";
    // sql query for receving max telegram timestamp
    //public static final String MAX_DATETIME_SQL =
    //        "select to_char(max(tc_date), 'dd-mm-yyyy HH24:MI:SS') from " +
    //                "(select to_date(%s, 'dd-mm-yyyy HH24:MI:SS') as tc_date from " + DATA_TABLE_NAME + " where " +
    //                DATA_TABLE_TELEGRAMID_COLUMN + " = '%s')";

    // DataMiner log4j config file
    //public static final String LOG4J_CONFIG_FILE = "log4j.properties";
    // DataMiner config file name
    //public static final String CONFIG_FILE = "miner.properties";

    // default modifier user for DataMiner application
    //public static final String DEFAULT_MODIFIER_DATAMINER = "dataMinerUtil";

    // Minimum repeat time for miner thread (seconds). If thread repeat time is less than this value thread won't start.
    //public static final int              MIN_REPEAT_TIME                = 30; // -> moved to [engine] module

    // Minimum repeat time for DBMS connections configs checker processor (seconds).
    //public static final int MIN_REPEAT_TIME_DBCONF_CHECKER = 120;

    // Hibernate configuration files
    //public static final String PDX_HIBERNATE_CONFIG = "hiber_pdx/hibernate_pdx.cfg.xml";
    //public static final String ORA_HIBERNATE_CONFIG = "hiber_ora/hibernate_ora.cfg.xml";

    // config keys: lab 100
    //public static final String KEY_LAB100_ENABLED = "lab100.enabled";
    //public static final String KEY_LAB100_FILE_NAME = "lab100.filename";
    //public static final String KEY_LAB100_REPEAT_TIME = "lab100.repeat.time";
    //public static final String KEY_LAB100_MODIFIER = "lab100.modifier";
    // config keys: scrap weighers
    //public static final String KEY_SCRAP_ENABLED = "scrap.enabled";
    //public static final String KEY_SCRAP_NORTH_FILENAME = "scrap.north.filename";
    //public static final String KEY_SCRAP_SOUTH_FILENAME = "scrap.south.filename";
    //public static final String KEY_SCRAP_REPEAT_TIME = "scrap.repeat.time";
    //public static final String KEY_SCRAP_MODIFIER = "scrap.modifier";
    // config keys: turning bills data
    //public static final String KEY_TURNING_ENABLED = "turning.enabled";
    //public static final String KEY_TURNING_DATA_FOLDER = "turning.data.folder";
    //public static final String KEY_TURNING_REPEAT_TIME = "turning.repeat.time";
    //public static final String KEY_TURNING_MODIFIER = "turning.modifier";

    // config keys: paradox directories
    //public static final String KEY_DIRECTORIES_ENABLED = "directories.enabled";
    //public static final String KEY_DIRECTORIES_TABLES_CONFIG = "directories.tables.properties";
    //public static final String KEY_DIRECTORIES_REPEAT_TIME = "directories.repeat.time";
    //public static final String KEY_DIRECTORIES_MODIFIER = "directories.modifier";
    // config keys: db configs checker (processor)
    //public static final String KEY_DBCONF_CHECKER_REPEAT_TIME = "dbconf.checker.repeat.time";

    // config keys: personnel data processing
    //public static final String KEY_PERSONNEL_ENABLED = "personnel.enabled";
    //public static final String KEY_PERSONNEL_ACCESSDB_FILE = "personnel.accessdb.file";
    //public static final String KEY_PERSONNEL_REPEAT_TIME = "personnel.repeat.time";

    /** Mill groups enum data type. */
    public static enum MILL_GROUP {
        MILL900, MILL350, UNKNOWN;

        /** Get mill group from string value. */
        public static MILL_GROUP getMillGroup(String value) {
            MILL_GROUP result;

            if (!StringUtils.isBlank(value)) {
                if (StringUtils.trimToEmpty(value).startsWith("9")) {
                    result = MILL900;
                } else if (StringUtils.trimToEmpty(value).startsWith("3")) {
                    result = MILL350;
                } else {
                    result = UNKNOWN;
                }
            } else {
                result = UNKNOWN;
            }

            return result;
        }

    }

    /** Data type for common purposes - ARM/MES/UNKNOWN. */
    public static enum DATATYPE {
        ARM, MES, UNKNOWN
    }

    /** Common date format for MES Mill tables/modules. */
    public static final SimpleDateFormat MES_MILL_DATE_FORMAT = new SimpleDateFormat("yyyyMMdd");
    /** Common date format for ARM Mill tables/modules. */
    public static final SimpleDateFormat ARM_MILL_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    //
    //public static final String TELEGRAM_SERVICE_DBMODIFIER  = "TelegramService";
    //
    public static final String DATAMINER_SERVICE_DBMODIFIER = "DataMiner";
    //
    public static final int SESSION_FLUSH_STEP = 1000;

}