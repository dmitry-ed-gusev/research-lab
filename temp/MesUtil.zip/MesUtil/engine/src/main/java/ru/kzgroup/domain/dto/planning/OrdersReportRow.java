package ru.kzgroup.domain.dto.planning;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 22.08.2014)
*/

public class OrdersReportRow {

    private String     shipmentType;       //
    private String     marketType;         //
    private String     consignee;          // name + code
    private String     payer;              // name + code
    private int        mill;               //
    private Date       orderOpenDate;      //
    private Date       orderChangeDate;    //
    private int        movedFromMonth;     //
    private String     orderNumber;        //
    private String     orderPosition;      //
    private String     steelGrade;         // steel grade mark name + code + group code
    private String     section;            // section name + code
    private int        size1;              //
    private int        size2;              //
    private String     lengthType;         //
    private int        lengthFrom;         //
    private int        lengthTo;           //
    private String     steelGradeStandard; //
    private String     sectionStandard;    //
    private String     extraItems;         //
    private String     heatTreat;          //
    private String     note1;              //
    private String     note2;              //
    private BigDecimal weight;             //

    // rolling data for order position (RK110)
    private BigDecimal rollingWeight;      //
    private String     meltNumber;         //
    private String     workCardNumber;     //
    private String     workCardDate;       //
    private BigDecimal acceptanceWeightAD; //
    private Date       acceptanceDateAD;   //
    private BigDecimal otkWeight;          //

    // finished goods items data (M149)

}