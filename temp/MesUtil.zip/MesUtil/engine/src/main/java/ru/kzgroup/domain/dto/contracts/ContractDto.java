package ru.kzgroup.domain.dto.contracts;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Domain object - one contract/
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 09.01.14)
*/

// todo: fix comments for fields

public class ContractDto extends BaseDto { // (PDX -> N27001)

    private Long            id;           // (PDX -> RegistryNo) unique contract identifier
    private String          number;       // (PDX -> ВходНомер) unique contract number (real number)
    private String          year;         // (PDX -> Год) year of contract, 4 digits
    private Date            startDate;    // (PDX -> ДатаДоговора) contract start date
    private Date            endDate;      // (PDX -> СрокДействия) contract end date
    // data about partner exists in different table
    private Integer         partnerId;    // (PDX -> КодПредпр) other side for current contract (ID)
    // This data exists in different table (PDX table N27002).
    // (PDX -> КодПрДоговора (N27001), КодПредДоговор (N27002))
    //private Integer        subjectTypeId;    // (value from table N27001) идентификатор типа предмета (темы) договора
    // we don't need this field for PDX, but need for ORA
    private String          subjectTypeValue; // (value from table N27002) непосредственно значение типа предмета договора
    private SubjectTypeDto  subjectType;      // (value from table N27002) object reference to table N27002
    private String          subject;          // (PDX -> Тема) предмет (тема) договора
    // (N27001->ТипДокум, N27004->ContractTypeDto) contract type (контракт/договор/соглашение)
    private ContractTypeDto contractType;
    // (N27001->КодР, N27003->RoleTypeDto object reference) role in contract (продавец/покупатель/исполнитель/заказчик)
    private RoleTypeDto     roleType;
    private BigDecimal      amount;           // (PDX -> СуммаДоговора) total amount of contract
    private boolean         valid;            // (PDX -> ПризнакДейств) is current contract valid? (действующий?)
    private Date            validityDate;     // (PDX -> ДатаНДейств) дата прекращения действия (может отличаться от endDate)
    //
    private Integer         currencyCode;     // Integer - possible null values in PDX DB
    //
    //private CurrencyDto     currency;         //
    //
    private String          numberEGRUL;      //
    //
    private Date            dateEGRUL;        //

    private int             registeredShopCode;     // (N27001->RegShopNo)
    private int             registeredDeptCode;     // (N27001->КодОтдела)
    private int             internalContractNumber; // (N27001->NДоговора)

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Integer getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(Integer partnerId) {
        this.partnerId = partnerId;
    }

    public String getSubjectTypeValue() {
        return subjectTypeValue;
    }

    public void setSubjectTypeValue(String subjectTypeValue) {
        this.subjectTypeValue = subjectTypeValue;
    }

    public SubjectTypeDto getSubjectType() {
        return subjectType;
    }

    public void setSubjectType(SubjectTypeDto subjectType) {
        this.subjectType = subjectType;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public ContractTypeDto getContractType() {
        return contractType;
    }

    public void setContractType(ContractTypeDto contractType) {
        this.contractType = contractType;
    }

    public RoleTypeDto getRoleType() {
        return roleType;
    }

    public void setRoleType(RoleTypeDto roleType) {
        this.roleType = roleType;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public Date getValidityDate() {
        return validityDate;
    }

    public void setValidityDate(Date validityDate) {
        this.validityDate = validityDate;
    }

    public String getNumberEGRUL() {
        return numberEGRUL;
    }

    public void setNumberEGRUL(String numberEGRUL) {
        this.numberEGRUL = numberEGRUL;
    }

    public Date getDateEGRUL() {
        return dateEGRUL;
    }

    public void setDateEGRUL(Date dateEGRUL) {
        this.dateEGRUL = dateEGRUL;
    }

    //public CurrencyDto getCurrency() {
    //    return currency;
    //}

    //public void setCurrency(CurrencyDto currency) {
    //    this.currency = currency;
    //}

    public Integer getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(Integer currencyCode) {
        this.currencyCode = currencyCode;
    }

    public int getRegisteredShopCode() {
        return registeredShopCode;
    }

    public void setRegisteredShopCode(int registeredShopCode) {
        this.registeredShopCode = registeredShopCode;
    }

    public int getRegisteredDeptCode() {
        return registeredDeptCode;
    }

    public void setRegisteredDeptCode(int registeredDeptCode) {
        this.registeredDeptCode = registeredDeptCode;
    }

    public int getInternalContractNumber() {
        return internalContractNumber;
    }

    public void setInternalContractNumber(int internalContractNumber) {
        this.internalContractNumber = internalContractNumber;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("number", number)
                .append("year", year)
                .append("startDate", startDate)
                .append("endDate", endDate)
                .append("partnerId", partnerId)
                .append("subjectTypeValue", subjectTypeValue)
                .append("subjectType", subjectType)
                .append("subject", subject)
                .append("contractType", contractType)
                .append("roleType", roleType)
                .append("amount", amount)
                .append("valid", valid)
                .append("validityDate", validityDate)
                .append("currencyCode", currencyCode)
                .append("registeredShopCode", registeredShopCode)
                .append("registeredDeptCode", registeredDeptCode)
                .append("internalContractNumber", internalContractNumber)
                //.append("currency", currency)
                .append("numberEGRUL", numberEGRUL)
                .append("dateEGRUL", dateEGRUL)
                .toString();
    }

}