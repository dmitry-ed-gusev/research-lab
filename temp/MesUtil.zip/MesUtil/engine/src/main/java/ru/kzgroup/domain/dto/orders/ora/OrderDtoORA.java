package ru.kzgroup.domain.dto.orders.ora;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.exceptions.InternalException;
import ru.kzgroup.domain.dto.directories.CountryDto;
import ru.kzgroup.domain.dto.directories.MarkingDto;
import ru.kzgroup.domain.dto.orders.AbstractOrder;
import ru.kzgroup.domain.dto.orders.OrdersHelper;
import ru.kzgroup.domain.dto.orders.pdx.OrderD0502002PDX;
import ru.kzgroup.domain.dto.orders.pdx.OrderDtoPDX;
import ru.kzgroup.domain.dto.orders.pdx.OrderPositionDtoPDX;

import java.util.*;

/**
 * ORDER - domain object (Oracle version). Oracle->TB_SM_ORDCOMM.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 02.06.2014)
*/

public class OrderDtoORA extends AbstractOrder {

    private static final Log log = LogFactory.getLog(OrderDtoORA.class);

    private OrderDtoIdORA            id;                   // composite primary key
    private String                   orderProgressCode;    // TB_SM_ORDCOMM->ORD_PROG_CD
    private String                   isCarCustomer;        // TB_SM_ORDCOMM->CAR_YN ('Y'/'N')
    private String                   contractName;         // TB_SM_ORDCOMM->CONTRACT_NAME
    private String                   contractOrderNumber;  // TB_SM_ORDCOMM->CONTRACT_ORD_NO (same data as ORD_NO - see primary key)
    private String                   note1;                // TB_SM_ORDCOMM->NOTE, D0502002->Notes
    private String                   note2;                // TB_SM_ORDCOMM->NOTE1, D0502002->Notes1
    private String                   orderConfirmDate;     // TB_SM_ORDCOMM->ORD_CONFIRM_DD
    private String                   packingId;            // TB_SM_ORDCOMM->PACKING_IDENTI
    private String                   customerSpecialPrint; // TB_SM_ORDCOMM->CUSTOMER_SPEC_PRINT
    private String                   customerDeliverDate;  // TB_SM_ORDCOMM->CUSTOMER_DELIVER_DD
    private Set<OrderPositionDtoORA> positions = new HashSet<>(); // order positions (table TB_SM_ORDDTL)

    /** Default constructor (with no parameters), used by Hibernate etc. */
    public OrderDtoORA() {}

    /** Copying constructor - copies object OrderDtoPDX state into current object. */
    public OrderDtoORA(OrderDtoPDX pdxOrder, Map<String, String> sectionsMap, Date currentDate, String modifier) throws InternalException {

        if (pdxOrder == null) {
            throw new InternalException("Paradox ORDER is NULL!");
        }

        // this global maps are for tech purpose - we have to be sure, that there is the only object with given state in memory
        // (we can't map two equals objects to one database row and merge this objects - we will receive IllegalStateException in Hibernate)
        Map<OrderIngredientDtoIdORA, OrderIngredientDtoORA> allIngredientsMap = new HashMap<>();
        Map<OrderExtraItemDtoIdORA, OrderExtraItemDtoORA>   allExtraItemsMap  = new HashMap<>();

        // create ID
        OrderDtoIdORA id = new OrderDtoIdORA();
        id.setOrderNumber(pdxOrder.getId().getOrderNumber());
        // month. we have to append a leading zero - month should be two digits long (1->01)
        String strMonth = String.valueOf(pdxOrder.getId().getOrderMonth());
        id.setOrderYearMonth(String.valueOf(pdxOrder.getId().getOrderYear()) + ("00" + strMonth).substring(strMonth.length()));
        this.id = id;

        // fields (internal state)
        this.setOrderDate(pdxOrder.getOrderDate());
        this.setOrderIndex(pdxOrder.getOrderIndex());
        // copy customer object
        //this.setCustomer(new CustomerDto(pdxOrder.getCustomer(), true));
        this.setCustomer(pdxOrder.getCustomer());
        // copy consignee object
        //this.setConsignee(new CustomerDto(pdxOrder.getConsignee(), true));
        this.setConsignee(pdxOrder.getConsignee());
        // copy territory object
        //this.setTerritory(new TerritoryDto(pdxOrder.getTerritory()));
        this.setTerritory(pdxOrder.getTerritory());
        this.setExportOrderNumber(pdxOrder.getExportOrderNumber());
        this.setLotNumber(pdxOrder.getLotNumber());
        this.setLotName(pdxOrder.getLotName());
        // notes for current order
        Set<OrderD0502002PDX> notes = pdxOrder.getNotesForOrder();
        if (notes != null && !notes.isEmpty()) {
            // get first note for current order (there should be ONE or ZERO notes)
            OrderD0502002PDX noteForCurrentOrder = notes.iterator().next();
            this.note1 = StringUtils.trimToNull(noteForCurrentOrder.getNotes());
            this.note2 = StringUtils.trimToNull(noteForCurrentOrder.getNotes1());
        }

        // contract info
        this.setContractNumber(pdxOrder.getContractNumber());
        this.contractName = (pdxOrder.getContract() == null ? null : pdxOrder.getContract().getInboxNumber());

        // order shipment type and is car customer or not?
        int shipmentTypeCode = pdxOrder.getShipmentType().getId();
        this.setShipmentType(pdxOrder.getShipmentType());
        this.isCarCustomer = (shipmentTypeCode >= 4 && shipmentTypeCode <= 6 ? "Y" : "N");

        // creating marking data map
        Map<Integer, MarkingDto> markingMap = OrdersHelper.getMarkingMap(pdxOrder);

        // positions (deep copy)
        Set<OrderPositionDtoPDX> pdxPositions = pdxOrder.getPositions();
        Set<OrderPositionDtoORA> oraPositions = new HashSet<>();
        if (pdxPositions != null && !pdxPositions.isEmpty()) {
            int orderIndex  = this.getOrderIndex().getId();
            // country code calculating for delivery tolerance
            CountryDto country = (this.getCustomer() == null ? null : this.getCustomer().getCountry());
            int countryCode = (country != null ? country.getCode() : 0);

            for (OrderPositionDtoPDX pdxPosition : pdxPositions) { // processing order positions - copying from PDX to ORA
                // create ORDER POSITION for Oracle from Paradox data
                OrderPositionDtoORA oraPosition = new OrderPositionDtoORA(pdxPosition, sectionsMap, allIngredientsMap,
                        allExtraItemsMap, currentDate, modifier);
                // set order index for position (index info presents only in order)
                oraPosition.setOrderIndex(this.getOrderIndex());
                // set delivery tolerance for position
                if (countryCode > 0) {
                    Pair<Integer, Integer> deliveryTolerance = OrdersHelper.getDeliveryTolerance(orderIndex, countryCode, oraPosition.getWeight());
                    if (deliveryTolerance != null) {
                        oraPosition.setDeliveryToleranceMin(deliveryTolerance.getLeft());
                        oraPosition.setDeliveryToleranceMax(deliveryTolerance.getRight());
                    }
                }
                // adding marking information for current order position
                MarkingDto marking = markingMap.get(oraPosition.getId().getOrderPosition());
                //oraPosition.setMarking((marking == null ? null : new MarkingDto(marking)));
                oraPosition.setMarking((marking == null ? null : marking));
                // add order position (Oracle) to resulting set of positions
                oraPositions.add(oraPosition);
            }
        } else {
            log.debug(String.format("Order [%s] haven't got any positions!", this.id));
        }

        this.positions = oraPositions;
        // current date and db modifier
        this.setModifyDate(currentDate);
        this.setModifyUser(modifier);
    }

    public OrderDtoIdORA getId() {
        return id;
    }

    public void setId(OrderDtoIdORA id) {
        this.id = id;
    }

    public String getOrderProgressCode() {
        return orderProgressCode;
    }

    public void setOrderProgressCode(String orderProgressCode) {
        this.orderProgressCode = orderProgressCode;
    }

    public String getIsCarCustomer() {
        return isCarCustomer;
    }

    public void setIsCarCustomer(String isCarCustomer) {
        this.isCarCustomer = isCarCustomer;
    }

    public String getContractName() {
        return contractName;
    }

    public void setContractName(String contractName) {
        this.contractName = contractName;
    }

    public String getContractOrderNumber() {
        return contractOrderNumber;
    }

    public void setContractOrderNumber(String contractOrderNumber) {
        this.contractOrderNumber = contractOrderNumber;
    }

    public String getNote1() {
        return note1;
    }

    public void setNote1(String note1) {
        this.note1 = note1;
    }

    public String getNote2() {
        return note2;
    }

    public void setNote2(String note2) {
        this.note2 = note2;
    }

    public String getOrderConfirmDate() {
        return orderConfirmDate;
    }

    public void setOrderConfirmDate(String orderConfirmDate) {
        this.orderConfirmDate = orderConfirmDate;
    }

    public String getPackingId() {
        return packingId;
    }

    public void setPackingId(String packingId) {
        this.packingId = packingId;
    }

    public String getCustomerSpecialPrint() {
        return customerSpecialPrint;
    }

    public void setCustomerSpecialPrint(String customerSpecialPrint) {
        this.customerSpecialPrint = customerSpecialPrint;
    }

    public String getCustomerDeliverDate() {
        return customerDeliverDate;
    }

    public void setCustomerDeliverDate(String customerDeliverDate) {
        this.customerDeliverDate = customerDeliverDate;
    }

    public Set<OrderPositionDtoORA> getPositions() {
        return positions;
    }

    public void setPositions(Set<OrderPositionDtoORA> positions) {
        this.positions = positions;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("order", super.toString())
                .append("orderProgressCode", orderProgressCode)
                .append("isCarCustomer", isCarCustomer)
                .append("contractName", contractName)
                .append("contractOrderNumber", contractOrderNumber)
                .append("note1", note1)
                .append("note2", note2)
                .append("orderConfirmDate", orderConfirmDate)
                .append("packingId", packingId)
                .append("customerSpecialPrint", customerSpecialPrint)
                .append("customerDeliverDate", customerDeliverDate)
                .append("positions", positions)
                .toString();
    }

}