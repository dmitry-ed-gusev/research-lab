package ru.kzgroup.domain.dto.directories.productionKind;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for domain object - production kind code.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 09.06.2014)
*/

public class ProductionKindCodeDtoId implements Serializable {

    private static final long serialVersionUID = 1L;

    private int stlGradeCodeFrom;
    private int stlGradeCodeTo;
    private int sectionCode;
    private int size1;

    public int getStlGradeCodeFrom() {
        return stlGradeCodeFrom;
    }

    public void setStlGradeCodeFrom(int stlGradeCodeFrom) {
        this.stlGradeCodeFrom = stlGradeCodeFrom;
    }

    public int getStlGradeCodeTo() {
        return stlGradeCodeTo;
    }

    public void setStlGradeCodeTo(int stlGradeCodeTo) {
        this.stlGradeCodeTo = stlGradeCodeTo;
    }

    public int getSectionCode() {
        return sectionCode;
    }

    public void setSectionCode(int sectionCode) {
        this.sectionCode = sectionCode;
    }

    public int getSize1() {
        return size1;
    }

    public void setSize1(int size1) {
        this.size1 = size1;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement", "QuestionableName"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        ProductionKindCodeDtoId that = (ProductionKindCodeDtoId) obj;

        if (sectionCode != that.sectionCode) return false;
        if (size1 != that.size1) return false;
        if (stlGradeCodeFrom != that.stlGradeCodeFrom) return false;
        if (stlGradeCodeTo != that.stlGradeCodeTo) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = stlGradeCodeFrom;
        result = 31 * result + stlGradeCodeTo;
        result = 31 * result + sectionCode;
        result = 31 * result + size1;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("stlGradeCodeFrom", stlGradeCodeFrom)
                .append("stlGradeCodeTo", stlGradeCodeTo)
                .append("sectionCode", sectionCode)
                .append("size1", size1)
                .toString();
    }

}