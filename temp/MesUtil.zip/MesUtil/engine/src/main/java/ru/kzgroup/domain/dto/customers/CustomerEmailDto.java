package ru.kzgroup.domain.dto.customers;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * EMAIL ADDRESS FOR CUSTOMER - domain object.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 28.05.2014)
*/

// todo: replace customer code with customer object

public class CustomerEmailDto extends BaseDto {

    private int    id;
    private int    customerCode;
    private String email;
    private String useInMailing;

    /** Default constructor (for Hibernate etc). */
    public CustomerEmailDto() {}

    public CustomerEmailDto(CustomerEmailDto email) {
        if (email != null) {
            this.id           = email.getId();
            this.customerCode = email.getCustomerCode();
            this.email        = email.getEmail();
            this.useInMailing = email.getUseInMailing();
        } else {
            LogFactory.getLog(CustomerEmailDto.class).warn(String.format("Copy NULL object [%s]!", CustomerEmailDto.class));
            this.id           = 0;
            this.customerCode = 0;
            this.email        = null;
            this.useInMailing = null;
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(int customerCode) {
        this.customerCode = customerCode;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUseInMailing() {
        return useInMailing;
    }

    public void setUseInMailing(String useInMailing) {
        this.useInMailing = useInMailing;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("customerCode", customerCode)
                .append("email", email)
                .append("useInMailing", useInMailing)
                .toString();
    }

}