package ru.kzgroup.domain.dto.directories;

import junit.framework.Assert;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Test;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 10.07.2014)
*/

public class BundleWeightStdTest {

    @Test
    public void testGetBundleWeightForNulls() {
        // tests fornull result
        Assert.assertNull("Method should return NULL!", BundleWeightStd.getBundleWeight("", 100));
        Assert.assertNull("Method should return NULL!", BundleWeightStd.getBundleWeight(null, 0));
        Assert.assertNull("Method should return NULL!", BundleWeightStd.getBundleWeight("ZZZZZ", 0));
        Assert.assertNull("Method should return NULL!", BundleWeightStd.getBundleWeight("ZZZZ", -1));
        Assert.assertNull("Method should return NULL!", BundleWeightStd.getBundleWeight("BD", -19));
        Assert.assertNull("Method should return NULL!", BundleWeightStd.getBundleWeight("    BD ", 0));
        Assert.assertNull("Method should return NULL!", BundleWeightStd.getBundleWeight("  BD   ", 401));
    }

    @Test
    public void testGetBundleWeight() {
        // tests for real results
        Assert.assertEquals("Invalid result!", new ImmutablePair<>(100, 100), BundleWeightStd.getBundleWeight("BD", 1));
        Assert.assertEquals("Invalid result!", new ImmutablePair<>(100, 100), BundleWeightStd.getBundleWeight("  BD    ", 100));
        Assert.assertEquals("Invalid result!", new ImmutablePair<>(100, 100), BundleWeightStd.getBundleWeight("BD", 400));

    }

}