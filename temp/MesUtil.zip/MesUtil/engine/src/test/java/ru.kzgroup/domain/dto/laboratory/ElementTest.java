package ru.kzgroup.domain.dto.laboratory;

import junit.framework.Assert;
import org.junit.Test;

/**
 * Some simple tests for Element class (enumeration).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 09.07.2014)
*/

public class ElementTest {

    @Test
    public void testCommon() {
        Assert.assertEquals("Invalid code!", 9, Element.MO.getCode());
        Assert.assertEquals("Invalid name!", "Молибден", Element.MO.getFullName());
        Assert.assertEquals("Invalid name!", "MO", Element.MO.name());
    }

    @Test
    public void testGetCodeByName_1() {
        // Si
        Assert.assertEquals("Invalid code for element!", 2, Element.getCodeByName("si"));
        Assert.assertEquals("Invalid code for element!", 2, Element.getCodeByName("SI"));
        Assert.assertEquals("Invalid code for element!", 2, Element.getCodeByName("sI"));
        Assert.assertEquals("Invalid code for element!", 2, Element.getCodeByName("Si"));
        Assert.assertEquals("Invalid code for element!", 2, Element.getCodeByName(" Si "));
        Assert.assertEquals("Invalid code for element!", 2, Element.getCodeByName("    sI       "));
        // N
        Assert.assertEquals("Invalid code for element!", 17, Element.getCodeByName("N"));
        Assert.assertEquals("Invalid code for element!", 17, Element.getCodeByName("n"));
        Assert.assertEquals("Invalid code for element!", 17, Element.getCodeByName(" N   "));
        Assert.assertEquals("Invalid code for element!", 17, Element.getCodeByName("   n "));
    }

    @Test
    public void testGetCodeByName_2() {
        Assert.assertEquals("Invalid code!", 0, Element.getCodeByName(""));
        Assert.assertEquals("Invalid code!", 0, Element.getCodeByName(null));
        Assert.assertEquals("Invalid code!", 0, Element.getCodeByName("NNN"));
        Assert.assertEquals("Invalid code!", 0, Element.getCodeByName("        "));
        Assert.assertEquals("Invalid code!", 0, Element.getCodeByName("H"));
    }

    @Test
    public void testGetLatinNameByCode_1() {
        Assert.assertEquals("Invalid latin name!", "Si", Element.getLatinNameByCode(2));
        Assert.assertEquals("Invalid latin name!", "W", Element.getLatinNameByCode(10));
        Assert.assertEquals("Invalid latin name!", "Nb", Element.getLatinNameByCode(15));
    }

    @Test
    @SuppressWarnings("UnnecessaryBoxing")
    public void testGetLatinNameByCode_2() {
        Assert.assertNull("Unexpected result!", Element.getLatinNameByCode(0));
        Assert.assertNull("Unexpected result!", Element.getLatinNameByCode(-100));
        Assert.assertNull("Unexpected result!", Element.getLatinNameByCode(new Integer(389)));
    }

}