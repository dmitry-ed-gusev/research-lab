package ru.kzgroup;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import ru.kzgroup.components.report.reportTable.TextTableModelTest;
import ru.kzgroup.domain.dto.customers.report.CustomerReportTest;
import ru.kzgroup.domain.dto.directories.BundleWeightStdTest;
import ru.kzgroup.domain.dto.laboratory.ElementTest;

/**
 * Test suite (tests aggregator) for [engine] module.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 10.09.13)
*/

@RunWith(value=Suite.class)
@Suite.SuiteClasses(value={ElementTest.class, BundleWeightStdTest.class, CustomerReportTest.class, TextTableModelTest.class})
@SuppressWarnings("ClassMayBeInterface")
public class EngineTestSuite {}