package ru.kzgroup.dataReporter;

import gusev.dmitry.jtils.utils.CommonUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import ru.kzgroup.dataReporter.services.RollingReportService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Main class for dataReporter module.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 07.09.13)
 */

public class Reporter {

    /***/
    public static void main(String[] args) throws ParseException {
        Log log = LogFactory.getLog(Reporter.class);
        PropertyConfigurator.configure("log4j.properties");

        log.info("MES Reporter started. Current dir: " + System.getProperty("user.dir"));

        // loading application context from config file
        ApplicationContext context = new ClassPathXmlApplicationContext("ru/kzgroup/ReporterContext.xml");
        log.debug("Application context loaded.");

        RollingReportService reportService = (RollingReportService) context.getBean("rollingReportService");
        Date reportDate = new SimpleDateFormat("dd-MM-yyyy").parse("28-08-2013");
        String differencesReport = reportService.getRollingReport(reportDate, 0);
        log.debug("Report received.\n" + differencesReport);
        CommonUtils.saveStringToFile(differencesReport, "report.txt");
        log.debug("Report has been saved to file.");

    }

}