package ru.kzgroup.dataReporter.services;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import ru.kzgroup.dataReporter.helpers.RollingReportHelper;
import ru.kzgroup.components.report.reportTable.TextTableHelper;
import ru.kzgroup.components.report.reportTable.TextTable;
import ru.kzgroup.components.report.reportTable.TextTableModel;
import ru.kzgroup.domain.dao.rolling.RollingDao;
import ru.kzgroup.domain.dto.rolling.RollingCard;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import static ru.kzgroup.dataReporter.helpers.RollingReportHelper.ROLLING_CARD_REPORT_HEADER;
import static ru.kzgroup.MesUtilDefaults.*;

/**
 * Rolling reporting service. This module is spring-oriented (configured).
 *
 * Important! Class is immutable.
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 06.09.13)
*/

@Repository
public class RollingReportService {

    private Log log = LogFactory.getLog(RollingReportService.class);

    private RollingDao rollingDao; // DAO component for communicating with databases (MES/ARM)

    /** Constructor. Using constructor injecting - this class is immutable. */
    @Autowired
    public RollingReportService(RollingDao rollingDao) {
        this.rollingDao = rollingDao;
    }

    /***/
    public String getRollingReport(Date reportDate, int deltaDays) throws ParseException {
        log.debug("RollingReportService.getRollingReport() working.");
        StringBuilder report = new StringBuilder();

        // receiving DB data (both MES/ARM)
        List<RollingCard> armCards = this.rollingDao.getWorkCards (reportDate, deltaDays, DATATYPE.ARM);
        List<RollingCard> mesCards = this.rollingDao.getWorkCards (reportDate, deltaDays, DATATYPE.MES);
        log.debug(String.format("Raw data received. Sizes: arm = [%s], mes = [%s].", armCards.size(), mesCards.size()));

        // add some special info to report
        report.append(String.format("Рабочие карты: АРМ = %s шт., МЕС = %s шт.\n", armCards.size(), mesCards.size()));

        // generating differences report (TextTableModel -> TextTable)
        List<String[]> reportRows = new ArrayList<String[]>(); // one report row
        // iterating on cards lists and find differences
        Iterator<RollingCard> armCardsIterator = armCards.iterator();
        int rowsCounter = 1; // left vertical counter in report table
        while (armCardsIterator.hasNext()) {
            RollingCard armCard = armCardsIterator.next();
            if (mesCards.contains(armCard)) { // we've found a match
                // Remove cards from both lists. We don't add complete match to report.
                armCardsIterator.remove();
                mesCards.remove(armCard);
                //log.debug(String.format("Current sizes: arm list = [%s], mes list = [%s].", armCards.size(), mesCards.size()));
            } else { // try to find some equal work card by key
                Iterator<RollingCard> mesCardsIterator = mesCards.iterator();
                while (mesCardsIterator.hasNext()) {
                    RollingCard mesCard = mesCardsIterator.next();
                    if (armCard.equalsByKey(mesCard)) {
                        // add cards to report
                        reportRows.add(TextTableHelper.mergeRows(RollingReportHelper.getRollingCardData(rowsCounter, armCard),
                                RollingReportHelper.getRollingCardData(0, mesCard)));
                        rowsCounter++;
                        // remove them from both lists
                        mesCardsIterator.remove();
                        armCardsIterator.remove();
                    }
                } // inner cycle - iterating over mes cards list
            }
        } // main while cycle for report generating

        // remaining data in ARM cards list
        if (!armCards.isEmpty()) {
            for (RollingCard armCard : armCards) {
                reportRows.add(RollingReportHelper.getRollingCardData(rowsCounter, armCard));
                rowsCounter++;
            }
        }
        // remaining data in MES cards list
        if (!mesCards.isEmpty()) {
            for (RollingCard mesCard : mesCards) {
                reportRows.add(RollingReportHelper.getRollingCardData(rowsCounter, mesCard));
                rowsCounter++;
            }
        }

        // generating TextTableModel
        String[]       header          = ROLLING_CARD_REPORT_HEADER;
        String[][]     data            = reportRows.toArray(new String[reportRows.size()][]);
        TextTableModel reportModel     = new TextTableModel(header, data);
        // generating TextTable
        TextTable      reportTextTable = new TextTable(reportModel);
        // completed report
        report.append(reportTextTable.getTextGrid());

        // return result
        return report.toString();
    }

}
