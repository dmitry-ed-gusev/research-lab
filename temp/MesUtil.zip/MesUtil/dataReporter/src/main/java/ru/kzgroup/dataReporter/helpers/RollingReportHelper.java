package ru.kzgroup.dataReporter.helpers;

import ru.kzgroup.domain.dto.rolling.RollingCard;

import java.text.SimpleDateFormat;
import java.util.Arrays;

/**
 * Helper utility class for generating rolling reports (using TextTable component).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 02.09.13)
*/

public final class RollingReportHelper {

    private static final SimpleDateFormat REPORT_DATE_FORMAT         = new SimpleDateFormat("dd-MM-yyyy");
    public  static final String[]         ROLLING_CARD_REPORT_HEADER = new String[] {"#", "Тип карты", "Раб.карта #", "Позиций", "Стан",
            "Дата проката", "Год", "Входящий вес", "Выход, ч/с", "Выход, заготовка"};

    private RollingReportHelper() {} // <- we can't instantiate this class

    /***/
    public static String[] getRollingCardData(int sequenceNumber, RollingCard card) {
        String[] cardData;
        if (card != null) {
            cardData = new String[] {
                    (sequenceNumber > 0 ? "#" + String.valueOf(sequenceNumber) : ""), // if number = 0 -> we don't add number
                    card.getCardType().toString(), card.getPonNumber(),
                    String.valueOf(card.getPonPositionsCount()), card.getMillGroup().toString(),
                    REPORT_DATE_FORMAT.format(card.getMillDate()), card.getProductionYear(), String.valueOf(card.getInputWeight()),
                    String.valueOf(card.getOutputPureGradeWeight()), String.valueOf(card.getOutputBlankWeight())
            };
        } else {
            cardData = new String[0];
        }
        return cardData;
    }

    /***/
    public static String[] getRollingCardEmptyData() {
        String[] result = new String[ROLLING_CARD_REPORT_HEADER.length];
        result[0] = ""; // for empty rolling card we don't add sequence number
        Arrays.fill(result, 1, result.length, "-");
        return result;
    }

}