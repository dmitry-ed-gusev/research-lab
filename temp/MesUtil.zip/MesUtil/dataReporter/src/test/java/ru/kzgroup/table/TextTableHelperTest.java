package ru.kzgroup.table;

import org.junit.Assert;
import org.junit.Test;
import ru.kzgroup.components.report.reportTable.TextTableHelper;

/**
 * Tests for ReportHelper class.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 03.09.13)
*/

public class TextTableHelperTest {

    @Test
    //@SuppressWarnings("NullArgumentToVariableArgMethod")
    public void testMergeRows() {

        // test bound values
        Assert.assertNotNull("Method shouldn't return null!", TextTableHelper.mergeRows(null));
        Assert.assertEquals("Wrong result length with null argument!", 0, TextTableHelper.mergeRows(null).length);
        Assert.assertArrayEquals("Result is wrong (#1)!", new String[0], TextTableHelper.mergeRows(new String[0]));
        Assert.assertArrayEquals("Result is wrong (#2)!", new String[0], TextTableHelper.mergeRows(new String[]{}));
        Assert.assertArrayEquals("Result is wrong (#3)!", new String[] {""}, TextTableHelper.mergeRows(new String[]{""}));
        Assert.assertArrayEquals("Result is wrong (#4)!", new String[] {""}, TextTableHelper.mergeRows(new String[]{null}));
        Assert.assertArrayEquals("Result is wrong (#5)!", new String[0], TextTableHelper.mergeRows(null));

        // some preparations for next test cases
        String[] str1 = new String[] {"gg", "kk", "666"};
        String[] str2 = new String[] {"999"};
        String[] str3 = new String[] {""};
        String[] str4 = new String[] {};
        String[] str5 = new String[] {"", null, "123"};
        // test cases
        Assert.assertArrayEquals("Result is wrong (#6)!", str1, TextTableHelper.mergeRows(str1));
        Assert.assertArrayEquals("Result is wrong (#7)!", new String[] {"gg\n999", "kk", "666"}, TextTableHelper.mergeRows(str1, str2));
        Assert.assertArrayEquals("Result is wrong (#8)!", new String[] {"999\ngg", "kk", "666"}, TextTableHelper.mergeRows(str2, str1));
        Assert.assertArrayEquals("Result is wrong (#9)!", new String[] {"gg\n999", "kk", "666"}, TextTableHelper.mergeRows(str1, str2, str3, str4));
        Assert.assertArrayEquals("Result is wrong (#10)!", new String[] {""}, TextTableHelper.mergeRows(str3, str4));
        Assert.assertArrayEquals("Result is wrong (#11)!", new String[] {"", "", "123"}, TextTableHelper.mergeRows(str3, str4, str5));

    }

}