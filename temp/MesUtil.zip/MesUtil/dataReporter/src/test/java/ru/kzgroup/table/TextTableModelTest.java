package ru.kzgroup.table;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import ru.kzgroup.components.report.reportTable.TextTableModel;

import java.util.Arrays;


/**
 * Unit tests for TextTableModel class.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 05.09.13)
*/

@SuppressWarnings("InstanceVariableMayNotBeInitialized")
public class TextTableModelTest {

    // empty data
    private String[]   emptyArray1 = new String[0];
    private String[][] emptyArray2 = new String[0][0];

    // non-empty headers/data
    private String[]   header1;
    private String[]   header1copy;
    private String[]   header2;
    private String[][] data1;
    private String[][] data2;
    // full-data variants
    private String[][] fullData1;
    private String[][] fullData2;
    private String[][] fullData3;
    private String[][] fullData4;
    // tables models variants
    private TextTableModel emptyModel = new TextTableModel(null, null);
    private TextTableModel emptyDataModel1;
    private TextTableModel emptyDataModel2;
    private TextTableModel emptyHeaderModel1;
    private TextTableModel emptyHeaderModel2;
    private TextTableModel nonEmptyDataModel1;
    private TextTableModel nonEmptyDataModel2;

    @BeforeClass
    public static void onlyOnceBeforeAll() {
        //System.out.println("once");
    }

    @Before
    /**
     * This method is executed before every test method and initializes environment for tests (we change this env.
     * in some tests - and it have to be restored before others.
    */
    public void beforeEveryTest() {
        // init headers/data
        header1     = new String[]   {"Column1", "Column2", "Column3"};
        header1copy = Arrays.copyOf(header1, header1.length);
        header2     = new String[]   {"Column1", "Column2", "Column3", null, ""};
        data1       = new String[][] {new String[] {"1-1", "1-2", "1-3"}, new String[] {"2-1", "2-2", "2-3"}};
        data2       = new String[][] {new String[] {"1-1", "1-2", "1-3"}, new String[] {"2-1", "2-2", "2-3"}, new String[] {null}, null};
        // init full-data
        fullData1   = new String[][] {header1};
        fullData2   = new String[][] {header1, data1[0], data1[1]};
        fullData3   = new String[][] {header2};
        fullData4   = new String[][] {header2, data2[0], data2[1], data2[2], data2[3]};
        // init tables models
        emptyDataModel1    = new TextTableModel(header1, null);
        emptyDataModel2    = new TextTableModel(header2, null);
        emptyHeaderModel1  = new TextTableModel(null, data1);
        emptyHeaderModel2  = new TextTableModel(null, data2);
        nonEmptyDataModel1 = new TextTableModel(header1, data1);
        nonEmptyDataModel2 = new TextTableModel(header2, data2);
    }

    @Test
    public void testConstructor() {
        // test empty model
        Assert.assertArrayEquals("Wrong empty model header", emptyArray1, emptyModel.getHeader());
        Assert.assertArrayEquals("Wrong empty model data", emptyArray2, emptyModel.getData());
        Assert.assertArrayEquals("Wrong empty model full data", emptyArray2, emptyModel.getFullData());
        // test model with empty data
        Assert.assertArrayEquals("Wrong header (empty data model)", header1, emptyDataModel1.getHeader());
        Assert.assertArrayEquals("Wrong data (empty data model)", emptyArray2, emptyDataModel1.getData());
        Assert.assertArrayEquals("Wrong full data (empty data model)", fullData1, emptyDataModel1.getFullData());
        // test model with empty header
        Assert.assertArrayEquals("Wrong header (empty header model)", emptyArray1, emptyHeaderModel1.getHeader());
        Assert.assertArrayEquals("Wrong data (empty header model)", data1, emptyHeaderModel1.getData());
        Assert.assertArrayEquals("Wrong full data (empty header model)", data1, emptyHeaderModel1.getFullData());
        // test non-empty model
        Assert.assertArrayEquals("Wrong header (non-empty model)", header1, nonEmptyDataModel1.getHeader());
        Assert.assertArrayEquals("Wrong data (non-empty model)", data1, nonEmptyDataModel1.getData());
        Assert.assertArrayEquals("Wrong full data (non-empty model)", fullData2, nonEmptyDataModel1.getFullData());
    }

    @Test
    public void testEmptyValues() {
        // test model with empty data
        Assert.assertArrayEquals("Wrong header (empty data model 2)", header2, emptyDataModel2.getHeader());
        Assert.assertArrayEquals("Wrong data (empty data model 2)", emptyArray2, emptyDataModel2.getData());
        Assert.assertArrayEquals("Wrong full data (empty data model 2)", fullData3, emptyDataModel2.getFullData());
        // test model with empty header
        Assert.assertArrayEquals("Wrong header (empty header model 2)", emptyArray1, emptyHeaderModel2.getHeader());
        Assert.assertArrayEquals("Wrong data (empty header model 2)", data2, emptyHeaderModel2.getData());
        Assert.assertArrayEquals("Wrong full data (empty header model 2)", data2, emptyHeaderModel2.getFullData());
        // test non-empty model
        Assert.assertArrayEquals("Wrong header (non-empty model 2)", header2, nonEmptyDataModel2.getHeader());
        Assert.assertArrayEquals("Wrong data (non-empty model 2)", data2, nonEmptyDataModel2.getData());
        Assert.assertArrayEquals("Wrong full data (non-empty model 2)", fullData4, nonEmptyDataModel2.getFullData());
    }

    @Test
    public void testIsEmptyMethod() {
        Assert.assertTrue("Empty model .isEmpty() wrong result (1)", emptyModel.isEmpty());
        Assert.assertFalse("Empty model .isEmpty() wrong result (2)", emptyHeaderModel1.isEmpty());
        Assert.assertFalse("Empty model .isEmpty() wrong result (3)", emptyDataModel1.isEmpty());
        Assert.assertFalse("Empty model .isEmpty() wrong result (4)", nonEmptyDataModel1.isEmpty());

        Assert.assertTrue("Empty model .isEmpty() wrong result (5)", new TextTableModel(emptyArray1, null).isEmpty());
        Assert.assertTrue("Empty model .isEmpty() wrong result (6)", new TextTableModel(null, emptyArray2).isEmpty());
        Assert.assertTrue("Empty model .isEmpty() wrong result (7)", new TextTableModel(emptyArray1, emptyArray2).isEmpty());
    }

    @Test
    public void testImmutability() {
        TextTableModel model = new TextTableModel(header1, data1);
        header1[0] = "ZZZZZZZZZZZZZZZZZZZZZZZZZZZ";
        Assert.assertTrue("Header array change broken", !Arrays.equals(header1, header1copy));
        Assert.assertArrayEquals("Immutability broken (1)", header1copy, model.getHeader());
    }

}
