package ru.kzgroup.dataReporter;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import ru.kzgroup.table.TextTableHelperTest;
import ru.kzgroup.table.TextTableModelTest;
import ru.kzgroup.table.TextTableTest;

/**
 * Test suite (accumulator class) for engine tests.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 03.09.13)
*/

@RunWith(value=Suite.class)
@Suite.SuiteClasses(value={TextTableHelperTest.class, TextTableModelTest.class, TextTableTest.class})
@SuppressWarnings("ClassMayBeInterface")
public class DataReporterTestSuite {}