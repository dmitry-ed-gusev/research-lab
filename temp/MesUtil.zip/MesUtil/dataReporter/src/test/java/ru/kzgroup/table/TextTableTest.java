package ru.kzgroup.table;

import junit.framework.Assert;
import org.junit.Test;
import ru.kzgroup.components.report.reportTable.TextTable;
import ru.kzgroup.components.report.reportTable.TextTableModel;

/**
 * Unit tests for TextTable reporting component class.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 04.09.13)
*/

public class TextTableTest {

    // empty TextTable
    private String         emptyTextTable = "-";
    // empty TextTableModels
    private TextTableModel emptyModel1    = new TextTableModel(null, null);
    private TextTableModel emptyModel2    = new TextTableModel(new String[0], null);
    private TextTableModel emptyModel3    = new TextTableModel(null, new String[0][0]);
    private TextTableModel emptyModel4    = new TextTableModel(new String[0], new String[0][0]);

    @Test
    public void testEmptyTextTable() {
        Assert.assertEquals("Invalid empty TextTable (1)", emptyTextTable, new TextTable(emptyModel1).getTextGrid());
        Assert.assertEquals("Invalid empty TextTable (2)", emptyTextTable, new TextTable(emptyModel2).getTextGrid());
        Assert.assertEquals("Invalid empty TextTable (3)", emptyTextTable, new TextTable(emptyModel3).getTextGrid());
        Assert.assertEquals("Invalid empty TextTable (4)", emptyTextTable, new TextTable(emptyModel4).getTextGrid());
    }

}