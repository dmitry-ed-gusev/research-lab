REM INSERTING into EXPORT_TABLE
SET DEFINE OFF;
Insert into EXPORT_TABLE ("Job","Log_user","Privilege_User","Schema_User","Last_Date","This_Date","Next_Date","Total_Time","Broken","Interval","Failures","What") values ('163','PMES','PMES','PMES',to_date('22.01.14','DD.MM.RR'),null,to_date('22.01.14','DD.MM.RR'),'729,999999999999999999999999999999999995','N','SYSDATE + 5/60/60/24','0','PMES.SP_PO_LEVEL2_INTERFACE_PROC;');
Insert into EXPORT_TABLE ("Job","Log_user","Privilege_User","Schema_User","Last_Date","This_Date","Next_Date","Total_Time","Broken","Interval","Failures","What") values ('164','PMES','PMES','PMES',to_date('22.01.14','DD.MM.RR'),null,to_date('22.01.14','DD.MM.RR'),'1236,999999999999999999999999999999999583','N','SYSDATE + 1/24','0','PMES.SP_SM_ORDER_INTERFACE_MAIN;');
