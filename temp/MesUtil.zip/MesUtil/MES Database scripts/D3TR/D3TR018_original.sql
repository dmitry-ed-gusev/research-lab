create or replace 
PROCEDURE      SP_TR_D3TR018 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR018        
 * VERSION           : V1.00                       
 * DESCRIPTION       : M900/680 Bundle weight information     
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
W_ERR_CODE              NUMBER;
W_ERR_MSG               VARCHAR2(250);

W_WEIGHING_TIME         VARCHAR2(19);
W_BUNDLE_WT             NUMBER;

  
BEGIN 
     
     INSERT INTO TB_PO_IF_PACKING_WEIGHING
           (TC_ID
           ,WEIGHING_DDTT
           ,WEIGHING_WT
           ,REG_DDTT
           ,REGISTER
           )
     SELECT 'D3TR018'
            ,TO_CHAR(TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS'),'YYYYMMDDHH24MISS')
            ,TRIM(ITEM_1)
            ,SYSDATE
            ,'SP_TR_D3TR018'   
       FROM TB_PO_LEVEL2_INTERFACE 
      WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
      
      
--     SP_TR_950_PACKING (IN_TC_ID,W_WEIGHING_TIME,W_BUNDLE_WT,W_ERR_CODE,W_ERR_MSG);
--     
--     IF  W_ERR_CODE IS NOT NULL  THEN 
--         RAISE_APPLICATION_ERROR(W_ERR_CODE,W_ERR_MSG);
--     END IF;                 
    COMMIT;
EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                             
END;