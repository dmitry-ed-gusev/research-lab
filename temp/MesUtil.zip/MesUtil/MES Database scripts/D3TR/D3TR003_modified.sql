create or replace 
PROCEDURE SP_TR_D3TR003 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR003      
 * VERSION           : V2.00                       
 * DESCRIPTION       : Temperture information of WBF
 * DEVELOPER NAME    : Lee
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 17.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D3TR003';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN
  --TB_PO_WBF_TEMPERATURE ----------
  BEGIN
    currentOperation := 'Operation [TB_PO_WBF_TEMPERATURE insert].'; -- current operation marker for error handling
    INSERT INTO TB_PO_WBF_TEMPERATURE (
                  MEASURING_TIME
                  ,NO1_FURNACE_ZONE1_TEMP
                  ,NO1_FURNACE_ZONE2_TEMP
                  ,NO2_FURNACE_ZONE1_TEMP
                  ,NO2_FURNACE_ZONE2_TEMP
                  ,REG_DDTT
                  ,REGISTER
                )
      SELECT TO_DATE(TRIM(ITEM), dateTimeTemplate)  --MEASURING_TIME
            ,TRIM(ITEM_1)                           --NO1_FURNACE_ZONE1_TEMP
            ,TRIM(ITEM_2)                           --NO1_FURNACE_ZONE2_TEMP
            ,TRIM(ITEM_3)                           --NO2_FURNACE_ZONE1_TEMP
            ,TRIM(ITEM_4)                           --NO2_FURNACE_ZONE2_TEMP
            ,SYSDATE
            ,defaultTelegramId
        FROM TB_PO_LEVEL2_INTERFACE 
        WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
  
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;