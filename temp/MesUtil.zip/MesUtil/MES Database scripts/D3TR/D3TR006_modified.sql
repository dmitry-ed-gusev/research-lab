create or replace 
PROCEDURE SP_TR_D3TR006 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR006      
 * VERSION           : V2.00                       
 * DESCRIPTION       : Entrance pass count of no.6 Stand
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 17.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D3TR006';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
meltNo              number;                 -- melt number
blankNo             number;                 -- blank number
measuringTime       date;
--prodYy              varchar(4);
--pon                 varchar(7);
--inputMaterialQnty   number;
--millResultQnty      number;
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

--W_MELT_NO               TB_PM_MILL_DAILY_PLAN.MELT_NO%TYPE;
--W_PROD_YY               VARCHAR2(4);
--W_PON                   VARCHAR2(7);
--W_MEASURING_TIME        DATE;
--W_INPUT_MATERIAL_QNTY   NUMBER; 
--W_MILL_RESULT_QNTY      NUMBER;

  
BEGIN
  RETURN;
  
  
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  -- select melt number, ingot number, blNK NUMBER
  SELECT to_number(TRIM(ITEM)), to_number(TRIM(ITEM_1)), TO_DATE(TRIM(ITEM_3), dateTimeTemplate)
    INTO  meltNo, blankNo, measuringTime
    FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = in_sequence_key;
      
    
--    SELECT TO_DATE(TRIM(C.ITEM_3),'DD-MM-YYYY HH24:MI:SS')
--          ,TRIM(C.ITEM)
--      INTO W_MEASURING_TIME
--          ,W_MELT_NO
--      FROM TB_PO_BLANK_COMM       A          
--          ,TB_PO_LEVEL2_INTERFACE C          
--     WHERE C.SEQUENCE_KEY = IN_SEQUENCE_KEY
--       AND A.MELT_NO      = TRIM(C.ITEM)
--       AND A.BLANK_NO     = TRIM(C.ITEM_1);
       
    -- TB_PM_MILL_DAILY_PLAN UPDATE 
--    UPDATE TB_PM_MILL_DAILY_PLAN
--       SET MILL_RESULT_QNTY = NVL(MILL_RESULT_QNTY,0) + 1
--     WHERE MILL_GP = '3'
--       AND PROD_YY = W_PROD_YY
--       AND PON     = W_PON;
       
    -- MONITORING CHECK & SET    
--    SELECT INPUT_MATERIAL_QNTY,MILL_RESULT_QNTY
--      INTO W_INPUT_MATERIAL_QNTY,W_MILL_RESULT_QNTY
--      FROM TB_PM_MILL_DAILY_PLAN
--     WHERE MILL_GP = '3'
--       AND PROD_YY = W_PROD_YY
--       AND PON     = W_PON;
       
--    IF  W_MILL_RESULT_QNTY = 1  THEN
    
        --  TB_PO_MILL_PON_RESULT UPDATE 
--        UPDATE TB_PO_MILL_PON_RESULT
--           SET MILL_START_DDTT = W_MEASURING_TIME - 1/24/60 
--               ,MILL_PETROL_DATE
--                = FN_PETRODATE(TO_CHAR(W_MEASURING_TIME,'YYYYMMDDHH24MISS'),'YYYYMMDDHH24MISS','YYYYMMDD') 
--               ,MOD_DDTT       = SYSDATE 
--               ,MODIFIER       = 'SP_TR_D3TR006'
--         WHERE MILL_GP = '3'
--           AND PROD_YY = W_PROD_YY
--           AND PON     = W_PON;
           
--        SP_TR_200_MONITOR  ('302'
--                           ,'H'
--                           ,W_MELT_NO
--                           ,TO_CHAR(W_MEASURING_TIME,'YYYYMMDDHH24MI')
--                           ,NULL
--                           ,'S'
--                           ,W_PROD_YY
--                           ,W_PON
--                           ,vERR_CODE 
--                           ,vERR_MSG 
--                          );
--    ELSIF  W_INPUT_MATERIAL_QNTY =  W_MILL_RESULT_QNTY THEN                   
--           SP_TR_200_MONITOR  ('302'
--                               ,'H'
--                               ,W_MELT_NO
--                               ,NULL
--                               ,TO_CHAR(W_MEASURING_TIME,'YYYYMMDDHH24MI')
--                               ,'E'
--                               ,W_PROD_YY
--                               ,W_PON
--                               ,vERR_CODE 
--                               ,vERR_MSG 
--                              );
--    END IF;                      
--    IF  vERR_MSG  IS NOT NULL  THEN        
--        RETURN;
--    END IF;

    --- END_DATE  UPDATE
--    UPDATE TB_PO_MILL_PON_RESULT
--       SET MILL_END_DDTT = W_MEASURING_TIME + 1/24/120 
--           ,MOD_DDTT     = SYSDATE 
--           ,MODIFIER     = 'SP_TR_D3TR006'
--     WHERE MILL_GP = '3'
--       AND PROD_YY = W_PROD_YY
--       AND PON     = W_PON;
--

  -- TB_PO_BLANK_COMM UPDATE ----------       
  BEGIN
    currentOperation := 'Operation [TB_PO_BLANK_COMM update].'; -- current operation marker for error handling
    UPDATE TB_PO_BLANK_COMM
      SET STAND_NO6_START_TIME  = measuringTime
          ,MOD_DDTT             = SYSDATE
          ,MODIFIER             = defaultTelegramId
      WHERE MELT_NO = meltNo and BLANK_NO = blankNo;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
  
  COMMIT;    

  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;