create or replace 
FUNCTION      FUN_FRACTURE
                                ( piPROD_YYMM      IN VARCHAR2
                                 ,piORD_NO1        IN VARCHAR2
                                 ,piORD_POSITION1  IN NUMBER
                                 ,piORD_NO2        IN VARCHAR2
                                 ,piORD_POSITION2  IN NUMBER
                                 ,piORD_NO3        IN VARCHAR2
                                 ,piORD_POSITION3  IN NUMBER
                                )         RETURN VARCHAR2
IS

    vFRACTURE                   VARCHAR2(1);
    vCORRECTION_PLAN_PROC_UW    TB_SM_ORDDTL_PROD.CORRECTION_PLAN_PROC_UW%TYPE;

BEGIN

    vFRACTURE   := NULL;

    SELECT MAX(CORRECTION_PLAN_PROC_UW)
      INTO vCORRECTION_PLAN_PROC_UW
      FROM (SELECT CORRECTION_PLAN_PROC_UW
              FROM TB_SM_ORDDTL_PROD X
             WHERE X.PROD_YYMM    = piPROD_YYMM
               AND X.ORD_NO       = piORD_NO1
               AND X.ORD_POSITION = piORD_POSITION1
            UNION ALL
            SELECT CORRECTION_PLAN_PROC_UW
              FROM TB_SM_ORDDTL_PROD X
             WHERE X.PROD_YYMM    = piPROD_YYMM
               AND X.ORD_NO       = piORD_NO2
               AND X.ORD_POSITION = piORD_POSITION2
            UNION ALL
            SELECT CORRECTION_PLAN_PROC_UW
              FROM TB_SM_ORDDTL_PROD X
             WHERE X.PROD_YYMM    = piPROD_YYMM
               AND X.ORD_NO       = piORD_NO3
               AND X.ORD_POSITION = piORD_POSITION3
           )
    ;

    IF vCORRECTION_PLAN_PROC_UW IS NOT NULL THEN
        vFRACTURE := '+';
    END IF;

    RETURN vFRACTURE;

EXCEPTION
    WHEN OTHERS THEN
        RETURN vFRACTURE;
END; 