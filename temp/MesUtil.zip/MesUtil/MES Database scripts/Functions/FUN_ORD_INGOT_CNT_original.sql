create or replace 
FUNCTION      FUN_ORD_INGOT_CNT
                                ( piMILL_GP         IN VARCHAR2
                                 ,piSECTION_TYPE    IN VARCHAR2
                                 ,piSECTION_SIZE_T  IN NUMBER
                                 ,piSECTION_SIZE_W  IN NUMBER
                                 ,piBLANK_KIND      IN VARCHAR2
                                )         RETURN NUMBER
IS

    vRESULT                     NUMBER;

    -- Variable For Program
    vMELT_YN                    VARCHAR2(10);
    vCNT                        NUMBER;

BEGIN

    vRESULT := 0;
    IF piMILL_GP = '9' THEN
        FOR C1 IN (SELECT PROD_YYMM
                         ,ORD_NO
                         ,ORD_POSITION
                         ,STLGRADE_CD
                     FROM TB_SM_ORDDTL
                    WHERE ORD_PROG_CD         = 'C'
                      AND MILL_GP             = piMILL_GP
                      AND R680_SECTION_TYPE   = piSECTION_TYPE
                      AND R680_SECTION_SIZE_T = piSECTION_SIZE_T
                      AND R680_SECTION_SIZE_W = piSECTION_SIZE_W
                      AND (NVL(INGOT_DESIGN_QNTY,0)
                         - NVL(INGOT_MPT_ORD_QNTY,0) ) > 0
--                        - NVL(INGOT_MATCH_QNTY,0) > 0
                  )
        LOOP
            vCNT := 0;
            FOR C11 IN (SELECT A.MELT_NO
                              ,B.STLGRADE_CD
                              ,COUNT(DISTINCT A.INGOT_KEY)   CNT
                          FROM TB_PO_INGOT_COMM     A
                              ,TB_QM_MELT_STL_GRADE B
                        WHERE A.PROG_CD     = 'F'
                          AND A.ORD_REM_GP  = '2'
                          AND A.MELT_NO     = B.MELT_NO
                          AND B.STLGRADE_CD = C1.STLGRADE_CD
                         GROUP BY A.MELT_NO
                                 ,B.STLGRADE_CD
                       )
            LOOP

                vMELT_YN := FUN_ORDER_MELT_YN(C1.PROD_YYMM ,C1.ORD_NO ,C1.ORD_POSITION, C11.MELT_NO, 'Y');

                IF vMELT_YN IN ('0','1') THEN
                    vRESULT  := vRESULT + C11.CNT;
                    vCNT     := vCNT    + C11.CNT;
                END IF;

            END LOOP;

        END LOOP;
    ELSE
        FOR C1 IN (SELECT PROD_YYMM
                         ,ORD_NO
                         ,ORD_POSITION
                         ,STLGRADE_CD
                     FROM TB_SM_ORDDTL
                    WHERE ORD_PROG_CD         = 'C'
                      AND MILL_GP             = piMILL_GP
                      AND R350_SECTION_TYPE   = piSECTION_TYPE
                      AND R350_SECTION_SIZE_T = piSECTION_SIZE_T
                      AND R350_SECTION_SIZE_W = piSECTION_SIZE_W
                      AND BLANK_KIND          = NVL(piBLANK_KIND, BLANK_KIND)
                      AND (NVL(INGOT_DESIGN_QNTY,0)
                         - NVL(INGOT_MPT_ORD_QNTY,0)) > 0
--                        - NVL(INGOT_MATCH_QNTY,0) > 0
                  )
        LOOP
            vCNT := 0;
            FOR C11 IN (SELECT A.MELT_NO
                              ,B.STLGRADE_CD
                              ,COUNT(DISTINCT A.INGOT_KEY)   CNT
                          FROM TB_PO_INGOT_COMM     A
                              ,TB_QM_MELT_STL_GRADE B
                        WHERE A.PROG_CD     = 'F'
                          AND A.ORD_REM_GP  = '2'
                          AND A.MELT_NO     = B.MELT_NO
                          AND B.STLGRADE_CD = C1.STLGRADE_CD
                         GROUP BY A.MELT_NO
                                 ,B.STLGRADE_CD
                       )
            LOOP

                vMELT_YN := FUN_ORDER_MELT_YN(C1.PROD_YYMM ,C1.ORD_NO ,C1.ORD_POSITION, C11.MELT_NO, 'Y');

                IF vMELT_YN IN ('0','1') THEN
                    vRESULT  := vRESULT + C11.CNT;
                    vCNT     := vCNT    + C11.CNT;
                END IF;

            END LOOP;

        END LOOP;    END IF;
    RETURN vRESULT;

EXCEPTION              
    WHEN OTHERS      THEN              
        RETURN -1;
END;