create or replace 
FUNCTION FN_PETRODATE (V_DATE IN VARCHAR2, V_IN_FORMAT  IN VARCHAR2, V_OUT_FORMAT IN VARCHAR2)
  RETURN VARCHAR2 IS
  
/*-----------------------------------------------------------------------------
 * PROGAM NAME       : FN_PETRODATE        
 * VERSION           : V1.00                       
 * DESCRIPTION       : function receive char representation of date/time, converts it to date,
                       shift forward for 59.99 minutes and again converts to characters. Converting
                       occured by date/time patterns, provided as function arguments.
 * DEVELOPER NAME    : someone from korean team :), Gusev D.               
 * CREATE DATE       : 2012              
 * MODIFY DATE       : 02.10.2013                                                       
*/-----------------------------------------------------------------------------

  V_RESULT VARCHAR2(08); 
BEGIN
  -- Accounted for one: this function shifts forward date/time value for 59.99 minutes. ????
  SELECT TO_CHAR(TO_DATE(V_DATE,V_IN_FORMAT) + ((60*59.99)/24/60/60), V_OUT_FORMAT)
    INTO V_RESULT FROM DUAL;
  RETURN V_RESULT;
END;