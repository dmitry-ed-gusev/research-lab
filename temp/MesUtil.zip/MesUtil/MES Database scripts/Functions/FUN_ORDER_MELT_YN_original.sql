create or replace 
FUNCTION      FUN_ORDER_MELT_YN
                                ( piPROD_YYMM       IN VARCHAR2
                                 ,piORD_NO          IN VARCHAR2
                                 ,piORD_POSITION    IN NUMBER
                                 ,piMELT_NO         IN NUMBER
                                 ,piINGOT_YN        IN VARCHAR2
                                )         RETURN VARCHAR2
IS

    vORD_GP                 TB_SM_ORDDTL.ORD_GP%TYPE;
    vMILL_GP                TB_SM_ORDDTL.MILL_GP%TYPE;
    vCONTRACT_NO            TB_SM_ORDCOMM.CONTRACT_NO%TYPE;
    vSTLGRADE_CD            TB_SM_ORDDTL.STLGRADE_CD%TYPE;
    vSTANDARD_KIND_CD       TB_QM_STANDARD.STANDARD_KIND_CD%TYPE;
    vSTANDARD_CD            TB_SM_ORDDTL.STANDARD_CD%TYPE;
    vCOUNT                  INTEGER;
    vDataFnd                INTEGER;

    vRESULT                 VARCHAR2(2);

BEGIN

    vRESULT   := '0';

    SELECT A.ORD_GP
          ,A.MILL_GP
          ,B.CONTRACT_NO
          ,A.STLGRADE_CD
          ,C.STANDARD_KIND_CD
          ,A.STANDARD_CD
      INTO vORD_GP
          ,vMILL_GP
          ,vCONTRACT_NO
          ,vSTLGRADE_CD
          ,vSTANDARD_KIND_CD
          ,vSTANDARD_CD
      FROM TB_SM_ORDDTL    A
          ,TB_SM_ORDCOMM   B
          ,TB_QM_STANDARD  C
     WHERE A.PROD_YYMM    = piPROD_YYMM
       AND A.ORD_NO       = piORD_NO
       AND A.ORD_POSITION = piORD_POSITION
       AND A.PROD_YYMM    = B.PROD_YYMM
       AND A.ORD_NO       = B.ORD_NO
       AND A.ORD_PROG_CD  = 'C'
       AND A.STANDARD_CD  = C.STANDARD_CD
    ;

    IF vMILL_GP = '9' THEN
        SELECT COUNT(*)
          INTO vCOUNT
          FROM TB_PO_MPT_RESULT
         WHERE MELT_NO          = piMELT_NO
           AND MILL350_ONLY_USE = '350'
        ;
        IF vCOUNT > 0 THEN
            RETURN '-1';
        END IF;
    END IF;

    IF piINGOT_YN = 'Y' THEN
        SELECT COUNT(*)
          INTO vCOUNT
          FROM TB_PO_INGOT_COMM
         WHERE MELT_NO     = piMELT_NO
           AND PROG_CD     = 'F'
           AND ORD_REM_GP  = '2'
        ;
    ELSE
        SELECT COUNT(*)
          INTO vCOUNT
          FROM TB_PO_BLANK_COMM
         WHERE MELT_NO     = piMELT_NO
           AND PROG_CD     = 'F'
           AND ORD_REM_GP  = '2'
        ;
    END IF;
    IF vCOUNT < 1 THEN
        RETURN '-1';
    END IF;


    vRESULT := FUN_MELT_INGR_YN(piPROD_YYMM ,piORD_NO ,piORD_POSITION ,piMELT_NO);
    IF vRESULT < '0' THEN
        RETURN '-1';
    END IF;


    vDataFnd  := 0;
    BEGIN
        SELECT COUNT(*)
          INTO vDataFnd
          FROM TB_QM_MELT_STL_GRADE          A
              ,TB_QM_MELT_STL_GRADE_STANDARD B
         WHERE A.MELT_NO     = piMELT_NO
           AND A.MELT_NO     = B.MELT_NO
           AND A.STLGRADE_CD = B.STLGRADE_CD
        ;
    EXCEPTION              
        WHEN OTHERS THEN              
            RETURN 'X';
    END;
    IF vDataFnd = 0 THEN
        vRESULT := '0';
        RETURN vRESULT;
    END IF;


    IF vSTANDARD_KIND_CD = '1' AND vORD_GP <> '1' THEN
        vSTANDARD_CD := 999;
    ELSIF vSTANDARD_KIND_CD = '6' THEN
        vSTANDARD_CD := 998;
    END IF;

    vRESULT   := '0';
    BEGIN
        SELECT '1'
          INTO vRESULT
          FROM (SELECT A.MELT_NO        ,A.STLGRADE_CD
                      ,B.STANDARD_CD    ,B.STANDARD_KIND_CD
                  FROM TB_QM_MELT_STL_GRADE          A
                      ,TB_QM_MELT_STL_GRADE_STANDARD B
                 WHERE A.MELT_NO     = piMELT_NO
                   AND A.MELT_NO     = B.MELT_NO
                   AND A.STLGRADE_CD = B.STLGRADE_CD
               )
         WHERE (STANDARD_KIND_CD = vSTANDARD_KIND_CD OR STANDARD_KIND_CD = '7')
           AND STLGRADE_CD     = vSTLGRADE_CD
           AND STANDARD_CD     = CASE WHEN STANDARD_KIND_CD  = '7' THEN vCONTRACT_NO
                                      ELSE vSTANDARD_CD
                                  END
        ;
    EXCEPTION              
        WHEN NO_DATA_FOUND THEN
            vRESULT := '0';
        WHEN OTHERS THEN
            RETURN 'X';
    END;

    vRESULT := FUN_MELT_INGR_YN(piPROD_YYMM ,piORD_NO ,piORD_POSITION ,piMELT_NO);
    IF vRESULT < '0' THEN
        RETURN '-1';
    END IF;


    RETURN vRESULT;

--    WITH SM_ORD_INFO AS
--       (SELECT X.PROD_YYMM      ,X.ORD_NO           ,X.ORD_POSITION
--              ,X.ORD_GP         ,X.MILL_GP          ,X.CONTRACT_NO
--              ,X.STLGRADE_CD    ,X.STANDARD_KIND_CD ,X.STANDARD_CD
--          FROM (SELECT A.PROD_YYMM      ,A.ORD_NO               ,A.ORD_POSITION
--                      ,A.ORD_GP         ,A.MILL_GP              ,B.CONTRACT_NO
--                      ,A.STLGRADE_CD    ,C.STANDARD_KIND_CD     ,A.STANDARD_CD
--                  FROM TB_SM_ORDDTL    A
--                      ,TB_SM_ORDCOMM   B
--                      ,TB_QM_STANDARD  C
--                 WHERE A.PROD_YYMM    = :piPROD_YYMM
--                   AND A.ORD_NO       = :piORD_NO
--                   AND A.ORD_POSITION = :piORD_POSITION
--                   AND A.PROD_YYMM    = B.PROD_YYMM
--                   AND A.ORD_NO       = B.ORD_NO
--                   AND A.ORD_PROG_CD  = 'C'
--                   AND A.STANDARD_CD  = C.STANDARD_CD
--               ) X
--       )
--    SELECT K.PROD_YYMM    ,K.ORD_NO            ,K.ORD_POSITION
--          ,K.ORD_GP       ,K.MILL_GP           ,K.CONTRACT_NO
--          ,K.STLGRADE_CD  ,K.STANDARD_KIND_CD  ,K.STANDARD_CD
--          ,K.MELT_NO      ,K.INGR_YN
--      FROM (SELECT X.PROD_YYMM    ,X.ORD_NO            ,X.ORD_POSITION
--                  ,X.ORD_GP       ,X.MILL_GP           ,X.CONTRACT_NO
--                  ,X.STLGRADE_CD  ,X.STANDARD_KIND_CD  ,X.STANDARD_CD
--                  ,Y.MELT_NO
--                  ,FUN_MELT_INGR_YN(X.PROD_YYMM   ,X.ORD_NO  ,X.ORD_POSITION  ,Y.MELT_NO) INGR_YN
--              FROM SM_ORD_INFO   X
--                  ,(SELECT A.MELT_NO        ,A.STLGRADE_CD
--                          ,B.STANDARD_CD    ,B.STANDARD_KIND_CD
--                      FROM TB_QM_MELT_STL_GRADE          A
--                          ,TB_QM_MELT_STL_GRADE_STANDARD B
--                          ,(SELECT DISTINCT MELT_NO
--                              FROM TB_PO_INGOT_COMM
--                             WHERE PROG_CD     = 'F'
--                               AND ORD_REM_GP  = '2'
--                           ) C
--                     WHERE A.MELT_NO     = B.MELT_NO
--                       AND A.STLGRADE_CD = B.STLGRADE_CD
--                       AND A.MELT_NO     = C.MELT_NO
--                   ) Y
--             WHERE (Y.STANDARD_KIND_CD = X.STANDARD_KIND_CD OR Y.STANDARD_KIND_CD = '7')
--               AND Y.STLGRADE_CD       = X.STLGRADE_CD
--               AND Y.STANDARD_CD       = CASE WHEN X.STANDARD_KIND_CD  = '1' AND X.ORD_GP <> '1' THEN 999
--                                              WHEN X.STANDARD_KIND_CD  = '6'                     THEN 998
--                                              WHEN Y.STANDARD_KIND_CD  = '7'                     THEN X.CONTRACT_NO
--                                              ELSE X.STANDARD_CD
--                                          END
--           ) K
--          ,TB_PO_MPT_RESULT H
--     WHERE K.MELT_NO = H.MELT_NO
--       AND ((K.MILL_GP = '9' AND H.MILL350_ONLY_USE <> '350') OR K.MILL_GP = '3')
--       AND K.INGR_YN          IN ('0','1')
--    ;

EXCEPTION              
    WHEN OTHERS      THEN              
        RETURN 'X';
END; 