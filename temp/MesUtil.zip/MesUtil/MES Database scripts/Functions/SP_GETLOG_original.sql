create or replace 
function sp_getlog
 return varchar2 is
  S varchar2(10000);
  L varchar2(1000);  
  I integer;
begin
  DBMS_Output.Get_Line(L,I);
  while I=0 loop
    S:= S || L || chr(10) || chr(13); 
    DBMS_Output.Get_Line(L,I);
  end loop;
  Return(S); 
end sp_getlog;
