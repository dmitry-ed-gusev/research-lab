create or replace 
FUNCTION      FUN_SM_ORD_EXTRA_LIST
                                ( piPROD_YYMM           IN VARCHAR2
                                 ,piORD_NO              IN VARCHAR2
                                 ,piORD_POSITION        IN NUMBER
                                )         RETURN VARCHAR2
IS


   vRESULT      VARCHAR2(4000);
   vFetchCnt    INTEGER;

BEGIN

    vRESULT   := NULL;

    vFetchCnt := 0;
    FOR C1 IN (SELECT DISTINCT EXTRA_ITEM_NAME
                 FROM (SELECT EXTRA_ITEM_CD
                             ,TRIM(EXTRA_ITEM_NAME) EXTRA_ITEM_NAME
                         FROM TB_SM_ORD_EXTRA_ITEM
                        WHERE PROD_YYMM    = piPROD_YYMM
                          AND ORD_NO       = piORD_NO
                          AND ORD_POSITION = piORD_POSITION
                        ORDER BY EXTRA_ITEM_CD
                      )
              )
    LOOP
        vFetchCnt := vFetchCnt + 1;

        IF vFetchCnt > 1 THEN
            vRESULT :=  vRESULT ||', ';
        END IF;
        vRESULT := vRESULT || C1.EXTRA_ITEM_NAME;

    END LOOP;
    vRESULT := REPLACE(vRESULT ,'>', ' +');
    vRESULT := REPLACE(vRESULT ,'<', ' -');

    RETURN vRESULT;
END; 