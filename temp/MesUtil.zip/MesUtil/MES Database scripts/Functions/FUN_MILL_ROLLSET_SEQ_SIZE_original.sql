create or replace 
FUNCTION      FUN_MILL_ROLLSET_SEQ_SIZE (piMILL_GP             IN VARCHAR2
                                                         , piSEQ                 IN NUMBER
                                                         , piMATERIAL_APPEARANCE IN VARCHAR2
                                                         , piSECTION_TYPE        IN VARCHAR2
                                                          )         RETURN VARCHAR2
IS

   vRESULT      VARCHAR2(4000);
   vFetchCnt    INTEGER;

BEGIN

    vRESULT   := NULL;
    vFetchCnt := 0;
    FOR C1 IN (SELECT SECTION_SIZE_T
                     ,SECTION_SIZE_W
                     ,ROUND(WT / 1000)          AS WT
                 FROM TB_PM_MILL_ROLLSET_SEQ
                WHERE MILL_GP             = piMILL_GP
                  AND SEQ                 = piSEQ
                  AND MATERIAL_APPEARANCE = piMATERIAL_APPEARANCE
                  AND SECTION_TYPE        = piSECTION_TYPE
                ORDER BY SECTION_SIZE_T ,SECTION_SIZE_W
              )
    LOOP
        vFetchCnt := vFetchCnt + 1;

        IF vFetchCnt > 1 THEN
            vRESULT := vRESULT || ', ';
        END IF;

        IF C1.SECTION_SIZE_T = C1.SECTION_SIZE_W THEN
            vRESULT := vRESULT || C1.SECTION_SIZE_T;
        ELSE
            vRESULT := vRESULT || C1.SECTION_SIZE_T ||'x' || C1.SECTION_SIZE_W;
        END IF;
        vRESULT := vRESULT || '(' || C1.WT || ')';

    END LOOP;

    RETURN vRESULT;
END
; 