create or replace 
FUNCTION      FUN_MELT_INGR_SPEC_LIST
                                ( piMELT_SEQ        IN NUMBER
                                )         RETURN VARCHAR2
IS

   vRESULT      VARCHAR2(4000);
   vFetchCnt    INTEGER;

BEGIN

    vRESULT   := NULL;
    vFetchCnt := 0;

    FOR C1 IN (SELECT DISTINCT ORD_INGR_SPEC    ,ORD_INGR_SPEC_UPPER
                 FROM (
               SELECT B.ORD_INGR_SPEC1          ORD_INGR_SPEC
                     ,UPPER(B.ORD_INGR_SPEC1)   ORD_INGR_SPEC_UPPER
                 FROM TB_PM_MELT_DESIGN_WORKING A
                     ,TB_SM_ORDDTL              B
                WHERE 1 = 1
                  AND A.MELT_SEQ     = piMELT_SEQ
                  AND A.PROD_YYMM    = B.PROD_YYMM
                  AND A.ORD_NO       = B.ORD_NO
                  AND A.ORD_POSITION = B.ORD_POSITION
                  AND B.ORD_INGR_SPEC1 IS NOT NULL
               UNION ALL
               SELECT B.ORD_INGR_SPEC2          ORD_INGR_SPEC
                     ,UPPER(B.ORD_INGR_SPEC2)   ORD_INGR_SPEC_UPPER
                 FROM TB_PM_MELT_DESIGN_WORKING A
                     ,TB_SM_ORDDTL              B
                WHERE 1 = 1
                  AND A.MELT_SEQ     = piMELT_SEQ
                  AND A.PROD_YYMM    = B.PROD_YYMM
                  AND A.ORD_NO       = B.ORD_NO
                  AND A.ORD_POSITION = B.ORD_POSITION
                  AND B.ORD_INGR_SPEC2 IS NOT NULL
               UNION ALL
               SELECT B.ORD_INGR_SPEC3          ORD_INGR_SPEC
                     ,UPPER(B.ORD_INGR_SPEC3)   ORD_INGR_SPEC_UPPER
                 FROM TB_PM_MELT_DESIGN_WORKING A
                     ,TB_SM_ORDDTL              B
                WHERE 1 = 1
                  AND A.MELT_SEQ     = piMELT_SEQ
                  AND A.PROD_YYMM    = B.PROD_YYMM
                  AND A.ORD_NO       = B.ORD_NO
                  AND A.ORD_POSITION = B.ORD_POSITION
                  AND B.ORD_INGR_SPEC3 IS NOT NULL
               UNION ALL
               SELECT B.ORD_INGR_SPEC4          ORD_INGR_SPEC
                     ,UPPER(B.ORD_INGR_SPEC4)   ORD_INGR_SPEC_UPPER
                 FROM TB_PM_MELT_DESIGN_WORKING A
                     ,TB_SM_ORDDTL              B
                WHERE 1 = 1
                  AND A.MELT_SEQ     = piMELT_SEQ
                  AND A.PROD_YYMM    = B.PROD_YYMM
                  AND A.ORD_NO       = B.ORD_NO
                  AND A.ORD_POSITION = B.ORD_POSITION
                  AND B.ORD_INGR_SPEC4 IS NOT NULL
               UNION ALL
               SELECT B.ORD_INGR_SPEC5          ORD_INGR_SPEC
                     ,UPPER(B.ORD_INGR_SPEC5)   ORD_INGR_SPEC_UPPER
                 FROM TB_PM_MELT_DESIGN_WORKING A
                     ,TB_SM_ORDDTL              B
                WHERE 1 = 1
                  AND A.MELT_SEQ     = piMELT_SEQ
                  AND A.PROD_YYMM    = B.PROD_YYMM
                  AND A.ORD_NO       = B.ORD_NO
                  AND A.ORD_POSITION = B.ORD_POSITION
                  AND B.ORD_INGR_SPEC5 IS NOT NULL
                  )
              ORDER BY ORD_INGR_SPEC_UPPER
              )
    LOOP
        vFetchCnt := vFetchCnt + 1;

        IF vFetchCnt > 1 THEN
            vRESULT :=  vRESULT ||'; ';
        END IF;
        vRESULT := vRESULT || C1.ORD_INGR_SPEC;

    END LOOP;
    vRESULT := REPLACE(vRESULT ,'>', ' +');
    vRESULT := REPLACE(vRESULT ,'<', ' -');


    RETURN vRESULT;
END; 