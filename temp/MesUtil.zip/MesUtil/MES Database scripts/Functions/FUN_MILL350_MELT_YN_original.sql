create or replace 
FUNCTION      FUN_MILL350_MELT_YN
                                ( piPROD_YYMM        IN VARCHAR2
                                 ,piORD_NO           IN VARCHAR2
                                 ,piORD_POSITION     IN NUMBER
                                 ,piORD_INGR_SPEC    IN VARCHAR2
                                 ,piMELT_NO          IN NUMBER
                                 ,piSTANDARD         IN  NUMBER
                                 ,piORD_GP           IN VARCHAR2
                                 ,piCONTRACT_NO      IN NUMBER
                                 ,piSTLGRADE_CD      IN NUMBER
                                 ,piSTANDARD_KIND_CD IN NUMBER
                                 ,piSTANDARD_CD      IN NUMBER
                                )         RETURN VARCHAR2
IS

    vSTANDARD_CD            TB_SM_ORDDTL.STANDARD_CD%TYPE;

    vCOUNT                  INTEGER;
    vDataFnd                INTEGER;

    vRESULT                 VARCHAR2(2);

BEGIN

    vRESULT      := '0';

    IF piORD_INGR_SPEC IS NOT NULL THEN
        vRESULT := FUN_MELT_INGR_YN(piPROD_YYMM ,piORD_NO ,piORD_POSITION ,piMELT_NO);
        IF vRESULT < '0' THEN
            RETURN '-1';
        END IF;
    END IF;

    IF piSTANDARD IS NULL THEN
        RETURN '0';
    END IF;


    vSTANDARD_CD := piSTANDARD_CD;
    IF piSTANDARD_KIND_CD = '1' AND piORD_GP <> '1' THEN
        vSTANDARD_CD := 999;
    ELSIF piSTANDARD_KIND_CD = '6' THEN
        vSTANDARD_CD := 998;
    END IF;

    vRESULT   := '0';
    BEGIN
        SELECT '1'
          INTO vRESULT
          FROM (SELECT A.MELT_NO        ,A.STLGRADE_CD
                      ,B.STANDARD_CD    ,B.STANDARD_KIND_CD
                  FROM TB_QM_MELT_STL_GRADE          A
                      ,TB_QM_MELT_STL_GRADE_STANDARD B
                 WHERE A.MELT_NO     = piMELT_NO
                   AND A.MELT_NO     = B.MELT_NO
                   AND A.STLGRADE_CD = B.STLGRADE_CD
               )
         WHERE (STANDARD_KIND_CD = piSTANDARD_KIND_CD OR STANDARD_KIND_CD = '7')
           AND STLGRADE_CD     = piSTLGRADE_CD
           AND STANDARD_CD     = CASE WHEN STANDARD_KIND_CD  = '7' THEN piCONTRACT_NO
                                      ELSE vSTANDARD_CD
                                  END
        ;
    EXCEPTION              
        WHEN NO_DATA_FOUND THEN
            vRESULT := '0';
        WHEN OTHERS THEN
            RETURN 'X';
    END;


    RETURN vRESULT;

EXCEPTION              
    WHEN OTHERS      THEN              
        RETURN 'X';
END; 