create or replace 
FUNCTION      FUN_ORD_INGR_SPEC_LIST
                                ( piPROD_YYMM           IN VARCHAR2
                                , piORD_NO              IN VARCHAR2
                                , piORD_POSITION        IN NUMBER
                                )         RETURN VARCHAR2
IS

   vRESULT      VARCHAR2(4000);
   vFetchCnt    INTEGER;

BEGIN

    vRESULT   := NULL;
    vFetchCnt := 0;

    FOR C1 IN (SELECT DISTINCT ORD_INGR_SPEC  ,ORD_INGR_SPEC_UPPER
                 FROM (
               SELECT ORD_INGR_SPEC1            ORD_INGR_SPEC
                     ,UPPER(ORD_INGR_SPEC1)     ORD_INGR_SPEC_UPPER
                 FROM TB_SM_ORDDTL
                WHERE PROD_YYMM    = piPROD_YYMM
                  AND ORD_NO       = piORD_NO
                  AND ORD_POSITION = piORD_POSITION
                  AND ORD_INGR_SPEC1 IS NOT NULL
               UNION ALL
               SELECT ORD_INGR_SPEC2      ORD_INGR_SPEC
                     ,UPPER(ORD_INGR_SPEC2)     ORD_INGR_SPEC_UPPER
                 FROM TB_SM_ORDDTL
                WHERE PROD_YYMM    = piPROD_YYMM
                  AND ORD_NO       = piORD_NO
                  AND ORD_POSITION = piORD_POSITION
                  AND ORD_INGR_SPEC2 IS NOT NULL
               UNION ALL
               SELECT ORD_INGR_SPEC3      ORD_INGR_SPEC
                     ,UPPER(ORD_INGR_SPEC3)     ORD_INGR_SPEC_UPPER
                 FROM TB_SM_ORDDTL
                WHERE PROD_YYMM    = piPROD_YYMM
                  AND ORD_NO       = piORD_NO
                  AND ORD_POSITION = piORD_POSITION
                  AND ORD_INGR_SPEC3 IS NOT NULL
               UNION ALL
               SELECT ORD_INGR_SPEC4      ORD_INGR_SPEC
                     ,UPPER(ORD_INGR_SPEC4)     ORD_INGR_SPEC_UPPER
                 FROM TB_SM_ORDDTL
                WHERE PROD_YYMM    = piPROD_YYMM
                  AND ORD_NO       = piORD_NO
                  AND ORD_POSITION = piORD_POSITION
                  AND ORD_INGR_SPEC4 IS NOT NULL
               UNION ALL
               SELECT ORD_INGR_SPEC5      ORD_INGR_SPEC
                     ,UPPER(ORD_INGR_SPEC5)     ORD_INGR_SPEC_UPPER
                 FROM TB_SM_ORDDTL
                WHERE PROD_YYMM    = piPROD_YYMM
                  AND ORD_NO       = piORD_NO
                  AND ORD_POSITION = piORD_POSITION
                  AND ORD_INGR_SPEC5 IS NOT NULL
                  )
              ORDER BY ORD_INGR_SPEC_UPPER
              )
    LOOP
        vFetchCnt := vFetchCnt + 1;

        IF vFetchCnt > 1 THEN
            vRESULT :=  vRESULT ||'; ';
        END IF;
        vRESULT := vRESULT || C1.ORD_INGR_SPEC;

        vRESULT := REPLACE(vRESULT ,'>', ' +');
        vRESULT := REPLACE(vRESULT ,'<', ' -');

    END LOOP;

    RETURN vRESULT;
END; 