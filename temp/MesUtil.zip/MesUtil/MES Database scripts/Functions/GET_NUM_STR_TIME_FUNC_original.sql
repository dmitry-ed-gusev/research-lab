create or replace 
FUNCTION      GET_NUM_STR_TIME_FUNC
                                    (piNUM_TIME     IN  NUMBER                  -- NUMBER TIME (Second)
                                    ,piTIME_TYPE    IN  VARCHAR2    DEFAULT 'S' -- TIME TYPE (S:HH24:MI:SS, M:HH24:MI, H:HH24)
                                    )   RETURN  VARCHAR2
IS

    vRESULT     VARCHAR2(10);    -- STRING TIME (HH24:MI:SS)
    vNUM_TIME   NUMBER;
    vHOUR       VARCHAR2(4);
    vMINUTE     VARCHAR2(2);
    vSECOND     VARCHAR2(2);

BEGIN

    --IF piNUM_TIME IS NULL OR piNUM_TIME = 0 THEN
    IF piNUM_TIME IS NULL THEN
        RETURN NULL; 
    END IF;

    vNUM_TIME := ROUND(piNUM_TIME);

    SELECT FLOOR(vNUM_TIME  / (60 * 60))
          ,LPAD(FLOOR (MOD(vNUM_TIME / 60, 60)),2,0)
          ,LPAD(FLOOR (MOD(vNUM_TIME,      60)),2,0)
      INTO vHOUR
          ,vMINUTE
          ,vSECOND
      FROM DUAL
    ;


    IF LENGTHB(vHOUR) = 0 THEN
        vHOUR := '00';
    ELSIF LENGTHB(vHOUR) = 1 THEN
        vHOUR := '0' || vHOUR;
    END IF;

    IF piTIME_TYPE = 'H' THEN
        vRESULT := vHOUR;
    ELSIF piTIME_TYPE = 'M' THEN
        vRESULT := vHOUR || ':' || vMINUTE;
    ELSE
        vRESULT := vHOUR || ':' || vMINUTE || ':' || NVL(vSECOND,'00');
    END IF;

    RETURN vRESULT;

END; 