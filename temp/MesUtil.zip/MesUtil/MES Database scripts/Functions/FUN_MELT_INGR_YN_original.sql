create or replace 
FUNCTION      FUN_MELT_INGR_YN
                                ( piPROD_YYMM       IN VARCHAR2
                                 ,piORD_NO          IN VARCHAR2
                                 ,piORD_POSITION    IN NUMBER
                                 ,piMELT_NO         IN NUMBER
                                )         RETURN VARCHAR2
IS

    vSQL            VARCHAR2(100);
    vVAL            NUMBER;
    vYN             VARCHAR2(1) := 'Y';
    vRESULT         VARCHAR2(2);

BEGIN

    vRESULT   := '0';
    FOR C1 IN (SELECT UPPER(INGR_CD)        INGR_CD
                     ,NVL(INGR_MIN,0)       INGR_MIN
                     ,NVL(INGR_MAX,9.9999)  INGR_MAX
                 FROM TB_SM_ORD_INGR
                WHERE PROD_YYMM    = piPROD_YYMM
                  AND ORD_NO       = piORD_NO
                  AND ORD_POSITION = piORD_POSITION
              )
    LOOP
        vRESULT   := '1';

        vSQL    := 'SELECT ' || C1.INGR_CD || '_VAL FROM TB_QM_STL_ANALYSIS_INGR '
                || ' WHERE MELT_NO = :MELT_NO AND LAST_YN  = :LAST_YN';

        EXECUTE IMMEDIATE vSQL INTO vVAL USING piMELT_NO ,vYN;

        IF vVAL < C1.INGR_MIN OR vVAL > C1.INGR_MIN THEN
            RETURN '-1';
        END IF;

    END LOOP;

    RETURN vRESULT;

EXCEPTION              
    WHEN OTHERS      THEN              
        RETURN 'X';
END; 