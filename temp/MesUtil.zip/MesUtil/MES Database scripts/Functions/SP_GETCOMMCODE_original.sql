create or replace 
FUNCTION      SP_GETCOMMCODE (V_CDID      IN VARCHAR2 -- PM001
                                              , V_CDVAL     IN VARCHAR2 -- 350, 680, 900
                                              , V_GRPNUM    IN VARCHAR2 -- GROUP1, GROUP2, GROUP3, GROUP4
                                              , V_GRPVAL    IN VARCHAR2 -- GROUP VALUE
                                              , LANG_1      IN VARCHAR2 -- Native language
                                              , LANG_2      IN VARCHAR2 -- Conversion language
)
    RETURN VARCHAR2
IS
   V_RESULT   VARCHAR2(20); 
BEGIN
    IF V_GRPNUM = 'GROUP1' THEN
        SELECT DECODE(C1.CD_ITEM, '', B1.CD_ITEM, C1.CD_ITEM) INTO V_RESULT
        FROM TB_CM_CDITEM A1
        , (SELECT * FROM TB_CM_CDITEM_LANG WHERE LANG_GP = LANG_1) B1  /* Native language */
        , (SELECT * FROM TB_CM_CDITEM_LANG WHERE LANG_GP = LANG_2) C1  /* Conversion language */
        WHERE A1.CD_ID  = B1.CD_ID(+)
        AND A1.CD_ITEM  = B1.CD_ITEM(+)
        AND A1.CD_ID    = C1.CD_ID(+)
        AND A1.CD_ITEM  = C1.CD_ITEM(+)
        AND A1.GRP_CD_1 = V_GRPVAL
        AND A1.CD_ITEM  = V_CDVAL;
    ELSIF V_GRPNUM = 'GROUP2' THEN
        SELECT DECODE(C1.CD_ITEM, '', B1.CD_ITEM, C1.CD_ITEM) INTO V_RESULT
        FROM TB_CM_CDITEM A1
        , (SELECT * FROM TB_CM_CDITEM_LANG WHERE LANG_GP = LANG_1) B1  /* Native language */
        , (SELECT * FROM TB_CM_CDITEM_LANG WHERE LANG_GP = LANG_2) C1  /* Conversion language */
        WHERE A1.CD_ID  = B1.CD_ID(+)
        AND A1.CD_ITEM  =  B1.CD_ITEM(+)
        AND A1.CD_ID    = C1.CD_ID(+)
        AND A1.CD_ITEM  = C1.CD_ITEM(+)
        AND A1.GRP_CD_2 = V_GRPVAL
        AND A1.CD_ITEM  = V_CDVAL;
    ELSIF V_GRPNUM = 'GROUP3' THEN
        SELECT DECODE(C1.CD_ITEM, '', B1.CD_ITEM, C1.CD_ITEM) INTO V_RESULT
        FROM TB_CM_CDITEM A1
        , (SELECT * FROM TB_CM_CDITEM_LANG WHERE LANG_GP = LANG_1) B1  /* Native language */
        , (SELECT * FROM TB_CM_CDITEM_LANG WHERE LANG_GP = LANG_2) C1  /* Conversion language */
        WHERE A1.CD_ID  = B1.CD_ID(+)
        AND A1.CD_ITEM  = B1.CD_ITEM(+)
        AND A1.CD_ID    = C1.CD_ID(+)
        AND A1.CD_ITEM  = C1.CD_ITEM(+)
        AND A1.GRP_CD_3 = V_GRPVAL
        AND A1.CD_ITEM  = V_CDVAL;
    ELSIF V_GRPNUM = 'GROUP4' THEN
        SELECT DECODE(C1.CD_ITEM, '', B1.CD_ITEM, C1.CD_ITEM) INTO V_RESULT
        FROM TB_CM_CDITEM A1
        , (SELECT * FROM TB_CM_CDITEM_LANG WHERE LANG_GP = LANG_1) B1  /* Native language */
        , (SELECT * FROM TB_CM_CDITEM_LANG WHERE LANG_GP = LANG_2) C1  /* Conversion language */
        WHERE A1.CD_ID  = B1.CD_ID(+)
        AND A1.CD_ITEM  = B1.CD_ITEM(+)
        AND A1.CD_ID    = C1.CD_ID(+)
        AND A1.CD_ITEM  = C1.CD_ITEM(+)
        AND A1.GRP_CD_4 = V_GRPVAL
        AND A1.CD_ITEM  = V_CDVAL;
    END IF;
        SELECT DECODE(C1.CD_ITEM, '', B1.CD_ITEM, C1.CD_ITEM) INTO V_RESULT
        FROM TB_CM_CDITEM A1
        , (SELECT * FROM TB_CM_CDITEM_LANG WHERE LANG_GP = LANG_1) B1  /* Native language */
        , (SELECT * FROM TB_CM_CDITEM_LANG WHERE LANG_GP = LANG_2) C1  /* Conversion language */
        WHERE A1.CD_ID = B1.CD_ID(+)
        AND A1.CD_ITEM = B1.CD_ITEM(+)
        AND A1.CD_ID   = C1.CD_ID(+)
        AND A1.CD_ITEM = C1.CD_ITEM(+)
        AND A1.CD_ITEM = V_CDVAL;
   RETURN V_RESULT;
END SP_GETCOMMCODE
; 