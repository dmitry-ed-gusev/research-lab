create or replace 
FUNCTION      FUN_SIMILAR_MELT_NO_LIST
                                ( piMILL_GP             IN VARCHAR2
                                 ,piMELT_NO             IN NUMBER
                                 ,piSTLGRADE_CD         IN NUMBER
                                 ,piCHARGE_RESULT_QNTY  IN NUMBER
                                )         RETURN VARCHAR2
IS

   vRESULT      VARCHAR2(4000);
   vFetchCnt    INTEGER;

BEGIN

    vRESULT   := NULL;

    IF NVL(piCHARGE_RESULT_QNTY,0) <> 0 THEN
        RETURN NULL;
    END IF;

    vFetchCnt := 0;
    FOR C1 IN (SELECT DISTINCT MELT_NO
                 FROM TB_PO_BLANK_COMM
                WHERE piMILL_GP   = '3'
                  AND STATUS      = '2'
                  AND MELT_NO    <> piMELT_NO
                  AND STLGRADE_CD = piSTLGRADE_CD
                  AND PROG_CD    IN ('F','E','J')
               UNION ALL
               SELECT DISTINCT MELT_NO
                 FROM TB_PO_INGOT_COMM
                WHERE piMILL_GP   = '9'
                  AND MELT_NO    <> piMELT_NO
                  AND STLGRADE_CD = piSTLGRADE_CD
                  AND PROG_CD    IN ('F','E','J')
              ORDER BY MELT_NO
              )
    LOOP
        vFetchCnt := vFetchCnt + 1;

        IF vFetchCnt > 1 THEN
            vRESULT :=  vRESULT ||', ';
        END IF;
        vRESULT := vRESULT || C1.MELT_NO;

    END LOOP;

    RETURN vRESULT;
END; 