create or replace 
FUNCTION      FUN_ORD_BLANK_CNT_BK01
                                ( piSECTION_TYPE    IN VARCHAR2
                                 ,piSECTION_SIZE_T  IN NUMBER
                                 ,piSECTION_SIZE_W  IN NUMBER
                                )         RETURN NUMBER
IS

    -- Variable For Program
    vSTAND_NO_CD                TB_PM_BLANK_SECTION_SIZE_STD.STAND_NO_CD%TYPE;
    vBLANK_KIND_1               TB_PM_BLANK_SECTION_SIZE_STD.BLANK_KIND_1%TYPE;
    vBLANK_KIND_2               TB_PM_BLANK_SECTION_SIZE_STD.BLANK_KIND_2%TYPE;
    vBLANK_KIND_3               TB_PM_BLANK_SECTION_SIZE_STD.BLANK_KIND_3%TYPE;
    vBLANK_KIND_4               TB_PM_BLANK_SECTION_SIZE_STD.BLANK_KIND_4%TYPE;

    vMELT_YN                    VARCHAR2(10);

    vRESULT                     NUMBER;

BEGIN


    SELECT DECODE(MAX(STAND_NO_CD),'8','8',MAX(STAND_NO_CD))
      INTO vSTAND_NO_CD
      FROM TB_PM_BLANK_SECTION_SIZE_STD
     WHERE SECTION_TYPE   = piSECTION_TYPE
       AND SECTION_SIZE_T = piSECTION_SIZE_T
       AND SECTION_SIZE_W = piSECTION_SIZE_W
    ;


    SELECT BLANK_KIND_1
          ,BLANK_KIND_2
          ,BLANK_KIND_3
          ,BLANK_KIND_4
      INTO vBLANK_KIND_1
          ,vBLANK_KIND_2
          ,vBLANK_KIND_3
          ,vBLANK_KIND_4
      FROM TB_PM_BLANK_SECTION_SIZE_STD
     WHERE SECTION_TYPE   = piSECTION_TYPE
       AND SECTION_SIZE_T = piSECTION_SIZE_T
       AND SECTION_SIZE_W = piSECTION_SIZE_W
       AND STAND_NO_CD    = vSTAND_NO_CD
    ;

    vRESULT := 0;
    FOR C1 IN (SELECT B.PROD_YYMM 
                     ,B.ORD_NO
                     ,B.ORD_POSITION
                     ,B.STLGRADE_CD
                 FROM TB_PM_DAILY_SECTION_SIZE_SEQ  A
                     ,TB_SM_ORDDTL                  B
                WHERE A.MILL_GP         = '3'
                  AND NVL(A.SEQ,0)      = 0
                  AND A.SECTION_TYPE    = piSECTION_TYPE
                  AND A.SECTION_SIZE_T  = piSECTION_SIZE_T
                  AND A.SECTION_SIZE_W  = piSECTION_SIZE_W
                  AND (A.STAND_NO_CD IS NULL OR A.STAND_NO_CD = vSTAND_NO_CD)
                  AND A.MILL_GP         = B.MILL_GP
                  AND A.SECTION_TYPE    = B.R350_SECTION_TYPE
                  AND A.SECTION_SIZE_T  = B.R350_SECTION_SIZE_T
                  AND A.SECTION_SIZE_W  = B.R350_SECTION_SIZE_W
                  AND (NVL(B.ORD_WT,0) - NVL(B.BLANK_MATCH_WT,0))   > 0    
                  AND B.SALE_GP         = '0'
                  AND B.ORD_PROG_CD     = 'C' 
                  AND B.PROD_END_YN     IS NULL
                ORDER BY  B.DELIVER_DD
                         ,B.ORD_GP
              )
    LOOP
        FOR C11 IN (SELECT MELT_NO
                          ,SUM(BLANK_WT)    BLANK_WT
                      FROM (SELECT A.MELT_NO
                                  ,A.BLANK_WT
                              FROM TB_PO_BLANK_COMM     A
                                  ,TB_QM_MELT_STL_GRADE B
                             WHERE A.PROG_CD     = 'F'
                               AND A.ORD_REM_GP  = '2'
                               AND A.STATUS      = '2'
                               AND A.BLANK_KIND  = vBLANK_KIND_1
                               AND A.MELT_NO     = B.MELT_NO
                               AND B.STLGRADE_CD = C1.STLGRADE_CD
                            UNION ALL
                            SELECT A.MELT_NO
                                  ,A.BLANK_WT
                              FROM TB_PO_BLANK_COMM     A
                                  ,TB_QM_MELT_STL_GRADE B
                             WHERE A.PROG_CD     = 'F'
                               AND A.ORD_REM_GP  = '2'
                               AND A.STATUS      = '2'
                               AND A.BLANK_KIND  = vBLANK_KIND_2
                               AND A.MELT_NO     = B.MELT_NO
                               AND B.STLGRADE_CD = C1.STLGRADE_CD
                            UNION ALL
                            SELECT A.MELT_NO
                                  ,A.BLANK_WT
                              FROM TB_PO_BLANK_COMM     A
                                  ,TB_QM_MELT_STL_GRADE B
                             WHERE A.PROG_CD     = 'F'
                               AND A.ORD_REM_GP  = '2'
                               AND A.STATUS      = '2'
                               AND A.BLANK_KIND  = vBLANK_KIND_3
                               AND A.MELT_NO     = B.MELT_NO
                               AND B.STLGRADE_CD = C1.STLGRADE_CD
                            UNION ALL
                            SELECT A.MELT_NO
                                  ,A.BLANK_WT
                              FROM TB_PO_BLANK_COMM     A
                                  ,TB_QM_MELT_STL_GRADE B
                             WHERE A.PROG_CD     = 'F'
                               AND A.ORD_REM_GP  = '2'
                               AND A.STATUS      = '2'
                               AND A.BLANK_KIND  = vBLANK_KIND_4
                               AND A.MELT_NO     = B.MELT_NO
                               AND B.STLGRADE_CD = C1.STLGRADE_CD
                           )
                     GROUP BY MELT_NO
                   )
        LOOP

            vMELT_YN := FUN_ORDER_MELT_YN(C1.PROD_YYMM ,C1.ORD_NO ,C1.ORD_POSITION, C11.MELT_NO, 'N');

            IF vMELT_YN IN ('0','1') THEN
                vRESULT   := vRESULT   + C11.BLANK_WT;
            END IF;

        END LOOP;

    END LOOP;

    RETURN vRESULT;

EXCEPTION              
    WHEN OTHERS      THEN              
        RETURN -1;
END;