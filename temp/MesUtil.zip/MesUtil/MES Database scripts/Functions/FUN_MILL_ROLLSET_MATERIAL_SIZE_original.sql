create or replace 
FUNCTION      FUN_MILL_ROLLSET_MATERIAL_SIZE 
                                ( piMILL_GP             IN VARCHAR2
                                , piSECTION_TYPE        IN VARCHAR2
                                , piROLL_SET_NO         IN NUMBER
                                )         RETURN VARCHAR2
IS

   vRESULT      VARCHAR2(4000);
   vFetchCnt    INTEGER;

BEGIN

    vRESULT   := NULL;
    vFetchCnt := 0;
    IF piMILL_GP = '6' AND piSECTION_TYPE IN ('SB','BL') THEN
        FOR C6 IN (SELECT SECTION_SIZE_T ,SECTION_SIZE_W
                     FROM TB_PM_MILL680_ROLLSET
                    WHERE SECTION_TYPE       IN ('SB','BL')
                      AND BLANK_GOODS_PROD_GP = 'M'
                      AND ROLL_SET_NO         = piROLL_SET_NO
                    ORDER BY SEQ_NO
                  )
        LOOP
            vFetchCnt := vFetchCnt + 1;

            IF vFetchCnt > 1 THEN
                vRESULT := vRESULT || '/';
            END IF;

            IF C6.SECTION_SIZE_T = C6.SECTION_SIZE_W THEN
                vRESULT := vRESULT || C6.SECTION_SIZE_T;
            ELSE
                vRESULT := vRESULT || C6.SECTION_SIZE_T ||'x' || C6.SECTION_SIZE_W;
            END IF;

        END LOOP;

    ELSIF piMILL_GP = '9' AND piSECTION_TYPE IN ('SB','BL') THEN
        FOR C9 IN (SELECT SECTION_SIZE_T ,SECTION_SIZE_W
                     FROM TB_PM_MILL900_ROLLSET
                    WHERE SECTION_TYPE       IN ('SB','BL')
                      AND BLANK_GOODS_PROD_GP = 'M'
                      AND ROLL_SET_NO         = piROLL_SET_NO
                    ORDER BY SECTION_SIZE_T DESC ,SECTION_SIZE_W
                  )
        LOOP
            vFetchCnt := vFetchCnt + 1;

            IF vFetchCnt > 1 THEN
                vRESULT := vRESULT || '/';
            END IF;

            IF C9.SECTION_SIZE_T = C9.SECTION_SIZE_W THEN
                vRESULT := vRESULT || C9.SECTION_SIZE_T;
            ELSE
                vRESULT := vRESULT || C9.SECTION_SIZE_T ||'x' || C9.SECTION_SIZE_W;
            END IF;

        END LOOP;

    END IF;

    RETURN vRESULT;
END
; 