create or replace 
FUNCTION      GET_STR_TIME_NUM_FUNC
                                    (piSTR_TIME     IN  VARCHAR2                -- STRING TIME (HH24:MI:SS)
                                    )   RETURN  NUMBER
IS

    vSTR_TIME       VARCHAR2(15);

    vINSTR          NUMBER;
    vHOUR           NUMBER;
    vMINUTE         NUMBER;
    vSECOND         NUMBER;

    vRESULT         NUMBER;    -- Second

    vERR_CODE       NUMBER;
    vERR_MSG        VARCHAR2(250);

BEGIN

    IF piSTR_TIME IS NULL THEN
        RETURN 0; 
    END IF;

    vSTR_TIME := piSTR_TIME;

    -- HOUR -> Second
    BEGIN
        SELECT INSTR(vSTR_TIME,':')
          INTO vINSTR
          FROM DUAL
        ;
    EXCEPTION              
        WHEN OTHERS THEN 
            RAISE;
    END;

    IF vINSTR = 0 THEN
        vERR_CODE   :=  -20001;                 
        vERR_MSG    :=  'Time Type Error (hh24:mi:ss) (' || piSTR_TIME || ')';
        RAISE_APPLICATION_ERROR(vERR_CODE ,vERR_MSG);
    ELSE
        vHOUR       := CAST(SUBSTR(vSTR_TIME ,1 ,vINSTR - 1) AS INTEGER) * 60 * 60;
        vSTR_TIME   := SUBSTR(vSTR_TIME ,vINSTR + 1 ,99);
    END IF;


    -- MINUTE -> Second
    BEGIN
        SELECT INSTR(vSTR_TIME,':')
          INTO vINSTR
          FROM DUAL
        ;
    EXCEPTION              
        WHEN OTHERS THEN 
            RAISE;
    END;

    IF vINSTR <> 3 THEN
        vERR_CODE   :=  -20001;                 
        vERR_MSG    :=  'Time Type Error (hh24:mi:ss) (' || piSTR_TIME || ')';
        RAISE_APPLICATION_ERROR(vERR_CODE ,vERR_MSG);
    ELSE
        vMINUTE     := CAST(SUBSTR(vSTR_TIME ,1 ,2) AS INTEGER) * 60;
        vSTR_TIME   := SUBSTR(vSTR_TIME ,vINSTR + 1 ,99);
    END IF;


    -- Second
    BEGIN
        SELECT INSTR(vSTR_TIME,':')
          INTO vINSTR
          FROM DUAL
        ;
    EXCEPTION              
        WHEN OTHERS THEN 
            RAISE;
    END;

    IF vINSTR <> 0 THEN
        vERR_CODE   :=  -20001;                 
        vERR_MSG    :=  'Time Type Error (hh24:mi:ss) (' || piSTR_TIME || ')';
        RAISE_APPLICATION_ERROR(vERR_CODE ,vERR_MSG);
    ELSE
        vSECOND     := CAST(SUBSTR(vSTR_TIME ,1 ,2) AS INTEGER);
    END IF;


    BEGIN
        SELECT LENGTHB(vSTR_TIME)
          INTO vINSTR
          FROM DUAL
        ;
    EXCEPTION              
        WHEN OTHERS THEN 
            RAISE;
    END;

    IF vINSTR <> 2 THEN
        vERR_CODE   :=  -20001;                 
        vERR_MSG    :=  'Time Type Error (hh24:mi:ss) (' || piSTR_TIME || ')';
        RAISE_APPLICATION_ERROR(vERR_CODE ,vERR_MSG);
    ELSE
        vRESULT := vHOUR + vMINUTE + vSECOND;
    END IF;


    RETURN vRESULT;

END; 