create or replace 
FUNCTION      FUN_ORD_BLANK_CNT_NEW01
                                ( piSECTION_TYPE    IN VARCHAR2
                                 ,piSECTION_SIZE_T  IN NUMBER
                                 ,piSECTION_SIZE_W  IN NUMBER
                                )         RETURN NUMBER
IS

    -- Variable For Program
    vSTAND_NO_CD                TB_PM_BLANK_SECTION_SIZE_STD.STAND_NO_CD%TYPE;
    vBLANK_KIND_1               TB_PM_BLANK_SECTION_SIZE_STD.BLANK_KIND_1%TYPE;
    vBLANK_KIND_2               TB_PM_BLANK_SECTION_SIZE_STD.BLANK_KIND_2%TYPE;
    vBLANK_KIND_3               TB_PM_BLANK_SECTION_SIZE_STD.BLANK_KIND_3%TYPE;
    vBLANK_KIND_4               TB_PM_BLANK_SECTION_SIZE_STD.BLANK_KIND_4%TYPE;

    vBLANK_WT                   NUMBER;
    vRESULT                     NUMBER;

BEGIN


    SELECT DECODE(MAX(STAND_NO_CD),'8','8',MAX(STAND_NO_CD))
      INTO vSTAND_NO_CD
      FROM TB_PM_BLANK_SECTION_SIZE_STD
     WHERE SECTION_TYPE   = piSECTION_TYPE
       AND SECTION_SIZE_T = piSECTION_SIZE_T
       AND SECTION_SIZE_W = piSECTION_SIZE_W
    ;


    SELECT BLANK_KIND_1
          ,BLANK_KIND_2
          ,BLANK_KIND_3
          ,BLANK_KIND_4
      INTO vBLANK_KIND_1
          ,vBLANK_KIND_2
          ,vBLANK_KIND_3
          ,vBLANK_KIND_4
      FROM TB_PM_BLANK_SECTION_SIZE_STD
     WHERE SECTION_TYPE   = piSECTION_TYPE
       AND SECTION_SIZE_T = piSECTION_SIZE_T
       AND SECTION_SIZE_W = piSECTION_SIZE_W
       AND STAND_NO_CD    = vSTAND_NO_CD
    ;

    vRESULT := 0;
    FOR C1 IN (SELECT B.PROD_YYMM 
                     ,B.ORD_NO
                     ,B.ORD_POSITION
                     ,B.STLGRADE_CD
                     ,D.STANDARD_KIND_CD
                     ,B.STANDARD_CD
                     ,B.ORD_GP
                     ,B.ORD_INGR_SPEC1
                     ,C.CONTRACT_NO
                 FROM TB_PM_DAILY_SECTION_SIZE_SEQ  A
                     ,TB_SM_ORDDTL                  B
                     ,TB_SM_ORDCOMM                 C
                     ,TB_QM_STANDARD                D
                     ,TB_PM_BLANK_SECTION_SIZE_STD  F 
                WHERE A.MILL_GP         = '3'
                  AND A.MILL_GP         = B.MILL_GP
                  AND A.SECTION_TYPE    = B.R350_SECTION_TYPE
                  AND A.SECTION_SIZE_T  = B.R350_SECTION_SIZE_T
                  AND A.SECTION_SIZE_W  = B.R350_SECTION_SIZE_W
                  AND B.PROD_YYMM       = C.PROD_YYMM
                  AND B.ORD_NO          = C.ORD_NO
                  AND B.STANDARD_CD     = D.STANDARD_CD
                  AND A.SECTION_TYPE    = F.SECTION_TYPE   (+)
                  AND A.SECTION_SIZE_T  = F.SECTION_SIZE_T (+)
                  AND A.SECTION_SIZE_W  = F.SECTION_SIZE_W (+)   
                  AND NVL(A.SEQ,0)      = 0
                  AND A.SECTION_TYPE    = piSECTION_TYPE
                  AND A.SECTION_SIZE_T  = piSECTION_SIZE_T
                  AND A.SECTION_SIZE_W  = piSECTION_SIZE_W
                  AND (NVL(B.ORD_WT,0) - NVL(B.BLANK_MATCH_WT,0))   > 0
                  AND B.SALE_GP         = '0'
                  AND B.ORD_PROG_CD     = 'C' 
                  AND B.PROD_END_YN     IS NULL
                  AND F.STAND_NO_CD (+) = vSTAND_NO_CD
                ORDER BY  B.DELIVER_DD
                         ,B.ORD_GP
              )
    LOOP

        SELECT SUM(A.BLANK_WT)
          INTO vBLANK_WT
          FROM (SELECT MELT_NO
                      ,BLANK_NO
                      ,BLANK_WT
                 FROM TB_PO_BLANK_COMM
                WHERE PROG_CD      = 'F'
                  AND ORD_REM_GP   = '2'
                  AND STATUS       = '2'
                  AND BLANK_KIND  IN (vBLANK_KIND_1, vBLANK_KIND_2, vBLANK_KIND_3, vBLANK_KIND_4)
              ) A
             ,(SELECT MELT_NO
                 FROM (SELECT DISTINCT
                              A.MELT_NO
                              ,DECODE(C.STANDARD_KIND_CD,NULL,FUN_MELT_INGR_YN(C1.PROD_YYMM     ,C1.ORD_NO
                                                                              ,C1.ORD_POSITION  ,A.MELT_NO)
                                                        ,FUN_MILL350_MELT_YN  (C1.PROD_YYMM     ,C1.ORD_NO
                                                                              ,C1.ORD_POSITION  ,C1.ORD_INGR_SPEC1
                                                                              ,A.MELT_NO        ,C.STANDARD_KIND_CD
                                                                              ,C1.ORD_GP        ,C1.CONTRACT_NO
                                                                              ,C1.STLGRADE_CD   ,C1.STANDARD_KIND_CD
                                                                              ,C1.STANDARD_CD))   ORDER_MELT_YN
                         FROM TB_PO_BLANK_COMM              A
                             ,TB_QM_MELT_STL_GRADE          B
                             ,TB_QM_MELT_STL_GRADE_STANDARD C
                        WHERE A.PROG_CD      = 'F'
                          AND A.ORD_REM_GP   = '2'
                          AND A.STATUS       = '2'
                          AND A.MELT_NO      = B.MELT_NO
                          AND B.STLGRADE_CD  = C1.STLGRADE_CD
                          AND B.MELT_NO      = C.MELT_NO(+)
                          AND B.STLGRADE_CD  = C.STLGRADE_CD(+)
                      )
                WHERE ORDER_MELT_YN IN ('0', '1')
              ) B
         WHERE A.MELT_NO = B.MELT_NO
        ;

        vRESULT := vRESULT + NVL(vBLANK_WT,0);
    END LOOP;

    RETURN vRESULT;

EXCEPTION              
    WHEN OTHERS      THEN              
        RETURN -1;
END; 