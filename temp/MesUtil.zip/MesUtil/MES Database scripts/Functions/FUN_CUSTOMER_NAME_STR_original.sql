create or replace 
FUNCTION      FUN_CUSTOMER_NAME_STR
                                ( piCUSTOMER_CD    IN NUMBER
                                )         RETURN VARCHAR2
IS

    vCUSTOMER_NAME          TB_SM_CUSTOMER.CUSTOMER_NAME%TYPE;

    vStrPos                 INTEGER;
    vStrPosNext             INTEGER;
    vStrPosNext2            INTEGER;

BEGIN

    vCUSTOMER_NAME  := NULL;
    vStrPosNext     := 0;
    vStrPosNext2    := 0;

    SELECT TRIM(CUSTOMER_NAME)
      INTO vCUSTOMER_NAME
      FROM TB_SM_CUSTOMER
     WHERE CUSTOMER_CD = piCUSTOMER_CD
    ;

    IF LENGTHB(TRIM(vCUSTOMER_NAME)) = 0 THEN
        RETURN vCUSTOMER_NAME;
    END IF;

    vStrPosNext := INSTR(vCUSTOMER_NAME, '(');
    IF vStrPosNext = 0 THEN
        RETURN vCUSTOMER_NAME;
    END IF;

    vStrPosNext2:= INSTR(SUBSTR(vCUSTOMER_NAME ,vStrPosNext + 1 ,999), ')');
    IF vStrPosNext2 = 0 THEN
        RETURN vCUSTOMER_NAME;
    END IF;


    vStrPos     := 0;
    vStrPosNext := 0;
    vStrPosNext2:= 0;
    LOOP
        vStrPosNext := INSTR(SUBSTR(vCUSTOMER_NAME ,vStrPos + 1 ,999), '(');
        IF vStrPosNext > 0 THEN
            vStrPosNext2 := INSTR(SUBSTR(vCUSTOMER_NAME ,vStrPosNext + 1 ,999), ')');
            IF vStrPosNext2 > 0 THEN
                vStrPos := vStrPosNext;
            ELSE
                EXIT;
            END IF;
        ELSE
            EXIT;
        END IF;
    END LOOP;

    IF vStrPos > 0 THEN
        vCUSTOMER_NAME := TRIM(SUBSTR(vCUSTOMER_NAME,0,vStrPos - 1));
    END IF;

    RETURN vCUSTOMER_NAME;

EXCEPTION
    WHEN OTHERS THEN
        RETURN vCUSTOMER_NAME;
END; 