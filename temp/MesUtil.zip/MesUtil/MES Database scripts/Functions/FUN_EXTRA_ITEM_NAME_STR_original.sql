create or replace 
FUNCTION      FUN_EXTRA_ITEM_NAME_STR
                                  ( piPROD_YYMM     IN VARCHAR2
                                   ,piORD_NO        IN VARCHAR2
                                   ,piORD_POSITION  IN NUMBER
                                  )         RETURN VARCHAR2
IS

    vEXTRA_ITEM_NAME        VARCHAR2(4000);

    vFetchCnt               INTEGER;

BEGIN

    vEXTRA_ITEM_NAME := NULL;
    vFetchCnt        := 0;
    FOR C1 IN (SELECT EXTRA_ITEM_CD
                     ,EXTRA_ITEM_NAME
                 FROM TB_SM_ORD_EXTRA_ITEM
                WHERE PROD_YYMM     = piPROD_YYMM
                  AND ORD_NO        = piORD_NO
                  AND ORD_POSITION  = piORD_POSITION
                ORDER BY EXTRA_ITEM_CD
              )
    LOOP
        vFetchCnt := vFetchCnt + 1;

        IF vFetchCnt > 1 THEN
            vEXTRA_ITEM_NAME :=  vEXTRA_ITEM_NAME ||'; ';
        END IF;
        vEXTRA_ITEM_NAME := vEXTRA_ITEM_NAME || TRIM(C1.EXTRA_ITEM_NAME);

    END LOOP;
--    vEXTRA_ITEM_NAME := REPLACE(vEXTRA_ITEM_NAME ,'>', ' +');
--    vEXTRA_ITEM_NAME := REPLACE(vEXTRA_ITEM_NAME ,'<', ' -');


    RETURN vEXTRA_ITEM_NAME;
END; 