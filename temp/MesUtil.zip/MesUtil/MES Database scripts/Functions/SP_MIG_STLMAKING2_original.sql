create or replace 
function sp_mig_stlmaking2
 return varchar2 is
  Res varchar2(10000);
begin
  DBMS_OUTPUT.ENABLE (10000);
  sp_mig_stlmaking;
  Res:= sp_getlog;
  return(Res);
end sp_mig_stlmaking2;
