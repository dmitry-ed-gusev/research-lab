create or replace 
PROCEDURE SP_TR_D1TR012 (in_sequence_key IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR012
 * VERSION           : V2.00
 * DESCRIPTION       : Weight of Liquid steel in Siphon
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 15.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D1TR012';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
meltNo              number;                 -- melt number
siphonNo            number;                 -- siphon number
craneWeight         number;                 -- crane weight
craneWeightingTime  date;                   -- crane weighting time
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;

  -- select melt number, siphon number, weighting time and crane weight
  SELECT to_number(TRIM(ITEM)), to_number(TRIM(ITEM_1)), to_date(TRIM(ITEM_2), dateTimeTemplate), to_number(TRIM(ITEM_4))
    INTO  meltNo, siphonNo, craneWeightingTime, craneWeight
    FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = in_sequence_key;
    
  -- 1. TB_PO_SIPHON_RESULT UPDATE FOR Previous Siphon data ----
  BEGIN
    currentOperation := 'Operation [TB_PO_SIPHON_RESULT update].'; -- current operation marker for error handling
    UPDATE TB_PO_SIPHON_RESULT
      SET SIPHON_POURING_END_TIME = craneWeightingTime
          ,SIPHON_WT              = SIPHON_WT - craneWeight
      WHERE (MELT_NO,SIPHON_NO)   = (
        SELECT MELT_NO, MAX(NVL(SIPHON_NO,0))
          FROM TB_PO_SIPHON_RESULT
          WHERE MELT_NO = meltNo AND SIPHON_POURING_END_TIME IS NULL AND SIPHON_NO <> siphonNo
          GROUP BY MELT_NO
        );
        
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
        
  -- 2. TB_PO_SIPHON_RESULT INSERT ----
  BEGIN
    currentOperation := 'Operation [TB_PO_SIPHON_RESULT insert].'; -- current operation marker for error handling
    INSERT INTO TB_PO_SIPHON_RESULT (MELT_NO, SIPHON_NO, SIPHON_POURING_START_TIME, SIPHON_WT, REG_DDTT, REGISTER)
      VALUES (meltNo, siphonNo, craneWeightingTime, craneWeight, SYSDATE, procedureName);
      
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN -- duplicate value, we just collect error and proceed
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
  
  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;