create or replace 
PROCEDURE SP_TR_D1TR006 (IN_SEQUENCE_KEY IN VARCHAR2, errors out VARCHAR2) IS

/*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR006        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Consumption of LF materials         
 * DEVELOPER NAME    : Lee, Gusev D.               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       : 30.09.2013                                                       
*/-----------------------------------------------------------------------------
  
-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D1TR006';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
processCode         varchar2(3)  := '202';  -- LF process code (AKOS)
-- parameters for procedure
telegramId          varchar2(7); -- telegram id
  
BEGIN 
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  -- Insert data into TB_PO_MATERIAL_PUT_RESULT table
  INSERT INTO TB_PO_MATERIAL_PUT_RESULT (MELT_NO, PLANT_PROC_CD, PUT_TIME, RAW_MATERIAL_CD, NET_WT, PUT_METHOD, CHECK_NO, REG_DDTT, REGISTER)
    SELECT TRIM(ITEM) /*MELT_NO*/, processCode /*PLANT_PROC_CD*/, TO_DATE(TRIM(ITEM_1), dateTimeTemplate) /*PUT_TIME*/, TRIM(ITEM_2) /*RAW_MATERIAL_CD*/,
      TRIM(ITEM_3) /*NET_WT*/, TRIM(ITEM_4) /*PUT_METHOD*/, '000000000' /*CHECK_NO - empty value*/, SYSDATE, procedureName 
        FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
        
  EXCEPTION
    WHEN OTHERS THEN
     errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, 'Operation [TB_PO_MATERIAL_PUT_RESULT insert].', errors);
END;