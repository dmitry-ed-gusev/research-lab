create or replace 
PROCEDURE      SP_TR_D1TR010 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR010        
 * VERSION           : V1.00                       
 * DESCRIPTION       : LF_end       
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);

W_MELT_NO               TB_PO_LF_RESULT.MELT_NO%TYPE;
W_LF_START_TIME         TB_PO_LF_RESULT.LF_START_TIME%TYPE;
W_LF_END_TIME           TB_PO_LF_RESULT.LF_END_TIME%TYPE;
W_LIQUID_STEEL_WT       TB_PO_LF_RESULT.LIQUID_STEEL_WT%TYPE;
W_WORK_DUTY             TB_PO_SHIFT_WORKER.WORK_DUTY%TYPE; 
W_WORK_SHIFT            TB_PO_SHIFT_WORKER.WORK_SHIFT%TYPE;

W_WORK_HR               CHAR(5);

  
BEGIN 
    -- Select interface data 
    SELECT TRIM(ITEM)
          ,TO_DATE(TRIM(ITEM_1),'DD-MM-YYYY HH24:MI:SS')
          ,TRIM(ITEM_5)
      INTO W_MELT_NO,W_LF_END_TIME,W_LIQUID_STEEL_WT
      FROM TB_PO_LEVEL2_INTERFACE 
     WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
      
    -- TB_PO_MPT_RESULT UPDATE ----------
    BEGIN
           UPDATE TB_PO_MPT_RESULT
              SET STLMAKING_PROG_CD = '6'   -- Pouring Start
                  ,LF_END_TIME      = W_LF_END_TIME
                  ,MELT_OUT_WT      = W_LIQUID_STEEL_WT
                  ,LF_PETROL_DATE   = FN_PETRODATE(TO_CHAR(W_LF_END_TIME,'DD-MM-YYYY HH24:MI:SS'),'DD-MM-YYYY HH24:MI:SS','YYYYMMDD')                   
                  ,MOD_DDTT = SYSDATE
                  ,MODIFIER = 'SP_TR_D1TR010'    
            WHERE MELT_NO = W_MELT_NO;
                   
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_MPT_RESULT UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';       
            RETURN;
    END;
    
    -- TB_PM_MELT_WORK_SEQUENCE UPDATE ----------
    BEGIN
           UPDATE TB_PM_MELT_WORK_SEQUENCE
              SET STLMAKE_STATUS_CD = '6'
                  ,MOD_DDTT = SYSDATE
                  ,MODIFIER = 'SP_TR_D1TR010'    
            WHERE MELT_NO = W_MELT_NO;
                   
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PM_MELT_WORK_SEQUENCE UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';       
            RETURN;
    END;
    
    --  TB_PO_WORK_SHIFT_RESULT  INSERT  
    SELECT LF_START_TIME INTO W_LF_START_TIME
      FROM TB_PO_LF_RESULT
     WHERE MELT_NO = W_MELT_NO;
  
    SP_TR_250_SHIFT (W_MELT_NO,'0','202'
                    ,TO_CHAR(W_LF_START_TIME,'YYYYMMDDHH24MI')
                    ,TO_CHAR(W_LF_END_TIME,'YYYYMMDDHH24MI')
                    ,W_LIQUID_STEEL_WT
                    ,vERR_CODE,vERR_MSG);
    IF  vERR_MSG  IS NOT NULL  THEN
        RETURN;
    END IF;
    
    -- MONITORING DATA SET
    SP_TR_200_MONITOR  ('202'
                       ,'E'
                       ,W_MELT_NO
                       ,TO_CHAR(W_LF_END_TIME,'YYYYMMDDHH24MI')
                       ,NULL
                       ,'E'
                       ,NULL
                       ,NULL
                       ,vERR_CODE 
                       ,vERR_MSG 
                      );
    IF  vERR_MSG  IS NOT NULL  THEN 
        RETURN;
    END IF;

    --TB_PO_LF_RESULT UPDATE ----------
    BEGIN
           UPDATE TB_PO_LF_RESULT
              SET (LF_END_TIME
                  ,LIQUID_STEEL_WT
                  ,SLAG_WT
                  ,LF_DURATION_TIME
                  ,GAS_POUR_DURATION_TIME
                  ,PWR_USE_DURATION_TIME
                  ,FIRST_TEMP
                  ,LAST_TEMP
                  ,AR_CONSUME_BOTTOM
                  ,AR_CONSUME_LANCE
                  ,N2_CONSUMPTION_BOTTOM
                  ,N2_CONSUMPTION_LANCE
                  ,PWR_CONSUMPTION_HR
                  ,PWR_CONSUMPTION_TON
                  ,LF_AIM_TEMP
                  )
                   = (SELECT TO_DATE(TRIM(ITEM_1),'DD-MM-YYYY HH24:MI:SS')  -- LF_END_TIME 
                             ,TRIM(ITEM_5)                               -- LIQUID_STEEL_WT
                             ,TRIM(ITEM_6)                               -- SLAG_WT
                             ,TRIM(ITEM_2)                               -- LF_DURATION_TIME
                             ,TRIM(ITEM_3)                               -- GAS_POUR_DURATION_TIME
                             ,TRIM(ITEM_4)                               -- PWR_USE_DURATION_TIME
                             ,TRIM(ITEM_7)                               -- FIRST_TEMP
                             ,TRIM(ITEM_8)                               -- LAST_TEMP
                             ,TRIM(ITEM_9)                               -- AR_CONSUME_BOTTOM
                             ,TRIM(ITEM_10)                              -- AR_CONSUME_LANCE
                             ,TRIM(ITEM_11)                              -- N2_CONSUMPTION_BOTTOM
                             ,TRIM(ITEM_12)                              -- N2_CONSUMPTION_LANCE
                             ,TRIM(ITEM_13)                              -- PWR_CONSUMPTION_HR
                             ,TRIM(ITEM_14)                              -- PWR_CONSUMPTION_TON
                             ,TRIM(ITEM_15)                              -- LF_AIM_TEMP
                        FROM TB_PO_LEVEL2_INTERFACE 
                       WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY)
                  ,MOD_DDTT = SYSDATE
                  ,MODIFIER = 'SP_TR_D1TR010'    
            WHERE MELT_NO = (SELECT TRIM(ITEM)
                               FROM TB_PO_LEVEL2_INTERFACE 
                              WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY); 
                   
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_LF_RESULT UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';       
            RETURN;
    END;
--COMMIT;
EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;