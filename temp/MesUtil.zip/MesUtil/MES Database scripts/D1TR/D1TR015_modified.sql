create or replace 
PROCEDURE SP_TR_D1TR015 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR015        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Ingot weight information after extracting from the mould       
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012             
 * MODIFY DATE       : 15.01.2014                                            
 */-----------------------------------------------------------------------------

--W_PROG_CD                  TB_PO_INGOT_COMM.PROG_CD%TYPE;
--W_HCR_GP                   TB_PM_MELT_WORK_SEQUENCE.HCR_GP%TYPE;
--W_UNHEATEDWELL_CHARGE_CD   TB_PM_MELT_WORK_SEQUENCE.UNHEATEDWELL_CHARGE_CD%TYPE;

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D1TR015';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
meltNo              number;                 -- melt number
checkCount          number;                 -- check count ingots
ingotWeight         number;                 -- ingot weight
weightingWeight     number;                 -- weighting weight
weightingTime       date;                   -- weighting time
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  -- select melt number, weighting time and weighting weight
  SELECT to_number(TRIM(ITEM)), TO_DATE(TRIM(ITEM_1), dateTimeTemplate), to_number(TRIM(ITEM_2))
    INTO meltNo, weightingTime, weightingWeight     
    FROM TB_PO_LEVEL2_INTERFACE 
    WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY; 
    
  IF (weightingWeight > 4000) THEN
    checkCount := 2;
    ingotWeight := ROUND(weightingWeight / 2,0);
  ELSE
    checkCount := 1;
    ingotWeight := weightingWeight;
  END IF; 
   
--   SELECT HCR_GP,UNHEATEDWELL_CHARGE_CD
--     INTO W_HCR_GP,W_UNHEATEDWELL_CHARGE_CD
--     FROM TB_PM_MELT_WORK_SEQUENCE
--    WHERE MELT_NO = W_MELT_NO;
    
--   IF   W_UNHEATEDWELL_CHARGE_CD = 'U'  THEN
--          W_PROG_CD   := '8';       
--   ELSIF  W_HCR_GP = 'H'  THEN
--          W_PROG_CD   := 'A';
--   END IF;
 
  -- TB_PO_INGOT_COMM update ----
  BEGIN
    currentOperation := 'Operation [TB_PO_INGOT_COMM update].'; -- current operation marker for error handling
    UPDATE TB_PO_INGOT_COMM
      SET --PROG_CD                    = W_PROG_CD
          --,PROG_DD                   = TO_CHAR(W_WEIGHING_TIME,'YYYYMMDD') 
          INGOT_CRANE_WEIGHING_TIME = weightingTime
          ,CRANE_WEIGHING_WEIGHT    = ingotWeight
          ,MOD_DDTT                 = SYSDATE
          ,MODIFIER                 = procedureName    
      WHERE (MELT_NO, INGOT_KEY) IN (
        SELECT MELT_NO, INGOT_KEY
          FROM (
            SELECT MELT_NO, INGOT_KEY
              FROM TB_PO_INGOT_COMM
              WHERE MELT_NO = meltNo AND CRANE_WEIGHING_WEIGHT IS NULL
              ORDER BY INGOT_KEY
          )
          WHERE ROWNUM <= checkCount
        );
    EXCEPTION          
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
  
  --   -- MPT RESULT UPDATE
  --   UPDATE TB_PO_MPT_RESULT
  --      SET STLMAKING_PROG_CD  = W_PROG_CD
  --          ,MOD_DDTT          = SYSDATE
  --          ,MODIFIER          = 'SP_TR_300_POUR'
  --    WHERE MELT_NO = W_MELT_NO;
  --
  --    -- MPT MELT WORK SEQUENCE UPDATE
  --   UPDATE TB_PM_MELT_WORK_SEQUENCE
  --      SET STLMAKE_STATUS_CD  = W_PROG_CD   
  --          ,MOD_DDTT          = SYSDATE
  --          ,MODIFIER          = 'SP_TR_300_POUR'
  --    WHERE MELT_NO = W_MELT_NO;
  
  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;