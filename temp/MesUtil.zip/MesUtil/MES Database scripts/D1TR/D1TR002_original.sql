create or replace 
PROCEDURE      SP_TR_D1TR002 (IN_SEQUENCE_KEY      IN  VARCHAR2
                                               ,IN_TC_ID             IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR002        
 * VERSION           : V1.00                       
 * DESCRIPTION       : Chemical composition         
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       : 16.09.2013, Gusev Dmitry                                                      
 * added template for converting char->number: to_number(char_value, '9.9999')
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
W_TEST_SEQ              NUMBER;


  
BEGIN 
    --RETURN;  
    --TB_PO_LEVEL2_INTERFACE Search & TB_QM_STL_ANALYSIS_INGR INSERT----------
    
    SELECT NVL(MAX(TEST_SEQ),0) INTO W_TEST_SEQ
      FROM TB_QM_STL_ANALYSIS_INGR
     WHERE MELT_NO 
           = (
              SELECT TO_NUMBER(ITEM)                                   -- MELT_NO 
                FROM TB_PO_LEVEL2_INTERFACE 
               WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY
             );
    
    --dbms_output.put_line('1');
    
    IF  W_TEST_SEQ > 0 THEN   
        --dbms_output.put_line('1-a');
        UPDATE TB_QM_STL_ANALYSIS_INGR
           SET LAST_YN = NULL
         WHERE (MELT_NO,TEST_SEQ)
               = (
                  SELECT TO_NUMBER(ITEM), W_TEST_SEQ                   -- MELT_NO 
                    FROM TB_PO_LEVEL2_INTERFACE 
                   WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY
                 ); 
    END IF;
    
    --dbms_output.put_line('2');
    BEGIN
    W_TEST_SEQ := W_TEST_SEQ + 1;
    --dbms_output.put_line('-> '||w_test_seq);
           INSERT INTO TB_QM_STL_ANALYSIS_INGR
                  (MELT_NO
                  ,PLANT_PROC_CD
                  ,TEST_SEQ
                  ,LAST_YN
                  ,SAMPLING_TIME
                  ,C_VAL
                  ,SI_VAL
                  ,MN_VAL
                  ,S_VAL
                  ,P_VAL
                  ,CR_VAL
                  ,NI_VAL
                  ,CU_VAL
                  ,W_VAL
                  ,MO_VAL
                  ,V_VAL
                  ,AL_VAL
                  ,TI_VAL
                  ,B_VAL
                  ,NB_VAL
                  ,PB_VAL
                  ,N_VAL
                  ,SN_VAL
                  ,AS_VAL
                  ,H2_VAL
                  ,O2_VAL
                  ,ZN_VAL
                  ,SB_VAL
                  ,CA_VAL
                  ,CEQU_VAL
                  ,LAB_TIME
                  ,CHECK_NO
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT TO_NUMBER(ITEM)                                   -- MELT_NO 
                  ,CASE WHEN ITEM_2 IN ('SIEM1','SIEM2','SIEM3','SIEM4') THEN '201' 
                        WHEN ITEM_2 IN ('LADLE')                         THEN '202' 
                                                                         ELSE '203' END          -- PLANT_PROC_CD
                  ,W_TEST_SEQ
                  ,'Y'
                  ,TO_DATE(TRIM(ITEM_3),'DD-MM-YYYY HH24:MI:SS')    -- SAMPLING_TIME(LAB)
                  ,TO_NUMBER(TRIM(ITEM_4), '9.9999')                                     -- C_VAL
                  ,TO_NUMBER(TRIM(ITEM_5), '9.9999')                                     -- SI_VAL
                  ,TO_NUMBER(TRIM(ITEM_6), '9.9999')                                     -- MN_VAL
                  ,TO_NUMBER(TRIM(ITEM_7), '9.9999')                                     -- S_VAL
                  ,TO_NUMBER(TRIM(ITEM_8), '9.9999')                                     -- P_VAL
                  ,TO_NUMBER(TRIM(ITEM_9), '9.9999')                                     -- CR_VAL 
                  ,TO_NUMBER(TRIM(ITEM_10), '9.9999')                                    -- NI_VAL
                  ,TO_NUMBER(TRIM(ITEM_11), '9.9999')                                    -- CU_VAL
                  ,TO_NUMBER(TRIM(ITEM_12), '9.9999')                                    -- W_VAL
                  ,TO_NUMBER(TRIM(ITEM_13), '9.9999')                                    -- MO_VAL
                  ,TO_NUMBER(TRIM(ITEM_14), '9.9999')                                    -- V_VAL
                  ,TO_NUMBER(TRIM(ITEM_15), '9.9999')                                    -- AL_VAL
                  ,TO_NUMBER(TRIM(ITEM_16), '9.9999')                                    -- TI_VAL
                  ,TO_NUMBER(TRIM(ITEM_17), '9.9999')                                    -- B_VAL
                  ,TO_NUMBER(TRIM(ITEM_18), '9.9999')                                    -- NB_VAL
                  ,TO_NUMBER(TRIM(ITEM_19), '9.9999')                                    -- PB_VAL
                  ,TO_NUMBER(TRIM(ITEM_20), '9.9999')                                    -- N_VAL
                  ,TO_NUMBER(TRIM(ITEM_21), '9.9999')                                    -- SN_VAL
                  ,TO_NUMBER(TRIM(ITEM_22), '9.9999')                                    -- AS_VAL
                  ,TO_NUMBER(TRIM(ITEM_23), '9.9999')                                    -- H2_VAL
                  ,TO_NUMBER(TRIM(ITEM_24), '9.9999')                                    -- O2_VAL
                  ,TO_NUMBER(TRIM(ITEM_25), '9.9999')                                    -- ZN_VAL
                  ,TO_NUMBER(TRIM(ITEM_26), '9.9999')                                    -- SB_VAL
                  ,TO_NUMBER(TRIM(ITEM_27), '9.9999')                                    -- CA_VAL
                  ,TO_NUMBER(TRIM(ITEM_28), '9.9999')                                    -- CEQU_VAL
                  ,TO_DATE(TRIM(ITEM_29),'DD-MM-YYYY HH24:MI:SS')   -- SAMPLE TAKE TIME
                  ,TRIM(ITEM_30)                                    -- CHECK_NO
                  ,SYSDATE
                  ,'SP_TR_D1TR002'
           FROM   TB_PO_LEVEL2_INTERFACE 
           WHERE  SEQUENCE_KEY = IN_SEQUENCE_KEY;  
           --dbms_output.put_line('3');
    EXCEPTION  
        WHEN  DUP_VAL_ON_INDEX THEN
              NULL;
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_QM_STL_ANALYSIS_INGR INSERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';        
            RETURN;
    END;

EXCEPTION  
    WHEN    OTHERS  THEN  
            vERR_CODE   := TO_CHAR(SQLCODE);
            vERR_MSG   := 'SYSTEM ERROR = ' || SQLERRM;
            --dbms_output.put_line(vERR_MSG||'   '||vERR_CODE);
        RAISE;                           
END;