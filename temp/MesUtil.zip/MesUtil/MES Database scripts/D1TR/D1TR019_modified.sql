create or replace 
PROCEDURE SP_TR_D1TR019 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR019        
 * VERSION           : V1.00                       
 * DESCRIPTION       : Consumption of LF Ar bypass       
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 15.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D1TR019';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)
  
BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
      
  -- TB_PO_LF_GAS insert ----------
  BEGIN
    currentOperation := 'Operation [TB_PO_LF_GAS insert].'; -- current operation marker for error handling
    INSERT INTO TB_PO_LF_GAS
          (MELT_NO
          ,GAS_KIND
          ,POUR_START_TIME
          ,POUR_END_TIME
          ,POUR_QNTY
          ,POUR_METHOD_CD
          ,REG_DDTT
          ,REGISTER
          )
      SELECT to_number(TRIM(ITEM))                            -- MELT_NO 
            ,'B'                                              -- GAS_KIND
            ,TO_DATE(TRIM(ITEM_1),'DD-MM-YYYY HH24:MI:SS')    -- POUR_START_TIME
            ,TO_DATE(TRIM(ITEM_2),'DD-MM-YYYY HH24:MI:SS')    -- POUR_END_TIME
            ,to_number(TRIM(ITEM_3))                          -- POUR_QNTY
            ,TRIM(ITEM_4)                                     -- POUR_METHOD
            ,SYSDATE
            ,defaultTelegramId
        FROM TB_PO_LEVEL2_INTERFACE 
        WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;  
      EXCEPTION          
        WHEN NO_DATA_FOUND THEN -- error entry not exist in table
          errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  EXCEPTION  
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);                         
END;