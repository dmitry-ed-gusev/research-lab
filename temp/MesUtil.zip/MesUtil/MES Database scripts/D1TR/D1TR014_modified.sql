create or replace 
PROCEDURE SP_TR_D1TR014 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR014        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Liquid steel temperature in Pouring Ladle        
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       : 15.01.2014
 */-----------------------------------------------------------------------------
 
 -- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D1TR014';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;

  -- insert data into TB_PO_POURING_TEMPERATURE ----
  BEGIN
    currentOperation := 'Operation [TB_PO_POURING_TEMPERATURE insert].'; -- current operation marker for error handling
    INSERT INTO TB_PO_POURING_TEMPERATURE
           (MELT_NO
           ,MEASURE_TIME
           ,MEASURE_TEMP
           ,MOD_DDTT
           ,MODIFIER
           )
    SELECT to_number(TRIM(ITEM))
           ,TO_DATE(TRIM(ITEM_1), dateTimeTemplate)
           ,to_number(TRIM(ITEM_2))
           ,SYSDATE
           ,procedureName
      FROM TB_PO_LEVEL2_INTERFACE 
      WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
                             
    EXCEPTION          
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
  
  EXCEPTION  
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;