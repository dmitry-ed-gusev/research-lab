create or replace
PROCEDURE      SP_TR_D1TR019 (IN_SEQUENCE_KEY       IN  VARCHAR2
                                                ,IN_TC_ID             IN  VARCHAR2
                                               )

 IS
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR019
 * VERSION           : V1.00
 * DESCRIPTION       : Consumption of LF Ar bypass
 * DEVELOPER NAME    : Lee
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       :
 */-----------------------------------------------------------------------------

vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);

BEGIN

    -- TB_PO_LF_GAS INSERT----------
    BEGIN
           INSERT INTO TB_PO_LF_GAS
                  (MELT_NO
                  ,GAS_KIND
                  ,POUR_START_TIME
                  ,POUR_END_TIME
                  ,POUR_QNTY
                  ,POUR_METHOD_CD
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT TRIM(ITEM)                                        -- MELT_NO
                  ,'B'                                              -- GAS_KIND
                  ,TO_DATE(TRIM(ITEM_1),'DD-MM-YYYY HH24:MI:SS')    -- POUR_START_TIME
                  ,TO_DATE(TRIM(ITEM_2),'DD-MM-YYYY HH24:MI:SS')    -- POUR_END_TIME
                  ,TRIM(ITEM_3)                                     -- POUR_QNTY
                  ,TRIM(ITEM_4)                                     -- POUR_METHOD
                  ,SYSDATE
                  ,'SP_TR_D1TR019'
           FROM   TB_PO_LEVEL2_INTERFACE
           WHERE  SEQUENCE_KEY = IN_SEQUENCE_KEY;
    EXCEPTION
        WHEN  NO_DATA_FOUND  THEN
            vERR_CODE   :=  -20001;
            vERR_MSG    :=  'TB_PO_LF_GAS INSERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';
            RETURN;
    END;

EXCEPTION
    WHEN    OTHERS  THEN
        RAISE;
END;