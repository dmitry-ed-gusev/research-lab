create or replace 
PROCEDURE SP_TR_D1TR011 (IN_SEQUENCE_KEY IN VARCHAR2, IN_TC_ID IN VARCHAR2, errors out varchar2) IS

/*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR011        
 * VERSION           : V2.00
 * DESCRIPTION       : Pouring_start
 * DEVELOPER NAME    : Lee, Gusev D., Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 30.09.2013
 * MODIFY DATE       : 17.01.2014
*/-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D1TR011';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);    -- telegram id
meltNo              number;         -- melt number
pouringStartTime    date;           -- pouring start time
weight              number;         -- weight
ladleNo             number;         -- ladle number
currentOperation    varchar2(300) := 'No operation.';    -- current processing operation
errorCode           varchar2(250) := null;

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  SELECT TRIM(ITEM), TO_DATE(ITEM_1, dateTimeTemplate), TRIM(ITEM_2), TRIM(ITEM_3)
    INTO meltNo, pouringStartTime, weight, ladleNo
    FROM TB_PO_LEVEL2_INTERFACE 
    WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
       
  --TB_PO_LEVEL2_INTERFACE Search & TB_PO_MPT_RESULT UPDATE ----------
  BEGIN
    currentOperation := 'Operation [TB_PO_MPT_RESULT update].';
    UPDATE TB_PO_MPT_RESULT
      SET STLMAKING_PROG_CD = '6'
          ,POURING_START_TIME = pouringStartTime
          ,MOD_DDTT = SYSDATE
          ,MODIFIER = procedureName
      WHERE MELT_NO = meltNo;          
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN  -- process every execption case
        errors := common_fn.process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
    
  BEGIN
    currentOperation := 'Operation [TB_PM_MELT_WORK_SEQUENCE update].';
    UPDATE  TB_PM_MELT_WORK_SEQUENCE
      SET  STLMAKE_STATUS_CD = '6'
          ,MOD_DDTT = SYSDATE
          ,MODIFIER = procedureName
      WHERE MELT_NO = meltNo;          
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN  -- process every execption case
        errors := common_fn.process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
  
  --TB_PO_LEVEL2_INTERFACE Search & TB_PO_LF_RESULT INSERT----------
  BEGIN
    currentOperation := 'Operation [TB_PO_POURING_RESULT update].';
    INSERT INTO TB_PO_POURING_RESULT (
                  MELT_NO
                  ,POURING_START_TIME
                  ,REG_DDTT
                  ,REGISTER
                )
      VALUES (
          meltNo
          ,pouringStartTime
          ,SYSDATE
          ,procedureName
        );
    
    EXCEPTION          
      WHEN DUP_VAL_ON_INDEX THEN
        UPDATE TB_PO_POURING_RESULT
          SET POURING_START_TIME = pouringStartTime
          WHERE  MELT_NO = meltNo;
  END;
  
  -- MONITORING DATA SET
  BEGIN
    currentOperation := 'Operation [call stored procedure SP_TR_200_MONITOR].'; -- current operation marker for error handling
    SP_TR_200_MONITOR ('203', 'F', meltNo, TO_CHAR(pouringStartTime,'YYYYMMDDHH24MI'), NULL, 'S', NULL, NULL, errorCode, errors);
    
    IF errors IS NOT NULL THEN
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
    END IF;
  END;

  EXCEPTION -- common exception handling statement  
    WHEN OTHERS THEN
      errors := common_fn.process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, 'Common case. '||currentOperation, errors);      

END;