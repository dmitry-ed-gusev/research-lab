create or replace 
PROCEDURE SP_TR_D1TR003 (IN_SEQUENCE_KEY IN  VARCHAR2, IN_TC_ID IN  VARCHAR2)     
IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR003        
 * VERSION           : V1.00                       
 * DESCRIPTION       : Utility Information for MPT Furnace#1~#4        
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       : 14.09.2013, Gusev Dmitry                                                      
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
noValue                 varchar(4) := '----';
--item_value    varchar(30); -- char value of 'item' row  
-- template for converting char -> date
date_template varchar(30) := 'DD-MM-YYYY HH24:MI:SS';

BEGIN 
    
    --TB_PO_LEVEL2_INTERFACE Search & TB_PO_UTILITY_MPT INSERT----------
    --Furnace#1                                               
    BEGIN
           INSERT INTO TB_PO_UTILITY_MPT
                  (MPT_GP
                  ,MEASURING_TIME
                  ,TEMP_AIR
                  ,TEMP_COMPRESSOR_AIR
                  ,TEMP_OXYGEN
                  ,TEMP_GAS
                  ,TEMP_BLANK_OIL
                  ,TEMP_LIQUID_STEEL
                  ,TEMP_FURNACE_ROOF
                  ,CONSUMPTION_AIR
                  ,CONSUMPTION_COMPRESSOR_AIR
                  ,CONSUMPTION_OXYGEN
                  ,CONSUMPTION_GAS
                  ,CONSUMPTION_BLANK_OIL
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT '1'                                               -- MPT_GP
                  --,TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS')      -- MEASURING_TIME
                  ,TO_DATE(TRIM(ITEM), date_template)      -- MEASURING_TIME
                  ,replace(TRIM(ITEM_1), noValue, 0)                                     -- TEMPERATURE_AIR
                  ,replace(TRIM(ITEM_2), noValue, 0)                                     -- TTEMPERATURE_COMPRESSOR_AIR
                  ,replace(TRIM(ITEM_3), noValue, 0)                                     -- TEMPERATURE_OXYGEN
                  ,replace(TRIM(ITEM_4), noValue, 0)                                     -- TEMPERATURE_GAS
                  ,replace(TRIM(ITEM_5), noValue, 0)                                     -- TEMPERATURE_BLANK_OIL
                  ,replace(TRIM(ITEM_6), noValue, 0)                                     -- TEMPERATURE_LIQUID_STEEL
                  ,replace(TRIM(ITEM_7), noValue, 0)                                     -- TEMPERATURE_FURNACE_ROOF
                  ,replace(TRIM(ITEM_8), noValue, 0)                                     -- CONSUMPTION_AIR
                  ,replace(TRIM(ITEM_9), noValue, 0)                                     -- CONSUMPTION_COMPRESSOR_AIR
                  ,replace(TRIM(ITEM_10), noValue, 0)                                    -- CONSUMPTION_OXYGEN
                  ,replace(TRIM(ITEM_11), noValue, 0)                                    -- CONSUMPTION_GAS
                  ,replace(TRIM(ITEM_12), noValue, 0)                                    -- CONSUMPTION_BLANK_OIL
                  ,SYSDATE
                  ,'SP_TR_D1TR003'
             FROM TB_PO_LEVEL2_INTERFACE 
            WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY
              AND NVL(TRIM(ITEM_1),'*') <> '*';  
 
 
      -- Furnace#2                                                                    
            INSERT INTO TB_PO_UTILITY_MPT
                  (MPT_GP
                  ,MEASURING_TIME
                  ,TEMP_AIR
                  ,TEMP_COMPRESSOR_AIR
                  ,TEMP_OXYGEN
                  ,TEMP_GAS
                  ,TEMP_BLANK_OIL
                  ,TEMP_LIQUID_STEEL
                  ,TEMP_FURNACE_ROOF
                  ,CONSUMPTION_AIR
                  ,CONSUMPTION_COMPRESSOR_AIR
                  ,CONSUMPTION_OXYGEN
                  ,CONSUMPTION_GAS
                  ,CONSUMPTION_BLANK_OIL
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT '2'                                               -- MPT_GP
                  --,TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS')      -- MEASURING_TIME
                  ,TO_DATE(TRIM(ITEM), date_template)      -- MEASURING_TIME
                  ,replace(TRIM(ITEM_13), noValue, 0)                                    -- TEMPERATURE_AIR
                  ,replace(TRIM(ITEM_14), noValue, 0)                                    -- TTEMPERATURE_COMPRESSOR_AIR
                  ,replace(TRIM(ITEM_15), noValue, 0)                                    -- TEMPERATURE_OXYGEN
                  ,replace(TRIM(ITEM_16), noValue, 0)                                    -- TEMPERATURE_GAS
                  ,replace(TRIM(ITEM_17), noValue, 0)                                    -- TEMPERATURE_BLANK_OIL
                  ,replace(TRIM(ITEM_18), noValue, 0)                                    -- TEMPERATURE_LIQUID_STEEL
                  ,replace(TRIM(ITEM_19), noValue, 0)                                   -- TEMPERATURE_FURNACE_ROOF
                  ,replace(TRIM(ITEM_20), noValue, 0)                                    -- CONSUMPTION_AIR
                  ,replace(TRIM(ITEM_21), noValue, 0)                                    -- CONSUMPTION_COMPRESSOR_AIR
                  ,replace(TRIM(ITEM_22), noValue, 0)                                    -- CONSUMPTION_OXYGEN
                  ,replace(TRIM(ITEM_23), noValue, 0)                                    -- CONSUMPTION_GAS
                  ,replace(TRIM(ITEM_24), noValue, 0)                                    -- CONSUMPTION_BLANK_OIL
                  ,SYSDATE
                  ,'SP_TR_D1TR003'
             FROM TB_PO_LEVEL2_INTERFACE 
            WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY
              AND NVL(TRIM(ITEM_13),'*') <> '*'; 
              
      -- Furnace#3                                                                    
            INSERT INTO TB_PO_UTILITY_MPT
                  (MPT_GP
                  ,MEASURING_TIME
                  ,TEMP_AIR
                  ,TEMP_COMPRESSOR_AIR
                  ,TEMP_OXYGEN
                  ,TEMP_GAS
                  ,TEMP_BLANK_OIL
                  ,TEMP_LIQUID_STEEL
                  ,TEMP_FURNACE_ROOF
                  ,CONSUMPTION_AIR
                  ,CONSUMPTION_COMPRESSOR_AIR
                  ,CONSUMPTION_OXYGEN
                  ,CONSUMPTION_GAS
                  ,CONSUMPTION_BLANK_OIL
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT '3'                                               -- MPT_GP
                  --,TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS')      -- MEASURING_TIME
                  ,TO_DATE(TRIM(ITEM), date_template)      -- MEASURING_TIME
                  ,replace(TRIM(ITEM_25), noValue, 0)                                    -- TEMPERATURE_AIR
                  ,replace(TRIM(ITEM_26), noValue, 0)                                    -- TTEMPERATURE_COMPRESSOR_AIR
                  ,replace(TRIM(ITEM_27), noValue, 0)                                    -- TEMPERATURE_OXYGEN
                  ,replace(TRIM(ITEM_28), noValue, 0)                                    -- TEMPERATURE_GAS
                  ,replace(TRIM(ITEM_29), noValue, 0)                                    -- TEMPERATURE_BLANK_OIL
                  ,replace(TRIM(ITEM_30), noValue, 0)                                    -- TEMPERATURE_LIQUID_STEEL
                  ,replace(TRIM(ITEM_31), noValue, 0)                                    -- TEMPERATURE_FURNACE_ROOF
                  ,replace(TRIM(ITEM_32), noValue, 0)                                    -- CONSUMPTION_AIR
                  ,replace(TRIM(ITEM_33), noValue, 0)                                    -- CONSUMPTION_COMPRESSOR_AIR
                  ,replace(TRIM(ITEM_34), noValue, 0)                                    -- CONSUMPTION_OXYGEN
                  ,replace(TRIM(ITEM_35), noValue, 0)                                    -- CONSUMPTION_GAS
                  ,replace(TRIM(ITEM_36), noValue, 0)                                    -- CONSUMPTION_BLANK_OIL
                  ,SYSDATE
                  ,'SP_TR_D1TR003'
             FROM TB_PO_LEVEL2_INTERFACE 
            WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY
              AND NVL(TRIM(ITEM_25),'*') <> '*';              

      -- Furnace#4                                                                    
            INSERT INTO TB_PO_UTILITY_MPT
                  (MPT_GP
                  ,MEASURING_TIME
                  ,TEMP_AIR
                  ,TEMP_COMPRESSOR_AIR
                  ,TEMP_OXYGEN
                  ,TEMP_GAS
                  ,TEMP_BLANK_OIL
                  ,TEMP_LIQUID_STEEL
                  ,TEMP_FURNACE_ROOF
                  ,CONSUMPTION_AIR
                  ,CONSUMPTION_COMPRESSOR_AIR
                  ,CONSUMPTION_OXYGEN
                  ,CONSUMPTION_GAS
                  ,CONSUMPTION_BLANK_OIL
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT '4'                                               -- MPT_GP
                  --,TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS')      -- MEASURING_TIME
                  ,TO_DATE(TRIM(ITEM), date_template)      -- MEASURING_TIME
                  ,replace(TRIM(ITEM_37), noValue, 0)                                    -- TEMPERATURE_AIR
                  ,replace(TRIM(ITEM_38), noValue, 0)                                    -- TTEMPERATURE_COMPRESSOR_AIR
                  ,replace(TRIM(ITEM_39), noValue, 0)                                    -- TEMPERATURE_OXYGEN
                  ,replace(TRIM(ITEM_40), noValue, 0)                                    -- TEMPERATURE_GAS
                  ,replace(TRIM(ITEM_41), noValue, 0)                                    -- TEMPERATURE_BLANK_OIL
                  ,replace(TRIM(ITEM_42), noValue, 0)                                    -- TEMPERATURE_LIQUID_STEEL
                  ,replace(TRIM(ITEM_43), noValue, 0)                                    -- TEMPERATURE_FURNACE_ROOF
                  ,replace(TRIM(ITEM_44), noValue, 0)                                    -- CONSUMPTION_AIR
                  ,replace(TRIM(ITEM_45), noValue, 0)                                    -- CONSUMPTION_COMPRESSOR_AIR
                  ,replace(TRIM(ITEM_46), noValue, 0)                                    -- CONSUMPTION_OXYGEN
                  ,replace(TRIM(ITEM_47), noValue, 0)                                    -- CONSUMPTION_GAS
                  ,replace(TRIM(ITEM_48), noValue, 0)                                    -- CONSUMPTION_BLANK_OIL
                  ,SYSDATE
                  ,'SP_TR_D1TR003'
             FROM TB_PO_LEVEL2_INTERFACE 
            WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY
              AND NVL(TRIM(ITEM_37),'*') <> '*';
              
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_UTILITY_MPT ISERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RETURN;
    END;

EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;