create or replace 
PROCEDURE      SP_TR_D1TR012 (IN_SEQUENCE_KEY       IN  VARCHAR2
                                                ,IN_TC_ID             IN  VARCHAR2
                                               )

 IS
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR012
 * VERSION           : V1.00
 * DESCRIPTION       : weight of Liquid steel in Siphon
 * DEVELOPER NAME    : Lee
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       :
 */-----------------------------------------------------------------------------

vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);

W_MELT_NO               TB_PO_SIPHON_RESULT.MELT_NO%TYPE;
W_SIPHON_NO             TB_PO_SIPHON_RESULT.SIPHON_NO%TYPE;
W_CRANE_WEIGHING_WT     TB_PO_SIPHON_RESULT.SIPHON_WT%TYPE;

W_CRANE_WEIGHING_TIME   DATE;


BEGIN

    SELECT TRIM(ITEM)
           ,TRIM(ITEM_1)
           ,TO_DATE(TRIM(ITEM_2),'DD-MM-YYYY HH24:MI:SS')
           ,TRIM(ITEM_4)
    INTO   W_MELT_NO
           ,W_SIPHON_NO
           ,W_CRANE_WEIGHING_TIME
           ,W_CRANE_WEIGHING_WT
    FROM   TB_PO_LEVEL2_INTERFACE
    WHERE  SEQUENCE_KEY = IN_SEQUENCE_KEY;
    
    
    BEGIN
        -- TB_PO_SIPHON_RESULT UPDATE FOR Previous Siphon data ----
        UPDATE TB_PO_SIPHON_RESULT
        SET    SIPHON_POURING_END_TIME = W_CRANE_WEIGHING_TIME
               ,SIPHON_WT              = SIPHON_WT - W_CRANE_WEIGHING_WT
        WHERE  (MELT_NO,SIPHON_NO)     = (SELECT MELT_NO,MAX(NVL(SIPHON_NO,0))
                                            FROM TB_PO_SIPHON_RESULT
                                           WHERE MELT_NO = W_MELT_NO
                                             AND SIPHON_POURING_END_TIME IS NULL
                                             AND SIPHON_NO <> W_SIPHON_NO
                                           GROUP BY MELT_NO
                                         );
        -- TB_PO_SIPHON_RESULT INSERT ----
        INSERT INTO TB_PO_SIPHON_RESULT
               (MELT_NO
               ,SIPHON_NO
               ,SIPHON_POURING_START_TIME
               ,SIPHON_WT
               ,REG_DDTT
               ,REGISTER)
        VALUES (W_MELT_NO
               ,W_SIPHON_NO
               ,W_CRANE_WEIGHING_TIME
               ,W_CRANE_WEIGHING_WT
               ,SYSDATE
               ,'SP_TR_D1TR012'
               );

    EXCEPTION
        WHEN  DUP_VAL_ON_INDEX  THEN
            NULL;
        WHEN  OTHERS  THEN
            vERR_CODE   :=  -20001;
            vERR_MSG    :=  'TB_PO_SIPHON_RESULT INSERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';
            RETURN;
    END;
--COMMIT;
EXCEPTION
    WHEN    OTHERS  THEN
        RAISE;
END;