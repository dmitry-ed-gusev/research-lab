--------------------------------------------------------
--  File created - Thursday-June-26-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure SP_TR_D1TR010
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "PMES"."SP_TR_D1TR010" (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

/*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR010        
 * VERSION           : V2.00                       
 * DESCRIPTION       : LF_end       
 * DEVELOPER NAME    : Lee, Gusev D.               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       : 02.10.2013
                     : 26.06.2014 - Hakimov R.
				-> Add processing new field 'SteelGradeCopy' at telegram 'D1TR010'
			       If in table 'TB_PM_MELT_WORK_SEQUENCE' field 'STLGRADE_NAME_LF'
				   is empty update this field from data in field 'ITEM_18' of this telegram 
*/-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D1TR010';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
processCode         varchar2(3)  := '202';  -- LF (AKOS) process code
stlMakingProgCode   varchar2(1)  := '6';    -- Pouring start code

-- parameters for procedure
telegramId          varchar2(7);   -- telegram id
meltNo              number;        --  
LFStartTime         date;          -- operation start time
LFEndTime           date;          -- operation end time
liquidSteelWeight   number;        --
errorMessage        varchar2(300); -- one error message
spErrorCode         number;        -- error code, returned from Stored Procedure 
spErrorMsg          varchar2(250); -- error message, returned from Stored Procedure
currentOperation    varchar2(300) := 'No operation.';    -- current processing operation

akosMaster          varchar2(50 char);  -- akos master info from telegram
akosWorker          varchar2(50 char);  -- akos worker info from telegram
splitResult         common_fn.stringsListTable; -- data processing tmp data
oneShift            common_fn.oneShiftRecord;
tmpChar             varchar2(1 char);  -- temporary symbol

curStlGradeName     VARCHAR2(30);  -- current steel grade name in table TB_PM_MELT_WORK_SEQUENCE (field STLGRADE_NAME_LF)
stlGradeNameCopy    VARCHAR2(30);  -- steel grade name copy

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  currentOperation := 'Operation [prepare some data].'; 
  -- select some data 
  SELECT TRIM(ITEM), TO_DATE(TRIM(ITEM_1), dateTimeTemplate), to_number(TRIM(ITEM_5), '99999.99'), trim(item_17), trim(item_16), trim(item_18) 
    INTO meltNo, LFEndTime, liquidSteelWeight, akosMaster, akosWorker, stlGradeNameCopy
      FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY; 
      
  -- 1. Update TB_PO_MPT_RESULT table
  BEGIN
    currentOperation := 'Operation [TB_PO_MPT_RESULT update].';
    UPDATE TB_PO_MPT_RESULT SET STLMAKING_PROG_CD = stlMakingProgCode /*Pouring Start*/, LF_END_TIME = LFEndTime, MELT_OUT_WT = liquidSteelWeight, 
      LF_PETROL_DATE = FN_PETRODATE(TO_CHAR(LFEndTime,'DD-MM-YYYY HH24:MI:SS'),'DD-MM-YYYY HH24:MI:SS','YYYYMMDD') /*shifts date/time 59,99 minutes forward*/,
        MOD_DDTT = SYSDATE, MODIFIER = procedureName WHERE MELT_NO = meltNo;
    EXCEPTION          
      WHEN NO_DATA_FOUND THEN  -- process every execption case
        errors := common_fn.process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
      RETURN;               
  END;
	
  -- 2. Get value of field STLGRADE_NAME_LF from table TB_PM_MELT_WORK_SEQUENCE
  BEGIN
    currentOperation := 'Operation [TB_PM_MELT_WORK_SEQUENCE get value of field STLGRADE_NAME_LF].';
	  curStlGradeName := '';
	  SELECT STLGRADE_NAME_LF into curStlGradeName FROM TB_PM_MELT_WORK_SEQUENCE
	    WHERE MELT_NO = meltNo;
	  EXCEPTION          
      WHEN NO_DATA_FOUND THEN
	    BEGIN
        errors := common_fn.process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
	  END;
  END;
  
  -- 3. Check is steel grade name is null or empty -> get steel grade name from this telegram
  IF curStlGradeName = '' OR curStlGradeName IS NULL THEN
    curStlGradeName := stlGradeNameCopy;
  END IF;
	
  -- 4. Update TB_PM_MELT_WORK_SEQUENCE table
  BEGIN
    currentOperation := 'Operation [TB_PM_MELT_WORK_SEQUENCE insert].';
    UPDATE TB_PM_MELT_WORK_SEQUENCE SET 
	  STLMAKE_STATUS_CD = stlMakingProgCode, STLGRADE_NAME_LF = curStlGradeName,
      MOD_DDTT = SYSDATE, MODIFIER = procedurename WHERE MELT_NO = meltNo;
    EXCEPTION          
      WHEN NO_DATA_FOUND THEN
        errors := common_fn.process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
      RETURN;
  END;
  
  -- 5. Insert workers data into table tb_po_shift_worker
  -- object 'one work shift'
  oneShift.workDate := to_char(LFEndTime, 'YYYYMMDD');
  -- processing master
  splitResult := common_fn.split(akosMaster, ' ');
  currentOperation := 'Operation [parse master data in telegram].';
  if splitResult.count = 2 then -- data is ok
    begin
      currentOperation := 'Operation [check master in tb_employees, master = ['||splitResult(1)||'/'||splitResult(2)||']].';             
      select short_rus_name, to_number(emp_number, '9999') into oneShift.masterName, oneShift.masterClock 
        from tb_employees where short_rus_name like splitResult(1)||'%' 
          and emp_number like '%'||splitResult(2) and is_alive = 'Y';
    exception  -- no data found about master 
      when no_data_found then
        errors := common_fn.process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
        oneShift.masterName  := '-';
        oneShift.masterClock := 0;
    end;
  else -- data is wrong!
    errors := common_fn.process_error('-', 0, telegramId, in_sequence_key, currentOperation, errors);
    oneShift.masterName  := '-';
    oneShift.masterClock := 0;
  end if;
  
  -- processing worker
  splitResult := common_fn.split(akosWorker, ' ');
  currentOperation := 'Operation [parse worker data in telegram].';
  if splitResult.count >= 3 then -- data is ok
    begin
      currentOperation := 'Operation [check worker in tb_employees, worker = ['||splitResult(1)||'/'||splitResult(2)||']].';
      select short_rus_name, to_number(emp_number, '9999') into oneShift.workerName, oneShift.workerClock
        from tb_employees where short_rus_name like splitResult(1)||'%'
          and emp_number like '%'||splitResult(2) and is_alive = 'Y';
    exception -- no data found about worker
      when no_data_found then
        errors := common_fn.process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
        oneShift.workerName  := '-';
        oneShift.workerClock := 0;
    end;
    -- processing shift (������� �������)
    currentOperation := 'Operation [check working shift].';
    if length(splitResult(3)) > 1 then
      tmpChar := substr(splitResult(3), 2, 1);
      oneShift.workShift := 
        CASE WHEN tmpChar = '�' THEN 'A' -- use english 'A' instead of russian 'A'
             WHEN tmpChar = '�' THEN 'B' -- use english 'B' instead of russian '�'
             WHEN tmpChar = '�' THEN 'C' -- use english 'C' instead of russian '�'
             WHEN tmpChar = '�' THEN 'D' -- use english 'D' instead of russian '�'
             ELSE '-' END;  -- default case
    else
      errors := common_fn.process_error('-', 0, telegramId, in_sequence_key, currentOperation, errors);
      oneShift.workShift := '-';
    end if;
    /*
    -- processing duty (������� �������)
    currentOperation := 'Operation [check working duty].';
    if length(splitResult(4)) > 2 then
      oneShift.workDuty := substr(splitResult(4), 3, 1);
    else
      errors := common_fn.process_error('-', 0, telegramId, in_sequence_key, currentOperation, errors);
      oneShift.workDuty := 0;
    end if;
    */
  else -- data is wrong
    errors := common_fn.process_error('-', 0, telegramId, in_sequence_key, currentOperation, errors);
  end if;
  
  --dbms_output.put_line(oneShift.workDate);
  --dbms_output.put_line(oneShift.workDuty);
  --dbms_output.put_line(oneShift.workShift);
  --dbms_output.put_line(oneShift.workerClock);
  --dbms_output.put_line(oneShift.workerName);
  --dbms_output.put_line(oneShift.masterClock);
  --dbms_output.put_line(oneShift.masterName);
  
  -- select duty number by time LF end
  select work_duty into oneShift.workDuty from 
   (SELECT WORK_DUTY, START_HR, END_HR FROM TB_PM_WORKDUTY_HR_STD  -- this select for duties 7-15 and 15-23
      WHERE SHOP_PROC_GP = '102' AND START_HR  < END_HR AND START_HR <= to_char(LFEndTime, 'HH24:MI')
      AND END_HR    > to_char(LFEndTime, 'HH24:MI')
    UNION ALL
    SELECT WORK_DUTY, START_HR, END_HR FROM TB_PM_WORKDUTY_HR_STD -- this select for duty 23-7
     WHERE SHOP_PROC_GP = '102' AND START_HR > END_HR 
      AND ((START_HR >= to_char(LFEndTime, 'HH24:MI') AND END_HR > to_char(LFEndTime, 'HH24:MI')) 
       OR (START_HR <= to_char(LFEndTime, 'HH24:MI') AND END_HR < to_char(LFEndTime, 'HH24:MI'))));
     
  -- insert processed data into TB_PO_SHIFT_WORKER table (record oneShift should be filled with info!)
  begin
    insert into tb_po_shift_worker (work_date, plant_proc_cd, mpt_gp, work_duty, work_shift, 
     worker_organic_no, worker_name, master_organic_no, master_name, reg_ddtt, register) 
       values (oneShift.workDate, processCode, 0, oneShift.workDuty, oneShift.workShift,
         oneShift.workerClock, oneShift.workerName, oneShift.masterClock, oneShift.masterName, sysdate, procedureName);
    commit;     
  exception
    when dup_val_on_index then
     errors := common_fn.process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  end;
  
  -- 6. Call stored procedure SP_TR_250_SHIFT (working with table TB_PO_WORK_SHIFT_RESULT)
  begin
    currentOperation := 'Operation select data from table ''TB_PO_LF_RESULT'' on melt_no = [' || meltNo || '].';
    SELECT LF_START_TIME INTO LFStartTime FROM TB_PO_LF_RESULT WHERE MELT_NO = meltNo;
    EXCEPTION
      when NO_DATA_FOUND then -- no data found with current meltNo
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  end;
  -- call stored procedure
  currentOperation := 'Operation [SP_TR_250_SHIFT call].';
  SP_TR_250_SHIFT (meltNo, '0', processCode, TO_CHAR(LFStartTime, 'YYYYMMDDHH24MI'), 
    TO_CHAR(LFEndTime,'YYYYMMDDHH24MI'), liquidSteelWeight, spErrorCode, spErrorMsg);
  -- if SP returns not empty error message - add it (message) to resulting errors list
  IF spErrorMsg IS NOT NULL THEN
    errors := common_fn.process_error(spErrorMsg, spErrorCode, telegramId, in_sequence_key, currentOperation, errors);
  END IF;
    
  -- 7. Call stored procedure SP_TR_200_MONITOR (working with monitoring table TB_PO_MONITORING)
  currentOperation := 'Operation [SP_TR_200_MONITOR call].';
  SP_TR_200_MONITOR (processCode, 'E', meltNo, TO_CHAR(LFEndTime,'YYYYMMDDHH24MI'), NULL, 'E', NULL, NULL, spErrorCode, spErrorMsg);
  IF spErrorMsg IS NOT NULL THEN
    errors := common_fn.process_error(spErrorMsg, spErrorCode, telegramId, in_sequence_key, currentOperation, errors);
  END IF;
  
  -- 8. Update TB_PO_LF_RESULT table
  BEGIN
    currentOperation := 'Operation [TB_PO_LF_RESULT update].';
    UPDATE TB_PO_LF_RESULT SET (LF_END_TIME, LIQUID_STEEL_WT, SLAG_WT, LF_DURATION_TIME, GAS_POUR_DURATION_TIME, PWR_USE_DURATION_TIME,
      FIRST_TEMP, LAST_TEMP, AR_CONSUME_BOTTOM, AR_CONSUME_LANCE, N2_CONSUMPTION_BOTTOM, N2_CONSUMPTION_LANCE, PWR_CONSUMPTION_HR,
        PWR_CONSUMPTION_TON, LF_AIM_TEMP) = 
          (SELECT TO_DATE(TRIM(ITEM_1), dateTimeTemplate) /*LF_END_TIME*/, to_number(TRIM(ITEM_5), '99999.99') /*LIQUID_STEEL_WT*/, to_number(TRIM(ITEM_6), '99999.99') /*SLAG_WT*/,
            TRIM(ITEM_2) /*LF_DURATION_TIME*/, TRIM(ITEM_3) /*GAS_POUR_DURATION_TIME*/, TRIM(ITEM_4) /*PWR_USE_DURATION_TIME*/,
              TRIM(ITEM_7) /*FIRST_TEMP*/, TRIM(ITEM_8) /*LAST_TEMP*/, to_number(TRIM(ITEM_9), '99999.99') /*AR_CONSUME_BOTTOM*/, to_number(TRIM(ITEM_10), '9999999') /*AR_CONSUME_LANCE*/, 
                to_number(TRIM(ITEM_11), '9999999') /*N2_CONSUMPTION_BOTTOM*/, to_number(TRIM(ITEM_12), '9999999') /*N2_CONSUMPTION_LANCE*/, to_number(TRIM(ITEM_13), '99999.99') /*PWR_CONSUMPTION_HR*/,
                  to_number(TRIM(ITEM_14), '99999.99') /*PWR_CONSUMPTION_TON*/, TRIM(ITEM_15) /*LF_AIM_TEMP*/ FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY),
          MOD_DDTT = SYSDATE, MODIFIER = procedureName WHERE MELT_NO = meltNo; 
                   
  EXCEPTION          
    WHEN NO_DATA_FOUND THEN
      errors := common_fn.process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
    RETURN;
  END;

EXCEPTION -- common exception handling statement  
  WHEN OTHERS THEN
    errors := common_fn.process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, 'Common case. '||currentOperation, errors);      
END;

/
