create or replace
PROCEDURE      SP_TR_D1TR011 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )

 IS
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR011
 * VERSION           : V1.00
 * DESCRIPTION       : Pouring_start
 * DEVELOPER NAME    : Lee
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       :
 */-----------------------------------------------------------------------------

vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);

W_MELT_NO               NUMBER;
W_POURING_START_TIME    DATE;
W_WEIGHT                NUMBER;
W_LADLE_NO              NUMBER;

BEGIN
     SELECT TRIM(ITEM)
           ,TO_DATE(ITEM_1,'DD-MM-YYYY HH24:MI:SS')
           ,TRIM(ITEM_2)
           ,TRIM(ITEM_3)
      INTO W_MELT_NO
           ,W_POURING_START_TIME
           ,W_WEIGHT
           ,W_LADLE_NO
      FROM TB_PO_LEVEL2_INTERFACE
     WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;

    --TB_PO_LEVEL2_INTERFACE Search & TB_PO_MPT_RESULT UPDATE ----------
    BEGIN
           UPDATE TB_PO_MPT_RESULT
              SET STLMAKING_PROG_CD = '6'
                  ,POURING_START_TIME = W_POURING_START_TIME
                  ,MOD_DDTT = SYSDATE
                  ,MODIFIER = 'SP_TR_D1TR011'
            WHERE MELT_NO = W_MELT_NO;

    EXCEPTION
        WHEN  NO_DATA_FOUND  THEN
            vERR_CODE   :=  -20001;
            vERR_MSG    :=  'TB_PO_MPT_RESULT UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';
            RETURN;
    END;

    BEGIN
           UPDATE  TB_PM_MELT_WORK_SEQUENCE
              SET  STLMAKE_STATUS_CD = '6'
                  ,MOD_DDTT = SYSDATE
                  ,MODIFIER = 'SP_TR_D1TR011'
            WHERE  MELT_NO = W_MELT_NO;

    EXCEPTION
        WHEN  NO_DATA_FOUND  THEN
            vERR_CODE   :=  -20001;
            vERR_MSG    :=  'TB_PM_MELT_WORK_SEQUENCE'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';
            RETURN;
    END;


    --TB_PO_LEVEL2_INTERFACE Search & TB_PO_LF_RESULT INSERT----------
    BEGIN
           INSERT INTO TB_PO_POURING_RESULT
                  (MELT_NO
                  ,POURING_START_TIME
                  ,REG_DDTT
                  ,REGISTER
                  )
           VALUES (W_MELT_NO
                  ,W_POURING_START_TIME
                  ,SYSDATE
                  ,'SP_TR_D1TR011'
                  );

    EXCEPTION
        WHEN  DUP_VAL_ON_INDEX   THEN
              UPDATE  TB_PO_POURING_RESULT
                 SET  POURING_START_TIME = W_POURING_START_TIME
               WHERE  MELT_NO = W_MELT_NO;
    END;
    -- MONITORING DATA SET
    SP_TR_200_MONITOR  ('203'
                       ,'F'
                       ,W_MELT_NO
                       ,TO_CHAR(W_POURING_START_TIME,'YYYYMMDDHH24MI')
                       ,NULL
                       ,'S'
                       ,NULL
                       ,NULL
                       ,vERR_CODE
                       ,vERR_MSG
                      );
    IF  vERR_MSG  IS NOT NULL  THEN
        RETURN;
    END IF;

EXCEPTION
    WHEN    OTHERS  THEN
            vERR_CODE   := TO_CHAR(SQLCODE);
            vERR_MSG   := 'SYSTEM ERROR = ' || SQLERRM;
        RAISE;
END;