create or replace 
PROCEDURE SP_TR_D1TR001 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

/*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR001        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Scrap weight information processing.
                       Error hadling occurs after every insert/update/delete statement 
                       and also we have common exceptions handling block - we want to
                       have ability to determine exception place - operation+table.
 * DEVELOPER NAME    : Lee, Gusev D.               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       : 03.10.2013                                                       
*/-----------------------------------------------------------------------------
  
-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D1TR001';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
processCode         varchar2(3)  := '201';  -- MPT process code
stlMakingProgCode   varchar2(1)  := '3';  -- ???
-- parameters for procedure
telegramId          varchar2(7);           -- telegram id
meltNo              number;                -- melt number
mptGroup            varchar2(1);           -- Siemens Martin number 1-2-3-4
meltMgmtNumber      number;                -- melt mgmt number - ???
addDeleteSign       varchar(1) := '-';     -- add/delete record about weighing (initial -> unknown)
materialPutDateTime date;                  -- put date/time (from scrap weigher) 
counter             number;                -- temporary counter
currentOperation    varchar2(200) := null; -- current processed operation (null - initial value, no operation)

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
    
  -- select melt number, put date/time, add/delete sign
  select to_number(trim(item)), to_date(trim(item_9), dateTimeTemplate), trim(item_11) into meltNo, materialPutDateTime, addDeleteSign 
   from tb_po_level2_interface where sequence_key = in_sequence_key;
    
  -- calculate mpt group
  mptGroup := 
    CASE WHEN SUBSTR(meltNo, 1, 1) = '5' THEN '1' 
         WHEN SUBSTR(meltNo, 1, 1) = '6' THEN '2' 
         WHEN SUBSTR(meltNo, 1, 1) = '7' THEN '3' 
         ELSE '4' END;
    
  -- 1. Insert data into TB_PO_MPT_RESULT table 
  SELECT COUNT(MELT_NO) INTO counter FROM TB_PO_MPT_RESULT WHERE MELT_NO = meltNo; -- count value
  IF  counter < 1 THEN -- if there is no such data in a table
    BEGIN
      currentOperation := 'Operation [TB_PO_MPT_RESULT insert].'; -- current operation marker for error handling
      INSERT INTO TB_PO_MPT_RESULT (MELT_NO, MPT_GP, STLMAKING_PROG_CD, OLD_MELT_NO, REG_DDTT, REGISTER)
        values (meltNo, mptGroup, stlMakingProgCode, meltNo, sysdate, procedureName);
      EXCEPTION -- on exception -> collect information and process next
        when DUP_VAL_ON_INDEX then -- duplicate value, we just collect error and proceed
          errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);       
    END;
  END IF; 
    
  -- 2. Insert data into TB_PM_MELT_WORK_SEQUENCE table
  SELECT COUNT(MELT_NO) INTO counter FROM TB_PM_MELT_WORK_SEQUENCE WHERE MELT_NO = meltNo; -- count value  
  IF  counter < 1 THEN -- if there is no such data in a table  
    BEGIN
      currentOperation := 'Operation [TB_PM_MELT_WORK_SEQUENCE insert].'; -- current operation marker for error handling
      -- calculate melt management number
      SELECT TO_CHAR(MAX(TO_NUMBER(MELT_MGMT_NO)) + 1) into meltMgmtNumber FROM TB_PM_MELT_WORK_SEQUENCE;
      -- insert data
      INSERT INTO TB_PM_MELT_WORK_SEQUENCE (MELT_MGMT_NO, WORK_PLAN_DD, PRIOR_IN_DATE, MELT_NO, MPT_GP, STLMAKE_STATUS_CD, REG_DDTT, REGISTER)
        values (meltMgmtNumber, to_char(sysdate, 'YYYYMMDD'), 1, meltNo, mptGroup, stlMakingProgCode, sysdate, procedureName);
      EXCEPTION
        when DUP_VAL_ON_INDEX then -- duplicate value, we just collect error and proceed
          errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
    END;
  END IF; 
           
  -- 3. Insert data into TB_PO_MATERIAL_PUT_RESULT table
  BEGIN
    currentOperation := 'Operation [TB_PO_MATERIAL_PUT_RESULT insert/delete]. Flag ['||addDeleteSign||'].'; -- current operation marker for error handling
    IF addDeleteSign = 'D' THEN -- delete record
      DELETE TB_PO_MATERIAL_PUT_RESULT WHERE MELT_NO = meltNo and PLANT_PROC_CD = processCode and PUT_TIME = materialPutDateTime;
    ELSE
      INSERT INTO TB_PO_MATERIAL_PUT_RESULT (MELT_NO, PLANT_PROC_CD, PUT_TIME, RAW_MATERIAL_CD, BASKET_TYPE, BASKET_QNTY,
        WHOLE_WT, NET_WT, ALLOCATED_WT, BASKET_WT, WEIGHER_POSITION, CHECK_NO, REG_DDTT, REGISTER)
          -- values to insert (received by select statement) 
          SELECT meltNo, processCode, materialPutDateTime, TRIM(ITEM_8) /*RAW_MATERIAL_CD*/, TRIM(ITEM_2) /*BASKET_TYPE*/,
            TRIM(ITEM_3) /*BASKET_QNTY*/, TRIM(ITEM_4) /*WHOLE_WT*/, TRIM(ITEM_5) /*NET_WT*/, TRIM(ITEM_5) /*NET_WT (ALLOCATED_WT)*/,
            TRIM(ITEM_6) /*BASKET_WT*/, TRIM(ITEM_7) /*WEIGHER_POSITION*/, TRIM(ITEM_10) /*CHECK_NO*/, SYSDATE, procedureName
              FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
    END IF;    
    EXCEPTION
      when DUP_VAL_ON_INDEX then -- duplicate value, we just collect error and proceed
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
      
COMMIT; -- commit all actions

EXCEPTION -- catch common exceptions
  WHEN OTHERS THEN
    errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;