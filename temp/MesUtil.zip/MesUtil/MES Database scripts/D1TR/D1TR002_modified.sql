create or replace 
PROCEDURE SP_TR_D1TR002 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

/*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR002        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Chemical composition         
 * DEVELOPER NAME    : Lee, Gusev D.               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       : 01.10.2013                                                      
 * CHANGES HISTORY   :
*   - added template for converting char->number: to_number(char_value, '9.9999')
*/-----------------------------------------------------------------------------
  
-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D1TR002';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
probeCodeSymbol     char(1 char) := '?';  -- Value shows what current telegram contains data with standard probe of steel
-- parameters for procedure
telegramId          varchar2(7);   -- telegram id
meltNo              number;        -- melt number
testSequenceNumber  NUMBER;        -- number of chemical test sequence for current melt
processCode         varchar2(10);  -- current process code
currentProbeNumber  varchar(10 char);  -- current number of probe

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  -- Get current probe number
  select trim(item_1) into currentProbeNumber from tb_po_level2_interface where sequence_key = in_sequence_key;
  
  -- If probe number equals variable 'probeCodeSymbol' - telegram contains data with standard probe of steel
  if substr(currentProbeNumber, 0, 1) = probeCodeSymbol then
    INSERT INTO TB_QM_STANDARD_ANALYS_INGR (PROBE_CODE, SAMPLING_TIME,
      C_VAL, SI_VAL, MN_VAL, S_VAL, P_VAL, CR_VAL, NI_VAL, CU_VAL, W_VAL, MO_VAL, V_VAL, AL_VAL, TI_VAL,
        B_VAL, NB_VAL, PB_VAL, N_VAL, SN_VAL, AS_VAL, H2_VAL, O2_VAL, ZN_VAL, SB_VAL, CA_VAL, CEQU_VAL,
          LAB_TIME, CHECK_NO, REG_DDTT, REGISTER)
            SELECT TRIM(ITEM), TO_DATE(TRIM(ITEM_3), dateTimeTemplate) /*SAMPLING_TIME(LAB)*/,
             TO_NUMBER(TRIM(ITEM_4), '9.9999')  /*C_VAL*/,  TO_NUMBER(TRIM(ITEM_5), '9.9999')  /*SI_VAL8*/,
             TO_NUMBER(TRIM(ITEM_6), '9.9999')  /*MN_VAL*/, TO_NUMBER(TRIM(ITEM_7), '9.9999')  /*S_VAL*/,
             TO_NUMBER(TRIM(ITEM_8), '9.9999')  /*P_VAL*/,  TO_NUMBER(TRIM(ITEM_9), '9.9999')  /*CR_VAL*/,
             TO_NUMBER(TRIM(ITEM_10), '9.9999') /*NI_VAL*/, TO_NUMBER(TRIM(ITEM_11), '9.9999') /*CU_VAL*/,
             TO_NUMBER(TRIM(ITEM_12), '9.9999') /*W_VAL*/,  TO_NUMBER(TRIM(ITEM_13), '9.9999') /*MO_VAL*/,
             TO_NUMBER(TRIM(ITEM_14), '9.9999') /*V_VAL*/,  TO_NUMBER(TRIM(ITEM_15), '9.9999') /*AL_VAL*/,
             TO_NUMBER(TRIM(ITEM_16), '9.9999') /*TI_VAL*/, TO_NUMBER(TRIM(ITEM_17), '9.9999') /*B_VAL*/,
             TO_NUMBER(TRIM(ITEM_18), '9.9999') /*NB_VAL*/, TO_NUMBER(TRIM(ITEM_19), '9.9999') /*PB_VAL*/,
             TO_NUMBER(TRIM(ITEM_20), '9.9999') /*N_VAL*/,  TO_NUMBER(TRIM(ITEM_21), '9.9999') /*SN_VAL*/,
             TO_NUMBER(TRIM(ITEM_22), '9.9999') /*AS_VAL*/, TO_NUMBER(TRIM(ITEM_23), '9.9999') /*H2_VAL*/,
             TO_NUMBER(TRIM(ITEM_24), '9.9999') /*O2_VAL*/, TO_NUMBER(TRIM(ITEM_25), '9.9999') /*ZN_VAL*/,
             TO_NUMBER(TRIM(ITEM_26), '9.9999') /*SB_VAL*/, TO_NUMBER(TRIM(ITEM_27), '9.9999') /*CA_VAL*/,
             TO_NUMBER(TRIM(ITEM_28), '9.9999') /*CEQU_VAL*/,
             TO_DATE(TRIM(ITEM_29), dateTimeTemplate) /*SAMPLE TAKE TIME*/, TRIM(ITEM_30) /*CHECK_NO*/,
             SYSDATE, procedureName 
               FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
               
  else -- telegram contains data with current probe of steel
    -- select melt number
    select to_number(trim(item)), trim(item_2) into meltNo, processCode from tb_po_level2_interface where sequence_key = in_sequence_key;
    -- calculate current process code
    processCode := CASE WHEN processCode IN ('SIEM1','SIEM2','SIEM3','SIEM4') THEN '201' -- MPT process 
                        WHEN processCode IN ('LADLE')                         THEN '202' -- LF process 
                        ELSE                                                       '203' -- POURING process
                        END;
    
    -- 1. select chemical test sequence number from TB_QM_STL_ANALYSIS_INGR 
    SELECT NVL(MAX(TEST_SEQ), 0) INTO testSequenceNumber FROM TB_QM_STL_ANALYSIS_INGR WHERE MELT_NO = meltNo; 
    -- 2. if there are chemical tests for this melt number, we remove LAST_YN sign from last chemical test for melt
    IF testSequenceNumber > 0 THEN   
     UPDATE TB_QM_STL_ANALYSIS_INGR SET LAST_YN = NULL where melt_no = meltNo and test_seq = testSequenceNumber; 
    END IF;
    
    -- 3. Insert data into TB_QM_STL_ANALYSIS_INGR table  
    testSequenceNumber := testSequenceNumber + 1;  -- increment test sequence number
    -- inserting data
    INSERT INTO TB_QM_STL_ANALYSIS_INGR (MELT_NO, PLANT_PROC_CD, TEST_SEQ, LAST_YN, SAMPLING_TIME,
      C_VAL, SI_VAL, MN_VAL, S_VAL, P_VAL, CR_VAL, NI_VAL, CU_VAL, W_VAL, MO_VAL, V_VAL, AL_VAL, TI_VAL,
        B_VAL, NB_VAL, PB_VAL, N_VAL, SN_VAL, AS_VAL, H2_VAL, O2_VAL, ZN_VAL, SB_VAL, CA_VAL, CEQU_VAL,
          LAB_TIME, CHECK_NO, REG_DDTT, REGISTER)
            SELECT meltNo, processCode, testSequenceNumber, 'Y' /*LAST_YN sequence sign*/, TO_DATE(TRIM(ITEM_3), dateTimeTemplate) /*SAMPLING_TIME(LAB)*/,
             TO_NUMBER(TRIM(ITEM_4), '9.9999')  /*C_VAL*/,  TO_NUMBER(TRIM(ITEM_5), '9.9999')  /*SI_VAL8*/,
             TO_NUMBER(TRIM(ITEM_6), '9.9999')  /*MN_VAL*/, TO_NUMBER(TRIM(ITEM_7), '9.9999')  /*S_VAL*/,
             TO_NUMBER(TRIM(ITEM_8), '9.9999')  /*P_VAL*/,  TO_NUMBER(TRIM(ITEM_9), '9.9999')  /*CR_VAL*/,
             TO_NUMBER(TRIM(ITEM_10), '9.9999') /*NI_VAL*/, TO_NUMBER(TRIM(ITEM_11), '9.9999') /*CU_VAL*/,
             TO_NUMBER(TRIM(ITEM_12), '9.9999') /*W_VAL*/,  TO_NUMBER(TRIM(ITEM_13), '9.9999') /*MO_VAL*/,
             TO_NUMBER(TRIM(ITEM_14), '9.9999') /*V_VAL*/,  TO_NUMBER(TRIM(ITEM_15), '9.9999') /*AL_VAL*/,
             TO_NUMBER(TRIM(ITEM_16), '9.9999') /*TI_VAL*/, TO_NUMBER(TRIM(ITEM_17), '9.9999') /*B_VAL*/,
             TO_NUMBER(TRIM(ITEM_18), '9.9999') /*NB_VAL*/, TO_NUMBER(TRIM(ITEM_19), '9.9999') /*PB_VAL*/,
             TO_NUMBER(TRIM(ITEM_20), '9.9999') /*N_VAL*/,  TO_NUMBER(TRIM(ITEM_21), '9.9999') /*SN_VAL*/,
             TO_NUMBER(TRIM(ITEM_22), '9.9999') /*AS_VAL*/, TO_NUMBER(TRIM(ITEM_23), '9.9999') /*H2_VAL*/,
             TO_NUMBER(TRIM(ITEM_24), '9.9999') /*O2_VAL*/, TO_NUMBER(TRIM(ITEM_25), '9.9999') /*ZN_VAL*/,
             TO_NUMBER(TRIM(ITEM_26), '9.9999') /*SB_VAL*/, TO_NUMBER(TRIM(ITEM_27), '9.9999') /*CA_VAL*/,
             TO_NUMBER(TRIM(ITEM_28), '9.9999') /*CEQU_VAL*/,
             TO_DATE(TRIM(ITEM_29), dateTimeTemplate) /*SAMPLE TAKE TIME*/, TRIM(ITEM_30) /*CHECK_NO*/,
             SYSDATE, procedureName 
               FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;  
   end if;
           
EXCEPTION
  WHEN  OTHERS  THEN  -- process every exception case 
   errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, 'Operation [TB_QM_STL_ANALYSIS_INGR update/insert].', errors);
END;