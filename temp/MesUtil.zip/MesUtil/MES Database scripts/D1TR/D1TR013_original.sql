create or replace 
PROCEDURE      SP_TR_D1TR013 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR013        
 * VERSION           : V1.00                       
 * DESCRIPTION       : Pouring_end       
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);

W_MELT_NO               TB_PO_SIPHON_RESULT.MELT_NO%TYPE;
W_CRANE_WEIGHING_WT     TB_PO_SIPHON_RESULT.SIPHON_WT%TYPE;

W_CRANE_WEIGHING_TIME   DATE;
  
BEGIN 
    
    SELECT TRIM(ITEM)
           ,TO_DATE(TRIM(ITEM_1),'DD-MM-YYYY HH24:MI:SS')
           ,TRIM(ITEM_2)
    INTO   W_MELT_NO
           ,W_CRANE_WEIGHING_TIME
           ,W_CRANE_WEIGHING_WT
    FROM   TB_PO_LEVEL2_INTERFACE
    WHERE  SEQUENCE_KEY = IN_SEQUENCE_KEY;
    
    -- TB_PO_MPT_RESULT UPDATE ----------
    BEGIN
           UPDATE TB_PO_MPT_RESULT
              SET STLMAKING_PROG_CD = '7'    -- Ingot extraction waiting
                  ,POURING_END_TIME = W_CRANE_WEIGHING_TIME
                  ,POUR_PETROL_DATE = FN_PETRODATE(TO_CHAR(W_CRANE_WEIGHING_TIME,'YYYYMMDDHH24MISS'),'YYYYMMDDHH24MISS','YYYYMMDD')
                  ,MELT_DATE        = FN_PETRODATE(TO_CHAR(W_CRANE_WEIGHING_TIME,'YYYYMMDDHH24MISS'),'YYYYMMDDHH24MISS','YYYYMMDD')
                  ,MOD_DDTT = SYSDATE
                  ,MODIFIER = 'SP_TR_D1TR013'    
            WHERE MELT_NO = W_MELT_NO; 
                   
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_MPT_RESULT UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';       
            RETURN;
    END;
    
    -- TB_PM_MELT_WORK_SEQUENCE UPDATE ----------
    BEGIN
           UPDATE TB_PM_MELT_WORK_SEQUENCE
              SET STLMAKE_STATUS_CD = '7'
                  ,MOD_DDTT         = SYSDATE
                  ,MODIFIER         = 'SP_TR_D1TR013'    
            WHERE MELT_NO = W_MELT_NO;
                   
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PM_MELT_WORK_SEQUENCE UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';       
            RETURN;
    END;

    
    BEGIN
           --TTB_PO_SIPHON_RESULT UPDATE ----------------
           UPDATE TB_PO_SIPHON_RESULT
              SET SIPHON_POURING_END_TIME = W_CRANE_WEIGHING_TIME
                  ,SIPHON_WT              = SIPHON_WT - W_CRANE_WEIGHING_WT                  
            WHERE MELT_NO = W_MELT_NO
              AND SIPHON_POURING_END_TIME IS NULL;
           
           --TB_PO_POURING_RESULT UPDATE ----------
           UPDATE TB_PO_POURING_RESULT
              SET POURING_END_TIME = W_CRANE_WEIGHING_TIME
                  ,MOD_DDTT = SYSDATE
                  ,MODIFIER = 'SP_TR_D1TR013'    
            WHERE MELT_NO = (SELECT TRIM(ITEM)
                               FROM TB_PO_LEVEL2_INTERFACE 
                              WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY); 
                   
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_LF_RESULT UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';       
            RETURN;
    END;
    
    
    -- MONITORING DATA SET
    SP_TR_200_MONITOR  ('203'
                       ,'F'
                       ,W_MELT_NO
                       ,NULL
                       ,TO_CHAR(W_CRANE_WEIGHING_TIME,'YYYYMMDDHH24MI')
                       ,'E'
                       ,NULL
                       ,NULL
                       ,vERR_CODE 
                       ,vERR_MSG 
                      );
    IF  vERR_MSG  IS NOT NULL  THEN
        RETURN;
    END IF;


EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;