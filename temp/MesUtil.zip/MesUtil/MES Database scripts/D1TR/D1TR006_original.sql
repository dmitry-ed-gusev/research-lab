create or replace
PROCEDURE      SP_TR_D1TR006 (IN_SEQUENCE_KEY       IN  VARCHAR2
                                                ,IN_TC_ID             IN  VARCHAR2
                                               )

 IS
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR006
 * VERSION           : V1.00
 * DESCRIPTION       : Consumption of LF materials
 * DEVELOPER NAME    : Lee
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       :
 */-----------------------------------------------------------------------------

vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);

BEGIN

    --TB_PO_LEVEL2_INTERFACE Search & TB_PO_MATERIAL_PUT_RESULT INSERT----------
    BEGIN
           INSERT INTO TB_PO_MATERIAL_PUT_RESULT
                  (MELT_NO
                  ,PLANT_PROC_CD
                  ,PUT_TIME
                  ,RAW_MATERIAL_CD
                  ,NET_WT
                  ,PUT_METHOD
                  ,CHECK_NO
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT nvl(TRIM(ITEM), 0)                                        -- MELT_NO
                  ,'202'                                            -- PLANT_PROC_CD
                  ,TO_DATE(TRIM(ITEM_1),'DD-MM-YYYY HH24:MI:SS')    -- PUT_TIME
                  ,TRIM(ITEM_2)                                     -- RAW_MATERIAL_CD
                  ,TRIM(ITEM_3)                                     -- NET_WT
                  ,TRIM(ITEM_4)                                     -- PUT_METHOD
                  ,'000000000'
                  ,SYSDATE
                  ,'SP_TR_D1TR006'
           FROM   TB_PO_LEVEL2_INTERFACE
           WHERE  SEQUENCE_KEY = IN_SEQUENCE_KEY;
    EXCEPTION
        WHEN  NO_DATA_FOUND  THEN
            vERR_CODE   :=  -20001;
            vERR_MSG    :=  'TB_PO_MATERIAL_PUT_RESULT INSERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';
            RETURN;
    END;

EXCEPTION
    WHEN    OTHERS  THEN
            vERR_CODE   := TO_CHAR(SQLCODE);
            vERR_MSG   := 'SYSTEM ERROR = ' || SQLERRM;
        RAISE;
END;