create or replace
PROCEDURE SP_TR_D1TR007 (IN_SEQUENCE_KEY IN VARCHAR2                                               ,IN_TC_ID             IN  VARCHAR2
                                               )

 IS
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR007
 * VERSION           : V1.00
 * DESCRIPTION       : Consumption of LF electricity
 * DEVELOPER NAME    : Lee
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       :
 */-----------------------------------------------------------------------------

vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);

BEGIN

    -- TB_PO_LF_ELECTRIC INSERT----------
    BEGIN
           INSERT INTO TB_PO_LF_ELECTRIC
                  (MELT_NO
                  ,PWR_USE_START_TIME
                  ,PWR_USE_END_TIME
                  ,PWR_USE_TIME
                  ,STAGE
                  ,PWR_USE_AMOUNT_HR
                  ,PWR_USE_AMOUNT_TON
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT TRIM(ITEM)                                        -- MELT_NO
                  ,TO_DATE(TRIM(ITEM_1),'DD-MM-YYYY HH24:MI:SS')    -- PWR_USE_START_TIME
                  ,TO_DATE(TRIM(ITEM_2),'DD-MM-YYYY HH24:MI:SS')    -- PWR_USE_END_TIME
                  ,TRIM(ITEM_3)                                     -- PWR_USE_TIME
                  ,TRIM(ITEM_4)                                     -- STAGE
                  ,TRIM(ITEM_5)                                     -- PWR_USE_AMOUNT_HR
                  ,TRIM(ITEM_6)                                     -- PWR_USE_AMOUNT_TON
                  ,SYSDATE
                  ,'SP_TR_D1TR007'
           FROM   TB_PO_LEVEL2_INTERFACE
           WHERE  SEQUENCE_KEY = IN_SEQUENCE_KEY;
    EXCEPTION
        WHEN  NO_DATA_FOUND  THEN
            vERR_CODE   :=  -20001;
            vERR_MSG    :=  'TB_PO_LF_ELECTRIC INSERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';
            RETURN;
    END;

EXCEPTION
    WHEN    OTHERS  THEN
        RAISE;
END;