create or replace 
PROCEDURE SP_TR_D1TR013 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR013
 * VERSION           : V2.00
 * DESCRIPTION       : Pouring_end
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 15.01.2014
 */-----------------------------------------------------------------------------
  
-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D1TR013';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
meltNo              number;                 -- melt number
craneWeight         number;                 -- crane weight
craneWeightingTime  date;                   -- crane weighting time
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)
errorCode           varchar2(250) := null;

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  -- select melt number, weighting time and crane weight
  SELECT to_number(TRIM(ITEM)), TO_DATE(TRIM(ITEM_1), dateTimeTemplate), to_number(TRIM(ITEM_2))
    INTO meltNo, craneWeightingTime, craneWeight
    FROM TB_PO_LEVEL2_INTERFACE
    WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
    
  -- TB_PO_MPT_RESULT UPDATE ----------
  BEGIN
    currentOperation := 'Operation [TB_PO_MPT_RESULT update].'; -- current operation marker for error handling
    UPDATE TB_PO_MPT_RESULT
      SET STLMAKING_PROG_CD = '7'    -- Ingot extraction waiting
          ,POURING_END_TIME = craneWeightingTime
          ,POUR_PETROL_DATE = FN_PETRODATE(TO_CHAR(craneWeightingTime,'YYYYMMDDHH24MISS'),'YYYYMMDDHH24MISS','YYYYMMDD')
          ,MELT_DATE        = FN_PETRODATE(TO_CHAR(craneWeightingTime,'YYYYMMDDHH24MISS'),'YYYYMMDDHH24MISS','YYYYMMDD')
          ,MOD_DDTT = SYSDATE
          ,MODIFIER = procedureName
      WHERE MELT_NO = meltNo;
                   
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
    
  -- TB_PM_MELT_WORK_SEQUENCE UPDATE ----------
  BEGIN
    currentOperation := 'Operation [TB_PM_MELT_WORK_SEQUENCE update].'; -- current operation marker for error handling
    UPDATE TB_PM_MELT_WORK_SEQUENCE
      SET STLMAKE_STATUS_CD = '7'
          ,MOD_DDTT         = SYSDATE
          ,MODIFIER         = procedureName
      WHERE MELT_NO = meltNo;
    
    EXCEPTION          
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  --TB_PO_SIPHON_RESULT UPDATE ----------------
  BEGIN
    currentOperation := 'Operation [TB_PO_SIPHON_RESULT update].'; -- current operation marker for error handling
    UPDATE TB_PO_SIPHON_RESULT
      SET SIPHON_POURING_END_TIME = craneWeightingTime
          ,SIPHON_WT              = SIPHON_WT - craneWeight
      WHERE MELT_NO = meltNo AND SIPHON_POURING_END_TIME IS NULL;
      
    UPDATE TB_PO_POURING_RESULT
      SET POURING_END_TIME = craneWeightingTime
          ,MOD_DDTT = SYSDATE
          ,MODIFIER = procedureName
      WHERE MELT_NO = meltNo;
      
    EXCEPTION          
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
  
  -- MONITORING DATA SET
  BEGIN
    currentOperation := 'Operation [call stored procedure SP_TR_200_MONITOR].'; -- current operation marker for error handling
    SP_TR_200_MONITOR ('203', 'F', meltNo, NULL, TO_CHAR(craneWeightingTime, 'YYYYMMDDHH24MI'), 'E', NULL, NULL, errorCode ,errors);
    
    IF errors IS NOT NULL THEN
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
    END IF;
  END;
  
  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;