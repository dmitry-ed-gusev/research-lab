/* Code of stored procedure. 27.09.2013 */
create or replace
PROCEDURE      SP_TR_D1TR001 (IN_SEQUENCE_KEY       IN  VARCHAR2
                                               ,IN_TC_ID              IN  VARCHAR2
                                               )

 IS
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR001
 * VERSION           : V1.00
 * DESCRIPTION       : Scrap weight information
 * DEVELOPER NAME    : Lee
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       :
 */-----------------------------------------------------------------------------

vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);

vCOUNT                  NUMBER;
W_ADD_DELETE            VARCHAR2(1);

BEGIN

    -- TB_PO_MPT_RESULT INSERT----------

    SELECT COUNT(MELT_NO) INTO vCOUNT
      FROM TB_PO_MPT_RESULT
     WHERE MELT_NO = (SELECT TO_NUMBER(TRIM(ITEM))
                        FROM TB_PO_LEVEL2_INTERFACE
                       WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY);
    IF  vCOUNT < 1 THEN
        BEGIN
              INSERT INTO TB_PO_MPT_RESULT
                     (MELT_NO
                     ,MPT_GP
                     ,STLMAKING_PROG_CD
                     ,OLD_MELT_NO
                     ,REG_DDTT
                     ,REGISTER
                     )
              SELECT TRIM(ITEM)                                -- MELT_NO
                     ,CASE WHEN SUBSTR(ITEM,1,1) = '5' THEN '1'
                           WHEN SUBSTR(ITEM,1,1) = '6' THEN '2'
                           WHEN SUBSTR(ITEM,1,1) = '7' THEN '3' ELSE '4' END
                     ,'3'                                        -- MPT Start
                     ,TRIM(ITEM)
                     ,SYSDATE
                     ,'SP_TR_D1TR001'
               FROM  TB_PO_LEVEL2_INTERFACE
               WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
        EXCEPTION
         WHEN  DUP_VAL_ON_INDEX THEN
               NULL;
         WHEN  OTHERS  THEN
               vERR_CODE   :=  -20001;
               vERR_MSG    :=  'TB_PO_MPT_RESULT INSERT ERROR'
                           ||  ' TC_ID='        || IN_TC_ID
                           ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                           ||  ' LEVEL2_INTERFACE '
                           ||  ' (' || SQLERRM || ')';
               RETURN;
        END;
    END IF;

    -- MELT WORK SEQUENCE INSERT
    SELECT COUNT(MELT_NO) INTO vCOUNT
      FROM TB_PM_MELT_WORK_SEQUENCE
     WHERE MELT_NO = (SELECT TO_NUMBER(TRIM(ITEM))
                        FROM TB_PO_LEVEL2_INTERFACE
                       WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY);
    IF  vCOUNT < 1 THEN
        BEGIN
              INSERT INTO TB_PM_MELT_WORK_SEQUENCE
                     (MELT_MGMT_NO
                     ,WORK_PLAN_DD
                     ,PRIOR_IN_DATE
                     ,MELT_NO
                     ,MPT_GP
                     ,STLMAKE_STATUS_CD
                     ,REG_DDTT
                     ,REGISTER
                     )
              SELECT (SELECT TO_CHAR(MAX(TO_NUMBER(MELT_MGMT_NO)) + 1) FROM TB_PM_MELT_WORK_SEQUENCE)
                     ,TO_CHAR(SYSDATE,'YYYYMMDD')
                     ,1
                     ,TRIM(ITEM)                                -- MELT_NO
                     ,CASE WHEN SUBSTR(ITEM,1,1) = '5' THEN '1'
                           WHEN SUBSTR(ITEM,1,1) = '6' THEN '2'
                           WHEN SUBSTR(ITEM,1,1) = '7' THEN '3' ELSE '4' END
                     ,'3'                                        -- MPT Start
                     ,SYSDATE
                     ,'SP_TR_D1TR001'
               FROM  TB_PO_LEVEL2_INTERFACE
               WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
        EXCEPTION
         WHEN  DUP_VAL_ON_INDEX THEN
               NULL;
         WHEN  OTHERS  THEN
               vERR_CODE   :=  -20001;
               vERR_MSG    :=  'TB_PM_MELT_WORK_SEQUENCE INSERT ERROR'
                           ||  ' TC_ID='        || IN_TC_ID
                           ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                           ||  ' LEVEL2_INTERFACE '
                           ||  ' (' || SQLERRM || ')';
               RETURN;
        END;
    END IF;



    -- TB_PO_MATERIAL_PUT_RESULT INSERT----------
    BEGIN
        SELECT TRIM(ITEM_11) INTO W_ADD_DELETE
          FROM   TB_PO_LEVEL2_INTERFACE
         WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;


        IF W_ADD_DELETE = 'D' THEN

           DELETE TB_PO_MATERIAL_PUT_RESULT
            WHERE (MELT_NO,PLANT_PROC_CD,PUT_TIME)
                  = (
                     SELECT TO_NUMBER(ITEM),'201',TO_DATE(TRIM(ITEM_9),'DD-MM-YYYY HH24:MI:SS')
                       FROM TB_PO_LEVEL2_INTERFACE
                      WHERE SEQUENCE_KEY  = IN_SEQUENCE_KEY
                    );
        ELSE
           INSERT INTO TB_PO_MATERIAL_PUT_RESULT
                  (MELT_NO
                  ,PLANT_PROC_CD
                  ,PUT_TIME
                  ,RAW_MATERIAL_CD
                  ,BASKET_TYPE
                  ,BASKET_QNTY
                  ,WHOLE_WT
                  ,NET_WT
                  ,ALLOCATED_WT
                  ,BASKET_WT
                  ,WEIGHER_POSITION
                  ,CHECK_NO
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT TO_NUMBER(ITEM)                                   -- MELT_NO
                  ,'201'                                            -- PLANT_PROC_CD
                  ,TO_DATE(TRIM(ITEM_9),'DD-MM-YYYY HH24:MI:SS')    -- PUT_TIME
                  ,TRIM(ITEM_8)                                     -- RAW_MATERIAL_CD
                  ,TRIM(ITEM_2)                                     -- BASKET_TYPE
                  ,TRIM(ITEM_3)                                     -- BASKET_QNTY
                  ,TRIM(ITEM_4)                                     -- WHOLE_WT
                  ,TRIM(ITEM_5)                                     -- NET_WT
                  ,TRIM(ITEM_5)                                     -- NET_WT (ALLOCATED_WT)
                  ,TRIM(ITEM_6)                                     -- BASKET_WT
                  ,TRIM(ITEM_7)                                     -- WEIGHER_POSITION
                  ,TRIM(ITEM_10)                                    -- CHECK_NO
                  ,SYSDATE
                  ,'SP_TR_D1TR001'
           FROM   TB_PO_LEVEL2_INTERFACE
           WHERE  SEQUENCE_KEY = IN_SEQUENCE_KEY;
        END IF;
    EXCEPTION
         WHEN  DUP_VAL_ON_INDEX THEN NULL;
         WHEN  OTHERS  THEN
               vERR_CODE   :=  -20001;
               vERR_MSG    :=  'TB_PO_MATERIAL_PUT_RESULT INSERT ERROR'
                           ||  ' TC_ID='        || IN_TC_ID
                           ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                           ||  ' LEVEL2_INTERFACE '
                           ||  ' (' || SQLERRM || ')';
               RETURN;

    END;
COMMIT;
EXCEPTION
    WHEN    OTHERS  THEN
        RAISE;
END;