create or replace
PROCEDURE      SP_TR_D1TR004 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )

 IS
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR004
 * VERSION           : V1.00
 * DESCRIPTION       : LF_start
 * DEVELOPER NAME    : Lee
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       :
 */-----------------------------------------------------------------------------

vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
vCNT                    NUMBER;

W_MELT_NO               NUMBER;
W_LF_START_TIME         DATE;
W_LADLE_NO              NUMBER;
W_LADLE_USE_COUNT       NUMBER;
W_STLGRADE_CD           NUMBER;
W_STLGRADE_NAME         VARCHAR2(20);

BEGIN
    SELECT TRIM(A.ITEM)
           ,TO_DATE(A.ITEM_1,'DD-MM-YYYY HH24:MI:SS')
           ,TRIM(A.ITEM_2)
           ,TRIM(A.ITEM_3)
           ,B.STLGRADE_CD
           ,TRIM(A.ITEM_4)
      INTO W_MELT_NO
           ,W_LF_START_TIME
           ,W_LADLE_NO
           ,W_LADLE_USE_COUNT
           ,W_STLGRADE_CD
           ,W_STLGRADE_NAME
      FROM TB_PO_LEVEL2_INTERFACE A
           ,TB_QM_STL_GRADE       B
     WHERE A.SEQUENCE_KEY = IN_SEQUENCE_KEY
       AND TRIM(A.ITEM_4) = B.STLGRADE_NAME(+);


    --TB_PO_LEVEL2_INTERFACE Search & TB_PO_MPT_RESULT UPDATE ----------
    BEGIN
           UPDATE TB_PO_MPT_RESULT
              SET STLMAKING_PROG_CD = '5'    -- LF Start
                  ,STLGRADE_CD      = W_STLGRADE_CD
                  ,AKOS             = 'Y'
                  ,LF_START_TIME    = W_LF_START_TIME
                  ,LADLE_NO         = W_LADLE_NO
                  ,MOD_DDTT = SYSDATE
                  ,MODIFIER = 'SP_TR_D1TR004'
            WHERE MELT_NO = W_MELT_NO;

    EXCEPTION
        WHEN  NO_DATA_FOUND  THEN
            vERR_CODE   :=  -20001;
            vERR_MSG    :=  'TB_PO_MPT_RESULT UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';
            RETURN;
    END;


    BEGIN
           UPDATE  TB_PM_MELT_WORK_SEQUENCE
              SET  STLMAKE_STATUS_CD = '5'
                  ,STLGRADE_CD = W_STLGRADE_CD
                  ,STLGRADE_NAME = W_STLGRADE_NAME
                  ,MOD_DDTT = SYSDATE
                  ,MODIFIER = 'SP_TR_D1TR004'
            WHERE  MELT_NO = W_MELT_NO;

    EXCEPTION
        WHEN  NO_DATA_FOUND  THEN
            vERR_CODE   :=  -20001;
            vERR_MSG    :=  'TB_PM_MELT_WORK_SEQUENCE'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';
            RETURN;
    END;


    --TB_PO_LEVEL2_INTERFACE Search & TB_PO_LF_RESULT INSERT----------
    BEGIN
           INSERT INTO TB_PO_LF_RESULT
                  (MELT_NO
                  ,STLGRADE_CD
                  ,LADLE_NO
                  ,LF_START_TIME
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT MELT_NO
                  ,STLGRADE_CD
                  ,LADLE_NO
                  ,LF_START_TIME
                  ,SYSDATE
                  ,'SP_TR_D1TR004'
             FROM TB_PO_MPT_RESULT
            WHERE MELT_NO = W_MELT_NO;

    EXCEPTION
        WHEN  DUP_VAL_ON_INDEX   THEN
              UPDATE  TB_PO_LF_RESULT
                 SET  LF_START_TIME = W_LF_START_TIME
                     ,LADLE_NO      = W_LADLE_NO
              WHERE  MELT_NO = W_MELT_NO;
    END;


    -- TB_PO_LADLE_MASTER UPDATE  ----------

    SELECT COUNT(*) INTO  vCNT
      FROM TB_PO_LADLE_MASTER
     WHERE  NO      = W_LADLE_NO;

    IF  vCNT > 0  THEN
        UPDATE  TB_PO_LADLE_MASTER
           SET  MELT_NO     = W_MELT_NO
               ,USAGE_COUNT = W_LADLE_USE_COUNT
               ,MOD_DDTT    = SYSDATE
               ,MODIFIER    = 'SP_TR_D1TR004'
         WHERE  NO      = W_LADLE_NO;
    ELSE
       INSERT  INTO  TB_PO_LADLE_MASTER
              (NO
              ,MELT_NO
              ,USAGE_COUNT
              ,REG_DDTT
              ,REGISTER
              )
       VALUES (W_LADLE_NO
              ,W_MELT_NO
              ,W_LADLE_USE_COUNT
              ,SYSDATE
              ,'SP_TR_D1TR004'
              );
    END IF;

    -- MONITORING DATA SET
    SP_TR_200_MONITOR  ('202'
                       ,'E'
                       ,W_MELT_NO
                       ,TO_CHAR(W_LF_START_TIME,'YYYYMMDDHH24MI')
                       ,NULL
                       ,'S'
                       ,NULL
                       ,NULL
                       ,vERR_CODE
                       ,vERR_MSG
                      );
    IF  vERR_MSG  IS NOT NULL  THEN
        RETURN;
    END IF;
EXCEPTION
    WHEN    OTHERS  THEN
            vERR_CODE   := TO_CHAR(SQLCODE);
            vERR_MSG   := 'SYSTEM ERROR = ' || SQLERRM;
        RAISE;
END;