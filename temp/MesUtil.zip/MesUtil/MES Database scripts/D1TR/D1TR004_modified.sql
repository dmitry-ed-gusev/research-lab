create or replace 
PROCEDURE SP_TR_D1TR004 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

/*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR004        
 * VERSION           : V2.00                       
 * DESCRIPTION       : LF_start       
 * DEVELOPER NAME    : Lee, Gusev D.               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       : 30.09.2013                                                       
*/-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D1TR004';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
stlMakingProgCode   varchar2(1)  := '5';  -- LF start code
-- parameters for procedure
telegramId          varchar2(7);   -- telegram id
meltNo              number;        -- melt number
LFStartTime         DATE;          -- event "LF start" datetime value   
stlGradeName        VARCHAR2(30);  -- steel grade name
counter             NUMBER;        -- temporary counter
ladleNumber         NUMBER;        -- number of ladle
ladleUseCount       NUMBER;        --
errorMessage        varchar2(300); -- one error message        
spErrorCode         number;        -- error code, returned from SP_TR_200_MONITOR 
spErrorMsg          varchar2(250); -- error message, returned from SP_TR_200_MONITOR

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  -- select some data 
  SELECT TRIM(ITEM), TO_DATE(ITEM_1, dateTimeTemplate), TRIM(ITEM_2), TRIM(ITEM_3), TRIM(ITEM_4) 
   INTO meltNo, LFStartTime, ladleNumber, ladleUseCount, stlGradeName
     FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
       
  -- 1. Update table TB_PO_MPT_RESULT
  BEGIN
    UPDATE TB_PO_MPT_RESULT SET STLMAKING_PROG_CD = stlMakingProgCode /*LF Start code*/, AKOS = 'Y', LF_START_TIME = LFStartTime,
      LADLE_NO = ladleNumber, MOD_DDTT = SYSDATE, MODIFIER = procedureName WHERE MELT_NO = meltNo;     
    EXCEPTION
      WHEN NO_DATA_FOUND THEN  -- process NO_DATA_FOUND execption case
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, 'Operation [TB_PO_MPT_RESULT update]. Exception [NO_DATA_FOUND].', errors);
      RETURN;
  END;
  
  -- 2. Update table TB_PM_MELT_WORK_SEQUENCE
  BEGIN
    UPDATE  TB_PM_MELT_WORK_SEQUENCE SET  STLMAKE_STATUS_CD = stlMakingProgCode, STLGRADE_NAME_LF = stlGradeName,
      MOD_DDTT = SYSDATE, MODIFIER = procedureName WHERE MELT_NO = meltNo;          
    EXCEPTION          
      WHEN NO_DATA_FOUND THEN
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, 'Operation [TB_PM_MELT_WORK_SEQUENCE update]. Exception [NO_DATA_FOUND].', errors);
      RETURN;
  END;
    
  -- 3. Select data from table TB_PO_MPT_RESULT and insert them into TB_PO_LF_RESULT table
  BEGIN
    INSERT INTO TB_PO_LF_RESULT (MELT_NO, STLGRADE_CD, LADLE_NO, LF_START_TIME, REG_DDTT, REGISTER)
      SELECT MELT_NO, STLGRADE_CD, LADLE_NO, LF_START_TIME, SYSDATE, procedureName
        FROM TB_PO_MPT_RESULT WHERE MELT_NO = meltNo;  
    EXCEPTION          
      WHEN DUP_VAL_ON_INDEX THEN
        -- 1err. error processing
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, 'Operation [TB_PO_LF_RESULT insert]. Exception [DUP_VAL_ON_INDEX].', errors);              
        -- 2err. updating table TB_PO_LF_RESULT 
        UPDATE  TB_PO_LF_RESULT SET LF_START_TIME = LFStartTime, LADLE_NO = ladleNumber WHERE MELT_NO = meltNo;        
  END;
   
  -- 4. Update/insert table TB_PO_LADLE_MASTER
  SELECT COUNT(*) INTO counter FROM TB_PO_LADLE_MASTER WHERE NO = ladleNumber;
  -- depends on select result we proceed with one of actions -> update/insert   
  IF counter > 0  THEN                    
   UPDATE TB_PO_LADLE_MASTER SET MELT_NO = meltNo, USAGE_COUNT = ladleUseCount, 
     MOD_DDTT = SYSDATE, MODIFIER = procedureName WHERE NO = ladleNumber;
  ELSE 
   INSERT INTO TB_PO_LADLE_MASTER (NO, MELT_NO, USAGE_COUNT, REG_DDTT, REGISTER)
     VALUES (ladleNumber, meltNo, ladleUseCount, SYSDATE, procedureName);
  END IF; 
    
  -- 5. Call Stored Procedure for update monitoring data (table TB_PO_MONITORING) 
  SP_TR_200_MONITOR ('202', 'E', meltNo, TO_CHAR(LFStartTime, 'YYYYMMDDHH24MI'), NULL, 'S', NULL, NULL, spErrorCode, spErrorMsg);
  -- if SP returns not empty error message - add it (message) to resulting errors list
  IF spErrorMsg IS NOT NULL THEN
    errors := fn_process_error(spErrorMsg, spErrorCode, telegramId, in_sequence_key, 'Operation [SP_TR_200_MONITOR call].', errors);
  END IF;
  
EXCEPTION -- common block for exceptions handle  
  WHEN OTHERS THEN -- process every kind of exception
    errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, 'Common error case.', errors);
END;