create or replace 
PROCEDURE      SP_TR_D1TR014 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR014        
 * VERSION           : V1.00                       
 * DESCRIPTION       : Liquid steel temperature in Pouring Ladle        
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
  
BEGIN 
      
   BEGIN 
           
          INSERT INTO TB_PO_POURING_TEMPERATURE
                 (MELT_NO
                 ,MEASURE_TIME
                 ,MEASURE_TEMP
                 ,MOD_DDTT
                 ,MODIFIER
                 )
          SELECT TRIM(ITEM)
                 ,TO_DATE(TRIM(ITEM_1),'DD-MM-YYYY HH24:MI:SS') 
                 ,TRIM(ITEM_2)
                 ,SYSDATE
                 ,'SP_TR_D1TR014'
            FROM TB_PO_LEVEL2_INTERFACE 
           WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY
           ;
                             
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_POURING_RESULT UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';       
            RETURN;
    END;


EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;