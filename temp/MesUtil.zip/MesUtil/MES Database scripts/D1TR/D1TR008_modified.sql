create or replace 
PROCEDURE SP_TR_D1TR008 (IN_SEQUENCE_KEY IN VARCHAR2, errors out VARCHAR2) IS

/*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR008        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Consumption of LF Ar        
 * DEVELOPER NAME    : Lee, Gusev D.               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       : 30.09.2013                                                      
*/-----------------------------------------------------------------------------
  
-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D1TR008';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7); -- telegram id

BEGIN 
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  -- Insert data into TB_PO_LF_GAS table
  INSERT INTO TB_PO_LF_GAS(MELT_NO, GAS_KIND, POUR_START_TIME, POUR_END_TIME, POUR_QNTY, POUR_METHOD_CD, REG_DDTT, REGISTER)
   SELECT TRIM(ITEM)/*MELT_NO*/, 'A' /*GAS_KIND*/, TO_DATE(TRIM(ITEM_1), dateTimeTemplate) /*POUR_START_TIME*/,
    TO_DATE(TRIM(ITEM_2), dateTimeTemplate) /*POUR_END_TIME*/, TRIM(ITEM_3) /*POUR_QNTY*/, 
     TRIM(ITEM_4) /*POUR_METHOD*/, SYSDATE, procedureName FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
     
  EXCEPTION
   WHEN OTHERS THEN
     errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, 'Operation [TB_PO_LF_GAS insert].', errors);
END;