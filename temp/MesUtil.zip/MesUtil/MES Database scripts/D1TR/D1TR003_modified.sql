create or replace 
PROCEDURE SP_TR_D1TR003 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

/*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR003        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Utility Information for MPT Furnaces #1~#4        
 * DEVELOPER NAME    : Lee, Gusev D.               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       : 03.10.2013                                                      
*/-----------------------------------------------------------------------------
  
-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D1TR003';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
noValue             varchar(4)   := '----'; -- "value doesn't exist" value for data
-- parameters for procedure
telegramId          varchar2(7);    -- telegram id
sqlquery            varchar2(1000); -- sql query for inserting data into target table
loopCounter         number := 0;         -- just loop counter

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  -- in a loop we produce sql queries and execute them  
  for loopCounter in 1..4 loop
    -- generating sql query
    sqlquery := 'INSERT INTO TB_PO_UTILITY_MPT (MPT_GP, MEASURING_TIME, TEMP_AIR, TEMP_COMPRESSOR_AIR, '||
                'TEMP_OXYGEN, TEMP_GAS, TEMP_BLANK_OIL, TEMP_LIQUID_STEEL, TEMP_FURNACE_ROOF, CONSUMPTION_AIR, '||
                'CONSUMPTION_COMPRESSOR_AIR, CONSUMPTION_OXYGEN, CONSUMPTION_GAS, CONSUMPTION_BLANK_OIL, REG_DDTT, REGISTER) '||
                'SELECT '''||loopCounter||''', '||                                                 /*MPT_GP*/
                'TO_DATE(TRIM(ITEM), '''||dateTimeTemplate||'''), '||                              /*MEASURING_TIME*/
                'replace(TRIM(ITEM_'||(12*(loopCounter - 1) + 1)||'),  '''||noValue||''', 0), '||  /*TEMPERATURE_AIR*/
                'replace(TRIM(ITEM_'||(12*(loopCounter - 1) + 2)||'),  '''||noValue||''', 0), '||  /*TEMPERATURE_COMPRESSOR_AIR*/
                'replace(TRIM(ITEM_'||(12*(loopCounter - 1) + 3)||'),  '''||noValue||''', 0), '||  /*TEMPERATURE_OXYGEN*/
                'replace(TRIM(ITEM_'||(12*(loopCounter - 1) + 4)||'),  '''||noValue||''', 0), '||  /*TEMPERATURE_GAS*/
                'replace(TRIM(ITEM_'||(12*(loopCounter - 1) + 5)||'),  '''||noValue||''', 0), '||  /*TEMPERATURE_BLANK_OIL*/
                'replace(TRIM(ITEM_'||(12*(loopCounter - 1) + 6)||'),  '''||noValue||''', 0), '||  /*TEMPERATURE_LIQUID_STEEL*/
                'replace(TRIM(ITEM_'||(12*(loopCounter - 1) + 7)||'),  '''||noValue||''', 0), '||  /*TEMPERATURE_FURNACE_ROOF*/
                'replace(TRIM(ITEM_'||(12*(loopCounter - 1) + 8)||'),  '''||noValue||''', 0), '||  /*CONSUMPTION_AIR*/
                'replace(TRIM(ITEM_'||(12*(loopCounter - 1) + 9)||'),  '''||noValue||''', 0), '||  /*CONSUMPTION_COMPRESSOR_AIR*/
                'replace(TRIM(ITEM_'||(12*(loopCounter - 1) + 10)||'), '''||noValue||''', 0), '||  /*CONSUMPTION_OXYGEN*/
                'replace(TRIM(ITEM_'||(12*(loopCounter - 1) + 11)||'), '''||noValue||''', 0), '||  /*CONSUMPTION_GAS*/
                'replace(TRIM(ITEM_'||(12*(loopCounter - 1) + 12)||'), '''||noValue||''', 0), '||  /*CONSUMPTION_BLANK_OIL*/
                'SYSDATE, '''||procedureName||''' FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = '||in_sequence_key||
                ' AND NVL(TRIM(ITEM_'||(12*(loopCounter - 1) + 1)||'), ''*'') <> ''*''';
   --dbms_output.put_line('****'||sqlquery);
    -- execute query
    execute immediate sqlquery;
  end loop;
  
exception
  when others then
    errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, 'Operation [TB_PO_UTILITY_MPT insert/TB_PO_LEVEL2_INTERFACE select].'|| 
      'Counter variable = ['||loopCounter||'].' , errors);
end;