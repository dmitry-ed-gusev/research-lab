create or replace 
PROCEDURE      SP_TR_D1TR015 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D1TR015        
 * VERSION           : V1.00                       
 * DESCRIPTION       : Ingot weight information after extracting from the mould       
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE                  NUMBER;
vERR_MSG                   VARCHAR2(250);

W_MELT_NO                  TB_PO_INGOT_COMM.MELT_NO%TYPE;
W_PROG_CD                  TB_PO_INGOT_COMM.PROG_CD%TYPE;
W_HCR_GP                   TB_PM_MELT_WORK_SEQUENCE.HCR_GP%TYPE;
W_UNHEATEDWELL_CHARGE_CD   TB_PM_MELT_WORK_SEQUENCE.UNHEATEDWELL_CHARGE_CD%TYPE;

W_WEIGHING_TIME            DATE;
W_WEIGHING_WEIGHT          NUMBER;
W_CHECK_CNT                NUMBER;
W_INGOT_WT                 NUMBER;

  
BEGIN 
      
   SELECT TRIM(ITEM)
          ,TO_DATE(TRIM(ITEM_1),'DD-MM-YYYY HH24:MI:SS')
          ,TRIM(ITEM_2)
     INTO W_MELT_NO,W_WEIGHING_TIME,W_WEIGHING_WEIGHT     
     FROM TB_PO_LEVEL2_INTERFACE 
    WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY; 
    
   IF     W_WEIGHING_WEIGHT > 4000  THEN
          W_CHECK_CNT  := 2;
          W_INGOT_WT   := ROUND(W_WEIGHING_WEIGHT / 2,0); 
   ELSE  
          W_CHECK_CNT  := 1;
          W_INGOT_WT   := W_WEIGHING_WEIGHT;
   END IF; 
   
--   SELECT HCR_GP,UNHEATEDWELL_CHARGE_CD
--     INTO W_HCR_GP,W_UNHEATEDWELL_CHARGE_CD
--     FROM TB_PM_MELT_WORK_SEQUENCE
--    WHERE MELT_NO = W_MELT_NO;
    
--   IF   W_UNHEATEDWELL_CHARGE_CD = 'U'  THEN
--          W_PROG_CD   := '8';       
--   ELSIF  W_HCR_GP = 'H'  THEN
--          W_PROG_CD   := 'A';
--   END IF;

 
   UPDATE TB_PO_INGOT_COMM A
      SET --PROG_CD                    = W_PROG_CD
          --,PROG_DD                   = TO_CHAR(W_WEIGHING_TIME,'YYYYMMDD') 
          INGOT_CRANE_WEIGHING_TIME = W_WEIGHING_TIME
          ,CRANE_WEIGHING_WEIGHT     = W_INGOT_WT
          ,MOD_DDTT                  = SYSDATE
          ,MODIFIER                  = 'SP_TR_D1TR015'    
     WHERE (MELT_NO, INGOT_KEY) IN (SELECT MELT_NO, INGOT_KEY
                                      FROM (SELECT MELT_NO, INGOT_KEY
                                              FROM TB_PO_INGOT_COMM
                                             WHERE MELT_NO = W_MELT_NO
                                               AND CRANE_WEIGHING_WEIGHT IS NULL
                                             ORDER BY INGOT_KEY
                                           )
                                      WHERE ROWNUM <= W_CHECK_CNT
                                   ) ;

--   -- MPT RESULT UPDATE
--   UPDATE TB_PO_MPT_RESULT
--      SET STLMAKING_PROG_CD  = W_PROG_CD
--          ,MOD_DDTT          = SYSDATE
--          ,MODIFIER          = 'SP_TR_300_POUR'
--    WHERE MELT_NO = W_MELT_NO;
--
--    -- MPT MELT WORK SEQUENCE UPDATE
--   UPDATE TB_PM_MELT_WORK_SEQUENCE
--      SET STLMAKE_STATUS_CD  = W_PROG_CD   
--          ,MOD_DDTT          = SYSDATE
--          ,MODIFIER          = 'SP_TR_300_POUR'
--    WHERE MELT_NO = W_MELT_NO;  

EXCEPTION  
    WHEN    OTHERS  THEN 
        vERR_CODE   := TO_CHAR(SQLCODE);
        vERR_MSG    := 'SYSTEM ERROR = ' || SQLERRM;
        RAISE;                           
END;