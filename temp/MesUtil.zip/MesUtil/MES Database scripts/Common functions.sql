create or replace 
FUNCTION FN_PETRODATE (V_DATE IN VARCHAR2, V_IN_FORMAT  IN VARCHAR2, V_OUT_FORMAT IN VARCHAR2)
  RETURN VARCHAR2 IS
  
/*-----------------------------------------------------------------------------
 * PROGAM NAME       : FN_PETRODATE        
 * VERSION           : V1.00                       
 * DESCRIPTION       : function receive char representation of date/time, converts it to date,
                       shift forward for 59.99 minutes and again converts to characters. Converting
                       occured by date/time patterns, provided as function arguments.
 * DEVELOPER NAME    : someone from korean team :), Gusev D.               
 * CREATE DATE       : 2012              
 * MODIFY DATE       : 02.10.2013                                                       
*/-----------------------------------------------------------------------------

  V_RESULT VARCHAR2(08); 
BEGIN
  -- Accounted for one: this function shifts forward date/time value for 59.99 minutes. ????
  SELECT TO_CHAR(TO_DATE(V_DATE,V_IN_FORMAT) + ((60*59.99)/24/60/60), V_OUT_FORMAT)
    INTO V_RESULT FROM DUAL;
  RETURN V_RESULT;
END;

-- -------------------------------------------------------------------------------------------------

create or replace
FUNCTION FN_PROCESS_ERROR (errMsg in varchar2, errCode in number, telegramId in varchar2,
  sequence_key in varchar2, optionalMessage in varchar2, errors in varchar2)
    return varchar2 is

/*-----------------------------------------------------------------------------
 * PROGAM NAME       : FN_PROCESS_ERROR
 * VERSION           : V1.00
 * DESCRIPTION       :
 * DEVELOPER NAME    : Gusev D.
 * CREATE DATE       : 02.10.2013
 * MODIFY DATE       :
*/-----------------------------------------------------------------------------

  noErrors     varchar2(2) := 'OK'; -- constant: no errors
  errorMessage varchar2(500);       -- one generated error message
  resultErrors varchar2(1000);      -- resulting message (many errors)
BEGIN

  -- generating error message
  errorMessage := 'Error ['||errMsg||', '||errCode||'] occured! '||'Telegram ['||telegramId||']. '||
    'Sequence key ['||sequence_key||'].';
  if optionalMessage is not null then
    errorMessage := errorMessage||' '||optionalMessage;
  end if;

  -- generate resulting errors message (with many errors)
  if errors != noErrors then -- there are other errors
    resultErrors := errors||chr(10)||errorMessage;
  else                       -- it's a first error - just return it
    resultErrors := errorMessage;
  end if;

  -- return result
  RETURN resultErrors;
END;