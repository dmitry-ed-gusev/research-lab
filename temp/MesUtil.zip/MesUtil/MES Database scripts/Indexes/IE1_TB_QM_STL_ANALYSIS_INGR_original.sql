--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index IE1_TB_QM_STL_ANALYSIS_INGR
--------------------------------------------------------

  CREATE INDEX "PMES"."IE1_TB_QM_STL_ANALYSIS_INGR" ON "PMES"."TB_QM_STL_ANALYSIS_INGR" ("MELT_NO", "LAST_YN") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 851968 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
