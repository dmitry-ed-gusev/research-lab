--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index PK_TB_MA_BLANK_INSPECTION
--------------------------------------------------------

  CREATE UNIQUE INDEX "PMES"."PK_TB_MA_BLANK_INSPECTION" ON "PMES"."TB_MA_BLANK_INSPECTION" ("BLANK_INSPECTION_SEQ") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 196608 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
