--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index PK_TB_PM_BAND_PRODUCT_MILL
--------------------------------------------------------

  CREATE UNIQUE INDEX "PMES"."PK_TB_PM_BAND_PRODUCT_MILL" ON "PMES"."TB_PM_BAND_PRODUCT_MILL" ("MILLGOODS_PROD_ROLL_GP") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOCOMPRESS LOGGING
  STORAGE( INITIAL 65536 NEXT 1048576 MINEXTENTS 1
  FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
