--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index IE2_TB_CM_BULLETIN_TO_DO_LIST
--------------------------------------------------------

  CREATE INDEX "PMES"."IE2_TB_CM_BULLETIN_TO_DO_LIST" ON "PMES"."TB_CM_BULLETIN_TO_DO_LIST" ("CONTENTS") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
