--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index PK_TB_MA_SCRAP_CHARGING
--------------------------------------------------------

  CREATE UNIQUE INDEX "PMES"."PK_TB_MA_SCRAP_CHARGING" ON "PMES"."TB_MA_SCRAP_CHARGING" ("MELT_NO", "MAT_KIND_CD", "MARK_CD", "MAT_CD", "STRING_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOCOMPRESS LOGGING
  STORAGE( INITIAL 65536 NEXT 1048576 MINEXTENTS 1
  FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
