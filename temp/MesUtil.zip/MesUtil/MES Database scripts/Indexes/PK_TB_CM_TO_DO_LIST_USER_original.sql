--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index PK_TB_CM_TO_DO_LIST_USER
--------------------------------------------------------

  CREATE UNIQUE INDEX "PMES"."PK_TB_CM_TO_DO_LIST_USER" ON "PMES"."TB_CM_TO_DO_LIST_USER" ("DATA_GP", "REGISTRATION_NO", "TODO_USER") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOCOMPRESS LOGGING
  STORAGE( INITIAL 65536 NEXT 1048576 MINEXTENTS 1
  FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
