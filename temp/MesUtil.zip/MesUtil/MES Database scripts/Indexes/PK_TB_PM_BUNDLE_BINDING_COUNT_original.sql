--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index PK_TB_PM_BUNDLE_BINDING_COUNT
--------------------------------------------------------

  CREATE UNIQUE INDEX "PMES"."PK_TB_PM_BUNDLE_BINDING_COUNT" ON "PMES"."TB_PM_BUNDLE_BINDING_COUNT" ("GOODS_LEN_MIN", "GOODS_LEN_MAX") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
