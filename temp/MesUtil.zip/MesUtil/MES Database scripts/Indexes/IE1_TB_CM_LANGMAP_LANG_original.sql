--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index IE1_TB_CM_LANGMAP_LANG
--------------------------------------------------------

  CREATE UNIQUE INDEX "PMES"."IE1_TB_CM_LANGMAP_LANG" ON "PMES"."TB_CM_LANGMAP_LANG" (DECODE("LANG_GP",'en_US',NULL,"ITEM_ID"), "LANG_GP", "LANG_ITEM_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 262144 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
