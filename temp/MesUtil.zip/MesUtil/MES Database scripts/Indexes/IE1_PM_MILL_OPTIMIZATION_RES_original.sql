--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index IE1_PM_MILL_OPTIMIZATION_RES
--------------------------------------------------------

  CREATE INDEX "PMES"."IE1_PM_MILL_OPTIMIZATION_RES" ON "PMES"."TB_PM_MILL_OPTIMIZATION_RESULT" ("MILL_GP", "PROD_YYMM", "ORD_NO", "ORD_POSITION", "ORD_DIVIDE_NO", "MATERIAL_APPEARANCE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOCOMPRESS LOGGING
  STORAGE( INITIAL 131072 NEXT 1048576 MINEXTENTS 1
  FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
