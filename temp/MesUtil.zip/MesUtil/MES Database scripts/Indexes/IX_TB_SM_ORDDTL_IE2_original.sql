--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index IX_TB_SM_ORDDTL_IE2
--------------------------------------------------------

  CREATE INDEX "PMES"."IX_TB_SM_ORDDTL_IE2" ON "PMES"."TB_SM_ORDDTL" ("SALE_GP", "MILL_GP", "ORD_PROG_CD", NVL("PROD_END_YN",' '), "INGOT_DESIGN_QNTY", "MILL900_ORD_QNTY") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 917504 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
