create or replace 
PROCEDURE SP_TR_D2TR001 (IN_SEQUENCE_KEY IN  VARCHAR2, errors out varchar2) IS        

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR001        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Ingot entrance pass 
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 15.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D2TR001';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
meltNo              number;                 -- melt number
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)


W_SEQ_IN_MELT           TB_PO_INGOT_COMM.SEQ_IN_MELT%TYPE;
W_PON_CNT               NUMBER;
  
BEGIN
  RETURN;
  
  
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  /*
  -- select melt number, siphon number, weighting time and crane weight
  SELECT to_number(TRIM(ITEM)), to_number(TRIM(ITEM_1)),  to_date(TRIM(ITEM_2), dateTimeTemplate), to_number(TRIM(ITEM_4))
    INTO  meltNo, siphonNo, craneWeightingTime, craneWeight
    FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = in_sequence_key;
    */
  
  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;