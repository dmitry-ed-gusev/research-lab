create or replace 
PROCEDURE      SP_TR_D2TR020 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR020        
 * VERSION           : V1.00                       
 * DESCRIPTION       : Consumption of energy at shop100 LF (KTC)       
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
  
BEGIN 
      
    --TB_PO_UTILITY_LF_KTC INSERT----------
                                                 
    BEGIN
           INSERT INTO TB_PO_UTILITY_LF_KTC
                  (MELT_NO
                  ,MEASURING_TIME
                  ,CONSUMPTION_GAS_LV1
                  ,CONSUMPTION_GAS_LV2
                  ,PRESSURE_GAS
                  ,TEMP_GAS
                  ,DIFF_PRESSURE_GAS_LV1
                  ,DIFF_PRESSURE_GAS_LV2
                  ,CONSUMPTION_ENERGY_KTP29_1
                  ,CONSUMPTION_ENERGY_KTP29_2
                  ,CONSUMPTION_ENERGY_SD1
                  ,CONSUMPTION_ENERGY_SD2
                  ,CONSUMPTION_ENERGY_KTP29_TP28
                  ,CONSUMPTION_ENERGY_RP209
                  ,CONSUMPTION_ENERGY_TP182_1
                  ,CONSUMPTION_ENERGY_TP182_2
                  ,CONSUMPTION_ENERGY_TP73_2
                  ,CONSUMPTION_ELECTRIC_TP76_1
                  ,CONSUMPTION_ELECTRIC_TP76_2
                  ,CONSUMPTION_ENERGY_FP7
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT TRIM(ITEM)                                        -- MPT_GP
                  ,TO_DATE(TRIM(ITEM_1),'DD-MM-YYYY HH24:MI:SS')    -- MEASURING_TIME
                  ,TRIM(ITEM_2)                                     -- CONSUMPTION_GAS_LV1
                  ,TRIM(ITEM_3)                                     -- CONSUMPTION_GAS_LV2
                  ,TRIM(ITEM_4)                                     -- PRESSURE_GAS
                  ,TRIM(ITEM_5)                                     -- TEMP_GAS
                  ,TRIM(ITEM_6)                                     -- DIFF_PRESSURE_GAS_LV1
                  ,TRIM(ITEM_7)                                     -- DIFF_PRESSURE_GAS_LV2
                  ,TRIM(ITEM_8)                                     -- CONSUMPTION_ENERGY_KTP29_1
                  ,TRIM(ITEM_9)                                     -- CONSUMPTION_ENERGY_KTP29_2
                  ,TRIM(ITEM_10)                                    -- CONSUMPTION_ENERGY_SD1
                  ,TRIM(ITEM_11)                                    -- CONSUMPTION_ENERGY_SD2
                  ,TRIM(ITEM_12)                                    -- CONSUMPTION_ENERGY_KTP29_TP28
                  ,TRIM(ITEM_13)                                    -- CONSUMPTION_ENERGY_RP209
                  ,TRIM(ITEM_14)                                    -- CONSUMPTION_ENERGY_TP182_1
                  ,TRIM(ITEM_15)                                    -- CONSUMPTION_ENERGY_TP182_2
                  ,TRIM(ITEM_16)                                    -- CONSUMPTION_ENERGY_TP73_2
                  ,TRIM(ITEM_17)                                    -- CONSUMPTION_ELECTRIC_TP76_1
                  ,TRIM(ITEM_18)                                    -- CONSUMPTION_ELECTRIC_TP76_2
                  ,TRIM(ITEM_19)                                    -- CONSUMPTION_ENERGY_FP7
                  ,SYSDATE
                  ,'SP_TR_D2TR020'
             FROM TB_PO_LEVEL2_INTERFACE 
            WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;

              
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_UTILITY_LF_KTC ISERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RETURN;
    END;

EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;