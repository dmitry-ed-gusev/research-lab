create or replace 
PROCEDURE SP_TR_D2TR007 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR007
 * VERSION           : V2.00
 * DESCRIPTION       : Mill900 Pass Ingot Temperature
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 16.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D2TR007';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN 
  RETURN;
  
  
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  --TB_PO_MILL900_OP_INFORMATION INSERT----------
  BEGIN
    currentOperation := 'Operation [TB_PO_MILL900_OP_INFORMATION insert].'; -- current operation marker for error handling
    INSERT INTO TB_PO_MILL900_OP_INFORMATION (
                  MELT_NO
                  ,INGOT_NO
                  ,TC_ID
                  ,MEASURING_TIME
                  ,UNEVEN_PASS_TEMP
                  ,REG_DDTT
                  ,REGISTER
                )
      SELECT to_number(TRIM(ITEM))                    --MELT_NO
            ,to_number(TRIM(ITEM_1))                  --INGOT_NO
            ,TRIM(TC_ID)                              --TC_ID   
            ,TO_DATE(TRIM(ITEM_2), dateTimeTemplate)  --MEASURING_TIME
            ,to_number(TRIM(ITEM_3))                  --UNEVEN_PASS_TEMP
            ,SYSDATE
            ,procedureName
      FROM TB_PO_LEVEL2_INTERFACE 
      WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
  
    EXCEPTION          
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;