create or replace 
PROCEDURE SP_TR_D2TR020 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR020        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Consumption of energy at shop100 LF (KTC)       
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 16.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D2TR020';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
      
  --TB_PO_UTILITY_LF_KTC INSERT----------
  BEGIN
    currentOperation := 'Operation [TB_PO_UTILITY_LF_KTC insert].'; -- current operation marker for error handling
    INSERT INTO TB_PO_UTILITY_LF_KTC (
                  MELT_NO
                  ,MEASURING_TIME
                  ,CONSUMPTION_GAS_LV1
                  ,CONSUMPTION_GAS_LV2
                  ,PRESSURE_GAS
                  ,TEMP_GAS
                  ,DIFF_PRESSURE_GAS_LV1
                  ,DIFF_PRESSURE_GAS_LV2
                  ,CONSUMPTION_ENERGY_KTP29_1
                  ,CONSUMPTION_ENERGY_KTP29_2
                  ,CONSUMPTION_ENERGY_SD1
                  ,CONSUMPTION_ENERGY_SD2
                  ,CONSUMPTION_ENERGY_KTP29_TP28
                  ,CONSUMPTION_ENERGY_RP209
                  ,CONSUMPTION_ENERGY_TP182_1
                  ,CONSUMPTION_ENERGY_TP182_2
                  ,CONSUMPTION_ENERGY_TP73_2
                  ,CONSUMPTION_ELECTRIC_TP76_1
                  ,CONSUMPTION_ELECTRIC_TP76_2
                  ,CONSUMPTION_ENERGY_FP7
                  ,REG_DDTT
                  ,REGISTER
                )
      SELECT  to_number(TRIM(ITEM))                     -- MPT_GP
              ,TO_DATE(TRIM(ITEM_1), dateTimeTemplate)  -- MEASURING_TIME
              ,to_number(TRIM(ITEM_2))                  -- CONSUMPTION_GAS_LV1
              ,to_number(TRIM(ITEM_3))                  -- CONSUMPTION_GAS_LV2
              ,to_number(TRIM(ITEM_4))                  -- PRESSURE_GAS
              ,to_number(TRIM(ITEM_5))                  -- TEMP_GAS
              ,to_number(TRIM(ITEM_6))                  -- DIFF_PRESSURE_GAS_LV1
              ,to_number(TRIM(ITEM_7))                  -- DIFF_PRESSURE_GAS_LV2
              ,to_number(TRIM(ITEM_8))                  -- CONSUMPTION_ENERGY_KTP29_1
              ,to_number(TRIM(ITEM_9))                  -- CONSUMPTION_ENERGY_KTP29_2
              ,to_number(TRIM(ITEM_10))                 -- CONSUMPTION_ENERGY_SD1
              ,to_number(TRIM(ITEM_11))                 -- CONSUMPTION_ENERGY_SD2
              ,to_number(TRIM(ITEM_12))                 -- CONSUMPTION_ENERGY_KTP29_TP28
              ,to_number(TRIM(ITEM_13))                 -- CONSUMPTION_ENERGY_RP209
              ,to_number(TRIM(ITEM_14))                 -- CONSUMPTION_ENERGY_TP182_1
              ,to_number(TRIM(ITEM_15))                 -- CONSUMPTION_ENERGY_TP182_2
              ,to_number(TRIM(ITEM_16))                 -- CONSUMPTION_ENERGY_TP73_2
              ,to_number(TRIM(ITEM_17))                 -- CONSUMPTION_ELECTRIC_TP76_1
              ,to_number(TRIM(ITEM_18))                 -- CONSUMPTION_ELECTRIC_TP76_2
              ,to_number(TRIM(ITEM_19))                 -- CONSUMPTION_ENERGY_FP7
              ,SYSDATE
              ,defaultTelegramId
        FROM TB_PO_LEVEL2_INTERFACE 
        WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
        
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;