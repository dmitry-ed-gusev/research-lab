create or replace 
PROCEDURE SP_TR_D2TR019 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR019        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Consumption of energy at shop100 MPT (KTC)       
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 16.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D2TR019';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  --TB_PO_UTILITY_MPT_KTC INSERT----------
  BEGIN
    currentOperation := 'Operation [TB_PO_UTILITY_MPT_KTC insert].'; -- current operation marker for error handling
    INSERT INTO TB_PO_UTILITY_MPT_KTC (
                    MELT_NO
                    ,MEASURING_TIME
                    ,CONSUMPTION_GAS_1
                    ,CONSUMPTION_GAS_2
                    ,GAS_PRESSURE_1
                    ,TEMP_GAS_1
                    ,GAS_PRESSURE_2
                    ,TEMP_GAS_2
                    ,DIFF_PRESSURE_GAS_1
                    ,DIFF_PRESSURE_GAS_2
                    ,DIFF_PRESSURE_OOB
                    ,CONSUMPTION_OXYGEN_LV1
                    ,CONSUMPTION_OXYGEN_LV2
                    ,PRESSURE_OXYGEN
                    ,TEMP_OXYGEN
                    ,DIFF_PRESSURE_OXYGEN_LV1
                    ,DIFF_PRESSURE_OXYGEN_LV2
                    ,REG_DDTT
                    ,REGISTER
                  )
      SELECT to_number(TRIM(ITEM))                    -- Melt No
            ,TO_DATE(TRIM(ITEM_1), dateTimeTemplate)  -- MEASURING_TIME
            ,to_number(TRIM(ITEM_2))                  -- CONSUMPTION_GAS_1
            ,to_number(TRIM(ITEM_3))                  -- CONSUMPTION_GAS_2
            ,to_number(TRIM(ITEM_4))                  -- GAS_PRESSURE_1
            ,to_number(TRIM(ITEM_5))                  -- TEMP_GAS_1
            ,to_number(TRIM(ITEM_6))                  -- GAS_PRESSURE_2
            ,to_number(TRIM(ITEM_7))                  -- TEMP_GAS_2
            ,to_number(TRIM(ITEM_8))                  -- DIFF_PRESSURE_GAS_1
            ,to_number(TRIM(ITEM_9))                  -- DIFF_PRESSURE_GAS_2
            ,to_number(TRIM(ITEM_10))                 -- DIFF_PRESSURE_OOB
            ,to_number(TRIM(ITEM_11))                 -- CONSUMPTION_OXYGEN_LV1
            ,to_number(TRIM(ITEM_12))                 -- CONSUMPTION_OXYGEN_LV2
            ,to_number(TRIM(ITEM_13))                 -- PRESSURE_OXYGEN
            ,to_number(TRIM(ITEM_14))                 -- TEMP_OXYGEN
            ,to_number(TRIM(ITEM_15))                 -- DIFF_PRESSURE_OXYGEN_LV1
            ,to_number(TRIM(ITEM_16))                 -- DIFF_PRESSURE_OXYGEN_LV2
            ,SYSDATE
            ,procedureName
        FROM TB_PO_LEVEL2_INTERFACE 
        WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
        
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;