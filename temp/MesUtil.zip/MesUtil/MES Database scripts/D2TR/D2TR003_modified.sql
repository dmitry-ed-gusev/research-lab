create or replace 
PROCEDURE SP_TR_D2TR003 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR003        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Temperture information of RHF     
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       : 16.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D2TR003';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)
  
BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;

  --TB_PO_RHF_TEMPERATURE INSERT----------   
  BEGIN
    currentOperation := 'Operation [TB_PO_RHF_TEMPERATURE insert].'; -- current operation marker for error handling
    INSERT INTO TB_PO_RHF_TEMPERATURE (
      MEASURING_TIME
      ,No1_Furnace_Zone1_Temp
      ,No1_Furnace_Zone2_Temp
      ,No1_Furnace_Zone3_Temp
      ,No1_Furnace_Zone4_Temp
      ,No1_Furnace_Zone5_TEMP
      ,No2_Furnace_Zone1_Temp
      ,No2_Furnace_Zone2_Temp
      ,No2_Furnace_Zone3_Temp
      ,No2_Furnace_Zone4_Temp
      ,No2_Furnace_Zone5_TEMP
      ,REG_DDTT
      ,REGISTER
    )
      SELECT TO_DATE(TRIM(ITEM), dateTimeTemplate)  -- MEASURING_TIME
            ,to_number(TRIM(ITEM_1))                --No1_Furnace_Zone1_Temp
            ,to_number(TRIM(ITEM_2))                --No1_Furnace_Zone2_Temp
            ,to_number(TRIM(ITEM_3))                --No1_Furnace_Zone3_Temp
            ,to_number(TRIM(ITEM_4))                --No1_Furnace_Zone4_Temp
            ,to_number(TRIM(ITEM_5))                --No1_Furnace_Zone5_Temp
            ,to_number(TRIM(ITEM_6))                --No2_Furnace_Zone1_Temp
            ,to_number(TRIM(ITEM_7))                --No2_Furnace_Zone2_Temp
            ,to_number(TRIM(ITEM_8))                --No2_Furnace_Zone3_Temp
            ,to_number(TRIM(ITEM_9))                --No2_Furnace_Zone4_Temp
            ,to_number(TRIM(ITEM_10))               --No2_Furnace_Zone5_Temp
            ,SYSDATE
            ,procedureName
        FROM TB_PO_LEVEL2_INTERFACE 
        WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
            
      EXCEPTION
        WHEN NO_DATA_FOUND THEN -- error entry not exist in table
          errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;