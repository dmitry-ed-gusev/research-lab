create or replace 
PROCEDURE      SP_TR_D2TR005 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )                                                                              
 IS        
 /*------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR005            
 * VERSION           : V1.00                       
 * DESCRIPTION       : Mill900 Entrance Count   
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 03.07.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------
 
vERR_CODE                      NUMBER;
vERR_MSG                       VARCHAR2(250);

W_MELT_NO                      TB_PM_MILL_DAILY_PLAN.MELT_NO%TYPE;
--W_SEQ_IN_MELT                  TB_PM_MILL_DAILY_PLAN.SEQ_IN_MELT%TYPE;
W_INGOT_NO                     NUMBER;
--W_CUTTING_SEQ                  NUMBER;  
W_START_DATE                   DATE;
W_MILL_RESULT_QNTY             NUMBER;  
W_PROD_YY                      VARCHAR2(4);
W_PON                          VARCHAR2(7);
 
BEGIN


 RETURN;
    --  If first data occurs monitoring data set--
    
    SELECT TRIM(ITEM)
           ,TRIM(ITEM_1)
           ,TO_DATE(ITEM_2,'DD-MM-YYYY HH24:MI:SS')
      INTO W_MELT_NO
           ,W_INGOT_NO
           ,W_START_DATE
      FROM TB_PO_LEVEL2_INTERFACE 
     WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;  
   
   
    SELECT B.PROD_YY,B.PON,B.MILL_RESULT_QNTY
      INTO W_PROD_YY,W_PON,W_MILL_RESULT_QNTY
      FROM TB_PO_INGOT_COMM       A
          ,TB_PM_MILL_DAILY_PLAN  B
     WHERE A.MELT_NO      = W_MELT_NO
       AND A.INGOT_NO     = W_INGOT_NO
       AND B.SEQ_IN_MELT  = A.SEQ_IN_MELT
       AND B.MELT_NO      = A.MELT_NO
       ;
       
    IF  NVL(W_MILL_RESULT_QNTY,0) = 0   THEN 

        -- MONITORING DATA SET
        SP_TR_200_MONITOR  ('302'
                           ,'G'
                           ,W_MELT_NO
                           ,TO_CHAR(W_START_DATE,'YYYYMMDDHH24MI')
                           ,NULL
                           ,'S'
                           ,W_PROD_YY
                           ,W_PON
                           ,vERR_CODE 
                           ,vERR_MSG 
                          );
        IF  vERR_MSG  IS NOT NULL  THEN        
            RAISE_APPLICATION_ERROR(vERR_CODE,vERR_MSG);
            RETURN;
        END IF;   
    END IF;
    
    --  INGOT RHF_WORK_STATUS UPDATE 
    UPDATE TB_PO_FURNACE_CHARGE_ORD
       SET FURNACE_WORK_STATUS = 'R'                     -- RHF_WORK_STATUS      
           ,MOD_DDTT       = SYSDATE 
           ,MODIFIER       = 'SP_TR_D2TR005'
     WHERE MELT_NO   =  W_MELT_NO
       AND INGOT_NO  =  W_INGOT_NO
      AND MILL_GP   =  '9';

              
    --  INGOT COMM (MILL_START_DATE) UPDATE  
    UPDATE TB_PO_INGOT_COMM
       SET MILL_START_DDTT = W_START_DATE   
           ,MOD_DDTT       = SYSDATE 
           ,MODIFIER       = 'SP_TR_D2TR005'
     WHERE (MELT_NO,INGOT_NO) 
           = (SELECT TRIM(ITEM)
                    ,TRIM(ITEM_1)
               FROM TB_PO_LEVEL2_INTERFACE 
              WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY);
              
        

EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;
END;