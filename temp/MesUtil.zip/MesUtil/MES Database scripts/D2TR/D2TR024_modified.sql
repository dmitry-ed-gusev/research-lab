create or replace 
PROCEDURE SP_TR_D2TR024 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR024        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Ingot temperature at RHF exit   
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 16.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D2TR024';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
meltNo              number;                 -- melt number
ingotNo             number;                 -- ingot number
rhfExtTemp          number;
meltNoStr           varchar2(10 char);      -- temp melt number
ingotNoStr          varchar2(10 char);      -- temp blank number
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN 
  --RETURN;
  
  
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  BEGIN
    -- select melt number, siphon number, weighting time and crane weight
    SELECT TRIM(ITEM), TRIM(ITEM_1), to_number(TRIM(ITEM_3))
      INTO  meltNoStr, ingotNoStr, rhfExtTemp
      FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = in_sequence_key;
    
    meltNo := to_number(meltNoStr);
    ingotNo := to_number(ingotNoStr);
    
    EXCEPTION
      WHEN INVALID_NUMBER or VALUE_ERROR THEN   -- can't convert string to number
        errors := fn_process_error('', '', telegramId, in_sequence_key, 'Error convert string to number! ''meltNo'' = [' || meltNoStr || ']; ''ingotNo'' = [' || ingotNoStr || ']!', errors);
        return;
  END;
  
  -- TB_PO_INGOT_COMM UPDATE ----------      
  BEGIN
    currentOperation := 'Operation [TB_PO_INGOT_COMM update].'; -- current operation marker for error handling
    UPDATE TB_PO_INGOT_COMM
      SET RHF_EXT_TEMP  = rhfExtTemp
          ,MOD_DDTT     = SYSDATE
          ,MODIFIER     = procedureName
      WHERE MELT_NO = meltNo and INGOT_NO = ingotNo;
            
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
    
  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;