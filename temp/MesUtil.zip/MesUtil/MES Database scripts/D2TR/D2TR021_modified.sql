create or replace 
PROCEDURE SP_TR_D2TR021 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR021        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Consumption of energy at shop160(KTC)       
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 16.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D2TR021';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
      
  --TB_PO_UTILITY_SHOP160_KTC INSERT----------
  BEGIN
    currentOperation := 'Operation [TB_PO_UTILITY_SHOP160_KTC insert].'; -- current operation marker for error handling
    INSERT INTO TB_PO_UTILITY_SHOP160_KTC (
                  MEASURING_TIME
                  ,CONSUMPTION_GAS_ST900_LV1
                  ,CONSUMPTION_GAS_ST900_LV2
                  ,CONSUMPTION_GAS_ST900_LV3
                  ,PRESSURE_GAS_ST900
                  ,TEMP_GAS_ST900
                  ,DIFF_PRESSURE_GAS_ST900_LV1
                  ,DIFF_PRESSURE_GAS_ST900_LV2
                  ,DIFF_PRESSURE_GAS_ST900_LV3
                  ,CONSUMPTION_GAS_ST900_NP1
                  ,PRESSURE_GAS_ST900_NP1
                  ,CONSUMPTION_GAS_ST900_NP2
                  ,PRESSURE_GAS_ST900_NP2
                  ,DIFF_PRESSURE_GAS_ST900_NP1
                  ,DIFF_PRESSURE_GAS_ST900_NP2
                  ,CONSUMPTION_GAS_ST350_NP1
                  ,PRESSURE_GAS_ST350_NP1
                  ,CONSUMPTION_GAS_ST350_NP2
                  ,PRESSURE_GAS_ST350_NP2
                  ,CONSUMPTION_GAS_ST350_TP1
                  ,PRESSURE_GAS_ST350_TP1
                  ,CONSUMPTION_GAS_ST350_TP2
                  ,PRESSURE_GAS_ST350_TP2
                  ,CONSUMPTION_GAS_ST350_LV1
                  ,CONSUMPTION_GAS_ST350_LV2
                  ,CONSUMPTION_GAS_ST350_LV3
                  ,PRESSURE_GAS_ST350
                  ,TEMP_GAS_ST350
                  ,DIFF_PRESSURE_GAS_ST350_LV1
                  ,DIFF_PRESSURE_GAS_ST350_LV2
                  ,DIFF_PRESSURE_GAS_ST350_LV3
                  ,CONSUMPTION_ENERGY_RP71_9
                  ,CONSUMPTION_ENERGY_RP71_21
                  ,CONSUMPTION_ENERGY_RP71_25
                  ,CONSUMPTION_ENERGY_RP71_39
                  ,CONSUMPTION_ENERGY_RP72_8
                  ,CONSUMPTION_ENERGY_RP72_14
                  ,CONSUMPTION_ENERGY_TP191
                  ,CONSUMPTION_ENERGY_RP187
                  ,CONSUMPTION_ENERGY_RP81_4
                  ,CONSUMPTION_ENERGY_RP81_5
                  ,CONSUMPTION_ENERGY_RP81_13
                  ,CONSUMPTION_ENERGY_RP81_39
                  ,CONSUMPTION_ENERGY_RP81_40
                  ,CONSUMPTION_ENERGY_RP81_54
                  ,CONSUMPTION_ENERGY_RP81_56
                  ,CONSUMPTION_ENERGY_RP14
                  ,REG_DDTT
                  ,REGISTER
                )
      SELECT TO_DATE(TRIM(ITEM), dateTimeTemplate)            -- MEASURING_TIME
            ,TRIM(ITEM_1)                                     -- CONSUMPTION_GAS_ST900_LV1
            ,TRIM(ITEM_2)                                     -- CONSUMPTION_GAS_ST900_LV2
            ,TRIM(ITEM_3)                                     -- CONSUMPTION_GAS_ST900_LV3
            ,TRIM(ITEM_4)                                     -- PRESSURE_GAS_ST900
            ,TRIM(ITEM_5)                                     -- TEMP_GAS_ST900
            ,TRIM(ITEM_6)                                     -- DIFF_PRESSURE_GAS_ST900_LV1
            ,TRIM(ITEM_7)                                     -- DIFF_PRESSURE_GAS_ST900_LV2
            ,TRIM(ITEM_8)                                     -- DIFF_PRESSURE_GAS_ST900_LV3
            ,TRIM(ITEM_9)                                     -- CONSUMPTION_GAS_ST900_NP1
            ,TRIM(ITEM_10)                                    -- PRESSURE_GAS_ST900_NP1
            ,TRIM(ITEM_11)                                    -- CONSUMPTION_GAS_ST900_NP2
            ,TRIM(ITEM_12)                                    -- PRESSURE_GAS_ST900_NP2
            ,TRIM(ITEM_13)                                    -- DIFF_PRESSURE_GAS_ST900_NP1
            ,TRIM(ITEM_14)                                    -- DIFF_PRESSURE_GAS_ST900_NP2
            ,TRIM(ITEM_15)                                    -- CONSUMPTION_GAS_ST350_NP1
            ,TRIM(ITEM_16)                                    -- PRESSURE_GAS_ST350_NP1
            ,TRIM(ITEM_17)                                    -- CONSUMPTION_GAS_ST350_NP2
            ,TRIM(ITEM_18)                                    -- PRESSURE_GAS_ST350_NP2
            ,TRIM(ITEM_19)                                    -- CONSUMPTION_GAS_ST350_TP1
            ,TRIM(ITEM_20)                                    -- PRESSURE_GAS_ST350_TP1
            ,TRIM(ITEM_21)                                    -- CONSUMPTION_GAS_ST350_TP2
            ,TRIM(ITEM_22)                                    -- PRESSURE_GAS_ST350_TP2
            ,TRIM(ITEM_23)                                    -- CONSUMPTION_GAS_ST350_LV1
            ,TRIM(ITEM_24)                                    -- CONSUMPTION_GAS_ST350_LV2
            ,TRIM(ITEM_25)                                    -- CONSUMPTION_GAS_ST350_LV3
            ,TRIM(ITEM_26)                                    -- PRESSURE_GAS_ST350
            ,TRIM(ITEM_27)                                    -- TEMP_GAS_ST350
            ,TRIM(ITEM_28)                                    -- DIFF_PRESSURE_GAS_ST350_LV1
            ,TRIM(ITEM_29)                                    -- DIFF_PRESSURE_GAS_ST350_LV2
            ,TRIM(ITEM_30)                                    -- DIFF_PRESSURE_GAS_ST350_LV3
            ,TRIM(ITEM_31)                                    -- CONSUMPTION_ENERGY_RP71_9
            ,TRIM(ITEM_32)                                    -- CONSUMPTION_ENERGY_RP71_21
            ,TRIM(ITEM_33)                                    -- CONSUMPTION_ENERGY_RP71_25
            ,TRIM(ITEM_34)                                    -- CONSUMPTION_ENERGY_RP71_39
            ,TRIM(ITEM_35)                                    -- CONSUMPTION_ENERGY_RP72_8
            ,TRIM(ITEM_36)                                    -- CONSUMPTION_ENERGY_RP72_14
            ,TRIM(ITEM_37)                                    -- CONSUMPTION_ENERGY_TP191
            ,TRIM(ITEM_38)                                    -- CONSUMPTION_ENERGY_RP187
            ,TRIM(ITEM_39)                                    -- CONSUMPTION_ENERGY_RP81_4
            ,TRIM(ITEM_40)                                    -- CONSUMPTION_ENERGY_RP81_5
            ,TRIM(ITEM_41)                                    -- CONSUMPTION_ENERGY_RP81_13
            ,TRIM(ITEM_42)                                    -- CONSUMPTION_ENERGY_RP81_39
            ,TRIM(ITEM_43)                                    -- CONSUMPTION_ENERGY_RP81_40
            ,TRIM(ITEM_44)                                    -- CONSUMPTION_ENERGY_RP81_54
            ,TRIM(ITEM_45)                                    -- CONSUMPTION_ENERGY_RP81_56
            ,TRIM(ITEM_46)                                    -- CONSUMPTION_ENERGY_RP14
            ,SYSDATE
            ,defaultTelegramId
      FROM TB_PO_LEVEL2_INTERFACE 
      WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
      
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;