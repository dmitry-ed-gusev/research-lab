create or replace 
PROCEDURE SP_TR_D2TR012 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS        

 /*------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR012            
 * VERSION           : V2.00
 * DESCRIPTION       : Mill680 Product Count
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 03.07.2012
 * MODIFY DATE       : 16.01.2014
 */-----------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D2TR012';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
meltNo              number;                 -- melt number
ingotNo             number;                 -- ingot number
millDdTt            date;
workDuty            varchar2(1) := null;
workShift           varchar2(1) := null;

workHour            char(5);
remainCount         number;
prodSeq             number;
cnt                 number;

prodYy              varchar2(4) := null;
pon                 varchar2(7) := null;
seqInMelt           number;
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)
errorCode           varchar2(250) := null;

BEGIN
  RETURN;
  
  
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  -- select melt number, siphon number, weighting time and crane weight
  SELECT to_number(TRIM(ITEM)), to_number(TRIM(ITEM_1)), to_date(TRIM(ITEM_3), dateTimeTemplate)
    INTO  meltNo, ingotNo, millDdTt
    FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = in_sequence_key;
    
  --  LAST PRODUCT CHECK FOR INGOT
  SELECT SUM(PROD_ORD_QNTY) - NVL(SUM(PROD_QNTY),0) INTO remainCount
    FROM TB_PO_MILL900_PIECE_ORD
    WHERE MELT_NO = meltNo AND INGOT_NO = ingotNo
    GROUP BY MELT_NO, INGOT_NO;
     
  --  update when  some ingot  finished production 
  IF remainCount = 1 THEN   --  LAST PRODUCT
    --  Mill daily plan update
    BEGIN
      currentOperation := 'Operation [TB_PM_MILL_DAILY_PLAN update].'; -- current operation marker for error handling
      UPDATE TB_PM_MILL_DAILY_PLAN
        SET MILL_RESULT_QNTY = NVL(MILL_RESULT_QNTY,0) + 1
        WHERE (MELT_NO,SEQ_IN_MELT) = (
                SELECT MELT_NO,SEQ_IN_MELT
                  FROM TB_PO_INGOT_COMM 
                  WHERE MELT_NO = meltNo AND INGOT_NO = ingotNo
              )
              AND MILL_GP = '9';
              
      EXCEPTION
        WHEN NO_DATA_FOUND THEN -- error entry not exist in table
          errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
    END;
        
    --  TB_PO_INGOT_COMM update
    BEGIN
      currentOperation := 'Operation [TB_PO_INGOT_COMM update].'; -- current operation marker for error handling
      UPDATE TB_PO_INGOT_COMM
        SET MILL_END_DDTT = millDdTt
        WHERE MELT_NO = meltNo AND INGOT_NO = ingotNo;
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN -- error entry not exist in table
          errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
    END;
        
  END IF;
  
  --  TB_PO_MILL900_PIECE_ORD (PROD_QNTY,MILL_DATE) UPDATE
  SELECT NVL(MIN(PROD_SEQ),0) INTO prodSeq
    FROM TB_PO_MILL900_PIECE_ORD
    WHERE MELT_NO = meltNo AND INGOT_NO = ingotNo AND PROD_ORD_MILL900_680_GP = '6' AND PROD_ORD_QNTY > NVL(PROD_QNTY,0)
    GROUP BY MELT_NO, INGOT_NO, PROD_ORD_MILL900_680_GP;
       
  IF prodSeq = 0 THEN
    SELECT NVL(MAX(PROD_SEQ),0) INTO prodSeq
      FROM TB_PO_MILL900_PIECE_ORD
      WHERE MELT_NO = meltNo AND INGOT_NO = ingotNo AND PROD_ORD_MILL900_680_GP = '6' AND PROD_ORD_QNTY <= NVL(PROD_QNTY,0)
      GROUP BY MELT_NO, INGOT_NO, PROD_ORD_MILL900_680_GP;
  END IF;
  
  BEGIN
    currentOperation := 'Operation [TB_PO_MILL900_PIECE_ORD update].'; -- current operation marker for error handling
    UPDATE TB_PO_MILL900_PIECE_ORD
      SET PROD_QNTY  = NVL(PROD_QNTY,0) + 1 
         ,MILL_DDTT  = millDdTt
         ,MOD_DDTT   = SYSDATE 
         ,MODIFIER   = procedureName
      WHERE MELT_NO = meltNo AND INGOT_NO = ingotNo AND PROD_SEQ = prodSeq;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
       
  --  TB_PO_MILL_PON_RESULT UPDATE
  SELECT B.PROD_YY,B.PON,B.SEQ_IN_MELT INTO prodYy, pon, seqInMelt
    FROM  TB_PO_INGOT_COMM A
          ,TB_PM_MILL_DAILY_PLAN B
    WHERE A.MELT_NO = meltNo
      AND A.INGOT_NO    = ingotNo
      AND B.MILL_GP     = '9'
      AND B.SEQ_IN_MELT = A.SEQ_IN_MELT
      AND B.MELT_NO     = A.MELT_NO; 
      
  -- MONITORING CHECK & SET                         
  SELECT COUNT(*) INTO cnt
    FROM TB_PO_MILL900_PIECE_ORD
    WHERE (MELT_NO,INGOT_NO) = (
      SELECT MELT_NO, MAX(INGOT_NO) INGOT_NO
        FROM TB_PO_INGOT_COMM
        WHERE MELT_NO = meltNo AND SEQ_IN_MELT = seqInMelt
        GROUP BY MELT_NO, SEQ_IN_MELT   
      )
      AND (PROD_ORD_MILL900_680_GP = '9' AND PROD_ORD_QNTY >= NVL(PROD_QNTY,0))
      AND (PROD_ORD_MILL900_680_GP = '6' AND PROD_ORD_QNTY >= NVL(PROD_QNTY,0));
      
  IF cnt > 0 THEN
    SP_TR_200_MONITOR ( '302'
                        ,'G'
                        ,meltNo
                        ,NULL
                        ,TO_CHAR(millDdTt,'YYYYMMDDHH24MI')
                        ,'E'
                        ,prodYy
                        ,pon
                        ,errorCode 
                        ,errors 
                      );
                      
    IF errors IS NOT NULL THEN
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
      RETURN;
    END IF;
  END IF;
  
  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;