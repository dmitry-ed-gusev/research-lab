create or replace 
PROCEDURE      SP_TR_D2TR012 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )                                                                              
 IS        
 /*------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR012            
 * VERSION           : V1.00                       
 * DESCRIPTION       : Mill680 Product Count   
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 03.07.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------
 
vERR_CODE                      NUMBER;
vERR_MSG                       VARCHAR2(250);

W_MELT_NO                      TB_PO_INGOT_COMM.MELT_NO%TYPE;
W_INGOT_NO                     TB_PO_INGOT_COMM.INGOT_NO%TYPE;
W_MILL_DDTT                    TB_PO_MILL900_PIECE_ORD.MILL_DDTT%TYPE; 
W_WORK_DUTY                    TB_PO_SHIFT_WORKER.WORK_DUTY%TYPE; 
W_WORK_SHIFT                   TB_PO_SHIFT_WORKER.WORK_SHIFT%TYPE;

W_WORK_HR                      CHAR(5);
W_REMAIN_CNT                   NUMBER;
W_PROD_SEQ                     NUMBER;
W_CNT                          NUMBER;

W_PROD_YY                      VARCHAR2(4);
W_PON                          VARCHAR2(7);
W_SEQ_IN_MELT                  NUMBER;
--W_CUTTING_SEQ                  NUMBER; 
 
BEGIN
 
  RETURN;
    -- Select interface data 
    SELECT TRIM(ITEM),TRIM(ITEM_1),TO_DATE(TRIM(ITEM_3),'DD-MM-YYYY HH24:MI:SS')
      INTO W_MELT_NO,W_INGOT_NO,W_MILL_DDTT 
      FROM TB_PO_LEVEL2_INTERFACE 
     WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
     
    --  LAST PRODUCT CHECK  FOR INGOT
    SELECT SUM(PROD_ORD_QNTY) - NVL(SUM(PROD_QNTY),0) 
      INTO W_REMAIN_CNT
      FROM TB_PO_MILL900_PIECE_ORD
     WHERE MELT_NO                 = W_MELT_NO
       AND INGOT_NO                = W_INGOT_NO
     GROUP BY MELT_NO,INGOT_NO; 
     
    --  update when  some ingot  finished production 
    IF  W_REMAIN_CNT  = 1   THEN   --  LAST PRODUCT
     
        --  Mill daily plan update 
        UPDATE TB_PM_MILL_DAILY_PLAN
          SET MILL_RESULT_QNTY = NVL(MILL_RESULT_QNTY,0) + 1
        WHERE (MELT_NO,SEQ_IN_MELT)
              = (SELECT MELT_NO,SEQ_IN_MELT
                   FROM TB_PO_INGOT_COMM 
                  WHERE MELT_NO   = W_MELT_NO
                    AND INGOT_NO  = W_INGOT_NO)
          AND MILL_GP = '9';
          
        --  INGOT COMM update  
        UPDATE TB_PO_INGOT_COMM
          SET MILL_END_DDTT = W_MILL_DDTT
        WHERE MELT_NO   = W_MELT_NO
          AND INGOT_NO  = W_INGOT_NO;          
           
    END IF;
    
       
    --  TB_PO_MILL900_PIECE_ORD (PROD_QNTY,MILL_DATE) UPDATE
    
    SELECT NVL(MIN(PROD_SEQ),0) INTO W_PROD_SEQ
      FROM TB_PO_MILL900_PIECE_ORD
     WHERE MELT_NO                 = W_MELT_NO
       AND INGOT_NO                = W_INGOT_NO 
       AND PROD_ORD_MILL900_680_GP = '6'
       AND PROD_ORD_QNTY           > NVL(PROD_QNTY,0)
     GROUP BY MELT_NO,INGOT_NO,PROD_ORD_MILL900_680_GP;
       
    IF  W_PROD_SEQ = 0  THEN
        SELECT NVL(MAX(PROD_SEQ),0) INTO W_PROD_SEQ
          FROM TB_PO_MILL900_PIECE_ORD
         WHERE MELT_NO                 = W_MELT_NO
           AND INGOT_NO                = W_INGOT_NO 
           AND PROD_ORD_MILL900_680_GP = '6'
           AND PROD_ORD_QNTY          <= NVL(PROD_QNTY,0)
         GROUP BY MELT_NO,INGOT_NO,PROD_ORD_MILL900_680_GP  ;  
    END IF;
   
    UPDATE TB_PO_MILL900_PIECE_ORD
       SET PROD_QNTY  = NVL(PROD_QNTY,0) + 1 
           ,MILL_DDTT  = W_MILL_DDTT
           ,MOD_DDTT   = SYSDATE 
           ,MODIFIER   = 'SP_TR_D2TR012'
     WHERE MELT_NO     = W_MELT_NO
       AND INGOT_NO    = W_INGOT_NO
       AND PROD_SEQ    = W_PROD_SEQ;
       
     --  TB_PO_MILL_PON_RESULT UPDATE
    SELECT B.PROD_YY,B.PON,B.SEQ_IN_MELT  INTO W_PROD_YY, W_PON, W_SEQ_IN_MELT
      FROM TB_PO_INGOT_COMM A
           ,TB_PM_MILL_DAILY_PLAN B
     WHERE A.MELT_NO     = W_MELT_NO
       AND A.INGOT_NO    = W_INGOT_NO
       AND B.MILL_GP     = '9'
       AND B.SEQ_IN_MELT = A.SEQ_IN_MELT
       AND B.MELT_NO     = A.MELT_NO; 
         

    -- MONITORING CHECK & SET                         
    SELECT COUNT(*) INTO W_CNT
      FROM TB_PO_MILL900_PIECE_ORD
     WHERE (MELT_NO,INGOT_NO) 
           = (SELECT MELT_NO,MAX(INGOT_NO) INGOT_NO
                FROM TB_PO_INGOT_COMM
               WHERE MELT_NO = W_MELT_NO
                 AND SEQ_IN_MELT = W_SEQ_IN_MELT
               GROUP BY MELT_NO,SEQ_IN_MELT   
             )
       AND (PROD_ORD_MILL900_680_GP = '9' AND PROD_ORD_QNTY >= NVL(PROD_QNTY,0))
       AND (PROD_ORD_MILL900_680_GP = '6' AND PROD_ORD_QNTY >= NVL(PROD_QNTY,0))
     ;  
    IF  W_CNT >  0  THEN
        SP_TR_200_MONITOR  ('302'
                           ,'G'
                           ,W_MELT_NO
                           ,NULL
                           ,TO_CHAR(W_MILL_DDTT,'YYYYMMDDHH24MI')
                           ,'E'
                           ,W_PROD_YY
                           ,W_PON
                           ,vERR_CODE 
                           ,vERR_MSG 
                          );
        IF  vERR_MSG  IS NOT NULL  THEN        
            RETURN;
        END IF;
    END IF;                         
EXCEPTION  
    WHEN    OTHERS  THEN 
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_MILL900_PIECE_ORD UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE '
                        ||  ' (' || SQLERRM || ')';      
            RAISE;
       
END;