create or replace 
PROCEDURE SP_TR_D2TR005 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR005            
 * VERSION           : V2.00                       
 * DESCRIPTION       : Mill900 Entrance Count   
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 03.07.2012
 * MODIFY DATE       : 16.01.2014
 */-----------------------------------------------------------------------
 
 -- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D2TR005';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
meltNo              number;                 -- melt number
ingotNo             number;                 -- ingot number
startDate           date;                   -- start date
millResultQnty      number;                 -- mill result quantity
prodYY              varchar2(4);
pon                 varchar2(7);
meltNoStr           varchar2(10 char);      -- temp melt number
ingotNoStr          varchar2(10 char);      -- temp blank number
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)
errorCode           varchar2(250) := null;

BEGIN
  --RETURN;
  
  
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  BEGIN
    -- select melt number, siphon number, weighting time and crane weight
    SELECT TRIM(ITEM), TRIM(ITEM_1), to_date(TRIM(ITEM_2), dateTimeTemplate)
      INTO  meltNoStr, ingotNoStr, startDate
      FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = in_sequence_key;
    
    meltNo := to_number(meltNoStr);
    ingotNo := to_number(ingotNoStr);
    
    EXCEPTION
      WHEN INVALID_NUMBER or VALUE_ERROR THEN   -- can't convert string to number
        errors := fn_process_error('', '', telegramId, in_sequence_key, 'Error convert string to number! ''meltNo'' = [' || meltNoStr || ']; ''ingotNo'' = [' || ingotNoStr || ']!', errors);
        return;
  END;
    
  SELECT B.PROD_YY, B.PON, B.MILL_RESULT_QNTY
    INTO prodYY, pon, millResultQnty
    FROM TB_PO_INGOT_COMM       A
        ,TB_PM_MILL_DAILY_PLAN  B
    WHERE A.MELT_NO     = meltNo
      AND A.INGOT_NO    = ingotNo
      AND B.SEQ_IN_MELT = A.SEQ_IN_MELT
      AND B.MELT_NO     = A.MELT_NO;

  -- MONITORING DATA SET
  IF NVL(millResultQnty, 0) = 0 THEN
    SP_TR_200_MONITOR ('302'
                      ,'G'
                      ,meltNo
                      ,TO_CHAR(startDate,'YYYYMMDDHH24MI')
                      ,NULL
                      ,'S'
                      ,prodYY
                      ,pon
                      ,errorCode 
                      ,errors 
                      );

    IF errors IS NOT NULL THEN        
      RAISE_APPLICATION_ERROR(errorCode, errors);
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
      RETURN;
    END IF;   
  END IF;

  --  TB_PO_FURNACE_CHARGE_ORD UPDATE
  BEGIN
    currentOperation := 'Operation [TB_PO_FURNACE_CHARGE_ORD update].'; -- current operation marker for error handling
    UPDATE TB_PO_FURNACE_CHARGE_ORD
      SET FURNACE_WORK_STATUS = 'R'         -- RHF_WORK_STATUS      
          ,MOD_DDTT       = SYSDATE 
          ,MODIFIER       = procedureName
      WHERE MELT_NO = meltNo AND INGOT_NO = ingotNo AND MILL_GP = '9';
      
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  --  TB_PO_INGOT_COMM UPDATE
  BEGIN
    currentOperation := 'Operation [TB_PO_INGOT_COMM update].'; -- current operation marker for error handling
    UPDATE TB_PO_INGOT_COMM
      SET MILL_START_DDTT = startDate   
          ,MOD_DDTT       = SYSDATE 
          ,MODIFIER       = procedureName
      WHERE MELT_NO = meltNo and INGOT_NO = ingotNo;
      
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;