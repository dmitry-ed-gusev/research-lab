create or replace 
PROCEDURE      SP_TR_D2TR022 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR022       
 * VERSION           : V1.00                       
 * DESCRIPTION       : Mill680 Roll Speed information 
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
  
BEGIN 
      
    --TB_PO_MILL900_ETC_INFORMATION INSERT----------
                                                 
    BEGIN
           INSERT INTO TB_PO_MILL_ROLL_SPEED
                  ( TC_ID
                    ,MEASURING_TIME
                    ,TOTAL_TELEGRMS
                    ,NUMBER_TELEGRAM
                    ,ROLL_SPEED_1
                    ,ROLL_SPEED_2
                    ,ROLL_SPEED_3
                    ,ROLL_SPEED_4
                    ,ROLL_SPEED_5
                    ,ROLL_SPEED_6
                    ,ROLL_SPEED_7
                    ,ROLL_SPEED_8
                    ,ROLL_SPEED_9
                    ,ROLL_SPEED_10
                    ,ROLL_SPEED_11
                    ,ROLL_SPEED_12
                    ,ROLL_SPEED_13
                    ,ROLL_SPEED_14
                    ,ROLL_SPEED_15
                    ,ROLL_SPEED_16
                    ,ROLL_SPEED_17
                    ,ROLL_SPEED_18
                    ,ROLL_SPEED_19
                    ,ROLL_SPEED_20
                    ,ROLL_SPEED_21
                    ,ROLL_SPEED_22
                    ,ROLL_SPEED_23
                    ,ROLL_SPEED_24
                    ,ROLL_SPEED_25
                    ,ROLL_SPEED_26
                    ,ROLL_SPEED_27
                    ,ROLL_SPEED_28
                    ,ROLL_SPEED_29
                    ,ROLL_SPEED_30
                    ,ROLL_SPEED_31
                    ,ROLL_SPEED_32
                    ,ROLL_SPEED_33
                    ,ROLL_SPEED_34
                    ,ROLL_SPEED_35
                    ,ROLL_SPEED_36
                    ,ROLL_SPEED_37
                    ,ROLL_SPEED_38
                    ,ROLL_SPEED_39
                    ,ROLL_SPEED_40
                    ,ROLL_SPEED_41
                    ,ROLL_SPEED_42
                    ,ROLL_SPEED_43
                    ,ROLL_SPEED_44
                    ,ROLL_SPEED_45
                    ,ROLL_SPEED_46
                    ,ROLL_SPEED_47
                    ,ROLL_SPEED_48
                    ,ROLL_SPEED_49
                    ,ROLL_SPEED_50
                    ,ROLL_SPEED_51
                    ,ROLL_SPEED_52
                    ,ROLL_SPEED_53
                    ,ROLL_SPEED_54
                    ,ROLL_SPEED_55
                    ,ROLL_SPEED_56
                    ,ROLL_SPEED_57
                    ,ROLL_SPEED_58
                    ,ROLL_SPEED_59
                    ,ROLL_SPEED_60
                    ,ROLL_SPEED_61
                    ,ROLL_SPEED_62
                    ,ROLL_SPEED_63
                    ,ROLL_SPEED_64
                    ,ROLL_SPEED_65
                    ,ROLL_SPEED_66
                    ,ROLL_SPEED_67
                    ,ROLL_SPEED_68
                    ,ROLL_SPEED_69
                    ,ROLL_SPEED_70
                    ,ROLL_SPEED_71
                    ,ROLL_SPEED_72
                    ,ROLL_SPEED_73
                    ,ROLL_SPEED_74
                    ,ROLL_SPEED_75
                    ,ROLL_SPEED_76
                    ,ROLL_SPEED_77
                    ,ROLL_SPEED_78
                    ,ROLL_SPEED_79
                    ,ROLL_SPEED_80
                    ,ROLL_SPEED_81
                    ,ROLL_SPEED_82
                    ,ROLL_SPEED_83
                    ,ROLL_SPEED_84
                    ,ROLL_SPEED_85
                    ,ROLL_SPEED_86
                    ,ROLL_SPEED_87
                    ,ROLL_SPEED_88
                    ,ROLL_SPEED_89
                    ,ROLL_SPEED_90
                    ,ROLL_SPEED_91
                    ,ROLL_SPEED_92
                    ,ROLL_SPEED_93
                    ,ROLL_SPEED_94
                    ,ROLL_SPEED_95
                    ,ROLL_SPEED_96
                    ,ROLL_SPEED_97
                    ,ROLL_SPEED_98
                    ,ROLL_SPEED_99
                    ,ROLL_SPEED_100
                    ,ROLL_SPEED_101
                    ,ROLL_SPEED_102
                    ,ROLL_SPEED_103
                    ,ROLL_SPEED_104
                    ,ROLL_SPEED_105
                    ,ROLL_SPEED_106
                    ,REG_DDTT
                    ,REGISTER
                  )
           SELECT   TRIM(TC_ID)                                     --TC_ID   
                    ,TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS')   --MEASURING_TIME
                    ,TRIM(ITEM_1)
                    ,TRIM(ITEM_2)
                    ,TRIM(ITEM_3)
                    ,TRIM(ITEM_4)
                    ,TRIM(ITEM_5)
                    ,TRIM(ITEM_6)
                    ,TRIM(ITEM_7)
                    ,TRIM(ITEM_8)
                    ,TRIM(ITEM_9)
                    ,TRIM(ITEM_10)
                    ,TRIM(ITEM_11)
                    ,TRIM(ITEM_12)
                    ,TRIM(ITEM_13)
                    ,TRIM(ITEM_14)
                    ,TRIM(ITEM_15)
                    ,TRIM(ITEM_16)
                    ,TRIM(ITEM_17)
                    ,TRIM(ITEM_18)
                    ,TRIM(ITEM_19)
                    ,TRIM(ITEM_20)
                    ,TRIM(ITEM_21)
                    ,TRIM(ITEM_22)
                    ,TRIM(ITEM_23)
                    ,TRIM(ITEM_24)
                    ,TRIM(ITEM_25)
                    ,TRIM(ITEM_26)
                    ,TRIM(ITEM_27)
                    ,TRIM(ITEM_28)
                    ,TRIM(ITEM_29)
                    ,TRIM(ITEM_30)
                    ,TRIM(ITEM_31)
                    ,TRIM(ITEM_32)
                    ,TRIM(ITEM_33)
                    ,TRIM(ITEM_34)
                    ,TRIM(ITEM_35)
                    ,TRIM(ITEM_36)
                    ,TRIM(ITEM_37)
                    ,TRIM(ITEM_38)
                    ,TRIM(ITEM_39)
                    ,TRIM(ITEM_40)
                    ,TRIM(ITEM_41)
                    ,TRIM(ITEM_42)
                    ,TRIM(ITEM_43)
                    ,TRIM(ITEM_44)
                    ,TRIM(ITEM_45)
                    ,TRIM(ITEM_46)
                    ,TRIM(ITEM_47)
                    ,TRIM(ITEM_48)
                    ,TRIM(ITEM_49)
                    ,TRIM(ITEM_50)
                    ,TRIM(ITEM_51)
                    ,TRIM(ITEM_52)
                    ,TRIM(ITEM_53)
                    ,TRIM(ITEM_54)
                    ,TRIM(ITEM_55)
                    ,TRIM(ITEM_56)
                    ,TRIM(ITEM_57)
                    ,TRIM(ITEM_58)
                    ,TRIM(ITEM_59)
                    ,TRIM(ITEM_60)
                    ,TRIM(ITEM_61)
                    ,TRIM(ITEM_62)
                    ,TRIM(ITEM_63)
                    ,TRIM(ITEM_64)
                    ,TRIM(ITEM_65)
                    ,TRIM(ITEM_66)
                    ,TRIM(ITEM_67)
                    ,TRIM(ITEM_68)
                    ,TRIM(ITEM_69)
                    ,TRIM(ITEM_70)
                    ,TRIM(ITEM_71)
                    ,TRIM(ITEM_72)
                    ,TRIM(ITEM_73)
                    ,TRIM(ITEM_74)
                    ,TRIM(ITEM_75)
                    ,TRIM(ITEM_76)
                    ,TRIM(ITEM_77)
                    ,TRIM(ITEM_78)
                    ,TRIM(ITEM_79)
                    ,TRIM(ITEM_80)
                    ,TRIM(ITEM_81)
                    ,TRIM(ITEM_82)
                    ,TRIM(ITEM_83)
                    ,TRIM(ITEM_84)
                    ,TRIM(ITEM_85)
                    ,TRIM(ITEM_86)
                    ,TRIM(ITEM_87)
                    ,TRIM(ITEM_88)
                    ,TRIM(ITEM_89)
                    ,TRIM(ITEM_90)
                    ,TRIM(ITEM_91)
                    ,TRIM(ITEM_92)
                    ,TRIM(ITEM_93)
                    ,TRIM(ITEM_94)
                    ,TRIM(ITEM_95)
                    ,TRIM(ITEM_96)
                    ,TRIM(ITEM_97)
                    ,TRIM(ITEM_98)
                    ,TRIM(ITEM_99)
                    ,TRIM(ITEM_100)
                    ,TRIM(ITEM_101)
                    ,TRIM(ITEM_102)
                    ,TRIM(ITEM_103)
                    ,TRIM(ITEM_104)
                    ,TRIM(ITEM_105)
                    ,TRIM(ITEM_106)
                    ,TRIM(ITEM_107)
                    ,TRIM(ITEM_108)
                    
                    ,SYSDATE
                    ,'SP_TR_D2TR022'
             FROM TB_PO_LEVEL2_INTERFACE 
            WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
              
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_MILL_ROLL_SPEED ISERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RETURN;
    END;

EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;