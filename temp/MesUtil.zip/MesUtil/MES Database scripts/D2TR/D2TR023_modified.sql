create or replace 
PROCEDURE SP_TR_D2TR023 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR023        
 * VERSION           : V2.00                       
 * DESCRIPTION       : Ingot entrance information(weight,temperature) in RHF    
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 16.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D2TR023';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
meltNo              number;                 -- melt number
ingotNo             number;                 -- ingot number
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN 
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  -- select melt number, ingot number
  SELECT to_number(TRIM(ITEM)), to_number(TRIM(ITEM_1))
    INTO  meltNo, ingotNo
    FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = in_sequence_key;
  
  -- TB_PO_INGOT_COMM UPDATE ----------
  BEGIN
    currentOperation := 'Operation [TB_PO_INGOT_COMM update].'; -- current operation marker for error handling
    UPDATE TB_PO_INGOT_COMM
      SET ( INGOT_RHF_WEIGHING_TIME
            ,RHF_WEIGHING_WT
            ,RHF_CHARGE_TEMP
            ,MOD_DDTT
            ,MODIFIER
          ) = (
              SELECT TO_DATE(TRIM(ITEM_2), dateTimeTemplate)
                    ,TRIM(ITEM_3)
                    ,TRIM(ITEM_4)
                    ,SYSDATE
                    ,defaultTelegramId
                FROM TB_PO_LEVEL2_INTERFACE 
                WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY)
      WHERE MELT_NO = meltNo and INGOT_NO = ingotNo;
      
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  -- TB_PO_RHF_CHARGE_ORD UPDEATE ----------
  BEGIN
    currentOperation := 'Operation [TB_PO_FURNACE_CHARGE_ORD update].'; -- current operation marker for error handling
    UPDATE TB_PO_FURNACE_CHARGE_ORD
      SET FURNACE_WORK_STATUS = 'W'                     -- INGOT WEIGHING STATUS       
          ,MOD_DDTT           = SYSDATE 
          ,MODIFIER           = defaultTelegramId
      WHERE MELT_NO = meltNo and INGOT_NO = ingotNo AND MILL_GP = '9';
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
    
  -- TB_PM_MILL_DAILY_PLAN UPDATE ----------
  BEGIN
    currentOperation := 'Operation [TB_PM_MILL_DAILY_PLAN update].'; -- current operation marker for error handling
    UPDATE TB_PM_MILL_DAILY_PLAN
      SET FURNACE_WEIGHING_QNTY = NVL(FURNACE_WEIGHING_QNTY,0) + 1
      WHERE (MELT_NO,SEQ_IN_MELT) = (
        SELECT MELT_NO,SEQ_IN_MELT
        FROM TB_PO_INGOT_COMM 
        WHERE MELT_NO = meltNo and INGOT_NO = ingotNo
      )                               
      AND MILL_GP = '9';
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;
  
     ---------- TB_PO_MILL_PON_RESULT INSERT  (PON)
     ---------- TB_PO_MILL900_PIECE_ORD INSERT(PON) 
--     SELECT COUNT(*) INTO W_PON_CNT
--       FROM TB_PM_MILL_DAILY_PLAN A
--            ,TB_PO_MILL_PON_RESULT B
--            ,(SELECT MELT_NO,SEQ_IN_MELT
--               FROM TB_PO_INGOT_COMM
--              WHERE (MELT_NO,INGOT_NO) = (SELECT TRIM(ITEM)
--                                                ,TRIM(ITEM_1)
--                                           FROM TB_PO_LEVEL2_INTERFACE 
--                                          WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY)) C
--      WHERE A.MELT_NO     = C.MELT_NO
--        AND A.SEQ_IN_MELT = C.SEQ_IN_MELT
--        AND A.MILL_GP     = '9'
--        AND B.MILL_GP     = A.MILL_GP
--        AND B.PROD_YY     = A.PROD_YY
--        AND B.PON         = A.PON;
      
--     IF  W_PON_CNT  = 0  THEN
--          
--         SELECT MELT_NO,SEQ_IN_MELT
--           INTO W_MELT_NO,W_SEQ_IN_MELT 
--           FROM TB_PO_INGOT_COMM
--          WHERE (MELT_NO,INGOT_NO) = (SELECT TRIM(ITEM)
--                                            ,TRIM(ITEM_1)
--                                       FROM TB_PO_LEVEL2_INTERFACE 
--                                      WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY);
--                                      
--         -- TB_PO_MILL_PON_RESULT INSERT  (PON)       
--                                      
--         SP_TR_400_PON9  (W_MELT_NO,W_SEQ_IN_MELT);
--         COMMIT;
--         
--         -- TB_PO_MILL900_PIECE_ORD INSERT(PON)
--                                      
--         SP_TR_400_PIECE  (W_MELT_NO,W_SEQ_IN_MELT);
--         COMMIT;
--     END IF;

  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;