create or replace 
PROCEDURE      SP_TR_D2TR008 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )                                                                              
 IS        
 /*------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR008            
 * VERSION           : V1.00                       
 * DESCRIPTION       : Mill680 Entrance Count   
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 03.07.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------
 
vERR_CODE                      NUMBER;
vERR_MSG                       VARCHAR2(250);


 
BEGIN
    RETURN;
    
   

EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;
END;