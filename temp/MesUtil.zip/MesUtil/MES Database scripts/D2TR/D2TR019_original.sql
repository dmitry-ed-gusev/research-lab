create or replace 
PROCEDURE      SP_TR_D2TR019 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR019        
 * VERSION           : V1.00                       
 * DESCRIPTION       : Consumption of energy at shop100 MPT (KTC)       
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
  
BEGIN 
      
    --TB_PO_UTILITY_MPT_KTC INSERT----------
    --Furnace#1                                               
    BEGIN
           INSERT INTO TB_PO_UTILITY_MPT_KTC
                  (MELT_NO
                  ,MEASURING_TIME
                  ,CONSUMPTION_GAS_1
                  ,CONSUMPTION_GAS_2
                  ,GAS_PRESSURE_1
                  ,TEMP_GAS_1
                  ,GAS_PRESSURE_2
                  ,TEMP_GAS_2
                  ,DIFF_PRESSURE_GAS_1
                  ,DIFF_PRESSURE_GAS_2
                  ,DIFF_PRESSURE_OOB
                  ,CONSUMPTION_OXYGEN_LV1
                  ,CONSUMPTION_OXYGEN_LV2
                  ,PRESSURE_OXYGEN
                  ,TEMP_OXYGEN
                  ,DIFF_PRESSURE_OXYGEN_LV1
                  ,DIFF_PRESSURE_OXYGEN_LV2
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT TRIM(ITEM)                                        -- MPT_GP
                  ,TO_DATE(TRIM(ITEM_1),'DD-MM-YYYY HH24:MI:SS')    -- MEASURING_TIME
                  ,TRIM(ITEM_2)                                     -- CONSUMPTION_GAS_1
                  ,TRIM(ITEM_3)                                     -- CONSUMPTION_GAS_2
                  ,TRIM(ITEM_4)                                     -- GAS_PRESSURE_1
                  ,TRIM(ITEM_5)                                     -- TEMP_GAS_1
                  ,TRIM(ITEM_6)                                     -- GAS_PRESSURE_2
                  ,TRIM(ITEM_7)                                     -- TEMP_GAS_2
                  ,TRIM(ITEM_8)                                     -- DIFF_PRESSURE_GAS_1
                  ,TRIM(ITEM_9)                                     -- DIFF_PRESSURE_GAS_2
                  ,TRIM(ITEM_10)                                     -- DIFF_PRESSURE_OOB
                  ,TRIM(ITEM_11)                                    -- CONSUMPTION_OXYGEN_LV1
                  ,TRIM(ITEM_12)                                    -- CONSUMPTION_OXYGEN_LV2
                  ,TRIM(ITEM_13)                                    -- PRESSURE_OXYGEN
                  ,TRIM(ITEM_14)                                    -- TEMP_OXYGEN
                  ,TRIM(ITEM_15)                                    -- DIFF_PRESSURE_OXYGEN_LV1
                  ,TRIM(ITEM_16)                                    -- DIFF_PRESSURE_OXYGEN_LV2
                  ,SYSDATE
                  ,'SP_TR_D2TR019'
             FROM TB_PO_LEVEL2_INTERFACE 
            WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;

              
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'B_PO_UTILITY_MPT_KTC ISERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RETURN;
    END;

EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;