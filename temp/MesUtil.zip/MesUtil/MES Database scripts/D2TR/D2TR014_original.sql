create or replace 
PROCEDURE      SP_TR_D2TR014 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR014       
 * VERSION           : V1.00                       
 * DESCRIPTION       : Mill900/680 electric consumption 
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
  
BEGIN 
      
    --TB_PO_MILL900_ETC_INFORMATION INSERT----------
                                                 
    BEGIN
           INSERT INTO TB_PO_MILL900_ETC_INFORMATION
                  (TC_ID
                  ,MEASURING_TIME
                  ,MILL900_PWR_USE_AMOUNT
                  ,MILL680_PWR_USE_AMOUNT
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT TRIM(TC_ID)                                     --TC_ID   
                  ,TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS')   --MEASURING_TIME
                  ,TRIM(ITEM_1)                                    --MILL900_ROLL_SPEED
                  ,TRIM(ITEM_2)                                    --MILL680_ROLL_SPEED
                  ,SYSDATE
                  ,'SP_TR_D2TR014'
             FROM TB_PO_LEVEL2_INTERFACE 
            WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
              
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_MILL900_ETC_INFORMATION ISERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RETURN;
    END;

EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;