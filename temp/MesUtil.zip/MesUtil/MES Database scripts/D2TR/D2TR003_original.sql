create or replace 
PROCEDURE      SP_TR_D2TR003 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR003        
 * VERSION           : V1.00                       
 * DESCRIPTION       : Temperture information of RHF     
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
  
BEGIN 
      
    --TB_PO_RHF_TEMPERATURE INSERT----------
                                                 
    BEGIN
           INSERT INTO TB_PO_RHF_TEMPERATURE
                  (MEASURING_TIME
                  ,No1_Furnace_Zone1_Temp
                  ,No1_Furnace_Zone2_Temp
                  ,No1_Furnace_Zone3_Temp
                  ,No1_Furnace_Zone4_Temp
                  ,NO1_FURNACE_ZONE5_TEMP
                  ,No2_Furnace_Zone1_Temp
                  ,No2_Furnace_Zone2_Temp
                  ,No2_Furnace_Zone3_Temp
                  ,No2_Furnace_Zone4_Temp
                  ,NO2_FURNACE_ZONE5_TEMP
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS')        -- MEASURING_TIME
                  ,TRIM(ITEM_1)                                      --No1_Furnace_Zone1_Temp
                  ,TRIM(ITEM_2)                                      --No1_Furnace_Zone2_Temp
                  ,TRIM(ITEM_3)                                      --No1_Furnace_Zone3_Temp
                  ,TRIM(ITEM_4)                                      --No1_Furnace_Zone4_Temp
                  ,TRIM(ITEM_5)                                      --No1_Furnace_Zone5_Temp
                  ,TRIM(ITEM_6)                                      --No2_Furnace_Zone1_Temp
                  ,TRIM(ITEM_7)                                      --No2_Furnace_Zone2_Temp
                  ,TRIM(ITEM_8)                                      --No2_Furnace_Zone3_Temp
                  ,TRIM(ITEM_9)                                      --No2_Furnace_Zone4_Temp
                  ,TRIM(ITEM_10)                                     --No2_Furnace_Zone5_Temp
                  ,SYSDATE
                  ,'SP_TR_D2TR003'
             FROM TB_PO_LEVEL2_INTERFACE 
            WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
              
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_RHF_TEMPERATURE ISERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RETURN;
    END;

EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;