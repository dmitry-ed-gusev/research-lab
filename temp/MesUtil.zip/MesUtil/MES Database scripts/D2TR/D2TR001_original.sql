create or replace 
PROCEDURE      SP_TR_D2TR001 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR001        
 * VERSION           : V1.00                       
 * DESCRIPTION       : Ingot entrance pass 
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);

W_MELT_NO               TB_PO_INGOT_COMM.MELT_NO%TYPE;
W_SEQ_IN_MELT           TB_PO_INGOT_COMM.SEQ_IN_MELT%TYPE;

W_PON_CNT               NUMBER;
  
BEGIN 
      
RETURN;
EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;