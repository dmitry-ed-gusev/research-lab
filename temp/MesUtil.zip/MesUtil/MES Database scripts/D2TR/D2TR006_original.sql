create or replace 
PROCEDURE      SP_TR_D2TR006 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR006        
 * VERSION           : V1.00                       
 * DESCRIPTION       : Mill900 Turning of Ingot   
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
  
BEGIN 
    RETURN;  
    --TB_PO_MILL900_OP_INFORMATION INSERT----------
                                                 
    BEGIN
           INSERT INTO TB_PO_MILL900_OP_INFORMATION
                  (MELT_NO
                  ,INGOT_NO
                  ,TC_ID
                  ,MEASURING_TIME
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT TRIM(ITEM)                                       --MELT_NO
                  ,TRIM(ITEM_1)                                    --INGOT_NO
                  ,TRIM(TC_ID)                                     --TC_ID   
                  ,TO_DATE(TRIM(ITEM_2),'DD-MM-YYYY HH24:MI:SS')   --MEASURING_TIME                                 --No2_Furnace_Zone4_Temp
                  ,SYSDATE
                  ,'SP_TR_D2TR006'
             FROM TB_PO_LEVEL2_INTERFACE 
            WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
              
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_MILL900_OP_INFORMATION ISERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RETURN;
    END;

EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;