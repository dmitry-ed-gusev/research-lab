/*
 * -----------------------------------------------------------------------------------
 * Big sql script (for Oracle 11g) for auxiliary/dictionaries and other special tables
 * for MES system.
 *
 * Warning! All names (tables/fields/indexes etc) should be written in UPPER case (its mandatory for ORACLE).
 * Tables list with short description:
 *  - TB_SM_CUSTOMER - customers list, data from Paradox DB.
 *  - TB_DICT_EXTRA_REQUIREMENTS - extra requirements for orders (paradox -> M116)
 *  - TB_DICT_EXTRA_REQS_WEIGHT - manual selection by weight from extra requirements (paradox -> M11602)
 *  - TB_DICT_EXTRA_REQS_CHEMISTRY - manual selection by chemistry from extra requirements (paradox -> M11601)
 *  - TB_SM_COUNTRY - countries dictionary
 *
 * Created: Gusev Dmitry, 2013-2014
 * -----------------------------------------------------------------------------------
*/

-- Customers dictionary table (all plant customers)
CREATE TABLE "PMES"."TB_SM_CUSTOMER" (
  "CUSTOMER_CD" NUMBER(7,0) NOT NULL ENABLE,
  "JURIDICALPHYSICAL" NUMBER(1,0),
  "OWNER_TYPE_CD" NUMBER(3,0),
  "CUSTOMER_ABRV" VARCHAR2(160 CHAR),
  "CUSTOMER_NAME" VARCHAR2(240 CHAR),
  "ZIP_NO" VARCHAR2(6 CHAR),
  "ORD_GP" VARCHAR2(1 CHAR),
  "COUNTRY_CD" NUMBER(4,0),
  "COUNTRY_NAME" VARCHAR2(90 CHAR),
  "REGION_CD" NUMBER(4,0),
  "REGION_NAME" VARCHAR2(90 CHAR),
  "CITY_CD" NUMBER(6,0),
  "CITY_NAME" VARCHAR2(90 CHAR),
  "ADDRESS_IN_CTY" VARCHAR2(120 CHAR),
  "ALL_ADDRESS" VARCHAR2(200 CHAR),
  "RLWAY_STATION_CD" VARCHAR2(10 CHAR),
  "INN" VARCHAR2(20 CHAR),
  "OKPO" VARCHAR2(11 CHAR),
  "OKONX" VARCHAR2(5 CHAR),
  "EN_COM_NAME" VARCHAR2(100 CHAR),
  "EN_CTY_ADDRESS" VARCHAR2(240 CHAR),
  "EN_ALL_ADDRESS" VARCHAR2(240 CHAR),
  "OGRN" VARCHAR2(20 CHAR),
  "KPP" VARCHAR2(20 CHAR),
  "STATUS_CD" NUMBER(1,0),
  "REG_DDTT" DATE,
  "REGISTER" VARCHAR2(15 CHAR),
  "MOD_DDTT" DATE,
  "MODIFIER" VARCHAR2(15 CHAR),
  CONSTRAINT "PK_TB_SM_CUSTOMER" PRIMARY KEY ("CUSTOMER_CD")
);
-- comments for customers table
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."CUSTOMER_CD" IS 'Customer Code';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."JURIDICALPHYSICAL" IS 'Juridical Physical';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."OWNER_TYPE_CD" IS 'Owner Type Code';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."CUSTOMER_ABRV" IS 'Customer Abbreviation';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."CUSTOMER_NAME" IS 'Customer Name';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."ZIP_NO" IS 'Zip Number';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."ORD_GP" IS 'Order Grouping';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."COUNTRY_CD" IS 'Country Code';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."COUNTRY_NAME" IS 'Country Name';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."REGION_CD" IS 'Region Code';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."REGION_NAME" IS 'Region Name';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."CITY_CD" IS 'City Code';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."CITY_NAME" IS 'City Name';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."ADDRESS_IN_CTY" IS 'Address In City';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."ALL_ADDRESS" IS 'Full Address';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."RLWAY_STATION_CD" IS 'Railway Station Code';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."INN" IS 'Inn';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."OKPO" IS 'OKPO';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."OKONX" IS 'OKONX';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."EN_COM_NAME" IS 'Company of English Name';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."EN_CTY_ADDRESS" IS 'City of English Address';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."EN_ALL_ADDRESS" IS 'Address of Full Name';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."OGRN" IS 'OGRN';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."KPP" IS 'Kpp';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."STATUS_CD" IS 'Status Code';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."REG_DDTT" IS 'Registration Date Time';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."REGISTER" IS 'Register';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."MOD_DDTT" IS 'Modification Date Time';
COMMENT ON COLUMN "PMES"."TB_SM_CUSTOMER"."MODIFIER" IS 'Modifier';
COMMENT ON TABLE "PMES"."TB_SM_CUSTOMER"  IS 'SM CUSTOMER';

/*
  * -----------------------------------------------------------------------------------
  * Table TB_DICT_CUSTOMERS_EMAILS is purposed to store customers emails info. Info will be added/editet by
  * operators (by hands).
  * Created:  20.03.2014, Gusev Dmitry
  * Modified:
  * -----------------------------------------------------------------------------------
*/
-- sequence for generating unique values (primary key)
CREATE SEQUENCE SEQ_TB_DICT_CUSTOMERS_EMAILS MINVALUE 1 START WITH 1 INCREMENT BY 1 CACHE 100;

CREATE TABLE TB_DICT_CUSTOMERS_EMAILS( -- customers email table
  ID                    NUMBER(7,0) NOT NULL ENABLE,
  CUSTOMER_CD           NUMBER(7,0) NOT NULL ENABLE,
  EMAIL                 VARCHAR2(150 CHAR) NOT NULL,
  -- use this email in auto emails sending system ('Y') or not ('N', default), emails
  -- are about finished production (goods on warehouse)
  PRODUCTION_AUTO_EMAIL VARCHAR2(1 CHAR) DEFAULT 'N' NOT NULL ENABLE,
  REG_DDTT              DATE,
  REGISTER              VARCHAR2(15 CHAR),
  MOD_DDTT              DATE,
  MODIFIER              VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_DICT_CUSTOMERS_EMAILS PRIMARY KEY (ID)
);

-- CURRENCY dictionary
CREATE TABLE TB_DICT_CURRENCY (
 CODE          NUMBER(7) NOT NULL ENABLE,
 NAME          VARCHAR2(100 CHAR),
 SHORT_NAME    VARCHAR2(50 CHAR),
 UNITS         NUMBER(7),
 PRIORITY_CODE NUMBER(5),
 CODE_OKB      NUMBER(5),
 REG_DDTT      DATE,
 REGISTER      VARCHAR2(15 CHAR),
 MOD_DDTT      DATE,
 MODIFIER      VARCHAR2(15 CHAR),
 CONSTRAINT PK_TB_DICT_CURRENCY PRIMARY KEY (CODE));

-- REGION dictionary
CREATE TABLE TB_DICT_REGION (
  COUNTRY_CODE   NUMBER(7) NOT NULL ENABLE,
 CODE           NUMBER(7) NOT NULL ENABLE,
 NAME           VARCHAR2(100 CHAR),
 CAPITAL_NAME   VARCHAR2(100 CHAR),
 USE_IN_ADDRESS NUMBER(1),
 STATUS_CODE    NUMBER(5),
 REG_DDTT       DATE,
 REGISTER       VARCHAR2(15 CHAR),
 MOD_DDTT       DATE,
 MODIFIER       VARCHAR2(15 CHAR),
 CONSTRAINT PK_TB_DICT_REGION PRIMARY KEY (COUNTRY_CODE, CODE));

-- TERRITORY dictionary
CREATE TABLE TB_DICT_TERRITORY(
 CODE          NUMBER(7) NOT NULL ENABLE,
 NAME          VARCHAR(100 CHAR),
 CODE_CSU      NUMBER(5),
 REGION_CODE   NUMBER(5),
 CUSTOMS_GROUP NUMBER(5),
 COUNTRY_GROUP NUMBER(5),
 COUNTRY_CODE  NUMBER(5),
 REG_DDTT      DATE,
 REGISTER      VARCHAR2(15 CHAR),
 MOD_DDTT      DATE,
 MODIFIER      VARCHAR2(15 CHAR),
 CONSTRAINT PK_TB_DICT_TERRITORY PRIMARY KEY (CODE));

/*
 * -----------------------------------------------------------------------------------
 * Table TB_DEPARTMENTS represents plant (Petrostal) departments, it is updated from
 * personnel DB Boss-Kadrovik (\\pst-fs\Boss\2Petrostal.accdb).
 * Created:  14.10.2013, Gusev Dmitry
 * Modified: 20.03.2014, Gusev D.
 * -----------------------------------------------------------------------------------
*/
CREATE TABLE TB_DEPARTMENTS (
  ID        number(10)    not null enable,             -- department ID (primary key)
  DEPT_CODE varchar2(30),                              -- department code, not unique
  DEPT_NAME varchar2(200) not null enable,             -- department name, not unique
  IS_ALIVE  varchar(1),                                -- is department alive ('Y') or closed ('N', null, other)
  DELETED   varchar(1)    default 'N' not null enable, -- is record deleted ('Y') or not ('N', default)
  REG_DDTT  date,                                      -- record registration date
  REGISTER  varchar2(15),                              -- record registrator name (user/process)
  MOD_DDTT  date,                                      -- record modification date
  MODIFIER  varchar2(15),                              -- record modifier name (user/process)
  CONSTRAINT PK_TB_DEPARTMENTS PRIMARY KEY (ID)
);
-- comments on table and on table columns
COMMENT ON TABLE  TB_DEPARTMENTS           IS 'Departments list (Boss-Kadrovik)';
COMMENT ON COLUMN TB_DEPARTMENTS.id        IS 'Department unique ID, primary key (from Boss-Kadrovik)';
COMMENT ON COLUMN TB_DEPARTMENTS.dept_code IS 'Department internal code';
COMMENT ON COLUMN TB_DEPARTMENTS.dept_name IS 'Department internal name';
COMMENT ON COLUMN TB_DEPARTMENTS.is_alive  IS 'Is department alive or closed sign (Y/N)';
COMMENT ON COLUMN TB_DEPARTMENTS.deleted   IS 'Record deleted sign (Y/N)';
COMMENT ON COLUMN TB_DEPARTMENTS.reg_ddtt  IS 'Registration Date Time';
COMMENT ON COLUMN TB_DEPARTMENTS.REGISTER  IS 'Register user/process';
COMMENT ON COLUMN TB_DEPARTMENTS.MOD_DDTT  IS 'Modification Date Time';
COMMENT ON COLUMN TB_DEPARTMENTS.MODIFIER  IS 'Modifier user/process';

/*
  * -----------------------------------------------------------------------------------
  * Table TB_EMPLOYEES represents plant employees with some additional info. This table is
  * updated from personnel DB Boss-Kadrovik (\\pst-fs\Boss\2Petrostal.accdb) and from
  * Active Directory data storage (login, email, etc).
  * Created:  14.10.2013, Gusev Dmitry
  * Modified: 20.03.2014, Gusev D.
  * -----------------------------------------------------------------------------------
 */
 -- employees table
 CREATE TABLE TB_EMPLOYEES (
   id             number(10)     not null enable,                        -- employee ID (primary key)
   full_name      varchar2(300)  not null enable,                        -- employee full name
   short_rus_name varchar2(100)  not null enable,                        -- short russian name (Family N.P.)
   short_eng_name varchar2(100)  not null enable,                        -- short english name (Family N.P., translit)
   birth_date     date,                                                  -- employee's date of birth
   emp_number     varchar2(6)    not null enable,                        -- employee's 'CLOCK' number
   shop_number    varchar2(6)    not null enable,                        -- employee's shop number
   login          varchar2(50),                                          -- employee's login (Active Directory)
   email          varchar2(500),                                         -- employee's email address (Active Directory)
   deptId         number         not null references TB_DEPARTMENTS(id), -- link (reference) to departments table
   is_alive       varchar(1),                                            -- is employee alive ('Y') or fired ('N', null, other)
   deleted        varchar(1)     default 'N' not null enable,            -- is record deleted ('Y') or not ('N', default)
   reg_ddtt       date,                                                  -- record registration date
   register       varchar2(15),                                          -- record registrator name (user/process)
   mod_ddtt       date,                                                  -- record modification date
   modifier       varchar2(15),                                          -- record modifier name (user/process)
   CONSTRAINT PK_TB_EMPLOYEES PRIMARY KEY (id)
 );

-- comments on table and on table columns
COMMENT ON TABLE TB_EMPLOYEES                 IS 'Employees list';
COMMENT ON COLUMN TB_EMPLOYEES.id             IS 'Employee unique ID in MES DB, primary key';
COMMENT ON COLUMN TB_EMPLOYEES.full_name      IS 'Employee russian full name';
COMMENT ON COLUMN TB_EMPLOYEES.short_rus_name IS 'Employee short russian name (Family N.P.)';
COMMENT ON COLUMN TB_EMPLOYEES.short_eng_name IS 'Employee short english name (Family N.P.)';
COMMENT ON COLUMN TB_EMPLOYEES.birth_date     IS 'Employees date of birth';
COMMENT ON COLUMN TB_EMPLOYEES.emp_number     IS 'Employees clock number';
COMMENT ON COLUMN TB_EMPLOYEES.shop_number    IS 'Employees shop number';
COMMENT ON COLUMN TB_EMPLOYEES.login          IS 'Employees login (AD)';
COMMENT ON COLUMN TB_EMPLOYEES.email          IS 'Employees email (AD)';
COMMENT ON COLUMN TB_EMPLOYEES.deptId         IS 'Departmnet ID (reference to TB_DEPARTMENTS table)';
COMMENT ON COLUMN TB_EMPLOYEES.is_alive       IS 'Is department alive or closed sign (Y/N)';
COMMENT ON COLUMN TB_EMPLOYEES.deleted        IS 'Record deleted sign (Y/N)';
COMMENT ON COLUMN TB_EMPLOYEES.reg_ddtt       IS 'Registration Date Time';
COMMENT ON COLUMN TB_EMPLOYEES.REGISTER       IS 'Register user/process';
COMMENT ON COLUMN TB_EMPLOYEES.MOD_DDTT       IS 'Modification Date Time';
COMMENT ON COLUMN TB_EMPLOYEES.MODIFIER       IS 'Modifier user/process';

/*
 * Finished items directory table (data about warehouse, shop 180). This table is used for email messaging to our
 * customers - notification about their own goods in warehouse, shop 180.
 * Created:  20.03.2014, Gusev D.
 * Modified: 12.08.2014, Gusev D.
*/
CREATE TABLE TB_FINISHED_GOODS_ITEMS(
  WORK_CARD_YEAR          NUMBER(7, 0) NOT NULL ENABLE, -- part of PK
  WORK_CARD_NUMBER        NUMBER(7, 0) NOT NULL ENABLE, -- part of PK
  WAYBILL_NUMBER          NUMBER(7, 0) NOT NULL ENABLE, -- part of PK
  ORDER_YEAR              NUMBER(7),
  ORDER_MONTH             NUMBER(7),
  ORDER_POSITION          NUMBER(7),
  SIZE_FROM               NUMBER(7),
  SIZE_TO                 NUMBER(7),
  AMOUNT_WITH_ADD         NUMBER(35, 25),
  PRICE_WITHOUT_ADD       NUMBER(35, 25),
  WAGON                   NUMBER(30, 20),
  REQUIREMENT_NUMBER      NUMBER(15),
  REQUIREMENT_NUMBER2     NUMBER(15),
  REQUIREMENT_DATE        DATE,
  REQUIREMENT_AMOUNT      NUMBER(35, 25),
  ADDITIONAL_CD1          NUMBER(10),
  ADDITIONAL_CD2          NUMBER(10),
  PAYER_CD                NUMBER(10),
  BILL_AMOUNT1            NUMBER(35, 25),
  EXCHANGE_RATE_DATE      DATE,
  CURRENCY_PRICE          NUMBER(15, 10),
  CUSTOMER_CD             NUMBER(7, 0),
  ORDER_NUMBER            VARCHAR2(100 CHAR),
  STEEL_GRADE_CD          NUMBER(5),
  SECTION_CD              NUMBER(5),
  SIZE1                   NUMBER(5),
  SIZE2                   NUMBER(5),
  WAREHOUSE_DATE          DATE,
  FROM_SHOP_SHIPMENT_DATE DATE,
  TO_SHOP_SHIPMENT_DATE   DATE,
  WEIGHT                  NUMBER(10, 4),
  RAILWAY_RATE            NUMBER(35, 25),
  SHOP_SENDER             NUMBER(6),
  STORAGE_DATE            DATE,
  RAILWAY_SHIPMENT_DATE   DATE,
  REG_DDTT                DATE,
  REGISTER                VARCHAR2(15 CHAR),
  MOD_DDTT                DATE,
  MODIFIER                VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_FINISHED_GOODS_ITEMS PRIMARY KEY(WORK_CARD_YEAR, WORK_CARD_NUMBER, WAYBILL_NUMBER)
);

/*
 * Test modes codes dictionary - for mechanical tests of steel.
 * Created: 27.03.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_DICT_TEST_MODES (
  TEST_CODE NUMBER(7) NOT NULL ENABLE,
  TEST_NAME VARCHAR2(100 CHAR),
  REG_DDTT  DATE,
  REGISTER  VARCHAR2(15 CHAR),
  MOD_DDTT  DATE,
  MODIFIER  VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_DICT_TEST_MODES PRIMARY KEY (TEST_CODE)
);

/*
 * Macro quality codes dictionary - for mechanical tests of steel.
 * Created: 27.03.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_DICT_MACRO_QUALITY (
  MACRO_CODE NUMBER(7) NOT NULL ENABLE,
  MACRO_NAME VARCHAR2(100 CHAR),
  REG_DDTT   DATE,
  REGISTER   VARCHAR2(15 CHAR),
  MOD_DDTT   DATE,
  MODIFIER   VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_DICT_MACRO_QUALITY PRIMARY KEY (MACRO_CODE)
);

/*
 * Additional mechanical tests dictionary - for additional mechanical tests of steel.
 * Created: 27.03.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_DICT_ADDITIONAL_TESTS (
  TEST_CODE          NUMBER(7) NOT NULL ENABLE,
  TEST_SHORT_NAME    VARCHAR2(100 CHAR),
  TEST_FULL_NAME     VARCHAR2(100 CHAR),
  TEST_FULL_NAME_ENG VARCHAR2(100 CHAR),
  REG_DDTT           DATE,
  REGISTER           VARCHAR2(15 CHAR),
  MOD_DDTT           DATE,
  MODIFIER           VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_DICT_ADDITIONAL_TESTS PRIMARY KEY (TEST_CODE)
);

/***
 * Railway station dictionary. Related to ARM table M120 (f:/users/new/spz/nsi).
 * Created: 02.06.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_DICT_RAILWAY_STATIONS (
  STATION_CD   NUMBER(7) NOT NULL ENABLE,
  STATION_NAME VARCHAR2(50 CHAR),
  RAILWAY_CD   NUMBER(5),
  DISTANCE_TO  NUMBER(5),
  REG_DDTT     DATE,
  REGISTER     VARCHAR2(15 CHAR),
  MOD_DDTT     DATE,
  MODIFIER     VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_DICT_RAILWAY_STATIONS PRIMARY KEY(STATION_CD)
);

/**
 * Delivery terms dictionary (used for ORDERS - positions). Paradox table M117.
 * Created: 07.06.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_DICT_DELIVERY_TERMS (
  LENGTH_CODE      NUMBER(6) NOT NULL ENABLE,
  TERM_NAME        VARCHAR2(20 CHAR),
  LENGTHFROM_FROM  NUMBER(6),
  LENGTHFROM_TO    NUMBER(6),
  LENGTHTO_FROM    NUMBER(6),
  LENGTHTO_TO      NUMBER(6),
  REG_DDTT         DATE,
  REGISTER         VARCHAR2(15 CHAR),
  MOD_DDTT         DATE,
  MODIFIER         VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_DICT_DELIVERY_TERMS PRIMARY KEY (LENGTH_CODE)
);

/**
 * Technical characteristics for ORDERS - positions. Paradox table M115.
 * Created: 09.06.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_DICT_TECH_CHARACTERS (
  PRODUCTION_CODE     NUMBER(10) NOT NULL ENABLE,
  CHARACTERISTIC_CODE NUMBER(6) NOT NULL ENABLE,
  REQUIREMENT_1       NUMBER(6),
  REQUIREMENT_2       NUMBER(6),
  REQUIREMENT_3       NUMBER(6),
  REQUIREMENT_4       NUMBER(6),
  REG_DDTT            DATE,
  REGISTER            VARCHAR2(15 CHAR),
  MOD_DDTT            DATE,
  MODIFIER            VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_DICT_TECH_CHARACTERS PRIMARY KEY (PRODUCTION_CODE, CHARACTERISTIC_CODE)
);

/**
 * Extra requrements (used mostly for orders). Paradox table M116.
 * Created: 09.06.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_DICT_EXTRA_REQUIREMENTS (
  REQ_CODE       NUMBER(6) NOT NULL ENABLE,
  REQ_NAME_FULL  VARCHAR2(100 CHAR),
  REQ_NAME_SHORT VARCHAR2(50 CHAR),
  REQ_TYPE       NUMBER(6),
  REQ_GROUP      NUMBER(6),
  REG_DDTT       DATE,
  REGISTER       VARCHAR2(15 CHAR),
  MOD_DDTT       DATE,
  MODIFIER       VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_DICT_EXTRA_REQUIREMENTS PRIMARY KEY (REQ_CODE)
);

/**
 * Derived data from table TB_DICT_EXTRA_REQUIREMENTS (M116) - manual selection for requirements by weight.
 * Paradox table M11602.
 * Created: 30.06.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_DICT_EXTRA_REQS_WEIGHT (
  REQ_CODE       NUMBER(6) NOT NULL ENABLE,
  REQ_MIN_VALUE  NUMBER(10, 5),
  REQ_MAX_VALUE  NUMBER(10, 5),
  REG_DDTT       DATE,
  REGISTER       VARCHAR2(15 CHAR),
  MOD_DDTT       DATE,
  MODIFIER       VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_DICT_EXTRA_REQS_WEIGHT PRIMARY KEY (REQ_CODE)
);

/**
 * Derived data from table TB_DICT_EXTRA_REQUIREMENTS (M116) - manual selection for requirements by chemistry.
 * Paradox table M11601.
 * Created: 30.06.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_DICT_EXTRA_REQS_CHEMISTRY (
  REQ_CODE       NUMBER(6) NOT NULL ENABLE,
  ELEMENT_CODE   NUMBER(6) NOT NULL ENABLE,
  REQ_MIN_VALUE  NUMBER(10, 5),
  REQ_MAX_VALUE  NUMBER(10, 5),
  REG_DDTT       DATE,
  REGISTER       VARCHAR2(15 CHAR),
  MOD_DDTT       DATE,
  MODIFIER       VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_DICT_EXTRA_REQS_CHEM PRIMARY KEY (REQ_CODE, ELEMENT_CODE)
);

/**
 * Production code for orders. Paradox table M112.
 * Created: 09.06.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_DICT_PRODUCTION_KIND_CODE (
  STL_GRADE_CODE_FROM  NUMBER(6) NOT NULL ENABLE,
  STL_GRADE_CODE_TO    NUMBER(6) NOT NULL ENABLE,
  SECTION_CODE         NUMBER(6) NOT NULL ENABLE,
  SIZE1                NUMBER(6) NOT NULL ENABLE,
  SIZE2                NUMBER(6),
  PRODUCTION_KIND_CODE NUMBER(10),
  ADDITIONAL_CODE1     NUMBER(6),
  ADDITIONAL_CODE2     NUMBER(6),
  REG_DDTT             DATE,
  REGISTER             VARCHAR2(15 CHAR),
  MOD_DDTT             DATE,
  MODIFIER             VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_DICT_PROD_KIND_CODE PRIMARY KEY (STL_GRADE_CODE_FROM, STL_GRADE_CODE_TO, SECTION_CODE, SIZE1)
);

/**
 * Dictionary table - countries list. Paradox table F96124.
 * Created: 2013, HAE
 * Modified: 03.07.2014, Gusev D.
*/
CREATE TABLE TB_SM_COUNTRY (
  COUNTRY_CD          NUMBER(4,0) NOT NULL ENABLE,
  COUNTRY_NAME        VARCHAR2(100 CHAR),
  COUNTRY_NAME_ENG    VARCHAR2(100 CHAR),
  COUNTRY_TWO_LETTERS VARCHAR2(10 CHAR),
  CUSTOMS_UNION_SIGN  VARCHAR2(5 CHAR),
  USE_YN              VARCHAR2(1 CHAR) DEFAULT 'Y' NOT NULL,
  REG_DDTT            DATE,
  REGISTER            VARCHAR2(15 CHAR),
  MOD_DDTT            DATE,
  MODIFIER            VARCHAR2(15 CHAR),
  CONSTRAINT "PK_TB_SM_COUNTRY" PRIMARY KEY ("COUNTRY_CD")
);
COMMENT ON TABLE  TB_SM_COUNTRY  IS 'SM Country';
COMMENT ON COLUMN TB_SM_COUNTRY.COUNTRY_CD IS 'Country Code';
COMMENT ON COLUMN TB_SM_COUNTRY.COUNTRY_NAME IS 'Country Name';
COMMENT ON COLUMN TB_SM_COUNTRY.COUNTRY_NAME_ENG IS 'Country English Name';
COMMENT ON COLUMN TB_SM_COUNTRY.COUNTRY_TWO_LETTERS IS 'Country International Two-letters Name';
COMMENT ON COLUMN TB_SM_COUNTRY.CUSTOMS_UNION_SIGN IS 'Customs union sign';
COMMENT ON COLUMN TB_SM_COUNTRY.USE_YN IS 'Use(Y/N)';
COMMENT ON COLUMN TB_SM_COUNTRY.REG_DDTT IS 'Registration Date Time';
COMMENT ON COLUMN TB_SM_COUNTRY.REGISTER IS 'Register';
COMMENT ON COLUMN TB_SM_COUNTRY.MOD_DDTT IS 'Modification Date Time';
COMMENT ON COLUMN TB_SM_COUNTRY.MODIFIER IS 'Modifier';

/**
 * Dictionary table - shipment types list. Paradox table M110.
 * Created: 31.07.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_DICT_SHIPMENT_TYPES (
  TYPE_CODE       NUMBER(4,0) NOT NULL ENABLE,
  TYPE_SHORT_NAME VARCHAR2(50 CHAR),
  TYPE_NAME       VARCHAR2(100 CHAR),
  REG_DDTT        DATE,
  REGISTER        VARCHAR2(15 CHAR),
  MOD_DDTT        DATE,
  MODIFIER        VARCHAR2(15 CHAR),
  CONSTRAINT "PK_TB_DICT_SHIPMENT_TYPES" PRIMARY KEY (TYPE_CODE)
);

/**
 * Dictionary table - orders types. Paradox table M123.
 * Created: 01.08.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_DICT_ORDER_MARKET_TYPES (
  TYPE_CODE       NUMBER(4,0) NOT NULL ENABLE,
  TYPE_SHORT_NAME VARCHAR2(50 CHAR),
  TYPE_NAME       VARCHAR2(100 CHAR),
  STRING_NUMBER   NUMBER(3),
  REG_DDTT        DATE,
  REGISTER        VARCHAR2(15 CHAR),
  MOD_DDTT        DATE,
  MODIFIER        VARCHAR2(15 CHAR),
  CONSTRAINT "PK_TB_DICT_ORDER_MARKET_TYPES" PRIMARY KEY (TYPE_CODE)
);

/**
 * Dictionary table - steel grades. Paradox table - M106.
 * Created: 2012, korean team
 * Modified: 03.09.2014, Gusev D.
*/
CREATE TABLE TB_QM_STL_GRADE (
  STLGRADE_CD    NUMBER(4,0) NOT NULL ENABLE,
  STLGRADE_NAME  VARCHAR2(50 CHAR),
  STLGRADE_CLASS VARCHAR2(1 CHAR),
  STLGRADE_GRP1  VARCHAR2(5 CHAR),
  STLGRADE_GRP2  VARCHAR2(3 CHAR),
  STLGRADE_GRP3  VARCHAR2(3 CHAR),
  USE_YN         VARCHAR2(1 CHAR),
  REG_DDTT       DATE,
  REGISTER       VARCHAR2(15 CHAR),
  MOD_DDTT       DATE,
  MODIFIER       VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_QM_STL_GRADE PRIMARY KEY (STLGRADE_CD)
);
-- indexes for TB_QM_STL_GRADE
CREATE INDEX IE1_TB_QM_STL_GRADE ON TB_QM_STL_GRADE(STLGRADE_NAME);
-- comments for TB_QM_STL_GRADE
COMMENT ON COLUMN TB_QM_STL_GRADE.STLGRADE_CD IS 'Steel Grade Code';
COMMENT ON COLUMN TB_QM_STL_GRADE.STLGRADE_NAME IS 'Steel Grade Name';
COMMENT ON COLUMN TB_QM_STL_GRADE.STLGRADE_CLASS IS 'Steel Grade Class';
COMMENT ON COLUMN TB_QM_STL_GRADE.STLGRADE_GRP1 IS 'Steel Grade Group1';
COMMENT ON COLUMN TB_QM_STL_GRADE.STLGRADE_GRP2 IS 'Steel Grade Group2';
COMMENT ON COLUMN TB_QM_STL_GRADE.STLGRADE_GRP3 IS 'Steel Grade Group3';
COMMENT ON COLUMN TB_QM_STL_GRADE.USE_YN IS 'Use(Y/N)';
COMMENT ON COLUMN TB_QM_STL_GRADE.REG_DDTT IS 'Registration Date Time';
COMMENT ON COLUMN TB_QM_STL_GRADE.REGISTER IS 'Register';
COMMENT ON COLUMN TB_QM_STL_GRADE.MOD_DDTT IS 'Modification Date Time';
COMMENT ON COLUMN TB_QM_STL_GRADE.MODIFIER IS 'Modifier';
COMMENT ON TABLE  TB_QM_STL_GRADE IS 'QM STEEL GRADE';

/**
 * Dictionary table - steel grades groups. Paradox table - F10004.
 * Created: 2012, korean team
 * Modified: 03.09.2014, Gusev D.
*/
CREATE TABLE TB_QM_STL_GRADE_GRP (
  STLGRADE_GRP_CD   VARCHAR2(5 CHAR) NOT NULL ENABLE,
  STLGRADE_GRP_NAME VARCHAR2(60 CHAR),
  FACTOR_350        NUMBER(8, 25),
  FACTOR_900        NUMBER(8, 25),
  FACTOR            NUMBER(8, 25),
  SALES_GROUP_CD    NUMBER(5),
  REG_DDTT          DATE,
  REGISTER          VARCHAR2(15 CHAR),
  MOD_DDTT          DATE,
  MODIFIER          VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_QM_STL_GRADE_GRP PRIMARY KEY (STLGRADE_GRP_CD)
);
-- comments for TB_QM_STL_GRADE_GRP
COMMENT ON COLUMN TB_QM_STL_GRADE_GRP.STLGRADE_GRP_CD IS 'Steel Grade Group Code';
COMMENT ON COLUMN TB_QM_STL_GRADE_GRP.STLGRADE_GRP_NAME IS 'Steel Grade Group Name';
COMMENT ON COLUMN TB_QM_STL_GRADE_GRP.REG_DDTT IS 'Registration Date Time';
COMMENT ON COLUMN TB_QM_STL_GRADE_GRP.REGISTER IS 'Register';
COMMENT ON COLUMN TB_QM_STL_GRADE_GRP.MOD_DDTT IS 'Modification Date Time';
COMMENT ON COLUMN TB_QM_STL_GRADE_GRP.MODIFIER IS 'Modifier';
COMMENT ON TABLE  TB_QM_STL_GRADE_GRP  IS 'QM STEEL GRADE GRP';

/**
 * Dictionary table - steel grades groups types. Paradox table - N86019.
 * Created: 2012, korean team
 * Modified: 03.09.2014, Gusev D.
*/
CREATE TABLE TB_QM_STL_GRADE_GRP_TYPE (
  GRP_TYPE_CD          NUMBER(6) NOT NULL ENABLE,
  GRP_TYPE_NAME        VARCHAR2(50 CHAR),
  GRP_TYPE_CD_COMMON   NUMBER(6),
  GRP_TYPE_NAME_COMMON VARCHAR2(50 CHAR),
  REG_DDTT             DATE,
  REGISTER             VARCHAR2(15 CHAR),
  MOD_DDTT             DATE,
  MODIFIER             VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_QM_STL_GRADE_GRP_TYPE PRIMARY KEY (GRP_TYPE_CD)
);