-- 09.08.2013
-- SQL query for removing duplicate data rows from some tables. Prepared for chemical tests table.
-- We remove duplicate rows by one fields, but its possible to add extra fields here.
DELETE FROM tb_qm_stl_analysis_ingr A WHERE ROWID >
(SELECT min(rowid) FROM tb_qm_stl_analysis_ingr B
 WHERE A.sampling_time = B.sampling_time);

-- Simple select chemical tests from table
select melt_no, test_seq, to_char(sampling_time,'dd-mm-yyyy HH:MI:SS') as dt, c_val, si_val
 from tb_qm_stl_analysis_ingr
 where melt_no = 84319;
 --order by sampling_time desc;

-- D1TR001. Remove duplicate rows from tb_po_level2_interface table - interface for hardware data.
DELETE FROM tb_po_level2_interface A WHERE ROWID >
(SELECT min(rowid) FROM tb_po_level2_interface B
   WHERE TC_ID = 'D1TR001' and A.item = B.item  and
     A.item_4 = B.item_4 and A.item_5 = B.item_5 and A.item_6 = B.item_6 and
     A.item_8 = B.item_8 and A.item_9 = B.item_9 and A.item_10 = B.item_10) and
        TC_ID = 'D1TR001';

-- D3TR010. Remove duplicates from interface table.
DELETE FROM tb_po_level2_interface A WHERE ROWID >
 (SELECT min(rowid) FROM tb_po_level2_interface B
   WHERE TC_ID = 'D3TR010' and trim(A.item) = trim(B.item))
and TC_ID = 'D3TR010';


-- 09.08.2013
-- Alter table tb_po_material_put_result - change primary key. I've executed this sequence of queries:
update tb_po_material_put_result set check_no = '000000000' where check_no is null;     -- remove null values
alter table tb_po_material_put_result modify CHECK_NO VARCHAR2(9 BYTE) not null enable; -- create constraint for column check_no
ALTER TABLE tb_po_material_put_result drop CONSTRAINT SYS_C008847; -- drop previous primary key
ALTER TABLE tb_po_material_put_result add CONSTRAINT SYS_C008847
 PRIMARY KEY (MELT_NO, PLANT_PROC_CD, RAW_MATERIAL_CD, PUT_TIME, CHECK_NO); -- add new primary key

-- 21.08.2013
-- Alter table tb_po_mill_blank
update tb_po_mill_blank set WORK_DUTY = '0' where work_duty is null;     -- remove null values
alter table tb_po_mill_blank modify WORK_DUTY VARCHAR2(1 BYTE) not null enable; -- create constraint
update tb_po_mill_blank set inspect_date = '20000101' where inspect_date is null;     -- remove null values
alter table tb_po_mill_blank modify INSPECT_DATE VARCHAR2(8 BYTE) not null enable; -- create constraint
drop index PK_TB_PO_MILL_BLANK;
ALTER TABLE tb_po_mill_blank drop CONSTRAINT SYS_C008867;
ALTER TABLE tb_po_mill_blank add CONSTRAINT SYS_C008867
 PRIMARY KEY (PROD_YY, PON, PON_SEQ, WORK_DUTY, INSPECT_DATE);

-- Rolling results (TB_PO_MILL_PON_RESULT)
select sum(nvl(input_wt, 0)) as input, 
       sum(case when length(rtrim(ltrim(nvl(PON, '')))) = 5 then nvl(prod_wt, 0) end) as pure_grade, 
       sum(case when length(rtrim(ltrim(nvl(PON, '')))) = 4 then nvl(prod_wt, 0) end) as blank, 
       count(case when length(PON) = 5 then PON end) as pure_grade_pons, 
       count(case when length(PON) = 4 then PON end) as blank_pons,
       mill_date
       from tb_po_mill_pon_result where mill_date = '20130827' and mill_gp = '9' group by mill_date order by mill_date

-- Rolling results for comparing data. MES query:
select pon as ponNumber, count(pon) as ponPositionsCount, mill_gp as millGroup, mill_date as millDate,
           prod_yy as productionYear, sum(nvl(input_wt, 0)) as inputWeight,
           sum(case when length(rtrim(ltrim(nvl(PON, '')))) = 5 then nvl(prod_wt, 0) end) as outputPureGradeWeight,
           sum(case when length(rtrim(ltrim(nvl(PON, '')))) = 4 then nvl(prod_wt, 0) end) as outputBlankWeight
           , WMSYS.wm_concat(work_duty)
    from tb_po_mill_pon_result
    --where to_date(mill_date, 'yyyyMMdd') >= to_date('20130729', 'yyyyMMdd') and to_date(mill_date, 'yyyyMMdd') <= to_date('20130801', 'yyyyMMdd')
    where mill_date >= '20130828' and mill_date <= '20130828'
    group by pon, mill_date, prod_yy, mill_gp --, work_duty
    order by ponNumber, millDate;
-- ARM query
select "Раб.карта" as ponNumber, count(WorkTicketStringNo) as ponPositionsCount, Стан as millGroup, "Дата_пр." as millDate,
       ГодРК as productionYear, sum(nvl("Вес_заг.", 0)) as inputWeight, sum(nvl("Прокат_вес_ч/с", 0)) as outputPureGradeWeight,
       sum(nvl("Прокат_вес_кв.заг.", 0)) as outputBlankWeight
, group_concat(Смена)
from F110 where millDate >= '2013-08-28' and millDate <= '2013-08-28'
group by ponNumber, millDate, productionYear, millGroup order by ponNumber, millDate

-- stored procedure for telegrams D3TR010
create or replace
PROCEDURE      SP_TR_D3TR010 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )

 IS
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR010
 * VERSION           : V1.00
 * DESCRIPTION       : Mill350 Bundle weight information
 * DEVELOPER NAME    : Lee
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       :
 */-----------------------------------------------------------------------------

W_ERR_CODE              NUMBER;
W_ERR_MSG               VARCHAR2(250);

W_WEIGHING_TIME         VARCHAR2(19);
W_BUNDLE_WT             NUMBER;

BEGIN

    INSERT INTO TB_PO_IF_PACKING_WEIGHING
           (TC_ID
           ,WEIGHING_DDTT
           ,WEIGHING_WT
           ,REG_DDTT
           ,REGISTER
           )
     SELECT 'D3TR010'
            ,TO_CHAR(TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS'),'YYYYMMDDHH24MISS')
            ,TRIM(ITEM_1)
            ,SYSDATE
            ,'SP_TR_D3TR010'
       FROM TB_PO_LEVEL2_INTERFACE
      WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
--
--     SELECT TO_CHAR(TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS'),'YYYYMMDDHH24MISS')
--            ,TRIM(ITEM_1)
--       INTO W_WEIGHING_TIME
--            ,W_BUNDLE_WT
--       FROM TB_PO_LEVEL2_INTERFACE
--      WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY
--     ;
--
--
--     SP_TR_350_BUNDL (IN_TC_ID,W_WEIGHING_TIME,W_BUNDLE_WT,W_ERR_CODE,W_ERR_MSG);
--
--     IF  W_ERR_CODE IS NOT NULL  THEN
--         RAISE_APPLICATION_ERROR(W_ERR_CODE,W_ERR_MSG);
--     END IF;
    COMMIT;
EXCEPTION
    WHEN    OTHERS  THEN
        RAISE;
END;

create or replace
PROCEDURE      SP_TR_D3TR012 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )

 IS
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR012
 * VERSION           : V1.00
 * DESCRIPTION       : MILL350 Packing weight information
 * DEVELOPER NAME    : Lee
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 14.09.2013, Gusev Dmitry
 */-----------------------------------------------------------------------------

W_ERR_CODE              NUMBER;
W_ERR_MSG               VARCHAR2(250);

W_WEIGHING_TIME         VARCHAR2(19);
W_BUNDLE_WT             NUMBER;

item_value    varchar(30); -- char value of 'item' row
date_template varchar(30); -- template for converting char -> date
BEGIN

   -- select value of 'item' column
   select trim(item) into item_value from tb_po_level2_interface where sequence_key = IN_SEQUENCE_KEY;
   -- check value and select conversion pattern
  if instr(item_value, '-') = 3 then
   date_template := 'DD-MM-YYYY HH24:MI:SS';
  elsif instr(item_value, '-') = 5 then
   data_template := 'YYYY-MM-DD HH24:MI:SS';
  else -- no variants - exception case
   raise_application_error(-20000, 'SP for D3TR012 -> Invalid date format in column ITEM!');
  end if;

     INSERT INTO TB_PO_IF_PACKING_WEIGHING
           (TC_ID
           ,WEIGHING_DDTT
           ,WEIGHING_WT
           ,REG_DDTT
           ,REGISTER
           )
     SELECT 'D3TR012'
            --,TO_CHAR(TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS'),'YYYYMMDDHH24MISS')
            ,TO_DATE(TRIM(ITEM), date_template)
            ,TRIM(ITEM_1)
            ,SYSDATE
            ,'SP_TR_D3TR012'
       FROM TB_PO_LEVEL2_INTERFACE
      WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;


EXCEPTION
    WHEN    OTHERS  THEN
        RAISE;
END;

-- change date format
update tb_po_level2_interface set item = to_char(to_date(item, 'YYYY-MM-DD HH24:MI:SS'), 'DD-MM-YYYY HH24:MI:SS')
where tc_id = 'D1TR003' and instr(item, '-') = 5
-- change date format
update tb_po_level2_interface set item_1 = to_char(to_date(item_1, 'YYYY-MM-DD HH24:MI:SS'), 'DD-MM-YYYY HH24:MI:SS')
where tc_id = 'D1TR010' and instr(item_1, '-') = 5;


-- change values [ -- ] to [----]
declare
 sqlQuery varchar(200);

begin

 for i in 1..50 loop
  sqlQuery := 'update tb_po_level2_interface set item_'||i||' = replace(item_'||i||', '' -- '', ''----'') where tc_id = ''D1TR003''
                and trim(item_'||i||') = ''--''';
  dbms_output.put_line('Executing -> '||sqlQuery);
  execute immediate sqlQuery;

 end loop;

end;

-- sql for altering tb_po_level2_interface (for telegram D1TR010, 27.09.2013, Gusev D.)
alter table tb_po_level2_interface modify item_16 varchar2(50);
alter table tb_po_level2_interface modify item_17 varchar2(50);

/**
 * Anonymous pl/sql block for add one field to all tables in PMES scheme.
*/
declare
  sqlquery varchar2(1000);
begin
  for s in (SELECT DISTINCT OWNER, OBJECT_NAME FROM DBA_OBJECTS
              WHERE OBJECT_TYPE = 'TABLE' AND OWNER = 'PMES' AND OBJECT_NAME NOT IN (T1, T2, T3)
              --AND OBJECT_NAME = 'TB_MA_BLANK_INSPECTION'
              --AND OBJECT_NAME LIKE 'TB_CM_F%'
              ORDER BY OBJECT_NAME)
    loop
      begin
        sqlquery := 'alter table '||s.object_name||' add (deleted number(1) default 0)';
        --dbms_output.put_line('-> '||sqlquery);
        execute immediate sqlquery;
        commit;
        dbms_output.put_line('processed -> '||sqlquery);

      exception
        when others then
          dbms_output.put_line('error -> '||sqlquery);
      end;
    end loop;
end;

/**
 * Anonymous pl/sql block for deleting one field.
*/
declare
  sqlquery varchar2(1000);
begin
  for s in (SELECT DISTINCT OWNER, OBJECT_NAME FROM DBA_OBJECTS
              WHERE OBJECT_TYPE = 'TABLE' AND OWNER = 'PMES'
              AND OBJECT_NAME NOT IN (
                'TB_CONTRACTS', 'TB_CONTRACTS_TYPES', 'TB_CONTRACTS_ROLES_TYPES', 'TB_CONTRACTS_SUBJECT_TYPES', 'TB_DICT_ADDITIONAL_TESTS',
                'TB_SM_CITY', 'TB_SM_COUNTRY', 'TB_DICT_CURRENCY', 'TB_SM_CUSTOMER', 'TB_FINISHED_GOODS_ITEMS', 'TB_DICT_CUSTOMERS_EMAILS',
                'TB_DICT_CUSTOMERS_EMAILS', 'TB_DICT_DELIVERY_TERMS', 'TB_DEPARTMENTS', 'TB_DEPARTMENTS_N270102', 'TB_EMPLOYEES',
                'TB_DICT_EXTRA_REQS_CHEMISTRY', 'TB_DICT_EXTRA_REQUIREMENTS', 'TB_DICT_EXTRA_REQS_WEIGHT', 'TB_DICT_MACRO_QUALITY',
                'TB_SM_MARKING', 'TB_PM_SCRAP_CODE_STD', 'TB_DICT_TEST_MODES', 'TB_DICT_PRODUCTION_KIND_CODE', 'TB_DICT_RAILWAY_STATIONS',
                'TB_DICT_REGION', 'TB_SM_SECTION', 'TB_DICT_SHIPMENT_TYPES', 'TB_QM_STANDARD', 'TB_QM_STANDARD_KIND', 'TB_QM_STL_GRADE',
                'TB_QM_STL_GRADE_GRP', 'TB_QM_STL_GRADE_GRP_TYPE', 'TB_DICT_TECH_CHARACTERS', 'TB_DICT_TERRITORY', 'TB_FINISHED_GOODS_ITEMS',
                'TB_SM_ORDCOMM', 'TB_SM_ORD_EXTRA_ITEM', 'TB_SM_ORD_INGR', 'TB_DICT_ORDER_MARKET_TYPES', 'TB_SM_ORDDTL', 'TB_ARM_RK110',
                'TB_ARM_D8001130', 'TB_ARM_N00161', 'TB_ARM_N01100', 'TB_ARM_RK110', 'TB_ARM_W161Z', 'TB_ARM_D8015009_AUDIT', 'TB_ARM_D8015009'
              )
              --AND OBJECT_NAME = 'TB_MA_BLANK_INSPECTION'
              --AND OBJECT_NAME LIKE 'TB_CM_F%'
              ORDER BY OBJECT_NAME)
    loop
      begin
        --sqlquery := 'alter table '||s.object_name||' add (deleted number(1) default 0)';
        sqlquery := 'alter table '||s.object_name||' drop column deleted';
        --dbms_output.put_line('-> '||sqlquery);
        execute immediate sqlquery;
        commit;
        dbms_output.put_line('Processed ['||s.OBJECT_NAME||'] -> '||sqlquery);

      exception
        when others then
          dbms_output.put_line('error -> '||sqlquery);
      end;
    end loop;
end;