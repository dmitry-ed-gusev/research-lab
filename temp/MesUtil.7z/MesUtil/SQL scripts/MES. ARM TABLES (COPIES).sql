/*
 * -----------------------------------------------------------------------------------
 * Table TB_DEPARTMENTS_N270102 represents old plant (Petrostal) departments structure.
 * It was used in ARM system and now is in "retire" state (but still used for contrcats etc.)
 * It is updated from Paradox DB: \\pst-fs\users\new\otep\nsi\N270102
 * Created:  01.04.2014, Gusev Dmitry
 * Modified:
 * -----------------------------------------------------------------------------------
*/
CREATE TABLE TB_DEPARTMENTS_N270102 (
  REGISTERED_SHOP_NUMBER NUMBER(10) NOT NULL ENABLE,
  REGISTERED_DEPT_NUMBER NUMBER(10) NOT NULL ENABLE,
  SHOP_NUMBER            NUMBER(10),
  DEPT_NUMBER            NUMBER(10),
  FULL_NAME              VARCHAR2(100 CHAR),
  SHORT_NAME             VARCHAR2(100 CHAR),
  REG_DDTT               DATE,
  REGISTER               VARCHAR2(15 CHAR),
  MOD_DDTT               DATE,
  MODIFIER               VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_DEPARTMENTS_N270102 PRIMARY KEY (REGISTERED_SHOP_NUMBER, REGISTERED_DEPT_NUMBER)
);
-- comments on table and on table columns
COMMENT ON TABLE  TB_DEPARTMENTS_N270102                        IS 'Departments list (old from ARMs system - N270102)';
COMMENT ON COLUMN TB_DEPARTMENTS_N270102.REGISTERED_SHOP_NUMBER IS 'Registered shop number (N270102->RegShopNo)';
COMMENT ON COLUMN TB_DEPARTMENTS_N270102.REGISTERED_DEPT_NUMBER IS 'Registered department number (N270102->RegDepNo)';
COMMENT ON COLUMN TB_DEPARTMENTS_N270102.SHOP_NUMBER            IS 'Shop number (N270102->ShopNo)';
COMMENT ON COLUMN TB_DEPARTMENTS_N270102.DEPT_NUMBER            IS 'Department number (N270102->DepNo)';
COMMENT ON COLUMN TB_DEPARTMENTS_N270102.FULL_NAME              IS 'Department full name (N270102->NameDepF)';
COMMENT ON COLUMN TB_DEPARTMENTS_N270102.SHORT_NAME             IS 'Department short name (N270102->NameDepB)';
COMMENT ON COLUMN TB_DEPARTMENTS_N270102.REG_DDTT               IS 'Registration Date Time';
COMMENT ON COLUMN TB_DEPARTMENTS_N270102.REGISTER               IS 'Register user/process';
COMMENT ON COLUMN TB_DEPARTMENTS_N270102.MOD_DDTT               IS 'Modification Date Time';
COMMENT ON COLUMN TB_DEPARTMENTS_N270102.MODIFIER               IS 'Modifier user/process';

/**
 * Copy of ARM table N01100.
 * Created:  30.05.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_ARM_N01100 (
  MELT_NO           VARCHAR2(8 CHAR) NOT NULL ENABLE,
  FURNACE_NO        NUMBER(6,0),
  MELT_DATE         DATE,
  C                 NUMBER(10, 4),
  SI                NUMBER(10, 4),
  MN                NUMBER(10, 4),
  S                 NUMBER(10, 4),
  P                 NUMBER(10, 4),
  CR                NUMBER(10, 4),
  NI                NUMBER(10, 4),
  CU                NUMBER(10, 4),
  CEQU              NUMBER(10, 4),
  BLANK_TYPE        NUMBER(6, 0),
  STL_GRADE_CD_PRED NUMBER(6, 0),
  REG_DDTT          DATE,
  REGISTER          VARCHAR2(15 CHAR),
  MOD_DDTT          DATE,
  MODIFIER          VARCHAR2(15 CHAR),
  CONSTRAINT TB_ARM_N01100_PK PRIMARY KEY (MELT_NO)
);
-- comments for table
COMMENT ON TABLE  TB_ARM_N01100                         IS 'Raw data table N01100 from ARM system.';
COMMENT ON COLUMN TB_ARM_N01100.MELT_NO                 IS 'Melt number - primary key for table. ';

/**
 * Copy of ARM table D8015009 - shop 100 data, furnace charging data.
 * Created: 10.08.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_ARM_D8015009 (
  MELT_NUMBER          NUMBER(5) NOT NULL ENABLE, -- part of PK
  SCRAP_GROUP_CD       NUMBER(5) NOT NULL ENABLE, -- part of PK
  SCRAP_CD             NUMBER(5) NOT NULL ENABLE, -- part of PK
  STEEL_GRADE_GROUP_CD NUMBER(5),
  STEEL_GRADE_CD       NUMBER(5) NOT NULL ENABLE, -- part of PK
  STRING_NUMBER        NUMBER(5) NOT NULL ENABLE, -- part of PK
  SHIFT                VARCHAR2(50 CHAR),
  CLOCK_NUMBER         NUMBER(10),
  WEIGHT               NUMBER(10, 5),
  AKOS                 NUMBER(2),
  DELETED              NUMBER(1) DEFAULT 0,
  MELT_DATE            DATE,
  REG_DDTT             DATE,
  REGISTER             VARCHAR2(15 CHAR),
  MOD_DDTT             DATE,
  MODIFIER             VARCHAR2(15 CHAR),
  CONSTRAINT "PK_TB_ARM_D8015009" PRIMARY KEY (MELT_NUMBER, SCRAP_GROUP_CD, STEEL_GRADE_CD, SCRAP_CD, STRING_NUMBER)
);

/*
 * Audit (changes record) table for TB_ARM_D8015009.
 * Created: 10.08.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_ARM_D8015009_AUDIT (
  ID                   NUMBER(10) NOT NULL ENABLE, -- PK
  ACTION               VARCHAR2(20) NOT NULL ENABLE,
  MELT_NUMBER          NUMBER(5) NOT NULL ENABLE,
  SCRAP_GROUP_CD       NUMBER(5) NOT NULL ENABLE,
  SCRAP_CD             NUMBER(5) NOT NULL ENABLE,
  STEEL_GRADE_GROUP_CD NUMBER(5),
  STEEL_GRADE_CD       NUMBER(5) NOT NULL ENABLE,
  STRING_NUMBER        NUMBER(5) NOT NULL ENABLE,
  SHIFT                VARCHAR2(50 CHAR),
  CLOCK_NUMBER         NUMBER(10),
  WEIGHT               NUMBER(10, 5),
  AKOS                 NUMBER(2),
  DELETED              NUMBER(1) DEFAULT 0,
  MELT_DATE            DATE,
  REG_DDTT             DATE,
  REGISTER             VARCHAR2(15 CHAR),
  MOD_DDTT             DATE,
  MODIFIER             VARCHAR2(15 CHAR),
  CONSTRAINT "PK_TB_ARM_D8015009_AUDIT" PRIMARY KEY (ID)
);
CREATE SEQUENCE SEQ_TB_ARM_D8015009_AUDIT MINVALUE 1 START WITH 1 INCREMENT BY 1 CACHE 100;

/**
 * Copy of ARM table D8001130 (path \\pst-fs\asu\USERS\NEW\C100\DATA1).
 * Table contains net cost data (себестоимость).
 * Created: 13.08.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_ARM_D8001130 (
  YEAR          NUMBER(5) NOT NULL ENABLE, -- part of PK
  MONTH         NUMBER(5) NOT NULL ENABLE, -- part of PK
  ATT_COMPAR    NUMBER(5) NOT NULL ENABLE, -- part of PK
  GROUP_MARK_CD NUMBER(5) NOT NULL ENABLE, -- part of PK
  CLAUSE_CD     NUMBER(5) NOT NULL ENABLE, -- part of PK
  PLAN_TONN     NUMBER(30, 20),
  PRICE_TONN    NUMBER(35, 25),
  CLAUSE_AMOUNT NUMBER(35, 25),
  REG_DDTT      DATE,
  REGISTER      VARCHAR2(15 CHAR),
  MOD_DDTT      DATE,
  MODIFIER      VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_ARM_D8001130 PRIMARY KEY (YEAR, MONTH, ATT_COMPAR, GROUP_MARK_CD, CLAUSE_CD)
);

/**
 * Copy of ARM table D8001150 (path \\pst-fs\asu\USERS\NEW\C100\DATA1).
 * Table contains net cost data (себестоимость).
 * Created: 13.08.2014, Gusev D.
 * Modified:
*/
/*
CREATE TABLE TB_ARM_D8001150 (
  YEAR          NUMBER(5) NOT NULL ENABLE, -- part of PK
  MONTH         NUMBER(5) NOT NULL ENABLE, -- part of PK
  GROUP_MARK_CD NUMBER(5) NOT NULL ENABLE, -- part of PK
  CLAUSE_CD     NUMBER(5) NOT NULL ENABLE, -- part of PK
  PRICE_TONN    NUMBER(35, 25),
  REG_DDTT      DATE,
  REGISTER      VARCHAR2(15 CHAR),
  MOD_DDTT      DATE,
  MODIFIER      VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_ARM_D8001150 PRIMARY KEY (YEAR, MONTH, GROUP_MARK_CD, CLAUSE_CD)
);
*/

/**
 * Copy of ARM table N00161 (path \\pst-fs\asu\USERS\NEW\SPZ\NSI4).
 * Table contains parameters (some data) for net cost data (себестоимость) calculation.
 * Created: 13.08.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_ARM_N00161 (
  YEAR            NUMBER(5) NOT NULL ENABLE, -- part of PK
  MONTH           NUMBER(5) NOT NULL ENABLE, -- part of PK
  CODE_PLAN       NUMBER(5) NOT NULL ENABLE, -- part of PK
  CODE_PARAMETER  NUMBER(5) NOT NULL ENABLE, -- part of PK
  NAME_PARAMETER  VARCHAR2(100 CHAR),
  ID_PARAMETER    VARCHAR2(10 CHAR),
  VALUE_PARAMETER NUMBER(30, 20),
  REG_DDTT        DATE,
  REGISTER        VARCHAR2(15 CHAR),
  MOD_DDTT        DATE,
  MODIFIER        VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_ARM_N00161 PRIMARY KEY (YEAR, MONTH, CODE_PLAN, CODE_PARAMETER)
);

/**
 * Copy of ARM table W161Z - net cost for orders (себестоимость по портфелю заказов).
 * Created: 14.08.2014, Gusev D.
 * Modified:
*/
CREATE TABLE TB_ARM_W161Z (
  YEAR_KEY                    NUMBER(7) NOT NULL ENABLE,      -- part of PK
  MONTH                       NUMBER(7) NOT NULL ENABLE,      -- part of PK
  YEAR_WORK_TICKET            NUMBER(7) NOT NULL ENABLE,      -- part of PK
  CODE_WORK_TICKET            NUMBER(30, 20) NOT NULL ENABLE, -- part of PK
  CODE_FRACHTBRIEF            NUMBER(30, 20) NOT NULL ENABLE, -- part of PK
  RECORD                      NUMBER(7) NOT NULL ENABLE,      -- part of PK
  YEAR                        NUMBER(7),
  ORDER_NUMBER                VARCHAR2(50),
  PERIOD                      NUMBER(7),
  POSITION                    NUMBER(7),
  GROUP_MRT                   NUMBER(7),
  ACCOUT_FACTOR               NUMBER(30, 20),
  WEIGHT                      NUMBER(30, 20),
  AMOUNT_FRACHTBRIEF          NUMBER(30, 20),
  PRICE                       NUMBER(30, 20),
  COST_PRICE_EXTRA_COSTS1     NUMBER(30, 20),
  COST_PRICE_REPAIR_EQUIPMENT NUMBER(30, 20),
  COST_PRICE_FACTORY_EXPENSES NUMBER(30, 20),
  REG_DDTT                    DATE,
  REGISTER                    VARCHAR2(15 CHAR),
  MOD_DDTT                    DATE,
  MODIFIER                    VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_ARM_W161Z PRIMARY KEY (YEAR_KEY, MONTH, YEAR_WORK_TICKET, CODE_WORK_TICKET, CODE_FRACHTBRIEF, RECORD)
);

/**
 * ---------------------------------------------------------------------------------------------------------------------
 * Copy of ARM table RK110 - acceptance information (информация по адъюстажу).
 * Created: 18.08.2014, Gusev D.
 * Modified:
 * ---------------------------------------------------------------------------------------------------------------------
*/
CREATE TABLE TB_ARM_RK110(
  YEAR                                   NUMBER(7) NOT NULL ENABLE, -- part of PK
  WORK_CARD_NUMBER                       NUMBER(7) NOT NULL ENABLE, -- part of PK
  WORK_CARD_POSITION                     NUMBER(7) NOT NULL ENABLE, -- part of PK
  STEEL_GRADE_CD                         NUMBER(7),
  STEEL_GRADE_NAME                       VARCHAR2(50 CHAR),
  SECTION_CD                             NUMBER(7),
  SECTION_NAME                           VARCHAR2(50 CHAR),
  SIZE1                                  NUMBER(7),
  SIZE2                                  NUMBER(7),
  LENGTH_FROM                            NUMBER(7),
  LENGTH_TO                              NUMBER(7),
  MELT_NUMBER                            VARCHAR2(20 CHAR),
  ORDER_YEAR                             NUMBER(7),
  ORDER_MONTH                            NUMBER(7),

  PROD_YYMM                              VARCHAR2(10 CHAR), -- link to PK in TB_SM_ORDDTL (orders details)
  ORD_NO                                 VARCHAR2(20 CHAR), -- link to PK in TB_SM_ORDDTL (orders details)
  ORD_POSITION                           NUMBER(7),         -- link to PK in TB_SM_ORDDTL (orders details)

  PERIOD                                 NUMBER(7),
  CONSIGNEE_CD                           NUMBER(15),
  COMPANY_NAME                           VARCHAR2(100),
  CITY                                   VARCHAR2(50),
  CUSTOMER_CD                            NUMBER(15),
  PAYER_CD                               NUMBER(15),
  WORK_CARD_DATE                         DATE,
  MILL_NUMBER                            NUMBER(5),
  ROLLING_PIECES_COUNT                   NUMBER(7),
  ROLLING_WEIGHT                         NUMBER(30, 20),
  ROLLING_BAD_PIECES                     NUMBER(7),
  ROLLING_BAD_WEIGHT                     NUMBER(30, 20),
  CORRECTION_WEIGHT                      NUMBER(30, 20),
  STAND1                                 NUMBER(7),
  TRIMMING_WEIGHT                        NUMBER(30, 20),
  STAND2                                 NUMBER(7),
  THERMAL_PROC_WEIGHT                    NUMBER(30, 20),
  STAND3                                 NUMBER(7),
  ACCEPT_DATE_AD                         DATE,
  ACCEPT_PIECES_AD                       NUMBER(7),
  ACCEPT_WEIGHT_AD                       NUMBER(30, 20),
  ACCEPT_PACKAGES_AD                     NUMBER(7),
  ACCEPT_BAD_PIECES_AD                   NUMBER(7),
  ACCEPT_BAD_WEIGHT_AD                   NUMBER(30, 20),
  ACCEPT_CUT_WEIGHT_AD                   NUMBER(30, 20),
  REMAINDER_WEIGHT                       NUMBER(30, 20),
  WORK_CARD_CLOSE_SIGN                   NUMBER(7),
  ACCEPTANCE_AD_TURN_WEIGHT              NUMBER(30, 20),
  TURN_SENT_DATE                         DATE,
  TURN_SENT_SECTION                      NUMBER(7),
  TURN_SENT_SIZE1                        NUMBER(7),
  TURN_SENT_PACKAGES                     NUMBER(7),
  TURN_SENT_PIECES                       NUMBER(7),
  TURN_SENT_WEIGHT                       NUMBER(30, 20),
  ACCEPT_AD_TURNBAD_PIECES               NUMBER(7),
  ACCEPT_AD_TURNBAD_WEIGHT               NUMBER(30, 20),
  ACCEPT_AD_TURNPROC_WEIGHT              NUMBER(30, 20),
  ACCEPT_AD_TURNBAD_TURN_PIECES          NUMBER(7),
  ACCEPT_AD_TURNBAD_TURN_WEIGHT          NUMBER(30, 20),
  ACCEPT_AD_TURNPROC_TURN_WEIGHT         NUMBER(30, 20),
  OTK_WEIGHT                             NUMBER(30, 20),
  OTK_PIECES_COUNT                       NUMBER(7),
  TURN_PROD_WASTE_PC                     NUMBER(7),
  ADD_PAIRING_PC                         NUMBER(7),
  ADD_PAIRING_TN                         NUMBER(30, 20),
  NO_ORDER_REASON_CD                     NUMBER(7),
  RAW_CD                                 NUMBER(7),
  LANDING_WEIGHT                         NUMBER(30, 20),
  CD_GROUP_CALC                          NUMBER(7),
  OTK_DATE                               DATE,
  OUT_DATE                               DATE,
  BR_DATE                                DATE,
  BASE_ORDER_NUMBER                      VARCHAR2(50),
  AD_SHIPMENT_DATE                       DATE,
  AD_PATH_OST                            NUMBER(7),
  IS_ARC                                 VARCHAR2(10),
  REG_DDTT                               DATE,
  REGISTER                               VARCHAR2(15 CHAR),
  MOD_DDTT                               DATE,
  MODIFIER                               VARCHAR2(15 CHAR),
  CONSTRAINT PK_TB_ARM_RK110 PRIMARY KEY (YEAR, WORK_CARD_NUMBER, WORK_CARD_POSITION)
);