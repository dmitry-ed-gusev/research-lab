package ru.kzgroup.domain.dto.orders.ora;

import org.apache.commons.lang3.builder.ToStringBuilder;
import ru.kzgroup.domain.dto.BaseDto;

import java.math.BigDecimal;

/**
 * ORDER INGREDIENT - domain object (extra data in MES (Oracle)). Oracle -> TB_SM_ORD_INGR.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 08.07.2014)
*/

public class OrderIngredientDtoORA extends BaseDto {

    private OrderIngredientDtoIdORA id;            // composite primary key for object
    private BigDecimal              ingredientMin; //
    private BigDecimal              ingredientMax; //

    /** Default constructor. Used by Hiber etc... */
    public OrderIngredientDtoORA() {}

    /***/
    public OrderIngredientDtoORA(OrderIngredientDtoIdORA id, BigDecimal ingredientMin, BigDecimal ingredientMax) {
        this.id            = id;
        this.ingredientMin = ingredientMin;
        this.ingredientMax = ingredientMax;
    }

    public OrderIngredientDtoIdORA getId() {
        return id;
    }

    public void setId(OrderIngredientDtoIdORA id) {
        this.id = id;
    }

    public BigDecimal getIngredientMin() {
        return ingredientMin;
    }

    public void setIngredientMin(BigDecimal ingredientMin) {
        this.ingredientMin = ingredientMin;
    }

    public BigDecimal getIngredientMax() {
        return ingredientMax;
    }

    public void setIngredientMax(BigDecimal ingredientMax) {
        this.ingredientMax = ingredientMax;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement", "QuestionableName", "ParameterNameDiffersFromOverriddenParameter"})
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OrderIngredientDtoORA that = (OrderIngredientDtoORA) o;

        if (!id.equals(that.id)) return false;
        if (ingredientMax != null ? !ingredientMax.equals(that.ingredientMax) : that.ingredientMax != null)
            return false;
        if (ingredientMin != null ? !ingredientMin.equals(that.ingredientMin) : that.ingredientMin != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id.hashCode();
        result = 31 * result + (ingredientMin != null ? ingredientMin.hashCode() : 0);
        result = 31 * result + (ingredientMax != null ? ingredientMax.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("id", id)
                .append("ingredientMin", ingredientMin)
                .append("ingredientMax", ingredientMax)
                .toString();
    }

}