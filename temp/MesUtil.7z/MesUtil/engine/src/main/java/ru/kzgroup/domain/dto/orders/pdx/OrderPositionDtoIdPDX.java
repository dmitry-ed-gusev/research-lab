package ru.kzgroup.domain.dto.orders.pdx;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Primary key for domain object - ORDER POSITION.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 07.06.2014)
*/

public class OrderPositionDtoIdPDX implements Serializable {

    private static final long serialVersionUID = 1L;

    private int    orderYear;     // D8609152->OrderYear (pos 1)
    private String orderNumber;   // D8609152->OrderNo (pos 2)
    private int    orderMonth;    // D8609152->OrderMonth (pos 3)
    private int    orderPosition; // D8609152->OrderPosition (pos 4)

    public int getOrderYear() {
        return orderYear;
    }

    public void setOrderYear(int orderYear) {
        this.orderYear = orderYear;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public int getOrderMonth() {
        return orderMonth;
    }

    public void setOrderMonth(int orderMonth) {
        this.orderMonth = orderMonth;
    }

    public int getOrderPosition() {
        return orderPosition;
    }

    public void setOrderPosition(int orderPosition) {
        this.orderPosition = orderPosition;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement", "QuestionableName"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        OrderPositionDtoIdPDX that = (OrderPositionDtoIdPDX) obj;

        if (orderMonth != that.orderMonth) return false;
        if (orderPosition != that.orderPosition) return false;
        if (orderYear != that.orderYear) return false;
        if (!orderNumber.equals(that.orderNumber)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = orderYear;
        result = 31 * result + orderNumber.hashCode();
        result = 31 * result + orderMonth;
        result = 31 * result + orderPosition;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("orderYear", orderYear)
                .append("orderNumber", orderNumber)
                .append("orderMonth", orderMonth)
                .append("orderPosition", orderPosition)
                .toString();
    }

}