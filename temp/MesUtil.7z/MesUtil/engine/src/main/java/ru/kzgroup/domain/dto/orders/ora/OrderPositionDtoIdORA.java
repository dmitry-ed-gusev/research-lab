package ru.kzgroup.domain.dto.orders.ora;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for ORDER POSITION domain object (for Oracle).
 * Warning: in MES and in ARM systems primary keys are different!
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 02.06.2014)
*/

public class OrderPositionDtoIdORA implements Serializable {

    private static final long serialVersionUID = 1L;

    private String orderYearMonth; // D8609152->OrderYear+OrderMonth, TB_SM_ORDDTL->PROD_YYMM (pos 1)
    private String orderNumber;    // D8609152->OrderNo,              TB_SM_ORDDTL->ORD_NO (pos 2)
    private int    orderPosition;  // D8609152->OrderPosition,        TB_SM_ORDDTL->ORD_POSITION (pos 3)

    public String getOrderYearMonth() {
        return orderYearMonth;
    }

    public void setOrderYearMonth(String orderYearMonth) {
        this.orderYearMonth = orderYearMonth;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public int getOrderPosition() {
        return orderPosition;
    }

    public void setOrderPosition(int orderPosition) {
        this.orderPosition = orderPosition;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement", "QuestionableName"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        OrderPositionDtoIdORA that = (OrderPositionDtoIdORA) obj;

        if (orderPosition != that.orderPosition) return false;
        if (!orderNumber.equals(that.orderNumber)) return false;
        if (!orderYearMonth.equals(that.orderYearMonth)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = orderYearMonth.hashCode();
        result = 31 * result + orderNumber.hashCode();
        result = 31 * result + orderPosition;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("orderYearMonth", orderYearMonth)
                .append("orderNumber", orderNumber)
                .append("orderPosition", orderPosition)
                .toString();
    }

}