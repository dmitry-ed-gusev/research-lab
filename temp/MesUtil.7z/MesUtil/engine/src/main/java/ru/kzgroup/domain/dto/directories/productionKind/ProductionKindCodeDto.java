package ru.kzgroup.domain.dto.directories.productionKind;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * Domain object - production kind code (for orders).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 09.06.2014)
*/

public class ProductionKindCodeDto extends BaseDto {

    private ProductionKindCodeDtoId id;
    private int                     size2;
    private int                     kindCode;
    private int                     additionalCode1;
    private int                     additionalCode2;

    public ProductionKindCodeDtoId getId() {
        return id;
    }

    public void setId(ProductionKindCodeDtoId id) {
        this.id = id;
    }

    public int getSize2() {
        return size2;
    }

    public void setSize2(int size2) {
        this.size2 = size2;
    }

    public int getKindCode() {
        return kindCode;
    }

    public void setKindCode(int kindCode) {
        this.kindCode = kindCode;
    }

    public int getAdditionalCode1() {
        return additionalCode1;
    }

    public void setAdditionalCode1(int additionalCode1) {
        this.additionalCode1 = additionalCode1;
    }

    public int getAdditionalCode2() {
        return additionalCode2;
    }

    public void setAdditionalCode2(int additionalCode2) {
        this.additionalCode2 = additionalCode2;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("size2", size2)
                .append("kindCode", kindCode)
                .append("additionalCode1", additionalCode1)
                .append("additionalCode2", additionalCode2)
                .toString();
    }

}