package ru.kzgroup.domain.dto.directories;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * MARKING - domain object. Paradox - N0502009, MES - TB_SM_MARKING.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 18.02.14)
*/

public class MarkingDto extends BaseDto {

    private String code;
    private String name;
    private String nameEnglish;

    /** Default constructor. Used for Hibernate. */
    public MarkingDto() {}

    /** Copying constructor. */
    public MarkingDto(MarkingDto marking) {
        this.code        = marking.getCode();
        this.name        = marking.getName();
        this.nameEnglish = marking.getNameEnglish();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameEnglish() {
        return nameEnglish;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("code", code)
                .append("name", name)
                .append("nameEnglish", nameEnglish)
                .toString();
    }

}