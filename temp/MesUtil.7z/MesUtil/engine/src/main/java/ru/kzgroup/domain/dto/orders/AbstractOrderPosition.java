package ru.kzgroup.domain.dto.orders;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;
import ru.kzgroup.domain.dto.directories.*;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Abstract domain object - order position.
 * Some notes for this object:
 *  - sizes: size1 -> circle diameter or square size, size2 -> other part of size, for circle - empty
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 16.06.2014)
*/

public abstract class AbstractOrderPosition extends BaseDto {

    private int             presenceSign;       // D8609152->PresenceSign, TB_SM_ORDDTL->SALE_GP
    private StandardDto     steelGradeStandard; // steel grade standard (link to D8609152 by StGrdStandardCode field)
    private StandardDto     profileStandard;    // profile standard (D8609152->ProfileStandardCode (link to N00200), TB_SM_ORDDTL -> PROFILE_STANDARD_CD)
    private SteelGradeDto   steelGradeFrom;     // D8609152->StGrdCodeA (link to M106)
    private SteelGradeDto   steelGradeTo;       // D8609152->StGrdCodeB (link to M106)
    private SectionDto      section;            // (профиль) D8609152->ProfileCode (link to M107)
    private Integer         sectionSize1From;   // D8609152->ProfileSize1From
    private Integer         sectionSize1To;     // D8609152->ProfileSize1To
    private Integer         sectionSize2From;   // D8609152->ProfileSize2From
    private Integer         sectionSize2To;     // D8609152->ProfileSize2To
    private int             lengthFrom;         // D8609152->LengthFrom
    private int             lengthTo;           // D8609152->LengthTo
    private int             millCode;           // D8609152->MillCode
    private BigDecimal      weight;             // D8609152->Weight
    private DeliveryTermDto deliveryTerm;       // D8609152->DeliveryTermsCode
    private Integer         previousMonth;      // D8609152->PrevMonth
    private BigDecimal      price;              // D8609152->Price
    private CurrencyDto     currency;           // D8609152->CurrencyCode
    private Date            planRollingDate;    // D8609152->PlanRollingDate
    private Integer         technicalCharCode;  // D8609152->TechnicalCharCode
    private Integer         productCode;        // D8609152->ProductCode
    private BigDecimal      plannedPrice;       // D8609152->PlanPrice

    public int getPresenceSign() {
        return presenceSign;
    }

    public void setPresenceSign(int presenceSign) {
        this.presenceSign = presenceSign;
    }

    public StandardDto getSteelGradeStandard() {
        return steelGradeStandard;
    }

    public void setSteelGradeStandard(StandardDto steelGradeStandard) {
        this.steelGradeStandard = steelGradeStandard;
    }

    public StandardDto getProfileStandard() {
        return profileStandard;
    }

    public void setProfileStandard(StandardDto profileStandard) {
        this.profileStandard = profileStandard;
    }

    public SteelGradeDto getSteelGradeFrom() {
        return steelGradeFrom;
    }

    public void setSteelGradeFrom(SteelGradeDto steelGradeFrom) {
        this.steelGradeFrom = steelGradeFrom;
    }

    public SteelGradeDto getSteelGradeTo() {
        return steelGradeTo;
    }

    public void setSteelGradeTo(SteelGradeDto steelGradeTo) {
        this.steelGradeTo = steelGradeTo;
    }

    public SectionDto getSection() {
        return section;
    }

    public void setSection(SectionDto section) {
        this.section = section;
    }

    public Integer getSectionSize1From() {
        return sectionSize1From;
    }

    public void setSectionSize1From(Integer sectionSize1From) {
        this.sectionSize1From = sectionSize1From;
    }

    public Integer getSectionSize1To() {
        return sectionSize1To;
    }

    public void setSectionSize1To(Integer sectionSize1To) {
        this.sectionSize1To = sectionSize1To;
    }

    public Integer getSectionSize2From() {
        return sectionSize2From;
    }

    public void setSectionSize2From(Integer sectionSize2From) {
        this.sectionSize2From = sectionSize2From;
    }

    public Integer getSectionSize2To() {
        return sectionSize2To;
    }

    public void setSectionSize2To(Integer sectionSize2To) {
        this.sectionSize2To = sectionSize2To;
    }

    public int getLengthFrom() {
        return lengthFrom;
    }

    public void setLengthFrom(int lengthFrom) {
        this.lengthFrom = lengthFrom;
    }

    public int getLengthTo() {
        return lengthTo;
    }

    public void setLengthTo(int lengthTo) {
        this.lengthTo = lengthTo;
    }

    public int getMillCode() {
        return millCode;
    }

    public void setMillCode(int millCode) {
        this.millCode = millCode;
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    public DeliveryTermDto getDeliveryTerm() {
        return deliveryTerm;
    }

    public void setDeliveryTerm(DeliveryTermDto deliveryTerm) {
        this.deliveryTerm = deliveryTerm;
    }

    public Integer getPreviousMonth() {
        return previousMonth;
    }

    public void setPreviousMonth(Integer previousMonth) {
        this.previousMonth = previousMonth;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public CurrencyDto getCurrency() {
        return currency;
    }

    public void setCurrency(CurrencyDto currency) {
        this.currency = currency;
    }

    public Date getPlanRollingDate() {
        return planRollingDate;
    }

    public void setPlanRollingDate(Date planRollingDate) {
        this.planRollingDate = planRollingDate;
    }

    public Integer getTechnicalCharCode() {
        return technicalCharCode;
    }

    public void setTechnicalCharCode(Integer technicalCharCode) {
        this.technicalCharCode = technicalCharCode;
    }

    public Integer getProductCode() {
        return productCode;
    }

    public void setProductCode(Integer productCode) {
        this.productCode = productCode;
    }

    public BigDecimal getPlannedPrice() {
        return plannedPrice;
    }

    public void setPlannedPrice(BigDecimal plannedPrice) {
        this.plannedPrice = plannedPrice;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("presenceSign", presenceSign)
                .append("steelGradeStandard", steelGradeStandard)
                .append("profileStandard", profileStandard)
                .append("steelGradeFrom", steelGradeFrom)
                .append("steelGradeTo", steelGradeTo)
                .append("section", section)
                .append("sectionSize1From", sectionSize1From)
                .append("sectionSize1To", sectionSize1To)
                .append("sectionSize2From", sectionSize2From)
                .append("sectionSize2To", sectionSize2To)
                .append("lengthFrom", lengthFrom)
                .append("lengthTo", lengthTo)
                .append("millCode", millCode)
                .append("weight", weight)
                .append("deliveryTerm", deliveryTerm)
                .append("previousMonth", previousMonth)
                .append("price", price)
                .append("currency", currency)
                .append("planRollingDate", planRollingDate)
                .append("technicalCharCode", technicalCharCode)
                .append("productCode", productCode)
                .append("plannedPrice", plannedPrice)
                .append("BaseDto", super.toString())
                .toString();
    }

}