package ru.kzgroup.domain.dto.directories;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * STANDARD - domain object. Paradox table N00200.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 17.02.14)
*/

public class StandardDto extends BaseDto {

    private int    code;
    private String kindCode;
    private String name;
    private String year;

    /** Default constructor without parameters - used by Hibernate. */
    public StandardDto() {}

    /** Copying constructor - copies state from another object field-by-field. If other object is NULL - state with default values. */
    public StandardDto(StandardDto standard) {
        if (standard != null) {
            this.code     = standard.getCode();
            this.kindCode = standard.getKindCode();
            this.name     = standard.getName();
            this.year     = standard.getYear();
        } else {
            LogFactory.getLog(StandardDto.class).warn(String.format("Copy NULL object [%s]!", StandardDto.class));
            this.code     = 0;
            this.kindCode = null;
            this.name     = null;
            this.year     = null;
        }
    }

    /** Copying constructor - deep copy, field-by-field. */


    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getKindCode() {
        return kindCode;
    }

    public void setKindCode(String kindCode) {
        this.kindCode = kindCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("code", code)
                .append("kindCode", kindCode)
                .append("name", name)
                .append("year", year)
                .toString();
    }

}