package ru.kzgroup.domain.dto.directories;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * MATERIAL (SCRAP) TYPE - domain object.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 18.02.14)
*/

public class MaterialDto extends BaseDto {

    private Integer code;
    private String  name;
    private String  typeCode;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTypeCode() {
        return typeCode;
    }

    public void setTypeCode(String typeCode) {
        this.typeCode = typeCode;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("code", code)
                .append("name", name)
                .append("typeCode", typeCode)
                .toString();
    }

}