package ru.kzgroup.domain.dto.rawTables.f110;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Domain object - raw table f110.
 * Field ID can't be null. If its null -> NPE!
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 10.05.2014)
*/

@SuppressWarnings({"ClassWithTooManyFields", "ClassWithTooManyMethods", "OverlyComplexClass"})
public class F110 implements Serializable {

    private static final long serialVersionUID = 1L;

    private F110Id     id;                       // composite primary key
    private String     meltNumber;               // "Плавка"->"VARCHAR"
    private Integer    blankSize1;               // "Разм1.заг."->"SMALLINT"
    private Integer    blankSize2;               // "Разм2.заг."->"SMALLINT"
    private Integer    size1;                    // "Разм1"->"SMALLINT"
    private Integer    size2;                    // "Разм2"->"SMALLINT"
    private Integer    lengthFrom;               // "Дл.от"->"SMALLINT"
    private Integer    lengthTo;                 // "Дл.до"->"SMALLINT"
    private Integer    downtimeCode;             // "Код_прст."->"SMALLINT"
    private Integer    steelGradeCode;           // "Код_марки"->"SMALLINT"
    private Integer    orderYear;                // "OrderYear"->"SMALLINT"
    private String     order;                    // "Заказ"->"VARCHAR"
    private Integer    subQualityPrepare;        // "SubQualityPrepare"->"SMALLINT"
    private Integer    orderMonth;               // "OrderMonth"->"SMALLINT"
    private Integer    placeCode;                // "КодМестаТО"->"SMALLINT"
    private Integer    position;                 // "Поз."->"SMALLINT"
    private Integer    millNumber;               // "Стан"->"SMALLINT"
    private Integer    blankCOde;                // "Код_заг."->"SMALLINT"
    private Integer    profileCode;              // "Код_проф."->"SMALLINT"
    private Integer    lengthCode;               // "Код_дл."->"SMALLINT"
    private Integer    blankCount;               // "К-во_заг."->"SMALLINT"
    private BigDecimal blank1Weight;             // "Вес_1_заг."->"DOUBLE"
    private BigDecimal purchasedBlankWeight;     // "Вес_заг.пок."->"DOUBLE"
    private BigDecimal blankWeight;              // "Вес_заг."->"DOUBLE"
    private Integer    rollingPiecesCount;       // "Прокат_шт."->"SMALLINT"
    private BigDecimal rollingPureGradeWeight;   // "Прокат_вес_ч/с"->"DOUBLE"
    private BigDecimal squareBlankRollingWeight; // "Прокат_вес_кв.заг."->"DOUBLE"
    private Integer    returnedPiecesCount;      // "Возврат,шт"->"SMALLINT"
    private BigDecimal returnedWeight;           // "Возврат,кг"->"DOUBLE"
    private Integer    unfinishedPiecesCount;    // "Недокат,шт"->"SMALLINT"
    private BigDecimal unfinishedWeight;         // "Недокат,кг"->"DOUBLE"
    private Integer    team;                     // "Бригада"->"SMALLINT"
    private String     teamMaster;               // "Бригадир"->"VARCHAR"
    private String     time;                     // "Время"->"VARCHAR"
    private Integer    standNumber;              // "StandNo"->"SMALLINT"
    private Integer    groupCodeCalc;            // "Код_кальк.гр."->"SMALLINT"
    private BigDecimal downtime;                 // "Время_простоя"->"DOUBLE"
    private BigDecimal weightTRM;                // "Вес_ТРМ"->"DOUBLE"
    private BigDecimal correctionWeight;         // "Вес,правка"->"DOUBLE"
    private Integer    sign;                     // "Призн.осед."->"SMALLINT"
    private BigDecimal putCalcWeight;            // "PutCalcWeight"->"DOUBLE"
    private BigDecimal validCalcWeight;          // "ValidCalcWeight"->"DOUBLE"
    private Integer    prepareOrPureGrade;       // "PrepareOrPureSort"->"SMALLINT"
    private Integer    rawMaterial;              // "RawMaterial"->"SMALLINT"
    private Integer    codeGroupCalc;            // "CodeGroupCalc"->"SMALLINT"
    private Integer    rawSize;                  // "SizeRaw"->"SMALLINT"
    private String     isArc;                    // "IsArc"->"VARCHAR"
    //ignored field -> "TKpieces"->"SMALLINT"


    public F110Id getId() {
        return id;
    }

    public void setId(F110Id id) {
        this.id = id;
    }

    public String getMeltNumber() {
        return meltNumber;
    }

    public void setMeltNumber(String meltNumber) {
        this.meltNumber = meltNumber;
    }

    public Integer getBlankSize1() {
        return blankSize1;
    }

    public void setBlankSize1(Integer blankSize1) {
        this.blankSize1 = blankSize1;
    }

    public Integer getBlankSize2() {
        return blankSize2;
    }

    public void setBlankSize2(Integer blankSize2) {
        this.blankSize2 = blankSize2;
    }

    public Integer getSize1() {
        return size1;
    }

    public void setSize1(Integer size1) {
        this.size1 = size1;
    }

    public Integer getSize2() {
        return size2;
    }

    public void setSize2(Integer size2) {
        this.size2 = size2;
    }

    public Integer getLengthFrom() {
        return lengthFrom;
    }

    public void setLengthFrom(Integer lengthFrom) {
        this.lengthFrom = lengthFrom;
    }

    public Integer getLengthTo() {
        return lengthTo;
    }

    public void setLengthTo(Integer lengthTo) {
        this.lengthTo = lengthTo;
    }

    public Integer getDowntimeCode() {
        return downtimeCode;
    }

    public void setDowntimeCode(Integer downtimeCode) {
        this.downtimeCode = downtimeCode;
    }

    public Integer getSteelGradeCode() {
        return steelGradeCode;
    }

    public void setSteelGradeCode(Integer steelGradeCode) {
        this.steelGradeCode = steelGradeCode;
    }

    public Integer getOrderYear() {
        return orderYear;
    }

    public void setOrderYear(Integer orderYear) {
        this.orderYear = orderYear;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public Integer getSubQualityPrepare() {
        return subQualityPrepare;
    }

    public void setSubQualityPrepare(Integer subQualityPrepare) {
        this.subQualityPrepare = subQualityPrepare;
    }

    public Integer getOrderMonth() {
        return orderMonth;
    }

    public void setOrderMonth(Integer orderMonth) {
        this.orderMonth = orderMonth;
    }

    public Integer getPlaceCode() {
        return placeCode;
    }

    public void setPlaceCode(Integer placeCode) {
        this.placeCode = placeCode;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public Integer getMillNumber() {
        return millNumber;
    }

    public void setMillNumber(Integer millNumber) {
        this.millNumber = millNumber;
    }

    public Integer getBlankCOde() {
        return blankCOde;
    }

    public void setBlankCOde(Integer blankCOde) {
        this.blankCOde = blankCOde;
    }

    public Integer getProfileCode() {
        return profileCode;
    }

    public void setProfileCode(Integer profileCode) {
        this.profileCode = profileCode;
    }

    public Integer getLengthCode() {
        return lengthCode;
    }

    public void setLengthCode(Integer lengthCode) {
        this.lengthCode = lengthCode;
    }

    public Integer getBlankCount() {
        return blankCount;
    }

    public void setBlankCount(Integer blankCount) {
        this.blankCount = blankCount;
    }

    public BigDecimal getBlank1Weight() {
        return blank1Weight;
    }

    public void setBlank1Weight(BigDecimal blank1Weight) {
        this.blank1Weight = blank1Weight;
    }

    public BigDecimal getPurchasedBlankWeight() {
        return purchasedBlankWeight;
    }

    public void setPurchasedBlankWeight(BigDecimal purchasedBlankWeight) {
        this.purchasedBlankWeight = purchasedBlankWeight;
    }

    public BigDecimal getBlankWeight() {
        return blankWeight;
    }

    public void setBlankWeight(BigDecimal blankWeight) {
        this.blankWeight = blankWeight;
    }

    public Integer getRollingPiecesCount() {
        return rollingPiecesCount;
    }

    public void setRollingPiecesCount(Integer rollingPiecesCount) {
        this.rollingPiecesCount = rollingPiecesCount;
    }

    public BigDecimal getRollingPureGradeWeight() {
        return rollingPureGradeWeight;
    }

    public void setRollingPureGradeWeight(BigDecimal rollingPureGradeWeight) {
        this.rollingPureGradeWeight = rollingPureGradeWeight;
    }

    public BigDecimal getSquareBlankRollingWeight() {
        return squareBlankRollingWeight;
    }

    public void setSquareBlankRollingWeight(BigDecimal squareBlankRollingWeight) {
        this.squareBlankRollingWeight = squareBlankRollingWeight;
    }

    public Integer getReturnedPiecesCount() {
        return returnedPiecesCount;
    }

    public void setReturnedPiecesCount(Integer returnedPiecesCount) {
        this.returnedPiecesCount = returnedPiecesCount;
    }

    public BigDecimal getReturnedWeight() {
        return returnedWeight;
    }

    public void setReturnedWeight(BigDecimal returnedWeight) {
        this.returnedWeight = returnedWeight;
    }

    public Integer getUnfinishedPiecesCount() {
        return unfinishedPiecesCount;
    }

    public void setUnfinishedPiecesCount(Integer unfinishedPiecesCount) {
        this.unfinishedPiecesCount = unfinishedPiecesCount;
    }

    public BigDecimal getUnfinishedWeight() {
        return unfinishedWeight;
    }

    public void setUnfinishedWeight(BigDecimal unfinishedWeight) {
        this.unfinishedWeight = unfinishedWeight;
    }

    public Integer getTeam() {
        return team;
    }

    public void setTeam(Integer team) {
        this.team = team;
    }

    public String getTeamMaster() {
        return teamMaster;
    }

    public void setTeamMaster(String teamMaster) {
        this.teamMaster = teamMaster;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Integer getStandNumber() {
        return standNumber;
    }

    public void setStandNumber(Integer standNumber) {
        this.standNumber = standNumber;
    }

    public Integer getGroupCodeCalc() {
        return groupCodeCalc;
    }

    public void setGroupCodeCalc(Integer groupCodeCalc) {
        this.groupCodeCalc = groupCodeCalc;
    }

    public BigDecimal getDowntime() {
        return downtime;
    }

    public void setDowntime(BigDecimal downtime) {
        this.downtime = downtime;
    }

    public BigDecimal getWeightTRM() {
        return weightTRM;
    }

    public void setWeightTRM(BigDecimal weightTRM) {
        this.weightTRM = weightTRM;
    }

    public BigDecimal getCorrectionWeight() {
        return correctionWeight;
    }

    public void setCorrectionWeight(BigDecimal correctionWeight) {
        this.correctionWeight = correctionWeight;
    }

    public Integer getSign() {
        return sign;
    }

    public void setSign(Integer sign) {
        this.sign = sign;
    }

    public BigDecimal getPutCalcWeight() {
        return putCalcWeight;
    }

    public void setPutCalcWeight(BigDecimal putCalcWeight) {
        this.putCalcWeight = putCalcWeight;
    }

    public BigDecimal getValidCalcWeight() {
        return validCalcWeight;
    }

    public void setValidCalcWeight(BigDecimal validCalcWeight) {
        this.validCalcWeight = validCalcWeight;
    }

    public Integer getPrepareOrPureGrade() {
        return prepareOrPureGrade;
    }

    public void setPrepareOrPureGrade(Integer prepareOrPureGrade) {
        this.prepareOrPureGrade = prepareOrPureGrade;
    }

    public Integer getRawMaterial() {
        return rawMaterial;
    }

    public void setRawMaterial(Integer rawMaterial) {
        this.rawMaterial = rawMaterial;
    }

    public Integer getCodeGroupCalc() {
        return codeGroupCalc;
    }

    public void setCodeGroupCalc(Integer codeGroupCalc) {
        this.codeGroupCalc = codeGroupCalc;
    }

    public Integer getRawSize() {
        return rawSize;
    }

    public void setRawSize(Integer rawSize) {
        this.rawSize = rawSize;
    }

    public String getIsArc() {
        return isArc;
    }

    public void setIsArc(String isArc) {
        this.isArc = isArc;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        F110 f110 = (F110) obj;

        if (blank1Weight != null ? !blank1Weight.equals(f110.blank1Weight) : f110.blank1Weight != null) return false;
        if (blankCOde != null ? !blankCOde.equals(f110.blankCOde) : f110.blankCOde != null) return false;
        if (blankCount != null ? !blankCount.equals(f110.blankCount) : f110.blankCount != null) return false;
        if (blankSize1 != null ? !blankSize1.equals(f110.blankSize1) : f110.blankSize1 != null) return false;
        if (blankSize2 != null ? !blankSize2.equals(f110.blankSize2) : f110.blankSize2 != null) return false;
        if (blankWeight != null ? !blankWeight.equals(f110.blankWeight) : f110.blankWeight != null) return false;
        if (codeGroupCalc != null ? !codeGroupCalc.equals(f110.codeGroupCalc) : f110.codeGroupCalc != null)
            return false;
        if (correctionWeight != null ? !correctionWeight.equals(f110.correctionWeight) : f110.correctionWeight != null)
            return false;
        if (downtime != null ? !downtime.equals(f110.downtime) : f110.downtime != null) return false;
        if (downtimeCode != null ? !downtimeCode.equals(f110.downtimeCode) : f110.downtimeCode != null) return false;
        if (groupCodeCalc != null ? !groupCodeCalc.equals(f110.groupCodeCalc) : f110.groupCodeCalc != null)
            return false;
        if (!id.equals(f110.id)) return false;
        if (isArc != null ? !isArc.equals(f110.isArc) : f110.isArc != null) return false;
        if (lengthCode != null ? !lengthCode.equals(f110.lengthCode) : f110.lengthCode != null) return false;
        if (lengthFrom != null ? !lengthFrom.equals(f110.lengthFrom) : f110.lengthFrom != null) return false;
        if (lengthTo != null ? !lengthTo.equals(f110.lengthTo) : f110.lengthTo != null) return false;
        if (meltNumber != null ? !meltNumber.equals(f110.meltNumber) : f110.meltNumber != null) return false;
        if (millNumber != null ? !millNumber.equals(f110.millNumber) : f110.millNumber != null) return false;
        if (order != null ? !order.equals(f110.order) : f110.order != null) return false;
        if (orderMonth != null ? !orderMonth.equals(f110.orderMonth) : f110.orderMonth != null) return false;
        if (orderYear != null ? !orderYear.equals(f110.orderYear) : f110.orderYear != null) return false;
        if (placeCode != null ? !placeCode.equals(f110.placeCode) : f110.placeCode != null) return false;
        if (position != null ? !position.equals(f110.position) : f110.position != null) return false;
        if (prepareOrPureGrade != null ? !prepareOrPureGrade.equals(f110.prepareOrPureGrade) : f110.prepareOrPureGrade != null)
            return false;
        if (profileCode != null ? !profileCode.equals(f110.profileCode) : f110.profileCode != null) return false;
        if (purchasedBlankWeight != null ? !purchasedBlankWeight.equals(f110.purchasedBlankWeight) : f110.purchasedBlankWeight != null)
            return false;
        if (putCalcWeight != null ? !putCalcWeight.equals(f110.putCalcWeight) : f110.putCalcWeight != null)
            return false;
        if (rawMaterial != null ? !rawMaterial.equals(f110.rawMaterial) : f110.rawMaterial != null) return false;
        if (rawSize != null ? !rawSize.equals(f110.rawSize) : f110.rawSize != null) return false;
        if (returnedPiecesCount != null ? !returnedPiecesCount.equals(f110.returnedPiecesCount) : f110.returnedPiecesCount != null)
            return false;
        if (returnedWeight != null ? !returnedWeight.equals(f110.returnedWeight) : f110.returnedWeight != null)
            return false;
        if (rollingPiecesCount != null ? !rollingPiecesCount.equals(f110.rollingPiecesCount) : f110.rollingPiecesCount != null)
            return false;
        if (rollingPureGradeWeight != null ? !rollingPureGradeWeight.equals(f110.rollingPureGradeWeight) : f110.rollingPureGradeWeight != null)
            return false;
        if (sign != null ? !sign.equals(f110.sign) : f110.sign != null) return false;
        if (size1 != null ? !size1.equals(f110.size1) : f110.size1 != null) return false;
        if (size2 != null ? !size2.equals(f110.size2) : f110.size2 != null) return false;
        if (squareBlankRollingWeight != null ? !squareBlankRollingWeight.equals(f110.squareBlankRollingWeight) : f110.squareBlankRollingWeight != null)
            return false;
        if (standNumber != null ? !standNumber.equals(f110.standNumber) : f110.standNumber != null) return false;
        if (steelGradeCode != null ? !steelGradeCode.equals(f110.steelGradeCode) : f110.steelGradeCode != null)
            return false;
        if (subQualityPrepare != null ? !subQualityPrepare.equals(f110.subQualityPrepare) : f110.subQualityPrepare != null)
            return false;
        if (team != null ? !team.equals(f110.team) : f110.team != null) return false;
        if (teamMaster != null ? !teamMaster.equals(f110.teamMaster) : f110.teamMaster != null) return false;
        if (time != null ? !time.equals(f110.time) : f110.time != null) return false;
        if (unfinishedPiecesCount != null ? !unfinishedPiecesCount.equals(f110.unfinishedPiecesCount) : f110.unfinishedPiecesCount != null)
            return false;
        if (unfinishedWeight != null ? !unfinishedWeight.equals(f110.unfinishedWeight) : f110.unfinishedWeight != null)
            return false;
        if (validCalcWeight != null ? !validCalcWeight.equals(f110.validCalcWeight) : f110.validCalcWeight != null)
            return false;
        if (weightTRM != null ? !weightTRM.equals(f110.weightTRM) : f110.weightTRM != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id.hashCode();
        result = 31 * result + (meltNumber != null ? meltNumber.hashCode() : 0);
        result = 31 * result + (blankSize1 != null ? blankSize1.hashCode() : 0);
        result = 31 * result + (blankSize2 != null ? blankSize2.hashCode() : 0);
        result = 31 * result + (size1 != null ? size1.hashCode() : 0);
        result = 31 * result + (size2 != null ? size2.hashCode() : 0);
        result = 31 * result + (lengthFrom != null ? lengthFrom.hashCode() : 0);
        result = 31 * result + (lengthTo != null ? lengthTo.hashCode() : 0);
        result = 31 * result + (downtimeCode != null ? downtimeCode.hashCode() : 0);
        result = 31 * result + (steelGradeCode != null ? steelGradeCode.hashCode() : 0);
        result = 31 * result + (orderYear != null ? orderYear.hashCode() : 0);
        result = 31 * result + (order != null ? order.hashCode() : 0);
        result = 31 * result + (subQualityPrepare != null ? subQualityPrepare.hashCode() : 0);
        result = 31 * result + (orderMonth != null ? orderMonth.hashCode() : 0);
        result = 31 * result + (placeCode != null ? placeCode.hashCode() : 0);
        result = 31 * result + (position != null ? position.hashCode() : 0);
        result = 31 * result + (millNumber != null ? millNumber.hashCode() : 0);
        result = 31 * result + (blankCOde != null ? blankCOde.hashCode() : 0);
        result = 31 * result + (profileCode != null ? profileCode.hashCode() : 0);
        result = 31 * result + (lengthCode != null ? lengthCode.hashCode() : 0);
        result = 31 * result + (blankCount != null ? blankCount.hashCode() : 0);
        result = 31 * result + (blank1Weight != null ? blank1Weight.hashCode() : 0);
        result = 31 * result + (purchasedBlankWeight != null ? purchasedBlankWeight.hashCode() : 0);
        result = 31 * result + (blankWeight != null ? blankWeight.hashCode() : 0);
        result = 31 * result + (rollingPiecesCount != null ? rollingPiecesCount.hashCode() : 0);
        result = 31 * result + (rollingPureGradeWeight != null ? rollingPureGradeWeight.hashCode() : 0);
        result = 31 * result + (squareBlankRollingWeight != null ? squareBlankRollingWeight.hashCode() : 0);
        result = 31 * result + (returnedPiecesCount != null ? returnedPiecesCount.hashCode() : 0);
        result = 31 * result + (returnedWeight != null ? returnedWeight.hashCode() : 0);
        result = 31 * result + (unfinishedPiecesCount != null ? unfinishedPiecesCount.hashCode() : 0);
        result = 31 * result + (unfinishedWeight != null ? unfinishedWeight.hashCode() : 0);
        result = 31 * result + (team != null ? team.hashCode() : 0);
        result = 31 * result + (teamMaster != null ? teamMaster.hashCode() : 0);
        result = 31 * result + (time != null ? time.hashCode() : 0);
        result = 31 * result + (standNumber != null ? standNumber.hashCode() : 0);
        result = 31 * result + (groupCodeCalc != null ? groupCodeCalc.hashCode() : 0);
        result = 31 * result + (downtime != null ? downtime.hashCode() : 0);
        result = 31 * result + (weightTRM != null ? weightTRM.hashCode() : 0);
        result = 31 * result + (correctionWeight != null ? correctionWeight.hashCode() : 0);
        result = 31 * result + (sign != null ? sign.hashCode() : 0);
        result = 31 * result + (putCalcWeight != null ? putCalcWeight.hashCode() : 0);
        result = 31 * result + (validCalcWeight != null ? validCalcWeight.hashCode() : 0);
        result = 31 * result + (prepareOrPureGrade != null ? prepareOrPureGrade.hashCode() : 0);
        result = 31 * result + (rawMaterial != null ? rawMaterial.hashCode() : 0);
        result = 31 * result + (codeGroupCalc != null ? codeGroupCalc.hashCode() : 0);
        result = 31 * result + (rawSize != null ? rawSize.hashCode() : 0);
        result = 31 * result + (isArc != null ? isArc.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("meltNumber", meltNumber)
                .append("blankSize1", blankSize1)
                .append("blankSize2", blankSize2)
                .append("size1", size1)
                .append("size2", size2)
                .append("lengthFrom", lengthFrom)
                .append("lengthTo", lengthTo)
                .append("downtimeCode", downtimeCode)
                .append("steelGradeCode", steelGradeCode)
                .append("orderYear", orderYear)
                .append("order", order)
                .append("subQualityPrepare", subQualityPrepare)
                .append("orderMonth", orderMonth)
                .append("placeCode", placeCode)
                .append("position", position)
                .append("millNumber", millNumber)
                .append("blankCOde", blankCOde)
                .append("profileCode", profileCode)
                .append("lengthCode", lengthCode)
                .append("blankCount", blankCount)
                .append("blank1Weight", blank1Weight)
                .append("purchasedBlankWeight", purchasedBlankWeight)
                .append("blankWeight", blankWeight)
                .append("rollingPiecesCount", rollingPiecesCount)
                .append("rollingPureGradeWeight", rollingPureGradeWeight)
                .append("squareBlankRollingWeight", squareBlankRollingWeight)
                .append("returnedPiecesCount", returnedPiecesCount)
                .append("returnedWeight", returnedWeight)
                .append("unfinishedPiecesCount", unfinishedPiecesCount)
                .append("unfinishedWeight", unfinishedWeight)
                .append("team", team)
                .append("teamMaster", teamMaster)
                .append("time", time)
                .append("standNumber", standNumber)
                .append("groupCodeCalc", groupCodeCalc)
                .append("downtime", downtime)
                .append("weightTRM", weightTRM)
                .append("correctionWeight", correctionWeight)
                .append("sign", sign)
                .append("putCalcWeight", putCalcWeight)
                .append("validCalcWeight", validCalcWeight)
                .append("prepareOrPureGrade", prepareOrPureGrade)
                .append("rawMaterial", rawMaterial)
                .append("codeGroupCalc", codeGroupCalc)
                .append("rawSize", rawSize)
                .append("isArc", isArc)
                .toString();
    }

}