package ru.kzgroup.domain.dto.orders;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;
import ru.kzgroup.domain.dto.customers.CustomerDto;
import ru.kzgroup.domain.dto.directories.ShipmentTypeDto;
import ru.kzgroup.domain.dto.directories.TerritoryDto;

import java.util.Date;

/**
 * Domain object - ORDER.
 * MES: TB_SM_ORD_COMM, ARM: D8609151.DB (f:/users/new/c160/data)
 * All paths specified in comments are relative to root [f:/users/new].
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 02.07.13)
*/

public abstract class AbstractOrder extends BaseDto {

    private Date               orderDate;          // D8609151->OrderDate, TB_SM_ORDCOMM->ORD_REG_DDTT
    private OrderMarketTypeDto orderIndex;         // D8609151->OrderIndex, TB_SM_ORDCOMM->ORD_GP
    private CustomerDto        customer;           // D8609151->CustomerCode (->N0004101 - spz/nsi3), TB_SM_ORDCOMM->CUSTOMER_CD
    private CustomerDto        consignee;          // D8609151->ConsigneeCode (->N0004101 = spz/nsi3), TB_SM_ORDCOMM->CONSIGNEE_CD
    private TerritoryDto       territory;          // D8609151->RegionCode (link to F96008 - spz/nsi), TB_SM_ORDCOMM->REGION_CD
    private String             exportOrderNumber;  // D8609151->ExpOrderNo, TB_SM_ORDCOMM->EXPORT_ORD_NO
    private Integer            contractNumber;     // D8609151->OrderContractNo (link to N27001 - otep/data), TB_SM_ORDCOMM->CONTRACT_NO
    private Integer            lotNumber;          // D8609151->LotNo, TB_SM_ORDCOMM->LOT_NO
    private String             lotName;            // D8609151->LotName, TB_SM_ORDCOMM->LOT_NAME
    // (D8609151->ShipmentType (4, 5 ,6 -> by car, other -> not by car))
    private ShipmentTypeDto    shipmentType;       // D8609151->ShipmentType, TB_SM_ORDCOMM->SHIPMENT_TYPE_CD

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public CustomerDto getCustomer() {
        return customer;
    }

    public void setCustomer(CustomerDto customer) {
        this.customer = customer;
    }

    public CustomerDto getConsignee() {
        return consignee;
    }

    public void setConsignee(CustomerDto consignee) {
        this.consignee = consignee;
    }

    public TerritoryDto getTerritory() {
        return territory;
    }

    public void setTerritory(TerritoryDto territory) {
        this.territory = territory;
    }

    public OrderMarketTypeDto getOrderIndex() {
        return orderIndex;
    }

    public void setOrderIndex(OrderMarketTypeDto orderIndex) {
        this.orderIndex = orderIndex;
    }

    public Integer getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(Integer contractNumber) {
        this.contractNumber = contractNumber;
    }

    public String getExportOrderNumber() {
        return exportOrderNumber;
    }

    public void setExportOrderNumber(String exportOrderNumber) {
        this.exportOrderNumber = exportOrderNumber;
    }

    public Integer getLotNumber() {
        return lotNumber;
    }

    public void setLotNumber(Integer lotNumber) {
        this.lotNumber = lotNumber;
    }

    public String getLotName() {
        return lotName;
    }

    public void setLotName(String lotName) {
        this.lotName = lotName;
    }

    public ShipmentTypeDto getShipmentType() {
        return shipmentType;
    }

    public void setShipmentType(ShipmentTypeDto shipmentType) {
        this.shipmentType = shipmentType;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("orderDate", orderDate)
                .append("customer", customer)
                .append("consignee", consignee)
                .append("territory", territory)
                .append("orderIndex", orderIndex)
                .append("contractNumber", contractNumber)
                .append("exportOrderNumber", exportOrderNumber)
                .append("lotNumber", lotNumber)
                .append("lotName", lotName)
                .append("shipmentType", shipmentType)
                .append("BaseDto", super.toString())
                .toString();
    }

}