package ru.kzgroup.domain.dto.directories;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * STEEL GRADE - domain object. Paradox - M106, MES - TB_QM_STL_GRADE.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 08.02.14)
*/

public class SteelGradeDto extends BaseDto {

    private int    code;       // primary key
    private String name;       //
    private String gradeClass; //
    private String group1;     //
    private String group2;     //
    private String group3;     //

    /** Default constructor (used by Hibernate etc). */
    public SteelGradeDto() {}

    /***/
    public SteelGradeDto(SteelGradeDto steelGrade) {
        if (steelGrade != null) {
            this.code       = steelGrade.getCode();
            this.name       = steelGrade.getName();
            this.gradeClass = steelGrade.getGradeClass();
            this.group1     = steelGrade.getGroup1();
            this.group2     = steelGrade.getGroup2();
            this.group3     = steelGrade.getGroup3();
        } else {
            LogFactory.getLog(SteelGradeDto.class).warn(String.format("Copy NULL object [%s]!", SteelGradeDto.class));
            this.code       = 0;
            this.name       = null;
            this.gradeClass = null;
            this.group1     = null;
            this.group2     = null;
            this.group3     = null;
        }
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGradeClass() {
        return gradeClass;
    }

    public void setGradeClass(String gradeClass) {
        this.gradeClass = gradeClass;
    }

    public String getGroup1() {
        return group1;
    }

    public void setGroup1(String group1) {
        this.group1 = group1;
    }

    public String getGroup2() {
        return group2;
    }

    public void setGroup2(String group2) {
        this.group2 = group2;
    }

    public String getGroup3() {
        return group3;
    }

    public void setGroup3(String group3) {
        this.group3 = group3;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("code", code)
                .append("name", name)
                .append("gradeClass", gradeClass)
                .append("group1", group1)
                .append("group2", group2)
                .append("group3", group3)
                .toString();
    }

}