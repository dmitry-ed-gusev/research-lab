package ru.kzgroup.domain.dto.orders.ora;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 22.08.2014)
 */

public class OrderRollingDtoId implements Serializable {

    private static final long serialVersionUID = 1L;

    private int year;             // RK110->Год
    private int workCardNumber;   // RK110->N_раб_карты
    private int workCardPosition; // RK110->WorkTicketStringNo

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getWorkCardNumber() {
        return workCardNumber;
    }

    public void setWorkCardNumber(int workCardNumber) {
        this.workCardNumber = workCardNumber;
    }

    public int getWorkCardPosition() {
        return workCardPosition;
    }

    public void setWorkCardPosition(int workCardPosition) {
        this.workCardPosition = workCardPosition;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        OrderRollingDtoId orderRollingDtoId = (OrderRollingDtoId) obj;

        if (workCardNumber != orderRollingDtoId.workCardNumber) return false;
        if (workCardPosition != orderRollingDtoId.workCardPosition) return false;
        if (year != orderRollingDtoId.year) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = year;
        result = 31 * result + workCardNumber;
        result = 31 * result + workCardPosition;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("year", year)
                .append("workCardNumber", workCardNumber)
                .append("workCardPosition", workCardPosition)
                .toString();
    }

}