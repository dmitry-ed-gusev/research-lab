package ru.kzgroup.domain.dto.directories.requirements;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

import java.util.HashSet;
import java.util.Set;

/**
 * EXTRA REQUIREMENT - domain object. Used for ORDER and other data. Paradox table - M116.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 09.06.2014)
*/

public class ExtraRequirementDto extends BaseDto {

    private int                               reqCode;                             // primary key
    private String                            reqFullName;                         //
    private String                            reqShortName;                        //
    private Integer                           reqType;                             //
    private Integer                           reqGroup;                            //
    private ExtraRequirementWeightDto         extraReqWeight;                      // link to M11602
    private Set<ExtraRequirementChemistryDto> extraReqChemistry = new HashSet<>(); // link to M11601

    public int getReqCode() {
        return reqCode;
    }

    public void setReqCode(int reqCode) {
        this.reqCode = reqCode;
    }

    public String getReqFullName() {
        return reqFullName;
    }

    public void setReqFullName(String reqFullName) {
        this.reqFullName = reqFullName;
    }

    public String getReqShortName() {
        return reqShortName;
    }

    public void setReqShortName(String reqShortName) {
        this.reqShortName = reqShortName;
    }

    public Integer getReqType() {
        return reqType;
    }

    public void setReqType(Integer reqType) {
        this.reqType = reqType;
    }

    public Integer getReqGroup() {
        return reqGroup;
    }

    public void setReqGroup(Integer reqGroup) {
        this.reqGroup = reqGroup;
    }

    public ExtraRequirementWeightDto getExtraReqWeight() {
        return extraReqWeight;
    }

    public void setExtraReqWeight(ExtraRequirementWeightDto extraReqWeight) {
        this.extraReqWeight = extraReqWeight;
    }

    public Set<ExtraRequirementChemistryDto> getExtraReqChemistry() {
        return extraReqChemistry;
    }

    public void setExtraReqChemistry(Set<ExtraRequirementChemistryDto> extraReqChemistry) {
        this.extraReqChemistry = extraReqChemistry;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("reqCode", reqCode)
                .append("reqFullName", reqFullName)
                .append("reqShortName", reqShortName)
                .append("reqType", reqType)
                .append("reqGroup", reqGroup)
                .append("extraReqWeight", extraReqWeight)
                .append("extraReqChemistry", extraReqChemistry)
                .toString();
    }

}