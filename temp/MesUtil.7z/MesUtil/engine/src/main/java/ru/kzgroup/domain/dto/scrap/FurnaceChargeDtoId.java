package ru.kzgroup.domain.dto.scrap;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for ONE FURNACE CHARGE - domain object (одна металлозавалка).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 04.08.2014)
*/

// todo: change codes to objects (fields)?
public class FurnaceChargeDtoId implements Serializable {

    private static final long serialVersionUID = 1L;

    private int meltNumber;      // D8015009->MeltNo
    private int scrapTypeCode;   // D8015009->MatKindCode
    private int scrapCode;       // D8015009->MatCode
    private int steelGradeCode;  // D8015009->MarkCode
    private int stringCode;      // D8015009->StringNo

    public int getMeltNumber() {
        return meltNumber;
    }

    public void setMeltNumber(int meltNumber) {
        this.meltNumber = meltNumber;
    }

    public int getScrapTypeCode() {
        return scrapTypeCode;
    }

    public void setScrapTypeCode(int scrapTypeCode) {
        this.scrapTypeCode = scrapTypeCode;
    }

    public int getScrapCode() {
        return scrapCode;
    }

    public void setScrapCode(int scrapCode) {
        this.scrapCode = scrapCode;
    }

    public int getSteelGradeCode() {
        return steelGradeCode;
    }

    public void setSteelGradeCode(int steelGradeCode) {
        this.steelGradeCode = steelGradeCode;
    }

    public int getStringCode() {
        return stringCode;
    }

    public void setStringCode(int stringCode) {
        this.stringCode = stringCode;
    }

    @SuppressWarnings({"MethodWithMultipleReturnPoints", "ParameterNameDiffersFromOverriddenParameter", "QuestionableName", "RedundantIfStatement"})
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FurnaceChargeDtoId that = (FurnaceChargeDtoId) o;

        if (meltNumber != that.meltNumber) return false;
        if (scrapCode != that.scrapCode) return false;
        if (scrapTypeCode != that.scrapTypeCode) return false;
        if (steelGradeCode != that.steelGradeCode) return false;
        if (stringCode != that.stringCode) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = meltNumber;
        result = 31 * result + scrapTypeCode;
        result = 31 * result + scrapCode;
        result = 31 * result + steelGradeCode;
        result = 31 * result + stringCode;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("meltNumber", meltNumber)
                .append("scrapTypeCode", scrapTypeCode)
                .append("scrapCode", scrapCode)
                .append("steelGradeCode", steelGradeCode)
                .append("stringCode", stringCode)
                .toString();
    }

}