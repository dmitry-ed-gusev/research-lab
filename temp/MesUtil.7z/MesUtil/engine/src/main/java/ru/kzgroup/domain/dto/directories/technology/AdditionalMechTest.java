package ru.kzgroup.domain.dto.directories.technology;

import org.apache.commons.lang3.builder.ToStringBuilder;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * One additional mech test for steel - domain object.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 27.03.2014)
*/

public class AdditionalMechTest extends BaseDto {

    private int    code;
    private String shortName;
    private String fullName;
    private String fullNameEng;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getFullNameEng() {
        return fullNameEng;
    }

    public void setFullNameEng(String fullnameEng) {
        this.fullNameEng = fullnameEng;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("code", code)
                .append("shortName", shortName)
                .append("fullName", fullName)
                .append("fullnameEng", fullNameEng)
                .toString();
    }

}