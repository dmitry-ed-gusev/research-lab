package ru.kzgroup.domain.dto.orders;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.domain.dto.directories.MarkingDto;
import ru.kzgroup.domain.dto.directories.characteristics.TechCharacteristicDto;
import ru.kzgroup.domain.dto.directories.requirements.ExtraRequirementDto;
import ru.kzgroup.domain.dto.orders.pdx.OrderD0502002PDX;
import ru.kzgroup.domain.dto.orders.pdx.OrderD0502003PDX;
import ru.kzgroup.domain.dto.orders.pdx.OrderDtoPDX;
import ru.kzgroup.domain.dto.orders.pdx.OrderPositionDtoPDX;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Helper class, it contains some utility methods.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 26.06.2014)
*/

public final class OrdersHelper {

    /** Date format for ORDER object. */
    public static final SimpleDateFormat ORDER_SDF = new SimpleDateFormat("yyyyMMdd");

    //private static final Log log = LogFactory.getLog(OrdersHelper.class);

    private OrdersHelper() {} /** we can't instantiate utility class */

    /**
     * Returns extra requirements map generated from OrderPositionDtoPDX object. Method never returns null.
    */
    public static Map<Integer, ExtraRequirementDto> getRequirementsMap(OrderPositionDtoPDX pdxPosition) {
        //log.debug("OrdersHelper.getRequirementsMap() working.");

        Map<Integer, ExtraRequirementDto> requirements = new HashMap<>();

        if (pdxPosition != null) {
            // extra requirement A
            ExtraRequirementDto requirementA = pdxPosition.getRequirementA();
            if (requirementA != null) {
                requirements.put(requirementA.getReqCode(), requirementA);
            }
            // extra requirement B
            ExtraRequirementDto requirementB = pdxPosition.getRequirementB();
            if (requirementB != null) {
                requirements.put(requirementB.getReqCode(), requirementB);
            }
            // extra requirement C
            ExtraRequirementDto requirementC = pdxPosition.getRequirementC();
            if (requirementC != null) {
                requirements.put(requirementC.getReqCode(), requirementC);
            }
            // extra requirement D
            ExtraRequirementDto requirementD = pdxPosition.getRequirementD();
            if (requirementD != null) {
                requirements.put(requirementD.getReqCode(), requirementD);
            }
            // tech characteristic
            TechCharacteristicDto techChar = pdxPosition.getTechCharacteristic();
            if (techChar != null) {
                // extra requirement 1
                ExtraRequirementDto requirement1 = techChar.getRequirement1();
                if (requirement1 != null) {
                    requirements.put(requirement1.getReqCode(), requirement1);
                }
                // extra requirement 2
                ExtraRequirementDto requirement2 = techChar.getRequirement2();
                if (requirement2 != null) {
                    requirements.put(requirement2.getReqCode(), requirement2);
                }
                // extra requirement 3
                ExtraRequirementDto requirement3 = techChar.getRequirement3();
                if (requirement3 != null) {
                    requirements.put(requirement3.getReqCode(), requirement3);
                }
                // extra requirement 4
                ExtraRequirementDto requirement4 = techChar.getRequirement4();
                if (requirement4 != null) {
                    requirements.put(requirement4.getReqCode(), requirement4);
                }
            }
        }

        return requirements;
    }

    /**
     * This calculation logic is from Arm86_09 - see source.
    */
    public static Pair<BigDecimal, BigDecimal> getExtraRequirementWeight(OrderPositionDtoPDX pdxPosition) {
        //log.debug("OrdersHelper.getExtraRequirementWeight() working.");

        Pair<BigDecimal, BigDecimal> result = null;

        if (pdxPosition != null) {
            // requirement A
            ExtraRequirementDto requirementA = pdxPosition.getRequirementA();
            if (requirementA != null && requirementA.getExtraReqWeight() != null) {
                result = new ImmutablePair<>(requirementA.getExtraReqWeight().getMinValue(), requirementA.getExtraReqWeight().getMaxValue());
            }
            // requirement B
            ExtraRequirementDto requirementB = pdxPosition.getRequirementB();
            if (requirementB != null && requirementB.getExtraReqWeight() != null) {
                result = new ImmutablePair<>(requirementB.getExtraReqWeight().getMinValue(), requirementB.getExtraReqWeight().getMaxValue());
            }
            // requirement C
            ExtraRequirementDto requirementC = pdxPosition.getRequirementC();
            if (requirementC != null && requirementC.getExtraReqWeight() != null) {
                result = new ImmutablePair<>(requirementC.getExtraReqWeight().getMinValue(), requirementC.getExtraReqWeight().getMaxValue());
            }
            // requirement D
            ExtraRequirementDto requirementD = pdxPosition.getRequirementD();
            if (requirementD != null && requirementD.getExtraReqWeight() != null) {
                result = new ImmutablePair<>(requirementD.getExtraReqWeight().getMinValue(), requirementD.getExtraReqWeight().getMaxValue());
            }
        }

        return result;
    }

    /**
     * This data stored in table TB_SM_ORDER_WEIGHT_TOLERANCE (MES, Oracle).
     * How this table is populated/updated with data - unknown.
     * Method working algorithm - see stored procedure SP_SM_100_ORDIF.
    */
    // todo: refactor this method to enumeration class
    public static Pair<Integer, Integer> getDeliveryTolerance(int orderIndex, int customerCountryCode, BigDecimal positionWeight) {
        //log.debug("OrdersHelper.getDeliveryTolerance() working.");

        Pair<Integer, Integer> result = null;

        // static data
        Pair<BigDecimal, BigDecimal> group1 = new ImmutablePair<>(new BigDecimal(1), new BigDecimal(10000));         // groups -> B, C
        Pair<BigDecimal, BigDecimal> group2 = new ImmutablePair<>(new BigDecimal(1), new BigDecimal(20000));         // groups -> E
        Pair<BigDecimal, BigDecimal> group3 = new ImmutablePair<>(new BigDecimal(10000), new BigDecimal(999999000)); // groups -> B, C
        Pair<BigDecimal, BigDecimal> group4 = new ImmutablePair<>(new BigDecimal(20000), new BigDecimal(60000));     // groups -> E
        Pair<BigDecimal, BigDecimal> group5 = new ImmutablePair<>(new BigDecimal(60000), new BigDecimal(99999990));  // groups -> E
        // calculating order group symbol
        String orderGroup;
        if (orderIndex == 1) {
            orderGroup = "E";
        } else if (customerCountryCode == 112) {
            orderGroup = "B";
        } else {
            orderGroup = "C";
        }

        // calculating tolerance
        switch (orderGroup) {
            case "B": case "C": // cases are equals
                if (positionWeight.compareTo(group1.getLeft()) >= 0 && positionWeight.compareTo(group1.getRight()) < 0) {
                    result = new ImmutablePair<>(15, 15);
                } else if (positionWeight.compareTo(group3.getLeft()) >= 0 && positionWeight.compareTo(group3.getRight()) < 0) {
                    result = new ImmutablePair<>(5, 5);
                }
                break;
            case "E" :
                if (positionWeight.compareTo(group2.getLeft()) >= 0 && positionWeight.compareTo(group2.getRight()) < 0) {
                    result = new ImmutablePair<>(15, 15);
                } else if (positionWeight.compareTo(group4.getLeft()) >= 0 && positionWeight.compareTo(group4.getRight()) < 0) {
                    result = new ImmutablePair<>(10, 10);
                } else if (positionWeight.compareTo(group5.getLeft()) >= 0 && positionWeight.compareTo(group5.getRight()) < 0) {
                    result = new ImmutablePair<>(5, 5);
                }
                break;
        }

        return result;
    }

    /** Returns simple MAP[POSITION, MARKING] with marking information for current ORDER (PDX). */
    public static Map<Integer, MarkingDto> getMarkingMap(OrderDtoPDX pdxOrder) {
        Map<Integer, MarkingDto> result = new HashMap<>();

        if (pdxOrder != null) {
            Set<OrderD0502002PDX> notes = pdxOrder.getNotesForOrder(); // notes should be empty or contains only one object!
            if (notes != null && !notes.isEmpty()) {
                if (notes.size() > 1) {
                    LogFactory.getLog(OrdersHelper.class).warn(String.format("More than 1 note for order [%s]!", pdxOrder.getId()));
                }
                OrderD0502002PDX note = notes.iterator().next(); // one (only) note for current order
                if (note != null) {
                    Set<OrderD0502003PDX> d0502003Set = note.getD0502003Set();
                    if (d0502003Set != null && !d0502003Set.isEmpty()) {
                        for (OrderD0502003PDX d0502003PDX : d0502003Set) {
                            result.put(d0502003PDX.getId().getPositionCode(), d0502003PDX.getMarking());
                        }
                    }
                }
            }
        }

        return result;
    }

}