package ru.kzgroup.domain.dto.scrap;

import org.apache.commons.lang3.builder.ToStringBuilder;
import ru.kzgroup.domain.dto.directories.MaterialDto;
import ru.kzgroup.domain.dto.directories.SteelGradeDto;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * ONE FURNACE CHARGE - domain object (одна металлозавалка). Concrete class.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 04.08.2014)
*/

// todo: merge in one class with AbstractFurnaceChargeDto
public class FurnaceChargeDto extends AbstractFurnaceChargeDto{

    private FurnaceChargeDtoId         id;
    private int                        deleted;                         // field for processing deleted records. Don't include it into equals() and hashCode()!
    private MaterialDto                material;                        // system, don't include into equals() and hashCode()
    private SteelGradeDto              steelGrade;                      // system, don't include into equals() and hashCode()
    private Set<FurnaceChargeAuditDto> changes = new LinkedHashSet<>(); // system, changes for current record

    public FurnaceChargeDtoId getId() {
        return id;
    }

    public void setId(FurnaceChargeDtoId id) {
        this.id = id;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    public MaterialDto getMaterial() {
        return material;
    }

    public void setMaterial(MaterialDto material) {
        this.material = material;
    }

    public SteelGradeDto getSteelGrade() {
        return steelGrade;
    }

    public void setSteelGrade(SteelGradeDto steelGrade) {
        this.steelGrade = steelGrade;
    }

    public Set<FurnaceChargeAuditDto> getChanges() {
        return changes;
    }

    public void setChanges(Set<FurnaceChargeAuditDto> changes) {
        this.changes = changes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        FurnaceChargeDto that = (FurnaceChargeDto) o;

        if (!id.equals(that.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("id", id)
                .append("deleted", deleted)
                .append("material", material)
                .append("steelGrade", steelGrade)
                .append("changes", changes)
                .appendSuper(super.toString())
                .toString();
    }

}