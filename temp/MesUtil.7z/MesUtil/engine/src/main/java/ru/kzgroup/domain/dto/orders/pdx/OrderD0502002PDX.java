package ru.kzgroup.domain.dto.orders.pdx;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

import java.util.HashSet;
import java.util.Set;

/**
 * Service domain object - NOTE for ORDER, and some info - marking.
 * ARM: D0502002, MES: fields in table TB_SM_ORDCOMM.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 05.06.2014)
*/

public class OrderD0502002PDX extends BaseDto {

    private OrderD0502002IdPDX    id;
    private int                   orderYear;
    private int                   orderMonth;
    private String                orderNumber;
    private String                notes;
    private String                notes1;
    private Set<OrderD0502003PDX> d0502003Set = new HashSet<>(); // link to D0502003, is empty or contains multiple elements

    public OrderD0502002IdPDX getId() {
        return id;
    }

    public void setId(OrderD0502002IdPDX id) {
        this.id = id;
    }

    public int getOrderYear() {
        return orderYear;
    }

    public void setOrderYear(int orderYear) {
        this.orderYear = orderYear;
    }

    public int getOrderMonth() {
        return orderMonth;
    }

    public void setOrderMonth(int orderMonth) {
        this.orderMonth = orderMonth;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getNotes1() {
        return notes1;
    }

    public void setNotes1(String notes1) {
        this.notes1 = notes1;
    }

    public Set<OrderD0502003PDX> getD0502003Set() {
        return d0502003Set;
    }

    public void setD0502003Set(Set<OrderD0502003PDX> d0502003) {
        this.d0502003Set = d0502003;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("orderYear", orderYear)
                .append("orderMonth", orderMonth)
                .append("orderNumber", orderNumber)
                .append("notes", notes)
                .append("notes1", notes1)
                .append("d0502003", d0502003Set)
                .toString();
    }

}