package ru.kzgroup.domain.dto.laboratory;

import org.apache.commons.lang3.StringUtils;

/**
 * CHEMICAL ELEMENTS enumeration object. Paradox table /spz/nsi/M106elem.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 08.07.2014)
*/

public enum Element {

    C (1,  "Углерод"),
    SI(2,  "Кремний"),
    MN(3,  "Марганец"),
    P (4,  "Фосфор"),
    S (5,  "Сера"),
    CR(6,  "Хром"),
    NI(7,  "Никель"),
    CU(8,  "Медь"),
    MO(9,  "Молибден"),
    W (10, "Вольфрам"),
    V (11, "Ванадий"),
    TI(12, "Титан"),
    AL(13, "Алюминий"),
    B (14, "Бор"),
    NB(15, "Ниобий"),
    PB(16, "Свинец"),
    N (17, "Азот"),
    SN(18, "Олово"),
    AS(19, "Мышьяк");

    /***/
    private Element(int code, String fullName) {
        this.code     = code;
        this.fullName = fullName;
    }

    private int    code;
    private String fullName;

    public int getCode() {
        return code;
    }

    public String getFullName() {
        return fullName;
    }

    /** Returns element code by english (latin) name (for example Cu, Cr, Ni, N etc...). If not found returns 0 (zero). */
    public static int getCodeByName(String latinName) {
        int code = 0;
        if (!StringUtils.isBlank(latinName)) {
            Element[] elements = Element.values();
            int     counter = 0;
            boolean isFound = false;
            while (counter < elements.length && !isFound) {
                if (elements[counter].name().equalsIgnoreCase(StringUtils.trimToEmpty(latinName).toUpperCase())) {
                    code = elements[counter].getCode();
                    isFound = true;
                }
                counter++;
            }
        }
        return code;
    }

    /***/
    public static String getLatinNameByCode(int code) {
        String latinName = null;
        if (code > 0) {
            Element[] elements = Element.values();
            int     counter = 0;
            boolean isFound = false;
            while (counter < elements.length && !isFound) {
                if (elements[counter].getCode() == code) {
                    latinName = elements[counter].name().substring(0, 1) + elements[counter].name().substring(1).toLowerCase();
                    isFound = true;
                }
                counter++;
            }
        }
        return latinName;
    }

}