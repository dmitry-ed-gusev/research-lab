package ru.kzgroup.domain.dao.rolling;

import gusev.dmitry.jtils.utils.CommonUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;
import ru.kzgroup.domain.dto.rolling.RollingResult;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static ru.kzgroup.MesUtilDefaults.MILL900;

/**
 * Dao
 * @deprecated don't use
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 26.08.13)
*/

public class RollingResultDao {

    private Log log = LogFactory.getLog(RollingResultDao.class);

    private static final SimpleDateFormat PDX_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    private static final SimpleDateFormat ORA_DATE_FORMAT = new SimpleDateFormat("yyyyMMdd");
    private static final String           PDX_DB          = "//pst-fs/asu/USERS/new/spz/DATA";
    //private static final OraDbConfig      ORA_DB          = new OraDbConfig("172.16.0.81:1521", "PMES", "pmes", "pmes1234");
    private static final String           MES_REPORT      = "MES";
    private static final String           ARM_REPORT      = "ARM";

    /***/
    @SuppressWarnings({"JDBCResourceOpenedButNotSafelyClosed", "CallToDriverManagerGetConnection"})
    public RollingResult getARMRollingResult(Date date, String millNumber) throws SQLException, ParseException {
        log.debug("RollingResultDao.getRollingResult() working.");
        RollingResult result;

        Connection pdxConnection = null;
        try {
            pdxConnection = DriverManager.getConnection("jdbc:paradox:///" + PDX_DB);
            // Paradox table columns
            String dateField              = "\"Дата_пр.\"";
            String inputBlankWeightField  = "\"Вес_заг.\"";
            String pureGradeWeightField   = "\"Прокат_вес_ч/с\"";
            String resultBlankWeightField = "\"Прокат_вес_кв.заг.\"";
            // converting data
            String rollingDateForQuery    = PDX_DATE_FORMAT.format(date);
            String getDataFromPdx = "select sum(nvl(%1$s, 0)) as input, sum(nvl(%2$s, 0)) as blank, " +
                    "sum(nvl(%3$s, 0)) as output, %4$s as date, " +
                    "from f110 where %4$s = '%5$s' and Стан = '%6$s' group by %4$s order by %4$s";
            String sql = String.format(getDataFromPdx, inputBlankWeightField, pureGradeWeightField, resultBlankWeightField,
                    dateField, rollingDateForQuery, millNumber);
            System.out.println("sql -> " + sql); // just for debug

            // get data from DB
            ResultSet rs = pdxConnection.createStatement().executeQuery(sql);
            System.out.println(CommonUtils.getStringResultSet(rs, 25)); // print result set - just for debug

            /*
            if (rs.next()) { // we received some data
                // get parameters from result set
                Date rollingDate       = PDX_DATE_FORMAT.parse(rs.getString("date"));
                int  inputBlankWeight  = rs.getInt("input");
                int  pureGradeWeight   = rs.getInt("blank");
                int  resultBlankWeight = rs.getInt("output");
                // create object
                result = new RollingResult(rollingDate, inputBlankWeight, pureGradeWeight, resultBlankWeight, millNumber, ARM_REPORT);
            } else { // there is no data
                result = new RollingResult(null, 0, 0, 0, null, null); // empty object
            }
            */

        } finally {
           if (pdxConnection != null) {
               try {
                   pdxConnection.close();
               } catch(SQLException e) {
                   log.error(e);
               }
           }
        }
        // returning result object
        return null; //result;
    }

    /***/
    @SuppressWarnings({"JDBCResourceOpenedButNotSafelyClosed", "CallToDriverManagerGetConnection"})
    public RollingResult getMESRollingResult(Date date, String millNumber) throws SQLException, ParseException {
        log.debug("RollingResultDao.getMESRollingResult() working.");
        RollingResult result;

        Connection oraConnection = null;
        try {
            oraConnection = null;//DriverManager.getConnection(ORA_DB.getConnectionUrl(), ORA_DB.getOraDbUser(), ORA_DB.getOraDbPass());

            // converting date
            String rollingDateForQuery = ORA_DATE_FORMAT.format(date);
            // sql query building
            String blankSql = "select sum(nvl(input_wt, 0)) as input, " +
                    "sum(case when length(rtrim(ltrim(nvl(PON, '')))) = 5 then nvl(prod_wt, 0) end) as pure_grade, " +
                    "sum(case when length(rtrim(ltrim(nvl(PON, '')))) = 4 then nvl(prod_wt, 0) end) as blank, mill_date " +
                    "from tb_po_mill_pon_result where mill_date = '%1$s' and mill_gp = '%2$s' group by mill_date";
            String sql = String.format(blankSql, rollingDateForQuery, (MILL900.equals(millNumber) ? "9" : "3"));
            // execute sql and get result data
            ResultSet rs = oraConnection.createStatement().executeQuery(sql);
            //System.out.println(DbUtils.getStringResultSet(rs, 25)); // print result set - just for debug

            if (rs.next()) { // we received some data
                // get parameters from result set
                Date rollingDate       = ORA_DATE_FORMAT.parse(rs.getString("mill_date"));
                int  inputBlankWeight  = rs.getInt("input");
                int  pureGradeWeight   = rs.getInt("pure_grade");
                int  resultBlankWeight = rs.getInt("blank");
                // create object
                result = new RollingResult(rollingDate, inputBlankWeight, pureGradeWeight, resultBlankWeight, millNumber, MES_REPORT);
            } else { // there is no data
                result = new RollingResult(null, 0, 0, 0, null, null); // empty object
            }

        } finally {
            if (oraConnection != null) {
                try {
                    oraConnection.close();
                } catch(SQLException e) {
                    log.error(e);
                }
            }
        }
        // return result object
        return result;
    }

    /***/
    public String getDiffReport(RollingResult report1, RollingResult report2) {
        log.debug("RollingResultDao.getDiffReport() working.");
        //TextTable report = new TextTable();

        // check input reports - if there are OK, we process them
        if (report1 != null && report2 != null) {
            String[] horizontalHeader = new String[] {"Заготовка (вход)", "Чистый сорт", "Заготовка (выход)", "Вес годного", "Потери"};

            /*
            report.append("|").append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center(String.valueOf(this.inputBlankWeight), COLUMN_WIDTH)));
                    report.append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center(String.valueOf(this.pureGradeWeight), COLUMN_WIDTH)));
                    report.append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center(String.valueOf(this.resultBlankWeight), COLUMN_WIDTH)));
                    report.append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center(String.valueOf(this.inputOkWeight), COLUMN_WIDTH)));
                    report.append(String.format("%" + COLUMN_WIDTH + "s|", StringUtils.center(String.valueOf(this.weightLoss), COLUMN_WIDTH)));
                    */
        } else {
            log.warn("One or both report(s) are empty!");
        }

        //return report.getTextGrid();
        return null;
    }

    /** Method just for test. */
    public static void main(String[] args) throws SQLException, ParseException {
        Log log = LogFactory.getLog(RollingDao.class);
        PropertyConfigurator.configure("log4j.properties");

        log.info("RollingResultDao starting.");
        RollingResultDao rollingResultDao = new RollingResultDao();

        rollingResultDao.getARMRollingResult(new SimpleDateFormat("dd-MM-yyyy").parse("27-08-2013"), "900");
        //System.out.println("-> \n" + rollingResultDao.getARMRollingResult(new SimpleDateFormat("dd-MM-yyyy").parse("23-08-2013"), "900").getReport());
        //System.out.println("-> \n" + rollingResultDao.getMESRollingResult(new SimpleDateFormat("dd-MM-yyyy").parse("23-08-2013"), "900").getReport());

        //OraDbConfig oracleDbConfig  = new OraDbConfig("172.16.0.81:1521", "PMES", "pmes", "pmes1234");

    }

}