package ru.kzgroup.domain.dto.customers.report;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.exceptions.InternalException;

import java.util.Date;

/**
 * One position for customer report.
 * in position all fields except size2 are non-nullable!
 *
 * Class is immutable!
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 27.05.2014)
*/

public class ReportPosition {

    private String  orderNumber;
    private String  steelGrade;
    private String  section;
    private Integer size1;
    private Integer size2;         // nullable
    private Date    warehouseDate;

    /***/
    public ReportPosition(String orderNumber, String steelGrade, String section, Integer size1, Integer size2, Date warehouseDate) throws InternalException {
        // check data
        if (StringUtils.isBlank(orderNumber) || StringUtils.isBlank(steelGrade) || StringUtils.isBlank(section) ||
                size1 == null || warehouseDate == null) {
            throw new InternalException(String.format("One of mandatory parameters is null: order=%s, steel=%s, section=%s, size1=%s, date=%s",
                    orderNumber, steelGrade, section, size1, warehouseDate));
        }
        this.orderNumber   = orderNumber;
        this.steelGrade    = steelGrade;
        this.section       = section;
        this.size1         = size1;
        this.size2         = size2;
        this.warehouseDate = warehouseDate;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public String getSteelGrade() {
        return steelGrade;
    }

    public String getSection() {
        return section;
    }

    public Integer getSize1() {
        return size1;
    }

    public Integer getSize2() {
        return size2;
    }

    public Date getWarehouseDate() {
        //return new Date(warehouseDate.getTime()); // defensive programming
        return warehouseDate;
    }

    @SuppressWarnings({"MethodWithMultipleReturnPoints", "QuestionableName", "RedundantIfStatement"})
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        ReportPosition that = (ReportPosition) obj;

        if (!orderNumber.equals(that.orderNumber)) return false;
        if (!section.equals(that.section)) return false;
        if (!size1.equals(that.size1)) return false;
        if (size2 != null ? !size2.equals(that.size2) : that.size2 != null) return false;
        if (!steelGrade.equals(that.steelGrade)) return false;
        if (!warehouseDate.equals(that.warehouseDate)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = orderNumber.hashCode();
        result = 31 * result + steelGrade.hashCode();
        result = 31 * result + section.hashCode();
        result = 31 * result + size1.hashCode();
        result = 31 * result + (size2 != null ? size2.hashCode() : 0);
        result = 31 * result + warehouseDate.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("orderNumber", orderNumber)
                .append("steelGrade", steelGrade)
                .append("section", section)
                .append("size1", size1)
                .append("size2", size2)
                .append("warehouseDate", warehouseDate)
                .toString();
    }

}