package ru.kzgroup.domain.dto.orders.pdx;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

import java.math.BigDecimal;

/**
 * ORDER EXTRA PARAMETER - domain object (for Paradox). Paradox table D8609PAR.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 17.06.2014)
*/

public class OrderExtraParameterDtoPDX extends BaseDto {

    private OrderExtraParameterDtoIdPDX id;
    private BigDecimal                  extraParameterValue;

    public OrderExtraParameterDtoIdPDX getId() {
        return id;
    }

    public void setId(OrderExtraParameterDtoIdPDX id) {
        this.id = id;
    }

    public BigDecimal getExtraParameterValue() {
        return extraParameterValue;
    }

    public void setExtraParameterValue(BigDecimal extraParameterValue) {
        this.extraParameterValue = extraParameterValue;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("extraParameterValue", extraParameterValue)
                .toString();
    }

}