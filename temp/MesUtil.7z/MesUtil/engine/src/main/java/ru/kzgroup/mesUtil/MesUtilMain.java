package ru.kzgroup.mesUtil;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;

import java.sql.SQLException;

/**
 * Main class for whole MES Util. This class will read config file, command line arguments etc and
 * will decide which module to execute: analizer, directories migration etc.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 29.06.13)
*/

public class MesUtilMain {

    private static Log log = LogFactory.getLog(MesUtilMain.class);

    public static void main(String[] args) throws SQLException {
        PropertyConfigurator.configure("log4j.properties");
        log.info("MesUtil starting.");

    } // end of MAIN

}