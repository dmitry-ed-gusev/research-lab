package ru.kzgroup.domain.dto.rawTables.RK110;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for raw ARMs table RK110. No one of fields can be null (empty), otherwise -
  * result is unknown (NPE or data inconsistency).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 10.05.2014)
*/

public class RK110DtoId implements Serializable {

    private static final long serialVersionUID = 1L;

    private int year;             // RK110->Год
    private int workCardNumber;   // RK110->N_раб_карты
    private int workCardPosition; // RK110->WorkTicketStringNo

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getWorkCardNumber() {
        return workCardNumber;
    }

    public void setWorkCardNumber(int workCardNumber) {
        this.workCardNumber = workCardNumber;
    }

    public int getWorkCardPosition() {
        return workCardPosition;
    }

    public void setWorkCardPosition(int workCardPosition) {
        this.workCardPosition = workCardPosition;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        RK110DtoId rk110DtoId = (RK110DtoId) obj;

        if (workCardNumber != rk110DtoId.workCardNumber) return false;
        if (workCardPosition != rk110DtoId.workCardPosition) return false;
        if (year != rk110DtoId.year) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = year;
        result = 31 * result + workCardNumber;
        result = 31 * result + workCardPosition;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("year", year)
                .append("workCardNumber", workCardNumber)
                .append("workCardPosition", workCardPosition)
                .toString();
    }

}