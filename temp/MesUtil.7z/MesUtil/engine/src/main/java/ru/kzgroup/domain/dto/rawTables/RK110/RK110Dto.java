package ru.kzgroup.domain.dto.rawTables.RK110;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Domain object - raw table RK110 (rolling data).
 * Field ID can't be null. If it is null -> NPE!
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 10.05.2014)
*/

@SuppressWarnings({"MethodParameterNamingConvention", "ClassWithTooManyFields", "ClassWithTooManyMethods", "OverlyComplexClass"})
public class RK110Dto extends BaseDto {

    private static final long serialVersionUID = 1L;

    private RK110DtoId id;                    // RK110->composite primary key
    private Integer    steelGradeCode;        // "Код_марки"->"SMALLINT"
    private Integer    profileCode;           // "Код_проф"->"SMALLINT"
    private Integer    size1;                 // "Разм1"->"SMALLINT"
    private Integer    size2;                 // "Разм2"->"SMALLINT"
    private Integer    lengthFrom;            // "Дл_от"->"SMALLINT"
    private Integer    lengthTo;              // "Дл_до"->"SMALLINT"
    private String     meltNumber;            // "Плавка"->"VARCHAR"

    private Integer    orderYear;             // "OrderYear"->"SMALLINT"
    private Integer    orderMonth;            // "OrderMonth"->"SMALLINT"
    private String     orderYearMonth;        // <- surrogate (calculated) field
    private String     orderNumber;           // "Заказ"->"VARCHAR"
    private Integer    orderPosition;         // "Позиция"->"SMALLINT"

    private Integer    period;                // "Период"->"SMALLINT"
    private String     steelGradeName;        // "Наим.марки"->"VARCHAR"
    private String     profileName;           // "Наим.профиля"->"VARCHAR"
    private BigDecimal consigneeCode;         // "Код_грузопол"->"DOUBLE"
    private String     companyName;           // "Наимен.предприятия"->"VARCHAR"
    private String     city;                  // "Город"->"VARCHAR"
    private BigDecimal customerCode;          // "Код_заказчика"->"DOUBLE"
    private BigDecimal payerCode;             // "Код_плательщика"->"DOUBLE"
    private Date       workCardDate;          // "Дата_раб_карты"->"DATE"
    private Integer    millNumber;            // "Стан"->"SMALLINT"
    private Integer    rollingPiecesCount;    // "Прокат_шт"->"SMALLINT"
    private BigDecimal rollingWeight;         // "Прокат_тн"->"DOUBLE"
    private Integer    rollingBadPieces;      // "Брак_прокат_шт"->"SMALLINT"
    private BigDecimal rollingBadWeight;      // "Брак_прокат_тн"->"DOUBLE"
    private BigDecimal correctionWeight;      // "Правка_тн"->"DOUBLE"
    private Integer    stand1;                // "Стойка1"->"SMALLINT"
    private BigDecimal trimmingWeight;        // "Зачистка_тн"->"DOUBLE"
    private Integer    stand2;                // "Стойка2"->"SMALLINT"
    private BigDecimal thermalProcWeight;     // "Терм_обр_тн"->"DOUBLE"
    private Integer    stand3;                // "Стойка3"->"SMALLINT"
    private Date       acceptanceDateAD;      // "Дата_приемки_АД"->"DATE"
    private Integer    acceptancePiecesAD;    // "Приемка_АД_шт"->"SMALLINT"
    private BigDecimal acceptanceWeigthAD;    // "Приемка_АД_тн"->"DOUBLE"
    private Integer    acceptancePackagesAD;  // "Приемка_АД_пак"->"SMALLINT"
    private Integer    acceptanceBadPiecesAD; // "Приемка_АД_брак_шт"->"SMALLINT"
    private BigDecimal acceptanceBadWeightAD; // "Приемка_АД_брак_тн"->"DOUBLE"
    private BigDecimal acceptanceCutWeightAD; // "Приемка_АД_обрезь_тн"->"DOUBLE"
    private BigDecimal remainderWeight;       // "Остаток_тн"->"DOUBLE"
    private Integer    workCardCloseSign;     // "Признак_закрытия_карты"->"SMALLINT"
    private BigDecimal acceptanceADTurningWeight; // "ПриемкаАДобточкаТн"->"DOUBLE"
    private Date       turningSentDate;       // "ДатаОтпрОбт"->"DATE"
    private Integer    turningSentProfile;    // "ОтпрОбтПроф"->"SMALLINT"
    private Integer    turningSentSize1;      // "ОтпрОбтРазм1"->"SMALLINT"
    private Integer    turningSentPackages;   // "ОтпрОбтПак"->"SMALLINT"
    private Integer    turningSentPieces;     // "ОтпрОбтШт"->"SMALLINT"
    private BigDecimal turningSentWeight;     // "ОтпрОбтТн"->"DOUBLE"
    // Приемка адьюстажа - обточка брак, штук (заполняется на обточке?)
    private Integer    acceptanceADTurningBadPieces;      // "ПриемАДобтБракШт"->"SMALLINT"
    // Приемка адьюстажа - обточка брак, тонн (вес) (заполняется на обточке?)
    private BigDecimal acceptanceADTurningBadWeight;      // "ПриемАДобтБракТн"->"DOUBLE"
    // Приемка адьюстажа - обточка обработано, тонн (вес) (заполняется на обточке?)
    private BigDecimal acceptanceADTurningProcWeight;     // "ПриемАДобтОбрТн"->"DOUBLE"
    // Приемка адьюстажа - брак обточки, штук (заполняется на адьюстаже?)
    private Integer    acceptanceADTurningBadTurnPieces;  // "ПриемАДобтБракОбтШт"->"SMALLINT"
    // Приемка адьюстажа - брак обточки, тонн (вес) (заполняется на адьюстаже?)
    private BigDecimal acceptanceADTurningBadTurnWeight;  // "ПриемАДобтБракОбтТн"->"DOUBLE"
    // Приемка адьюстажа - обточено (обработано), тонн (вес) (заполняется на адьюстаже?)
    private BigDecimal acceptanceADTurningProcTurnWeight; // "ПриемАДобтОбрОбтТн"->"DOUBLE"
    private BigDecimal otkWeight;          // "OTKWeight"->"DOUBLE"
    private Integer    otkPiecesCount;     // "OTKPiece"->"SMALLINT"
    private Integer    turnProdWastePC;    // "TurnProdWastePC"->"SMALLINT"
    private Integer    addParingPc;        // "AddParingPc"->"SMALLINT"
    private BigDecimal addParingTn;        // "AddParingTn"->"DOUBLE"
    private Integer    noOrderReasonCode;  // "NoOrderReasonCode"->"SMALLINT"
    private Integer    rawCode;            // "CodeRaw"->"SMALLINT"
    private BigDecimal landingWeight;      // "PosadTn"->"DOUBLE"
    private Integer    codeGroupCalc;      // "CodeGroupCalc"->"SMALLINT"
    private Date       otkDate;            // "DateOTK"->"DATE"
    private Date       outDate;            // "DateOut"->"DATE"
    private Date       brDate;             // "DateBr"->"DATE"
    private String     baseOrderNumber;    // "BaseOrderNo"->"VARCHAR"
    private Date       adShipmentDate;     // "ADShipDate"->"DATE"
    private Integer    adPathOst;          // "ADpathOst"->"SMALLINT"
    private String     isArc;              // "IsArc"->"VARCHAR"

    public RK110DtoId getId() {
        return id;
    }

    public void setId(RK110DtoId id) {
        this.id = id;
    }

    public Integer getSteelGradeCode() {
        return steelGradeCode;
    }

    public void setSteelGradeCode(Integer steelGradeCode) {
        this.steelGradeCode = steelGradeCode;
    }

    public Integer getProfileCode() {
        return profileCode;
    }

    public void setProfileCode(Integer profileCode) {
        this.profileCode = profileCode;
    }

    public Integer getSize1() {
        return size1;
    }

    public void setSize1(Integer size1) {
        this.size1 = size1;
    }

    public Integer getSize2() {
        return size2;
    }

    public void setSize2(Integer size2) {
        this.size2 = size2;
    }

    public Integer getLengthFrom() {
        return lengthFrom;
    }

    public void setLengthFrom(Integer lengthFrom) {
        this.lengthFrom = lengthFrom;
    }

    public Integer getLengthTo() {
        return lengthTo;
    }

    public void setLengthTo(Integer lengthTo) {
        this.lengthTo = lengthTo;
    }

    public String getMeltNumber() {
        return meltNumber;
    }

    public void setMeltNumber(String meltNumber) {
        this.meltNumber = meltNumber;
    }

    public Integer getOrderYear() {
        return orderYear;
    }

    public void setOrderYear(Integer orderYear) {
        this.orderYear = orderYear;
    }

    public Integer getPeriod() {
        return period;
    }

    public void setPeriod(Integer period) {
        this.period = period;
    }

    public Integer getOrderMonth() {
        return orderMonth;
    }

    public void setOrderMonth(Integer orderMonth) {
        this.orderMonth = orderMonth;
    }

    public String getSteelGradeName() {
        return steelGradeName;
    }

    public void setSteelGradeName(String steelGradeName) {
        this.steelGradeName = steelGradeName;
    }

    public String getProfileName() {
        return profileName;
    }

    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    public BigDecimal getConsigneeCode() {
        return consigneeCode;
    }

    public void setConsigneeCode(BigDecimal consigneeCode) {
        this.consigneeCode = consigneeCode;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public BigDecimal getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(BigDecimal customerCode) {
        this.customerCode = customerCode;
    }

    public BigDecimal getPayerCode() {
        return payerCode;
    }

    public void setPayerCode(BigDecimal payerCode) {
        this.payerCode = payerCode;
    }

    public Date getWorkCardDate() {
        return workCardDate;
    }

    public void setWorkCardDate(Date workCardDate) {
        this.workCardDate = workCardDate;
    }

    public Integer getMillNumber() {
        return millNumber;
    }

    public void setMillNumber(Integer millNumber) {
        this.millNumber = millNumber;
    }

    public Integer getRollingPiecesCount() {
        return rollingPiecesCount;
    }

    public void setRollingPiecesCount(Integer rollingPiecesCount) {
        this.rollingPiecesCount = rollingPiecesCount;
    }

    public BigDecimal getRollingWeight() {
        return rollingWeight;
    }

    public void setRollingWeight(BigDecimal rollingWeight) {
        this.rollingWeight = rollingWeight;
    }

    public Integer getRollingBadPieces() {
        return rollingBadPieces;
    }

    public void setRollingBadPieces(Integer rollingBadPieces) {
        this.rollingBadPieces = rollingBadPieces;
    }

    public BigDecimal getRollingBadWeight() {
        return rollingBadWeight;
    }

    public void setRollingBadWeight(BigDecimal rollingBadWeight) {
        this.rollingBadWeight = rollingBadWeight;
    }

    public BigDecimal getCorrectionWeight() {
        return correctionWeight;
    }

    public void setCorrectionWeight(BigDecimal correctionWeight) {
        this.correctionWeight = correctionWeight;
    }

    public Integer getStand1() {
        return stand1;
    }

    public void setStand1(Integer stand1) {
        this.stand1 = stand1;
    }

    public BigDecimal getTrimmingWeight() {
        return trimmingWeight;
    }

    public void setTrimmingWeight(BigDecimal trimmingWeight) {
        this.trimmingWeight = trimmingWeight;
    }

    public Integer getStand2() {
        return stand2;
    }

    public void setStand2(Integer stand2) {
        this.stand2 = stand2;
    }

    public BigDecimal getThermalProcWeight() {
        return thermalProcWeight;
    }

    public void setThermalProcWeight(BigDecimal thermalProcWeight) {
        this.thermalProcWeight = thermalProcWeight;
    }

    public Integer getStand3() {
        return stand3;
    }

    public void setStand3(Integer stand3) {
        this.stand3 = stand3;
    }

    public Date getAcceptanceDateAD() {
        return acceptanceDateAD;
    }

    public void setAcceptanceDateAD(Date acceptanceDateAD) {
        this.acceptanceDateAD = acceptanceDateAD;
    }

    public Integer getAcceptancePiecesAD() {
        return acceptancePiecesAD;
    }

    public void setAcceptancePiecesAD(Integer acceptancePiecesAD) {
        this.acceptancePiecesAD = acceptancePiecesAD;
    }

    public BigDecimal getAcceptanceWeigthAD() {
        return acceptanceWeigthAD;
    }

    public void setAcceptanceWeigthAD(BigDecimal acceptanceWeigthAD) {
        this.acceptanceWeigthAD = acceptanceWeigthAD;
    }

    public Integer getAcceptancePackagesAD() {
        return acceptancePackagesAD;
    }

    public void setAcceptancePackagesAD(Integer acceptancePackagesAD) {
        this.acceptancePackagesAD = acceptancePackagesAD;
    }

    public Integer getAcceptanceBadPiecesAD() {
        return acceptanceBadPiecesAD;
    }

    public void setAcceptanceBadPiecesAD(Integer acceptanceBadPiecesAD) {
        this.acceptanceBadPiecesAD = acceptanceBadPiecesAD;
    }

    public BigDecimal getAcceptanceBadWeightAD() {
        return acceptanceBadWeightAD;
    }

    public void setAcceptanceBadWeightAD(BigDecimal acceptanceBadWeightAD) {
        this.acceptanceBadWeightAD = acceptanceBadWeightAD;
    }

    public BigDecimal getAcceptanceCutWeightAD() {
        return acceptanceCutWeightAD;
    }

    public void setAcceptanceCutWeightAD(BigDecimal acceptanceCutWeightAD) {
        this.acceptanceCutWeightAD = acceptanceCutWeightAD;
    }

    public BigDecimal getRemainderWeight() {
        return remainderWeight;
    }

    public void setRemainderWeight(BigDecimal remainderWeight) {
        this.remainderWeight = remainderWeight;
    }

    public Integer getWorkCardCloseSign() {
        return workCardCloseSign;
    }

    public void setWorkCardCloseSign(Integer workCardCloseSign) {
        this.workCardCloseSign = workCardCloseSign;
    }

    public BigDecimal getAcceptanceADTurningWeight() {
        return acceptanceADTurningWeight;
    }

    public void setAcceptanceADTurningWeight(BigDecimal acceptanceADTurningWeight) {
        this.acceptanceADTurningWeight = acceptanceADTurningWeight;
    }

    public Date getTurningSentDate() {
        return turningSentDate;
    }

    public void setTurningSentDate(Date turningSentDate) {
        this.turningSentDate = turningSentDate;
    }

    public Integer getTurningSentProfile() {
        return turningSentProfile;
    }

    public void setTurningSentProfile(Integer turningSentProfile) {
        this.turningSentProfile = turningSentProfile;
    }

    public Integer getTurningSentSize1() {
        return turningSentSize1;
    }

    public void setTurningSentSize1(Integer turningSentSize1) {
        this.turningSentSize1 = turningSentSize1;
    }

    public Integer getTurningSentPackages() {
        return turningSentPackages;
    }

    public void setTurningSentPackages(Integer turningSentPackages) {
        this.turningSentPackages = turningSentPackages;
    }

    public Integer getTurningSentPieces() {
        return turningSentPieces;
    }

    public void setTurningSentPieces(Integer turningSentPieces) {
        this.turningSentPieces = turningSentPieces;
    }

    public BigDecimal getTurningSentWeight() {
        return turningSentWeight;
    }

    public void setTurningSentWeight(BigDecimal turningSentWeight) {
        this.turningSentWeight = turningSentWeight;
    }

    public Integer getAcceptanceADTurningBadPieces() {
        return acceptanceADTurningBadPieces;
    }

    public void setAcceptanceADTurningBadPieces(Integer acceptanceADTurningBadPieces) {
        this.acceptanceADTurningBadPieces = acceptanceADTurningBadPieces;
    }

    public BigDecimal getAcceptanceADTurningBadWeight() {
        return acceptanceADTurningBadWeight;
    }

    public void setAcceptanceADTurningBadWeight(BigDecimal acceptanceADTurningBadWeight) {
        this.acceptanceADTurningBadWeight = acceptanceADTurningBadWeight;
    }

    public BigDecimal getAcceptanceADTurningProcWeight() {
        return acceptanceADTurningProcWeight;
    }

    public void setAcceptanceADTurningProcWeight(BigDecimal acceptanceADTurningProcWeight) {
        this.acceptanceADTurningProcWeight = acceptanceADTurningProcWeight;
    }

    public Integer getAcceptanceADTurningBadTurnPieces() {
        return acceptanceADTurningBadTurnPieces;
    }

    public void setAcceptanceADTurningBadTurnPieces(Integer acceptanceADTurningBadTurnPieces) {
        this.acceptanceADTurningBadTurnPieces = acceptanceADTurningBadTurnPieces;
    }

    public BigDecimal getAcceptanceADTurningBadTurnWeight() {
        return acceptanceADTurningBadTurnWeight;
    }

    public void setAcceptanceADTurningBadTurnWeight(BigDecimal acceptanceADTurningBadTurnWeight) {
        this.acceptanceADTurningBadTurnWeight = acceptanceADTurningBadTurnWeight;
    }

    public BigDecimal getAcceptanceADTurningProcTurnWeight() {
        return acceptanceADTurningProcTurnWeight;
    }

    public void setAcceptanceADTurningProcTurnWeight(BigDecimal acceptanceADTurningProcTurnWeight) {
        this.acceptanceADTurningProcTurnWeight = acceptanceADTurningProcTurnWeight;
    }

    public BigDecimal getOtkWeight() {
        return otkWeight;
    }

    public void setOtkWeight(BigDecimal otkWeight) {
        this.otkWeight = otkWeight;
    }

    public Integer getOtkPiecesCount() {
        return otkPiecesCount;
    }

    public void setOtkPiecesCount(Integer otkPiecesCount) {
        this.otkPiecesCount = otkPiecesCount;
    }

    public Integer getTurnProdWastePC() {
        return turnProdWastePC;
    }

    public void setTurnProdWastePC(Integer turnProdWastePC) {
        this.turnProdWastePC = turnProdWastePC;
    }

    public Integer getAddParingPc() {
        return addParingPc;
    }

    public void setAddParingPc(Integer addParingPc) {
        this.addParingPc = addParingPc;
    }

    public BigDecimal getAddParingTn() {
        return addParingTn;
    }

    public void setAddParingTn(BigDecimal addParingTn) {
        this.addParingTn = addParingTn;
    }

    public Integer getNoOrderReasonCode() {
        return noOrderReasonCode;
    }

    public void setNoOrderReasonCode(Integer noOrderReasonCode) {
        this.noOrderReasonCode = noOrderReasonCode;
    }

    public Integer getRawCode() {
        return rawCode;
    }

    public void setRawCode(Integer rawCode) {
        this.rawCode = rawCode;
    }

    public BigDecimal getLandingWeight() {
        return landingWeight;
    }

    public void setLandingWeight(BigDecimal landingWeight) {
        this.landingWeight = landingWeight;
    }

    public Integer getCodeGroupCalc() {
        return codeGroupCalc;
    }

    public void setCodeGroupCalc(Integer codeGroupCalc) {
        this.codeGroupCalc = codeGroupCalc;
    }

    public Date getOtkDate() {
        return otkDate;
    }

    public void setOtkDate(Date otkDate) {
        this.otkDate = otkDate;
    }

    public Date getOutDate() {
        return outDate;
    }

    public void setOutDate(Date outDate) {
        this.outDate = outDate;
    }

    public Date getBrDate() {
        return brDate;
    }

    public void setBrDate(Date brDate) {
        this.brDate = brDate;
    }

    public String getBaseOrderNumber() {
        return baseOrderNumber;
    }

    public void setBaseOrderNumber(String baseOrderNumber) {
        this.baseOrderNumber = baseOrderNumber;
    }

    public Date getAdShipmentDate() {
        return adShipmentDate;
    }

    public void setAdShipmentDate(Date adShipmentDate) {
        this.adShipmentDate = adShipmentDate;
    }

    public Integer getAdPathOst() {
        return adPathOst;
    }

    public void setAdPathOst(Integer adPathOst) {
        this.adPathOst = adPathOst;
    }

    public String getIsArc() {
        return isArc;
    }

    public void setIsArc(String isArc) {
        this.isArc = isArc;
    }

    public String getOrderYearMonth() {
        return orderYearMonth;
    }

    public void setOrderYearMonth(String orderYearMonth) {
        this.orderYearMonth = orderYearMonth;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public Integer getOrderPosition() {
        return orderPosition;
    }

    public void setOrderPosition(Integer orderPosition) {
        this.orderPosition = orderPosition;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("steelGradeCode", steelGradeCode)
                .append("profileCode", profileCode)
                .append("size1", size1)
                .append("size2", size2)
                .append("lengthFrom", lengthFrom)
                .append("lengthTo", lengthTo)
                .append("meltNumber", meltNumber)
                .append("orderYear", orderYear)
                .append("orderMonth", orderMonth)
                .append("orderYearMonth", orderYearMonth)
                .append("orderNumber", orderNumber)
                .append("orderPosition", orderPosition)
                .append("period", period)
                .append("steelGradeName", steelGradeName)
                .append("profileName", profileName)
                .append("consigneeCode", consigneeCode)
                .append("companyName", companyName)
                .append("city", city)
                .append("customerCode", customerCode)
                .append("payerCode", payerCode)
                .append("workCardDate", workCardDate)
                .append("millNumber", millNumber)
                .append("rollingPiecesCount", rollingPiecesCount)
                .append("rollingWeight", rollingWeight)
                .append("rollingBadPieces", rollingBadPieces)
                .append("rollingBadWeight", rollingBadWeight)
                .append("correctionWeight", correctionWeight)
                .append("stand1", stand1)
                .append("trimmingWeight", trimmingWeight)
                .append("stand2", stand2)
                .append("thermalProcWeight", thermalProcWeight)
                .append("stand3", stand3)
                .append("acceptanceDateAD", acceptanceDateAD)
                .append("acceptancePiecesAD", acceptancePiecesAD)
                .append("acceptanceWeigthAD", acceptanceWeigthAD)
                .append("acceptancePackagesAD", acceptancePackagesAD)
                .append("acceptanceBadPiecesAD", acceptanceBadPiecesAD)
                .append("acceptanceBadWeightAD", acceptanceBadWeightAD)
                .append("acceptanceCutWeightAD", acceptanceCutWeightAD)
                .append("remainderWeight", remainderWeight)
                .append("workCardCloseSign", workCardCloseSign)
                .append("acceptanceADTurningWeight", acceptanceADTurningWeight)
                .append("turningSentDate", turningSentDate)
                .append("turningSentProfile", turningSentProfile)
                .append("turningSentSize1", turningSentSize1)
                .append("turningSentPackages", turningSentPackages)
                .append("turningSentPieces", turningSentPieces)
                .append("turningSentWeight", turningSentWeight)
                .append("acceptanceADTurningBadPieces", acceptanceADTurningBadPieces)
                .append("acceptanceADTurningBadWeight", acceptanceADTurningBadWeight)
                .append("acceptanceADTurningProcWeight", acceptanceADTurningProcWeight)
                .append("acceptanceADTurningBadTurnPieces", acceptanceADTurningBadTurnPieces)
                .append("acceptanceADTurningBadTurnWeight", acceptanceADTurningBadTurnWeight)
                .append("acceptanceADTurningProcTurnWeight", acceptanceADTurningProcTurnWeight)
                .append("otkWeight", otkWeight)
                .append("otkPiecesCount", otkPiecesCount)
                .append("turnProdWastePC", turnProdWastePC)
                .append("addParingPc", addParingPc)
                .append("addParingTn", addParingTn)
                .append("noOrderReasonCode", noOrderReasonCode)
                .append("rawCode", rawCode)
                .append("landingWeight", landingWeight)
                .append("codeGroupCalc", codeGroupCalc)
                .append("otkDate", otkDate)
                .append("outdate", outDate)
                .append("brDate", brDate)
                .append("baseOrderNumber", baseOrderNumber)
                .append("adShipmentdate", adShipmentDate)
                .append("adPathOst", adPathOst)
                .append("isArc", isArc)
                .toString();
    }

}