package ru.kzgroup.domain.dto.directories;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * ROLLING SECTION TYPE - domain object (профиль проката).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 12.02.14)
*/

public class SectionDto extends BaseDto {

    private String code;
    private String name;
    private String nameEnglish;
    private String type;

    /** Default constructor for Hibernate. */
    public SectionDto() {}

    /** Copying constructor. */
    public SectionDto(SectionDto section) {
        if (section != null) {
            this.code        = section.getCode();
            this.name        = section.getName();
            this.nameEnglish = section.getNameEnglish();
            this.type        = section.getType();
        } else {
            LogFactory.getLog(SectionDto.class).warn(String.format("Copy NULL object [%s]!", SectionDto.class));
            this.code        = null;
            this.name        = null;
            this.nameEnglish = null;
            this.type        = null;
        }
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameEnglish() {
        return nameEnglish;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("code", code)
                .append("name", name)
                .append("nameEnglish", nameEnglish)
                .append("type", type)
                .toString();
    }

}