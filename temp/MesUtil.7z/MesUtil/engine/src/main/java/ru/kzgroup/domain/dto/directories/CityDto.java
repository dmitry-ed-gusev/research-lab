package ru.kzgroup.domain.dto.directories;

import ru.kzgroup.domain.dto.BaseDto;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 18.02.14)
*/

public class CityDto extends BaseDto {

    private int     code;
    private String  name;
    private Integer countryCode; // we use Integer, because this value could be nullable (in PDX)

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(Integer countryCode) {
        this.countryCode = countryCode;
    }

}