package ru.kzgroup.domain.dto.directories;

import org.apache.commons.lang3.builder.ToStringBuilder;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * Type of standard - domain object.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 17.02.14)
*/

public class StandardTypeDto extends BaseDto {

    private String code;
    private String name;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("code", code)
                .append("name", name)
                .toString();
    }

}