package ru.kzgroup.domain.dto.rawTables;

import ru.kzgroup.domain.dto.BaseDto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Class for raw ARM data table N01100.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 30.05.2014)
*/

public class N01100 extends BaseDto {

    private String     meltNo;
    private Integer    furnanceNumber; // nullable
    private Date       meltDate;
    private BigDecimal elementC;
    private BigDecimal elementSI;
    private BigDecimal elementMN;
    private BigDecimal elementS;
    private BigDecimal elementP;
    private BigDecimal elementCR;
    private BigDecimal elementNI;
    private BigDecimal elementCU;
    private BigDecimal elementCEQU;
    private Integer    blankType;
    private Integer    steelGrade;

    public String getMeltNo() {
        return meltNo;
    }

    public void setMeltNo(String meltNo) {
        this.meltNo = meltNo;
    }

    public Integer getFurnanceNumber() {
        return furnanceNumber;
    }

    public void setFurnanceNumber(Integer furnanceNumber) {
        this.furnanceNumber = furnanceNumber;
    }

    public Date getMeltDate() {
        return meltDate;
    }

    public void setMeltDate(Date meltDate) {
        this.meltDate = meltDate;
    }

    public BigDecimal getElementC() {
        return elementC;
    }

    public void setElementC(BigDecimal elementC) {
        this.elementC = elementC;
    }

    public BigDecimal getElementSI() {
        return elementSI;
    }

    public void setElementSI(BigDecimal elementSI) {
        this.elementSI = elementSI;
    }

    public BigDecimal getElementMN() {
        return elementMN;
    }

    public void setElementMN(BigDecimal elementMN) {
        this.elementMN = elementMN;
    }

    public BigDecimal getElementS() {
        return elementS;
    }

    public void setElementS(BigDecimal elementS) {
        this.elementS = elementS;
    }

    public BigDecimal getElementP() {
        return elementP;
    }

    public void setElementP(BigDecimal elementP) {
        this.elementP = elementP;
    }

    public BigDecimal getElementCR() {
        return elementCR;
    }

    public void setElementCR(BigDecimal elementCR) {
        this.elementCR = elementCR;
    }

    public BigDecimal getElementNI() {
        return elementNI;
    }

    public void setElementNI(BigDecimal elementNI) {
        this.elementNI = elementNI;
    }

    public BigDecimal getElementCU() {
        return elementCU;
    }

    public void setElementCU(BigDecimal elementCU) {
        this.elementCU = elementCU;
    }

    public BigDecimal getElementCEQU() {
        return elementCEQU;
    }

    public void setElementCEQU(BigDecimal elementCEQU) {
        this.elementCEQU = elementCEQU;
    }

    public Integer getBlankType() {
        return blankType;
    }

    public void setBlankType(Integer blankType) {
        this.blankType = blankType;
    }

    public Integer getSteelGrade() {
        return steelGrade;
    }

    public void setSteelGrade(Integer steelGrade) {
        this.steelGrade = steelGrade;
    }

}