package ru.kzgroup.domain.dto.rawTables.W161Z;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Composite primary key for raw ARM table - W161Z.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 13.08.2014)
*/

public class W161ZDtoId implements Serializable {

    private static final long serialVersionUID = 1L;

    private int        year;
    private int        month;
    private int        yearWorkTicket;
    private BigDecimal codeWorkTicket;
    private BigDecimal codeFrachtbrief;
    private int        record;

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYearWorkTicket() {
        return yearWorkTicket;
    }

    public void setYearWorkTicket(int yearWorkTicket) {
        this.yearWorkTicket = yearWorkTicket;
    }

    public BigDecimal getCodeWorkTicket() {
        return codeWorkTicket;
    }

    public void setCodeWorkTicket(BigDecimal codeWorkTicket) {
        this.codeWorkTicket = codeWorkTicket;
    }

    public BigDecimal getCodeFrachtbrief() {
        return codeFrachtbrief;
    }

    public void setCodeFrachtbrief(BigDecimal codeFrachtbrief) {
        this.codeFrachtbrief = codeFrachtbrief;
    }

    public int getRecord() {
        return record;
    }

    public void setRecord(int record) {
        this.record = record;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        W161ZDtoId that = (W161ZDtoId) o;

        if (month != that.month) return false;
        if (record != that.record) return false;
        if (year != that.year) return false;
        if (yearWorkTicket != that.yearWorkTicket) return false;
        if (!codeFrachtbrief.equals(that.codeFrachtbrief)) return false;
        if (!codeWorkTicket.equals(that.codeWorkTicket)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = year;
        result = 31 * result + month;
        result = 31 * result + yearWorkTicket;
        result = 31 * result + codeWorkTicket.hashCode();
        result = 31 * result + codeFrachtbrief.hashCode();
        result = 31 * result + record;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("year", year)
                .append("month", month)
                .append("yearWorkTicket", yearWorkTicket)
                .append("codeWorkTicket", codeWorkTicket)
                .append("codeFrachtbrief", codeFrachtbrief)
                .append("record", record)
                .toString();
    }

}