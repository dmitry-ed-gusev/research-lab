package ru.kzgroup.exceptions;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 30.04.2014)
*/

public class InternalException extends Exception {

    public InternalException(String message) {
        super(message);
    }

    public InternalException(Throwable cause) {
        super(cause);
    }

}