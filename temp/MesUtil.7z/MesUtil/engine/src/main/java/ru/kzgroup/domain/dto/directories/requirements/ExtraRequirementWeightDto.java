package ru.kzgroup.domain.dto.directories.requirements;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

import java.math.BigDecimal;

/**
 * EXTRA REQUIREMENT BY WEIGHT - selection (manual) from all extra requirements.
 * Paradox table M11602, Oracle table TB_DICT_EXTRA_REQS_WEIGHT.
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 30.06.2014)
 */
public class ExtraRequirementWeightDto extends BaseDto {

    private int        reqCode;  // primary key
    private BigDecimal minValue;
    private BigDecimal maxValue;

    public int getReqCode() {
        return reqCode;
    }

    public void setReqCode(int reqCode) {
        this.reqCode = reqCode;
    }

    public BigDecimal getMinValue() {
        return minValue;
    }

    public void setMinValue(BigDecimal minValue) {
        this.minValue = minValue;
    }

    public BigDecimal getMaxValue() {
        return maxValue;
    }

    public void setMaxValue(BigDecimal maxValue) {
        this.maxValue = maxValue;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("reqCode", reqCode)
                .append("minValue", minValue)
                .append("maxValue", maxValue)
                .toString();
    }

}