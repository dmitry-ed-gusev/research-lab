package ru.kzgroup.domain.dto.rolling;

/**
 * One position from RollingCard.
 *
 * Important!
 * All info about links to databases/tables fields is actual on 30.08.2013!
 *
 * @author Gusev Dmitry (GusevD)
 * @version 1.0 (DATE: 19.07.13)
*/

public class RollingWorkCardPosition {

    // Mill group: 900/350. In MES values '3'/'9',
    // MILL_GP -> TB_PO_MILL_PON_RESULT (primary key - seq. #1)
    // Стан -> f110
    private String millGroup;

    // PROD_YY -> TB_PO_MILL_PON_RESULT (primary key - seq. #2)
    // ГодРК -> f110 (primary key - seq. #1)
    private String productionYear;

    // Work card number (PON - Product Order Number)
    // PON -> TB_PO_MILL_PON_RESULT (primary key - seq. #3)
    // Раб.карта -> f110 (primary key - seq. #2)
    private String ponNumber;

    // Work card position number
    // PON_SEQ -> TB_PO_MILL_PON_RESULT (primary key - seq. #4)
    // WorkTicketStringNo -> f110 (primary key - seq. #3)
    private String ponSequenceNumber;

    // [дата проката]
    // MILL_DATE -> TB_PO_MILL_PON_RESULT (primary key - seq. #5)
    // Дата_пр. -> f110 (primary key - seq #4)
    private String millDate;

    // [смена (заводская, по времени)].
    // WORK_DUTY -> TB_PO_MILL_PON_RESULT (primary key - seq. #6)
    // Смена -> f110 (primary key - seq #5)
    private String workShift;

    private String status;
    private String orderRemainGrouping;
    private String heatingCode;
    private String yardNumber;
    private String meltNumber;
    private String steelGradeGroupCode;
    private String steelGradeCode;
    private String steelGradeName;

    private int    inputSectionThickness;
    private int    inputSectionWidth;

    // Quantity of input (900 - melts, 350 - blanks)
    // INPUT_QNTY -> TB_PO_MILL_PON_RESULT
    // К-во_заг. -> f110
    private int    inputQuantity;

    private int    purchaseWeight;

    // Weight of input (900 - melts, 350 - blanks)
    // INPUT_WT -> TB_PO_MILL_PON_RESULT
    // Вес_заг. -> f110
    private int    inputWeight;

    private String sectionCode;
    private String sectionType;
    private String sectionThickness;
    private String sectionWidth;

    private String lengthCode;
    private String lengthFrom;
    private String lengthTo;

    private String productQuantity;
    private String productWeight;
    private String productYearMonth;

    private String orderNumber;
    private String orderPosition;
    private String reheatingQuantity;
    private String reheatingWeight;
    private String tkBadQuantity;
    private String tkBadWeight;
    private String scrapBadQuantity;
    private String scrapBadWeight;

    private String heatingSendWeight;
    private String straightSendWeight;

    private String downTimeCode;    // простой оборудования/смены - код
    private String downTimeLength;  // простой оборудования/смены - длительность

    // [Рабочая бригада (номер/буква)].
    // WORK_SHIFT -> TB_PO_MILL_PON_RESULT
    // бригада -> f110
    private String brigade;

    private String workerName;  // бригадир/мастер?

    /***/
    public RollingWorkCardPosition(String millGroup, String productionYear, String ponNumber,
                                   String ponSequenceNumber, String millDate, String workShift) {
        this.productionYear    = productionYear;
        this.ponNumber         = ponNumber;
        this.ponSequenceNumber = ponSequenceNumber;
        this.millDate          = millDate;
    }

}