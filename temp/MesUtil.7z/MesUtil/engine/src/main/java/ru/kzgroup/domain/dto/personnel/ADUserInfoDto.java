package ru.kzgroup.domain.dto.personnel;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * Utility class for representing Active Directory info for one employee.
 * Class is immutable.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 14.10.13)
*/

public final class ADUserInfoDto {

    private String fullName;
    private String login;
    private String email;

    public ADUserInfoDto(String fullName, String login, String email) {
        this.fullName = fullName;
        this.login = login;
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public String getLogin() {
        return login;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("fullName", fullName)
                .append("login", login)
                .append("email", email)
                .toString();
    }

}