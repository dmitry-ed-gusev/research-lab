package ru.kzgroup.domain.dto.orders.pdx;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;
import ru.kzgroup.domain.dto.directories.MarkingDto;

/**
 * Service object - for marking data
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 19.06.2014)
*/

public class OrderD0502003PDX extends BaseDto {

    private OrderD0502003IdPDX id;
    private MarkingDto         marking;

    public OrderD0502003IdPDX getId() {
        return id;
    }

    public void setId(OrderD0502003IdPDX id) {
        this.id = id;
    }

    public MarkingDto getMarking() {
        return marking;
    }

    public void setMarking(MarkingDto marking) {
        this.marking = marking;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("marking", marking)
                .toString();
    }

}