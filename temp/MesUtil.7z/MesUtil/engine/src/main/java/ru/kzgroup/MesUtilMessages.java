package ru.kzgroup;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 17.01.14)
*/

public interface MesUtilMessages {

    // scrap processing -> OK message
    public static final String MSG_SCRAP_PROCESSED_OK          = "Scrap:  [%s] rec(s). Time: %s.";
    // lab100 processing -> OK message
    public static final String MSG_LAB100_PROCESSED_OK         = "Lab100: [%S] rec(s). Time: %s.";
    // contracts processing (PDX->Oracle)
    //public static final String MSG_CONTRACTS_PROCESSED         = "[%s] rec(s) processed PDX->Oracle.";
    // directories processing (PDX->Oracle)
    public static final String MSG_DIRECTORY_PROCESSED         = "[%s]->[%s/%s] rec(s) PDX->Oracle.";
}
