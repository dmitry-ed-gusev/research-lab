package ru.kzgroup.domain.dto.customers.report;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.exceptions.InternalException;
import ru.kzgroup.domain.dto.customers.CustomerDto;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * CUSTOMER REPORT MODEL - data about finished goods for one customer.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 27.05.2014)
*/

public class CustomerReport {

    private static final Log log = LogFactory.getLog(CustomerReport.class);

    // date format template for record
    public static final String            REPORT_DATE_TEMPLATE = "dd.MM.yyyy";
    // date format object for report
    private static final SimpleDateFormat REPORT_DATE_FORMAT   = new SimpleDateFormat(REPORT_DATE_TEMPLATE);
    // report header (static data)
    private static final String[]         REPORT_HEADER        =
            {null, "Заказчик", "Номер заказа", "Марка стали", "Профиль", "Размер", "Дата поступления на склад", "Вес, тн"};
    // empty line for report
    private static final String[]         REPORT_EMPTY_LINE    = new String[]{null, null, null, null, null, null, null, null};

    private CustomerDto                         customer;
    private HashMap<ReportPosition, BigDecimal> report;
    private BigDecimal                          totalWeight;

    /***/
    public CustomerReport(CustomerDto customer) throws InternalException {
        if (customer == null || StringUtils.isBlank(customer.getName())) { // check input data
            throw new InternalException(String.format("Empty customer object or customer name!\nCustomer->[%s]", String.valueOf(customer)));
        }
        this.customer     = customer;
        this.report       = new LinkedHashMap<>(); // we will preserve insertion order (by date)
        this.totalWeight  = new BigDecimal(0);
    }

    /**
     * @return boolean true - position added, otherwise - not.
    */
    public boolean addReportPosition(ReportPosition position, BigDecimal weight) {
        boolean result = false;
        if (position != null && weight != null) {
            if (!this.report.containsKey(position)) { // new position - just add
                this.report.put(position, weight);
            } else { // existing position - just update data (add weight)
                BigDecimal previousValue = this.report.get(position);
                this.report.put(position, previousValue.add(weight));
            }
            this.totalWeight = this.totalWeight.add(weight); // counting total weight
            result = true;
        } else {
            log.warn(String.format("Empty position or weight! Customer [%s].", this.customer));
        }
        return result;
    }

    /***/
    public String[][] getReportDataMatrix(boolean addTopEmptyLine) {
        // lines count = report size + 1 line for total, rows count = header size
        String[][] data   = new String[this.report.size() + (addTopEmptyLine ? 2 : 1)][REPORT_HEADER.length];
        // add top empty line - if parameter is true
        if (addTopEmptyLine) {
            data[0] = REPORT_EMPTY_LINE;
        }
        // put data into report matrix
        int counter = (addTopEmptyLine ? 1 : 0);
        boolean isCustomerNameAdded = false;
        for (Map.Entry entry : this.report.entrySet()) {
            data[counter][0] = null; // first column
            if (!isCustomerNameAdded) { // add customer name (second column)
                data[counter][1]    = this.customer.getName();
                isCustomerNameAdded = true;
            }
            // adding data
            ReportPosition position       = (ReportPosition) entry.getKey();
            BigDecimal     positionWeight = (BigDecimal)     entry.getValue();
            data[counter][2] = position.getOrderNumber();
            data[counter][3] = position.getSteelGrade();
            data[counter][4] = position.getSection();
            // position size
            Integer size1 = position.getSize1();
            Integer size2 = position.getSize2();
            String size = size1 + (size2 == null ? "" : ("x" + size2));
            data[counter][5] = size;
            data[counter][6] = REPORT_DATE_FORMAT.format(position.getWarehouseDate());
            data[counter][7] = positionWeight.toString();
            counter++; // rows counter
        }
        // adding total weight to last line
        data[counter] = new String[] {"Всего", null, null, null, null, null, null, this.totalWeight.toString()};
        return data;
    }

    /***/
    public static String[] getReportHeader() {
        return Arrays.copyOf(REPORT_HEADER, REPORT_HEADER.length); // defensive - no one can change header!
    }

    /***/
    public static String[] getReportEmptyLine() {
        return Arrays.copyOf(REPORT_EMPTY_LINE, REPORT_EMPTY_LINE.length); // defensive - no one can change empty line!
    }

    public CustomerDto getCustomer() {
        return customer;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("customer", customer)
                .append("report", report)
                .append("totalWeight", totalWeight)
                .toString();
    }

    /** just for test*/
    /*
    public static void main(String[] args) throws ParseException, InternalException {
        ReportPosition pos1 = new ReportPosition("40023203", "40ХФА", "круг", 65, null, new SimpleDateFormat("ddmmyyyy").parse("01012014"));
        ReportPosition pos2 = new ReportPosition("40023203", "СТ3СП", "полоса", 25, 65, new SimpleDateFormat("ddmmyyyy").parse("01012014"));
        System.out.println("1-> " + (pos1.equals(pos2)));
        System.out.println("2-> " + (pos1.hashCode() == pos2.hashCode()));
    }
    */

}