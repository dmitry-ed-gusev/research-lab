package ru.kzgroup.domain.dto.orders.ora;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for ORDER INGREDIENT (extra data in MES (Oracle)). Oracle -> TB_SM_ORD_INGR.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 08.07.2014)
*/

public class OrderIngredientDtoIdORA implements Serializable {

    private static final long serialVersionUID = 1L;

    private String orderYearMonth;      //
    private String orderNumber;         //
    private int    orderPosition;       //
    private String ingredientLatinName; // TB_SM_ORD_INGR->INGR_CD

    /** Default constructor (for Hibernate etc). */
    public OrderIngredientDtoIdORA() {}

    /** Full-init constructor - initializes all fields of object. */
    public OrderIngredientDtoIdORA(String orderYearMonth, String orderNumber, int orderPosition, String ingredientLatinName) {
        this.orderYearMonth      = orderYearMonth;
        this.orderNumber         = orderNumber;
        this.orderPosition       = orderPosition;
        this.ingredientLatinName = ingredientLatinName;
    }

    public String getOrderYearMonth() {
        return orderYearMonth;
    }

    public void setOrderYearMonth(String orderYearMonth) {
        this.orderYearMonth = orderYearMonth;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public int getOrderPosition() {
        return orderPosition;
    }

    public void setOrderPosition(int orderPosition) {
        this.orderPosition = orderPosition;
    }

    public String getIngredientLatinName() {
        return ingredientLatinName;
    }

    public void setIngredientLatinName(String ingredientLatinName) {
        this.ingredientLatinName = ingredientLatinName;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "ParameterNameDiffersFromOverriddenParameter", "QuestionableName", "RedundantIfStatement"})
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OrderIngredientDtoIdORA that = (OrderIngredientDtoIdORA) o;

        if (orderPosition != that.orderPosition) return false;
        if (!ingredientLatinName.equals(that.ingredientLatinName)) return false;
        if (!orderNumber.equals(that.orderNumber)) return false;
        if (!orderYearMonth.equals(that.orderYearMonth)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = orderYearMonth.hashCode();
        result = 31 * result + orderNumber.hashCode();
        result = 31 * result + orderPosition;
        result = 31 * result + ingredientLatinName.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("orderYearMonth", orderYearMonth)
                .append("orderNumber", orderNumber)
                .append("orderPosition", orderPosition)
                .append("ingredientLatinName", ingredientLatinName)
                .toString();
    }

}