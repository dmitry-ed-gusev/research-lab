package ru.kzgroup.dataProcessing;

/**
 * Common interface for one data processing component, that will work in seperate thread.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 31.07.13)
*/

public interface ProcessorInterface {

    public void process();

}