package ru.kzgroup.domain.dto.directories;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;
import ru.kzgroup.domain.dto.IAuditLog;

/**
 * CURRENCY - domain object.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 20.02.14)
*/

public class CurrencyDto extends BaseDto implements IAuditLog {

    private int     code;
    private String  name;
    private String  shortName;
    private int     units;
    private int     priorityCode;
    private Integer codeOKB;      // Integer instead of int due to possible null values in Paradox DB

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public int getUnits() {
        return units;
    }

    public void setUnits(int units) {
        this.units = units;
    }

    public int getPriorityCode() {
        return priorityCode;
    }

    public void setPriorityCode(int priorityCode) {
        this.priorityCode = priorityCode;
    }

    public Integer getCodeOKB() {
        return codeOKB;
    }

    public void setCodeOKB(Integer codeOKB) {
        this.codeOKB = codeOKB;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("code", code)
                .append("name", name)
                .append("shortName", shortName)
                .append("units", units)
                .append("priorityCode", priorityCode)
                .append("codeOKB", codeOKB)
                .toString();
    }

}