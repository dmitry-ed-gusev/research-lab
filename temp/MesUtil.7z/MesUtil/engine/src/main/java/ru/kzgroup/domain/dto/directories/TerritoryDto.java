package ru.kzgroup.domain.dto.directories;

import org.apache.commons.logging.LogFactory;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * TERRITORY - domain object. Paradox - F96008 (//pst-fs/asu/USERS/new/spz/NSI), Oracle - TB_DICT_TERRITORY.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 27.02.14)
*/

public class TerritoryDto extends BaseDto {

    private int     code;         // primary key
    private String  name;         //
    private int     codeCSU;      //
    private int     regionCode;   //
    private Integer customsGroup; //
    private Integer countryGroup; //
    private Integer countryCode;  //

    /** Default constructor (for Hibernate etc). */
    public TerritoryDto() {}

    /** Copying constructor. */
    public TerritoryDto(TerritoryDto territory) {
        if (territory != null) {
            this.code         = territory.getCode();
            this.name         = territory.getName();
            this.codeCSU      = territory.getCodeCSU();
            this.regionCode   = territory.getRegionCode();
            this.customsGroup = territory.getCustomsGroup();
            this.countryGroup = territory.getCountryGroup();
            this.countryCode  = territory.getCountryCode();
        } else {
            LogFactory.getLog(TerritoryDto.class).warn(String.format("Copy NULL object [%s]!", TerritoryDto.class));
            this.code         = 0;
            this.name         = null;
            this.codeCSU      = 0;
            this.regionCode   = 0;
            this.customsGroup = null;
            this.countryGroup = null;
            this.countryCode  = null;
        }
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCodeCSU() {
        return codeCSU;
    }

    public void setCodeCSU(int codeCSU) {
        this.codeCSU = codeCSU;
    }

    public int getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(int regionCode) {
        this.regionCode = regionCode;
    }

    public Integer getCustomsGroup() {
        return customsGroup;
    }

    public void setCustomsGroup(Integer customsGroup) {
        this.customsGroup = customsGroup;
    }

    public Integer getCountryGroup() {
        return countryGroup;
    }

    public void setCountryGroup(Integer countryGroup) {
        this.countryGroup = countryGroup;
    }

    public Integer getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(Integer countryCode) {
        this.countryCode = countryCode;
    }

}