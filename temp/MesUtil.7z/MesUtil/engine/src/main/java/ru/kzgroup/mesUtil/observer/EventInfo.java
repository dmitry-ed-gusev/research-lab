package ru.kzgroup.mesUtil.observer;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Event class for observer pattern. Holds info about observable object.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 08.05.13)
 */

public class EventInfo {

    private Log log = LogFactory.getLog(EventInfo.class);

    private String message;
    private int    progress;

    public EventInfo(String message, int progress) {
        log.debug("EventInfo constructor() working.");
        this.message = message;
        this.progress = progress;
    }

    public String getMessage() {
        return message;
    }

    public int getProgress() {
        return progress;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("message", message)
                .append("progress", progress)
                .toString();
    }

}