package ru.kzgroup.domain.dto.orders.pdx;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for ORDER domain object (for Paradox).
 * Warning: in MES and in ARM system primary keys are different!
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 02.06.2014)
*/

public class OrderDtoIdPDX implements Serializable {

    private static final long serialVersionUID = 1L;

    private int    orderYear;   // D8609151->OrderYear (pos 1),  TB_SM_ORDCOMM->X
    private String orderNumber; // D8609151->OrderNo (pos 2),    TB_SM_ORDCOMM->ORD_NO (pos 2)
    private int    orderMonth;  // D8609151->OrderMonth (pos 3), TB_SM_ORDCOMM->X

    public int getOrderYear() {
        return orderYear;
    }

    public void setOrderYear(int orderYear) {
        this.orderYear = orderYear;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public int getOrderMonth() {
        return orderMonth;
    }

    public void setOrderMonth(int orderMonth) {
        this.orderMonth = orderMonth;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement", "QuestionableName"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        OrderDtoIdPDX that = (OrderDtoIdPDX) obj;

        if (orderMonth != that.orderMonth) return false;
        if (orderYear != that.orderYear) return false;
        if (!orderNumber.equals(that.orderNumber)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = orderYear;
        result = 31 * result + orderNumber.hashCode();
        result = 31 * result + orderMonth;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("orderYear", orderYear)
                .append("orderNumber", orderNumber)
                .append("orderMonth", orderMonth)
                .toString();
    }

}