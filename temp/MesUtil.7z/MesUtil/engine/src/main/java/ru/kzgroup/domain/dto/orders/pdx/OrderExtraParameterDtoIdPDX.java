package ru.kzgroup.domain.dto.orders.pdx;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for order extra parameter - domain object.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 17.06.2014)
*/

public class OrderExtraParameterDtoIdPDX implements Serializable {

    private static final long serialVersionUID = 1L;

    private int    orderYear;
    private String orderNumber;
    private int    orderMonth;
    private int    orderPosition;
    private int    extraParameterNumber;

    public int getOrderYear() {
        return orderYear;
    }

    public void setOrderYear(int orderYear) {
        this.orderYear = orderYear;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public int getOrderMonth() {
        return orderMonth;
    }

    public void setOrderMonth(int orderMonth) {
        this.orderMonth = orderMonth;
    }

    public int getOrderPosition() {
        return orderPosition;
    }

    public void setOrderPosition(int orderPosition) {
        this.orderPosition = orderPosition;
    }

    public int getExtraParameterNumber() {
        return extraParameterNumber;
    }

    public void setExtraParameterNumber(int extraParameterNumber) {
        this.extraParameterNumber = extraParameterNumber;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement", "QuestionableName"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        OrderExtraParameterDtoIdPDX that = (OrderExtraParameterDtoIdPDX) obj;

        if (extraParameterNumber != that.extraParameterNumber) return false;
        if (orderMonth != that.orderMonth) return false;
        if (orderPosition != that.orderPosition) return false;
        if (orderYear != that.orderYear) return false;
        if (!orderNumber.equals(that.orderNumber)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = orderYear;
        result = 31 * result + orderNumber.hashCode();
        result = 31 * result + orderMonth;
        result = 31 * result + orderPosition;
        result = 31 * result + extraParameterNumber;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("orderYear", orderYear)
                .append("orderNumber", orderNumber)
                .append("orderMonth", orderMonth)
                .append("orderPosition", orderPosition)
                .append("extraParameterNumber", extraParameterNumber)
                .toString();
    }

}