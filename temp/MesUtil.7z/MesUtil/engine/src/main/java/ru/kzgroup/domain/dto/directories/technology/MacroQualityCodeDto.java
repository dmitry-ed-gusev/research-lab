package ru.kzgroup.domain.dto.directories.technology;

import org.apache.commons.lang3.builder.ToStringBuilder;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * One macro quality code - domain object.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 18.02.14)
*/

public class MacroQualityCodeDto extends BaseDto {

    private int    code;
    private String name;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("code", code)
                .append("name", name)
                .toString();
    }

}