package ru.kzgroup.domain.dao.personnel;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.exceptions.MesException;
import ru.kzgroup.domain.dto.personnel.ADUserInfoDto;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;
import java.util.Hashtable;

/**
 * Utility class for working with AD - get user information.
 * @author Gusev Dmitry (GusevD)
 * @version 1.0 (DATE: 16.08.12)
*/

public class ActiveDirectoryDao {

    private static Log log = LogFactory.getLog(ActiveDirectoryDao.class);

    // internal constants
    private static final String   LDAP_CONTEXT_FACTORY      = "com.sun.jndi.ldap.LdapCtxFactory";                 // LDAP context factory class
    private static final String   LDAP_BASE_DN              = "OU=Users,OU=ЗАО -Петросталь-,DC=kzgroup,DC=local"; // Distinguished Name
    private static final String   LDAP_USER_LOGIN_ATTRIBUTE = "samAccountName";
    private static final String   LDAP_USER_EMAIL_ATTRIBUTE = "mail";
    private static final String[] LDAP_ATTRIBUTES           = {/*"sn","givenName",*/ LDAP_USER_LOGIN_ATTRIBUTE, LDAP_USER_EMAIL_ATTRIBUTE};
    private static final String   LDAP_SEARCH_FILTER        = "(&(objectClass=user)&(cn=%s))";

    // object internal state
    private DirContext                ldapContext = null; // AD connection context
    private Hashtable<String, String> ldapEnv;            // AD connection parameters (LDAP)
    private SearchControls            searchControls;     // AD search controls

    /***/
    public ActiveDirectoryDao(ActiveDirectoryConfig adConfig) throws MesException {
        if (adConfig == null) {
            throw new MesException("Empty ActiveDirectory connection config!");
        }
        // init internal object state
        this.ldapEnv = new Hashtable<>(5);
        ldapEnv.put(Context.INITIAL_CONTEXT_FACTORY, LDAP_CONTEXT_FACTORY);
        ldapEnv.put(Context.PROVIDER_URL,            "ldap://" + adConfig.getAddress());
        ldapEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
        ldapEnv.put(Context.SECURITY_PRINCIPAL,      adConfig.getUsername() + "@kzgroup.local");
        ldapEnv.put(Context.SECURITY_CREDENTIALS,    adConfig.getPassword());
        // Create the search controls
        this.searchControls = new SearchControls();
        this.searchControls.setReturningAttributes(LDAP_ATTRIBUTES);
        //Specify the search scope
        this.searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
    }

    /***/
    public void ldapConnect() throws NamingException {
        log.debug("ActiveDirectoryDao.ldapConnect() working.");
        if (this.ldapContext == null) { // we are not connected yet
            this.ldapContext = new InitialDirContext(this.ldapEnv);
            log.debug("ActiveDirectory: connected.");
        } else { // we are already connected
            log.warn("ActiveDirectory: already connected!");
        }
    }

    /***/
    public void ldapDisconnect() throws NamingException {
        log.debug("ActiveDirectoryDao.ldapDisconnect() working.");
        if (this.ldapContext != null) { // we are connected - disconnect
            this.ldapContext.close();
            this.ldapContext = null;  // mark as not connected
            log.debug("ActiveDirectory: disconnected.");
        } else { // we are not connected - we can't disconnect
            log.warn("ActiveDirectory: already disconnected!");
        }
    }

    /***/
    public ADUserInfoDto getADUserInfo(String userFullName) throws NamingException {
        //log.debug("ActiveDirectoryDao.getADUserLogin() working."); // -> too much output
        ADUserInfoDto adInfo; // found user info
        if (!StringUtils.isBlank(userFullName)) { // if user name isn't empty - search for login
            //log.debug("Full user name [" + userFullName + "] is OK. Searching in AD."); // -> too much output
            // search for login
            NamingEnumeration<SearchResult> answer = this.ldapContext.search(LDAP_BASE_DN,
                    String.format(LDAP_SEARCH_FILTER, userFullName), this.searchControls);
            // we will get just first found element (we can find more than one element!)
            if (answer.hasMoreElements()) {
                // process result
                SearchResult sr = answer.next();
                //log.debug("Found -> " + sr.getName()); // -> too much output
                // result attributes
                Attributes attrs = sr.getAttributes();
                String login;
                String email;
                // get login value
                Attribute loginAttribute = attrs.get(LDAP_USER_LOGIN_ATTRIBUTE);
                if (loginAttribute != null) {
                    String userLoginAttribute = loginAttribute.toString();
                    int delimiterIndex = userLoginAttribute.indexOf(":");
                    if (delimiterIndex >= 0) { // delimiter is present
                        login = userLoginAttribute.substring(delimiterIndex + 1, userLoginAttribute.length()).trim();
                    } else { // no delimiter - how to get login info???
                        log.warn("No delimiter symbol [:] in userLoginAttribute = [" + userLoginAttribute + "].");
                        login = "";
                    }
                } else {
                    log.debug("There is no login attribute for user [" + userFullName + "].");
                    login = "";
                }
                // get email value
                Attribute emailAttribute = attrs.get(LDAP_USER_EMAIL_ATTRIBUTE);
                if (emailAttribute != null) {
                    String userEmailAttribute = emailAttribute.toString();
                    int delimiterIndex = userEmailAttribute.indexOf(":");
                    if (delimiterIndex >= 0) { // delimiter present
                        email = userEmailAttribute.substring(delimiterIndex + 1, userEmailAttribute.length()).trim();
                    } else { // no delimiter
                        log.warn("No delimiter symbol [:] in userEmailAttribute = [" + userEmailAttribute + "].");
                        email = "";
                    }
                } else {
                    log.debug("There is no email attribute for user [" + userFullName + "].");
                    email = "";
                }
                // creating result object
                adInfo = new ADUserInfoDto(userFullName, login, email);
            } else { // nothing found
                //log.debug("No data found for user [" + userFullName + "]."); // -> too much output
                adInfo = null;
            }
        } else { // empty user name for search
            adInfo = null;
            log.warn("Can't find login for empty user name!");
        }

        return adInfo;
    }

    /** This method is just for test! */
    /*
    public static void main(String[] args) throws MesException, NamingException {
        Log log = LogFactory.getLog(ActiveDirectoryDao.class);
        PropertyConfigurator.configure("engine/src/main/resources/log4j.properties");
        log.info("ActiveDirectoryDao main mathod started.");
        //
        ActiveDirectoryConfig adConfig = new ActiveDirectoryConfig("172.16.0.20:389", "MESSystem", "tky4582e");
        ActiveDirectoryDao    adDao    = new ActiveDirectoryDao(adConfig);
        //
        adDao.ldapConnect();
        ADUserInfoDto adUserInfoDto = adDao.getADUserInfo("Гусев Дмитрий Эдуардович");
        //ADUserInfoDto adUserInfoDto = adDao.getADUserInfo("вввв");
        adDao.ldapDisconnect();
        //
        log.info("-> " + adUserInfoDto);
    }
    */

}