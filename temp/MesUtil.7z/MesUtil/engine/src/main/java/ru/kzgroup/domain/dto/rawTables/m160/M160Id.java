package ru.kzgroup.domain.dto.rawTables.m160;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Composite primary key for table M160. No one of fields can be null (empty), otherwise -
 * result is unknown (NPE or data inconsistency).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 08.05.2014)
*/

public class M160Id implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer year;             // Год
    private Integer workCardNumber;   // N_раб_карты
    private Integer workCardPosition; // WorkTicketStringNo
    private Integer waybillNumber;    // N_накл

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getWorkCardNumber() {
        return workCardNumber;
    }

    public void setWorkCardNumber(Integer workCardNumber) {
        this.workCardNumber = workCardNumber;
    }

    public Integer getWorkCardPosition() {
        return workCardPosition;
    }

    public void setWorkCardPosition(Integer workCardPosition) {
        this.workCardPosition = workCardPosition;
    }

    public Integer getWaybillNumber() {
        return waybillNumber;
    }

    public void setWaybillNumber(Integer waybillNumber) {
        this.waybillNumber = waybillNumber;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        M160Id m160Id = (M160Id) obj;

        if (!waybillNumber.equals(m160Id.waybillNumber)) return false;
        if (!workCardNumber.equals(m160Id.workCardNumber)) return false;
        if (!workCardPosition.equals(m160Id.workCardPosition)) return false;
        if (!year.equals(m160Id.year)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = year.hashCode();
        result = 31 * result + workCardNumber.hashCode();
        result = 31 * result + workCardPosition.hashCode();
        result = 31 * result + waybillNumber.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("year", year)
                .append("workCardNumber", workCardNumber)
                .append("workCardPosition", workCardPosition)
                .append("waybillNumber", waybillNumber)
                .toString();
    }

}