package ru.kzgroup.domain.dto.scrap;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.text.DecimalFormat;

import static ru.kzgroup.MesUtilDefaults.TELEGRAMS_TABLE_NAME;
import static ru.kzgroup.MesUtilDefaults.SCRAP_TELEGRAM_NAME;

/**
 * One metal filling object (объект - одна металлозавалка).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 29.07.13)
*/

public final class MetalFilling {

    // format of total weight value in MES DB (interface table)
    private static final DecimalFormat TOTAL_WEIGHT_DB_FORMAT = new DecimalFormat("00000");
    // format of weighing key value in MES DB (interface table)
    private static final DecimalFormat WEIGHING_KEY_DB_FORMAT = new DecimalFormat("000000000");

    private int    key;
    private int    meltNumber;
    private String weighingDate;
    private String weighingSign;
    private int    scrapCode;
    private String scrapName;
    private int    totalWeight;    // total
    private int    netWeight;      // чистый вес
    private int    moldWeight;     // вес пустых мульд
    private int    moldCount;      // кол-во мульд
    private int    furnanceNumber; // furnance number
    private String weigher;        // weigher - south (S) or north (N)


    public MetalFilling(int key, int meltNumber, String weighingDate, String weighingSign, int scrapCode,
                        String scrapName, int totalWeight, int netWeight, int moldWeight, int moldCount,
                        int furnanceNumber, String weigher) {
        this.key            = key;
        this.meltNumber     = meltNumber;
        this.weighingDate   = weighingDate;
        this.weighingSign   = weighingSign;
        this.scrapCode      = scrapCode;
        this.scrapName      = scrapName;
        this.totalWeight    = totalWeight;
        this.netWeight      = netWeight;
        this.moldWeight     = moldWeight;
        this.moldCount      = moldCount;
        this.furnanceNumber = furnanceNumber;
        this.weigher        = weigher;
    }

    /***/
    public String getInsertSql() {
        StringBuilder sql = new StringBuilder();

        // Some data preparation (for MES DB):
        // 1. Total weight should be 5 digits length
        String strTotalWeight = TOTAL_WEIGHT_DB_FORMAT.format(this.totalWeight);
        // 2. key value should be 9 digits length
        String strKey         = WEIGHING_KEY_DB_FORMAT.format(this.key);
        // 3. calculating mold (busket) type - it depends on mold weight
        int moldType;
        if (this.moldWeight >= 3201 && this.moldWeight <= 3700) {
            moldType = 3;
        } else if (this.moldWeight >= 2900 && this.moldWeight <= 3200) {
            moldType = 1;
        } else if (this.moldWeight >= 1800 && this.moldWeight <= 2899) {
            moldType = 2;
        } else if (this.moldWeight >= 6800 && this.moldWeight <= 7900) {
            moldType = 7;
        } else {
            moldType = 0;
        }

        // generating sql query
        sql.append("insert into ").append(TELEGRAMS_TABLE_NAME).append("(SEQUENCE_KEY, TC_ID, ITEM, ITEM_1, ITEM_2, ITEM_3, ITEM_4, ITEM_5, ")
                .append("ITEM_6, ITEM_7, ITEM_8, ITEM_9, ITEM_10, ITEM_11) values (SEQUENCE_KEY.NEXTVAL, '").append(SCRAP_TELEGRAM_NAME)
                .append("', '").append(meltNumber).append("', '").append(furnanceNumber).append("', '").append(moldType).append("', '")
                .append(moldCount).append("', '").append(strTotalWeight).append("', '").append(netWeight).append("', '").append(moldWeight)
                .append("', '").append(weigher).append("', '").append(scrapCode).append("', '").append(weighingDate).append("', '")
                .append(strKey).append("', '").append(weighingSign).append("')");

        return sql.toString();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SIMPLE_STYLE)
                .append("key", key)
                .append("meltNumber", meltNumber)
                .append("weighingDate", weighingDate)
                .append("weighingSign", weighingSign)
                .append("scrapCode", scrapCode)
                .append("scrapName", scrapName)
                .append("totalWeight", totalWeight)
                .append("netWeight", netWeight)
                .append("moldWeight", moldWeight)
                .append("moldCount", moldCount)
                .append("furnanceNumber", furnanceNumber)
                .append("weigher", weigher)
                .toString();
    }

}