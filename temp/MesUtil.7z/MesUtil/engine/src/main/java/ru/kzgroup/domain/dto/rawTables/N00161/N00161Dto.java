package ru.kzgroup.domain.dto.rawTables.N00161;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.domain.dto.BaseDto;

import java.math.BigDecimal;

/**
 * Raw ARM table N00161.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 13.08.2014)
*/

public class N00161Dto extends BaseDto {

    private N00161DtoId id;
    private String      nameParameter;
    private String      idParameter;
    private BigDecimal  valueParameter;

    public N00161DtoId getId() {
        return id;
    }

    public void setId(N00161DtoId id) {
        this.id = id;
    }

    public String getNameParameter() {
        return nameParameter;
    }

    public void setNameParameter(String nameParameter) {
        this.nameParameter = nameParameter;
    }

    public String getIdParameter() {
        return idParameter;
    }

    public void setIdParameter(String idParameter) {
        this.idParameter = idParameter;
    }

    public BigDecimal getValueParameter() {
        return valueParameter;
    }

    public void setValueParameter(BigDecimal valueParameter) {
        this.valueParameter = valueParameter;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("id", id)
                .append("nameParameter", nameParameter)
                .append("idParameter", idParameter)
                .append("valueParameter", valueParameter)
                .toString();
    }

}