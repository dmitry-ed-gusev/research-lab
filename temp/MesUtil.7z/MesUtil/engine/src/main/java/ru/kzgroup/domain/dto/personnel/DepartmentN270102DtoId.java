package ru.kzgroup.domain.dto.personnel;

import java.io.Serializable;

/**
 * Composite primary key for domain object DepartmentN270102Dto.
 * Table //pst-fs/users/new/otep/nsi/N270102.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 01.04.2014)
*/

public class DepartmentN270102DtoId implements Serializable {

    private static final long serialVersionUID = 1L;

    private int registeredShopNumber; // (N270102->RegShopNo)
    private int registeredDeptNumber; // (N270102->RegDepNo)

    public int getRegisteredShopNumber() {
        return registeredShopNumber;
    }

    public void setRegisteredShopNumber(int registeredShopNumber) {
        this.registeredShopNumber = registeredShopNumber;
    }

    public int getRegisteredDeptNumber() {
        return registeredDeptNumber;
    }

    public void setRegisteredDeptNumber(int registeredDeptNumber) {
        this.registeredDeptNumber = registeredDeptNumber;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "ParameterNameDiffersFromOverriddenParameter", "RedundantIfStatement", "QuestionableName"})
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DepartmentN270102DtoId that = (DepartmentN270102DtoId) o;
        if (registeredDeptNumber != that.registeredDeptNumber) return false;
        if (registeredShopNumber != that.registeredShopNumber) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = registeredShopNumber;
        result = 31 * result + registeredDeptNumber;
        return result;
    }

}