package ru.kzgroup.domain.dto.directories;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

/**
 * Static data for bundle weight standards. Paradox (ARMs) - ?, MES - TB_PM_BUNDLE_WEIGHT_STD
 * (MES screen: Order->Standard->[1018] Bundle Weight&Binding).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 10.07.2014)
*/

public enum BundleWeightStd {

    BD_0_400  ("BD", 0, 400, 100, 100),  // полоса
    SB_0_600  ("SB", 0, 600, 200, 250),  // квадрат (square bar)
    RB_0_120  ("RB", 0, 120, 0, 5000),   // круг (round bar)
    RB_120_200("RB", 120, 200, 0, 5000), // круг (round bar)
    RB_200_250("RB", 200, 250, 0, 5000); // круг (round bar)

    /** Constructor. */
    private BundleWeightStd(String sectionType, int sectionSizeT1, int sectionSizeT2, int bundleWeightMin, int bundleWeightMax) {
        this.sectionType = sectionType;
        this.sectionSizeT1 = sectionSizeT1;
        this.sectionSizeT2 = sectionSizeT2;
        this.bundleWeightMin = bundleWeightMin;
        this.bundleWeightMax = bundleWeightMax;
    }

    private String sectionType;
    private int    sectionSizeT1;
    private int    sectionSizeT2;
    private int    bundleWeightMin;
    private int    bundleWeightMax;

    public String getSectionType() {
        return sectionType;
    }

    public int getSectionSizeT1() {
        return sectionSizeT1;
    }

    public int getSectionSizeT2() {
        return sectionSizeT2;
    }

    public int getBundleWeightMin() {
        return bundleWeightMin;
    }

    public int getBundleWeightMax() {
        return bundleWeightMax;
    }

    /***/
    public static Pair<Integer, Integer> getBundleWeight(String sectionType, int size) {
        Pair<Integer, Integer> result = null;
        if (!StringUtils.isBlank(sectionType) && size >= 0) {
            BundleWeightStd[] standards = BundleWeightStd.values();
            int     counter = 0;
            boolean isFound = false;
            while (counter < standards.length && !isFound) {
                String section = standards[counter].getSectionType();
                int    t1      = standards[counter].getSectionSizeT1();
                int    t2      = standards[counter].getSectionSizeT2();
                if (section.equalsIgnoreCase(StringUtils.trimToEmpty(sectionType)) && (t1 < size) && (size <= t2)) {
                    result = new ImmutablePair<>(standards[counter].getBundleWeightMin(), standards[counter].getBundleWeightMax());
                    isFound = true;
                }
                counter++;
            }
        }
        return result;
    }

}