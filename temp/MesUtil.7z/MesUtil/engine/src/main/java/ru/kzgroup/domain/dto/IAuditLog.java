package ru.kzgroup.domain.dto;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 29.07.2014)
*/

public interface IAuditLog {}