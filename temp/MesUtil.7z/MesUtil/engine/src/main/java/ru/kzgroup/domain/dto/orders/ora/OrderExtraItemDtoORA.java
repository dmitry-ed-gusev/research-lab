package ru.kzgroup.domain.dto.orders.ora;

import org.apache.commons.lang3.builder.ToStringBuilder;
import ru.kzgroup.domain.dto.BaseDto;

/**
 * ORDER EXTRA ITEM - domain object (extra data in MES (Oracle)). Oracle -> TB_SM_ORD_EXTRA_ITEM.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 08.07.2014)
*/

public class OrderExtraItemDtoORA extends BaseDto {

    private OrderExtraItemDtoIdORA id;       // composite primary key for object
    private String                 itemName; //

    /** Default constructor. */
    public OrderExtraItemDtoORA() {}

    /***/
    public OrderExtraItemDtoORA(OrderExtraItemDtoIdORA id, String itemName) {
        this.id       = id;
        this.itemName = itemName;
    }

    public OrderExtraItemDtoIdORA getId() {
        return id;
    }

    public void setId(OrderExtraItemDtoIdORA id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "RedundantIfStatement", "QuestionableName", "ParameterNameDiffersFromOverriddenParameter"})
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OrderExtraItemDtoORA that = (OrderExtraItemDtoORA) o;

        if (!id.equals(that.id)) return false;
        if (itemName != null ? !itemName.equals(that.itemName) : that.itemName != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id.hashCode();
        result = 31 * result + (itemName != null ? itemName.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("id", id)
                .append("itemName", itemName)
                .toString();
    }

}