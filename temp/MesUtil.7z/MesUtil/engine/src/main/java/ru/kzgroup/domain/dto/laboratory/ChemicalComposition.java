package ru.kzgroup.domain.dto.laboratory;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.MesUtilDefaults;

import java.util.Map;

/**
 * One chemical test result object (объект - одна хим. проба). This object is related to record format in
 * LAB100 hardware chemical analyzer.
 *
 * @author Gusev Dmitry (GusevD)
 * @version 1.0 (DATE: 24.07.13)
*/

public final class ChemicalComposition {

    // zero value for values (we need exactly this format - x.xxxx - for MES DB)
    public static final String   ZERO_VALUE = "0.0000";

    // Order for inserting elements in MES data telegrams table. For elements C-Sn we get real data,
    // for elements As-Cequ we use value '000000'.
    private static final String[] CHEMICAL_ELEMENTS = new String[] {"C", "Si", "Mn", "S", "P", "Cr", "Ni", "Cu", "W", "Mo", "V", "Al",
            "Ti", "B", "Nb", "Pb", "N", "Sn", "As", "H2", "O2", "Zn", "Sb", "Ca", "Cequ"};
    // Special element name - all elements after it should have value = '000000' (six zeroes) - see comment above
    private static final String   SPECIAL_ELEMENT   = "As";

    // data fields for this object
    private String              chemicalTestDate; // date of test (date+time)
    private String              meltNumber;       // melt number
    private String              meltSequence;     // melt sequence number
    private String              meltType;         // type -> MPT (SIEM1-SIEM4)/LADLE/POURI
    private Map<String, String> chemicalData;     // key -> element name, value -> element amount in the test

    /***/
    public ChemicalComposition(String chemicalTestDate, String meltNumber, String meltSequence, Map<String, String> chemicalData) {

        Log log = LogFactory.getLog(ChemicalComposition.class);

        // check input data
        if (StringUtils.isBlank(chemicalTestDate) || StringUtils.isBlank(meltNumber) || StringUtils.isBlank(meltSequence) ||
                chemicalData == null || chemicalData.isEmpty()) {
            throw new IllegalStateException("One of parameters is empty!");
        }

        // data is ok processing
        this.chemicalTestDate = chemicalTestDate;
        this.meltNumber       = meltNumber;
        this.meltSequence     = meltSequence;

        // Determine type of chemical test - MPT/LADLE/POURI (мартен/ковшевая/разливочная)
        // We have 4 MPT furnances, first letter in melt number means MPT number: 5 -> MPT1, 6 -> MPT2,
        // 7 -> MPT3, 8 -> MPT4. For MPTs we will use values: SIEM1, SIEM2, SIEM3, SIEM4.
        if (meltSequence.equals("KZ") || meltSequence.equals("4C") || meltSequence.equals("5C") ||
                meltSequence.equals("6C") || meltSequence.equals("7C")) {
            this.meltType = "POURI"; // POURI (разливочная проба с сифонов)
            // LADLE (ковшевая проба с печи-ковша, АКОС) - ladle test sequence will ends with A symbol - US or RU.
        } else if (meltSequence.toUpperCase().endsWith("A") ||     // english A
                meltSequence.toUpperCase().endsWith("А")) {        // russian A
            this.meltType = "LADLE";
        } else { // MPT (мартеновская плавочная проба) - not pouring and not ladle => MPT
            // select MPT number
            switch (this.meltNumber.charAt(0)) {
                case '5': this.meltType = "SIEM1"; break;
                case '6': this.meltType = "SIEM2"; break;
                case '7': this.meltType = "SIEM3"; break;
                case '8': this.meltType = "SIEM4"; break;
                default :
                    //log.debug("Check type of this chemical test [" + this.meltNumber + "-" + this.meltSequence + "]!"); // -> to much output
                    this.meltType = "LADLE";
            }
        }

        this.chemicalData = chemicalData;
    }

    public String getMeltSequence() {
        return meltSequence;
    }

    /**
     * Method returns sql query for inserting this object (its data) into MES DB telegrams table.
    */
    public String getInsertSql() {
        StringBuilder sql = new StringBuilder();
        sql.append("insert into ").append(MesUtilDefaults.TELEGRAMS_TABLE_NAME).append("(SEQUENCE_KEY, TC_ID, ITEM, ");

        // first part of sql query
        for (int i = 1; i <= 29; i++) {
            sql.append("ITEM_").append(i);
            if (i < 29) {
                sql.append(", ");
            }
        }

        // values for sql query
        sql.append(") values (SEQUENCE_KEY.NEXTVAL, '").append(MesUtilDefaults.LAB100_TELEGRAM_NAME).append("', '").append(meltNumber);
        sql.append("', '").append(meltSequence).append("', '").append(meltType).append("', '").append(chemicalTestDate).append("', ");

        // elements values
        boolean zeroValue = false;
        for (String element : CHEMICAL_ELEMENTS) {

            // check for special element - see comments above (in fields/constants definitions)
            if (SPECIAL_ELEMENT.equals(element)) {
                zeroValue = true;
            }

            // element value
            String elementValue;
            if (zeroValue) {
                elementValue = ZERO_VALUE;
            } else {
                // protection for final value from empty/null values (bulletproof code :) )
                String tmpValue = chemicalData.get(element);
                if (!StringUtils.isBlank(tmpValue)) {
                    elementValue = tmpValue;
                } else {
                    elementValue = ZERO_VALUE;
                }
            }
            // sql.append("'").append(element + " -> ").append(elementValue).append("', "); // <- sql just for test!!!
            sql.append("'").append(elementValue).append("', ");
        }
        // tail of sql query
        sql.append("'").append(chemicalTestDate).append("')");

        return sql.toString();
    }

}