package ru.kzgroup.domain.dto.goods;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.logging.LogFactory;

import java.io.Serializable;

/**
 * ONE FINISHED GOODS ITEM - domain object - composite primary key. ARM -> M149, MES ->
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 20.03.2014)
*/

public class FinishedGoodsItemDtoId implements Serializable {

    private static final long serialVersionUID = 1L;

    private int workCardYear;   // M149->ГодРК
    private int workCardNumber; // M149->РК
    private int waybillNumber;  // M149->Накладная

    /** Default constructor (for Hibernate etc). */
    public FinishedGoodsItemDtoId() {}

    /** Copying constructor. */
    public FinishedGoodsItemDtoId(FinishedGoodsItemDtoId finishedGoodsItemDtoId) {
        if (finishedGoodsItemDtoId != null) {
            this.workCardYear   = finishedGoodsItemDtoId.getWorkCardYear();
            this.workCardNumber = finishedGoodsItemDtoId.getWorkCardNumber();
            this.waybillNumber  = finishedGoodsItemDtoId.getWaybillNumber();
        } else {
            LogFactory.getLog(FinishedGoodsItemDtoId.class).warn(String.format("Copy NULL object [%s]!", FinishedGoodsItemDtoId.class));
            this.workCardYear   = 0;
            this.workCardNumber = 0;
            this.waybillNumber  = 0;
        }
    }

    public int getWorkCardYear() {
        return workCardYear;
    }

    public void setWorkCardYear(int workCardYear) {
        this.workCardYear = workCardYear;
    }

    public int getWorkCardNumber() {
        return workCardNumber;
    }

    public void setWorkCardNumber(int workCardNumber) {
        this.workCardNumber = workCardNumber;
    }

    public int getWaybillNumber() {
        return waybillNumber;
    }

    public void setWaybillNumber(int waybillNumber) {
        this.waybillNumber = waybillNumber;
    }

    @Override
    @SuppressWarnings({"MethodWithMultipleReturnPoints", "ParameterNameDiffersFromOverriddenParameter", "RedundantIfStatement", "QuestionableName"})
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FinishedGoodsItemDtoId that = (FinishedGoodsItemDtoId) o;

        if (waybillNumber != that.waybillNumber) return false;
        if (workCardNumber != that.workCardNumber) return false;
        if (workCardYear != that.workCardYear) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = workCardYear;
        result = 31 * result + workCardNumber;
        result = 31 * result + waybillNumber;
        return result;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("workCardYear", workCardYear)
                .append("workCardNumber", workCardNumber)
                .append("waybillNumber", waybillNumber)
                .toString();
    }

}