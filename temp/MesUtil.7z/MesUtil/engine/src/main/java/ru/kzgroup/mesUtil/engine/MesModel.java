package ru.kzgroup.mesUtil.engine;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 06.05.13)
 */
public class MesModel {
}
