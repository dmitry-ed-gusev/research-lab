package ru.kzgroup.mesUtil.engine.db;

import gusev.dmitry.jtils.JTilsException;
import gusev.dmitry.jtils.db.OraDbConfig;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.exceptions.MesException;

import java.io.IOException;
import java.sql.*;
import java.util.Map;
import java.util.TreeMap;

import static ru.kzgroup.MesUtilDefaults.DBOBJECT_TYPE;

/**
 * Class for analizing MES database on Oracle server.
 * Date: 10.05.13
*/

public class MesDbAnalizer extends AbstractDbAnalizer {

    private static Log log = LogFactory.getLog(MesDbAnalizer.class);

    // config for connecting to MES database
    private OraDbConfig oraDbConfig;

    /**
     * Constructor throws IllegalArgumentException, if OraDbConfig argument is null. It guarantees
     * proper configuration for this module.
    */
    public MesDbAnalizer(OraDbConfig oraDbConfig) {
        if (oraDbConfig != null) {
            this.oraDbConfig = oraDbConfig;
        } else {
            throw new IllegalArgumentException("OraDbConfig is NULL!");
        }
    }

    /***/
    @Override
    public Map<String, DBOBJECT_TYPE> getDbObjects() throws MesException {
        log.debug("MesDbAnalizer.getDBObjects() working.");
        Map<String, DBOBJECT_TYPE> dbObjects = new TreeMap<String, DBOBJECT_TYPE>();

        Connection connection = null;
        try {
            //String url = "jdbc:oracle:thin:@//" + oraDbConfig.getOraDbAddress() + "/" + oraDbConfig.getOraDbServiceName();
            connection = DriverManager.getConnection(/*url*/oraDbConfig.getConnectionUrl(), oraDbConfig.getOraDbUser(), oraDbConfig.getOraDbPass());
            if (connection != null) {
                log.debug("Successfully connected to DB!");
                DatabaseMetaData dbmeta = connection.getMetaData();
                // get tables list
                ResultSet tablesRs = dbmeta.getTables(null, "PMES", null, null);
                if (tablesRs.next()) { // some data exists
                    do {
                        //String res = String.format("%-50s|%-30s|%-10s", rs.getString("TABLE_NAME"), rs.getString("TABLE_CAT"), rs.getString("TABLE_SCHEM"));
                        dbObjects.put(tablesRs.getString("TABLE_NAME"), DBOBJECT_TYPE.TABLE);
                    } while (tablesRs.next());
                } else { // no data
                    log.error("No data about tables found!");
                }

                // get procedures list (this list includes functions too)
                ResultSet proceduresRs= dbmeta.getProcedures(null, "PMES", null);
                if (proceduresRs.next()) { // some data exists
                    do {
                        //String res = String.format("%-50s|%-30s|%-10s|%-10s", rs.getString("PROCEDURE_NAME"), rs.getString("PROCEDURE_CAT"),
                        //        rs.getString("PROCEDURE_SCHEM"), rs.getString("PROCEDURE_TYPE"));
                        short type = proceduresRs.getShort("PROCEDURE_TYPE");
                        switch (type) {
                            case DatabaseMetaData.procedureNoResult:
                                dbObjects.put(proceduresRs.getString("PROCEDURE_NAME"), DBOBJECT_TYPE.PROCEDURE);
                                break;
                            case DatabaseMetaData.procedureReturnsResult :
                                dbObjects.put(proceduresRs.getString("PROCEDURE_NAME"), DBOBJECT_TYPE.FUNCTION);
                                break;
                            default:
                                dbObjects.put(proceduresRs.getString("PROCEDURE_NAME"), DBOBJECT_TYPE.UNKNOWN);
                        }
                    } while (proceduresRs.next());
                } else { // no data
                    log.error("No data about procedures/functions found!");
                }

            } else {
                log.fatal("Connection not established!");
            }
        } catch (SQLException e) {
            throw new MesException(e);
        } finally { // we should close all used resources!
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    log.fatal("Can't close connection to DBMS! Reason: " + e.getMessage());
                }
            }
        }
        return dbObjects;
    }

    /***/
    public static void main(String[] args) throws JTilsException {
        Log log = LogFactory.getLog(MesDbAnalizer.class);
        log.info("Starting MES DB analizer.");
        //List<String> tables = MesDbAnalizer.getTablesListFromScript("c:/temp/pmesdb/tables.sql");
        //log.info("--->\n" + tables);

        try {
            OraDbConfig config = new OraDbConfig("172.16.0.81:1521", "PMES", "PMES", "pmes1234");
            MesDbAnalizer dbAnalizer = new MesDbAnalizer(config);
            dbAnalizer.saveDBObjectsList("mes_db_objects.db");
            //System.out.println(dbAnalizer.getDBObjects());
        } catch (MesException e) {
            log.error(e.getMessage());
        } catch (IOException e) {
            log.error(e.getMessage());
        }

    }

}