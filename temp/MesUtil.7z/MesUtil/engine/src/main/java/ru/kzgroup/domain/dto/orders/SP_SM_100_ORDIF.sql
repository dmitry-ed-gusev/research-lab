create or replace
PROCEDURE      SP_SM_100_ORDIF (IN_DUMMY         IN  VARCHAR2
                                                 ,W_ERR_CODE       OUT VARCHAR2
                                                 ,W_ERR_MSG        OUT VARCHAR2 )
 IS
 /*--------------------------------------------------------------------------------------
 * PROGAM NAME       : SP_SM_100_ORDIF
 * VERSION           : V1.00
 * DESCRIPTION       : TB_SM_ORDCOMM_INTERFACE --> TB_SM_ORDCOMM
 * DEVELOPER NAME    : Lee
 * CREATE DATE       : 03.07.2012
 * MODIFY DATE       :
 */--------------------------------------------------------------------------------------

ERROR_RTN                      EXCEPTION;

--W_ERR_CODE                     NUMBER;
W_TB_ERR_MSG                   TB_SM_ORDDTL.ERR_MSG%TYPE;

W_PGM_ID                       TB_CM_ERR_LOGMGMT.PGM_ID%TYPE := 'SP_SM_100_ORDIF';

W_SECTION_TYPE                 TB_SM_ORDDTL.SECTION_TYPE%TYPE;
W_ORD_WT_MIN                   TB_SM_ORDDTL.ORD_WT%TYPE;
W_DELIVER_TOLERANCE_MIN        TB_SM_ORDDTL.DELIVER_TOLERANCE_MIN%TYPE;
W_DELIVER_TOLERANCE_MAX        TB_SM_ORDDTL.DELIVER_TOLERANCE_MAX%TYPE;
W_ROLL_SECTION_SIZE_T          TB_SM_ORDDTL.ROLL_SECTION_SIZE_T%TYPE;
W_ROLL_SECTION_SIZE_W          TB_SM_ORDDTL.ROLL_SECTION_SIZE_T%TYPE;
W_ORD_PROG_CD                  TB_SM_ORDDTL.ORD_PROG_CD%TYPE;
W_R680_SECTION_TYPE            TB_SM_ORDDTL.R680_SECTION_TYPE%TYPE;
W_R680_SECTION_SIZE_T          TB_SM_ORDDTL.R680_SECTION_SIZE_T%TYPE;
W_R680_SECTION_SIZE_W          TB_SM_ORDDTL.R680_SECTION_SIZE_W%TYPE;
W_R350_SECTION_TYPE            TB_SM_ORDDTL.R350_SECTION_TYPE%TYPE;
W_R350_SECTION_SIZE_T          TB_SM_ORDDTL.R350_SECTION_SIZE_T%TYPE;
W_R350_SECTION_SIZE_W          TB_SM_ORDDTL.R350_SECTION_SIZE_W%TYPE;
W_ROLL_SECTION_SIZE_T1         TB_SM_ORDDTL.ROLL_SECTION_SIZE_T1%TYPE;
W_ROLL_SECTION_SIZE_T2         TB_SM_ORDDTL.ROLL_SECTION_SIZE_T1%TYPE;
W_ROLL_SECTION_SIZE_T3         TB_SM_ORDDTL.ROLL_SECTION_SIZE_T1%TYPE;
W_ORD_SHORT_LEN_MIN            TB_SM_ORDDTL.ORD_SHORT_LEN_MIN%TYPE;
W_ORD_SHORT_LEN_ALLOW_RATE     TB_SM_ORDDTL.ORD_SHORT_LEN_ALLOW_RATE%TYPE;
W_MILL900_350_COMM_SIZE_YN     TB_SM_ORDDTL.MILL900_350_COMM_SIZE_YN%TYPE;
W_QUALITY_DESIGN_YN            TB_SM_ORDDTL.QUALITY_DESIGN_YN%TYPE;


W_ORD_NO                       VARCHAR2(10);
W_ORD_NO_NUM                   NUMBER;


W_COUNT                        NUMBER;
W_EXIST_COUNT                  NUMBER;
W_POSITION_COUNT               NUMBER;
W_INTERFACE_EXECUTION_STATUS   VARCHAR2(1);
W_TURN_B2                      VARCHAR2(1);
W_REGION_CD                    NUMBER;
W_CUSTOMER_CD                  VARCHAR2(10);
W_CONTINUE_YN                  VARCHAR2(1);
W_COMM_ERR_YN                  VARCHAR2(1);

BEGIN

   FOR C1 IN (SELECT A.SEQUENCE_KEY
                    ,A.PROD_YYMM
                    ,A.CONTRACT_ORD_NO
                    ,A.INTERFACE_GP
                    ,A.ORD_GP
                    ,A.CUSTOMER_CD
                    ,A.CUSTOMER_NAME
                    ,A.CUSTOMER_ADDRESS_RUS
                    ,A.CUSTOMER_ADDRESS_ENG
                    ,A.CUSTOMER_COUNTRY_CD
                    ,A.CUSTOMER_COUNTRY_NAME
                    ,A.CUSTOMER_CITY_CD
                    ,A.CUSTOMER_CITY_NAME
                    ,A.CONSIGNEE_CD
                    ,A.CONSIGNEE_NAME
                    ,A.CONSIGNEE_ADDRESS_RUS
                    ,A.CONSIGNEE_ADDRESS_ENG
                    ,A.CONSIGNEE_COUNTRY_CD
                    ,A.CONSIGNEE_COUNTRY_NAME
                    ,A.CONSIGNEE_CITY_CD
                    ,A.CONSIGNEE_CITY_NAME
                    ,A.REGION_CD
                    ,A.REGION_NAME
                    ,A.CONTRACT_NO
                    ,A.CONTRACT_NAME
                    ,A.EXPORT_ORD_NO
                    ,A.CAR_CUSTOMER_YN
                    ,A.LOT_NO
                    ,A.LOT_NAME
                    ,A.NOTE
                    ,A.NOTE1
                    ,A.INTERFACE_DATE
               FROM TB_SM_ORDCOMM_INTERFACE A
                    ,(SELECT PROD_YYMM,CONTRACT_ORD_NO, MAX(SEQUENCE_KEY) SEQUENCE_KEY
                        FROM TB_SM_ORDCOMM_INTERFACE
                       WHERE INTERFACE_EXECUTION_STATUS = '1'
                       GROUP BY PROD_YYMM,CONTRACT_ORD_NO
                     ) B
              WHERE A.SEQUENCE_KEY = B.SEQUENCE_KEY
              ORDER BY A.PROD_YYMM,A.CONTRACT_ORD_NO
              )
   LOOP
      -- interface group = 3 -> delete order
      IF  C1.INTERFACE_GP = '3'  THEN

          UPDATE TB_SM_ORDCOMM
             SET ORD_PROG_CD     = 'F' -- code F -> finished
           WHERE PROD_YYMM       = C1.PROD_YYMM
             AND ORD_NO          = C1.CONTRACT_ORD_NO;

          UPDATE TB_SM_ORDDTL
             SET ORD_PROG_CD = 'F' -- code F -> finished
           WHERE ORD_NO = (SELECT ORD_NO
                             FROM TB_SM_ORDCOMM
                            WHERE PROD_YYMM       = C1.PROD_YYMM
                              AND ORD_NO          = C1.CONTRACT_ORD_NO
                          );
          UPDATE TB_SM_ORDCOMM_INTERFACE
              SET INTERFACE_EXECUTION_STATUS = '2'  -- order executed (processed)
            WHERE PROD_YYMM       = C1.PROD_YYMM
              AND CONTRACT_ORD_NO = C1.CONTRACT_ORD_NO;

          UPDATE TB_SM_ORDDTL_INTERFACE
              SET INTERFACE_EXECUTION_STATUS = '2' -- order executed (processed)
            WHERE PROD_YYMM       = C1.PROD_YYMM
              AND CONTRACT_ORD_NO = C1.CONTRACT_ORD_NO;

      ELSE -- other interface groups (1 -> add, 2 -> edit)

         --DELETE TB_SM_ORDCOMM
         -- WHERE PROD_YYMM       = C1.PROD_YYMM
          --  AND CONTRACT_ORD_NO = C1.CONTRACT_ORD_NO;

         --  CUSTOMER INFORMATION INSERT, if no customer info exists (TB_SM_CUSTOMER)
         IF  C1.CUSTOMER_CD IS NOT NULL  THEN
             BEGIN
                SELECT CUSTOMER_CD INTO W_CUSTOMER_CD
                  FROM TB_SM_CUSTOMER
                 WHERE CUSTOMER_CD = C1.CUSTOMER_CD;
             EXCEPTION
                  WHEN  NO_DATA_FOUND   THEN
                        INSERT INTO TB_SM_CUSTOMER
                                (CUSTOMER_CD
                                ,CUSTOMER_ABRV
                                ,CUSTOMER_NAME
                                ,ORD_GP
                                ,COUNTRY_CD
                                ,COUNTRY_NAME
                                ,CITY_CD
                                ,CITY_NAME
                                ,ALL_ADDRESS
                                ,EN_ALL_ADDRESS
                                )
                         VALUES (C1.CUSTOMER_CD
                                ,C1.CUSTOMER_NAME
                                ,C1.CUSTOMER_NAME
                                ,C1.ORD_GP
                                ,C1.CUSTOMER_COUNTRY_CD
                                ,C1.CUSTOMER_COUNTRY_NAME
                                ,C1.CUSTOMER_CITY_CD
                                ,C1.CUSTOMER_CITY_NAME
                                ,C1.CUSTOMER_ADDRESS_RUS
                                ,C1.CUSTOMER_ADDRESS_ENG
                                );
                 WHEN  OTHERS         THEN
                      W_ERR_CODE  := TO_CHAR(SQLCODE);
                      W_ERR_MSG   := 'SYSTEM ERROR = ' || SQLERRM;
                     RAISE ERROR_RTN;
             END;
         END IF;

         --  CONSIGNEE INFORMATION INSERT, if no consignee info exists (TB_SM_CUSTOMER)
         IF  C1.CONSIGNEE_CD IS NOT NULL  THEN
             BEGIN
                 SELECT CUSTOMER_CD  INTO W_CUSTOMER_CD
                  FROM TB_SM_CUSTOMER
                 WHERE CUSTOMER_CD = C1.CONSIGNEE_CD;
             EXCEPTION
                  WHEN  NO_DATA_FOUND   THEN
                        INSERT INTO TB_SM_CUSTOMER
                                (CUSTOMER_CD
                                ,CUSTOMER_ABRV
                                ,CUSTOMER_NAME
                                ,ORD_GP
                                ,COUNTRY_CD
                                ,COUNTRY_NAME
                                ,REGION_CD
                                ,REGION_NAME
                                ,CITY_CD
                                ,CITY_NAME
                                ,ALL_ADDRESS
                                ,EN_ALL_ADDRESS
                                )
                         VALUES (C1.CONSIGNEE_CD
                                ,C1.CONSIGNEE_NAME
                                ,C1.CONSIGNEE_NAME
                                ,C1.ORD_GP
                                ,C1.CONSIGNEE_COUNTRY_CD
                                ,C1.CONSIGNEE_COUNTRY_NAME
                                ,C1.REGION_CD
                                ,C1.REGION_NAME
                                ,C1.CONSIGNEE_CITY_CD
                                ,C1.CONSIGNEE_CITY_NAME
                                ,C1.CONSIGNEE_ADDRESS_RUS
                                ,C1.CONSIGNEE_ADDRESS_ENG
                                );
                 WHEN  OTHERS         THEN
                      W_ERR_CODE  := TO_CHAR(SQLCODE);
                      W_ERR_MSG   := 'SYSTEM ERROR = ' || SQLERRM;
                     RAISE ERROR_RTN;
             END;
         END IF;

         -- REGION INFROMATION INSERT, if no region info exists (TB_SM_REGION)
         IF  C1.REGION_CD IS NOT NULL  THEN
             BEGIN
                 SELECT REGION_CD INTO W_REGION_CD
                   FROM TB_SM_REGION
                  WHERE REGION_CD = C1.REGION_CD;
             EXCEPTION
                  WHEN  NO_DATA_FOUND   THEN
                        INSERT INTO TB_SM_REGION
                                (REGION_CD
                                ,REGION_NAME
                                )
                         VALUES (C1.REGION_CD
                                ,C1.REGION_NAME
                                );
                 WHEN  OTHERS         THEN
                      W_ERR_CODE  := TO_CHAR(SQLCODE);
                      W_ERR_MSG   := 'SYSTEM ERROR = ' || SQLERRM;
                     RAISE ERROR_RTN;
             END;
         END IF;

         -- delete previous order from table TB_SM_ORDCOMM
         DELETE TB_SM_ORDCOMM WHERE PROD_YYMM = C1.PROD_YYMM AND CONTRACT_ORD_NO = C1.CONTRACT_ORD_NO;

         -- ORDER COMM INFORMATION INSERT
         INSERT INTO TB_SM_ORDCOMM (PROD_YYMM,    ORD_NO,             ORD_PROG_CD, ORD_GP,CUSTOMER_CD,CONSIGNEE_CD,REGION_CD,CONTRACT_NO,CONTRACT_NAME,
                                    EXPORT_ORD_NO,NOTE,NOTE1,CONTRACT_ORD_NO,LOT_NO,LOT_NAME,CAR_YN,REG_DDTT,REGISTER)

                            VALUES (C1.PROD_YYMM, C1.CONTRACT_ORD_NO, 'A',         C1.ORD_GP
                 ,C1.CUSTOMER_CD
                 ,C1.CONSIGNEE_CD
                 ,C1.REGION_CD
                 ,C1.CONTRACT_NO
                 ,C1.CONTRACT_NAME
                 ,C1.EXPORT_ORD_NO
                 ,C1.NOTE
                 ,C1.NOTE1
                 ,C1.CONTRACT_ORD_NO
                 ,C1.LOT_NO
                 ,C1.LOT_NAME
                 ,C1.CAR_CUSTOMER_YN
                 ,SYSDATE
                 ,'SP_SM_100_ORDIF'
                 );

         -- delete previous details for order from table TB_SM_ORDDTL (clear before insert)
         DELETE TB_SM_ORDDTL
          WHERE PROD_YYMM    = C1.PROD_YYMM
            AND ORD_NO       = C1.CONTRACT_ORD_NO;
       --   AND ORD_POSITION = C2.ORD_POSITION;

         -- delete previous order ingredients from table TB_SM_ORD_INGR (clear before insert)
         DELETE TB_SM_ORD_INGR
          WHERE PROD_YYMM    = C1.PROD_YYMM
            AND ORD_NO       = C1.CONTRACT_ORD_NO;
       --     AND ORD_POSITION = C2.ORD_POSITION;

        -- delete previous extra items from table TB_SM_ORD_EXTRA_ITEM (clear before insert)
         DELETE TB_SM_ORD_EXTRA_ITEM
          WHERE PROD_YYMM    = C1.PROD_YYMM
            AND ORD_NO       = C1.CONTRACT_ORD_NO;
       --     AND ORD_POSITION = C2.ORD_POSITION;

         -- cycle for inserting order details
         W_POSITION_COUNT  := 0;
         W_COMM_ERR_YN     := 'N';
         FOR C2 IN  (SELECT  A.SEQUENCE_KEY
                            ,A.PROD_YYMM
                            ,A.CONTRACT_ORD_NO
                            ,A.ORD_POSITION
                            ,A.ORD_GP
                            ,A.SALE_GP
                            ,A.STLGRADE_STANDARD_CD
                            ,A.PROFILE_STANDARD_CD
                            ,A.STLGRADE_CD_FR
                            ,A.STLGRADE_CD_TO
                            ,A.SECTION_CD
                            ,A.SECTION_SIZE_T_FR
                            ,A.SECTION_SIZE_T_TO
                            ,A.SECTION_SIZE_W_FR
                            ,A.SECTION_SIZE_W_TO
                            ,A.GOODS_LEN_MIN
                            ,A.GOODS_LEN_MAX
                            ,A.GOODS_LEN_TOL_MIN
                            ,A.GOODS_LEN_TOL_MAX
                            ,A.SHORT_LEN_MIN
                            ,A.SHORT_LEN_ALLOW_RATE
                            ,A.ORD_WT
                            ,A.MILL_GP
                            ,A.SPECIFICATION_NO
                            ,A.TECH_AGREE_NO
                            ,A.MARKING_CD
                            ,A.HEAT_TREAT_YN
                            ,A.SURFACE_STATUS
                            ,A.SURFACE_TREAT_GP
                            ,A.PACKING_WT_MIN
                            ,A.PACKING_WT_MAX
                            ,A.BINDING_COUNT
                            ,A.B2B5_STANDARD
                            ,A.GRINDING_YN
                            ,A.DELIVER_DD
                            ,A.DELIVER_TERMS_LEN_CD
                            ,A.DELIVER_TERMS_LEN_NAME
                            ,A.ORD_INGR_SPEC1
                            ,A.ORD_INGR_SPEC2
                            ,A.ORD_INGR_SPEC3
                            ,A.ORD_INGR_SPEC4
                            ,A.ORD_INGR_SPEC5
                            ,A.INTERFACE_DATE
                            ,A.REG_DDTT
                       FROM TB_SM_ORDDTL_INTERFACE A
                            ,(SELECT PROD_YYMM,CONTRACT_ORD_NO,ORD_POSITION, MAX(SEQUENCE_KEY) SEQUENCE_KEY
                                FROM TB_SM_ORDDTL_INTERFACE
                               WHERE INTERFACE_EXECUTION_STATUS = '1'
                                 AND PROD_YYMM              = C1.PROD_YYMM
                                 AND CONTRACT_ORD_NO        = C1.CONTRACT_ORD_NO
                               GROUP BY PROD_YYMM,CONTRACT_ORD_NO,ORD_POSITION
                             ) B
                       WHERE A.SEQUENCE_KEY           = B.SEQUENCE_KEY
                       ORDER BY B.PROD_YYMM,B.CONTRACT_ORD_NO,B.ORD_POSITION
                      )
         LOOP

              IF  C2.SALE_GP = '1' OR  C2.ORD_WT = 1  THEN
                  SELECT COUNT(*) INTO W_EXIST_COUNT
                    FROM TB_SM_ORDDTL
                   WHERE PROD_YYMM     = C1.PROD_YYMM
                     AND ORD_NO        = C1.CONTRACT_ORD_NO
                     AND ORD_POSITION  = C2.ORD_POSITION;

                  IF  W_EXIST_COUNT > 0  THEN
                      UPDATE TB_SM_ORDDTL
                         SET ORD_PROG_CD = 'E'
                             ,SALE_GP    = C2.SALE_GP
                             ,ORD_WT     = C2.ORD_WT
                       WHERE PROD_YYMM     = C1.PROD_YYMM
                         AND ORD_NO        = C1.CONTRACT_ORD_NO
                         AND ORD_POSITION  = C2.ORD_POSITION;

                      GOTO   LOOP_END_RTN;
                  END IF;
              END IF;

              DELETE TB_SM_ORDDTL
               WHERE PROD_YYMM    = C1.PROD_YYMM
                 AND ORD_NO       = C1.CONTRACT_ORD_NO
                 AND ORD_POSITION = C2.ORD_POSITION;

              DELETE TB_SM_ORD_INGR
               WHERE PROD_YYMM    = C1.PROD_YYMM
                 AND ORD_NO       = C1.CONTRACT_ORD_NO
                 AND ORD_POSITION = C2.ORD_POSITION;

              DELETE TB_SM_ORD_EXTRA_ITEM
               WHERE PROD_YYMM    = C1.PROD_YYMM
                 AND ORD_NO       = C1.CONTRACT_ORD_NO
                 AND ORD_POSITION = C2.ORD_POSITION;

              W_TB_ERR_MSG       := NULL;
         ----------------------------------------------------------------------
         -- INTERFACE DATA CHECK
         ----------------------------------------------------------------------

              IF  NVL(C2.MILL_GP,' ')  NOT  IN ('3','9')  THEN -- check MILL_GP
                  W_TB_ERR_MSG    := 'Data Miss : MILL_GP';
                  W_COMM_ERR_YN   := 'Y';
              ELSIF  NVL(C2.SECTION_SIZE_T_FR,0)  =   0  THEN -- checl section size
                     W_TB_ERR_MSG    := 'Data Miss : SECTION_SIZE_T_FR';
                     W_COMM_ERR_YN   := 'Y';
              ELSIF  NVL(C2.GOODS_LEN_MIN,0)   =   0  THEN -- check goods length
                     W_TB_ERR_MSG    := 'Data Miss : GOODS_LEN_MIN';
                     W_COMM_ERR_YN   := 'Y';
              ELSIF  NVL(C2.GOODS_LEN_MAX,0)   =   0  THEN -- check goods length
                     W_TB_ERR_MSG    := 'Data Miss : GOODS_LEN_MAX';
                     W_COMM_ERR_YN   := 'Y';
              END IF;

              IF  NVL(C2.SECTION_SIZE_W_FR,0)  = 0 THEN
                  C2.SECTION_SIZE_W_FR    := C2.SECTION_SIZE_T_FR;
              END IF;
              IF  NVL(C2.SECTION_SIZE_W_TO,0)  = 0 THEN
                  C2.SECTION_SIZE_W_TO    := C2.SECTION_SIZE_T_TO;
              END IF;



         ----------------------------------------------------------------------
         -- STANDARD DATA CHECK
         ----------------------------------------------------------------------

              W_SECTION_TYPE  := NULL;
              BEGIN -- check section (profile) data in database
                  SELECT SECTION_TYPE INTO W_SECTION_TYPE
                    FROM TB_SM_SECTION
                   WHERE SECTION_CD = C2.SECTION_CD;
              EXCEPTION
                     WHEN  NO_DATA_FOUND  THEN
                           W_TB_ERR_MSG    := 'SECTION TYPE NOT MATCH';
                           W_COMM_ERR_YN   := 'Y';
                     WHEN  OTHERS         THEN
                           W_ERR_CODE  := TO_CHAR(SQLCODE);
                           W_ERR_MSG   := 'SYSTEM ERROR = ' || SQLERRM;
                           RAISE ERROR_RTN;
              END;

              -- BUNDLE MIN,MAX WEIGHT SET
              IF  C2.PACKING_WT_MIN IS NULL AND  C2.PACKING_WT_MAX IS NULL THEN
                  BEGIN
                      SELECT BUNDLE_MIN_WT, BUNDLE_MAX_WT
                        INTO C2.PACKING_WT_MIN, C2.PACKING_WT_MAX
                        FROM TB_PM_BUNDLING_WEIGHT_STD
                       WHERE SECTION_TYPE(+) = NVL(W_SECTION_TYPE,' ')
                         AND SECTION_SIZE_T_1(+) < C2.SECTION_SIZE_T_FR
                         AND SECTION_SIZE_T_2(+) >= C2.SECTION_SIZE_T_FR;
                  EXCEPTION
                       WHEN  NO_DATA_FOUND  THEN
                             NULL;
                       WHEN  OTHERS         THEN
                             W_ERR_CODE  := TO_CHAR(SQLCODE);
                             W_ERR_MSG   := 'SYSTEM ERROR = ' || SQLERRM;
                             RAISE ERROR_RTN;
                  END;
              END IF;

              -- BUNDLE BINDING COUNT SET
              IF  C2.BINDING_COUNT IS NULL THEN
                  BEGIN
                      SELECT BUNDLE_BINDING_COUNT
                        INTO C2.BINDING_COUNT
                        FROM TB_PM_BUNDLE_BINDING_COUNT
                       WHERE C2.GOODS_LEN_MAX >  GOODS_LEN_MIN(+)
                         AND C2.GOODS_LEN_MAX <= GOODS_LEN_MAX(+);
                  EXCEPTION
                         WHEN  NO_DATA_FOUND  THEN
                               NULL;
                         WHEN  OTHERS         THEN
                               W_ERR_CODE  := TO_CHAR(SQLCODE);
                               W_ERR_MSG   := 'SYSTEM ERROR = ' || SQLERRM;
                               RAISE ERROR_RTN;
                  END;
              END IF;

              -- Order Weight Tolence Set
              BEGIN
                  SELECT  DELIVER_TOLERANCE_MIN,   DELIVER_TOLERANCE_MAX
                    INTO  W_DELIVER_TOLERANCE_MIN, W_DELIVER_TOLERANCE_MAX
                    FROM  TB_SM_ORDER_WEIGHT_TOLERANCE B
                   WHERE  ORDER_WT_FR  <=  C2.ORD_WT
                     AND  ORDER_WT_TO  >   C2.ORD_WT
                     AND  ORD_GP       =  CASE WHEN C2.ORD_GP = '1' THEN 'E'
                                               WHEN C1.CUSTOMER_COUNTRY_CD = '112' THEN 'B'
                                               ELSE 'C' END;
              EXCEPTION
                    WHEN NO_DATA_FOUND  THEN
                         W_TB_ERR_MSG  := 'Order Weight Tolence Not Found';
                         W_COMM_ERR_YN := 'Y';
                    WHEN OTHERS         THEN
                         W_ERR_CODE  := TO_CHAR(SQLCODE);
                         W_ERR_MSG   := 'SYSTEM ERROR = ' || SQLERRM;
                         RAISE ERROR_RTN;
              END;

              --  SIZE CONTROL
              W_TURN_B2                :=   NULL;
              IF  C2.SURFACE_TREAT_GP = '1'    THEN
                  W_TURN_B2            :=  'T';
              END IF;
              IF  C2.B2B5_STANDARD    =  'B5'  THEN
                  W_TURN_B2            :=  'B';
              END IF;

              W_R680_SECTION_TYPE      := NULL;
              W_R680_SECTION_SIZE_T    := NULL;
              W_R680_SECTION_SIZE_W    := NULL;
              W_R350_SECTION_TYPE      := NULL;
              W_R350_SECTION_SIZE_T    := NULL;
              W_R350_SECTION_SIZE_W    := NULL;
              W_ROLL_SECTION_SIZE_T    := NULL;
              W_ROLL_SECTION_SIZE_T1   := NULL;
              W_ROLL_SECTION_SIZE_T2   := NULL;
              W_ROLL_SECTION_SIZE_T3   := NULL;

              -- W_MILL900_350_COMM_SIZE CHECK
              IF  W_SECTION_TYPE = 'RB' AND C2.SECTION_CD = '1177' AND C2.SECTION_SIZE_T_FR = 110
                  OR  W_SECTION_TYPE = 'RB' AND C2.SECTION_SIZE_T_FR > 110 THEN
                  C2.MILL_GP := '9';
              ELSE
                  W_MILL900_350_COMM_SIZE_YN  := NULL;
              END IF;

              --  TURNING ROLL_SECTION_SIZE SET
              IF  W_TURN_B2  IS NOT NULL  THEN
                  W_COUNT  := 0;
                  FOR C3 IN (SELECT ROLL_SECTION_SIZE
                               FROM TB_QM_TURNING_B5_MILL_SIZE
                              WHERE TURNING_B5_GP    = W_TURN_B2
                                AND ORD_SECTION_SIZE = C2.SECTION_SIZE_T_FR
                             )
                  LOOP
                      W_COUNT := W_COUNT + 1;
                      IF  W_COUNT = 1  THEN
                          W_ROLL_SECTION_SIZE_T   := C3.ROLL_SECTION_SIZE;
                          W_ROLL_SECTION_SIZE_T1 := C3.ROLL_SECTION_SIZE;
                        --  W_TURNING_YIELD_RATE   := C3.ROLL_SECTION_SIZE;
                      ELSE
                          IF  W_COUNT = 2  THEN
                              W_ROLL_SECTION_SIZE_T2 := C3.ROLL_SECTION_SIZE;
                          ELSE
                              W_ROLL_SECTION_SIZE_T3 := C3.ROLL_SECTION_SIZE;
                          END IF;
                      END IF;
                  END LOOP;
                  IF  W_COUNT = 0  THEN
                      W_TB_ERR_MSG    :=  'Tuning OR B5 Size Not Define' ;
                      W_COMM_ERR_YN   := 'Y';
                  ELSE
                      W_ROLL_SECTION_SIZE_W      := W_ROLL_SECTION_SIZE_T;
                      IF  C2.MILL_GP = '9'  THEN
                          W_R680_SECTION_TYPE    := W_SECTION_TYPE;
                          W_R680_SECTION_SIZE_T  := W_ROLL_SECTION_SIZE_T;
                          W_R680_SECTION_SIZE_W  := W_ROLL_SECTION_SIZE_T;
                      ELSE
                          W_R350_SECTION_TYPE    := W_SECTION_TYPE;
                          W_R350_SECTION_SIZE_T  := W_ROLL_SECTION_SIZE_T;
                          W_R350_SECTION_SIZE_W  := W_ROLL_SECTION_SIZE_T;
                      END IF;
                  END IF;
              ELSE
                  W_ROLL_SECTION_SIZE_T  :=  C2.SECTION_SIZE_T_FR;
                  W_ROLL_SECTION_SIZE_W  :=  C2.SECTION_SIZE_W_FR;

                  IF  C2.MILL_GP = '9'  THEN
                      W_R680_SECTION_TYPE    := W_SECTION_TYPE;
                      W_R680_SECTION_SIZE_T  := C2.SECTION_SIZE_T_FR;
                      W_R680_SECTION_SIZE_W  := C2.SECTION_SIZE_W_FR;
                  ELSE
                      W_R350_SECTION_TYPE    := W_SECTION_TYPE;
                      W_R350_SECTION_SIZE_T  := C2.SECTION_SIZE_T_FR;
                      W_R350_SECTION_SIZE_W  := C2.SECTION_SIZE_W_FR;
                  END IF;
              END IF;



              -- Unit Weight Check

              SELECT COUNT(*) INTO W_COUNT
                FROM TB_PM_UNIT_WEIGHT_STD
               WHERE SECTION_TYPE   = W_SECTION_TYPE
                 AND SECTION_SIZE_T = W_ROLL_SECTION_SIZE_T
                 AND SECTION_SIZE_W = W_ROLL_SECTION_SIZE_W;

              IF  W_COUNT = 0 THEN
                  INSERT INTO TB_PM_UNIT_WEIGHT_STD
                         (SECTION_TYPE
                         ,SECTION_SIZE_T
                         ,SECTION_SIZE_W
                         ,UNIT_WT
                         )
                  SELECT  W_SECTION_TYPE
                         ,W_ROLL_SECTION_SIZE_T
                         ,W_ROLL_SECTION_SIZE_W
                         ,ROUND(W_ROLL_SECTION_SIZE_T * W_ROLL_SECTION_SIZE_W * SPECIFIC_GRAVITY / 1000,3)
                    FROM TB_QM_SPECIFIC_GRAVITY
                   WHERE SECTION_TYPE = W_SECTION_TYPE;
              END IF;

              -- GOODS_LEN_TOLERANCE set
              W_ORD_SHORT_LEN_MIN           := C2.SHORT_LEN_MIN;
              W_ORD_SHORT_LEN_ALLOW_RATE    := C2.SHORT_LEN_ALLOW_RATE;


              IF  C2.GOODS_LEN_MIN < C2.GOODS_LEN_MAX  THEN
                  C2.SHORT_LEN_MIN          := 0;
                  C2.SHORT_LEN_ALLOW_RATE   := 0;
                  C2.GOODS_LEN_TOL_MIN      := 0;
                  C2.GOODS_LEN_TOL_MAX      := 0;
              ELSE
                  IF  C2.GOODS_LEN_MIN = C2.GOODS_LEN_MAX
                         AND  NVL(C2.GOODS_LEN_TOL_MIN,0) = 0
                         AND  NVL(C2.GOODS_LEN_TOL_MAX,0) = 0  THEN
                      C2.GOODS_LEN_TOL_MAX  := 50;
                  END IF;
              END IF;
              -- GOODS_LEN_TOLERANCE set
              IF  NVL(C2.SHORT_LEN_ALLOW_RATE,0) > 0 AND NVL(C2.SHORT_LEN_MIN,0) = 0 THEN
                  C2.SHORT_LEN_MIN  := 2500;
              END IF;

              --  HEAT_TREAT_YN SET
              IF  C2.HEAT_TREAT_YN  <> 'Y' AND C2.MILL_GP = '3' THEN
                  SELECT COUNT(*) INTO W_COUNT
                    FROM TB_QM_HEATING_STL_GRADE_STD
                   WHERE STLGRADE_CD       = C2.STLGRADE_CD_FR
                     AND SECTION_TYPE      = W_SECTION_TYPE
                     AND SECTION_SIZE_T_FR <= C2.SECTION_SIZE_T_FR
                     AND SECTION_SIZE_T_TO >= C2.SECTION_SIZE_T_FR;
                  IF  W_COUNT > 0  THEN
                      C2.HEAT_TREAT_YN := 'Y';
                  END IF;
              END IF;

              -- STLGRADE CHECK
              W_CONTINUE_YN   := 'Y';
              SELECT COUNT(*) INTO W_COUNT FROM TB_QM_STL_GRADE
                WHERE STLGRADE_CD = C2.STLGRADE_CD_FR;
              IF  W_COUNT = 0  THEN
                  W_TB_ERR_MSG    :=  'SeelGrade Not found Error' ;
                  W_COMM_ERR_YN   := 'Y';
                  W_CONTINUE_YN   := 'N';
              END IF;

--              IF  C2.PROD_YYMM < TO_CHAR(SYSDATE,'YYYYMM') THEN
--                  W_TB_ERR_MSG    :=  'Prod Month Error' ;
--                  W_CONTINUE_YN := 'N';
--              END IF;
              IF  C2.SALE_GP = '1' OR  C2.ORD_WT = 1 THEN
                  W_ORD_PROG_CD     := 'E';
              ELSE
                  -- W_TB_ERR_MSG is not null when there are errors with dictionary data -
                  -- standards, steel grades, section type etc...
                  IF  W_TB_ERR_MSG IS NULL THEN
                      W_ORD_PROG_CD     := 'B';
                  ELSE
                      W_ORD_PROG_CD     := 'A';
                  END IF;
              END IF;

              BEGIN
                  -- TB_SM_ORDDTL INSERT
                  INSERT INTO TB_SM_ORDDTL
                          (ORD_NO                -- C1.CONTRACT_ORD_NO
                          ,ORD_POSITION          -- C2.ORD_POSITION
                          ,PROD_YYMM             -- C2.PROD_YYMM
                          ,ORD_PROG_CD           -- W_ORD_PROG_CD
                          ,ORD_GP                -- C2.ORD_GP
                          ,SALE_GP               -- C2.SALE_GP
                          ,STANDARD_CD           -- C2.STLGRADE_STANDARD_CD
                          ,PROFILE_STANDARD_CD   -- C2.PROFILE_STANDARD_CD
                          ,STLGRADE_CD
                          ,STLGRADE_CD_FR
                          ,STLGRADE_CD_TO
                          ,SECTION_CD
                          ,SECTION_TYPE          -- W_SECTION_TYPE
                          ,SECTION_SIZE_T
                          ,SECTION_SIZE_W
                          ,SECTION_SIZE_T_FR
                          ,SECTION_SIZE_T_TO
                          ,SECTION_SIZE_W_FR
                          ,SECTION_SIZE_W_TO
                          ,GOODS_LEN_MIN            -- GOODS_LEN_MIN
                          ,GOODS_LEN_MAX            -- GOODS_LEN_MAX
                          ,GOODS_LEN_TOL_MIN        -- GOODS_LEN_TOL_MIN
                          ,GOODS_LEN_TOL_MAX        -- GOODS_LEN_TOL_MAX
                          ,SHORT_LEN_MIN            --
                          ,SHORT_LEN_ALLOW_RATE     --
                          ,ORD_SHORT_LEN_MIN        --
                          ,ORD_SHORT_LEN_ALLOW_RATE --

                          ,ORD_WT                   -- ORD_WT
                          ,R680_SECTION_TYPE        -- W_R680_SECTION_TYPE
                          ,R680_SECTION_SIZE_T      -- W_R680_SECTION_SIZE_T
                          ,R680_SECTION_SIZE_W      -- W_R680_SECTION_SIZE_W
                          ,R350_SECTION_TYPE        -- W_R350_SECTION_TYPE
                          ,R350_SECTION_SIZE_T      -- W_R350_SECTION_SIZE_T
                          ,R350_SECTION_SIZE_W      -- W_R350_SECTION_SIZE_W
                          ,DELIVER_TOLERANCE_MIN    -- W_DELIVER_TOLERANCE_MIN
                          ,DELIVER_TOLERANCE_MAX    -- W_DELIVER_TOLERANCE_Max
                          ,MILL_GP                  -- MILL_GP

                          ,CUSTOMER_DELIVER_DD      --
                          ,DELIVER_DD               --

                          ,ROLL_SECTION_SIZE_T
                          ,ROLL_SECTION_SIZE_T1
                          ,ROLL_SECTION_SIZE_T2
                          ,ROLL_SECTION_SIZE_T3
                          ,MILL900_350_COMM_SIZE_YN
                        --  ,INGOT_DESIGN_WAIT_WT
                        --  ,INGOT_DESIGN_WAIT_WT_MIN
                        --  ,INGOT_DESIGN_WAIT_WT_MAX
                          ,MARKING_CD
                          ,HEAT_TREAT_YN
                          ,BUNDLE_MIN_WT
                          ,BUNDLE_MAX_WT
                          ,BUNDLE_BINDING_COUNT
                          ,SURFACE_TREAT_GP
                          ,SURFACE_STATUS
                          ,B2B5_STANDARD
                          ,GRINDING_YN
                          ,QUALITY_DESIGN_YN
                          ,DELIVER_TERMS_LEN_CD
                          ,DELIVER_TERMS_LEN_NAME
                       --   ,SUPPLY_ORD_WT
                          ,ORD_INGR_SPEC1
                          ,ORD_INGR_SPEC2
                          ,ORD_INGR_SPEC3
                          ,ORD_INGR_SPEC4
                          ,ORD_INGR_SPEC5
                          ,ORD_RECEIPT_ERR_YN
                          ,PROD_END_YN
                          ,RECEIPT_DATE
                          ,ERR_MSG
                          ,REG_DDTT
                          ,REGISTER)
                   VALUES (C1.CONTRACT_ORD_NO
                          ,C2.ORD_POSITION
                          ,C2.PROD_YYMM
                          ,W_ORD_PROG_CD
                          ,C2.ORD_GP
                          ,C2.SALE_GP
                          ,C2.STLGRADE_STANDARD_CD
                          ,C2.PROFILE_STANDARD_CD
                          ,C2.STLGRADE_CD_FR
                          ,C2.STLGRADE_CD_FR
                          ,C2.STLGRADE_CD_TO
                          ,C2.SECTION_CD
                          ,W_SECTION_TYPE
                          ,C2.SECTION_SIZE_T_FR
                          ,C2.SECTION_SIZE_W_FR
                          ,C2.SECTION_SIZE_T_FR
                          ,C2.SECTION_SIZE_T_TO
                          ,C2.SECTION_SIZE_W_FR
                          ,C2.SECTION_SIZE_W_TO
                          ,C2.GOODS_LEN_MIN
                          ,C2.GOODS_LEN_MAX
                          ,CASE WHEN NVL(C2.GOODS_LEN_TOL_MIN,0)    = 0 THEN 0 ELSE C2.GOODS_LEN_TOL_MIN    END
                          ,CASE WHEN NVL(C2.GOODS_LEN_TOL_MAX,0)    = 0 THEN 0 ELSE C2.GOODS_LEN_TOL_MAX    END
                          ,CASE WHEN NVL(C2.SHORT_LEN_MIN,0)        = 0 THEN 0 ELSE C2.SHORT_LEN_MIN        END
                          ,CASE WHEN NVL(C2.SHORT_LEN_ALLOW_RATE,0) = 0 THEN 0 ELSE C2.SHORT_LEN_ALLOW_RATE END
                          ,W_ORD_SHORT_LEN_MIN
                          ,W_ORD_SHORT_LEN_ALLOW_RATE
                          ,C2.ORD_WT
                          ,W_R680_SECTION_TYPE
                          ,W_R680_SECTION_SIZE_T
                          ,W_R680_SECTION_SIZE_W
                          ,W_R350_SECTION_TYPE
                          ,W_R350_SECTION_SIZE_T
                          ,W_R350_SECTION_SIZE_W
                          ,W_DELIVER_TOLERANCE_MIN
                          ,W_DELIVER_TOLERANCE_MAX
                          ,C2.MILL_GP
                          ,TO_CHAR(TO_DATE(C2.DELIVER_DD,'DD.MM.YYYY'),'YYYYMMDD')
                          ,TO_CHAR(TO_DATE(C2.DELIVER_DD,'DD.MM.YYYY'),'YYYYMMDD')
                          ,W_ROLL_SECTION_SIZE_T
                          ,W_ROLL_SECTION_SIZE_T1
                          ,W_ROLL_SECTION_SIZE_T2
                          ,W_ROLL_SECTION_SIZE_T3
                          ,W_MILL900_350_COMM_SIZE_YN
                        --  ,C2.ORD_WT
                        --  ,C2.ORD_WT - ROUND(W_DELIVER_TOLERANCE_MIN * C2.ORD_WT / 100)
                        --  ,C2.ORD_WT + ROUND(W_DELIVER_TOLERANCE_MAX * C2.ORD_WT / 100)
                          ,C2.MARKING_CD
                          ,C2.HEAT_TREAT_YN
                          ,C2.PACKING_WT_MIN
                          ,C2.PACKING_WT_MAX
                          ,C2.BINDING_COUNT
                          ,C2.SURFACE_TREAT_GP
                          ,C2.SURFACE_STATUS
                          ,C2.B2B5_STANDARD
                          ,C2.GRINDING_YN
                          ,'Y'
                          ,C2.DELIVER_TERMS_LEN_CD
                          ,C2.DELIVER_TERMS_LEN_NAME
                     --     ,CASE WHEN C2.MILL_GP = '3' THEN C2.ORD_WT ELSE NULL END
                          ,C2.ORD_INGR_SPEC1
                          ,C2.ORD_INGR_SPEC2
                          ,C2.ORD_INGR_SPEC3
                          ,C2.ORD_INGR_SPEC4
                          ,C2.ORD_INGR_SPEC5
                          ,CASE WHEN W_TB_ERR_MSG IS NOT NULL THEN 'Y' ELSE NULL END
                          ,CASE WHEN W_ORD_PROG_CD = 'E' THEN 'Y' ELSE NULL END
                          ,NVL(C2.INTERFACE_DATE,C2.REG_DDTT)
                          ,W_TB_ERR_MSG
                          ,SYSDATE
                          ,'SP_SM_100_ORDIF'
                          );

              EXCEPTION
                   WHEN  OTHERS         THEN
                         W_ERR_CODE  := TO_CHAR(SQLCODE);
                         W_ERR_MSG   := 'TB_SM_ORDDTL INSERT ERROR = ' || SQLERRM;
                         RAISE ERROR_RTN;
              END;

              -- TB_SM_ORD_INGR INSERT
              SELECT COUNT(*) INTO W_COUNT
                FROM TB_SM_ORD_INGR_INTERFACE
               WHERE PROD_YYMM    = C1.PROD_YYMM
                 AND ORD_NO       = C1.CONTRACT_ORD_NO
                 AND ORD_POSITION = C2.ORD_POSITION;
             --    AND INTERFACE_EXECUTION_STATUS = '1';

              IF  W_COUNT > 0  THEN

                  BEGIN
                      INSERT INTO TB_SM_ORD_INGR
                              (PROD_YYMM
                              ,ORD_NO
                              ,ORD_POSITION
                              ,INGR_CD
                              ,INGR_MIN
                              ,INGR_MAX
                              ,REG_DDTT
                              ,REGISTER)
                       SELECT  C1.PROD_YYMM
                              ,C1.CONTRACT_ORD_NO
                              ,C2.ORD_POSITION
                              ,A.INGR_CD
                              ,A.INGR_MIN
                              ,A.INGR_MAX
                              ,SYSDATE
                              ,'SP_SM_100_ORDIF'
                         FROM TB_SM_ORD_INGR_INTERFACE A
                              ,(SELECT PROD_YYMM,ORD_NO,ORD_POSITION,INGR_CD
                                     ,MAX(SEQUENCE_KEY) SEQUENCE_KEY
                                 FROM TB_SM_ORD_INGR_INTERFACE
                                WHERE PROD_YYMM    = C1.PROD_YYMM
                                  AND ORD_NO       = C1.CONTRACT_ORD_NO
                                  AND ORD_POSITION = C2.ORD_POSITION
                            --      AND INTERFACE_EXECUTION_STATUS = '1'
                                GROUP BY PROD_YYMM,ORD_NO,ORD_POSITION,INGR_CD
                               ) B
                         WHERE A.SEQUENCE_KEY = B.SEQUENCE_KEY;
                  EXCEPTION
                       WHEN  OTHERS         THEN
                             W_ERR_CODE  := TO_CHAR(SQLCODE);
                             W_ERR_MSG   := 'TB_SM_ORD_INGR INSERT ERROR = ' || SQLERRM;
                             RAISE ERROR_RTN;
                  END;

              END IF;

              -- TB_SM_ORD_EXTRA_ITEM INSERT
              SELECT COUNT(*) INTO W_COUNT
                FROM TB_SM_ORD_EXTRA_ITEM_INTERFACE
               WHERE PROD_YYMM    = C1.PROD_YYMM
                 AND ORD_NO       = C1.CONTRACT_ORD_NO
                 AND ORD_POSITION = C2.ORD_POSITION;
              --   AND INTERFACE_EXECUTION_STATUS = '1';

              IF  W_COUNT > 0  THEN

                  BEGIN
                      INSERT INTO TB_SM_ORD_EXTRA_ITEM
                              (PROD_YYMM
                              ,ORD_NO
                              ,ORD_POSITION
                              ,EXTRA_ITEM_CD
                              ,EXTRA_ITEM_NAME
                              ,REG_DDTT
                              ,REGISTER)
                       SELECT C1.PROD_YYMM
                              ,C1.CONTRACT_ORD_NO
                              ,C2.ORD_POSITION
                              ,A.EXTRA_ITEM_CD
                              ,A.EXTRA_ITEM_NAME
                              ,SYSDATE
                              ,'SP_SM_100_ORDIF'
                         FROM TB_SM_ORD_EXTRA_ITEM_INTERFACE A
                              ,(SELECT PROD_YYMM,ORD_NO,ORD_POSITION,EXTRA_ITEM_CD
                                     ,MAX(SEQUENCE_KEY) SEQUENCE_KEY
                                 FROM TB_SM_ORD_EXTRA_ITEM_INTERFACE
                                WHERE PROD_YYMM    = C1.PROD_YYMM
                                  AND ORD_NO       = C1.CONTRACT_ORD_NO
                                  AND ORD_POSITION = C2.ORD_POSITION
                              --    AND INTERFACE_EXECUTION_STATUS = '1'
                                GROUP BY PROD_YYMM,ORD_NO,ORD_POSITION,EXTRA_ITEM_CD
                               ) B
                         WHERE A.SEQUENCE_KEY = B.SEQUENCE_KEY;

                  EXCEPTION
                       WHEN  OTHERS         THEN
                             W_ERR_CODE  := TO_CHAR(SQLCODE);
                             W_ERR_MSG   := 'TB_SM_ORD_EXTRA_ITEM INSERT ERROR = ' || SQLERRM;
                             RAISE ERROR_RTN;
                  END;
              END IF;

              IF  W_CONTINUE_YN = 'Y' THEN

                  -- QUALITY DESIGN DATA SET
                  SP_SM_450_QUAL ( C2.PROD_YYMM
                                   ,C2.CONTRACT_ORD_NO
                                   ,C2.ORD_POSITION
                                   ,C2.STLGRADE_STANDARD_CD
                                   ,C2.STLGRADE_CD_FR
                                   ,W_SECTION_TYPE
                                   ,C2.SECTION_SIZE_T_FR
                                   ,W_ERR_CODE
                                   ,W_TB_ERR_MSG
                                  ) ;
                  IF  W_TB_ERR_MSG IS NOT NULL THEN

                      UPDATE TB_SM_ORDDTL
                         SET QUALITY_DESIGN_YN  = 'N'
--                             ,ORD_PROG_CD = 'A'
--                             ,ORD_RECEIPT_ERR_YN = 'Y'
                             ,ERR_MSG     = W_TB_ERR_MSG
                       WHERE PROD_YYMM = C2.PROD_YYMM
                         AND ORD_NO    = C1.CONTRACT_ORD_NO
                         AND ORD_POSITION = C2.ORD_POSITION;

                       W_TB_ERR_MSG  := NULL;
                  END IF;

              END IF;

              << LOOP_END_RTN >>

              W_POSITION_COUNT  := W_POSITION_COUNT + 1;

              -- INTERFACE TABLE UPDATE
              IF  W_TB_ERR_MSG IS NULL   THEN
                  W_INTERFACE_EXECUTION_STATUS := '2';
              ELSE
                  W_COMM_ERR_YN                := 'Y';
                  W_INTERFACE_EXECUTION_STATUS := '1';
              END IF;

              UPDATE TB_SM_ORDDTL_INTERFACE
                 SET INTERFACE_EXECUTION_STATUS = W_INTERFACE_EXECUTION_STATUS
                     ,INTERFACE_ERROR_TEXT      = W_TB_ERR_MSG
               WHERE PROD_YYMM       = C1.PROD_YYMM
                 AND CONTRACT_ORD_NO = C1.CONTRACT_ORD_NO
                 AND ORD_POSITION    = C2.ORD_POSITION;

              BEGIN
                  UPDATE TB_SM_ORD_INGR_INTERFACE
                     SET INTERFACE_EXECUTION_STATUS = W_INTERFACE_EXECUTION_STATUS
                   WHERE PROD_YYMM       = C1.PROD_YYMM
                     AND ORD_NO          = C1.CONTRACT_ORD_NO
                     AND ORD_POSITION    = C2.ORD_POSITION;
              EXCEPTION
                   WHEN  NO_DATA_FOUND  THEN
                         NULL;
                   WHEN  OTHERS         THEN
                         W_ERR_CODE  := TO_CHAR(SQLCODE);
                         W_ERR_MSG   := 'TB_SM_ORD_INGR UPDATE ERROR = ' || SQLERRM;
                         RAISE ERROR_RTN;
              END;

              BEGIN
                  UPDATE TB_SM_ORD_EXTRA_ITEM_INTERFACE
                     SET INTERFACE_EXECUTION_STATUS = W_INTERFACE_EXECUTION_STATUS
                   WHERE PROD_YYMM       = C1.PROD_YYMM
                     AND ORD_NO          = C1.CONTRACT_ORD_NO
                     AND ORD_POSITION    = C2.ORD_POSITION;
              EXCEPTION
                   WHEN  NO_DATA_FOUND  THEN
                         NULL;
                   WHEN  OTHERS         THEN
                         W_ERR_CODE  := TO_CHAR(SQLCODE);
                         W_ERR_MSG   := 'TB_SM_ORD_EXTRA_ITEM_INTERFACE UPDATE ERROR = ' || SQLERRM;
                         RAISE ERROR_RTN;
              END;
         END LOOP;
      END IF;

      IF W_POSITION_COUNT  > 0  THEN

          W_ERR_MSG    := NULL;
          -- STANDARD VALUES set
          SP_SM_200_PROD  ( C1.PROD_YYMM
                           ,C1.CONTRACT_ORD_NO
                           ,W_ERR_CODE
                           ,W_ERR_MSG
                          ) ;
      END IF;

      -- INTERFACE_EXECUTION_STATUS set
      IF  W_ERR_MSG IS NULL  AND W_COMM_ERR_YN = 'N' THEN
          W_INTERFACE_EXECUTION_STATUS := '2';
      ELSE
          W_INTERFACE_EXECUTION_STATUS := '1';
      END IF;

      UPDATE TB_SM_ORDCOMM_INTERFACE
         SET INTERFACE_EXECUTION_STATUS = W_INTERFACE_EXECUTION_STATUS
             ,INTERFACE_ERROR_TEXT      = W_ERR_MSG
       WHERE PROD_YYMM       = C1.PROD_YYMM
         AND CONTRACT_ORD_NO = C1.CONTRACT_ORD_NO;

      COMMIT;
   END LOOP;
   COMMIT;

   -- DESIGN_CHK
   SP_SM_300_DESIGN_CHK ('DUMMY',W_ERR_CODE,W_ERR_MSG);

EXCEPTION
       WHEN      ERROR_RTN   THEN
                 SP_CM_100_ERR(W_PGM_ID, W_ERR_CODE,  W_ERR_MSG);
                 ROLLBACK;
       WHEN      OTHERS      THEN
                 W_ERR_CODE  := TO_CHAR(SQLCODE);
                 W_ERR_MSG   := 'SYSTEM ERROR = ' || SQLERRM;
                 SP_CM_100_ERR(W_PGM_ID, W_ERR_CODE,  W_ERR_MSG);
                 ROLLBACK;
END;