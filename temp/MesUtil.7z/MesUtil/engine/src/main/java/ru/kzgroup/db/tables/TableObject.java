package ru.kzgroup.db.tables;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Object represents one table (both Paradox/Oracle, maybe Access DB table). If exists path (not empty) => this
 * is Paradox table, if path is sempty => not Paradox (in most cases - Oracle).
 *
 * IMPORTANT: object is immutable!
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 09.07.13)
 */

// todo: implement hashCode, equals, compareTo -> all by String name!
// todo: this class can uses more than one key field (key fields count >= 1), but DataDirectory don't!!!!
// todo: move TableObject and TablesConfig to DataMiner module???

public final class TableObject {

    // class logger
    private Log log = LogFactory.getLog(TableObject.class);

    private String   path;               // Optional for Oracle/mandatory for Paradox
    private String   name;               // Table name. Mandatory field for Paradox/Oracle
    private String[] fields;             // Fields list. Mandatory field for Paradox/Oracle
    // todo: key fields count can be >= 1, but class DataDirectory can't work with it!
    private int      keyFieldsCount = 1; // Optional. Default value = 1 (first field in list is the key field).
    private String   description;        // Optional. Default value = "" (empty string).

    /**
     * @param name String Table name. Mandatory field. Can't be null.
     * @param path String Path (in a filesystem) to table. Optional. If we have Paradox table - should be filled.
     * @param fields String[] Fields list for table. Mandatory. Can't be null or empty. List should be ordered - key fields
     * have to go first in a list, key fields count - keyFieldsCount parameter.
    */
    // todo: if there are empty fields, do we have to throw error or just ignore empty field???
    public TableObject(String name, String path, String[] fields, String description) throws UnsupportedEncodingException {
        if (StringUtils.isBlank(name) || fields == null || fields.length <= 0) {
            throw new IllegalArgumentException("Empty argument in method constructor (table name or fields list)!");
        }
        this.name = StringUtils.trimToEmpty(name);
        this.path = StringUtils.trimToEmpty(path);

        // description
        this.description = StringUtils.trimToEmpty(description);

        // todo: we process fields in TablesConfig module - do we need this check here too?
        // processing fields
        ArrayList<String> list = new ArrayList<String>();
        for (String field : fields) {
            if (!StringUtils.isBlank(field)) {

                /*
                String utf8Field;
                System.out.println("original -> " + field);
                try {
                    utf8Field = new String(field.getBytes(), "UTF-8");
                    System.out.println("win -> " + utf8Field);
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException("!!!!!");
                }
                System.out.println("***");
                */

                // todo: for russian columns names in Paradox - source file encoding should be UTF-8!!!
                list.add(StringUtils.trimToEmpty(new String(field.getBytes(), "UTF-8")));
            } else {
                log.warn("Empty field in fields list!");
            }
        } // end of for

        if (list.isEmpty()) { // check resulting fields list
            throw new IllegalArgumentException("Fields list is empty!");
        } else {
            this.fields = list.toArray(new String[list.size()]);
        }

    }

    /***/
    public int fieldsListLenght() {
        return this.fields.length;
    }

    public String getPath() {
        return path;
    }

    /**
     * Method returns sql query for getting all data from this table. For all fields.
    */
    public String getReceiveAllDataSql() {
        log.debug("TableObject.getReceiveAllDataSql() working.");
        StringBuilder sql = new StringBuilder();
        sql.append("select ");
        for (int i = 0; i < this.fields.length; i++) {
            String currentField = this.fields[i];
            // In columns names with spaces or dots we need escape symbol \" (backslash and double quote).
            // Such names may occure in paradox tables.
            String escapeSymbol = (currentField != null && (currentField.contains(" ") || currentField.contains("."))) ? "\"" : "";
            sql.append(escapeSymbol).append(currentField).append(escapeSymbol);
            if (i < this.fields.length - 1) {
                sql.append(", ");
            }
        } // end of for
        sql.append(" from ").append(this.name);
        return sql.toString();
    }

    /**
     * Method returns sql query for inserting data into this table. For all fields.
     * @param registerUserName String adding user registration info. Used in Oracle tables. If empty
     * or null - register info will be ignored.
    */
    public String getInsertDataSql(String registerUserName) {
        log.debug("TableObject.getInsertDataSql() working.");
        StringBuilder sql = new StringBuilder();
        sql.append("insert into ").append(this.name).append("(");
        StringBuilder valuesSqlPart = new StringBuilder();
        valuesSqlPart.append("(");
        for (int i = 0; i < this.fields.length; i++) {
            String currentField = this.fields[i];
            // In columns names with spaces or dots we need escape symbol \" (backslash and double quote).
            // Such names may occure in paradox tables.
            String escapeSymbol = (currentField != null && (currentField.contains(" ") || currentField.contains("."))) ? "\"" : "";
            sql.append(escapeSymbol).append(currentField).append(escapeSymbol);
            valuesSqlPart.append("?");
            if (i < this.fields.length - 1) {
                sql.append(", ");
                valuesSqlPart.append(", ");
            }
        } // end of for

        // adding fields for register date and register user
        if (!StringUtils.isEmpty(registerUserName)) {
            sql.append(", REG_DDTT, REGISTER");
            valuesSqlPart.append(", sysdate, '").append(registerUserName).append("'");
        }

        // merge two parts of sql query
        sql.append(") values").append(valuesSqlPart).append(")");
        return sql.toString();
    }

    /***/
    public String getUpdateDataSql(String modifierUserName) {
        log.debug("TableObject.getUpdateDataSql() working.");
        StringBuilder sql = new StringBuilder();
        sql.append("update ").append(this.name).append(" set ");
        // we start from index this.keyFieldsCount, because index < this.keyFieldsCount = key fields
        for (int i = this.keyFieldsCount; i < this.fields.length; i++) {
            String currentField = this.fields[i];
            // In columns names with spaces or dots we need escape symbol \" (backslash and double quote).
            // Such names may occure in paradox tables.
            String escapeSymbol = (currentField != null && (currentField.contains(" ") || currentField.contains("."))) ? "\"" : "";
            sql.append(escapeSymbol).append(this.fields[i]).append(escapeSymbol).append(" = ?");
            if (i < this.fields.length - 1) {
                sql.append(", ");
            }
        } // end of for
        if (!StringUtils.isBlank(modifierUserName)) {
            // adding fields for modify date and modifier user
            sql.append(", MOD_DDTT = sysdate, MODIFIER = '").append(modifierUserName).append("'");
        }
        // rest of sql query - key fields list
        sql.append(" where ");
        for (int i = 0; i < this.keyFieldsCount; i++) {
            String currentField = this.fields[i];
            // In columns names with spaces or dots we need escape symbol \" (backslash and double quote).
            // Such names may occure in paradox tables.
            String escapeSymbol = (currentField != null && (currentField.contains(" ") || currentField.contains("."))) ? "\"" : "";
            sql.append(escapeSymbol).append(currentField).append(escapeSymbol).append(" = ?");
            if (i < this.keyFieldsCount - 1) {
                sql.append(" and ");
            }
        }
        return sql.toString();
    }

    /**
     * In check data sql we will get all our fields (with key fields) because in DataDirectory class we will
     * compare two records in different databases (MES-ARM) and decide - do we need to update MES record?
    */
    public String getCheckDataSql() {
        log.debug("TableObject.getCheckDataSql() working.");
        StringBuilder sql = new StringBuilder();

        String currentField; // temporary value
        String escapeSymbol; // temporary value

        // fields list for selection - all fields except key fields
        sql.append("select ");
        // we start from index keyFieldsCount, because fields with index < keyFieldsCount are key fields
        for (int i = this.keyFieldsCount; i < this.fields.length; i++) {
            currentField = this.fields[i];
            escapeSymbol = (currentField != null && (currentField.contains(" ") || currentField.contains("."))) ? "\"" : "";
            sql.append(escapeSymbol).append(currentField).append(escapeSymbol);
            if (i < this.fields.length - 1) {
                sql.append(", ");
            }
        }
        sql.append(" from ").append(this.name).append(" where ");

        // adding key fields list to [where] clause of sql query
        for (int i = 0; i < this.keyFieldsCount; i++) {
            currentField = this.fields[i];
            // In columns names with spaces or dots we need escape symbol \" (backslash and double quote).
            // Such names may occure in paradox tables.
            escapeSymbol = (currentField != null && (currentField.contains(" ") || currentField.contains("."))) ? "\"" : "";
            sql.append(escapeSymbol).append(currentField).append(escapeSymbol).append(" = ?");
            if (i < this.keyFieldsCount - 1) {
                sql.append(" and ");
            }
        }
        return sql.toString();
    }

    public String getDescription() {
        return description;
    }

    /**
     * According to immutability principle we will not return direct link to fields array - we will
     * return just new copy of this array.
    */
    public String[] getFields() {
        return Arrays.copyOf(this.fields, this.fields.length);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("name", name)
                .append("fields", fields)
                .append("keyFieldsCount", keyFieldsCount)
                .append("path", path)
                .toString();
    }

    /** Method just for test. */
    public static void main(String[] args) throws UnsupportedEncodingException {
        Log log = LogFactory.getLog(TableObject.class);
        PropertyConfigurator.configure("log4j.properties");

        log.info("TableObject testing...");

        TableObject table = new TableObject("MyTable", null, new String[] {"f1 ff", "f2", "f3", "f4", "f5"}, "table description");

        log.info(table);
        log.info("select ->   " + table.getReceiveAllDataSql());
        log.info("insert ->   " + table.getInsertDataSql(null));
        log.info("insert ->   " + table.getInsertDataSql("gusevd"));
        log.info("update ->   " + table.getUpdateDataSql("gusevd"));
        log.info("check  ->   " + table.getCheckDataSql());
    }

}