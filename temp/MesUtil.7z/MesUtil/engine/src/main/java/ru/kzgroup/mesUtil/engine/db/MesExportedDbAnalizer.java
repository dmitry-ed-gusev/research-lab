package ru.kzgroup.mesUtil.engine.db;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import static ru.kzgroup.MesUtilDefaults.DBOBJECT_TYPE;

/**
 * Module for analizing exported MES DB. DB should be exported into sql-script file (class
 * works with sql text, it searches CREATE TABLE ... and CREATE PROCEDURE/FUNCTION constructions).
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 15.05.13)
 */

// todo: move files check operation to separate method...? and we can use this method in constructor and in
// todo: other methods (processing).

public class MesExportedDbAnalizer extends AbstractDbAnalizer {

    // sql queries for search (in sql scripts files) to determine db objects names
    private static enum Queries {
        CREATE_TABLE("CREATE TABLE"), CREATE_PROCEDURE(" PROCEDURE"), CREATE_FUNCTION(" FUNCTION");

        private final String query;

        private Queries(String query) {
            this.query = query;
        }

        public String getQuery() {
            return this.query;
        }

    }

    private Log log = LogFactory.getLog(MesExportedDbAnalizer.class);

    // list of sql scripts to process
    private Set<String> scripts;

    /***/
    // todo: maybe we should check files (exists and is a file) in a moment of processing (method getDbObjects())?
    public MesExportedDbAnalizer(String... exportedDbScripts) {
        log.debug("MesExportedDbAnalizer constructor() working.");
        if (exportedDbScripts != null && exportedDbScripts.length > 0) {
            this.scripts = new TreeSet<String>();
            for (String script : exportedDbScripts) {
                if (!StringUtils.isBlank(script) && new File(script).exists() && new File(script).isFile()) {
                    this.scripts.add(script);
                } else {
                    log.error("Invalid script file [" + script + "]! Name is empty or file doesn't exists or not a file!");
                }
            } // end for processing of scripts list
            if (this.scripts.isEmpty()) {
                throw new IllegalArgumentException("No valid scripts in db scripts list!");
            }
        } else { // empty scripts list
            throw new IllegalArgumentException("Empty exported db scripts list!");
        }
    }

    /***/
    private Map<String, DBOBJECT_TYPE> extractDbObjects(String sqlScript) {
        log.debug("MesExportedDbAnalizer.extractDbObjects() working (PRIVATE).");

        Map<String, DBOBJECT_TYPE> result = new TreeMap<String, DBOBJECT_TYPE>();
        if (!StringUtils.isBlank(sqlScript)) {
            log.debug("Sql script string is ok. Processing.");

            // processing all scripts in enumeration
            for (Queries query : Queries.values()) {
                // processing script
                String strQuery = query.getQuery();
                int index = sqlScript.indexOf(strQuery);
                while (index >= 0) {
                    // extract rough name
                    String objectName = StringUtils.trimToEmpty(
                            sqlScript.substring(index + strQuery.length(), sqlScript.indexOf("(", index)));
                    // clean up name
                    objectName = objectName.replaceAll("\"", ""); // remove " symbols
                    String[] tmp = objectName.split("\\.");
                    //log.debug(tmp.length + " - " + tableName.indexOf("."));
                    objectName = tmp[tmp.length - 1];

                    // select db object type (by query)
                    DBOBJECT_TYPE objectType;
                    switch (query) {
                        case CREATE_TABLE:
                            objectType = DBOBJECT_TYPE.TABLE;
                            break;
                        case CREATE_PROCEDURE:
                            objectType = DBOBJECT_TYPE.PROCEDURE;
                            break;
                        case CREATE_FUNCTION:
                            objectType = DBOBJECT_TYPE.FUNCTION;
                            break;
                        default:
                            objectType = DBOBJECT_TYPE.UNKNOWN;
                    }

                    result.put(objectName, objectType);
                    //log.debug(tableName);
                    //tablesList.add(objectName);
                    index = sqlScript.indexOf(strQuery, index + strQuery.length());
                }
            }
        } else {
            log.error("Empty sql script string!");
        }
        return result;
    }

    /***/
    @Override
    public Map<String, DBOBJECT_TYPE> getDbObjects() {
        log.debug("MesExportedDbAnalizer.getDbObjects() working.");
        Map<String, DBOBJECT_TYPE> result = new TreeMap<String, DBOBJECT_TYPE>();

        // processing all sql scripts
        for (String script : this.scripts) {

            // todo: we already have done this check during object creation (constructor). But what if
            // todo: between that moment and now files were changed? (remove check from constructor?)
            // check sql script
            if (!StringUtils.isBlank(script)) {
                File dbScriptFile = new File(script);
                if (dbScriptFile.exists() && dbScriptFile.isFile()) {
                    log.debug("MES DB script [" + script + "] exists and is a file! Processing.");
                    // start processing of DB script
                    BufferedReader bReader = null;
                    FileReader fReader = null;
                    try {
                        log.debug("Opening file [" + script + "].");
                        fReader = new FileReader(script);
                        bReader = new BufferedReader(fReader);

                        // reading file into buffer
                        String line;
                        StringBuilder sqlScript = new StringBuilder();
                        while ((line = bReader.readLine()) != null) {
                            if (!StringUtils.trimToEmpty(line).startsWith("--")) { // skip comments
                                sqlScript.append(line);
                            }
                        }
                        log.debug("File has been read.");
                        // extracting tables names from script (only for queries from enum)
                        result.putAll(this.extractDbObjects(sqlScript.toString()));
                    } catch (IOException e) { // if we have troubles with one file - we will process next file
                        log.error("Can't read file [" + script + "]!", e);
                    } finally { // free resources
                        if (bReader != null) {
                            try {
                                bReader.close();
                            } catch (IOException e) {
                                log.error("Can't close BufferedReader for [" + script + "] file!", e);
                            }
                        }

                        if (fReader != null) {
                            try {
                                fReader.close();
                            } catch (IOException e) {
                                log.error("Can't close FileReader for [" + script + "] file!", e);
                            }
                        }
                    }
                } else { // invalid script file
                    log.error("MES DB script file [" + script + "] doesn't exist or not a file!");
                }
            } else {
                log.error("Path to MES DB script is empty!");
            }
        } // end of for cycle

        return Collections.unmodifiableMap(result);
    }

}