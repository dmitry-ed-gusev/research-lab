package ru.kzgroup.domain.dto;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.Date;

/**
 * Base abstract class for all domain objects. It aggregates common fields.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 17.02.14)
*/

public abstract class BaseDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private Date   registerDate;
    private String registerUser;
    private Date   modifyDate;
    private String modifyUser;
    private int    deleted      = 0; // new object (instance) always is active (not deleted)

    public Date getRegisterDate() {
        return registerDate;
    }

    public void setRegisterDate(Date registerDate) {
        this.registerDate = registerDate;
    }

    public String getRegisterUser() {
        return registerUser;
    }

    public void setRegisterUser(String registerUser) {
        this.registerUser = registerUser;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("registerDate", registerDate)
                .append("registerUser", registerUser)
                .append("modifyDate", modifyDate)
                .append("modifyUser", modifyUser)
                .append("deleted", deleted)
                .toString();
    }

}