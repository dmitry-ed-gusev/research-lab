package ru.kzgroup.components.report.reportTable;

import org.junit.Test;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 11.08.2014)
*/

// todo: implement tests for component
public class TextTableModelTest {

    @Test
    public void isEmptyTest() {
    }

}