package ru.kzgroup.domain.dto.customers.report;

import org.junit.Test;
import ru.kzgroup.exceptions.InternalException;
import ru.kzgroup.domain.dto.customers.CustomerDto;

/**
 * Unit test for CustomerReport class.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 21.07.2014)
*/

public class CustomerReportTest {

    @Test(expected = InternalException.class)
    public void testConstructorException1() throws InternalException {
        new CustomerReport(null);
    }

    @Test(expected = InternalException.class)
    public void testConstructorException2() throws InternalException {
        new CustomerReport(new CustomerDto());
    }

}