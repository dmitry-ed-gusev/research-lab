04.04.2014

This module is intended for:
 - mining (get) data from technoligy systems: north-south scrap weighers (shop 100), express-laboratory (shop 100)