package ru.kzgroup.technology.dataMiner.processors.lab100;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.kzgroup.exceptions.DataMinerException;
import ru.kzgroup.dataProcessing.ProcessorInterface;
import ru.kzgroup.domain.dto.laboratory.ChemicalComposition;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static ru.kzgroup.MesUtilDefaults.COMMON_DATE_FORMAT;
import static ru.kzgroup.MesUtilMessages.*;

/**
 * Utility class for processing data from shop 100 laboratory (text file ANALYSEN.DAT from spectrometr). Result of
 * processing is a collection of immutable objects ChemicalComposition.
 * Notes:
 * - class can't be final, because frameworks Spring/Hibernate use proxy and can't subclass final class
 *
 * <p>27.07.13
 * There are 3 (three, or more) ways to get info:
 * 1. read the data file via network and process it (parse strings and create objects collection) in one cycle -
 * the slowest way (more than 20 seconds - 27.07.13)
 * 2. read tha data file via network in one cycle without processing (about 13-15 seconds - 27.07.13) and process
 * data in other cycle (about 5-10 seconds - 27.07.13). In this case we can reduce file access time via network -
 * its better, than previous case
 * 3. copy file to local temp folder (about 3-5 seconds - 27.07.13) and process local copy of the file (5-10 seconds).
 * The third way is the fastest - processing local file is faster, than processing file via network.
 * I think, we have to use the third way, because we access file via network in the shortest time. And I implemented
 * processing data file in the third way (case 3).
 *
 * <p>31.07.2013
 * We will not sort chemical composition data by time, because this data already sorted in source data file (ANALYSEN.DAT).
 *
 * <p>07.02.2014
 * For this processor we will use pure spring - we dont need Hibernate here.
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 23.07.13)
 */

@Component
@Transactional
public class Lab100DataProcessor implements ProcessorInterface {

    private Log log = LogFactory.getLog(Lab100DataProcessor.class);

    // constants
    private static final String           LAB100_LOCAL_TEMP_FILE = "c:/temp/lab100temp/ANALYSEN.DAT"; // local data file
    private static final SimpleDateFormat SDF_COMMON_DATE_FORMAT = new SimpleDateFormat(COMMON_DATE_FORMAT);
    private static final String           MAX_DATETIME_SQL       =
            "select to_char(max(to_date(ITEM_3, 'dd-mm-yyyy HH24:MI:SS')), 'dd-mm-yyyy HH24:MI:SS') as tc_date from TB_PO_LEVEL2_INTERFACE where TC_ID = 'D1TR002'";

    @Value("${lab100.filename}")
    private String         lab100FileName; // lab 100 source data file (file on network)
    @Autowired @Qualifier("oraJdbcTemplate")
    private JdbcTemplate   jdbcTemplate;   // JDBC Template for interacting with Oracle database

    public Lab100DataProcessor() {} // default constructor for framewroks compatibility (we can omit it)

    /**
     * Method work algoritm: copy data file from lab100 to local temp filder, read file into list of strings, process every
     * string - split by space, remove empty columns, add resulting lines to another list, create ChemicalComposition object
     * for every non-empty line, add created objects to list of ChemicalComposition objects. After all -> batch insert data
     * into table in Oracle.
    */
    public void process() {
        log.debug("Lab100DataProcessor.process() working.");
        try {
            // copy lab100 data file to local temp folder
            FileUtils.copyFile(new File(this.lab100FileName), new File(LAB100_LOCAL_TEMP_FILE));
            log.debug("File [" + this.lab100FileName + "] has been copied to [" + LAB100_LOCAL_TEMP_FILE + "].");

            // Now we have copied source file - we can process local file (its faster, than process remote file).
            // In this case we will use Java 7 feature - try-with-resouirces
            try (FileReader     freader    = new FileReader(LAB100_LOCAL_TEMP_FILE); // characters files reader
                 BufferedReader breader    = new BufferedReader(freader)             // buffered reader stream for reading characters files
            ) {
                // get max date value for current telegrams type
                Date maxDate;
                List<String> maxDatesList = jdbcTemplate.queryForList(MAX_DATETIME_SQL, String.class);
                if (maxDatesList == null || maxDatesList.isEmpty() || StringUtils.isBlank(maxDatesList.get(0))) {
                    maxDate = null;
                } else {
                    maxDate = SDF_COMMON_DATE_FORMAT.parse(maxDatesList.get(0));
                }

                // processing file line-by-line
                String line;        // current line from data file
                int    counter = 0; // inserted records counter (OK records)
                log.debug("Reading data file [" + LAB100_LOCAL_TEMP_FILE + "].");
                List<String> compositions = new ArrayList<>();
                while ((line = breader.readLine()) != null) {
                    if (!StringUtils.isBlank(line)) { // we will skip empty lines
                        String[] tmpLine = line.split(" ");
                        List<String> oneLine = new ArrayList<>();
                        // create one line list - we will remove empty columns
                        for (String column : tmpLine) {
                            if (!StringUtils.isBlank(column)) {
                                oneLine.add(StringUtils.trimToEmpty(column));
                            }
                        }
                        // Create object from data line. In case of exception - we will skip this line (don't stop
                        // entire process). Skipped line will be writed to log file.
                        try {
                            ChemicalComposition composition = Lab100Helper.getCompositionObject(oneLine, maxDate);
                            // If we don't accept data line by date - we receive null value (skip it). And we will filter
                            // composition objects by sequence number - if its equal '?', than we have wrong chemical test
                            // number - not in format MXXXX-Y[Z|-] (see comment in getCompositionObject() method) - we will not
                            // skip it, because it is a "TEST" measurement - we will send it to.
                            if (composition != null /*&& !UNKNOWN_SEQUENCE_TEST_VALUE.equals(composition.getMeltSequence())*/) {
                                compositions.add(composition.getInsertSql());
                                counter++; // increment OK records counter
                            }
                        } catch (ParseException | DataMinerException e) {
                            log.error(String.format("Exception [%1$s] on line [%2$s]!", e.getClass(), oneLine));
                            //log.debug(e); // print stack trace only in debug mode?
                        }
                    } else { // skipped empty line
                        log.warn("Empty line in lab100 data file!");
                    }
                } // end of while - reading and processing data file
                log.debug("Processing cycle finished.");

                if (!compositions.isEmpty()) { // if found objects list isn't empty - process it
                    jdbcTemplate.batchUpdate(compositions.toArray(new String[compositions.size()]));
                }
                log.info(String.format(MSG_LAB100_PROCESSED_OK, counter, SDF_COMMON_DATE_FORMAT.format(maxDate)));
            } catch (IOException | ParseException e) {
                log.error(e.getMessage(), e);
            } finally { // free resources and clean
                try { // deleting local temp file (if it exists)
                    File tmpFile = new File(LAB100_LOCAL_TEMP_FILE);
                    if (tmpFile.exists()) {
                        FileUtils.forceDelete(tmpFile);
                        log.debug("File [" + LAB100_LOCAL_TEMP_FILE + "] deleted.");
                    } else {
                        log.warn("File [" + LAB100_LOCAL_TEMP_FILE + "] doesn't exists!");
                    }
                } catch (IOException e) {
                    log.error("Can't delete temp file [" + LAB100_LOCAL_TEMP_FILE + "]!", e);
                }
            }
        } catch (IOException e) {
            //log.error(e.getMessage(), e); // <- too much output with stack trace
            log.error(e.getMessage());
        }
        log.debug("Lab 100 data mining finished.");
    }

}