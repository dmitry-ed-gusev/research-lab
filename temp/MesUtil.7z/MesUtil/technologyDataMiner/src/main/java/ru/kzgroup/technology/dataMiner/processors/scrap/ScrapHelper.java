package ru.kzgroup.technology.dataMiner.processors.scrap;

import com.healthmarketscience.jackcess.Database;
import com.healthmarketscience.jackcess.Table;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.domain.dto.scrap.MetalFilling;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static ru.kzgroup.MesUtilDefaults.COMMON_DATE_FORMAT;

/**
 * Utility class for scrap data processor.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 07.02.14)
*/

public final class ScrapHelper {

    private static Log log = LogFactory.getLog(ScrapHelper.class);

    // date/time formats for scrap DB (MS Access format)
    private static final SimpleDateFormat SDF_SCRAPDB_DATETIME_FORMAT = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.US);
    private static final SimpleDateFormat SDF_SCRAPDB_TIME_FORMAT     = new SimpleDateFormat("HH:mm:ss");
    private static final SimpleDateFormat SDF_SCRAPDB_DATE_FORMAT     = new SimpleDateFormat("dd-MM-yyyy");
    private static final SimpleDateFormat SDF_COMMON_DATE_FORMAT      = new SimpleDateFormat(COMMON_DATE_FORMAT);
    private static final String           SCRAP_DATA_TABLE            = "tb_data"; // data table name in SCRAP DB

    private ScrapHelper() {}

    /***/
    public static List<MetalFilling> getScrapDataFromFile(String scrapDataFile, Date startDate) throws IOException {
        List<MetalFilling> metalFillingsList = new ArrayList<>(); // result map of objects MetalFilling
        // open MS ACCESS db and read table
        Table table = Database.open(new File(scrapDataFile)).getTable(SCRAP_DATA_TABLE);
        // iterate trough rows and get data
        for(Map<String,Object> row : table) {
            try { // try..catch - for catching parse exceptions, if it occurs, we will skip whole line (row)
                int scrapCode = Integer.parseInt(String.valueOf(row.get("Код"))); // scrap code

                // We will skip some lines - control weighing, new melt line.
                // New melt: "код" = 101 (1st furnance), 102 (2nd), 103 (3rd), 104 (4th).
                // Control weighing: "код" = 201
                if (scrapCode != 101 && scrapCode != 102 && scrapCode != 103 && scrapCode != 104 && scrapCode != 201) {
                    // Composite timestamp (two rows). We will compare this datetime with received startDate parameter and discard all
                    // data rows with datetime, less than startDate. If startDate is null - we will accept all data lines.
                    Date   time        = SDF_SCRAPDB_DATETIME_FORMAT.parse(String.valueOf(row.get("Время"))); // time value
                    Date   date        = SDF_SCRAPDB_DATETIME_FORMAT.parse(String.valueOf(row.get("Дата")));  // date value
                    String strDateTime = SDF_SCRAPDB_DATE_FORMAT.format(date) + " " + SDF_SCRAPDB_TIME_FORMAT.format(time);
                    Date   dateTime    = SDF_COMMON_DATE_FORMAT.parse(strDateTime);

                    // check date for data row
                    if (startDate == null || dateTime.after(startDate)) { // we will accept this data row
                        //String meltNumber   = String.valueOf(row.get("Номер плавки"));          // melt number
                        int meltNumber = Integer.parseInt(String.valueOf(row.get("Номер плавки")));          // melt number
                        // if melt number = 0, its just weighing - not for concrete melt - we will skip it
                        if (meltNumber > 0) {
                            int    key            = Integer.parseInt(String.valueOf(row.get("key"))); // metal filling key
                            // weighing sign "+" -> "A" (add) or "-" (any other "+") -> "D" (delete)
                            String weighingSign   = (String.valueOf(row.get("Признак взвешивания")).equals("+") ? "A" : "D");
                            String scrapName      = String.valueOf(row.get("Наименование"));                                     // scrap name
                            // for integer values we will use truncating, because all values are exactly in kg (no grams)
                            int    totalWeight    = (int) Double.parseDouble(String.valueOf(row.get("Общий вес")));              // total weight
                            int    netWeight      = (int) Double.parseDouble(String.valueOf(row.get("Чистый вес")));             // net (чистый вес)
                            int    moldWeight     = (int) Double.parseDouble(String.valueOf(row.get("Вес пустых мульд")));       // вес пустых мульд
                            int    moldCount      = (int) Double.parseDouble(String.valueOf(row.get("Количество мульд")));       // кол-во мульд
                            int    furnanceNumber = (int) Double.parseDouble(String.valueOf(row.get("Номер принимающей печи"))); // number
                            // weigher sign: 1 -> N (north), 2 -> S (south)
                            String weigher        = (String.valueOf(row.get("ScalesNo")).equals("1") ? "N" : "S");
                            // creating metal filling object
                            MetalFilling metalFilling = new MetalFilling(key, meltNumber, strDateTime, weighingSign, scrapCode, scrapName,
                                    totalWeight, netWeight, moldWeight, moldCount, furnanceNumber, weigher);
                            metalFillingsList.add(metalFilling);
                        }
                    }
                }
            } catch (ParseException | NumberFormatException e) {
                log.error(e.getMessage(), e);
            }

        } // end of for -> rows processing

        return metalFillingsList;
    }

}