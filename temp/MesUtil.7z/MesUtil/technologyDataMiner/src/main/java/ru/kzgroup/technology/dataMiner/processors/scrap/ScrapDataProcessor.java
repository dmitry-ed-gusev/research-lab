package ru.kzgroup.technology.dataMiner.processors.scrap;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.kzgroup.dataProcessing.ProcessorInterface;
import ru.kzgroup.domain.dto.scrap.MetalFilling;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static ru.kzgroup.MesUtilDefaults.COMMON_DATE_FORMAT;
import static ru.kzgroup.MesUtilMessages.MSG_SCRAP_PROCESSED_OK;

/**
 * <p>31.07.2013
 * We have to sort all objects by timestamp (composite from two fields), because we have two data sources - north
 * and south weighers (weighing is mixed south-north-south-nosth - any oredr is possible).
 * <p/>
 * <p>07.02.2014
 * For this processor we will use pure spring - we dont need Hibernate here.
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 27.07.13)
 */

@Component
@Transactional
public class ScrapDataProcessor implements ProcessorInterface {

    private static Log log = LogFactory.getLog(ScrapDataProcessor.class);

    private static final SimpleDateFormat SDF_COMMON_DATE_FORMAT = new SimpleDateFormat(COMMON_DATE_FORMAT);

    // todo: change query - get last record not by date/time, but by sequence_key! if date/time corrupted in Oracle - module crashes (date/time in ORA here is varchar!)
    // todo: if last is corrupted - get previous - 10 times (records) is enough
    private static final String           MAX_DATETIME_SQL       =
            "select to_char(max(to_date(ITEM_9, 'dd-mm-yyyy HH24:MI:SS')), 'dd-mm-yyyy HH24:MI:SS') as tc_date from TB_PO_LEVEL2_INTERFACE where TC_ID = 'D1TR001'";

    @Value("${scrap.north.filename}")
    private String northWeigherFileName; // north weigher data file
    @Value("${scrap.south.filename}")
    private String southWeigherFileName; // south weigher data file
    // All data processing flag: true -> we will ignore dates and transfer all data from scrap weighing to
    // MES DB; false -> we will use max datetime telegram value from MES DB. This flag is set during object creation
    // and can't be changed later. Default value = false;
    @Value("${scrap.processAllData}")
    private boolean      processAllData;
    @Autowired @Qualifier("oraJdbcTemplate")
    private JdbcTemplate jdbcTemplate;         // JDBC Template for interacting with Oracle database (MES)

    /***/
    @Override
    public void process() {
        log.debug("ScrapDataProcessor.process() working.");
        try {
            Date maxDate; // max telegram date
            if (!this.processAllData) { // get max telegram date from MES DB telegrams table
                List<String> maxDatesList = jdbcTemplate.queryForList(MAX_DATETIME_SQL, String.class);
                if (maxDatesList == null || maxDatesList.isEmpty() || StringUtils.isBlank(maxDatesList.get(0))) {
                    maxDate = null;
                } else {
                    maxDate = SDF_COMMON_DATE_FORMAT.parse(maxDatesList.get(0));
                }
            } else {
                maxDate = null;
            }
            // gete data from weighers file (north and south)
            List<MetalFilling> fillingsList = new ArrayList<>(); // all data from north/south weighers
            fillingsList.addAll(ScrapHelper.getScrapDataFromFile(this.northWeigherFileName, maxDate));
            log.debug("Data from north weigher received.");
            fillingsList.addAll(ScrapHelper.getScrapDataFromFile(this.southWeigherFileName, maxDate));
            log.debug("Data from south weigher received.");
            // Cycle - process all MetalFilling objects and create sql batch. We use two different cycles - one for
            // creating Map of objects and another for put data into DB - it reduces loading time of MES DB
            int counter = 0; // inserted records counter (OK records)
            List<String> fillings = new ArrayList<>();
            for (MetalFilling oneFilling : fillingsList) {
                fillings.add(oneFilling.getInsertSql());
                counter++;
            }
            log.debug("Processing cycle finished.");

            if (!fillings.isEmpty()) { // execute sql queries in a batch, if there are queries
                jdbcTemplate.batchUpdate(fillings.toArray(new String[fillings.size()]));
            }
            log.info(String.format(MSG_SCRAP_PROCESSED_OK, counter, SDF_COMMON_DATE_FORMAT.format(maxDate)));
        } catch (IOException | ParseException e) {
            // log.error(e.getMessage(), e); // <- too much output with stack trace
            log.error(e.getMessage());
        }
        log.debug("Scrap data mining finished.");
    }

}