package ru.kzgroup.technology.dataMiner.processors.lab100;

import org.apache.commons.lang3.StringUtils;
import ru.kzgroup.exceptions.DataMinerException;
import ru.kzgroup.domain.dto.laboratory.ChemicalComposition;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static ru.kzgroup.MesUtilDefaults.COMMON_DATE_FORMAT;
import static ru.kzgroup.MesUtilDefaults.LAB100_SOURCE_DATE_FORMAT;
import static ru.kzgroup.domain.dto.laboratory.ChemicalComposition.ZERO_VALUE;

/**
 * Helper class for processing Lab100 data.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 06.02.14)
*/

public final class Lab100Helper {

    private static final int              DATE_TIME_COLUMN            = 0;   // date/time column in a data string
    private static final int              MELT_NUMBER_COLUMN          = 3;   // melt number/sequence column
    // min length (in symbols) of data in first (datetime) column
    private static final int              DATETIME_COLUMN_MIN_LENGTH  = 17;
    // format of chemical element value in MES DB (interface table)
    private static final DecimalFormat    ELEMENT_VALUE_DB_FORMAT     = new DecimalFormat("#0.000#");
    // this is border column between date/time/melt/sequence columns and first column with chemical info
    private static final String           BORDER_COLUMN_VALUE         = "026C";
    private static final String           UNKNOWN_SEQUENCE_TEST_VALUE = "?"; // chemical test sequence number is unknown
    private static final SimpleDateFormat SDF_COMMON_DATE_FORMAT      = new SimpleDateFormat(COMMON_DATE_FORMAT);

    private Lab100Helper() {} // this is just utility class - no instances

    /**
     * Method extracts chemical elemet-value pairs from one data string.
    */
    private static Map<String, String> getElementsMap(List<String> dataLine) throws DataMinerException {
        Map<String, String> result; // resulting map

        if (dataLine == null || dataLine.isEmpty()) { // if input data is empty - we will return empty resutl
            result = Collections.emptyMap();
        } else {
            result = new LinkedHashMap<>();  // Java 7 feature - "diamond syntax"
            // Processing chemical data (usual this are columns 5-28). We iterate over list of strings, and when we reach
            // column with value "026C", we set up flag to true and start processing chemical data from next column.
            boolean startProcessing = false;
            for (int i = 0; i < dataLine.size(); i++) {
                String currentColumn = dataLine.get(i);

                if (!StringUtils.isBlank(currentColumn)) { // if current column is OK - process it
                    if (startProcessing) { // if flag set we start processing chemical data
                        String elementName = dataLine.get(i - 1).replaceAll("[^a-zA-Z]", "");        // get just letters (name);
                        StringBuilder elementValueBuilder = new StringBuilder();
                        if (currentColumn.startsWith("<")) {
                            elementValueBuilder.append(ZERO_VALUE);
                        } else {
                            try {
                                // get just digits and decimal point (value) and after parse double value from String
                                double dValue = Double.parseDouble(currentColumn.replaceAll("[^\\.0123456789]", ""));
                                // format value and replace [,]->[.]
                                elementValueBuilder.append(ELEMENT_VALUE_DB_FORMAT.format(dValue).replaceAll(",", "."));
                                // value should be 6 characters length
                                if (elementValueBuilder.length() < 6) {
                                    elementValueBuilder.append("0");
                                }
                            } catch (NumberFormatException | ArithmeticException e) {  // NFE -> .parseDouble() | AE -> .format()
                                throw new DataMinerException(e);
                            }
                        }
                        // put element=value pair into map
                        result.put(elementName, elementValueBuilder.toString());
                    }

                    // check column value
                    if (BORDER_COLUMN_VALUE.equals(currentColumn)) {
                        startProcessing = true; // set flag - we have to start processing from next iteration
                    }
                } else { // current column is empty - we will throw exception
                    throw new DataMinerException("Empty column in data line [" + dataLine + "]!");
                }

            } // end of FOR cycle
        }
        // return unmodifiable map, because we will create immutable object ChemicalComposition
        return Collections.unmodifiableMap(result);
    }

    /**
     * Method creates one ChemicalComposition object from data string. If startDate is later (in time), than timestamp
     * in a dataLine, we will discard this dataLine - method returns null.
     * @param startDate Date We will create objects for lines with timestamp > startDate (timestamp in a line should
     * be AFTER startDate in time). If startDate is null, we will accept all data lines. If we don't accept data line
     * we will return null value (implementation details).
     */
    public static ChemicalComposition getCompositionObject(List<String> dataLine, Date startDate) throws ParseException, DataMinerException {
        ChemicalComposition composition;

        if (dataLine == null || dataLine.isEmpty()) { // check data line - if its empty we return null object
            composition = null;
        } else {                                      // data line is ok - processing
            // Field/column 0 - date/time. Values in special positions in string.
            String dateTimeColumn = dataLine.get(DATE_TIME_COLUMN);
            // check column value
            if (StringUtils.isEmpty(dateTimeColumn) || dateTimeColumn.length() < DATETIME_COLUMN_MIN_LENGTH) {
                throw new DataMinerException("Column with date/time is empty or too short (length < " + DATETIME_COLUMN_MIN_LENGTH + ")!");
            }
            Date resultDate = LAB100_SOURCE_DATE_FORMAT.parse(dateTimeColumn.substring(4, 16));
            // if startDate is null or our date > startDate, we will accept this line and create object
            if (startDate == null || resultDate.after(startDate)) {
                String resultDateStr = SDF_COMMON_DATE_FORMAT.format(resultDate);

                // Field/column 3 - melt number and test number.
                // Right chemical test number is MXXXX-Y[Z|-], first part (MXXXX) is melt number, second part (Y[Z|-])
                // is a chemical test sequence number, where:
                //  - M is a furnance index: 5 -> 1st furnance, 6 -> 2nd, 7 -> 3rd, 8 -> 4th, others is wrong
                //  - X is a digit 0..9
                //  - Y and Z are digits 0..9 and, also, may be letters a-zA-Z.
                // Some special cases:
                //  - if Y=1 then sequence is [1-] - special case for first chemical test (transferring to some program)
                //  - if sequence is KZ, 5C, 6C, 7C - this is test from pouring (разливка), otherwise test is from ladle (ковшевая проба)
                // Any other values or other format of chemical test number is special chemical test (do we need it?)
                String meltNumberColumn = dataLine.get(MELT_NUMBER_COLUMN);
                int dashIndex = meltNumberColumn.indexOf("-");

                String meltNumber; // todo: use StringBuilder?
                String sequenceNumber;
                if (dashIndex == 5) { // right melt number - five digits XXXXX
                    meltNumber = meltNumberColumn.substring(0, 5);
                    if (dashIndex < meltNumberColumn.length() - 1) { // there is sequence number
                        sequenceNumber = meltNumberColumn.substring(dashIndex + 1, meltNumberColumn.length());
                    } else { // there is no sequence number
                        sequenceNumber = UNKNOWN_SEQUENCE_TEST_VALUE;
                    }
                } else { // invalid melt number - we get all columns values before column value [026C]
                    int columnCounter = MELT_NUMBER_COLUMN;
                    String columnValue = dataLine.get(columnCounter);
                    meltNumber = "";
                    while (columnCounter < dataLine.size() && !columnValue.equals(BORDER_COLUMN_VALUE)) {
                        meltNumber += columnValue + " ";
                        columnCounter++;
                        columnValue = dataLine.get(columnCounter);
                    }
                    meltNumber = StringUtils.trimToEmpty(meltNumber); // remove last space
                    sequenceNumber = UNKNOWN_SEQUENCE_TEST_VALUE;
                }
                // check resulting melt number and sequence number
                if (StringUtils.isBlank(meltNumber) || StringUtils.isBlank(sequenceNumber)) {
                    throw new DataMinerException("Empty melt number [" + meltNumber + "] or sequence [" + sequenceNumber + "]!");
                }
                // if we pass all checks and receive all data - create object
                composition = new ChemicalComposition(resultDateStr, meltNumber, sequenceNumber, Lab100Helper.getElementsMap(dataLine));
            } else { // we will not accept this line - result object is null
                composition = null;
            }
        }
        // resulting object
        return composition;
    }

}