package ru.kzgroup.technology.dataMiner;

import gusev.dmitry.jtils.spring.CustomPropertySource;
import gusev.dmitry.jtils.utils.CommandLine;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Locale;

import static ru.kzgroup.MesUtilDefaults.CUSTOM_PROPERTY_ORA_HOST;
import static ru.kzgroup.utils.CmdLineOptions.ORA_HOST;

/**
 * Main module of TechnologyDataMiner application.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 04.04.2014)
 */

// todo: IMPORTANT! if runtime error occurs, we don't have record in log file about it!!!
// todo: records modifier name - lab100, scrap weighers

public class TechnologyDataMinerMain {

    private static       Log    log                = LogFactory.getLog(TechnologyDataMinerMain.class);
    private static final String SPRING_CONFIG_NAME = "spring/TechnologyDataMinerContext.xml";

    /**
     * Main app method. Starting whole app cycle - load Spring/Hiber container and all resources and finish main thread.
    */
    public static void main(String[] args) {
        Log log = LogFactory.getLog(TechnologyDataMinerMain.class);
        log.info("TechnologyDataMiner started.");
        Locale.setDefault(Locale.US); // without this setting Oracle XE refuses connections (we have to set locale value).
        // processing command line arguments
        CommandLine cmdLine = new CommandLine(args); // read command line
        String      oraHost = cmdLine.optionValue(ORA_HOST.getOptionName()); // get value for -oraHost option
        try {
            // load spring application context with changed property value
            AbstractApplicationContext context = new ClassPathXmlApplicationContext(new String[] {SPRING_CONFIG_NAME}, false);
            if (!StringUtils.isBlank(oraHost)) { // add new value for custom property
                context.getEnvironment().getPropertySources().addLast(new CustomPropertySource("custom", CUSTOM_PROPERTY_ORA_HOST, oraHost));
            }
            context.refresh(); // refresh context (load it completely)
            log.debug("Application context initialized and loaded.");
        } catch (BeansException e) { // context loading exception
            log.error(String.format("Can't load context from [%s]!", "TechnologyDataMinerContext.xml"), e);
        }
        log.info("TechnologyDataMiner MAIN THREAD finished.");
    }

}