package ru.kzgroup.dataSync.engine.actions;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 10.05.2014)
 */
public class UpdateDataAction {
}
