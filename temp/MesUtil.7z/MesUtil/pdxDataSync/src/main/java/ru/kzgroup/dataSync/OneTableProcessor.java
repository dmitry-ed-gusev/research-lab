package ru.kzgroup.dataSync;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.transaction.annotation.Transactional;
import ru.kzgroup.dataProcessing.ProcessorInterface;
import ru.kzgroup.domain.dto.rawTables.m160.M160;

import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import static ru.kzgroup.MesUtilMessages.MSG_DIRECTORY_PROCESSED;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 13.02.14)
*/

@Transactional
public class OneTableProcessor<T> implements ProcessorInterface {

    private final Log log = LogFactory.getLog(OneTableProcessor.class);

    private Class<T>       clazz;
    private SessionFactory sourcePdxSessionFactory;
    private SessionFactory destPdxSessionFactory;

    public Class<T> getClazz() {
        return clazz;
    }

    public void setClazz(Class<T> clazz) {
        this.clazz = clazz;
    }

    public SessionFactory getSourcePdxSessionFactory() {
        return sourcePdxSessionFactory;
    }

    public void setSourcePdxSessionFactory(SessionFactory sourcePdxSessionFactory) {
        this.sourcePdxSessionFactory = sourcePdxSessionFactory;
    }

    public SessionFactory getDestPdxSessionFactory() {
        return destPdxSessionFactory;
    }

    public void setDestPdxSessionFactory(SessionFactory destPdxSessionFactory) {
        this.destPdxSessionFactory = destPdxSessionFactory;
    }

    /***/
    private List getDataListFromSource() {
        List    result;
        Session pdxSession = null;
        try {
            pdxSession = sourcePdxSessionFactory.openSession();
            result     = pdxSession.createQuery("from " + clazz.getName()).list();
        } finally {
            if (pdxSession != null) {
                pdxSession.close();
            }
        }
        return result;
    }

    /***/
    @Override
    public void process() {
        log.debug("OneDirectoryProcessor.process() working. Class [" + clazz.getName() + "].");
        List objects = this.getDataListFromSource();
        log.debug("Received -> " + objects.size());
        if (objects != null && !objects.isEmpty()) { // if we receive non-empty list, we process it
            log.debug("Processing data upload to Oracle (MES).");
            Session destSession = destPdxSessionFactory.openSession();
            int counter = 0;
            int processedCounter = 0;
            for (Object object : objects) { // upload data cycle
                //M160 sourceM160Object = (M160) object;
                counter++;
                Object obj = destSession.get(clazz, ((M160) object).getId());
                if (obj != null) {
                    //M160 destM160Object = (M160) obj;
                    if (/*sourceM160Object.equals(destM160Object)*/object.equals(obj)) {
                        //System.out.println("*");
                        //System.out.println("dest   -> " + destM160Object);
                        //System.out.println("source -> " + sourceM160Object);
                    } else {
                        System.out.println("***");
                        //System.out.println("dest   -> " + destM160Object);
                        //System.out.println("source -> " + sourceM160Object);
                        System.out.println("dest   -> " + obj);
                        System.out.println("source -> " + object);
                        //System.exit(5555);
                        destSession.merge(object);
                        processedCounter++;
                    }
                } else {
                    //destSession.update(object);
                    destSession.merge(object);
                    processedCounter++;
                    System.out.println("!!!!!");
                }
                //destSession.merge(object);           // merge object to DB (save or update)
                if (counter > 0 && counter % /*SESSION_FLUSH_STEP*/2000 == 0) { // every step for flush and release
                    //destSession.flush();
                    //destSession.clear();
                    log.debug("processed records -> " + counter);
                }

                //if (counter > 0 && counter % /*SESSION_FLUSH_STEP*/40000 == 0) {
                //    destSession.flush();
                //    destSession.clear();
                //    System.out.println("%%%%");
                //}

                if (processedCounter > 0 && processedCounter % 2000 == 0) {
                    destSession.flush();
                    destSession.clear();
                    log.debug("!!!!merged records -> " + counter);
                }
            } // end of FOR cycle

            destSession.flush();
            destSession.clear();

            log.info(String.format(MSG_DIRECTORY_PROCESSED, this.clazz.getSimpleName(), counter));
        } else { //nothing found
            log.warn("Objects [" + this.clazz.getSimpleName() + "] not found in Paradox DB!");
        }
    }

    /***/
    public void ppp() {
        log.debug("OneDirectoryProcessor.ppp() working. Class [" + clazz.getName() + "].");
        Session destSession = destPdxSessionFactory.openSession();
        List destList     = destSession.createQuery("from " + clazz.getName()).list();
        log.debug("Received dest objects -> " + destList.size());
        List sourceList = this.getDataListFromSource();
        log.debug("Received source objects -> " + sourceList.size());
        int counter = 0;
        int processedCounter = 0;
        Iterator iterator = sourceList.iterator();
        //for (Object object : sourceList) {
        while(iterator.hasNext()) {
            Object object = iterator.next();
            counter++;
            if (destList.contains(object)) {
                //destSession.update(object);
                //sourceList.remove(object);
                iterator.remove(); // remove current
                destList.remove(object);
            } else {
                destSession.merge(object);
                processedCounter++;
            }
            if (counter > 0 && counter % /*SESSION_FLUSH_STEP*/2000 == 0) { // every step for flush and release
                //destSession.flush();
                //destSession.clear();
                log.debug("processed records -> " + counter);
            }

            if (processedCounter > 0 && processedCounter % 2000 == 0) {
                destSession.flush();
                destSession.clear();
                log.debug("!!!!merged records -> " + counter);
            }
        }

        destSession.flush();
        destSession.clear();

        // remove from dest
        int zzz = 0;
        if (!destList.isEmpty()) {
            log.debug("Destination isn't empty - processing. " + destList.size());
            for (Object object : destList) {
                destSession.delete(object);
                zzz++;
            }
            destSession.flush();
            destSession.clear();
        }
        System.out.println("+++++++++++++++++ -> " + zzz);

        log.info(String.format(MSG_DIRECTORY_PROCESSED, this.clazz.getSimpleName(), counter));
        System.out.println("-> " + processedCounter);
    }

    /** just for test */
    public static void main(String[] args) {
        Log log = LogFactory.getLog(OneTableProcessor.class);
        log.info("OneDirectoryProcessor starting.");
        Locale.setDefault(Locale.US);

        final String SPRING_CONFIG_NAME = "spring/DataSyncContext.xml";
        AbstractApplicationContext context = new ClassPathXmlApplicationContext(new String[] {SPRING_CONFIG_NAME}, false);
        context.refresh();
        OneTableProcessor processor = (OneTableProcessor) context.getBean("baseDirectoryBean");
        processor.ppp();
        //processor.process();
    }

}