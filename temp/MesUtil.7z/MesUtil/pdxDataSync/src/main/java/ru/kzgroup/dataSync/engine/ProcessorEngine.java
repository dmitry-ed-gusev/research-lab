package ru.kzgroup.dataSync.engine;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.exceptions.InternalException;
import ru.kzgroup.dataSync.DataProcessor;
import ru.kzgroup.dataSync.config.ProcessorConfig;
import ru.kzgroup.dataSync.config.ProcessorFilterOptions;

import java.io.IOException;
import java.sql.*;

/**
 * Engine module for DataProcessor utility.
 * This class is immutable.
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 30.04.2014)
*/

// todo: check for key fields - comparing with database info (meta data)
// todo: disable apply filter to key fields

public final class ProcessorEngine {

    @SuppressWarnings("ConstantNamingConvention")
    private final static Log    log            = LogFactory.getLog(ProcessorEngine.class);
    private final static String CONNECTION_URL = "jdbc:paradox:///%s";

    private ProcessorConfig config;

    /***/
    public ProcessorEngine(ProcessorConfig config) throws InternalException {
        if (config == null) { // null config -> exception
            throw new InternalException("Empty ProcessorConfig object!");
        }
        this.config = config;
    }

    /***/
    private void replaceData() { // current algorithm
        //todo: implement
    }

    /***/
    private void updateData(ResultSetMetaData metaData, ResultSet sourceResultSet, Connection destConnection) throws SQLException {
        log.debug("ProcessorEngine.updateData() working [PRIVATE].");
        // check key fields - without it we can't update data
        String checkResult = EngineHelper.checkKeyFields(metaData, this.config);
        if (EngineHelper.OK_RES.equals(checkResult)) { // specified key fields list is OK
            log.debug("Specified key fields list is OK. Processing next.");

            // meta data is OK - processing
            String insertSql = EngineHelper.getInsertSql(metaData, this.config);
            String updateSql = EngineHelper.getUpdateSql(metaData, this.config);
            String checkSql  = EngineHelper.getCheckSql(this.config);

            // preparing statements for update data into destination
            try (PreparedStatement insertStmt = destConnection.prepareStatement(insertSql);
                 PreparedStatement updateStmt = destConnection.prepareStatement(updateSql);
                 PreparedStatement checkStmt  = destConnection.prepareStatement(checkSql);
                 Statement         destStmt   = destConnection.createStatement()) {

                // preparing cycle
                int batchSize         = 0; // current batch size counter
                int counter           = 0; // processed records counter
                int columnsCount      = StringUtils.countMatches(updateSql, "?"); // we can omit some fields and count of real fields will be decreased
                int startColumnNumber = this.config.getDestKeyFields().size() + 1;

                // do we use a filter or not?
                boolean useFilter = (!this.config.getFilterFields().isEmpty() && !this.config.getFilterOption().equals(ProcessorFilterOptions.UNKNOWN));
                if (useFilter) { // message - we will use filter
                    log.info(String.format("Filter [%s] will be used for fields: %s.", this.config.getFilterOption(), this.config.getFilterFields()));
                }

                int insert = 0;
                int update = 0;
                do { // iterate over all received source data row-by-row (do..while -> we already moved RS pointer forward)

                    // put data into check sql query
                    for (int i = 1; i <= this.config.getDestKeyFields().size(); i++) {
                        checkStmt.setObject(i, sourceResultSet.getObject(i));
                    }
                    boolean isInsert = !checkStmt.executeQuery().next();

                    if (isInsert) {
                        insert++;
                    } else {
                        update++;
                    }

                    // check data existence in destination and select one of queries - insert/update

                    /*
                    // FOR cycle for put data into UPDATE part of query
                    for (int i = startColumnNumber; i <= columnsCount; i++) { // set data into prepared statement col-by-col
                        Object value = sourceResultSet.getObject(i); // value for this field
                        if (useFilter) { // there are filter fields and filter value
                            String currentFieldName = metaData.getColumnName(i);
                            if (this.config.getFilterFields().contains(currentFieldName)) {
                                // select filter option and apply it
                                switch (this.config.getFilterOption()) {
                                    case BLANK_TO_ZERO: // blank (null) fileds will be replaced with zeroes
                                        if (value == null) {
                                            updateStmt.setObject(i - this.config.getDestKeyFields().size(), 0);
                                        } else {
                                            destPStmt.setObject(i, value);
                                        }
                                        break;
                                    default:
                                        destPStmt.setObject(i, value); // unknown option - filter not applyed
                                }
                            } else { // current field not present in filter fields list
                                destPStmt.setObject(i, value);
                            }
                        } else { // we will not use filtering
                            destPStmt.setObject(i, value);
                        }
                    } // end of FOR cycle for one row

                    */

                    //destPStmt.addBatch();
                    batchSize++;
                    counter++;


                    if (batchSize >= DataProcessor.BATCH_EXECUTE_SIZE) { // we reached batch execute size - execute the batch!
                        //destPStmt.executeBatch();
                        if (counter % (DataProcessor.PROCESSING_INFO_MESSAGE_STEP * batchSize) == 0) { // log message X times seldom, than executing a batch
                            log.info(String.format("Processed [%s].", counter));
                        }
                        batchSize = 0; // reset batch size (for next step)
                    }

                } while (sourceResultSet.next()); // end of do-while processing cycle

                log.debug("insert [" + insert + "], update [" + update + "]");
                //destPStmt.executeBatch(); // execute remaining batch queries
                //log.info(String.format("Total processed [%s].", counter));


            } // end of TRY clause for destination prepared statement

        } else { // key fields list isn't OK - we will not process data
            log.error(checkResult);
        }

    }

    /***/
    private void fillPreparedInsertStmt(int columnsCount, ResultSet resultSet, boolean useFilter,
                                        ResultSetMetaData metaData, PreparedStatement insertPStmt) throws SQLException {
        for (int i = 1; i <= columnsCount; i++) { // set data into prepared statement col-by-col
            Object value = resultSet.getObject(i); // value for this field
            if (useFilter) { // there are filter fields and filter value
                String currentFieldName = metaData.getColumnName(i);
                if (this.config.getFilterFields().contains(currentFieldName)) {
                    // select filter option and apply it
                    switch (this.config.getFilterOption()) {
                        case BLANK_TO_ZERO: // blank (null) fileds will be replaced with zeroes
                            if (value == null) {
                                insertPStmt.setObject(i, 0);
                            } else {
                                insertPStmt.setObject(i, value);
                            }
                            break;
                        default:
                            insertPStmt.setObject(i, value); // unknown option - filter not applyed
                    }
                } else { // current field not present in filter fields list
                    insertPStmt.setObject(i, value);
                }
            } else { // we will not use filtering
                insertPStmt.setObject(i, value);
            }
        } // end of FOR cycle for one row
    }

    /***/
    @SuppressWarnings("CallToDriverManagerGetConnection")
    public void process() throws SQLException, IOException {
        log.debug("ProcessorEngine.process() working.");
        // connections URLs
        //String sourceUrl = "jdbc:paradox:///" + this.config.getSourcePath();
        //String destUrl   = "jdbc:paradox:///" + this.config.getDestPath();
        //log.debug(String.format("\nSouce URL [%s].\nDest URL [%s].", sourceUrl, destUrl));

        try (Connection sourceConnection   = DriverManager.getConnection(String.format(CONNECTION_URL, this.config.getSourcePath()));
             Connection destConnection     = DriverManager.getConnection(String.format(CONNECTION_URL, this.config.getDestPath()));
             PreparedStatement sourcePStmt = sourceConnection.prepareStatement("SELECT * FROM " + this.config.getSourceTable());
             Statement  destStmt           = destConnection.createStatement()) {

            log.debug("Connected to source and to destination.");
            // get all data from source table
            ResultSet resultSet = sourcePStmt.executeQuery();
            // get metadata from source
            ResultSetMetaData metaData = resultSet.getMetaData();

            if (metaData != null && resultSet.next()) { // data from source received and source isn't empty
                log.debug("All metaData data from source received, source isn't empty. Process next.");

                // select data copy method - [UPDATE] or [REPLACE]
                if (this.config.isUseUpdateMethod()) { // [UPDATE] data
                    log.info("Method [UPDATE] will be used.");
                    // call to update data method
                    this.updateData(metaData, resultSet, destConnection);

                } else { // [REPLACE] data
                    log.info("Method [REPLACE] will be used.");
                    try {
                        // clear destination table (truncate)
                        destStmt.executeUpdate("truncate table " + this.config.getDestTable());
                        log.info(String.format("Destination table [%s] cleared.", this.config.getFullDestPath()));
                    } catch (SQLException e) {
                        // we will try to repair only table RK110R
                        if ("RK110R".equals(this.config.getDestTable())) { // todo: hardcoded value!!!
                            log.error(String.format("Excuting query on destination table failed! Message -> [%s].", e.getMessage()));
                            log.info("Try to repair destination table.");
                            // try to replace destination with template
                            EngineHelper.copyTemplate(this.config); // -> in case of exception - leave it goes to upper level
                            // try again to clear destination, if we will receive exception again - leave it to upper level
                            destStmt.executeUpdate("truncate table " + this.config.getDestTable());
                            log.info(String.format("Destination table [%s] cleared.", this.config.getFullDestPath()));
                        } else { // for other table we will rethrow exception
                            throw new SQLException(e);
                        }
                    }

                    // generate insert sql query (for prepared statement)
                    String insertSql = EngineHelper.getInsertSql(metaData, this.config);
                    log.debug("Insert sql generated.");

                    try (PreparedStatement destPStmt = destConnection.prepareStatement(insertSql)) { // preparing statement for insert data into destination
                        // preparing cycle
                        int batchSize = 0; // current batch size counter
                        int counter = 0; // processed records counter

                        int columnsCount = StringUtils.countMatches(insertSql, "?"); // we can omit some fields and coun of real fields will be decreased

                        boolean useFilter = (!this.config.getFilterFields().isEmpty() && !this.config.getFilterOption().equals(ProcessorFilterOptions.UNKNOWN));
                        if (useFilter) { // message - we will use filter
                            log.info(String.format("Filter [%s] will be used for fields: %s.", this.config.getFilterOption(), this.config.getFilterFields()));
                        }
                        do { // iterate over all received source data row-by-row (do..while -> we already moved RS pointer forward)

                            // call method and fill one prepared statement with data
                            this.fillPreparedInsertStmt(columnsCount, resultSet, useFilter, metaData, destPStmt);
                            // add filled statement to batch
                            destPStmt.addBatch();

                            batchSize++;
                            counter++;

                            if (batchSize >= DataProcessor.BATCH_EXECUTE_SIZE) { // we reached batch execute size - execute the batch!
                                destPStmt.executeBatch();
                                if (counter % (DataProcessor.PROCESSING_INFO_MESSAGE_STEP * batchSize) == 0) { // log message X times seldom, than executing a batch
                                    log.info(String.format("Processed [%s].", counter));
                                }
                                batchSize = 0; // reset batch size (for next step)
                            }

                        } while (resultSet.next()); // end of do-while processing cycle

                        destPStmt.executeBatch(); // execute remaining batch queries
                        log.info(String.format("Total processed [%s].", counter));
                    } // end of TRY clause for destination prepared statement
                }
            } else { // source is empty (ResultSet is empty) - no data!
                log.error("Source is empty or meta data is empty! Can't process!");
            }
        } // end of main TRY clause

    } // end of process() method

}