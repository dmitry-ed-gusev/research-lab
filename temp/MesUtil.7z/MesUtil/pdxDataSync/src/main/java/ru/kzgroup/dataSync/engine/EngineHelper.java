package ru.kzgroup.dataSync.engine;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.dataSync.config.ProcessorConfig;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.LinkedHashSet;

/**
 * Helper utility class for ProcessorEngine module.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 07.05.2014)
*/

public final class EngineHelper {

    @SuppressWarnings("ConstantNamingConvention")
    private static final Log      log           = LogFactory.getLog(EngineHelper.class);

    // used for generating sql queries
    private final static String   AND_PIECE     = " AND "; // [ AND ] part for sql query
    // used for copy template for "healing" dest table in case of corruption
    private final static String[] DB_EXTENSIONS = {".DB", ".PX", ".XG0", ".YG0"}; // file extensions for DB template
    /** OK (positive) result for some actions */
    public  final static String   OK_RES        = "OK"; // OK result message

    private EngineHelper() {} // we can't create instance of this utility class

    /**
     * Helper method for generating SELECT sql query for check for existence of a record. It needs access to current instance config.
     */
    public static String getCheckSql(ProcessorConfig config) throws SQLException {
        log.debug("EngineHelper.getCheckSql() working.");
        // if there are no key fields - throw an exception
        if (config == null || config.getDestKeyFields().isEmpty()) {
            throw new SQLException("Empty config or key fields list!");
        }
        StringBuilder wherePart = new StringBuilder();
        for (String keyField : config.getDestKeyFields()) { // generating WHERE part of query (with keys)
            wherePart.append("\"").append(keyField).append("\" = ?").append(AND_PIECE);
        } // end of FOR
        StringBuilder query = new StringBuilder("SELECT * FROM ").append(config.getDestTable()).append(" WHERE ")
                .append(StringUtils.strip(StringUtils.trimToEmpty(wherePart.toString()), AND_PIECE));
        log.debug(String.format("Resulting query -> [%s].", query.toString()));
        return query.toString();
    }

    /**
     * Helper method for generating UPDATE sql query. It needs access to current instance config.
     */
    public static String getUpdateSql(ResultSetMetaData resultSetMetaData, ProcessorConfig config) throws SQLException {
        log.debug("EngineHelper.getUpdateSql() working.");
        // if meta data is empty or there are no key fields - throw an exception
        if (resultSetMetaData == null || config == null || config.getDestKeyFields().isEmpty()) {
            throw new SQLException("Empty MetaData object or empty config or empty key fields list!");
        }
        int startColumnNumber = config.getDestKeyFields().size() + 1;
        StringBuilder updatePart = new StringBuilder();
        for (int i = startColumnNumber; i <= resultSetMetaData.getColumnCount(); i++) { // generating UPDATE part of query
            // get name of current processed field
            String currentField = resultSetMetaData.getColumnName(i);
            if (!config.getExcludeSourceFields().contains(currentField)) { // field isn't present in exclude list
                // add allowed field to query and question mark for it
                updatePart.append("\"").append(currentField).append("\" = ?, ");
            } else { // we will skip this field
                log.warn(String.format("Field [%s] from source table [%s] is skipped!", currentField, config.getSourceTable()));
            }
        } // end of FOR cycle (UPDATE part)
        StringBuilder wherePart = new StringBuilder();
        for (int i = 1; i <= startColumnNumber - 1; i++) { // generating WHERE part of query (with keys)
            wherePart.append("\"").append(resultSetMetaData.getColumnName(i)).append("\" = ?").append(AND_PIECE);
        } // end of FOR
        // merge two parts of query and generate result
        StringBuilder query = new StringBuilder("UPDATE ").append(config.getDestTable()).append(" SET ")
                .append(StringUtils.strip(StringUtils.trimToEmpty(updatePart.toString()), ",")).append(" WHERE ")
                .append(StringUtils.strip(StringUtils.trimToEmpty(wherePart.toString()), AND_PIECE));
        log.debug(String.format("Resulting query -> [%s].", query.toString()));
        return query.toString();
    }

    /**
     * Helper method for generating INSERT sql query. It needs access to current instance config.
     */
    public static String getInsertSql(ResultSetMetaData resultSetMetaData, ProcessorConfig config) throws SQLException {
        log.debug("EngineHelper.getInsertSql() working.");
        // if meta data is empty - throw an exception
        if (resultSetMetaData == null || config == null) {
            throw new SQLException("Empty ResultSetMetaData object or empty config!");
        }
        // add to sql query fields names and questions marks (prepared statement)
        StringBuilder columnsPart = new StringBuilder();
        StringBuilder valuesPart = new StringBuilder();
        for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
            // get name of current processed field
            String currentField = resultSetMetaData.getColumnName(i);
            if (!config.getExcludeSourceFields().contains(currentField)) { // field isn't present in exclude list
                // add allowed field to query and question mark for it
                columnsPart.append("\"").append(currentField).append("\", ");
                valuesPart.append("?, ");
            } else { // we will skip this field
                log.warn(String.format("Field [%s] from source table [%s] is skipped!", currentField, config.getSourceTable()));
            }
        } // end of FOR cycle
        // join all query parts together
        StringBuilder query = new StringBuilder("INSERT INTO ").append(config.getDestTable()).append(" (")
                .append(StringUtils.strip(StringUtils.trimToEmpty(columnsPart.toString()), ",")).append(") VALUES (")
                .append(StringUtils.strip(StringUtils.trimToEmpty(valuesPart.toString()), ",")).append(")");
        // debug output
        log.debug(String.format("Resulting query -> [%s].", query.toString()));
        return query.toString();
    }

    /***/
    // todo: check count of key fields
    public static String checkKeyFields(ResultSetMetaData metaData, ProcessorConfig config) throws SQLException {
        log.debug("EngineHelper.checkKeyFields() working.");
        // if meta data is empty - throw an exception
        if (metaData == null || config == null) {
            throw new SQLException("Empty ResultSetMetaData object or empty config!");
        }
        String result = OK_RES;
        // meta data ok - processing next
        if (!config.getDestKeyFields().isEmpty()) { // key fields list isn't empty
            log.debug("Source key fields list isn't empty - processing.");
            int counter = 1;
            LinkedHashSet<String> realFields = new LinkedHashSet<>();
            // check cycle
            for (String field : config.getDestKeyFields()) {
                // create list of "real" fileds with order
                String realField = metaData.getColumnName(counter);
                realFields.add(realField);
                // check equality
                if (!field.equalsIgnoreCase(realField)) { // todo: optimize???
                    result = "Real key fields %s don't equal params key fields %s!";
                }
                counter++;
            }
            // if something is wrong - add info to result message
            if (!OK_RES.equals(result)) {
                result = String.format(result, realFields, config.getDestKeyFields());
            }
        } else { // key fields list is empty
            result = "Can't process - source key fields list is empty!";
        }
        return result;
    }

    /***/
    public static void copyTemplate(ProcessorConfig config) throws IOException {
        if (config == null) { // check config
            throw new IOException("Empty config!");
        }
        log.debug(String.format("EngineHelper.copyTemplate() working. Template [%s].", config.getDestTable()));
        String templateName = config.getDestTable();
        for (String extension : DB_EXTENSIONS) {
            Path sourcePath = Paths.get(System.getProperty("user.dir") + "/templates/" + templateName + "/" + templateName + extension);
            Path destPath   = Paths.get(config.getDestPath() + "/" + templateName + extension);
            Files.copy(sourcePath, destPath, StandardCopyOption.REPLACE_EXISTING);
            log.debug(String.format("Template [%s] copied to [%s].", sourcePath.toString(), destPath.toString()));
        }
    }

}