package ru.kzgroup.dataSync.config;

import org.apache.commons.lang3.StringUtils;

/**
 * Filtering options enumeration for DataProcessor.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 01.05.2014)
*/

public enum ProcessorFilterOptions {

    BLANK_TO_ZERO("blank, changeto 0"),
    UNKNOWN("");

    private ProcessorFilterOptions(String filterValue) {
        this.filterValue = filterValue;
    }

    private String filterValue;

    public String getFilterValue() {
        return filterValue;
    }

    /**
     * Method returns value ProcessorFilterOptions by string representation.
    */
    public static ProcessorFilterOptions getFilterOption(String filterString) {
        ProcessorFilterOptions result = UNKNOWN;
        if (!StringUtils.isBlank(filterString)) { // if parameter is OK - process it
            boolean found = false;
            int counter = 0;
            ProcessorFilterOptions[] filterOptionsList = ProcessorFilterOptions.values();
            while (!found && counter < filterOptionsList.length) {
                if (filterOptionsList[counter].getFilterValue().equals(StringUtils.trim(filterString))) {
                    result = filterOptionsList[counter];
                    found = true;
                }
                counter++;
            }
        }
        return result;
    }

}