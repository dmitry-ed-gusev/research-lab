package ru.kzgroup.dataSync.config;

/**
 * Command line options enumeration class for DataProcessor utility.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 30.04.2014)
*/

public enum ProcessorCmdLineOptions {

    SOURCE_PATH          ("-sourcePath",          "-sourcePath <path>               -Path to source database (folder)."),
    DEST_PATH            ("-destPath",            "-destPath <path>                 -Path to destination database (folder)."),
    SOURCE_TABLE         ("-sourceTable",         "-sourceTable <table_name>        -Name of source table (Paradox table -> DB)."),

    // todo: --- options for removal ---
    DEST_TABLE           ("-destTable",           "-destTable <table_name>          -Name of dest table (Paradox table -> DB)."),
    DEST_TABLE_KEY       ("-destKeyFields",       "-destKeyFields <k1,...kN>        -Key fields list for dest table."),
    EXCLUDE_SOURCE_FIELDS("-excludeSourceFields", "-excludeSourceFields <f1,...,fN> -List of source table fields, that will be excluded from data transfer."),
    FILTER_FIELDS        ("-filterFields",        "-filterFields <f1,...,fN>        -Comma separated list of fields for applying a filter."),
    FILTER_VALUE         ("-filterValue",         "-filterValue <filter>            -Filter value. Possible filters: " +
            ProcessorFilterOptions.BLANK_TO_ZERO.getFilterValue()),
    // todo: --- options for removal ---

    USE_UPDATE_METHOD    ("-useUpdateMethod",     "-useUpdateMethod                 -With this option [UPDATE] method will be used, otherwise - [REPLACE] - default.");

    private ProcessorCmdLineOptions(String optionName, String optionDesc) {
        this.optionName = optionName;
        this.optionDesc = optionDesc;
    }

    private String optionName;
    private String optionDesc;

    public String getOptionName() {
        return optionName;
    }

    public String getOptionDesc() {
        return optionDesc;
    }

}