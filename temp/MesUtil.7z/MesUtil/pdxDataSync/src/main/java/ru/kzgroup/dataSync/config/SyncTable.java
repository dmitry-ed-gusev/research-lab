package ru.kzgroup.dataSync.config;

import org.apache.commons.lang3.StringUtils;
import java.util.Arrays;
import static ru.kzgroup.dataSync.config.ProcessorFilterOptions.BLANK_TO_ZERO;
import static ru.kzgroup.dataSync.config.ProcessorFilterOptions.UNKNOWN;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 10.05.2014)
*/

public enum SyncTable {

    //    source |  dest    | excluded source fields  |                          filtered source fields                          |   filter value
    F110 ("F110",  "F110R",  new String[] {"TKpieces"}, new String[] {"Вес_заг.пок., Вес_заг., Прокат_вес_ч/с, Прокат_вес_кв.заг."}, BLANK_TO_ZERO),
    M160 ("M160",  "M160R",  new String[] {}, new String[] {}, UNKNOWN),
    RK110("RK110", "RK110R", new String[] {}, new String[] {}, UNKNOWN),
    UNKNOWN_TABLE("", "", new String[] {}, new String[] {}, UNKNOWN);

    /***/
    private SyncTable(String sourceTableName, String destTableName, String[] excludeFields, String[] filterFields, ProcessorFilterOptions filterValue) {
        this.sourceTableName = sourceTableName;
        this.destTableName   = destTableName;
        this.excludeFields   = excludeFields;
        this.filterFields    = filterFields;
        this.filterValue     = filterValue;
    }

    private String                 sourceTableName;
    private String                 destTableName;
    private String[]               excludeFields;
    private String[]               filterFields;
    private ProcessorFilterOptions filterValue;

    public String getSourceTableName() {
        return sourceTableName;
    }

    public String getDestTableName() {
        return destTableName;
    }

    public String[] getExcludeFields() {
        return Arrays.copyOf(excludeFields, excludeFields.length);
    }

    public String[] getFilterFields() {
        return Arrays.copyOf(filterFields, filterFields.length);
    }

    public ProcessorFilterOptions getFilterValue() {
        return filterValue;
    }

    /**
     * Method returns value SyncTables by string representation.
    */
    public static SyncTable getSyncTable(String syncTable) {
        SyncTable result = UNKNOWN_TABLE;
        if (!StringUtils.isBlank(syncTable)) { // if parameter is OK - process it
            boolean found   = false; // "item found!" sign
            int     counter = 0;     // pricessed items counter
            SyncTable[] syncTablesList = SyncTable.values();
            while (!found && counter < syncTablesList.length) {
                if (syncTablesList[counter].sourceTableName.equals(StringUtils.trim(syncTable)) ||
                        syncTablesList[counter].destTableName.equals(StringUtils.trim(syncTable))) {
                    result = syncTablesList[counter];
                    found = true;
                }
                counter++;
            }
        }
        return result;
    }

}