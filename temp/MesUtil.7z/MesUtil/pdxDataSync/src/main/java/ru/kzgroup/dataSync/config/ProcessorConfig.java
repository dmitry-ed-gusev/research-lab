package ru.kzgroup.dataSync.config;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import ru.kzgroup.exceptions.InternalException;
import gusev.dmitry.jtils.utils.CommandLine;

import java.io.File;
import java.util.*;

/**
 * DataProcessor utility config module. It accepts command line (array String[]) and parses it.
 * This class is immutable.
 *
 * Notes.
 * 1. For [excludeSourceFields] and [filterFields] we used TreeSet implementation of Set - we don't care about
 *    elemants order, we just need a Set for removing duplicates.
 * 2. For [destKeyFields] we used LinkedHashSet implementation of Set - we need to remove duplicates and
 *    we have to take care about elements ordering (which is the order in which elements were inserted into the set,
 *    insert-ordering).
 *
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 30.04.2014)
*/

// todo: check some rules for config parameters (consistency)
// todo: check source and dest - if they are the same - exception (safety)

public final class ProcessorConfig {

    private String                 sourcePath;
    private String                 destPath;
    private SyncTable              table;
    private boolean                useUpdateMethod;

    // todo: fields for removal
    private String      sourceTable;
    private String      destTable;
    private Set<String> excludeSourceFields;
    private Set<String> filterFields;
    private Set<String> destKeyFields;
    private ProcessorFilterOptions filterOption;

    /***/
    public ProcessorConfig(String[] cmdLineOptions) throws InternalException {

        // parse command line
        if (cmdLineOptions != null && cmdLineOptions.length > 0) { // command line isn't empty
            CommandLine cmdLine = new CommandLine(cmdLineOptions);

            // source path
            this.sourcePath     = StringUtils.trimToEmpty(cmdLine.optionValue(ProcessorCmdLineOptions.SOURCE_PATH.getOptionName()));
            File sourcePathFile = new File(this.sourcePath);
            if (StringUtils.isBlank(this.sourcePath) || !sourcePathFile.exists() || !sourcePathFile.isDirectory()) {
                throw new InternalException(String.format("Invalid source path [%s]!", this.sourcePath));
            }
            // source table
            this.sourceTable = StringUtils.trimToEmpty(cmdLine.optionValue(ProcessorCmdLineOptions.SOURCE_TABLE.getOptionName())).toUpperCase();
            File sourceTableFile = new File(this.sourcePath + "/" + this.sourceTable + ".DB");
            if (!sourceTableFile.exists() || !sourceTableFile.isFile()) {
                throw new InternalException(String.format("Invalid source table [%s]!", this.sourceTable));
            }
            // dest path
            this.destPath     = StringUtils.trimToEmpty(cmdLine.optionValue(ProcessorCmdLineOptions.DEST_PATH.getOptionName()));
            File destPathFile = new File(this.destPath);
            if (StringUtils.isBlank(this.destPath) || !destPathFile.exists() || !destPathFile.isDirectory()) {
                throw new InternalException(String.format("Invalid dest path [%s]!", this.destPath));
            }
            // dest table
            this.destTable = StringUtils.trimToEmpty(cmdLine.optionValue(ProcessorCmdLineOptions.DEST_TABLE.getOptionName())).toUpperCase();
            File destTableFile = new File(this.destPath + "/" + this.destTable + ".DB");
            if (!destTableFile.exists() || !destTableFile.isFile()) {
                throw new InternalException(String.format("Invalid dest table [%s]!", this.destTable));
            }

            // calculate - is dest table known?
            //this.isDestTableKnown = ProcessorConfig.KNOWN_TABLES.containsKey(this.destTable);

            // list (set) of excluded source fields (split regex - [\\s*,\\s*] - split by comma (,) and remove spaces)
            this.excludeSourceFields = new TreeSet<>(); // remove dups, order doesn't matter
            String excludeSourceFieldsValue = StringUtils.trimToEmpty(cmdLine.optionValue(ProcessorCmdLineOptions.EXCLUDE_SOURCE_FIELDS.getOptionName()));
            if (!StringUtils.isBlank(excludeSourceFieldsValue)) {
                String[] excludedSourceFieldsArray = excludeSourceFieldsValue.split("\\s*,\\s*");
                this.excludeSourceFields.addAll(Arrays.asList(excludedSourceFieldsArray));
            }

            // list (set) of filter fields (split regex - [\\s*,\\s*] - split by comma (,) and remove spaces)
            this.filterFields = new TreeSet<>(); // remove dups, order doesn't matter
            String filterFieldsValue = StringUtils.trimToEmpty(cmdLine.optionValue(ProcessorCmdLineOptions.FILTER_FIELDS.getOptionName()));
            if (!StringUtils.isBlank(filterFieldsValue)) {
                String[] filterFieldsArray = filterFieldsValue.split("\\s*,\\s*");
                this.filterFields.addAll(Arrays.asList(filterFieldsArray));
            }

            // list (set) of dest table key fields (split regex - [\\s*,\\s*] - split by comma (,) and remove spaces)
            this.destKeyFields = new LinkedHashSet<>(); // remove dups and order does matter
            // for known tables we ignore cmd line value for key fields
            //if (this.isDestTableKnown) {
            //    this.destKeyFields.addAll(Arrays.asList(KNOWN_TABLES.get(this.destTable)));
            //} else { // dest table is unknown - get cmd line value
                String destKeyFieldsValue = StringUtils.trimToEmpty(cmdLine.optionValue(ProcessorCmdLineOptions.DEST_TABLE_KEY.getOptionName()));
                if (!StringUtils.isBlank(destKeyFieldsValue)) {
                    String[] destKeyFieldsArray = destKeyFieldsValue.split("\\s*,\\s*");
                    this.destKeyFields.addAll(Arrays.asList(destKeyFieldsArray));
                }
            //}

            // filter option
            this.filterOption = ProcessorFilterOptions.getFilterOption(StringUtils.trimToEmpty(cmdLine.optionValue(ProcessorCmdLineOptions.FILTER_VALUE.getOptionName())));
            // use [UPDATE] method option
            this.useUpdateMethod = cmdLine.hasOption(ProcessorCmdLineOptions.USE_UPDATE_METHOD.getOptionName());

        } else { // cmd line is empty
            throw new InternalException("Empty command line!");
        }

    } // end of constructor

    public String getSourcePath() {
        return sourcePath;
    }

    public String getDestPath() {
        return destPath;
    }

    public String getSourceTable() {
        return sourceTable;
    }

    public String getDestTable() {
        return destTable;
    }

    /**
     * Returns full destination path -> catalog + table
    */
    public String getFullDestPath() {
        return this.destPath + "/" + this.destTable + ".DB";
    }

    public Set<String> getExcludeSourceFields() {
        return Collections.unmodifiableSet(excludeSourceFields); // defensive programming :)
    }

    public Set<String> getFilterFields() {
        return Collections.unmodifiableSet(filterFields); // defensive programming :)
    }

    public Set<String> getDestKeyFields() {
        return Collections.unmodifiableSet(destKeyFields); // defensive programming :)
    }

    /***/
    public String getDestKeyFieldsCSV() {
        StringBuilder keysCSVList = new StringBuilder();
        if (!this.destKeyFields.isEmpty()) {
            int counter = 1;
            for (String key : this.destKeyFields) {
                keysCSVList.append(key);
                if (counter < this.destKeyFields.size()) {
                    keysCSVList.append(", ");
                }
                counter++;
            }
        }
        return keysCSVList.toString();
    }

    public ProcessorFilterOptions getFilterOption() {
        return filterOption;
    }

    public boolean isUseUpdateMethod() {
        return useUpdateMethod;
    }

    //public boolean isDestTableKnown() {
    //    return isDestTableKnown;
    //}

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("sourcePath", sourcePath)
                .append("destPath", destPath)
                .append("sourceTable", sourceTable)
                .append("destTable", destTable)
                .append("excludeSourceFields", excludeSourceFields)
                .append("filterFields", filterFields)
                .append("destKeyFields", destKeyFields)
                .append("filterOption", filterOption)
                .append("useUpdateMethod", useUpdateMethod)
                //.append("isDestTableKnown", isDestTableKnown)
                //.append("KNOWN_TABLES", KNOWN_TABLES)
                .toString();
    }

}