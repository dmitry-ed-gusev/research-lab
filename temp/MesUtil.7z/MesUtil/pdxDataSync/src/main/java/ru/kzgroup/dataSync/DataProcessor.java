package ru.kzgroup.dataSync;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ru.kzgroup.exceptions.InternalException;
import ru.kzgroup.dataSync.config.ProcessorConfig;
import ru.kzgroup.dataSync.engine.ProcessorEngine;

import java.io.IOException;
import java.sql.SQLException;

/**
 * Main module for DataProcessor utility.
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 29.04.2014)
*/

// todo: cmd line key for help and help screen
// todo: add to help screen known tables list with keys
// todo: add function - just truncate dest
// todo: add function - just rebuild all indexes on destination

public class DataProcessor {

    /** Batch size - every this count of steps batch will be executed. */
    public static final int    BATCH_EXECUTE_SIZE           = 2000;
    /** Log info message every ([processing counter] % (PROCESSING_INFO_MESSAGE_STEP * BATCH_EXECUTE_SIZE) == 0) step.*/
    public static final int    PROCESSING_INFO_MESSAGE_STEP = 4;

    /***/
    public static void main(String[] args) {
        Log log = LogFactory.getLog(DataProcessor.class);
        try {
            // lines below -> just for debug!
            //args = ("-sourcePath //pst-fs/asu/USERS/new/spz/DATA/ -sourceTable RK110 -destPath c:/temp/temp_pst_fs/failed " +
            //        "-destTable rk110r -excludeSourceFields111 IsArc,Код_марки -sourceKeyFields Год,N_раб_карты,WorkTicketStringNo " +
            //        "-useUpdateMethod").split(" ");
            args = ("-sourcePath c:/temp/temp_pst_fs/data -sourceTable RK110 -destPath c:/temp/temp_pst_fs/failed " +
                                 "-destTable rk110r -excludeSourceFields111 IsArc,Код_марки -sourceKeyFields Год,N_раб_карты,WorkTicketStringNo " +
                                "-useUpdateMethod").split(" ");


            // create ProcessorConfig instance
            ProcessorConfig config = new ProcessorConfig(args);
            log.info(String.format("DataProcessor processing: [%s -> %s].", config.getSourceTable(), config.getDestTable()));
            log.debug("Current config: " + config);
            // create ProcessorEngine instance
            ProcessorEngine engine = new ProcessorEngine(config);
            // execute engine - process data
            engine.process();
        } catch (InternalException | IOException | SQLException e) {
            log.error(String.format("Internal exception: [%s]", e.getMessage()), e);
        }
    }

}