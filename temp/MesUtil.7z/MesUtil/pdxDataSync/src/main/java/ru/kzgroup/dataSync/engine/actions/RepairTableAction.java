package ru.kzgroup.dataSync.engine.actions;

/**
 * @author Gusev Dmitry (gusevd)
 * @version 1.0 (DATE: 10.05.2014)
*/

public class RepairTableAction {

    // test query: select top 1 * from <table name>


}
