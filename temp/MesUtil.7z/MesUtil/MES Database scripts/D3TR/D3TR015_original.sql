create or replace 
PROCEDURE      SP_TR_D3TR015 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D2TR001        
 * VERSION           : V1.00                       
 * DESCRIPTION       : Blank weight information before WBF entrance    
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);

W_MELT_NO               TB_PO_INGOT_COMM.MELT_NO%TYPE;
W_SEQ_IN_MELT           TB_PO_INGOT_COMM.SEQ_IN_MELT%TYPE;

W_PON_CNT               NUMBER;
  
BEGIN 
     
    RETURN;
    
    -- TB_PO_INGOT_COMM UPDATE ----------
    UPDATE TB_PO_BLANK_COMM
       SET (BLANK_WEIGHING_TIME
           ,WBF_WEIGHING_WT
           ,MOD_DDTT
           ,MODIFIER)
              = (SELECT TO_DATE(TRIM(ITEM_3),'DD-MM-YYYY HH24:MI:SS')
                        ,TRIM(ITEM_4)
                       ,SYSDATE
                        ,'SP_TR_D3TR015'
                   FROM TB_PO_LEVEL2_INTERFACE 
                  WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY)
     WHERE (MELT_NO,BLANK_NO) 
              = (SELECT TRIM(ITEM),TRIM(ITEM_1)
                   FROM TB_PO_LEVEL2_INTERFACE 
                  WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY);

    -- TB_PO_RHF_CHARGE_ORD UPDEATE ----------

    UPDATE TB_PO_FURNACE_CHARGE_ORD
       SET FURNACE_WORK_STATUS = 'W'                     -- INGOT WEIGHING STATUS       
           ,MOD_DDTT       = SYSDATE 
           ,MODIFIER       = 'SP_TR_D3TR015'
     WHERE (MELT_NO,BLANK_NO) = (SELECT TRIM(ITEM),TRIM(ITEM_1)
                                   FROM TB_PO_LEVEL2_INTERFACE 
                                  WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY)
       AND MILL_GP = '3';                           
    
    -- TB_PM_MILL_DAILY_PLAN UPDEATE ----------
    
     UPDATE TB_PM_MILL_DAILY_PLAN
       SET FURNACE_WEIGHING_QNTY = NVL(FURNACE_WEIGHING_QNTY,0) + 1
     WHERE (MELT_NO,SEQ_IN_MELT)
           = (SELECT MELT_NO,SEQ_IN_MELT
                FROM TB_PO_BLANK_COMM 
                WHERE (MELT_NO,BLANK_NO) = ( SELECT TRIM(ITEM),TRIM(ITEM_1)
                                               FROM TB_PO_LEVEL2_INTERFACE 
                                              WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY)
              )                               
       AND MILL_GP = '3';                                       
               
     

                                      
         -- TB_PO_MILL_PON_RESULT INSERT  (PON)       
                                      
 --        SP_TR_400_PON3  (W_MELT_NO,W_SEQ_IN_MELT);
--         COMMIT;
         
         -- TB_PO_MILL350_BUNDLE_WEIGHING(PON)
                                      
--         SP_TR_520_350BD (W_MELT_NO,W_SEQ_IN_MELT);
--         COMMIT;
                      
                                 
COMMIT;    
EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;