create or replace 
PROCEDURE      SP_TR_D3TR012 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR012        
 * VERSION           : V1.00                       
 * DESCRIPTION       : MILL350 Packing weight information     
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       : 14.09.2013, Gusev Dmitry                                                      
 */-----------------------------------------------------------------------------
  
W_ERR_CODE              NUMBER;
W_ERR_MSG               VARCHAR2(250);

W_WEIGHING_TIME         VARCHAR2(19);
W_BUNDLE_WT             NUMBER;

item_value    varchar(30); -- char value of 'item' row  
date_template varchar(30); -- template for converting char -> date
BEGIN

   -- select value of 'item' column
   select trim(item) into item_value from tb_po_level2_interface where SEQUENCE_KEY = IN_SEQUENCE_KEY;
   -- check value and select conversion pattern
  if instr(item_value, '-') = 3 then 
   date_template := 'DD-MM-YYYY HH24:MI:SS';
  elsif instr(item_value, '-') = 5 then  
   date_template := 'YYYY-MM-DD HH24:MI:SS';
  else -- no variants - exception case
   raise_application_error(-20000, 'SP for D3TR012 -> Invalid date format in column ITEM!');
  end if;
     
     INSERT INTO TB_PO_IF_PACKING_WEIGHING
           (TC_ID
           ,WEIGHING_DDTT
           ,WEIGHING_WT
           ,REG_DDTT
           ,REGISTER
           )
     SELECT 'D3TR012'
            --,TO_CHAR(TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS'),'YYYYMMDDHH24MISS')
            ,TO_DATE(TRIM(ITEM), date_template)
            ,TRIM(ITEM_1)
            ,SYSDATE
            ,'SP_TR_D3TR012'   
       FROM TB_PO_LEVEL2_INTERFACE 
      WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
               
    
EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                             
END;