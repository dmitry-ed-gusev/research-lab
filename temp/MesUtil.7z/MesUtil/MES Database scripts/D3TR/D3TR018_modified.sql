create or replace 
PROCEDURE SP_TR_D3TR018 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR018        
 * VERSION           : V2.00                       
 * DESCRIPTION       : M900/680 Bundle weight information     
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 17.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D3TR018';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
     
  INSERT INTO TB_PO_IF_PACKING_WEIGHING (
                TC_ID
                ,WEIGHING_DDTT
                ,WEIGHING_WT
                ,REG_DDTT
                ,REGISTER
              )
  SELECT  telegramId
          ,TO_CHAR(TO_DATE(TRIM(ITEM), dateTimeTemplate),'YYYYMMDDHH24MISS')
          ,TRIM(ITEM_1)
          ,SYSDATE
          ,procedureName
    FROM TB_PO_LEVEL2_INTERFACE 
    WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
    
-- SP_TR_950_PACKING (IN_TC_ID,W_WEIGHING_TIME,W_BUNDLE_WT,W_ERR_CODE,W_ERR_MSG);
--     
-- IF  W_ERR_CODE IS NOT NULL  THEN 
-- RAISE_APPLICATION_ERROR(W_ERR_CODE,W_ERR_MSG);
-- END IF;

  COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;