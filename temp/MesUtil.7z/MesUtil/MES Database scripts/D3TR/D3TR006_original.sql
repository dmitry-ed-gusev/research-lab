create or replace 
PROCEDURE      SP_TR_D3TR006 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR006      
 * VERSION           : V1.00                       
 * DESCRIPTION       : Entrance pass count of no.6 Stand
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);

W_MELT_NO               TB_PM_MILL_DAILY_PLAN.MELT_NO%TYPE;
W_SEQ_IN_MELT           TB_PM_MILL_DAILY_PLAN.SEQ_IN_MELT%TYPE;
--W_INGOT_CNT             NUMBER;
--W_CUTTING_SEQ           NUMBER;  


--W_WORK_DUTY             TB_PO_SHIFT_WORKER.WORK_DUTY%TYPE; 
--W_WORK_SHIFT            TB_PO_SHIFT_WORKER.WORK_SHIFT%TYPE;
W_PROD_YY               VARCHAR2(4);
W_PON                   VARCHAR2(7);
--W_START_DATE            DATE; 
W_MEASURING_TIME        DATE;
W_WORK_HR               CHAR(5);
W_TEMP                  NUMBER;
W_INPUT_MATERIAL_QNTY   NUMBER; 
W_MILL_RESULT_QNTY      NUMBER;

  
BEGIN
  
RETURN;
     
    SELECT TO_DATE(TRIM(C.ITEM_3),'DD-MM-YYYY HH24:MI:SS')
          ,TRIM(C.ITEM)
      INTO W_MEASURING_TIME
          ,W_MELT_NO
      FROM TB_PO_BLANK_COMM       A          
          ,TB_PO_LEVEL2_INTERFACE C          
     WHERE C.SEQUENCE_KEY = IN_SEQUENCE_KEY
       AND A.MELT_NO      = TRIM(C.ITEM)
       AND A.BLANK_NO     = TRIM(C.ITEM_1);
      
      
       
    -- TB_PM_MILL_DAILY_PLAN UPDATE 
--    UPDATE TB_PM_MILL_DAILY_PLAN
--       SET MILL_RESULT_QNTY = NVL(MILL_RESULT_QNTY,0) + 1
--     WHERE MILL_GP = '3'
--       AND PROD_YY = W_PROD_YY
--       AND PON     = W_PON;
       
    -- MONITORING CHECK & SET    
--    SELECT INPUT_MATERIAL_QNTY,MILL_RESULT_QNTY
--      INTO W_INPUT_MATERIAL_QNTY,W_MILL_RESULT_QNTY
--      FROM TB_PM_MILL_DAILY_PLAN
--     WHERE MILL_GP = '3'
--       AND PROD_YY = W_PROD_YY
--       AND PON     = W_PON;
       
--    IF  W_MILL_RESULT_QNTY = 1  THEN
    
        --  TB_PO_MILL_PON_RESULT UPDATE 
--        UPDATE TB_PO_MILL_PON_RESULT
--           SET MILL_START_DDTT = W_MEASURING_TIME - 1/24/60 
--               ,MILL_PETROL_DATE
--                = FN_PETRODATE(TO_CHAR(W_MEASURING_TIME,'YYYYMMDDHH24MISS'),'YYYYMMDDHH24MISS','YYYYMMDD') 
--               ,MOD_DDTT       = SYSDATE 
--               ,MODIFIER       = 'SP_TR_D3TR006'
--         WHERE MILL_GP = '3'
--           AND PROD_YY = W_PROD_YY
--           AND PON     = W_PON;
           
--        SP_TR_200_MONITOR  ('302'
--                           ,'H'
--                           ,W_MELT_NO
--                           ,TO_CHAR(W_MEASURING_TIME,'YYYYMMDDHH24MI')
--                           ,NULL
--                           ,'S'
--                           ,W_PROD_YY
--                           ,W_PON
--                           ,vERR_CODE 
--                           ,vERR_MSG 
--                          );
--    ELSIF  W_INPUT_MATERIAL_QNTY =  W_MILL_RESULT_QNTY THEN                   
--           SP_TR_200_MONITOR  ('302'
--                               ,'H'
--                               ,W_MELT_NO
--                               ,NULL
--                               ,TO_CHAR(W_MEASURING_TIME,'YYYYMMDDHH24MI')
--                               ,'E'
--                               ,W_PROD_YY
--                               ,W_PON
--                               ,vERR_CODE 
--                               ,vERR_MSG 
--                              );
--    END IF;                      
--    IF  vERR_MSG  IS NOT NULL  THEN        
--        RETURN;
--    END IF;
                             


           
      
    --- END_DATE  UPDATE
--    UPDATE TB_PO_MILL_PON_RESULT
--       SET MILL_END_DDTT = W_MEASURING_TIME + 1/24/120 
--           ,MOD_DDTT     = SYSDATE 
--           ,MODIFIER     = 'SP_TR_D3TR006'
--     WHERE MILL_GP = '3'
--       AND PROD_YY = W_PROD_YY
--       AND PON     = W_PON;
--            
   
    -- TB_PO_BLANK_COMM UPDATE ----------
                                                 
    BEGIN
           UPDATE TB_PO_BLANK_COMM
              SET STAND_NO6_START_TIME = W_MEASURING_TIME
                  ,MOD_DDTT        = SYSDATE
                  ,MODIFIER        = 'SP_TR_D3TR006'
            WHERE (MELT_NO,BLANK_NO)      
                  = (SELECT TRIM(ITEM)                 --MELT_NO
                            ,TRIM(ITEM_1)              --BLANK_NO
                       FROM TB_PO_LEVEL2_INTERFACE 
                      WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY);
              
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_BLANK_COMM UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RETURN;
    END;
COMMIT;    

EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;