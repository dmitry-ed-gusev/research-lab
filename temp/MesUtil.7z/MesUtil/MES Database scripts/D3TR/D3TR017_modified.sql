create or replace 
PROCEDURE SP_TR_D3TR017 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR017        
 * VERSION           : V2.00                       
 * DESCRIPTION       : BLANK temperature at WBF exit   
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 17.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D3TR017';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
meltNo              number;                 -- melt number
blankNo             number;                 -- blank number
wbf_exit_temp       number;
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN
  RETURN;
  
  
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  -- select melt number, blank number, wbf exit temp
  SELECT to_number(TRIM(ITEM)), to_number(TRIM(ITEM_1)), to_number(TRIM(ITEM_4))
    INTO  meltNo, blankNo, wbf_exit_temp
    FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = in_sequence_key;
    
  -- TB_PO_INGOT_COMM UPDATE ----------
  BEGIN
    currentOperation := 'Operation [TB_PO_BLANK_COMM update].'; -- current operation marker for error handling
    UPDATE TB_PO_BLANK_COMM
      SET WBF_EXIT_TEMP = wbf_exit_temp
          ,MOD_DDTT     = SYSDATE
          ,MODIFIER     = procedureName
      WHERE MELT_NO = meltNo and BLANK_NO = blankNo;
  
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;