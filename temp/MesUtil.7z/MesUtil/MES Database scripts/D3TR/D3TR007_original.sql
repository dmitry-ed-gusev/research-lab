create or replace 
PROCEDURE      SP_TR_D3TR007 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR007      
 * VERSION           : V1.00                       
 * DESCRIPTION       : Exit Time no.6 Stand
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
  
BEGIN 
    RETURN;  
    --TB_PO_BLANK_COMM UPDATE ----------
                                                 
    BEGIN
           UPDATE TB_PO_BLANK_COMM
              SET (STAND_NO6_EXIT_TIME,STAND_NO6_EXIT_TEMP)
                  = (SELECT TO_DATE(TRIM(ITEM_2),'DD-MM-YYYY HH24:MI:SS')  --STAND_NO6_EXIT_TIME
                            ,TRIM(ITEM_3) 
                       FROM TB_PO_LEVEL2_INTERFACE 
                      WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY)
                  ,MOD_DDTT = SYSDATE
                  ,MODIFIER = 'SP_TR_D3TR007'
            WHERE (MELT_NO,BLANK_NO)      
                  = (SELECT TRIM(ITEM)                 --MELT_NO
                            ,TRIM(ITEM_1)              --BLANK_NO
                       FROM TB_PO_LEVEL2_INTERFACE 
                      WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY);
              
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_BLANK_COMM UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RETURN;
    END;

EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;