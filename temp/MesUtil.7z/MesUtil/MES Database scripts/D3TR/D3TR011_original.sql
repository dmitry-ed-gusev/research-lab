create or replace 
PROCEDURE      SP_TR_D3TR011 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR011       
 * VERSION           : V1.00                       
 * DESCRIPTION       : Mill350 Tailed scrap weight information
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
  
BEGIN 
      
    --TB_PO_MILL_TAILED_SCRAP ----------
                                                 
    BEGIN
           INSERT INTO TB_PO_MILL_TAILED_SCRAP
                  (TC_ID
                  ,WEIGHING_DDTT
                  ,TAILED_SCRAP_WT
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT TRIM(TC_ID)                                    --TC_ID   
                  ,TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS')   --WEIGHING_TIME
                  ,TRIM(ITEM_1)                                  --TAILED_SCRAP_WT
                  ,SYSDATE
                  ,'SP_TR_D3TR011'
             FROM TB_PO_LEVEL2_INTERFACE 
            WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
              
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_MILL_TAILED_SCRAP ISERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RAISE;
    END;

EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;