create or replace 
PROCEDURE SP_TR_D3TR012 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR012        
 * VERSION           : V2.00                       
 * DESCRIPTION       : MILL350 Packing weight information     
 * DEVELOPER NAME    : Lee, Gusev, Hakimov
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       : 14.09.2013, Gusev Dmitry
 * MODIFY DATE       : 17.01.2014, Hakimov
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D3TR012';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
weightingWeight     number;
weightingDdTt       date;
item_value          varchar(30); -- char value of 'item' row  
date_template       varchar(30); -- template for converting char -> date
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  -- weighting time and weight
  SELECT TRIM(ITEM), to_number(TRIM(ITEM_1))
    INTO  item_value, weightingWeight
    FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = in_sequence_key;
    
  -- check value and select conversion pattern
  if instr(item_value, '-') = 3 then 
    date_template := 'DD-MM-YYYY HH24:MI:SS';
  elsif instr(item_value, '-') = 5 then  
    date_template := 'YYYY-MM-DD HH24:MI:SS';
  else -- no variants - exception case
    raise_application_error(-20000, 'SP for D3TR012 -> Invalid date format in column ITEM!');
  end if;
     
  INSERT INTO TB_PO_IF_PACKING_WEIGHING (
                TC_ID
                ,WEIGHING_DDTT
                ,WEIGHING_WT
                ,REG_DDTT
                ,REGISTER
              )
    values (
        telegramId
        ,TO_DATE(item_value, date_template)
        ,weightingWeight
        ,SYSDATE
        ,procedureName
      );
          
  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;