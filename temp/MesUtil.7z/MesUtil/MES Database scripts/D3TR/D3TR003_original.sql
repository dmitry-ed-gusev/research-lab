create or replace 
PROCEDURE      SP_TR_D3TR003 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR003      
 * VERSION           : V1.00                       
 * DESCRIPTION       : Temperture information of WBF
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
  
BEGIN 
      
    --TB_PO_WBF_TEMPERATURE ----------
                                                 
    BEGIN
           INSERT INTO TB_PO_WBF_TEMPERATURE
                  (MEASURING_TIME
                  ,NO1_FURNACE_ZONE1_TEMP
                  ,NO1_FURNACE_ZONE2_TEMP
                  ,NO2_FURNACE_ZONE1_TEMP
                  ,NO2_FURNACE_ZONE2_TEMP
                  ,REG_DDTT
                  ,REGISTER
                  )
           SELECT TO_DATE(TRIM(ITEM),'DD-MM-YYYY HH24:MI:SS')    --MEASURING_TIME
                  ,TRIM(ITEM_1)                                  --NO1_FURNACE_ZONE1_TEMP
                  ,TRIM(ITEM_2)                                  --NO1_FURNACE_ZONE2_TEMP
                  ,TRIM(ITEM_3)                                  --NO2_FURNACE_ZONE1_TEMP
                  ,TRIM(ITEM_4)                                  --NO2_FURNACE_ZONE2_TEMP
                  ,SYSDATE
                  ,'SP_TR_D3TR003'
             FROM TB_PO_LEVEL2_INTERFACE 
            WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
              
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_WBF_TEMPERATURE ISERT ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RETURN;
    END;

EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;