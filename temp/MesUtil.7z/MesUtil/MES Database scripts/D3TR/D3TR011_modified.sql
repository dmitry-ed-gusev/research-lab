create or replace 
PROCEDURE SP_TR_D3TR011 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR011       
 * VERSION           : V2.00                       
 * DESCRIPTION       : Mill350 Tailed scrap weight information
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 17.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D3TR011';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
      
  --TB_PO_MILL_TAILED_SCRAP ----------
  BEGIN
    currentOperation := 'Operation [TB_PO_MILL_TAILED_SCRAP insert].'; -- current operation marker for error handling
    INSERT INTO TB_PO_MILL_TAILED_SCRAP (
                  TC_ID
                  ,WEIGHING_DDTT
                  ,TAILED_SCRAP_WT
                  ,REG_DDTT
                  ,REGISTER
                )
      SELECT TRIM(TC_ID)                            --TC_ID   
            ,TO_DATE(TRIM(ITEM), dateTimeTemplate)  --WEIGHING_TIME
            ,TRIM(ITEM_1)                           --TAILED_SCRAP_WT
            ,SYSDATE
            ,procedureName
      FROM TB_PO_LEVEL2_INTERFACE 
      WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY;
      
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;