create or replace 
PROCEDURE SP_TR_D3TR007 (IN_SEQUENCE_KEY IN VARCHAR2, errors out varchar2) IS

 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR007      
 * VERSION           : V2.00                       
 * DESCRIPTION       : Exit Time no.6 Stand
 * DEVELOPER NAME    : Lee, Hakimov
 * CREATE DATE       : 06.09.2012
 * MODIFY DATE       : 17.01.2014
 */-----------------------------------------------------------------------------

-- constants for this procedure
defaultTelegramId   varchar2(7)  := 'D3TR007';
procedureName       varchar2(13) := 'SP_TR_'||defaultTelegramId;
dateTimeTemplate    varchar2(21) := 'DD-MM-YYYY HH24:MI:SS';
-- parameters for procedure
telegramId          varchar2(7);            -- telegram id
meltNo              number;                 -- melt number
blankNo             number;                 -- blank number
stand6_exit_temp    number;
stand6_exit_time    date;
meltNoStr           varchar2(10 char);      -- temp melt number
blankNoStr          varchar2(10 char);      -- temp blank number
currentOperation    varchar2(200) := null;  -- current processed operation (null - initial value, no operation)

BEGIN
  --RETURN;  
  
  
  -- no errors
  errors := 'OK';
  -- select and check telegram id
  select upper(tc_id) into telegramId from tb_po_level2_interface where sequence_key = in_sequence_key;
  -- check telegram id for processing
  if telegramId != defaultTelegramId then
    errors := 'Invalid telegram ID -> ['||telegramId||'] instead of ['||defaultTelegramId||']. Sequence key = ['||in_sequence_key||']';
    return;
  end if;
  
  BEGIN
    -- select melt number, blank number, exit time and exit temp from stand 6
    SELECT TRIM(ITEM), TRIM(ITEM_1), TO_DATE(TRIM(ITEM_2), dateTimeTemplate), to_number(TRIM(ITEM_3))
      INTO  meltNoStr, blankNoStr, stand6_exit_time, stand6_exit_temp
      FROM TB_PO_LEVEL2_INTERFACE WHERE SEQUENCE_KEY = in_sequence_key;
    
    meltNo := to_number(meltNoStr);
    blankNo := to_number(blankNoStr);
    
    EXCEPTION
      WHEN INVALID_NUMBER or VALUE_ERROR THEN   -- can't convert string to number
        errors := fn_process_error('', '', telegramId, in_sequence_key, 'Error convert string to number! ''meltNo'' = [' || meltNoStr || ']; ''blankNo'' = [' || blankNoStr || ']!', errors);
        return;
  END;
    
  --TB_PO_BLANK_COMM UPDATE ---------- 
  BEGIN
    currentOperation := 'Operation [TB_PO_BLANK_COMM update].'; -- current operation marker for error handling
    UPDATE TB_PO_BLANK_COMM
      SET STAND_NO6_EXIT_TIME   = stand6_exit_time
          ,STAND_NO6_EXIT_TEMP  = stand6_exit_temp
          ,MOD_DDTT = SYSDATE
          ,MODIFIER = procedureName
      WHERE MELT_NO = meltNo and BLANK_NO = blankNo;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- error entry not exist in table
        errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
  END;

  EXCEPTION
    WHEN OTHERS THEN -- catch common exceptions
      errors := fn_process_error(sqlerrm, sqlcode, telegramId, in_sequence_key, currentOperation, errors);
END;