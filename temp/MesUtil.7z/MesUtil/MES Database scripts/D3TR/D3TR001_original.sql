create or replace 
PROCEDURE      SP_TR_D3TR001 (IN_SEQUENCE_KEY            IN  VARCHAR2
                                               ,IN_TC_ID                   IN  VARCHAR2
                                               )     

 IS        
 /*-----------------------------------------------------------------------------
 * PROGAM NAME       : SP_TR_D3TR001        
 * VERSION           : V1.00                       
 * DESCRIPTION       : BLANK charging time in WBF   
 * DEVELOPER NAME    : Lee               
 * CREATE DATE       : 06.09.2012              
 * MODIFY DATE       :                                                       
 */-----------------------------------------------------------------------------
  
vERR_CODE               NUMBER;
vERR_MSG                VARCHAR2(250);
  
BEGIN 
    RETURN;  
    -- TB_PO_INGOT_COMM UPDATE ----------
                                                 
    BEGIN
           UPDATE TB_PO_BLANK_COMM
              SET (WBF_CHARGE_TIME
                  ,MOD_DDTT
                  ,MODIFIER)
                     = (SELECT TO_DATE(TRIM(ITEM_2),'DD-MM-YYYY HH24:MI:SS')
                               ,SYSDATE
                               ,'SP_TR_D3TR001'
                          FROM TB_PO_LEVEL2_INTERFACE 
                         WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY)
            WHERE (MELT_NO,BLANK_NO) 
                     = (SELECT TRIM(ITEM),TRIM(ITEM_1)
                          FROM TB_PO_LEVEL2_INTERFACE 
                         WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY);
              
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_INGOT_COMM UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RETURN;
    END;
    
    -- TB_PO_RHF_CHARGE_ORD UPDATE ----------
    BEGIN
           UPDATE TB_PO_FURNACE_CHARGE_ORD
              SET FURNACE_WORK_STATUS = 'C'                     -- INGOT WEIGHING STATUS       
                  ,MOD_DDTT   = SYSDATE 
                  ,MODIFIER   = 'SP_TR_D3TR001'
            WHERE (MELT_NO,INGOT_NO,BLANK_NO) = (SELECT TRIM(ITEM)
                                                       ,TRIM(ITEM_1)
                                                       ,TRIM(ITEM_2)
                                                  FROM TB_PO_LEVEL2_INTERFACE 
                                                 WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY)
              AND MILL_GP     = '3';
              
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PO_RHF_CHARGE_ORD UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RAISE;
    END;
    
    -- TB_PM_MILL_DAILY_PLAN UPDEATE ----------
    BEGIN
           UPDATE TB_PM_MILL_DAILY_PLAN
              SET CHARGE_RESULT_QNTY = NVL(CHARGE_RESULT_QNTY,0) + 1
            WHERE (MELT_NO,SEQ_IN_MELT)
                  = (SELECT MELT_NO,SEQ_IN_MELT
                       FROM TB_PO_BLANK_COMM 
                      WHERE (MELT_NO,BLANK_NO) = (SELECT TRIM(ITEM)
                                                         ,TRIM(ITEM_1)
                                                     FROM TB_PO_LEVEL2_INTERFACE 
                                                    WHERE SEQUENCE_KEY = IN_SEQUENCE_KEY)
                     );   
    EXCEPTION          
        WHEN  NO_DATA_FOUND  THEN  
            vERR_CODE   :=  -20001;                 
            vERR_MSG    :=  'TB_PM_MILL_DAILY_PLAN UPDATE ERROR'
                        ||  ' TC_ID='        || IN_TC_ID
                        ||  ' SEQUENCE_KEY=' || IN_SEQUENCE_KEY
                        ||  ' LEVEL2_INTERFACE TB NOT FOUND';     
            RAISE;
    END;

COMMIT;
EXCEPTION  
    WHEN    OTHERS  THEN              
        RAISE;                           
END;