-- Original table altered on 12.10.2013

/*
 -- script for altering source (original) table
 alter table tb_cm_dept_cd modify dept_name varchar2(300);
 alter table tb_cm_dept_cd add is_alive varchar2(1) default 'Y' not null enable;
 alter table tb_cm_dept_cd add dept_id number default 0 not null enable;
*/

