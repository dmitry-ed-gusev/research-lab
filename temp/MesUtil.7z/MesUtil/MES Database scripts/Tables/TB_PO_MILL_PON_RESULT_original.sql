--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table TB_PO_MILL_PON_RESULT
--------------------------------------------------------

  CREATE TABLE "PMES"."TB_PO_MILL_PON_RESULT" 
   (	"MILL_GP" VARCHAR2(1 BYTE), 
	"PROD_YY" VARCHAR2(4 BYTE), 
	"PON" VARCHAR2(7 BYTE), 
	"PON_SEQ" NUMBER(2,0), 
	"MILL_DATE" VARCHAR2(8 BYTE), 
	"WORK_DUTY" VARCHAR2(1 BYTE), 
	"STATUS" VARCHAR2(1 BYTE), 
	"ORD_REM_GP" VARCHAR2(1 BYTE), 
	"HEATING_CD" VARCHAR2(2 BYTE), 
	"YARD_NO" VARCHAR2(20 BYTE), 
	"MELT_NO" NUMBER(7,0), 
	"STLGRADE_GRP_CD" VARCHAR2(5 BYTE), 
	"STLGRADE_CD" NUMBER(4,0), 
	"INPUT_SECTION_SIZE_T" NUMBER(4,1), 
	"INPUT_SECTION_SIZE_W" NUMBER(4,1), 
	"INPUT_QNTY" NUMBER(4,0), 
	"PURCHASE_WT" NUMBER(10,3), 
	"INPUT_WT" NUMBER(10,3), 
	"SECTION_CD" VARCHAR2(4 BYTE), 
	"SECTION_TYPE" VARCHAR2(2 BYTE), 
	"SECTION_SIZE_T" NUMBER(4,1), 
	"SECTION_SIZE_W" NUMBER(4,1), 
	"LEN_CD" VARCHAR2(2 BYTE), 
	"PROD_LEN_FR" NUMBER(4,0), 
	"PROD_LEN_TO" NUMBER(4,0), 
	"PROD_QNTY" NUMBER(4,0), 
	"PROD_WT" NUMBER(10,3), 
	"PROD_YYMM" VARCHAR2(6 BYTE), 
	"ORD_NO" VARCHAR2(10 BYTE), 
	"ORD_POSITION" NUMBER(3,0), 
	"REHEATING_MATERIAL_QNTY" NUMBER(5,0), 
	"REHEATING_MATERIAL_WT" NUMBER(10,3), 
	"TK_BAD_QNTY" NUMBER(5,0), 
	"TK_BAD_WT" NUMBER(10,3), 
	"SCRAP_BAD_QNTY" NUMBER(5,0), 
	"SCRAP_BAD_WT" NUMBER(10,3), 
	"HEATING_SEND_WT" NUMBER(10,3), 
	"STRAIGHT_SEND_WT" NUMBER(10,3), 
	"WORK_DOWN_CD" VARCHAR2(2 BYTE), 
	"WORK_DOWN_TIME" NUMBER(4,0), 
	"WORK_SHIFT" VARCHAR2(1 BYTE), 
	"WORKER_NAME" VARCHAR2(80 BYTE), 
	"REG_DDTT" DATE, 
	"REGISTER" VARCHAR2(15 BYTE), 
	"MOD_DDTT" DATE, 
	"MODIFIER" VARCHAR2(15 BYTE), 
	"BLANK_TYPE_CODE" NUMBER(3,0), 
	"PROD_WT_NATIVE" NUMBER(10,3)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 6291456 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
 

   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."MILL_GP" IS 'Mill Grouping';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."PROD_YY" IS 'Product Year';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."PON" IS 'Pon';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."PON_SEQ" IS 'Pon Sequence';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."MILL_DATE" IS 'Mill Date';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."WORK_DUTY" IS 'Work Duty';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."STATUS" IS 'Status';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."ORD_REM_GP" IS 'Order Remain Grouping';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."HEATING_CD" IS 'Heating Code';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."YARD_NO" IS 'Yard Number';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."MELT_NO" IS 'Melt Number';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."STLGRADE_GRP_CD" IS 'Steel Grade Group Code';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."STLGRADE_CD" IS 'Steel Grade Code';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."INPUT_SECTION_SIZE_T" IS 'Input Section Size Thickness';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."INPUT_SECTION_SIZE_W" IS 'Input Section Size Width';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."INPUT_QNTY" IS 'Input Qualtity';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."PURCHASE_WT" IS 'Purchase Weight';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."INPUT_WT" IS 'Input Weight';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."SECTION_CD" IS 'Section Code';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."SECTION_TYPE" IS 'SECTION TYPE';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."SECTION_SIZE_T" IS 'Section Size Thickness';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."SECTION_SIZE_W" IS 'Section Size Width';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."LEN_CD" IS 'Length Code';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."PROD_LEN_FR" IS 'Product Length From';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."PROD_LEN_TO" IS 'Product Length To';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."PROD_QNTY" IS 'Product Quantity';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."PROD_WT" IS 'Product Weight';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."PROD_YYMM" IS 'Product Year Month';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."ORD_NO" IS 'Order Number';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."ORD_POSITION" IS 'Order Position';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."REHEATING_MATERIAL_QNTY" IS 'Reheating Material Quantity';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."REHEATING_MATERIAL_WT" IS 'Reheating Material Weight';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."TK_BAD_QNTY" IS 'TK Bad Quantity';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."TK_BAD_WT" IS 'TK Bad Weight';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."SCRAP_BAD_QNTY" IS 'Scrap Bad Quantity';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."SCRAP_BAD_WT" IS 'Scrap Bad Weight';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."HEATING_SEND_WT" IS 'Heating Send Weight';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."STRAIGHT_SEND_WT" IS 'Straight Send Weight';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."WORK_DOWN_CD" IS 'Work Down Code';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."WORK_DOWN_TIME" IS 'Work Down Time';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."WORK_SHIFT" IS 'Work Shift';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."WORKER_NAME" IS 'Worker Name';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."REG_DDTT" IS 'Registration Date Time';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."REGISTER" IS 'Register';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."MOD_DDTT" IS 'Modification Date Time';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PON_RESULT"."MODIFIER" IS 'Modifier';
 
   COMMENT ON TABLE "PMES"."TB_PO_MILL_PON_RESULT"  IS 'PO MILL PON RESULT';
--------------------------------------------------------
--  DDL for Index IE1_TB_PO_MILL_PON_RESULT
--------------------------------------------------------

  CREATE INDEX "PMES"."IE1_TB_PO_MILL_PON_RESULT" ON "PMES"."TB_PO_MILL_PON_RESULT" ("MILL_GP", "STATUS", "INPUT_QNTY") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 917504 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index PK_TB_PO_MILL_PON_RESULT
--------------------------------------------------------

  CREATE UNIQUE INDEX "PMES"."PK_TB_PO_MILL_PON_RESULT" ON "PMES"."TB_PO_MILL_PON_RESULT" ("MILL_GP", "PROD_YY", "PON", "PON_SEQ", "MILL_DATE", "WORK_DUTY") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 2097152 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table TB_PO_MILL_PON_RESULT
--------------------------------------------------------

  ALTER TABLE "PMES"."TB_PO_MILL_PON_RESULT" MODIFY ("MILL_GP" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MILL_PON_RESULT" MODIFY ("PROD_YY" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MILL_PON_RESULT" MODIFY ("PON" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MILL_PON_RESULT" MODIFY ("PON_SEQ" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MILL_PON_RESULT" MODIFY ("MILL_DATE" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MILL_PON_RESULT" MODIFY ("WORK_DUTY" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MILL_PON_RESULT" ADD PRIMARY KEY ("MILL_GP", "PROD_YY", "PON", "PON_SEQ", "MILL_DATE", "WORK_DUTY")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 2097152 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  DDL for Trigger TB_PO_MILL_PON_RESULT_D
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_PO_MILL_PON_RESULT_D" 
AFTER DELETE ON PMES.TB_PO_MILL_PON_RESULT 
FOR EACH ROW
BEGIN

    IF  TO_NUMBER(:NEW.PON) >= 10000  AND TO_NUMBER(:NEW.PON)  < 99999 THEN
    
                  
        INSERT INTO TB_MA_PRODUCT_ROLLING
              ( PRODUCT_ROLLING_SEQ
                ,WORK_TICKET_YEAR
                ,WORK_TICKET_NO
                ,WORK_TICKET_STRING_NO
                ,ROLLING_DATE
                ,SHIFT_NO
                ,HEAT_NO
                ,SIZE1_INGOT
                ,SIZE2_INGOT
                ,SIZE1
                ,SIZE2
                ,LEN_FR
                ,LEN_TO
                ,STLGRADE_CD
                ,ORD_YY
                ,ORD_NO
                ,ORD_MONTH
                ,ORD_POSITION
                ,MILL_CD
              --  ,INGOT_CD
                ,PROFILE_CD
                ,QUANTITY_OF_INGOTS
                ,PURCHASED_INGOT_WT_KG
                ,INGOT_WT_KG
                ,ROLLED_PIECES
                ,PURE_GRADE_ROLLED_WT_KG
                ,RETURN_PIECES
                ,RETURN_KG
                ,UNFINISHED_SECTION_PIECES
                ,UNFINISHED_SECTION_KG
                ,ROLLING_CREW
                ,ROLLING_FOREMAN
                ,SHIFT_TIME
                ,DOWN_TIME
                ,THERMAL_TREATMENT_WT_KG
                ,FLATTENING_WT_KG
                ,NEW_UPDATE_RECORD
                ,REG_DDTT
                ,REGISTER
                ,MOD_DDTT
                ,MODIFIER
               )    
        VALUES ( PRODUCT_ROLLING_SEQ.NEXTVAL
                ,:OLD.PROD_YY                   --  WORK_TICKET_YEAR
                ,TO_NUMBER(:OLD.PON)            --  WORK_TICKET_NO
                ,:OLD.PON_SEQ                   --  WORK_TICKET_STRING_NO
                ,:OLD.MILL_DATE                 --  ROLLING_DATE
                ,TO_NUMBER(:OLD.WORK_DUTY)                 --  SHIFT_NO
                ,TO_CHAR(:OLD.MELT_NO)                   --  HEAT_NO
                ,TRUNC(:OLD.INPUT_SECTION_SIZE_T,0)      --  SIZE1_INGOT
                ,TRUNC(:OLD.INPUT_SECTION_SIZE_W,0)     --  SIZE2_INGOT
                ,TRUNC(:OLD.SECTION_SIZE_W,0)   --  SIZE1
                ,TRUNC(:OLD.SECTION_SIZE_T,0)   --  SIZE2
                ,:OLD.PROD_LEN_FR               --  LEN_FR
                ,:OLD.PROD_LEN_TO               --  LEN_TO
                ,:OLD.STLGRADE_CD
                ,SUBSTR(:OLD.PROD_YYMM,1,4)     --  ORD_YY
                ,:OLD.ORD_NO
                ,SUBSTR(:OLD.PROD_YYMM,5,2)     --  ORD_MONTH
                ,:OLD.ORD_POSITION
                ,CASE WHEN :OLD.MILL_GP = '3' THEN 350 ELSE 900 END     --  MILL_CD
              --  ,A.INGOT_CD
                ,TO_NUMBER(:OLD.SECTION_CD)                --  PROFILE_CD               
                ,:OLD.INPUT_QNTY                --  QUANTITY_OF_INGOTS
                ,:OLD.PURCHASE_WT               --  PURCHASED_INGOT_WT_KG
                ,:OLD.INPUT_WT                  --  INGOT_WT_KG
                ,:OLD.PROD_QNTY                 --  ROLLED_PIECES
                ,:OLD.PROD_WT                   --  PURE_GRADE_ROLLED_WT_KG
                ,:OLD.REHEATING_MATERIAL_QNTY   --  RETURN_PIECES
                ,:OLD.REHEATING_MATERIAL_WT     --  RETURN_KG
                ,CASE WHEN :OLD.ORD_NO IS NULL THEN :OLD.PROD_QNTY ELSE NULL END  -- UNFINISHED_SECTION_PIECES
                ,CASE WHEN :OLD.ORD_NO IS NULL THEN :OLD.PROD_WT   ELSE NULL END  -- UNFINISHED_SECTION_KG
                ,CASE WHEN :OLD.WORK_SHIFT = 'A' THEN 1 
                      WHEN :OLD.WORK_SHIFT = 'B' THEN 2
                      WHEN :OLD.WORK_SHIFT = 'C' THEN 3
                      ELSE 4 END             --  ROLLING_CREW                
                ,SUBSTR(:OLD.WORKER_NAME,1,15)      --  ROLLING_FOREMAN
                ,(SELECT START_HR || '-'|| END_HR FROM TB_PM_WORKDUTY_HR_STD 
                   WHERE SHOP_PROC_GP = '160' AND WORK_DUTY = :OLD.WORK_DUTY) -- SHIFT_TIME
                ,:OLD.WORK_DOWN_TIME            --  DOWN_TIME
                ,:OLD.HEATING_SEND_WT           --  THERMAL_TREATMENT_WT_KG
                ,:OLD.STRAIGHT_SEND_WT          --  FLATTENING_WT_KG
                ,'D'
                ,:OLD.REG_DDTT
                ,:OLD.REGISTER
                ,:OLD.MOD_DDTT
                ,:OLD.MODIFIER
               );
   ELSE 
       
        INSERT INTO TB_MA_BLANK_PRODUCTION
               (BLANK_PRODUCTION_SEQ
                ,WORK_TICKET_YEAR
                ,WORK_TICKET_NO
                ,WORK_TICKET_STRING_NO
                ,ROLLING_DATE
                ,SHIFT_NO
                ,HEAT_NO
                ,SIZE1_INGOT
                ,SIZE2_INGOT
                ,SIZE1
                ,SIZE2
                ,LEN_FR
                ,LEN_TO
                ,STLGRADE_CD
                ,MILL_CD
              --  ,INGOT_CD
                ,PROFILE_CD
                ,QUANTITY_OF_INGOTS
                ,PURCHASED_INGOT_WT_KG
                ,INGOT_WT_KG
                ,ROLLED_PIECES
                ,SQUARE_INGOT_ROLLED_WT_KG
                ,UNFINISHED_SECTION_PIECES
                ,UNFINISHED_SECTION_KG
                ,ROLLING_CREW
                ,ROLLING_FOREMAN
                ,NEW_UPDATE_RECORD
                ,MOD_DDTT
                ,MODIFIER
               )                    
        VALUES ( BLANK_PRODUCTION_SEQ.NEXTVAL
                ,:OLD.PROD_YY                    --  WORK_TICKET_YEAR
                ,TO_NUMBER(:OLD.PON)            --  WORK_TICKET_NO
                ,:OLD.PON_SEQ                   --  WORK_TICKET_STRING_NO
                ,:OLD.MILL_DATE                 --  ROLLING_DATE
                ,TO_NUMBER(:OLD.WORK_DUTY)                 --  SHIFT_NO
                ,TO_CHAR(:OLD.MELT_NO)                   --  HEAT_NO
                ,TRUNC(:OLD.INPUT_SECTION_SIZE_T,0)      --  SIZE1_INGOT
                ,TRUNC(:OLD.INPUT_SECTION_SIZE_W,0)     --  SIZE2_INGOT
                ,TRUNC(:OLD.SECTION_SIZE_W,0)   --  SIZE1
                ,TRUNC(:OLD.SECTION_SIZE_T,0)   --  SIZE2
                ,:OLD.PROD_LEN_FR               --  LEN_FR
                ,:OLD.PROD_LEN_TO               --  LEN_TO
                ,:OLD.STLGRADE_CD               
                ,CASE WHEN :OLD.MILL_GP = '3' THEN 350 ELSE 900 END     --  MILL_CD
              --  ,A.INGOT_CD
                ,TO_NUMBER(:OLD.SECTION_CD)                --  PROFILE_CD               
                ,:OLD.INPUT_QNTY                --  QUANTITY_OF_INGOTS
                ,:OLD.PURCHASE_WT               --  PURCHASED_INGOT_WT_KG
                ,:OLD.INPUT_WT                  --  INGOT_WT_KG
                ,:OLD.PROD_QNTY                 --  ROLLED_PIECES
                ,:OLD.PROD_WT                   --  PURE_GRADE_ROLLED_WT_KG
                ,CASE WHEN :OLD.ORD_NO IS NULL THEN :OLD.PROD_QNTY ELSE NULL END  -- UNFINISHED_SECTION_PIECES
                ,CASE WHEN :OLD.ORD_NO IS NULL THEN :OLD.PROD_WT   ELSE NULL END  -- UNFINISHED_SECTION_KG
                ,CASE WHEN :OLD.WORK_SHIFT = 'A' THEN 1 
                      WHEN :OLD.WORK_SHIFT = 'B' THEN 2
                      WHEN :OLD.WORK_SHIFT = 'C' THEN 3
                      ELSE 4 END             --  ROLLING_CREW                
                ,SUBSTR(:OLD.WORKER_NAME,1,15)               --  ROLLING_FOREMAN 
                ,'D'
                ,:OLD.MOD_DDTT
                ,:OLD.MODIFIER
                );  
   END IF;
END;
/
ALTER TRIGGER "PMES"."TB_PO_MILL_PON_RESULT_D" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TB_PO_MILL_PON_RESULT_I
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_PO_MILL_PON_RESULT_I" 
AFTER INSERT ON PMES.TB_PO_MILL_PON_RESULT 
FOR EACH ROW
BEGIN

    IF  TO_NUMBER(:NEW.PON) >= 10000  AND TO_NUMBER(:NEW.PON)  < 99999 THEN
    
                  
        INSERT INTO TB_MA_PRODUCT_ROLLING
              ( PRODUCT_ROLLING_SEQ
                ,WORK_TICKET_YEAR
                ,WORK_TICKET_NO
                ,WORK_TICKET_STRING_NO
                ,ROLLING_DATE
                ,SHIFT_NO
                ,HEAT_NO
                ,SIZE1_INGOT
                ,SIZE2_INGOT
                ,SIZE1
                ,SIZE2
                ,LEN_FR
                ,LEN_TO
                ,STLGRADE_CD
                ,ORD_YY
                ,ORD_NO
                ,ORD_MONTH
                ,ORD_POSITION
                ,MILL_CD
              --  ,INGOT_CD
                ,PROFILE_CD
                ,QUANTITY_OF_INGOTS
                ,PURCHASED_INGOT_WT_KG
                ,INGOT_WT_KG
                ,ROLLED_PIECES
                ,PURE_GRADE_ROLLED_WT_KG
                ,RETURN_PIECES
                ,RETURN_KG
                ,UNFINISHED_SECTION_PIECES
                ,UNFINISHED_SECTION_KG
                ,ROLLING_CREW
                ,ROLLING_FOREMAN
                ,SHIFT_TIME
                ,DOWN_TIME
                ,THERMAL_TREATMENT_WT_KG
                ,FLATTENING_WT_KG
                ,NEW_UPDATE_RECORD
                ,REG_DDTT
                ,REGISTER
                ,MOD_DDTT
                ,MODIFIER
               )    
        VALUES ( PRODUCT_ROLLING_SEQ.NEXTVAL
                ,:NEW.PROD_YY                   --  WORK_TICKET_YEAR
                ,TO_NUMBER(:NEW.PON)            --  WORK_TICKET_NO
                ,:NEW.PON_SEQ                   --  WORK_TICKET_STRING_NO
                ,:NEW.MILL_DATE                 --  ROLLING_DATE
                ,TO_NUMBER(:NEW.WORK_DUTY)                 --  SHIFT_NO
                ,TO_CHAR(:NEW.MELT_NO)                   --  HEAT_NO
                ,TRUNC(:NEW.INPUT_SECTION_SIZE_T,0)      --  SIZE1_INGOT
                ,TRUNC(:NEW.INPUT_SECTION_SIZE_W,0)     --  SIZE2_INGOT
                ,TRUNC(:NEW.SECTION_SIZE_W,0)   --  SIZE1
                ,TRUNC(:NEW.SECTION_SIZE_T,0)   --  SIZE2
                ,:NEW.PROD_LEN_FR               --  LEN_FR
                ,:NEW.PROD_LEN_TO               --  LEN_TO
                ,:NEW.STLGRADE_CD
                ,SUBSTR(:NEW.PROD_YYMM,1,4)     --  ORD_YY
                ,:NEW.ORD_NO
                ,SUBSTR(:NEW.PROD_YYMM,5,2)     --  ORD_MONTH
                ,:NEW.ORD_POSITION
                ,CASE WHEN :NEW.MILL_GP = '3' THEN 350 ELSE 900 END     --  MILL_CD
              --  ,A.INGOT_CD
                ,TO_NUMBER(:NEW.SECTION_CD)                --  PROFILE_CD               
                ,:NEW.INPUT_QNTY                --  QUANTITY_OF_INGOTS
                ,:NEW.PURCHASE_WT               --  PURCHASED_INGOT_WT_KG
                ,:NEW.INPUT_WT                  --  INGOT_WT_KG
                ,:NEW.PROD_QNTY                 --  ROLLED_PIECES
                ,:NEW.PROD_WT                   --  PURE_GRADE_ROLLED_WT_KG
                ,:NEW.REHEATING_MATERIAL_QNTY   --  RETURN_PIECES
                ,:NEW.REHEATING_MATERIAL_WT     --  RETURN_KG
                ,CASE WHEN :NEW.ORD_NO IS NULL THEN :NEW.PROD_QNTY ELSE NULL END  -- UNFINISHED_SECTION_PIECES
                ,CASE WHEN :NEW.ORD_NO IS NULL THEN :NEW.PROD_WT   ELSE NULL END  -- UNFINISHED_SECTION_KG
                ,CASE WHEN :NEW.WORK_SHIFT = 'A' THEN 1 
                      WHEN :NEW.WORK_SHIFT = 'B' THEN 2
                      WHEN :NEW.WORK_SHIFT = 'C' THEN 3
                      ELSE 4 END             --  ROLLING_CREW                
                ,SUBSTR(:NEW.WORKER_NAME,1,15)      --  ROLLING_FOREMAN
                ,(SELECT START_HR || '-'|| END_HR FROM TB_PM_WORKDUTY_HR_STD 
                   WHERE SHOP_PROC_GP = '160' AND WORK_DUTY = :NEW.WORK_DUTY) -- SHIFT_TIME
                ,:NEW.WORK_DOWN_TIME            --  DOWN_TIME
                ,:NEW.HEATING_SEND_WT           --  THERMAL_TREATMENT_WT_KG
                ,:NEW.STRAIGHT_SEND_WT          --  FLATTENING_WT_KG
                ,'I'
                ,:NEW.REG_DDTT
                ,:NEW.REGISTER
                ,:NEW.MOD_DDTT
                ,:NEW.MODIFIER
               );
   ELSE 
       
        INSERT INTO TB_MA_BLANK_PRODUCTION
               (BLANK_PRODUCTION_SEQ
                ,WORK_TICKET_YEAR
                ,WORK_TICKET_NO
                ,WORK_TICKET_STRING_NO
                ,ROLLING_DATE
                ,SHIFT_NO
                ,HEAT_NO
                ,SIZE1_INGOT
                ,SIZE2_INGOT
                ,SIZE1
                ,SIZE2
                ,LEN_FR
                ,LEN_TO
                ,STLGRADE_CD
                ,MILL_CD
              --  ,INGOT_CD
                ,PROFILE_CD
                ,QUANTITY_OF_INGOTS
                ,PURCHASED_INGOT_WT_KG
                ,INGOT_WT_KG
                ,ROLLED_PIECES
                ,SQUARE_INGOT_ROLLED_WT_KG
                ,UNFINISHED_SECTION_PIECES
                ,UNFINISHED_SECTION_KG
                ,ROLLING_CREW
                ,ROLLING_FOREMAN
                ,NEW_UPDATE_RECORD
                ,REG_DDTT
                ,REGISTER
               )                    
        VALUES ( BLANK_PRODUCTION_SEQ.NEXTVAL
                ,:NEW.PROD_YY                    --  WORK_TICKET_YEAR
                ,TO_NUMBER(:NEW.PON)            --  WORK_TICKET_NO
                ,:NEW.PON_SEQ                   --  WORK_TICKET_STRING_NO
                ,:NEW.MILL_DATE                 --  ROLLING_DATE
                ,TO_NUMBER(:NEW.WORK_DUTY)                 --  SHIFT_NO
                ,TO_CHAR(:NEW.MELT_NO)                   --  HEAT_NO
                ,TRUNC(:NEW.INPUT_SECTION_SIZE_T,0)      --  SIZE1_INGOT
                ,TRUNC(:NEW.INPUT_SECTION_SIZE_W,0)     --  SIZE2_INGOT
                ,TRUNC(:NEW.SECTION_SIZE_W,0)   --  SIZE1
                ,TRUNC(:NEW.SECTION_SIZE_T,0)   --  SIZE2
                ,:NEW.PROD_LEN_FR               --  LEN_FR
                ,:NEW.PROD_LEN_TO               --  LEN_TO
                ,:NEW.STLGRADE_CD               
                ,CASE WHEN :NEW.MILL_GP = '3' THEN 350 ELSE 900 END     --  MILL_CD
              --  ,A.INGOT_CD
                ,TO_NUMBER(:NEW.SECTION_CD)                --  PROFILE_CD               
                ,:NEW.INPUT_QNTY                --  QUANTITY_OF_INGOTS
                ,:NEW.PURCHASE_WT               --  PURCHASED_INGOT_WT_KG
                ,:NEW.INPUT_WT                  --  INGOT_WT_KG
                ,:NEW.PROD_QNTY                 --  ROLLED_PIECES
                ,:NEW.PROD_WT                   --  PURE_GRADE_ROLLED_WT_KG
                ,CASE WHEN :NEW.ORD_NO IS NULL THEN :NEW.PROD_QNTY ELSE NULL END  -- UNFINISHED_SECTION_PIECES
                ,CASE WHEN :NEW.ORD_NO IS NULL THEN :NEW.PROD_WT   ELSE NULL END  -- UNFINISHED_SECTION_KG
                ,CASE WHEN :NEW.WORK_SHIFT = 'A' THEN 1 
                      WHEN :NEW.WORK_SHIFT = 'B' THEN 2
                      WHEN :NEW.WORK_SHIFT = 'C' THEN 3
                      ELSE 4 END             --  ROLLING_CREW                
                ,SUBSTR(:NEW.WORKER_NAME,1,15)               --  ROLLING_FOREMAN 
                ,'I'
                ,:NEW.REG_DDTT
                ,:NEW.REGISTER
                );  
   END IF;
END;
/
ALTER TRIGGER "PMES"."TB_PO_MILL_PON_RESULT_I" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TB_PO_MILL_PON_RESULT_U
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_PO_MILL_PON_RESULT_U" 
AFTER UPDATE ON PMES.TB_PO_MILL_PON_RESULT 
FOR EACH ROW
BEGIN

    IF  TO_NUMBER(:NEW.PON) >= 10000  AND TO_NUMBER(:NEW.PON)  < 99999 THEN
    
                  
        INSERT INTO TB_MA_PRODUCT_ROLLING
              ( PRODUCT_ROLLING_SEQ
                ,WORK_TICKET_YEAR
                ,WORK_TICKET_NO
                ,WORK_TICKET_STRING_NO
                ,ROLLING_DATE
                ,SHIFT_NO
                ,HEAT_NO
                ,SIZE1_INGOT
                ,SIZE2_INGOT
                ,SIZE1
                ,SIZE2
                ,LEN_FR
                ,LEN_TO
                ,STLGRADE_CD
                ,ORD_YY
                ,ORD_NO
                ,ORD_MONTH
                ,ORD_POSITION
                ,MILL_CD
              --  ,INGOT_CD
                ,PROFILE_CD
                ,QUANTITY_OF_INGOTS
                ,PURCHASED_INGOT_WT_KG
                ,INGOT_WT_KG
                ,ROLLED_PIECES
                ,PURE_GRADE_ROLLED_WT_KG
                ,RETURN_PIECES
                ,RETURN_KG
                ,UNFINISHED_SECTION_PIECES
                ,UNFINISHED_SECTION_KG
                ,ROLLING_CREW
                ,ROLLING_FOREMAN
                ,SHIFT_TIME
                ,DOWN_TIME
                ,THERMAL_TREATMENT_WT_KG
                ,FLATTENING_WT_KG
                ,NEW_UPDATE_RECORD
                ,REG_DDTT
                ,REGISTER
                ,MOD_DDTT
                ,MODIFIER
               )    
        VALUES ( PRODUCT_ROLLING_SEQ.NEXTVAL
                ,:NEW.PROD_YY                   --  WORK_TICKET_YEAR
                ,TO_NUMBER(:NEW.PON)            --  WORK_TICKET_NO
                ,:NEW.PON_SEQ                   --  WORK_TICKET_STRING_NO
                ,:NEW.MILL_DATE                 --  ROLLING_DATE
                ,TO_NUMBER(:NEW.WORK_DUTY)                 --  SHIFT_NO
                ,TO_CHAR(:NEW.MELT_NO)                   --  HEAT_NO
                ,TRUNC(:NEW.INPUT_SECTION_SIZE_T,0)      --  SIZE1_INGOT
                ,TRUNC(:NEW.INPUT_SECTION_SIZE_W,0)     --  SIZE2_INGOT
                ,TRUNC(:NEW.SECTION_SIZE_W,0)   --  SIZE1
                ,TRUNC(:NEW.SECTION_SIZE_T,0)   --  SIZE2
                ,:NEW.PROD_LEN_FR               --  LEN_FR
                ,:NEW.PROD_LEN_TO               --  LEN_TO
                ,:NEW.STLGRADE_CD
                ,SUBSTR(:NEW.PROD_YYMM,1,4)     --  ORD_YY
                ,:NEW.ORD_NO
                ,SUBSTR(:NEW.PROD_YYMM,5,2)     --  ORD_MONTH
                ,:NEW.ORD_POSITION
                ,CASE WHEN :NEW.MILL_GP = '3' THEN 350 ELSE 900 END     --  MILL_CD
              --  ,A.INGOT_CD
                ,TO_NUMBER(:NEW.SECTION_CD)                --  PROFILE_CD               
                ,:NEW.INPUT_QNTY                --  QUANTITY_OF_INGOTS
                ,:NEW.PURCHASE_WT               --  PURCHASED_INGOT_WT_KG
                ,:NEW.INPUT_WT                  --  INGOT_WT_KG
                ,:NEW.PROD_QNTY                 --  ROLLED_PIECES
                ,:NEW.PROD_WT                   --  PURE_GRADE_ROLLED_WT_KG
                ,:NEW.REHEATING_MATERIAL_QNTY   --  RETURN_PIECES
                ,:NEW.REHEATING_MATERIAL_WT     --  RETURN_KG
                ,CASE WHEN :NEW.ORD_NO IS NULL THEN :NEW.PROD_QNTY ELSE NULL END  -- UNFINISHED_SECTION_PIECES
                ,CASE WHEN :NEW.ORD_NO IS NULL THEN :NEW.PROD_WT   ELSE NULL END  -- UNFINISHED_SECTION_KG
                ,CASE WHEN :NEW.WORK_SHIFT = 'A' THEN 1 
                      WHEN :NEW.WORK_SHIFT = 'B' THEN 2
                      WHEN :NEW.WORK_SHIFT = 'C' THEN 3
                      ELSE 4 END             --  ROLLING_CREW                
                ,SUBSTR(:NEW.WORKER_NAME,1,15)      --  ROLLING_FOREMAN
                ,(SELECT START_HR || '-'|| END_HR FROM TB_PM_WORKDUTY_HR_STD 
                   WHERE SHOP_PROC_GP = '160' AND WORK_DUTY = :NEW.WORK_DUTY) -- SHIFT_TIME
                ,:NEW.WORK_DOWN_TIME            --  DOWN_TIME
                ,:NEW.HEATING_SEND_WT           --  THERMAL_TREATMENT_WT_KG
                ,:NEW.STRAIGHT_SEND_WT          --  FLATTENING_WT_KG
                ,'U'
                ,:NEW.REG_DDTT
                ,:NEW.REGISTER
                ,:NEW.MOD_DDTT
                ,:NEW.MODIFIER             
               );
   ELSE 
       
        INSERT INTO TB_MA_BLANK_PRODUCTION
               (BLANK_PRODUCTION_SEQ
                ,WORK_TICKET_YEAR
                ,WORK_TICKET_NO
                ,WORK_TICKET_STRING_NO
                ,ROLLING_DATE
                ,SHIFT_NO
                ,HEAT_NO
                ,SIZE1_INGOT
                ,SIZE2_INGOT
                ,SIZE1
                ,SIZE2
                ,LEN_FR
                ,LEN_TO
                ,STLGRADE_CD
                ,MILL_CD
              --  ,INGOT_CD
                ,PROFILE_CD
                ,QUANTITY_OF_INGOTS
                ,PURCHASED_INGOT_WT_KG
                ,INGOT_WT_KG
                ,ROLLED_PIECES
                ,SQUARE_INGOT_ROLLED_WT_KG
                ,UNFINISHED_SECTION_PIECES
                ,UNFINISHED_SECTION_KG
                ,ROLLING_CREW
                ,ROLLING_FOREMAN
                ,NEW_UPDATE_RECORD
                ,REG_DDTT
                ,REGISTER
                ,MOD_DDTT
                ,MODIFIER
               )                    
        VALUES ( BLANK_PRODUCTION_SEQ.NEXTVAL
                ,:NEW.PROD_YY                    --  WORK_TICKET_YEAR
                ,TO_NUMBER(:NEW.PON)            --  WORK_TICKET_NO
                ,:NEW.PON_SEQ                   --  WORK_TICKET_STRING_NO
                ,:NEW.MILL_DATE                 --  ROLLING_DATE
                ,TO_NUMBER(:NEW.WORK_DUTY)                 --  SHIFT_NO
                ,TO_CHAR(:NEW.MELT_NO)                   --  HEAT_NO
                ,TRUNC(:NEW.INPUT_SECTION_SIZE_T,0)      --  SIZE1_INGOT
                ,TRUNC(:NEW.INPUT_SECTION_SIZE_W,0)     --  SIZE2_INGOT
                ,TRUNC(:NEW.SECTION_SIZE_W,0)   --  SIZE1
                ,TRUNC(:NEW.SECTION_SIZE_T,0)   --  SIZE2
                ,:NEW.PROD_LEN_FR               --  LEN_FR
                ,:NEW.PROD_LEN_TO               --  LEN_TO
                ,:NEW.STLGRADE_CD               
                ,CASE WHEN :NEW.MILL_GP = '3' THEN 350 ELSE 900 END     --  MILL_CD
              --  ,A.INGOT_CD
                ,TO_NUMBER(:NEW.SECTION_CD)                --  PROFILE_CD               
                ,:NEW.INPUT_QNTY                --  QUANTITY_OF_INGOTS
                ,:NEW.PURCHASE_WT               --  PURCHASED_INGOT_WT_KG
                ,:NEW.INPUT_WT                  --  INGOT_WT_KG
                ,:NEW.PROD_QNTY                 --  ROLLED_PIECES
                ,:NEW.PROD_WT                   --  PURE_GRADE_ROLLED_WT_KG
                ,CASE WHEN :NEW.ORD_NO IS NULL THEN :NEW.PROD_QNTY ELSE NULL END  -- UNFINISHED_SECTION_PIECES
                ,CASE WHEN :NEW.ORD_NO IS NULL THEN :NEW.PROD_WT   ELSE NULL END  -- UNFINISHED_SECTION_KG
                ,CASE WHEN :NEW.WORK_SHIFT = 'A' THEN 1 
                      WHEN :NEW.WORK_SHIFT = 'B' THEN 2
                      WHEN :NEW.WORK_SHIFT = 'C' THEN 3
                      ELSE 4 END             --  ROLLING_CREW                
                ,SUBSTR(:NEW.WORKER_NAME,1,15)               --  ROLLING_FOREMAN 
                ,'U'
                ,:NEW.REG_DDTT
                ,:NEW.REGISTER
                ,:NEW.MOD_DDTT
                ,:NEW.MODIFIER 
                );  
   END IF;
END;
/
ALTER TRIGGER "PMES"."TB_PO_MILL_PON_RESULT_U" ENABLE;
