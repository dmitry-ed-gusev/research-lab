--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table TB_CM_MENUINFO
--------------------------------------------------------

  CREATE TABLE "PMES"."TB_CM_MENUINFO" 
   (	"MENU_GRP" VARCHAR2(5 BYTE), 
	"MENU_ID" VARCHAR2(10 BYTE), 
	"UI_ID" VARCHAR2(50 BYTE), 
	"MENU_LEVEL" NUMBER(3,0), 
	"SORT_SEQ" NUMBER(3,0), 
	"REG_DDTT" DATE, 
	"REGISTER" VARCHAR2(15 BYTE), 
	"MOD_DDTT" DATE, 
	"MODIFIER" VARCHAR2(15 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
 

   COMMENT ON COLUMN "PMES"."TB_CM_MENUINFO"."MENU_GRP" IS 'Menu Group';
 
   COMMENT ON COLUMN "PMES"."TB_CM_MENUINFO"."MENU_ID" IS 'Menu ID';
 
   COMMENT ON COLUMN "PMES"."TB_CM_MENUINFO"."UI_ID" IS 'User Interface ID';
 
   COMMENT ON COLUMN "PMES"."TB_CM_MENUINFO"."MENU_LEVEL" IS 'Menu Level';
 
   COMMENT ON COLUMN "PMES"."TB_CM_MENUINFO"."SORT_SEQ" IS 'Sort Sequence';
 
   COMMENT ON COLUMN "PMES"."TB_CM_MENUINFO"."REG_DDTT" IS 'Registration Date Time';
 
   COMMENT ON COLUMN "PMES"."TB_CM_MENUINFO"."REGISTER" IS 'Register';
 
   COMMENT ON COLUMN "PMES"."TB_CM_MENUINFO"."MOD_DDTT" IS 'Modification Date Time';
 
   COMMENT ON COLUMN "PMES"."TB_CM_MENUINFO"."MODIFIER" IS 'Modifier';
 
   COMMENT ON TABLE "PMES"."TB_CM_MENUINFO"  IS 'CM Menu information';
--------------------------------------------------------
--  DDL for Index PK_TB_CM_MENUINFO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PMES"."PK_TB_CM_MENUINFO" ON "PMES"."TB_CM_MENUINFO" ("MENU_GRP", "MENU_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table TB_CM_MENUINFO
--------------------------------------------------------

  ALTER TABLE "PMES"."TB_CM_MENUINFO" ADD CONSTRAINT "PK_TB_CM_MENUINFO" PRIMARY KEY ("MENU_GRP", "MENU_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "PMES"."TB_CM_MENUINFO" MODIFY ("MENU_GRP" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_CM_MENUINFO" MODIFY ("MENU_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  DDL for Trigger TB_CM_MENUINFO_UD
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_CM_MENUINFO_UD" 
    AFTER UPDATE or DELETE ON PMES.TB_CM_MENUINFO   FOR EACH ROW

DECLARE NUMROWS INTEGER;

BEGIN

    /* TB_CM_MENUINFO UPDATE */
    IF :NEW.MENU_GRP IS NOT NULL OR :NEW.UI_ID IS NOT NULL THEN
        IF :NEW.MENU_GRP IS NOT NULL THEN
            SELECT COUNT(*) INTO NUMROWS
              FROM TB_CM_GRPMENU_INFO
             WHERE MENU_GRP = :NEW.MENU_GRP;

            IF NUMROWS = 0 THEN
                RAISE_APPLICATION_ERROR(-20002,
                                        'Cannot UPDATE TB_CM_MENUINFO because TB_CM_GRPMENU_INFO does not exist.'
                                        );
            END IF;
        END IF;

        IF :NEW.UI_ID IS NOT NULL THEN
            SELECT COUNT(*) INTO NUMROWS
              FROM TB_CM_UIINFO
             WHERE UI_ID = :NEW.UI_ID;

            IF NUMROWS = 0 THEN
                RAISE_APPLICATION_ERROR(-20002,
                                        'Cannot UPDATE TB_CM_MENUINFO because TB_CM_UIINFO does not exist.'
                                        );
            END IF;
        END IF;

        IF :NEW.MENU_GRP <> :OLD.MENU_GRP OR :NEW.MENU_ID <> :OLD.MENU_ID THEN
            UPDATE TB_CM_MYMENUINFO
               SET MENU_GRP = :NEW.MENU_GRP
                  ,MENU_ID  = :NEW.MENU_ID
             WHERE MENU_GRP = :OLD.MENU_GRP
               AND MENU_ID  = :OLD.MENU_ID;

            UPDATE TB_CM_MENUINFO_LANG
               SET MENU_GRP = :NEW.MENU_GRP
                  ,MENU_ID  = :NEW.MENU_ID
             WHERE MENU_GRP = :OLD.MENU_GRP
               AND MENU_ID  = :OLD.MENU_ID;
        END IF;

    ELSE    /* TB_CM_MENUINFO DELETE */
        DELETE FROM TB_CM_MYMENUINFO
         WHERE MENU_GRP = :OLD.MENU_GRP
           AND MENU_ID  = :OLD.MENU_ID;

        DELETE FROM TB_CM_MENUINFO_LANG
         WHERE MENU_GRP = :OLD.MENU_GRP
           AND MENU_ID  = :OLD.MENU_ID;
    END IF;

END; 
/
ALTER TRIGGER "PMES"."TB_CM_MENUINFO_UD" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TB_CM_MENUINFO_I
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_CM_MENUINFO_I" 
    AFTER INSERT ON PMES.TB_CM_MENUINFO   FOR EACH ROW

DECLARE NUMROWS INTEGER;

BEGIN

    IF :NEW.MENU_GRP IS NOT NULL THEN
        SELECT COUNT(*) INTO NUMROWS
          FROM TB_CM_GRPMENU_INFO
         WHERE MENU_GRP = :NEW.MENU_GRP;

        IF NUMROWS = 0 THEN
            RAISE_APPLICATION_ERROR(-20002,
                                    'Cannot INSERT TB_CM_MENUINFO because TB_CM_GRPMENU_INFO does not exist.'
                                    );
        END IF;
    END IF;

    IF :NEW.UI_ID IS NOT NULL THEN
        SELECT COUNT(*) INTO NUMROWS
          FROM TB_CM_UIINFO
         WHERE UI_ID = :NEW.UI_ID;

        IF NUMROWS = 0 THEN
            RAISE_APPLICATION_ERROR(-20002,
                                    'Cannot INSERT TB_CM_MENUINFO because TB_CM_UIINFO does not exist.'
                                    );
        END IF;
    END IF;

END; 
/
ALTER TRIGGER "PMES"."TB_CM_MENUINFO_I" ENABLE;
