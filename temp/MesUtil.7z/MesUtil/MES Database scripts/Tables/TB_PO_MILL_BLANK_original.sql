--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table TB_PO_MILL_BLANK
--------------------------------------------------------

  CREATE TABLE "PMES"."TB_PO_MILL_BLANK" 
   (	"PROD_YY" VARCHAR2(4 BYTE), 
	"PON" VARCHAR2(7 BYTE), 
	"PON_SEQ" NUMBER(2,0), 
	"MELT_NO" NUMBER(7,0), 
	"STLGRADE_CD" NUMBER(4,0), 
	"STATUS" VARCHAR2(1 BYTE), 
	"MILL_DATE" VARCHAR2(8 BYTE), 
	"BLANK_KIND" VARCHAR2(8 BYTE), 
	"SECTION_CD" VARCHAR2(4 BYTE), 
	"SECTION_TYPE" VARCHAR2(2 BYTE), 
	"SECTION_SIZE_T" NUMBER(4,1), 
	"SECTION_SIZE_W" NUMBER(4,1), 
	"PROD_LEN_FR" NUMBER(4,0), 
	"PROD_LEN_TO" NUMBER(4,0), 
	"PROD_QNTY" NUMBER(5,0), 
	"PROD_WT" NUMBER(10,3), 
	"INSPECT_DATE" VARCHAR2(8 BYTE), 
	"INSPECT_QNTY" NUMBER(5,0), 
	"INSPECT_WT" NUMBER(10,3), 
	"INSPECT_BAD_CD" NUMBER(3,0), 
	"INSPECT_BAD_QNTY" NUMBER(5,0), 
	"INSPECT_BAD_WT" NUMBER(10,3), 
	"INSPECT_BAD_CUT_WT" NUMBER(10,3), 
	"YARD_GP" VARCHAR2(6 BYTE), 
	"WORK_DUTY" VARCHAR2(1 BYTE), 
	"WORK_SHIFT" VARCHAR2(1 BYTE), 
	"BEFORE_PON_SEQ" NUMBER(2,0), 
	"REG_DDTT" DATE, 
	"REGISTER" VARCHAR2(15 BYTE), 
	"MOD_DDTT" DATE, 
	"MODIFIER" VARCHAR2(15 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
 

   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."PROD_YY" IS 'Product Year';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."PON" IS 'Pon';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."PON_SEQ" IS 'Pon Sequence';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."MELT_NO" IS 'Melt Number';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."STLGRADE_CD" IS 'Steel Grade Code';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."STATUS" IS 'Status';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."MILL_DATE" IS 'Mill Date';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."BLANK_KIND" IS 'Blank Kind';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."SECTION_CD" IS 'Section Code';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."SECTION_TYPE" IS 'Section Type';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."SECTION_SIZE_T" IS 'Section Size Thickness';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."SECTION_SIZE_W" IS 'Section Size Width';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."PROD_LEN_FR" IS 'Product Length From';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."PROD_LEN_TO" IS 'Product Length To';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."PROD_QNTY" IS 'Product Quantity';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."PROD_WT" IS 'Product Weight';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."INSPECT_DATE" IS 'Inspect Date';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."INSPECT_QNTY" IS 'Inspect Quantity';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."INSPECT_WT" IS 'Inspect Weight';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."INSPECT_BAD_CD" IS 'Inspect Bad code';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."INSPECT_BAD_QNTY" IS 'Inspect Bad Quantity';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."INSPECT_BAD_WT" IS 'Inspect Bad Weight';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."INSPECT_BAD_CUT_WT" IS 'Inspect Bad Cut Weight';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."YARD_GP" IS 'Yard Grouping';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."WORK_DUTY" IS 'Wordk duty';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."WORK_SHIFT" IS 'Work Shift';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."BEFORE_PON_SEQ" IS 'Befror PON sequence';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."REG_DDTT" IS 'Registration Date Time';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."REGISTER" IS 'Register';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."MOD_DDTT" IS 'Modification Date Time';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_BLANK"."MODIFIER" IS 'Modifier';
 
   COMMENT ON TABLE "PMES"."TB_PO_MILL_BLANK"  IS 'Blank inspection data';
--------------------------------------------------------
--  DDL for Index PK_TB_PO_MILL_BLANK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PMES"."PK_TB_PO_MILL_BLANK" ON "PMES"."TB_PO_MILL_BLANK" ("PROD_YY", "PON", "PON_SEQ") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 393216 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table TB_PO_MILL_BLANK
--------------------------------------------------------

  ALTER TABLE "PMES"."TB_PO_MILL_BLANK" MODIFY ("PROD_YY" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MILL_BLANK" MODIFY ("PON" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MILL_BLANK" MODIFY ("PON_SEQ" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MILL_BLANK" ADD PRIMARY KEY ("PROD_YY", "PON", "PON_SEQ")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 393216 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  DDL for Trigger TB_PO_MILL_BLANK_D
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_PO_MILL_BLANK_D" 
AFTER DELETE ON PMES.TB_PO_MILL_BLANK 
FOR EACH ROW

BEGIN
    
    INSERT INTO TB_MA_BLANK_INSPECTION
              ( BLANK_INSPECTION_SEQ
                ,WORK_TICKET_YEAR
                ,WORK_TICKET_NO
                ,WORK_TICKET_STRING_NO
                ,HEAT_NO
                ,SIZE1
                ,SIZE2
                ,LEN_FR
                ,LEN_TO
                ,STLGRADE_CD
                ,PROFILE_CD
                ,ROLLING_DATE
                ,ROLLED_PIECES
                ,ROLLED_WT_KG
                ,AD_ACCEPTANCE_DATE
                ,AD_ACCEPTANCE_PIECES
                ,AD_ACCEPTANCE_WT_KG
                ,AD_ACCEPTANCE_CLIPPING_KG
                ,AD_ACCEPTANCE_DEFECT_PIECES
                ,NEW_UPDATE_RECORD
                ,REG_DDTT
                ,REGISTER
                ,MOD_DDTT
                ,MODIFIER
               ) 
        VALUES (BLANK_INSPECTION_SEQ.NEXTVAL
                ,:OLD.PROD_YY                    --  WORK_TICKET_YEAR
                ,TO_NUMBER(:OLD.PON)             --  WORK_TICKET_NO
                ,:OLD.PON_SEQ                   --  WORK_TICKET_STRING_NO
                ,TO_CHAR(:OLD.MELT_NO)                   --  HEAT_NO
                ,TRUNC(:OLD.SECTION_SIZE_W,0)   --  SIZE1
                ,TRUNC(:OLD.SECTION_SIZE_T,0)   --  SIZE2
                ,:OLD.PROD_LEN_FR               --  LEN_FR
                ,:OLD.PROD_LEN_TO               --  LEN_TO
                ,:OLD.STLGRADE_CD               
                ,TO_NUMBER(:OLD.SECTION_CD)                --  PROFILE_CD 
                ,TO_DATE(:OLD.MILL_DATE,'YYYYMMDD HH24MISS')
                ,:OLD.PROD_QNTY                 --  ROLLED_PIECES
                ,:OLD.PROD_WT                   --  PURE_GRADE_ROLLED_WT_KG 
                ,TO_DATE(:OLD.INSPECT_DATE,'YYYYMMDD HH24MISS')
                ,:OLD.INSPECT_QNTY
                ,:OLD.INSPECT_WT
                ,:OLD.INSPECT_BAD_WT + :OLD.INSPECT_BAD_CUT_WT
                ,:OLD.INSPECT_BAD_QNTY
                ,'D'
                ,:OLD.REG_DDTT
                ,:OLD.REGISTER
                ,:OLD.MOD_DDTT
                ,:OLD.MODIFIER
               );
END;
/
ALTER TRIGGER "PMES"."TB_PO_MILL_BLANK_D" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TB_PO_MILL_BLANK_I
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_PO_MILL_BLANK_I" 
AFTER INSERT ON PMES.TB_PO_MILL_BLANK 
FOR EACH ROW

BEGIN
    
    INSERT INTO TB_MA_BLANK_INSPECTION
              ( BLANK_INSPECTION_SEQ
                ,WORK_TICKET_YEAR
                ,WORK_TICKET_NO
                ,WORK_TICKET_STRING_NO
                ,HEAT_NO
                ,SIZE1
                ,SIZE2
                ,LEN_FR
                ,LEN_TO
                ,STLGRADE_CD
                ,PROFILE_CD
                ,ROLLING_DATE
                ,ROLLED_PIECES
                ,ROLLED_WT_KG
                ,AD_ACCEPTANCE_DATE
                ,AD_ACCEPTANCE_PIECES
                ,AD_ACCEPTANCE_WT_KG
                ,AD_ACCEPTANCE_CLIPPING_KG
                ,AD_ACCEPTANCE_DEFECT_PIECES
                ,NEW_UPDATE_RECORD
                ,REG_DDTT
                ,REGISTER
                ,MOD_DDTT
                ,MODIFIER
               ) 
        VALUES (BLANK_INSPECTION_SEQ.NEXTVAL
                ,:NEW.PROD_YY                    --  WORK_TICKET_YEAR
                ,TO_NUMBER(:NEW.PON)             --  WORK_TICKET_NO
                ,:NEW.PON_SEQ                   --  WORK_TICKET_STRING_NO
                ,TO_CHAR(:NEW.MELT_NO)                   --  HEAT_NO
                ,TRUNC(:NEW.SECTION_SIZE_W,0)   --  SIZE1
                ,TRUNC(:NEW.SECTION_SIZE_T,0)   --  SIZE2
                ,:NEW.PROD_LEN_FR               --  LEN_FR
                ,:NEW.PROD_LEN_TO               --  LEN_TO
                ,:NEW.STLGRADE_CD               
                ,TO_NUMBER(:NEW.SECTION_CD)                --  PROFILE_CD 
                ,TO_DATE(:NEW.MILL_DATE,'YYYYMMDD HH24MISS')
                ,:NEW.PROD_QNTY                 --  ROLLED_PIECES
                ,:NEW.PROD_WT                   --  PURE_GRADE_ROLLED_WT_KG 
                ,TO_DATE(:NEW.INSPECT_DATE,'YYYYMMDD HH24MISS')                
                ,:NEW.INSPECT_QNTY
                ,:NEW.INSPECT_WT
                ,:NEW.INSPECT_BAD_WT + :NEW.INSPECT_BAD_CUT_WT
                ,:NEW.INSPECT_BAD_QNTY
                ,'I'
                ,:NEW.REG_DDTT
                ,:NEW.REGISTER
                ,:NEW.MOD_DDTT
                ,:NEW.MODIFIER
               );
END;
/
ALTER TRIGGER "PMES"."TB_PO_MILL_BLANK_I" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TB_PO_MILL_BLANK_U
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_PO_MILL_BLANK_U" 
AFTER UPDATE ON PMES.TB_PO_MILL_BLANK 
FOR EACH ROW
BEGIN

    
    INSERT INTO TB_MA_BLANK_INSPECTION
              ( BLANK_INSPECTION_SEQ
                ,WORK_TICKET_YEAR
                ,WORK_TICKET_NO
                ,WORK_TICKET_STRING_NO
                ,HEAT_NO
                ,SIZE1
                ,SIZE2
                ,LEN_FR
                ,LEN_TO
                ,STLGRADE_CD
                ,PROFILE_CD
                ,ROLLING_DATE
                ,ROLLED_PIECES
                ,ROLLED_WT_KG
                ,AD_ACCEPTANCE_DATE
                ,AD_ACCEPTANCE_PIECES
                ,AD_ACCEPTANCE_WT_KG
                ,AD_ACCEPTANCE_CLIPPING_KG
                ,AD_ACCEPTANCE_DEFECT_PIECES
                ,NEW_UPDATE_RECORD
                ,REG_DDTT
                ,REGISTER
                ,MOD_DDTT
                ,MODIFIER
               ) 
        VALUES (BLANK_INSPECTION_SEQ.NEXTVAL
                ,:NEW.PROD_YY                    --  WORK_TICKET_YEAR
                ,TO_NUMBER(:NEW.PON)             --  WORK_TICKET_NO
                ,:NEW.PON_SEQ                   --  WORK_TICKET_STRING_NO
                ,TO_CHAR(:NEW.MELT_NO)                   --  HEAT_NO
                ,TRUNC(:NEW.SECTION_SIZE_W,0)   --  SIZE1
                ,TRUNC(:NEW.SECTION_SIZE_T,0)   --  SIZE2
                ,:NEW.PROD_LEN_FR               --  LEN_FR
                ,:NEW.PROD_LEN_TO               --  LEN_TO
                ,:NEW.STLGRADE_CD               
                ,TO_NUMBER(:NEW.SECTION_CD)                --  PROFILE_CD 
                ,TO_DATE(:NEW.MILL_DATE,'YYYYMMDD HH24MISS')
                ,:NEW.PROD_QNTY                 --  ROLLED_PIECES
                ,:NEW.PROD_WT                   --  PURE_GRADE_ROLLED_WT_KG 
                ,TO_DATE(:NEW.INSPECT_DATE,'YYYYMMDD HH24MISS')
                ,:NEW.INSPECT_QNTY
                ,:NEW.INSPECT_WT
                ,:NEW.INSPECT_BAD_WT + :NEW.INSPECT_BAD_CUT_WT
                ,:NEW.INSPECT_BAD_QNTY
                ,'U'
                ,:NEW.REG_DDTT
                ,:NEW.REGISTER
                ,:NEW.MOD_DDTT
                ,:NEW.MODIFIER
               );
END;
/
ALTER TRIGGER "PMES"."TB_PO_MILL_BLANK_U" ENABLE;
