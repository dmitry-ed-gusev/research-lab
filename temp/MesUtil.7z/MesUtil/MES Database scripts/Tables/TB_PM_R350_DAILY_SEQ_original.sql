--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table TB_PM_R350_DAILY_SEQ
--------------------------------------------------------

  CREATE TABLE "PMES"."TB_PM_R350_DAILY_SEQ" 
   (	"SECTION_TYPE" VARCHAR2(2 BYTE), 
	"SECTION_SIZE_T" NUMBER(4,1), 
	"SECTION_SIZE_W" NUMBER(4,1), 
	"SEQ" NUMBER(3,0), 
	"STAND_NO" VARCHAR2(2 BYTE), 
	"WORK_ORDER_YN" VARCHAR2(1 BYTE), 
	"REG_DDTT" DATE, 
	"REGISTER" VARCHAR2(15 BYTE), 
	"MOD_DDTT" DATE, 
	"MODIFIER" VARCHAR2(15 BYTE)
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE( INITIAL 65536 NEXT 1048576 MINEXTENTS 1
  FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table TB_PM_R350_DAILY_SEQ
--------------------------------------------------------

  ALTER TABLE "PMES"."TB_PM_R350_DAILY_SEQ" MODIFY ("SECTION_TYPE" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PM_R350_DAILY_SEQ" MODIFY ("SECTION_SIZE_T" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PM_R350_DAILY_SEQ" MODIFY ("SECTION_SIZE_W" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PM_R350_DAILY_SEQ" MODIFY ("SEQ" NOT NULL ENABLE);
