--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table TB_MIGRATION_TABLES
--------------------------------------------------------

  CREATE TABLE "PMES"."TB_MIGRATION_TABLES" 
   (	"FILE_NAME1" VARCHAR2(100 BYTE), 
	"FILE_NAME2" VARCHAR2(100 BYTE), 
	"FILE_NAME3" VARCHAR2(100 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table TB_MIGRATION_TABLES
--------------------------------------------------------

  ALTER TABLE "PMES"."TB_MIGRATION_TABLES" MODIFY ("FILE_NAME1" NOT NULL ENABLE);
