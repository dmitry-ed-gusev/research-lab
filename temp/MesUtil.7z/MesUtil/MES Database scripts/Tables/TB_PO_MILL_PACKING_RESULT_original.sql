--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table TB_PO_MILL_PACKING_RESULT
--------------------------------------------------------

  CREATE TABLE "PMES"."TB_PO_MILL_PACKING_RESULT" 
   (	"PROD_YY" VARCHAR2(4 BYTE), 
	"PON" VARCHAR2(7 BYTE), 
	"PON_SEQ" NUMBER(2,0), 
	"PACKING_NO" NUMBER(3,0), 
	"MELT_NO" NUMBER(5,0), 
	"STLGRADE_CD" NUMBER(4,0), 
	"PROD_YYMM" VARCHAR2(6 BYTE), 
	"ORD_NO" VARCHAR2(10 BYTE), 
	"ORD_POSITION" NUMBER(3,0), 
	"ORD_REM_GP" VARCHAR2(1 BYTE), 
	"STATUS" VARCHAR2(1 BYTE), 
	"SECTION_CD" VARCHAR2(4 BYTE), 
	"SECTION_TYPE" VARCHAR2(2 BYTE), 
	"SECTION_SIZE_T" NUMBER(4,1), 
	"SECTION_SIZE_W" NUMBER(4,1), 
	"LEN_FR" NUMBER(4,0), 
	"LEN_TO" NUMBER(4,0), 
	"GOODS_QNTY" NUMBER(5,0), 
	"GOODS_WT" NUMBER(10,3), 
	"WEIGHING_DDTT" DATE, 
	"MILL_GP" VARCHAR2(1 BYTE), 
	"RECEIPT_DATE" DATE, 
	"OTK" VARCHAR2(1 BYTE), 
	"OTK_DATE" VARCHAR2(8 BYTE), 
	"RETURN_DDTT" DATE, 
	"ORDER_MATCH_DATE" VARCHAR2(8 BYTE), 
	"REMAIN_CAUSE_CD" VARCHAR2(1 BYTE), 
	"REMAIN_OCCUR_DATE" VARCHAR2(8 BYTE), 
	"INVOICE_NO_SHOP160" VARCHAR2(12 BYTE), 
	"INVOICE_NO_SHOP750" VARCHAR2(12 BYTE), 
	"INVOICE_NO" VARCHAR2(12 BYTE), 
	"SHIPMENT_DATE" VARCHAR2(8 BYTE), 
	"YARD_GP" VARCHAR2(6 BYTE), 
	"CUSTOMER_PACKING_NO" NUMBER(4,0), 
	"PACKING_GROUPING_NO" NUMBER(2,0), 
	"COPY_PACKING_QNTY" NUMBER(5,0), 
	"REG_DDTT" DATE, 
	"REGISTER" VARCHAR2(15 BYTE), 
	"MOD_DDTT" DATE, 
	"MODIFIER" VARCHAR2(15 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 8388608 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
 

   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."PROD_YY" IS 'Product Year';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."PON" IS 'Pon';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."PON_SEQ" IS 'Pon Sequence';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."PACKING_NO" IS 'Packing Number';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."MELT_NO" IS 'Melt Number';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."STLGRADE_CD" IS 'Steel Grade Code';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."PROD_YYMM" IS 'Product Year Month';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."ORD_NO" IS 'Order Number';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."ORD_POSITION" IS 'Order Position';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."ORD_REM_GP" IS 'Order Remain Grouping';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."STATUS" IS 'Status';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."SECTION_CD" IS 'Section Code';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."SECTION_TYPE" IS 'Section Type';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."SECTION_SIZE_T" IS 'Section Size Thickness';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."SECTION_SIZE_W" IS 'Section Size Width';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."LEN_FR" IS 'Length From';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."LEN_TO" IS 'Length To';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."GOODS_QNTY" IS 'Goods Quantity';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."GOODS_WT" IS 'Goods Weight';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."WEIGHING_DDTT" IS 'Weighing Date Time';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."MILL_GP" IS 'Mill Grouping';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."RECEIPT_DATE" IS 'Receipt Date';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."OTK" IS 'OTK';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."OTK_DATE" IS 'OTK Date';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."RETURN_DDTT" IS 'Return Date Time';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."ORDER_MATCH_DATE" IS 'Order Match Date';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."REMAIN_CAUSE_CD" IS 'Remain Cause Code';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."REMAIN_OCCUR_DATE" IS 'Remain Occurrence Date';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."INVOICE_NO_SHOP160" IS 'Invoice Number Shop160';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."INVOICE_NO_SHOP750" IS 'Invoice Number Shop750';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."INVOICE_NO" IS 'Invoice Number';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."SHIPMENT_DATE" IS 'Shipment Date TIme';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."YARD_GP" IS 'Yard Grouping';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."CUSTOMER_PACKING_NO" IS 'Customer Packing Number';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."PACKING_GROUPING_NO" IS 'Packing Grouping Number';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."COPY_PACKING_QNTY" IS 'Copy packing quantity';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."REG_DDTT" IS 'Registration Date Time';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."REGISTER" IS 'Register';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."MOD_DDTT" IS 'Modification Date Time';
 
   COMMENT ON COLUMN "PMES"."TB_PO_MILL_PACKING_RESULT"."MODIFIER" IS 'Modifier';
 
   COMMENT ON TABLE "PMES"."TB_PO_MILL_PACKING_RESULT"  IS 'Packing result';
--------------------------------------------------------
--  DDL for Index PK_TB_PO_MILL_PACKING_RESULT
--------------------------------------------------------

  CREATE UNIQUE INDEX "PMES"."PK_TB_PO_MILL_PACKING_RESULT" ON "PMES"."TB_PO_MILL_PACKING_RESULT" ("PROD_YY", "PON", "PON_SEQ", "PACKING_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 3145728 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table TB_PO_MILL_PACKING_RESULT
--------------------------------------------------------

  ALTER TABLE "PMES"."TB_PO_MILL_PACKING_RESULT" MODIFY ("PROD_YY" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MILL_PACKING_RESULT" MODIFY ("PON" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MILL_PACKING_RESULT" MODIFY ("PON_SEQ" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MILL_PACKING_RESULT" MODIFY ("PACKING_NO" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MILL_PACKING_RESULT" ADD PRIMARY KEY ("PROD_YY", "PON", "PON_SEQ", "PACKING_NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 3145728 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  DDL for Trigger TB_PO_MILL_PACKING_RESULT_D
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_PO_MILL_PACKING_RESULT_D" 
AFTER DELETE ON PMES.TB_PO_MILL_PACKING_RESULT 
FOR EACH ROW
BEGIN

          
    INSERT INTO TB_MA_MILL_PACKING_RESULT
              ( MILL_PACKING_SEQ
                ,PROD_YY
                ,PON
                ,PON_SEQ
                ,PACKING_NO
                ,MELT_NO
                ,STLGRADE_CD
                ,PROD_YYMM
                ,ORD_NO
                ,ORD_POSITION
                ,ORD_REM_GP
                ,SECTION_CD
                ,SECTION_TYPE
                ,SECTION_SIZE_T
                ,SECTION_SIZE_W
                ,LEN_FR
                ,LEN_TO
                ,GOODS_QNTY
                ,GOODS_WT
                ,WEIGHING_DDTT
                ,MILL_GP
                ,RECEIPT_DATE
                ,OTK
                ,OTK_DATE
                ,INVOICE_NO_SHOP160
                ,INVOICE_NO_SHOP750
                ,INVOICE_NO
                ,SHIPMENT_DATE
                ,YARD_GP
                ,CUSTOMER_PACKING_NO
                ,NEW_UPDATE_RECORD
                ,REG_DDTT
                ,REGISTER
                ,MOD_DDTT
                ,MODIFIER
               ) 
        VALUES (MILL_PACKING_SEQ.NEXTVAL
                ,:NEW.PROD_YY
                ,:NEW.PON
                ,:NEW.PON_SEQ
                ,:NEW.PACKING_NO
                ,:NEW.MELT_NO
                ,:NEW.STLGRADE_CD
                ,:NEW.PROD_YYMM
                ,:NEW.ORD_NO
                ,:NEW.ORD_POSITION
                ,:NEW.ORD_REM_GP
                ,:NEW.SECTION_CD
                ,:NEW.SECTION_TYPE
                ,:NEW.SECTION_SIZE_T
                ,:NEW.SECTION_SIZE_W
                ,:NEW.LEN_FR
                ,:NEW.LEN_TO
                ,:NEW.GOODS_QNTY
                ,:NEW.GOODS_WT
                ,:NEW.WEIGHING_DDTT
                ,:NEW.MILL_GP
                ,:NEW.RECEIPT_DATE
                ,:NEW.OTK
                ,:NEW.OTK_DATE
                ,:NEW.INVOICE_NO_SHOP160
                ,:NEW.INVOICE_NO_SHOP750
                ,:NEW.INVOICE_NO
                ,:NEW.SHIPMENT_DATE
                ,:NEW.YARD_GP
                ,:NEW.CUSTOMER_PACKING_NO
                ,'D'
                ,:NEW.REG_DDTT
                ,:NEW.REGISTER
                ,:NEW.MOD_DDTT
                ,:NEW.MODIFIER
                );
END;
/
ALTER TRIGGER "PMES"."TB_PO_MILL_PACKING_RESULT_D" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TB_PO_MILL_PACKING_RESULT_I
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_PO_MILL_PACKING_RESULT_I" 
AFTER INSERT ON PMES.TB_PO_MILL_PACKING_RESULT 
FOR EACH ROW
BEGIN
          
    INSERT INTO TB_MA_MILL_PACKING_RESULT
              ( MILL_PACKING_SEQ
                ,PROD_YY
                ,PON
                ,PON_SEQ
                ,PACKING_NO
                ,MELT_NO
                ,STLGRADE_CD
                ,PROD_YYMM
                ,ORD_NO
                ,ORD_POSITION
                ,ORD_REM_GP
                ,SECTION_CD
                ,SECTION_TYPE
                ,SECTION_SIZE_T
                ,SECTION_SIZE_W
                ,LEN_FR
                ,LEN_TO
                ,GOODS_QNTY
                ,GOODS_WT
                ,WEIGHING_DDTT
                ,MILL_GP
                ,RECEIPT_DATE
                ,OTK
                ,OTK_DATE
                ,INVOICE_NO_SHOP160
                ,INVOICE_NO_SHOP750
                ,INVOICE_NO
                ,SHIPMENT_DATE
                ,YARD_GP
                ,CUSTOMER_PACKING_NO
                ,NEW_UPDATE_RECORD
                ,REG_DDTT
                ,REGISTER
                ,MOD_DDTT
                ,MODIFIER
               ) 
        VALUES (MILL_PACKING_SEQ.NEXTVAL
                ,:NEW.PROD_YY
                ,:NEW.PON
                ,:NEW.PON_SEQ
                ,:NEW.PACKING_NO
                ,:NEW.MELT_NO
                ,:NEW.STLGRADE_CD
                ,:NEW.PROD_YYMM
                ,:NEW.ORD_NO
                ,:NEW.ORD_POSITION
                ,:NEW.ORD_REM_GP
                ,:NEW.SECTION_CD
                ,:NEW.SECTION_TYPE
                ,:NEW.SECTION_SIZE_T
                ,:NEW.SECTION_SIZE_W
                ,:NEW.LEN_FR
                ,:NEW.LEN_TO
                ,:NEW.GOODS_QNTY
                ,:NEW.GOODS_WT
                ,:NEW.WEIGHING_DDTT
                ,:NEW.MILL_GP
                ,:NEW.RECEIPT_DATE
                ,:NEW.OTK
                ,:NEW.OTK_DATE
                ,:NEW.INVOICE_NO_SHOP160
                ,:NEW.INVOICE_NO_SHOP750
                ,:NEW.INVOICE_NO
                ,:NEW.SHIPMENT_DATE
                ,:NEW.YARD_GP
                ,:NEW.CUSTOMER_PACKING_NO
                ,'I'
                ,:NEW.REG_DDTT
                ,:NEW.REGISTER
                ,:NEW.MOD_DDTT
                ,:NEW.MODIFIER
                );
END;
/
ALTER TRIGGER "PMES"."TB_PO_MILL_PACKING_RESULT_I" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TB_PO_MILL_PACKING_RESULT_U
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_PO_MILL_PACKING_RESULT_U" 
AFTER UPDATE ON PMES.TB_PO_MILL_PACKING_RESULT 
FOR EACH ROW
BEGIN

         
    INSERT INTO TB_MA_MILL_PACKING_RESULT
              ( MILL_PACKING_SEQ
                ,PROD_YY
                ,PON
                ,PON_SEQ
                ,PACKING_NO
                ,MELT_NO
                ,STLGRADE_CD
                ,PROD_YYMM
                ,ORD_NO
                ,ORD_POSITION
                ,ORD_REM_GP
                ,SECTION_CD
                ,SECTION_TYPE
                ,SECTION_SIZE_T
                ,SECTION_SIZE_W
                ,LEN_FR
                ,LEN_TO
                ,GOODS_QNTY
                ,GOODS_WT
                ,WEIGHING_DDTT
                ,MILL_GP
                ,RECEIPT_DATE
                ,OTK
                ,OTK_DATE
                ,INVOICE_NO_SHOP160
                ,INVOICE_NO_SHOP750
                ,INVOICE_NO
                ,SHIPMENT_DATE
                ,YARD_GP
                ,CUSTOMER_PACKING_NO
                ,NEW_UPDATE_RECORD
                ,REG_DDTT
                ,REGISTER
                ,MOD_DDTT
                ,MODIFIER
               ) 
        VALUES (MILL_PACKING_SEQ.NEXTVAL
                ,:NEW.PROD_YY
                ,:NEW.PON
                ,:NEW.PON_SEQ
                ,:NEW.PACKING_NO
                ,:NEW.MELT_NO
                ,:NEW.STLGRADE_CD
                ,:NEW.PROD_YYMM
                ,:NEW.ORD_NO
                ,:NEW.ORD_POSITION
                ,:NEW.ORD_REM_GP
                ,:NEW.SECTION_CD
                ,:NEW.SECTION_TYPE
                ,:NEW.SECTION_SIZE_T
                ,:NEW.SECTION_SIZE_W
                ,:NEW.LEN_FR
                ,:NEW.LEN_TO
                ,:NEW.GOODS_QNTY
                ,:NEW.GOODS_WT
                ,:NEW.WEIGHING_DDTT
                ,:NEW.MILL_GP
                ,:NEW.RECEIPT_DATE
                ,:NEW.OTK
                ,:NEW.OTK_DATE
                ,:NEW.INVOICE_NO_SHOP160
                ,:NEW.INVOICE_NO_SHOP750
                ,:NEW.INVOICE_NO
                ,:NEW.SHIPMENT_DATE
                ,:NEW.YARD_GP
                ,:NEW.CUSTOMER_PACKING_NO
                ,'U'
                ,:NEW.REG_DDTT
                ,:NEW.REGISTER
                ,:NEW.MOD_DDTT
                ,:NEW.MODIFIER
                );
END;
/
ALTER TRIGGER "PMES"."TB_PO_MILL_PACKING_RESULT_U" ENABLE;
