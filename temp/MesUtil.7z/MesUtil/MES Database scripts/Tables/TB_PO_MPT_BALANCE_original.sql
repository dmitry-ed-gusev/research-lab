--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table TB_PO_MPT_BALANCE
--------------------------------------------------------

  CREATE TABLE "PMES"."TB_PO_MPT_BALANCE" 
   (	"RAW_MATERIAL_CD" VARCHAR2(4 BYTE), 
	"IN_STOCK" VARCHAR2(1 BYTE), 
	"BASKET_QNTY" NUMBER(2,0), 
	"NET_WT" NUMBER(6,0), 
	"REG_DDTT" DATE, 
	"REGISTER" VARCHAR2(15 BYTE), 
	"MOD_DDTT" DATE, 
	"MODIFIER" VARCHAR2(15 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table TB_PO_MPT_BALANCE
--------------------------------------------------------

  ALTER TABLE "PMES"."TB_PO_MPT_BALANCE" MODIFY ("RAW_MATERIAL_CD" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MPT_BALANCE" MODIFY ("IN_STOCK" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MPT_BALANCE" MODIFY ("BASKET_QNTY" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_PO_MPT_BALANCE" MODIFY ("NET_WT" NOT NULL ENABLE);
