--------------------------------------------------------
--  File created - �����-������-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table TB_QM_MELT_STL_GRADE
--------------------------------------------------------

  CREATE TABLE "PMES"."TB_QM_MELT_STL_GRADE" 
   (	"MELT_NO" NUMBER(5,0), 
	"STLGRADE_CD" NUMBER(4,0), 
	"SEQ" NUMBER(3,0), 
	"COMMENTS" VARCHAR2(150 BYTE), 
	"REG_DDTT" DATE, 
	"REGISTER" VARCHAR2(15 BYTE), 
	"MOD_DDTT" DATE, 
	"MODIFIER" VARCHAR2(15 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 196608 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
 

   COMMENT ON COLUMN "PMES"."TB_QM_MELT_STL_GRADE"."MELT_NO" IS 'Melt Number';
 
   COMMENT ON COLUMN "PMES"."TB_QM_MELT_STL_GRADE"."STLGRADE_CD" IS 'Steel Grade Code';
 
   COMMENT ON COLUMN "PMES"."TB_QM_MELT_STL_GRADE"."SEQ" IS 'Sequence';
 
   COMMENT ON COLUMN "PMES"."TB_QM_MELT_STL_GRADE"."COMMENTS" IS 'Comments';
 
   COMMENT ON COLUMN "PMES"."TB_QM_MELT_STL_GRADE"."REG_DDTT" IS 'Registration Date Time';
 
   COMMENT ON COLUMN "PMES"."TB_QM_MELT_STL_GRADE"."REGISTER" IS 'Register';
 
   COMMENT ON COLUMN "PMES"."TB_QM_MELT_STL_GRADE"."MOD_DDTT" IS 'Modification Date Time';
 
   COMMENT ON COLUMN "PMES"."TB_QM_MELT_STL_GRADE"."MODIFIER" IS 'Modifier';
 
   COMMENT ON TABLE "PMES"."TB_QM_MELT_STL_GRADE"  IS 'QM MELT STL GRADE';
--------------------------------------------------------
--  DDL for Index PK_TB_QM_MELT_STL_GRADE
--------------------------------------------------------

  CREATE UNIQUE INDEX "PMES"."PK_TB_QM_MELT_STL_GRADE" ON "PMES"."TB_QM_MELT_STL_GRADE" ("MELT_NO", "STLGRADE_CD") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 196608 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index IE1_TB_QM_MELT_STL_GRADE
--------------------------------------------------------

  CREATE INDEX "PMES"."IE1_TB_QM_MELT_STL_GRADE" ON "PMES"."TB_QM_MELT_STL_GRADE" ("STLGRADE_CD", "MELT_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 196608 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table TB_QM_MELT_STL_GRADE
--------------------------------------------------------

  ALTER TABLE "PMES"."TB_QM_MELT_STL_GRADE" ADD CONSTRAINT "PK_TB_QM_MELT_STL_GRADE" PRIMARY KEY ("MELT_NO", "STLGRADE_CD")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 196608 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "PMES"."TB_QM_MELT_STL_GRADE" MODIFY ("MELT_NO" NOT NULL ENABLE);
 
  ALTER TABLE "PMES"."TB_QM_MELT_STL_GRADE" MODIFY ("STLGRADE_CD" NOT NULL ENABLE);
--------------------------------------------------------
--  DDL for Trigger TB_QM_MELT_STL_GRADE_I
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_QM_MELT_STL_GRADE_I" 
  AFTER INSERT ON PMES.TB_QM_MELT_STL_GRADE
  FOR EACH ROW

BEGIN

    INSERT INTO TB_QM_MELT_STL_GRADE_HIST
               ( MELT_NO
                ,STLGRADE_CD
                ,SEQ
                ,COMMENTS
                ,SQL_TYPE
                ,REGISTER )
        VALUES ( :NEW.MELT_NO
                ,:NEW.STLGRADE_CD
                ,:NEW.SEQ
                ,:NEW.COMMENTS
                ,'INSERT'
                ,:NEW.REGISTER )
    ;

END; 
/
ALTER TRIGGER "PMES"."TB_QM_MELT_STL_GRADE_I" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TB_QM_MELT_STL_GRADE_U
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_QM_MELT_STL_GRADE_U" 
  AFTER UPDATE ON PMES.TB_QM_MELT_STL_GRADE
  FOR EACH ROW

BEGIN

    INSERT INTO TB_QM_MELT_STL_GRADE_HIST
               ( MELT_NO
                ,STLGRADE_CD
                ,SEQ
                ,COMMENTS
                ,SQL_TYPE
                ,REGISTER )
        VALUES ( :NEW.MELT_NO
                ,:NEW.STLGRADE_CD
                ,:NEW.SEQ
                ,:NEW.COMMENTS
                ,'UPDATE'
                ,:NEW.REGISTER )
    ;

END; 
/
ALTER TRIGGER "PMES"."TB_QM_MELT_STL_GRADE_U" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TB_QM_MELT_STL_GRADE_D
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "PMES"."TB_QM_MELT_STL_GRADE_D" 
  AFTER DELETE ON PMES.TB_QM_MELT_STL_GRADE
  FOR EACH ROW

BEGIN

    INSERT INTO TB_QM_MELT_STL_GRADE_HIST
               ( MELT_NO
                ,STLGRADE_CD
                ,SEQ
                ,COMMENTS
                ,SQL_TYPE
                ,REGISTER )
        VALUES ( :OLD.MELT_NO
                ,:OLD.STLGRADE_CD
                ,:OLD.SEQ
                ,:OLD.COMMENTS
                ,'DELETE'
                ,:OLD.REGISTER )
    ;

END; 
/
ALTER TRIGGER "PMES"."TB_QM_MELT_STL_GRADE_D" ENABLE;
