package org.agoncal.book.javaee7.chapter02.ex21;

import java.io.Serializable;

/**
 * @author Antonio Goncalves
 *         APress Book - Beginning Java EE 7 with Glassfish 4
 *         http://www.apress.com/
 *         http://www.antoniogoncalves.org
 *         --
 */
public class CustomerService implements Serializable {

  // ======================================
  // =           Public Methods           =
  // ======================================

  public void createCustomer(Customer customer) {
  }
}