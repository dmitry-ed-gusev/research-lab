/*
 * Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.bdp.ditoolcore.dbfacade;

public enum DbType {
    HIVE,
    ORACLE,
    SQLSERVER,
    TERADATA,
    HANA,
    DB2
}

