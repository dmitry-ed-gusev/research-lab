use norm_docs
go

--insert into dbo.norm_docs_parts(docId, partName) values(1, 'Part 995')
--go
-- update dbo.norm_docs_parts set partName='fff' where id = 1
--go
delete from dbo.docTypes where id = 2
go 

select * from dbo.docTypes
go
select * from dbo.norm_docs
go
select * from dbo.norm_docs_parts
go

use master
go