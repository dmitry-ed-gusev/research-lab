package normDocs.dataModel;

import normDocs.Defaults;
import normDocs.dataModel.dao.ChangesDAO;
import normDocs.dataModel.dao.DocsDAO;
import normDocs.dataModel.dao.DocsPartsDAO;
import normDocs.dataModel.mybatis.dao.DocsTypesBatisDAO;
import normDocs.exceptions.SupidException;
import org.apache.log4j.Logger;


/**
 * @author Gusev Dmitry (����� �������)
 * @version 1.0 (DATE: 07.07.11)
*/

public final class DaoHandler
 {
  private final Logger            logger = Logger.getLogger(Defaults.LOGGER_NAME);
  private final DocsTypesBatisDAO docsTypesBatisDAO;
  private final DocsDAO           docsDAO;
  private final DocsPartsDAO      docsPartsDAO;
  private final ChangesDAO        changesDAO;

  public DaoHandler() throws SupidException
   {
    logger.debug("DaoHandler constructor.");
    this.docsTypesBatisDAO = new DocsTypesBatisDAO();
    logger.debug("DaoHandler constructor. DocsTypes.");
    this.docsDAO           = new DocsDAO();
    logger.debug("DaoHandler constructor. Docs.");
    this.docsPartsDAO      = new DocsPartsDAO();
    logger.debug("DaoHandler constructor. DocsParts.");
    this.changesDAO        = new ChangesDAO();
    logger.debug("DaoHandler constructor. Changes.");
   }

  public DocsTypesBatisDAO getDocsTypesBatisDAO() {
   return docsTypesBatisDAO;
  }

  public DocsDAO getDocsDAO() {
   return docsDAO;
  }

  public DocsPartsDAO getDocsPartsDAO() {
   return docsPartsDAO;
  }

  public ChangesDAO getChangesDAO() {
   return changesDAO;
  }

 }