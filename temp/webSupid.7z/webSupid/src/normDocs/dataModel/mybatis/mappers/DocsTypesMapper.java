package normDocs.dataModel.mybatis.mappers;

import normDocs.dataModel.dto.DocTypeDTO;
import org.apache.ibatis.annotations.Param;

import java.util.ArrayList;

/**
 * @author Gusev Dmitry (����� �������)
 * @version 1.0 (DATE: 04.07.11)
 */
public interface DocsTypesMapper
 {
  DocTypeDTO            findDocType(@Param("id") int id, @Param("active") boolean active);
  ArrayList<DocTypeDTO> findAllDocTypes(@Param("active") boolean active);
  void                  insertDocType(DocTypeDTO docType);
  void                  updateDocType(DocTypeDTO docType);
 }
