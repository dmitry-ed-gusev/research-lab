package normDocs.dataModel.mybatis.dao;

import normDocs.Defaults;
import normDocs.dataModel.dto.DocTypeDTO;
import normDocs.dataModel.mybatis.mappers.DocsTypesMapper;
import normDocs.exceptions.SupidException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import java.util.ArrayList;

/**
 * @author Gusev Dmitry (����� �������)
 * @version 1.0 (DATE: 05.07.11)
 */
public final class DocsTypesBatisDAO extends AbstractBatisDAO
 {
  private Logger logger = Logger.getLogger(Defaults.LOGGER_NAME);

  public DocsTypesBatisDAO() throws SupidException {}

  /***/
  public ArrayList<DocTypeDTO> findAll(boolean active)
   {
    logger.debug("DocsTypesBatisDAO: findAllPartsForDoc().");
    ArrayList<DocTypeDTO> list = null;
    SqlSession session = null;
    try
     {
      session = this.getSqlSession();
      DocsTypesMapper mapper = session.getMapper(DocsTypesMapper.class);
      list = mapper.findAllDocTypes(active);
     }
    catch (SupidException e) {logger.error(e.getMessage());}
    finally {if (session != null) {session.close();}}
    return list;
   }

  /***/
  public DocTypeDTO findById(int id, boolean active)
   {
    logger.debug("DocsTypesBatisDAO: findById().");
    DocTypeDTO doc = null;
    SqlSession session = null;
    try
     {
      session = this.getSqlSession();
      DocsTypesMapper mapper = session.getMapper(DocsTypesMapper.class);
      doc = mapper.findDocType(id, active);
     }
    catch (SupidException e) {logger.error(e.getMessage());}
    finally {if (session != null) {session.close();}}
    return doc;
   }

  /***/
  public void change(DocTypeDTO docType)
   {
    logger.debug("DocsTypesBatisDAO: change().");
    SqlSession session = null;
    try
     {
      if (docType != null)
       {
        session = this.getSqlSession();
        DocsTypesMapper mapper = session.getMapper(DocsTypesMapper.class);
        if (docType.getId() > 0)
         {
          logger.debug("Executing update for doc type.");
          mapper.updateDocType(docType);
         }
        else
         {
          logger.debug("Executing insert for doc type.");
          mapper.insertDocType(docType);
         }
        // ������ �������. ���� �� ������� �������� ���� boolean ������ true � ������ ������
        // SqlSession openSession(boolean autoCommit), �� ������ ����� ��������������!
        //session.commit();
       }
      else {logger.warn("Doc type is NULL! Can't process!");}
     }
    catch (SupidException e) {logger.error(e.getMessage());}
    finally {if (session != null) {session.close();}}
   }

 }