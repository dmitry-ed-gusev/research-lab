package normDocs.struts.forms;

import org.apache.struts.action.ActionForm;
import java.util.List;

/**
 * ����� ��������� ��� (bean) ��� �������� ��������� ����������� � �����-���� ����� ���������.
 * @author Gusev Dmitry
 * @version 2.0 (DATE: 12.07.2011)
*/

public class ViewOffersForm extends ActionForm
 {
  private String  action;
  private int     typeId;
  private int     docId;
  private int     partId;
  private String  docName;
  private String  docNumber;
  private String  partName;
  private boolean archive;
  private List    offersList;
  private int     changeId;

  public String getAction() {
   return action;
  }

  public void setAction(String action) {
   this.action = action;
  }

  public String getPartName() {
   return partName;
  }

  public void setPartName(String partName) {
   this.partName = partName;
  }

  public String getDocName() {
   return docName;
  }

  public void setDocName(String docName) {
   this.docName = docName;
  }

  public String getDocNumber() {
   return docNumber;
  }

  public void setDocNumber(String docNumber) {
   this.docNumber = docNumber;
  }

  public boolean isArchive() {
   return archive;
  }

  public void setArchive(boolean archive) {
   this.archive = archive;
  }

  public List getOffersList() {
   return offersList;
  }

  public void setOffersList(List offersList) {
   this.offersList = offersList;
  }

  public int getTypeId() {
   return typeId;
  }

  public void setTypeId(int typeId) {
   this.typeId = typeId;
  }

  public int getDocId() {
   return docId;
  }

  public void setDocId(int docId) {
   this.docId = docId;
  }

  public int getPartId() {
   return partId;
  }

  public void setPartId(int partId) {
   this.partId = partId;
  }

  public int getChangeId() {
   return changeId;
  }

  public void setChangeId(int changeId) {
   this.changeId = changeId;
  }

 }