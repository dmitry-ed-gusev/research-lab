package normDocs.struts.forms;

import org.apache.struts.action.ActionForm;

/**
 * @author Gusev Dmitry (����� �������)
 * @version 1.0 (DATE: 12.07.11)
*/

public class DownloadForm extends ActionForm
 {
  private int changeId;

  public int getChangeId() {
   return changeId;
  }

  public void setChangeId(int changeId) {
   this.changeId = changeId;
  }

 }