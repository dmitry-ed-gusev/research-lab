package normDocs.struts.forms;

import normDocs.dataModel.dto.DocPartDTO;
import org.apache.struts.action.ActionForm;

import java.util.List;

/**
 * ����� ��������� ����� ��� ������ �� ������� ������/���� ���������.
 * @author Gusev Dmitry
 * @version 1.0
*/

public class ViewPartsForm extends ActionForm
 {
  private int     typeId;
  private int     docId;
  private String  name;
  private String  number;
  private boolean archive;
  private List<DocPartDTO> partsList;

  public String getName() {
   return name;
  }

  public void setName(String name) {
   this.name = name;
  }

  public String getNumber() {
   return number;
  }

  public void setNumber(String number) {
   this.number = number;
  }

  public boolean isArchive() {
   return archive;
  }

  public void setArchive(boolean archive) {
   this.archive = archive;
  }

  public List<DocPartDTO> getPartsList() {
   return partsList;
  }

  public void setPartsList(List<DocPartDTO> partsList) {
   this.partsList = partsList;
  }

  public int getTypeId() {
   return typeId;
  }

  public void setTypeId(int typeId) {
   this.typeId = typeId;
  }

  public int getDocId() {
   return docId;
  }

  public void setDocId(int docId) {
   this.docId = docId;
  }

 }