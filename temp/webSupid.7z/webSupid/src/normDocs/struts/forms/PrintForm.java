package normDocs.struts.forms;

import org.apache.struts.action.ActionForm;

/**
 * ������ ����� ��������� ����� ��� �������� ������ �������� �����.
 * @author Gusev Dmitry
 * @version 1.0
*/

public class PrintForm extends ActionForm
 {
  private int    changeId;
  private String name;
  private String number;
  private String partName;
  private String sourceDate;
  private String source;
  private String text;
  private String conclusionDate;
  private String conclusion;
  private String answerDate;
  private String answer;
  private String fileName;

  public int getChangeId() {
   return changeId;
  }

  public void setChangeId(int changeId) {
   this.changeId = changeId;
  }

  public String getName() {
   return name;
  }

  public void setName(String name) {
   this.name = name;
  }

  public String getNumber() {
   return number;
  }

  public void setNumber(String number) {
   this.number = number;
  }

  public String getPartName() {
   return partName;
  }

  public void setPartName(String partName) {
   this.partName = partName;
  }

  public String getSourceDate() {
   return sourceDate;
  }

  public void setSourceDate(String sourceDate) {
   this.sourceDate = sourceDate;
  }

  public String getSource() {
   return source;
  }

  public void setSource(String source) {
   this.source = source;
  }

  public String getText() {
   return text;
  }

  public void setText(String text) {
   this.text = text;
  }

  public String getConclusionDate() {
   return conclusionDate;
  }

  public void setConclusionDate(String conclusionDate) {
   this.conclusionDate = conclusionDate;
  }

  public String getConclusion() {
   return conclusion;
  }

  public void setConclusion(String conclusion) {
   this.conclusion = conclusion;
  }

  public String getAnswerDate() {
   return answerDate;
  }

  public void setAnswerDate(String answerDate) {
   this.answerDate = answerDate;
  }

  public String getAnswer() {
   return answer;
  }

  public void setAnswer(String answer) {
   this.answer = answer;
  }

  public String getFileName() {
   return fileName;
  }

  public void setFileName(String fileName) {
   this.fileName = fileName;
  }

 }