package normDocs.exceptions;

/**
 * @author Gusev Dmitry (����� �������)
 * @version 1.0 (DATE: 30.06.11)
*/

public class SupidException extends Exception
 {
  public SupidException(String s)            {super(s);}
  public SupidException(Throwable throwable) {super(throwable);}
 }