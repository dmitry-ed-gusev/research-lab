package vg;

/**
 * Default for graphics signs/figures.
 *
 * @author Gusev Dmitry
 */

public interface SignDefaults {

    /**
     * Military area type.
     */
    enum MilitaryAreaType {
        POSITION_AREA, // positioning area
        BASE_AREA      // base area
    }

    /**
     * Date/times modes for attributes.
     */
    enum TimeMode {
        DATE,      // Date
        TIME,      // Time
        DATE_TIME  // Date+Time
    }

    /**
     * Состояние объекта.
     *
     */
    public enum State {

        /**
         * Объект в работоспособном состоянии.
         */
        ENABLED("01", "Объект в работоспособном состоянии"),
        /**
         * Повреждённый объект (аварийный, неисправный).
         */
        DAMAGED("02", "Повреждённый объект (аварийный, неисправный)"),
        /**
         * Уничтоженный объект (разрушенный, подорванный).
         */
        DESTROYED("03", "Уничтоженный объект (разрушенный, подорванный)"),
        /**
         * Неработоспособное состояние с указанием причины.
         */
        DISABLE("04", "Неработоспособное состояние с указанием причины");

        /**
         * Код доп. признака из БЭУЗ.
         */
        public static final String attribute = "1500";
        /**
         * Код значения доп. признака из БЭУЗ.
         */
        public final String value;
        /**
         * Числовое значение кода значения доп. признака.
         */
        public final int intValue;
        /**
         * Имя.
         */
        private String name;

        /**
         * @param value Код.
         * @param name  Имя.
         */
        private State(String value, String name) {
            this.value = value;
            if (value != null) {
                int intValue;
                try {
                    intValue = Integer.parseInt(value, 10);
                } catch (NumberFormatException e) {
                    intValue = 0;
                }
                this.intValue = intValue;
            } else {
                this.intValue = 0;
            }
            this.name = name;
        }

        /**
         * Получить признак состояния по коду доп. признака.
         *
         * @param code Код доп. признака.
         * @return Признак состояния.
         */
        public static State get(String code) {
            for (State v : values()) {
                if (v.value.equals(code)) {
                    return v;
                }
            }
            return null;
        }

        /**
         * Получить признак состояния по коду доп. признака.
         *
         * @param intValue Числовое значение кода значения доп. признака.
         * @return Признак состояния.
         */
        public static State get(int intValue) {
            for (State v : values()) {
                if (v.intValue == intValue) {
                    return v;
                }
            }
            return null;
        }

        /**
         * Получить имя.
         *
         * @return Имя.
         */
        public String getName() {
            return name;
        }

        /**
         * Получить код.
         *
         * @return Код.
         */
        public String getCode() {
            return value;
        }

    }

    /**
     * Госпринадлежность.
     *
     */
    public enum Country {

        /**
         * Не установлена.
         */
        UNKNOW("00", 0x00000000, "Не установлена"),
        /**
         * Свои.
         */
        OWN("01", 0xFFFF0000, "Свои"),
        /**
         * Противник.
         */
        ENEMY("02", 0xFF0000FF, "Противник"),
        /**
         * Союзник.
         */
        ALLY("03", 0xFF00FF00, "Союзник"),
        /**
         * Нейтрал.
         */
        NEUTRAL("04", 0xFFFF00FF, "Нейтрал"),
        /**
         * Принадлежность по названию страны.
         */
        BYCOUNTRY("05", 0x00000000, "Принадлежность по названию страны"),
        /**
         * Международный.
         */
        INTERNATIONAL("06", 0x00000000, "Международный");

        /**
         * Код доп. признака из БЭУЗ.
         */
        public static final String attribute = "1100";
        /**
         * Код значения доп. признака из БЭУЗ.
         */
        public final String value;
        /**
         * Числовое значение кода значения доп. признака.
         */
        public final int intValue;
        /**
         * Цвет, соответствующий госпринадлежности.
         */
        public final int color;
        /**
         * Имя.
         */
        private String name;

        /**
         * @param value Код.
         * @param color Цвет.
         * @param name  Имя.
         */
        private Country(String value, int color, String name) {
            this.value = value;
            if (value != null) {
                int intValue;
                try {
                    intValue = Integer.parseInt(value, 10);
                } catch (NumberFormatException e) {
                    intValue = 0;
                }
                this.intValue = intValue;
            } else {
                this.intValue = 0;
            }
            this.color = color;
            this.name = name;
        }

        /**
         * Получить госпринадлежность по коду доп. признака.
         *
         * @param code Код доп. признака.
         * @return Госпринадлежность.
         */
        public static Country get(String code) {
            for (Country v : values())
                if (v.value.equals(code))
                    return v;
            return null;
        }

        /**
         * Получить признак состояния по коду доп. признака.
         *
         * @param intValue Числовое значение кода значения доп. признака.
         * @return Признак состояния.
         */
        public static Country get(int intValue) {
            for (Country v : values())
                if (v.intValue == intValue)
                    return v;
            return null;
        }

        /**
         * Получить имя.
         *
         * @return Имя.
         */
        public String getName() {
            return name;
        }

    }

    /**
     * Признак действия.
     *
     */
    public enum Action {

        /**
         * Фактическое.
         */
        FACTUAL("01", "Фактическое (реальное) действие"),
        /**
         * Планируемое (предполагаемое).
         */
        PLANED("02", "Планируемое или предполагаемое действие");

        /**
         * Код доп. признака из БЭУЗ.
         */
        public static final String attribute = "1200";
        /**
         * Код значения доп. признака из БЭУЗ.
         */
        public final String value;
        /**
         * Числовое значение кода значения доп. признака.
         */
        public final int intValue;
        /**
         * Имя.
         */
        private String name;

        /**
         * @param value Код.
         * @param name  Имя.
         */
        private Action(String value, String name) {
            this.value = value;
            if (value != null) {
                int intValue;
                try {
                    intValue = Integer.parseInt(value, 10);
                } catch (NumberFormatException e) {
                    intValue = 0;
                }
                this.intValue = intValue;
            } else {
                this.intValue = 0;
            }
            this.name = name;
        }

        /**
         * Получить характер действия по коду доп. признака.
         *
         * @param code Код доп. признака.
         * @return Характер действия.
         */
        public static Action get(String code) {
            for (Action v : values())
                if (v.value.equals(code))
                    return v;
            return null;
        }

        /**
         * Получить признак состояния по коду доп. признака.
         *
         * @param intValue Числовое значение кода значения доп. признака.
         * @return Признак состояния.
         */
        public static Action get(int intValue) {
            for (Action v : values())
                if (v.intValue == intValue)
                    return v;
            return null;
        }

        /**
         * Получить имя.
         *
         * @return Имя.
         */
        public String getName() {
            return name;
        }

    }

    /**
     * Рабочий режим выравнивателя.
     *
     */
    public enum AlignMode {
        /**
         * Размещение.
         */
        PLACE,
        /**
         * Выравнивание.
         */
        ALIGN
    }

    /**
     * Тип части круга/окружности.
     *
     */
    public enum CirclePartType {

        /**
         * Дуга.
         */
        ARC,
        /**
         * Сектор.
         */
        SECTOR,
        /**
         * Сегмент.
         */
        SEGMENT

    }

    /**
     * Фигура, по которой наносится знак.
     *
     */
    public static enum PlacingFigure {

        /**
         * Свободная.
         */
        FREE("Свободная"),
        /**
         * Полилиния.
         */
        POLYLINE("Разомкнутая полилиния"),
        /**
         * Сплайн.
         */
        SPLINE("Разомкнутый сплайн"),
        /**
         * Замкнутая полилиния.
         */
        CLOSED_POLYLINE("Замкнутая полилиния"),
        /**
         * Замкнутый сплайн.
         */
        CLOSED_SPLINE("Замкнутый сплайн"),
        /**
         * Треугольник.
         */
        TRIANGLE("Треугольник"),
        /**
         * Четырёхугольник.
         */
        QUADRANGLE("Четырёхугольник"),
        /**
         * Сектор окружности.
         */
        ELLIPSE_SECTOR("Сектор окружности"),
        /**
         * Дуга окружности.
         */
        ELLIPSE_ARC("Дуга окружности"),
        /**
         * Сегмент окружности.
         */
        ELLIPSE_SEGMENT("Сегмент окружности");

        /**
         * Строковый эквивалент значения.
         */
        private String equivalent;


        /**
         * @param s Строковый эквивалет.
         */
        private PlacingFigure(String s) {
            this.equivalent = s;
        }


        /**
         * Получить строковый эквивалент.
         *
         * @return Строковый эквивалент.
         */
        public String getEquivalent() {
            return equivalent;
        }

        /**
         * Получить фигуру по эквиваленту.
         *
         * @param s Строковый эквивалент.
         * @return Фигура.
         */
        public static PlacingFigure getByEquivalent(String s) {
            if (s.equals(SPLINE.getEquivalent())) {
                return SPLINE;
            } else if (s.equals(POLYLINE.getEquivalent())) {
                return POLYLINE;
            } else if (s.equals(FREE.getEquivalent())) {
                return FREE;
            } else if (s.equals(CLOSED_POLYLINE.getEquivalent())) {
                return CLOSED_POLYLINE;
            } else if (s.equals(CLOSED_SPLINE.getEquivalent())) {
                return CLOSED_SPLINE;
            } else if (s.equals(TRIANGLE.getEquivalent())) {
                return TRIANGLE;
            } else if (s.equals(QUADRANGLE.getEquivalent())) {
                return QUADRANGLE;
            } else if (s.equals(ELLIPSE_SECTOR.getEquivalent())) {
                return ELLIPSE_SECTOR;
            } else if (s.equals(ELLIPSE_ARC.getEquivalent())) {
                return ELLIPSE_ARC;
            } else if (s.equals(ELLIPSE_SEGMENT.getEquivalent())) {
                return ELLIPSE_SEGMENT;
            }
            return null;
        }

    }

}