package vg.sign.visual.signs;

import vg.geometry.cp.*;
import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.visual.api.IAnchorPoint;
import vg.sign.visual.api.IGraphElement;
import vg.sign.visual.tools.AbstractSignVisual;
import vg.sign.visual.tools.AnchorPointsList;
import vg.sign.visual.tools.RootGraphElement;
import vg.utils.ListReference;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


/**
 * Визуальное представление точечного знака.
 *
 */
public class PointSignVisual extends AbstractSignVisual {

    /**
     * Абстрактная предопределённая точка.
     *
     */
    public static abstract class AbstractPredefinedPoint implements CPoint {

        /***/
        private static final long serialVersionUID = 4473782342720400390L;

        /**
         * Редактируемость.
         */
        protected boolean editable;
        /**
         * Расчётная точка, реализующая математику.
         */
        protected CPoint point;

        /**
         * @param editable Редактируемость.
         * @param point    Расчётная точка, реализующая математику.
         */
        public AbstractPredefinedPoint(boolean editable, CPoint point) {
            this.editable = editable;
            this.point = point;
        }


        @Override
        public PointSignVisual.AbstractPredefinedPoint clone() {
            throw new UnsupportedOperationException("Predefined points cloning is forbidden.");
        }

        public abstract AbstractPredefinedPoint clone(PointSignVisual parent);

        /**
         * Получить редактируемость точки.
         *
         * @return Sergei Tumanov
         */
        public boolean isEditable() {
            return editable;
        }

        /**
         * Задать редактируемость точки.
         *
         * @param editable Sergei Tumanov
         */
        public void setEditable(boolean editable) {
            this.editable = editable;
        }


        @Override
        public double getX() {
            return point.getX();
        }

        @Override
        public void setX(double x) {
            point.setX(x);
        }

        @Override
        public double getY() {
            return point.getY();
        }

        @Override
        public void setY(double y) {
            point.setY(y);
        }

        @Override
        public CPoint calculate() {
            return point.calculate();
        }

        @Override
        public CPoint decalculate() {
            return point.decalculate();
        }

        @Override
        public Set<CPoint> getDependencies() {
            return point.getDependencies();
        }

        @Override
        public boolean equals(BasePoint2D p) {
            return point.equals(p);
        }

    }

    /**
     * Абсолютная предопределённая точка.
     *
     */
    public static class AbsolutePredefinedPoint extends AbstractPredefinedPoint {

        /***/
        private static final long serialVersionUID = 2745794748962375329L;

        /**
         * @param editable Редактируемость.
         * @param x        Координата x в с.к. знака.
         * @param y        Координата y в с.к. знака.
         */
        public AbsolutePredefinedPoint(boolean editable, double x, double y) {
            super(editable, new AbsoluteCPoint(x, y));
        }

        @Override
        public AbsolutePredefinedPoint clone(PointSignVisual parent) {
            return new AbsolutePredefinedPoint(editable, getX(), getY());
        }

        @Override
        public String toString() {
            return String.format("AbsolutePP {(%f, %f)}", getX(), getY());
        }

    }

    /**
     * Смещённая предопределённая точка.
     * Располагается со смещением относительно другой точки.
     *
     */
    public class DisplacementPredefinedPoint extends AbstractPredefinedPoint {

        /***/
        private static final long serialVersionUID = -5093005845459717048L;

        /**
         * @param editable Редактируемость.
         * @param ppIndex  Индекс предопределённой точки.
         * @param dx       Смещение по X.
         * @param dy       Смещение по Y.
         */
        public DisplacementPredefinedPoint(boolean editable, int ppIndex, double dx, double dy) {
            super(editable, new DisplacementCPoint(
                    new ListCPointReference(predefinedPoints, ppIndex), dx, dy));
            this.editable = editable;
        }

        @Override
        public DisplacementPredefinedPoint clone(PointSignVisual parent) {
            DisplacementPredefinedPoint clonedObject = ((PointSignVisual) parent).new DisplacementPredefinedPoint(
                    editable, getPredefinedPointIndex(), getD().getX(), getD().getY());
            clonedObject.setX(getX());
            clonedObject.setY(getY());
            return clonedObject;
        }

        @Override
        public String toString() {
            int ppIndex = getPredefinedPointIndex();
            CPoint cp = predefinedPoints.get(ppIndex);
            BasePoint2D p = new BasePoint2D(cp.getX(), cp.getY());
            return String.format("DisplacementPP {(%f, %f), p[%d]: (%.3f; %.3f), d: %s}",
                    getX(), getY(),
                    ppIndex, p.getX(), p.getY(),
                    getD());
        }

        @Override
        public boolean isEditable() {
            return editable;
        }

        @Override
        public void setEditable(boolean editable) {
            this.editable = editable;
        }

        /**
         * Получить индекс предопределённой точки отсчёта.
         *
         * @return Индекс предопределённой точки отсчёта.
         */
        public int getPredefinedPointIndex() {
            return ((ListCPointReference) ((DisplacementCPoint) point).getP0()).getIndex();
        }

        /**
         * Задать индекс предопределённой точки отсчёта.
         *
         * @param ppIndex Индекс предопределённой точки отсчёта.
         */
        public void setPredefinedPointIndex(int ppIndex) {
            ((ListCPointReference) ((DisplacementCPoint) point).getP0()).setIndex(ppIndex);
        }

        /**
         * Получить смещение.
         *
         * @return Смещение.
         */
        public BasePoint2D getD() {
            return ((DisplacementCPoint) point).getD();
        }

        /**
         * Задать смещение.
         *
         * @param d Смещение.
         */
        public void setD(BasePoint2D d) {
            ((DisplacementCPoint) point).setD(d);
        }

    }

    /**
     * Относительная предопределённая точка.
     * Располагается на линии между двумя другими точками.
     *
     */
    public class RelativePredefinedPoint extends AbstractPredefinedPoint {

        /***/
        private static final long serialVersionUID = -4824972498378802054L;

        /**
         * @param editable Редактируемость.
         * @param ppIndex1 Индекс первой предопределённой точки.
         * @param ppIndex2 Индекс второй предопределённой точки.
         * @param t        Коэффициент положения точки.
         */
        public RelativePredefinedPoint(boolean editable, int ppIndex1, int ppIndex2, double t) {
            super(editable, new RelativeCPoint(
                    new ListCPointReference(predefinedPoints, ppIndex1),
                    new ListCPointReference(predefinedPoints, ppIndex2),
                    t));
            this.editable = editable;
        }

        @Override
        public RelativePredefinedPoint clone(PointSignVisual parent) {
            RelativePredefinedPoint clonedObject = ((PointSignVisual) parent).new RelativePredefinedPoint(
                    editable, getPredefinedPointIndex1(), getPredefinedPointIndex2(), getT());
            clonedObject.setX(getX());
            clonedObject.setY(getY());
            return clonedObject;
        }

        @Override
        public String toString() {
            int ppIndex1 = getPredefinedPointIndex1();
            int ppIndex2 = getPredefinedPointIndex2();

            CPoint cp1 = predefinedPoints.get(ppIndex1);
            CPoint cp2 = predefinedPoints.get(ppIndex2);
            BasePoint2D p1 = new BasePoint2D(cp1.getX(), cp1.getY());
            BasePoint2D p2 = new BasePoint2D(cp2.getX(), cp2.getY());

            return String.format("RelativePP {(%f, %f), p[%d]: (%.3f; %.3f), p[%d]: (%.3f; %.3f), t: %.3f}",
                    getX(), getY(),
                    ppIndex1, p1.getX(), p1.getY(),
                    ppIndex2, p2.getX(), p2.getY(),
                    getT());
        }

        @Override
        public boolean isEditable() {
            return editable;
        }

        @Override
        public void setEditable(boolean editable) {
            this.editable = editable;
        }

        /**
         * Получить индекс первой предопределённой точки отсчёта.
         *
         * @return Индекс первой предопределённой точки отсчёта.
         */
        public int getPredefinedPointIndex1() {
            return ((ListCPointReference) ((RelativeCPoint) point).getP0()).getIndex();
        }

        /**
         * Задать индекс первой предопределённой точки отсчёта.
         *
         * @param ppIndex1 Индекс первой предопределённой точки отсчёта.
         */
        public void setPredefinedPointIndex1(int ppIndex1) {
            ((ListCPointReference) ((RelativeCPoint) point).getP0()).setIndex(ppIndex1);
        }

        /**
         * Получить индекс второй предопределённой точки отсчёта.
         *
         * @return Индекс второй предопределённой точки отсчёта.
         */
        public int getPredefinedPointIndex2() {
            return ((ListCPointReference) ((RelativeCPoint) point).getP1()).getIndex();
        }

        /**
         * Задать индекс второй предопределённой точки отсчёта.
         *
         * @param ppIndex2 Индекс второй предопределённой точки отсчёта.
         */
        public void setPredefinedPointIndex2(int ppIndex2) {
            ((ListCPointReference) ((RelativeCPoint) point).getP1()).setIndex(ppIndex2);
        }

        /**
         * Получить относительное смещение точки.
         *
         * @return Относительное смещение точки.
         */
        public double getT() {
            return ((RelativeCPoint) point).getT();
        }

        /**
         * Задать относительное смещение точки.
         *
         * @param t Относительное смещение точки.
         */
        public void setT(double t) {
            ((RelativeCPoint) point).setT(t);
        }

    }

    /**
     * Относительная предопределённая точка. Раздельная по X и Y относительная предопределённая точка.
     * Располагается на линии между двумя другими точками.
     *
     */
    public class XYRelativePredefinedPoint extends AbstractPredefinedPoint {

        /***/
        private static final long serialVersionUID = 6360341414029352304L;

        /**
         * @param editable Редактируемость.
         * @param ppIndex1 Индекс первой предопределённой точки.
         * @param ppIndex2 Индекс второй предопределённой точки.
         * @param tx       Коэффициент положения точки по X.
         * @param ty       Коэффициент положения точки по Y.
         */
        public XYRelativePredefinedPoint(boolean editable, int ppIndex1, int ppIndex2, double tx, double ty) {
            super(editable, new XYRelativeCPoint(
                    new ListCPointReference(predefinedPoints, ppIndex1),
                    new ListCPointReference(predefinedPoints, ppIndex2),
                    tx, ty));
            this.editable = editable;
        }

        @Override
        public XYRelativePredefinedPoint clone(PointSignVisual parent) {
            XYRelativePredefinedPoint clonedObject = ((PointSignVisual) parent).new XYRelativePredefinedPoint(
                    editable, getPredefinedPointIndex1(), getPredefinedPointIndex2(), getT().getX(), getT().getY());
            clonedObject.setX(getX());
            clonedObject.setY(getY());
            return clonedObject;
        }

        @Override
        public String toString() {
            int ppIndex1 = getPredefinedPointIndex1();
            int ppIndex2 = getPredefinedPointIndex2();

            CPoint cp1 = predefinedPoints.get(ppIndex1);
            CPoint cp2 = predefinedPoints.get(ppIndex2);
            BasePoint2D p1 = new BasePoint2D(cp1.getX(), cp1.getY());
            BasePoint2D p2 = new BasePoint2D(cp2.getX(), cp2.getY());
            return String.format("XYRelativePP {(%f, %f), p[%d]: (%.3f; %.3f), p[%d]: (%.3f; %.3f), t: %s}",
                    getX(), getY(),
                    ppIndex1, p1.getX(), p1.getY(),
                    ppIndex2, p2.getX(), p2.getY(),
                    getT());
        }

        @Override
        public boolean isEditable() {
            return editable;
        }

        @Override
        public void setEditable(boolean editable) {
            this.editable = editable;
        }

        /**
         * Получить индекс первой предопределённой точки отсчёта.
         *
         * @return Индекс первой предопределённой точки отсчёта.
         */
        public int getPredefinedPointIndex1() {
            return ((ListCPointReference) ((XYRelativeCPoint) point).getP0()).getIndex();
        }

        /**
         * Задать индекс первой предопределённой точки отсчёта.
         *
         * @param ppIndex1 Индекс первой предопределённой точки отсчёта.
         */
        public void setPredefinedPointIndex1(int ppIndex1) {
            ((ListCPointReference) ((XYRelativeCPoint) point).getP0()).setIndex(ppIndex1);
        }

        /**
         * Получить индекс второй предопределённой точки отсчёта.
         *
         * @return Индекс второй предопределённой точки отсчёта.
         */
        public int getPredefinedPointIndex2() {
            return ((ListCPointReference) ((XYRelativeCPoint) point).getP1()).getIndex();
        }

        /**
         * Задать индекс второй предопределённой точки отсчёта.
         *
         * @param ppIndex2 Индекс второй предопределённой точки отсчёта.
         */
        public void setPredefinedPointIndex2(int ppIndex2) {
            ((ListCPointReference) ((XYRelativeCPoint) point).getP1()).setIndex(ppIndex2);
        }

        /**
         * Получить относительное смещение точки.
         *
         * @return Относительное смещение точки.
         */
        public BasePoint2D getT() {
            return ((XYRelativeCPoint) point).getT();
        }

        /**
         * Задать относительное смещение точки.
         *
         * @param t Относительное смещение точки.
         */
        public void setT(BasePoint2D t) {
            ((XYRelativeCPoint) point).setT(t);
        }

    }


    /**
     * Коннекторы графических элементов.
     */
    protected List<IGraphElement> graphElements = new ArrayList<IGraphElement>();
    /**
     * Список предопределённых точек.
     */
    protected List<AbstractPredefinedPoint> predefinedPoints = new ArrayList<AbstractPredefinedPoint>();
    /**
     * Список индексов предопределённых точек, на которые натягиваются графические элементы.
     */
    protected List<List<Integer>> predefinedPointIndices = new ArrayList<List<Integer>>();


    /***/
    public PointSignVisual() {
        anchorPoints = new AnchorPointsList(1, 1);
        rootGraphElement = new RootGraphElement(
                "Точечный ЭУЗ",
                this,
                new ListReference<IGraphElement>(graphElements, false));
    }


    @Override
    public PointSignVisual clone() {
        PointSignVisual clonedObject = (PointSignVisual) super.clone();

        clonedObject.graphElements = new ArrayList<IGraphElement>();
        for (IGraphElement ge : graphElements)
            clonedObject.graphElements.add(ge.clone());

        clonedObject.predefinedPoints = new ArrayList<AbstractPredefinedPoint>();
        for (AbstractPredefinedPoint pp : predefinedPoints)
            clonedObject.predefinedPoints.add(pp.clone(clonedObject));

        clonedObject.predefinedPointIndices = new ArrayList<List<Integer>>();
        for (List<Integer> ppi : predefinedPointIndices)
            clonedObject.predefinedPointIndices.add(new ArrayList<Integer>(ppi));

        clonedObject.rootGraphElement = new RootGraphElement(
                "Точечный ЭУЗ",
                clonedObject,
                new ListReference<IGraphElement>(clonedObject.graphElements, false));

        return clonedObject;
    }

    /**
     * Получить список графических элементов.
     *
     * @return Список графических элементов.
     */
    public List<IGraphElement> getGraphElements() {
        return graphElements;
    }

    /**
     * Получить список предопределённых точек.
     *
     * @return Список предопределённых точек.
     */
    public List<AbstractPredefinedPoint> getPredefinedPoints() {
        return predefinedPoints;
    }

    /**
     * Получить список индексов предопределённых точек, на которые натягиваются графические элементы.
     *
     * @return Список индексов предопределённых точек, на которые натягиваются графические элементы.
     */
    public List<List<Integer>> getPredefinedPointIndices() {
        return predefinedPointIndices;
    }

    /**
     * Получить матрицу преобразования предопределённых точек в контрольные.
     * <p>Другими словами, преобразования из с.к. точечного знака в с.к. документа.
     *
     * @return Матрица преобразования предопределённых точек в контрольные.
     */
    public BaseMatrix2D getToDocumentMatrix() {
        BasePoint2D anchorPoint =
                !anchorPoints.isEmpty() ?
                        anchorPoints.get(0).getPoint() :
                        new BasePoint2D(0.0, 0.0);
        return new BaseMatrix2D()
                // Ось Y знака направлена вверх, а ось Y холста - вниз; Учитываем это:
                .scale(1.0, -1.0, 0, 0)
                // Трансформации знака:
                .scale(scale.getX(), scale.getY(), 0, 0)
                .rotate(angle, 0, 0)
                // Перемещение к точке привязки:
                .translate(anchorPoint);
    }

    @Override
    public void createDefaultSemantics(int index, IAnchorPoint anchorPoint) {
    }

    /**
     * Обновление индексов предопределенных точек у графических элементов и у зависимых точек после добавления предопределенной точки.
     *
     * @param index Индекс добавленной предопределенной точки.
     * @throws RuntimeException Удалена точка от которой зависят другие.
     */
    public void updatePredefinedPointsAfterAdd(int index) {
        updatePredefinedPoints(0, index);
    }

    /**
     * Обновление индексов предопределенных точек у графических элементов и у зависимых точек после удаления предопределенной точки.
     *
     * @param index Индекс удаленной предопределенной точки.
     */
    public void updatePredefinedPointsAfterRemove(int index) {
        updatePredefinedPoints(1, index);
    }

    /**
     * Обновление предопределенных точек после удаления или добавления точки.
     *
     * @param operation Тип операции: 0 - добавление точки, 1- удаление точки.
     * @param index     Индекс точки.
     */
    protected void updatePredefinedPoints(int operation, int index) {
        List<List<Integer>> indices = getPredefinedPointIndices();
        for (Iterator<List<Integer>> graphElementIt = indices.iterator(); graphElementIt.hasNext(); ) {
            List<Integer> graphElementIndices = graphElementIt.next();
            for (int i = 0; i < graphElementIndices.size(); i++) {
                int curIndex = graphElementIndices.get(i);
                if (curIndex == index) {
                    graphElementIndices.remove(i);
                    i = -1;
                } else {
                    curIndex = updateIndex(curIndex, index, operation);
                    if (curIndex < 0 && curIndex >= graphElementIndices.size())
                        new RuntimeException("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    graphElementIndices.set(i, curIndex);
                }
                if (graphElementIndices.size() <= 1) {
                    int graphElementIndex = indices.indexOf(graphElementIndices);
                    graphElements.remove(graphElementIndex);
                    graphElementIt.remove();
                    i = 0;
                    break;
                }
            }
        }

        for (AbstractPredefinedPoint predefinedPoint : getPredefinedPoints()) {
            if (predefinedPoint instanceof RelativePredefinedPoint) {
                RelativePredefinedPoint relativePredefinedPoint = (RelativePredefinedPoint) predefinedPoint;
                int i1 = relativePredefinedPoint.getPredefinedPointIndex1();
                int i2 = relativePredefinedPoint.getPredefinedPointIndex2();
                if (operation == 1 && (i1 == index || i2 == index))
                    new RuntimeException("Удалена точка от которой засивят другие точки.");
                relativePredefinedPoint.setPredefinedPointIndex1(updateIndex(i1, index, operation));
                relativePredefinedPoint.setPredefinedPointIndex2(updateIndex(i2, index, operation));
            } else if (predefinedPoint instanceof XYRelativePredefinedPoint) {
                XYRelativePredefinedPoint xyRelativePredefinedPoint = (XYRelativePredefinedPoint) predefinedPoint;
                int i1 = xyRelativePredefinedPoint.getPredefinedPointIndex1();
                int i2 = xyRelativePredefinedPoint.getPredefinedPointIndex2();
                if (operation == 1 && (i1 == index || i2 == index))
                    new RuntimeException("Удалена точка от которой засивят другие точки.");
                xyRelativePredefinedPoint.setPredefinedPointIndex1(updateIndex(i1, index, operation));
                xyRelativePredefinedPoint.setPredefinedPointIndex2(updateIndex(i2, index, operation));
            } else if (predefinedPoint instanceof DisplacementPredefinedPoint) {
                DisplacementPredefinedPoint displacementPredefinedPoint = (DisplacementPredefinedPoint) predefinedPoint;
                int i = displacementPredefinedPoint.getPredefinedPointIndex();
                if (operation == 1 && i == index)
                    new RuntimeException("Удалена точка от которой засивят другие точки.");
                displacementPredefinedPoint.setPredefinedPointIndex(updateIndex(i, index, operation));
            }
        }
    }

    /**
     * Обновить индекс точки привязки после удаления или добавления предопределенной точки.
     *
     * @param index          Индекс предопределенной точки.
     * @param operationIndex Индекс удаленной или добавленной предопределенной точки.
     * @param operation      Тип операции: 0 - добавление точки, 1- удаление точки.
     * @return Обновленный индекс.
     */
    private int updateIndex(int index, int operationIndex, int operation) {
        int i = (operation == 1 && index > operationIndex) ? index - 1 :
                (operation == 1 && index < operationIndex) ? index :
                        (operation == 0 && index >= operationIndex) ? index + 1 :
                                (operation == 0 && index < operationIndex) ? index : index;
        return i;
    }

}
