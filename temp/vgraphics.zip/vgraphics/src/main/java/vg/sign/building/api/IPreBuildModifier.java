package vg.sign.building.api;

import vg.sign.visual.api.ISignVisual;

/**
 * Модификатор визуального представления перед построением.
 */
public interface IPreBuildModifier {

    /**
     * Получить флаг включённости модификатора.
     * Данный флаг не влияет на работу модификатора и должен проверяться во внешнем коде.
     *
     * @return Флаг включённости модификатора.
     */
    public boolean isEnabled();

    /**
     * Включить/выключить модификатор.
     * Данный флаг не влияет на работу модификатора и должен проверяться во внешнем коде.
     *
     * @param enabled Флаг включённости модификатора.
     */
    public void setEnabled(boolean enabled);

    /**
     * Модифицировать визуальное представление.
     *
     * @param visual Визуальное представление.
     */
    public void modify(ISignVisual visual);

}
