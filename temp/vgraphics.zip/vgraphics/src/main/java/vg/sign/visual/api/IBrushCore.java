package vg.sign.visual.api;

/**
 * Основа заливки.
 *
 */
public interface IBrushCore extends Cloneable {

    /**
     * Клонирование.
     *
     * @return Клон.
     */
    // todo: remove cloneable!!!
    public IBrushCore clone();

}
