package vg.sign.visual.tools.pen;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import vg.geometry.GeometryDefaults;
import vg.sign.visual.SignVisualFactory;
import vg.sign.visual.api.IPen;
import vg.sign.visual.api.IPenCore;
import vg.sign.visual.api.IPenElement;

import static vg.geometry.GeometryDefaults.*;
/**
 * Factory for creating pens of different styles.
 * Created by gusevdm on 11/23/2016.
 */

public final class PensFactory {

    private static final Log LOG = LogFactory.getLog(PensFactory.class);
    private static final int DEFAULT_MASK = 0xFFFFFFFF;

    static {
        LOG.debug("PensFactory loaded.");
    }

    private PensFactory() {} // non-instantiability

    /***/
    public static IPen createSolidPen(int color, double width) {
        LOG.debug("Creating solid pen []");

        // create one pen element with default params
        IPenElement pe = new PenElement();
        pe.setCore(new SolidPenCore());
        pe.setColor(color, DEFAULT_MASK);
        pe.setWidth(width);
        pe.setCap(LineCapType.BUTT);
        pe.setJoin(LinesJoinType.MITTER);
        pe.setBeginArrow(LineArrowType.NONE);
        pe.setEndArrow(LineArrowType.NONE);

        // creating a pen and put into an element
        IPen pen = new Pen();
        pen.getElements().add(pe);

        return pen;
    }

}
