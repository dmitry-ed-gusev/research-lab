package vg.sign.visual.tools.pen;

import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.visual.api.IPatternPenCore;
import vg.sign.visual.api.IPenPattern;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Элемента пера - простой шаблон.
 */
public class PatternPenCore implements IPatternPenCore {

    /**
     * Шаблон пера.
     * <p>С.к. шаблона - это не прямоугольная система координат.
     * X направлена вдоль базовой линии (та, которая рисуется этим шаблоном).
     * Y направлена вдоль нормали к линии в точке X.
     *
     */
    public static class PenPattern implements IPenPattern {


        /**
         * Элемент шаблона.
         *
         */
        public static class Element implements IPenPattern.IElement {

            /**
             * Точки.
             */
            private BasePoint2D[] points;
            /**
             * Флаг залитости.
             */
            private boolean filled;
            /**
             * Флаг наличия начальной стрелки.
             */
            private boolean beginArrow;
            /**
             * Флаг наличия конечной стрелки.
             */
            private boolean endArrow;


            /***/
            public Element() {
                this.points = new BasePoint2D[0];
                this.filled = false;
                this.beginArrow = false;
                this.endArrow = false;
            }

            /**
             * @param filled Флаг залитости.
             * @param points Точки.
             */
            public Element(boolean filled, BasePoint2D... points) {
                this.filled = filled;
                this.points = new BasePoint2D[points.length];
                int counter = 0;
                for (BasePoint2D p : points) {
                    this.points[counter++] = new BasePoint2D(p);
                }
                this.beginArrow = false;
                this.endArrow = false;
            }

            /**
             * @param filled     Флаг залитости.
             * @param beginArrow Флаг наличия начальной стрелки.
             * @param endArrow   Флаг наличия конечной стрелки.
             * @param points     Точки.
             */
            public Element(boolean filled, boolean beginArrow, boolean endArrow, BasePoint2D... points) {
                this.filled = filled;
                this.points = new BasePoint2D[points.length];
                int counter = 0;
                for (BasePoint2D p : points) {
                    this.points[counter++] = new BasePoint2D(p);
                }
                this.beginArrow = beginArrow;
                this.endArrow = endArrow;
            }

            /**
             * @param filled Флаг залитости.
             * @param values Значения в формате [x, y].
             */
            public Element(boolean filled, double... values) {
                this.filled = filled;
                int pointsCount = (values.length - (values.length % 2)) / 2;
                points = new BasePoint2D[pointsCount];
                for (int i = 0; i < pointsCount; i++) {
                    points[i] = new BasePoint2D(values[i * 2], values[(i * 2) + 1]);
                }
                this.beginArrow = false;
                this.endArrow = false;
            }

            /**
             * @param filled     Флаг залитости.
             * @param beginArrow Флаг наличия начальной стрелки.
             * @param endArrow   Флаг наличия конечной стрелки.
             * @param values     Значения в формате [x, y].
             */
            public Element(boolean filled, boolean beginArrow, boolean endArrow, double... values) {
                this.filled = filled;
                int pointsCount = (values.length - (values.length % 2)) / 2;
                points = new BasePoint2D[pointsCount];
                for (int i = 0; i < pointsCount; i++) {
                    points[i] = new BasePoint2D(values[i * 2], values[(i * 2) + 1]);
                }
                this.beginArrow = beginArrow;
                this.endArrow = endArrow;
            }


            @Override
            public Element clone() {
                try {
                    Element clone = (Element) super.clone();
                    int n = points.length;
                    clone.points = new BasePoint2D[n];
                    for (int i = 0; i < n; i++) {
                        clone.points[i] = new BasePoint2D(points[i]);
                    }
                    return clone;
                } catch (CloneNotSupportedException e) {
                    throw new RuntimeException(e);
                }
            }

            @Override
            public int hashCode() {
                int result = 17;
                for (BasePoint2D point : points)
                    result = result * 7 + point.hashCode();
                result = result * 7 + GeometryUtils.hashCode(filled);
                result = result * 7 + GeometryUtils.hashCode(beginArrow);
                result = result * 7 + GeometryUtils.hashCode(endArrow);
                return result;
            }


            @Override
            public BasePoint2D[] getPoints() {
                return points;
            }

            @Override
            public void setPoints(BasePoint2D[] points) {
                this.points = points;
            }

            @Override
            public boolean getFilled() {
                return filled;
            }

            @Override
            public void setFilled(boolean filled) {
                this.filled = filled;
            }

            @Override
            public boolean hasBeginArrow() {
                return beginArrow;
            }

            @Override
            public void setBeginArrow(boolean exists) {
                this.beginArrow = exists;
            }

            @Override
            public boolean hasEndArrow() {
                return endArrow;
            }

            @Override
            public void setEndArrow(boolean exists) {
                this.endArrow = exists;
            }

            @Override
            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (obj == null) {
                    return false;
                }
                if (!(obj instanceof Element)) {
                    return false;
                }
                Element other = (Element) obj;
                if (beginArrow != other.beginArrow) {
                    return false;
                }
                if (endArrow != other.endArrow) {
                    return false;
                }
                if (filled != other.filled) {
                    return false;
                }
                if (!Arrays.equals(points, other.points)) {
                    return false;
                }
                return true;
            }

        }


        /**
         * Длина шаблона.
         */
        private double size;
        /**
         * Масштаб.
         */
        private double scale;
        /**
         * Элементы шаблона.
         */
        private List<IElement> elements;


        /***/
        public PenPattern() {
            this.elements = new ArrayList<IPenPattern.IElement>();
        }

        ;

        /**
         * @param size     Размер.
         * @param elements Элементы.
         */
        public PenPattern(double size, IElement... elements) {
            this.size = size;
            this.scale = 1.0;
            this.elements = new ArrayList<IElement>();
            for (IElement e : elements) {
                this.elements.add(e.clone());
            }
        }

        /**
         * @param size     Размер.
         * @param scale    Множитель размера.
         * @param elements Элементы.
         */
        public PenPattern(double size, double scale, IElement... elements) {
            this.size = size;
            this.scale = scale;
            this.elements = new ArrayList<IElement>();
            for (IElement e : elements) {
                this.elements.add(e.clone());
            }
        }


        @Override
        public PenPattern clone() {
            try {
                PenPattern pp = (PenPattern) super.clone();
                pp.elements = new ArrayList<IPenPattern.IElement>(elements.size());
                for (IElement e : elements) {
                    pp.getElements().add(e.clone());
                }
                return pp;
            } catch (CloneNotSupportedException e) {
                throw new RuntimeException(e);
            }

        }

        @Override
        public int hashCode() {
            int result = 17;
            result = result * 7 + GeometryUtils.hashCode(size);
            result = result * 7 + GeometryUtils.hashCode(scale);
            for (IElement element : elements)
                result = result * 7 + element.hashCode();
            return result;
        }


        @Override
        public List<IElement> getElements() {
            return elements;
        }

        @Override
        public double getSize() {
            return size;
        }

        @Override
        public void setSize(double size) {
            this.size = size;
        }

        @Override
        public double getScale() {
            return scale;
        }

        @Override
        public void setScale(double scale) {
            this.scale = scale;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            PenPattern other = (PenPattern) obj;
            if (elements == null) {
                if (other.elements != null)
                    return false;
            } else if (!elements.equals(other.elements))
                return false;
            if (Double.doubleToLongBits(scale) != Double
                    .doubleToLongBits(other.scale))
                return false;
            if (Double.doubleToLongBits(size) != Double
                    .doubleToLongBits(other.size))
                return false;
            return true;
        }

    }


    /**
     * Шаблон.
     */
    private IPenPattern pattern;


    /***/
    public PatternPenCore() {
        this(null);
    }

    /**
     * @param pattern Шаблон.
     */
    public PatternPenCore(IPenPattern pattern) {
        this.pattern = pattern;
    }


    @Override
    public PatternPenCore clone() {
        try {
            PatternPenCore clonedObject = (PatternPenCore) super.clone();

            clonedObject.pattern = pattern.clone();

            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }


    @Override
    public IPenPattern getPattern() {
        return pattern;
    }

    @Override
    public void setPattern(IPenPattern pattern) {
        this.pattern = pattern;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof PatternPenCore)) {
            return false;
        }
        PatternPenCore other = (PatternPenCore) obj;
        if (pattern == null) {
            if (other.pattern != null) {
                return false;
            }
        } else if (!pattern.equals(other.pattern)) {
            return false;
        }
        return true;
    }

}
