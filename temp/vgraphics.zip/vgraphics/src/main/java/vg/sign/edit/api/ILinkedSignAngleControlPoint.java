package vg.sign.edit.api;

/**
 * Интерейс контрольной точки для регулировки угла наклона врезанного точечного знака внутри линейного.
 *
 * @author Giller
 */
public interface ILinkedSignAngleControlPoint extends IControlPoint, IPositionControlPoint {

    /**
     * Получить угол наклона в радианах.
     *
     * @return угол наклона в радианах.
     */
    public double getSlopeAngle();
}
