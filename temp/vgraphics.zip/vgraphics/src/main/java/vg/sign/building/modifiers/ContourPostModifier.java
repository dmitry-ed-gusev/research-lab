package vg.sign.building.modifiers;

import vg.draw.vobject.*;
import vg.sign.building.VGPatternPen;
import vg.sign.building.api.IContourModePostModifier;

import java.util.List;

/**
 * Контурный модификатор.
 *
 * @author Giller
 */
public class ContourPostModifier extends AbstractPostModifier implements IContourModePostModifier {

//	/** Цвет контурного режима. */
//	private static final int COLOR = 0xFF000000;


    @Override
    public void modify(VGObject image) {
        if (image instanceof VGShape)
            this.checkShape((VGShape) image);

        else if (image instanceof VGGroup) {
            List<VGObject> ls = ((VGGroup) image).getChildren();
            for (int i = 0; i < ls.size(); ++i)
                this.modify(ls.get(i));

        } else if (image instanceof VGText)
            this.checkVGText((VGText) image);
    }

    /**
     * Модификация текста.
     *
     * @param text текст.
     * @return текст.
     */
    private VGText checkVGText(VGText text) {
//		text.setTextColor(COLOR);
        text.setFieldBrush(this.checkBrush(text.getFieldBrush()));
        text.setFieldPen(this.checkPen(text.getFieldPen()));
        text.setBackgroundBrush(this.checkBrush(text.getBackgroundBrush()));
        text.setBackgroundPen(this.checkPen(text.getBackgroundPen()));

        return text;
    }

    /**
     * Модификация фигуры.
     *
     * @param shape фигура.
     */
    private void checkShape(VGShape shape) {
        shape.setBrush(this.checkBrush(shape.getBrush()));
        shape.setPen(this.checkPen(shape.getPen()));
    }

    /**
     * Модификация пера.
     *
     * @param pen перо.
     * @return перо.
     */
    private VGPen checkPen(VGPen pen) {
        if (pen instanceof VGBasicPen) {
            VGBasicPen vgPen = (VGBasicPen) pen;
//			vgPen.setColor(COLOR);
            vgPen.setWidth(1.0);

        } else if (pen instanceof VGGroupPen) {
            List<VGPen> ls = ((VGGroupPen) pen).getChildren();
            for (int i = 0; i < ls.size(); ++i)
                this.checkPen(ls.get(i));

        } else if (pen instanceof VGPatternPen) {
//			VGPatternPen vgPen = (VGPatternPen)pen;
//			vgPen.setColor(COLOR);
            pen = new VGBasicPen(((VGPatternPen) pen).getColor(), 1.0);
        }

        return pen;
    }

    /**
     * Модификация кисти.
     *
     * @param brush кисть.
     * @return кисить.
     */
    private VGBrush checkBrush(VGBrush brush) {
        return null;
//		if (brush instanceof VGBasicBrush)
//			((VGBasicBrush)brush).setColor(((VGBasicBrush)brush).getColor() & 0x00FFFFFF);
//
//		else if (brush instanceof VGGroupBrush) {
//			List<VGBrush> ls = ((VGGroupBrush)brush).getChildren();
//			for (int i = 0; i < ls.size(); ++i)
//				this.chechBrush(ls.get(i));
//
//		} else if (brush instanceof VGShadingBrush)
//			((VGShadingBrush)brush).setColor(((VGShadingBrush)brush).getColor() & 0x00FFFFFF);
    }
}
