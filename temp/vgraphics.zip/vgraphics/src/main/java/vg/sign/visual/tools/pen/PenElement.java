package vg.sign.visual.tools.pen;

import vg.draw.Colors;
import vg.geometry.GeometryDefaults;
import vg.sign.visual.api.IPenCore;
import vg.sign.visual.api.IPenElement;

/**
 * Элемент пера.
 */
public class PenElement implements IPenElement {

    /**
     * Сердечник.
     */
    private IPenCore core;
    /**
     * Цвет.
     */
    private int color;
    /**
     * Толщина линии.
     */
    private double width;
    /**
     * Тип окончаний линии.
     */
    private GeometryDefaults.LineCapType cap = GeometryDefaults.LineCapType.BUTT;
    /**
     * Тип сочленения отрезков полилинии.
     */
    private GeometryDefaults.LinesJoinType join = GeometryDefaults.LinesJoinType.MITTER;
    /**
     * Ограничение длины угла при угловом сочленении.
     */
    private double miterLimit = 4.0;
    /**
     * Начальная стрелка.
     */
    private GeometryDefaults.LineArrowType beginArrow = GeometryDefaults.LineArrowType.NONE;
    /**
     * Конечная стрелка.
     */
    private GeometryDefaults.LineArrowType endArrow = GeometryDefaults.LineArrowType.NONE;
    /**
     * Смещение.
     */
    private double shift;
    /**
     * Полоса
     */
    private double strip;


    /***/
    public PenElement() {
        this(null, 0xFF000000, 1.0, 0.0, 0.0);
    }

    /**
     * Конструктор чёрного пера толщиной 1.
     *
     * @param core Сердечник пера.
     */
    public PenElement(IPenCore core) {
        this(core, 0xFF000000, 1.0, 0.0, 0.0);
    }

    /**
     * @param core  Сердечник пера.
     * @param color Цвет.
     */
    public PenElement(IPenCore core, int color) {
        this(core, color, 1.0, 0.0, 0.0);
    }

    /**
     * @param core  Сердечник пера.
     * @param color Цвет.
     * @param width Толщина.
     */
    public PenElement(IPenCore core, int color, double width) {
        this(core, color, width, 0.0, 0.0);
    }


    /**
     * @param core  Сердечник пера.
     * @param color Цвет.
     * @param width Толщина.
     * @param shift Смещение.
     * @param strip Полоса.
     */
    public PenElement(IPenCore core, int color, double width, double shift, double strip) {
        this.core = core;
        this.color = color;
        this.width = width;
        this.shift = shift;
        this.strip = strip;
    }


    @Override
    public PenElement clone() {
        try {
            PenElement clonedObject = (PenElement) super.clone();
            clonedObject.beginArrow = beginArrow;
            clonedObject.endArrow = endArrow;
            clonedObject.cap = cap;
            clonedObject.join = join;
            clonedObject.core = core.clone();
            clonedObject.color = color;
            clonedObject.miterLimit = miterLimit;
            clonedObject.shift = shift;
            clonedObject.strip = strip;
            clonedObject.width = width;
            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void init(IPenElement penElement) {
        this.beginArrow = penElement.getBeginArrow();
        this.endArrow = penElement.getEndArrow();
        this.cap = penElement.getCap();
        this.join = penElement.getJoin();
        this.core = penElement.getCore().clone();
        this.color = penElement.getColor();
        this.miterLimit = penElement.getMiterLimit();
        this.shift = penElement.getShift();
        this.strip = penElement.getStrip();
        this.width = penElement.getWidth();
    }


    @Override
    public int getColor() {
        return color;
    }

    @Override
    public void setColor(int color, int mask) {
        this.color = Colors.setColor(this.color, color, mask);
    }

    @Override
    public double getWidth() {
        return width;
    }

    @Override
    public void setWidth(double width) {
        this.width = width;
    }

    @Override
    public GeometryDefaults.LineCapType getCap() {
        return cap;
    }

    @Override
    public void setCap(GeometryDefaults.LineCapType cap) {
        this.cap = cap;
    }

    @Override
    public GeometryDefaults.LinesJoinType getJoin() {
        return join;
    }

    @Override
    public void setJoin(GeometryDefaults.LinesJoinType join) {
        this.join = join;
    }

    @Override
    public double getMiterLimit() {
        return miterLimit;
    }

    @Override
    public void setMiterLimit(double miterLimit) {
        this.miterLimit = miterLimit;
    }

    @Override
    public GeometryDefaults.LineArrowType getBeginArrow() {
        return beginArrow;
    }

    @Override
    public void setBeginArrow(GeometryDefaults.LineArrowType arrow) {
        this.beginArrow = arrow;
    }

    @Override
    public GeometryDefaults.LineArrowType getEndArrow() {
        return endArrow;
    }

    @Override
    public void setEndArrow(GeometryDefaults.LineArrowType arrow) {
        this.endArrow = arrow;
    }

    @Override
    public double getShift() {
        return shift;
    }

    @Override
    public void setShift(double shift) {
        this.shift = shift;
    }

    @Override
    public double getStrip() {
        return strip;
    }

    @Override
    public void setStrip(double strip) {
        this.strip = strip;
    }

    @Override
    public IPenCore getCore() {
        return core;
    }

    @Override
    public void setCore(IPenCore core) {
        this.core = core;
    }

}
