package vg.sign.building;

import vg.draw.vobject.VGObject;
import vg.geometry.GeometryProcessor;
import vg.geometry.primitives.BasePoint2D;
import vg.geometry.primitives.BaseRectangle2D;
import vg.sign.building.api.ICalculatedGraph;
import vg.sign.building.api.IGeometry;
import vg.sign.visual.api.IAnchorPoint;
import vg.sign.visual.api.ISignVisual;
import vg.sign.visual.signs.AreaSignVisual;
import vg.sign.visual.signs.LineSignVisual;
import vg.sign.visual.signs.PointSignVisual;

import java.util.ArrayList;
import java.util.List;

/**
 * Класс для работы с изображением.
 *
 * @author Giller
 */
public class CalculatedGraph implements ICalculatedGraph {

    /**
     * Графический объект.
     */
    private VGObject gObject;
    /**
     * Набор геометрических параметров.
     */
    private IGeometry geometry;


    /*
     * Получить геометрические характеристики.
     * @return геометрические характеристики.
     */
    @Override
    public IGeometry getGeometry() {
        return this.geometry;
    }

    /*
     * Установить геометрические характеристики.
     * @param geometry геометрические характеристики.
     */
    @Override
    public void setGemetry(IGeometry geometry) {
        this.geometry = geometry;
    }

    /*
     * Получить графический объект.
     * @return графический объект.
     */
    @Override
    public VGObject getImage() {
        return gObject;
    }

    /*
     * Установить графический объект.
     * @param gObject графический объект.
     */
    @Override
    public void setImage(VGObject gObject) {
        this.gObject = gObject;
    }

    /**
     * Вычислить геометрические параметры.
     *
     * @param signVisual визуальное представление знака.
     * @param bounds     рамка.
     * @return геометрические параметры.
     */
    public IGeometry calculateGeometry(ISignVisual signVisual, BaseRectangle2D bounds) {
        this.geometry.setAngle(bounds.getAngle());
        this.geometry.setWidth(bounds.getWidth());
        this.geometry.setHeight(bounds.getHeight());
        this.geometry.setDiagonal(Math.sqrt(Math.pow(2.0, bounds.getWidth()) + Math.pow(2.0, bounds.getHeight())));
        this.geometry.setRadius(this.geometry.getDiagonal() / 2.0);

        if (signVisual instanceof PointSignVisual) {
            this.geometry.setLength(0);
            this.geometry.setSpace(0);

        } else {
            // Расчёт основной линии.
            List<BasePoint2D> basePoints = new ArrayList<BasePoint2D>(signVisual.getAnchorPoints().size());
            for (IAnchorPoint ap : signVisual.getAnchorPoints())
                basePoints.add(ap.getPoint());

            List<BasePoint2D> linePoints = null;
            if (signVisual instanceof LineSignVisual) {
                LineSignVisual lineSV = (LineSignVisual) signVisual;
                linePoints = buildLinePoints(basePoints, lineSV.isSmooth(), false);
                this.geometry.setLength(GeometryProcessor.getPolylineLength(linePoints));
                this.geometry.setSpace(0);

            } else if (signVisual instanceof AreaSignVisual) {
                AreaSignVisual areaVisual = (AreaSignVisual) signVisual;
                linePoints = buildLinePoints(basePoints, areaVisual.isSmooth(), true);
                this.geometry.setLength(GeometryProcessor.getPolylineLength(linePoints));
                this.geometry.setSpace(GeometryProcessor.getAreaSpace(linePoints));
            }
        }

        return geometry;
    }

    /**
     * Получить точки фигуры.
     *
     * @param basePoints Базовые точки линии.
     * @param smooth     Сглаженность линии.
     * @param closed     Замкнутость линии.
     * @return Расчитанные точки линии.
     */
    private List<BasePoint2D> buildLinePoints(List<? extends BasePoint2D> basePoints, boolean smooth, boolean closed) {
        if (smooth) {
            List<BasePoint2D> referencePoints = new ArrayList<BasePoint2D>();
            for (BasePoint2D bp : basePoints)
                referencePoints.add(new BasePoint2D(bp));
            List<BasePoint2D> linePoints = new ArrayList<BasePoint2D>();
            GeometryProcessor.getSplinePoints(linePoints, referencePoints, GeometryProcessor.ST_CUBIC, closed);
            return (List) linePoints;
        } else {
            List<BasePoint2D> linePoints = new ArrayList<BasePoint2D>();
            for (BasePoint2D bp : basePoints)
                linePoints.add(new BasePoint2D(bp));
            if (closed && !linePoints.isEmpty() && !linePoints.get(0).equals(linePoints.get(linePoints.size() - 1)))
                linePoints.add(new BasePoint2D(linePoints.get(0)));
            return linePoints;
        }
    }
}
