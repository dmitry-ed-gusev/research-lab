package vg.sign.visual.api;


import vg.geometry.primitives.BasePoint2D;

/**
 * Визуальное представление знака.
 *
 */
public interface ISignVisual extends Cloneable {

    /**
     * Клонирование.
     *
     * @return Клон.
     */
    public ISignVisual clone();

    /**
     * Получить уникальный идентификатор экземпляра Визуального представления.
     *
     * @return Уникальный идентификатор Визуального представления.
     */
    public String getId();

    /**
     * Задать уникальный идентификатор Визуального представления.
     *
     * @param id Уникальный идентификатор Визуального представления.
     */
    public void setId(String id);

    /**
     * Получить список точек привязки знака.
     *
     * @return Список точек привязки знака.
     */
    public IAnchorPointsList getAnchorPoints();


    /**
     * Получить видимость знака.
     *
     * @return видимость знака.
     */
    public boolean isVisible();

    /**
     * Установить видимость знака.
     *
     * @param visible видимость знака.
     */
    public void setVisible(boolean visible);

    /**
     * Получить зеркальность.
     *
     * @return зеркальность.
     */
    public boolean isMirrored();

    /**
     * Установить зеркальность.
     *
     * @param mirrored зеркальность.
     */
    public void setMirrored(boolean mirrored);

    /**
     * Получить масштабный коэффициент знака.
     *
     * @return Масштабный коэффициент знака.
     */
    public BasePoint2D getScale();

    /**
     * Задать масштабный коэффициент знака.
     *
     * @param scale Масштабный коэффициент знака.
     */
    public void setScale(BasePoint2D scale);

    /**
     * Получить угол поворота знака.
     *
     * @return Угол поворота знака.
     */
    public double getAngle();

    /**
     * Задать угол поворота знака.
     *
     * @param angle Угол поворота знака.
     */
    public void setAngle(double angle);

    /**
     * Получить флаг масштабируемости.
     *
     * @return true знак можно масштабировать, false - иначе.
     */
    public boolean isScalable();

    /**
     * Установить флаг масштабируемости.
     *
     * @param scalable флаг масштабируемости.
     */
    public void setScalable(boolean scalable);

    /**
     * Получить флаг вращения.
     *
     * @return true знак можно вращать, false - иначе.
     */
    public boolean isRotatable();

    /**
     * Установить флаг вращения.
     *
     * @param rotatable флаг вращения.
     */
    public void setRotatable(boolean rotatable);

    /**
     * Получить корневой графический элемент.
     *
     * @return Корневой графический элемент.
     */
    public IRootGraphElement getRootGraphElement();

    /**
     * Создать семантики точки привязки по умолчанию.
     *
     * @param index       Индекс точки привязки.
     * @param anchorPoint Точка привязки.
     */
    public void createDefaultSemantics(int index, IAnchorPoint anchorPoint);

}
