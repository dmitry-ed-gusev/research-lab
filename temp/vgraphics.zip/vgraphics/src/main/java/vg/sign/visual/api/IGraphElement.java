package vg.sign.visual.api;

/**
 * Графический элемент.
 *
 */
public interface IGraphElement extends Cloneable {

    /**
     * Клонирование.
     *
     * @return Клон.
     */
    public IGraphElement clone();


    /**
     * Получить ID.
     *
     * @return ID.
     */
    public String getId();

    /**
     * Задать ID.
     *
     * @param id ID.
     */
    public void setId(String id);

    /**
     * Получить название графического элемента.
     *
     * @return название графического элемента.
     */
    public String getName();

    /**
     * Установить название графического элемента.
     *
     * @param name название графического элемента.
     */
    public void setName(String name);

    /**
     * Получить видимость.
     *
     * @return видимость.
     */
    public boolean isVisible();

    /**
     * Установить видимость элемента.
     *
     * @param visible видимость элемента.
     */
    public void setVisible(boolean visible);

    /**
     * Получить флаг редактируемости элемента.
     *
     * @return флаг редактируемости элемента.
     */
    public boolean isEditable();

    /**
     * Установить флаг редактируемости элемента.
     *
     * @param editable флаг редактируемости элемента.
     */
    public void setEditable(boolean editable);


    /**
     * Получить перо контура.
     *
     * @return Перо контура.
     */
    public IPen getPen();

    /**
     * Задать перо контура.
     *
     * @param pen Перо контура.
     */
    public void setPen(IPen pen);

    /**
     * Получить заливку.
     *
     * @return Заливка.
     */
    public IBrush getBrush();

    /**
     * Задать заливку.
     *
     * @param brush Заливка.
     */
    public void setBrush(IBrush brush);

    /**
     * Получить текст.
     *
     * @return Текст.
     */
    public IText getText();

    /**
     * Задать текст.
     *
     * @param text Текст.
     */
    public void setText(IText text);

}
