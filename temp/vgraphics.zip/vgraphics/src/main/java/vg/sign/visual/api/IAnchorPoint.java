package vg.sign.visual.api;

import vg.geometry.primitives.BasePoint2D;

import java.util.Map;

/**
 * Anchoring point.
 */

public interface IAnchorPoint extends Cloneable {

    /**
     * Клонирование.
     *
     * @return Клон.
     */
    IAnchorPoint clone();

    /**
     * Получить координаты точки.
     *
     * @return Координаты точки.
     */
    public BasePoint2D getPoint();

    /**
     * Задать координаты точки.
     *
     * @param point Координаты точки.
     */
    public void setPoint(BasePoint2D point);

    /**
     * Получить карту смысловых значений.
     *
     * @return Карта смысловых значений.
     */
    public Map<String, Object> getSemantic();

}
