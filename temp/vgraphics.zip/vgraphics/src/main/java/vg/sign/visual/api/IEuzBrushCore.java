package vg.sign.visual.api;

import vg.sign.visual.signs.PointSignVisual;

/**
 * Элемент заливки шаблоном из ЭУЗ.
 *
 */
public interface IEuzBrushCore extends IBrushCore {

    /**
     * Получить ЭУЗ шаблона.
     *
     * @return ЭУЗ шаблона.
     */
    public PointSignVisual getEuz();

    /**
     * Задать ЭУЗ шаблона.
     *
     * @param euz ЭУЗ шаблона.
     */
    public void setEuz(PointSignVisual euz);

}
