package vg.sign.building.api;

import java.util.List;


/**
 * Групповой премодификатор.
 */
public interface IGroupPreModifier extends IPreBuildModifier {

    /**
     * Получить перечень предварительных модификаторов.
     *
     * @return перечень предварительных модификаторов.
     */
    public List<IPreBuildModifier> getElements();

}
