package vg.sign.visual.table;

import vg.sign.visual.api.IGraphElement;

/**
 * Интерфес содержимого ячейки.
 *
 * @author Giller
 */
public interface ICellContent extends Cloneable {

    /**
     * Получить идентификатор содержимого ячейки.
     *
     * @return идентификатор содержимого ячейки.
     */
    public String getId();

    /**
     * Установить идентификатор содержимого ячейки.
     *
     * @param id идентификатор содержимого ячейки.
     */
    public void setId(String id);

    /**
     * Получить графический элемент содержимого.
     *
     * @return графический элемент содержимого.
     */
    public IGraphElement getGraphElement();

    /**
     * Клонирование.
     *
     * @return клон.
     */
    public ICellContent clone();

}