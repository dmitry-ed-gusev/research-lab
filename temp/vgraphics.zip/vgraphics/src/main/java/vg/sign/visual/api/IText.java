package vg.sign.visual.api;

/**
 * Текст.
 *
 */
public interface IText extends Cloneable {

    /**
     * Горизонтальное левое выравнивание.
     */
    public static final int HA_LEFT = 0x01;
    /**
     * Горизонтальное правое выравнивание.
     */
    public static final int HA_RIGHT = 0x02;
    /**
     * Горизонтальное центральное выравнивание.
     */
    public static final int HA_CENTER = 0x03;
    /**
     * Вертикальное верхнее выравнивание.
     */
    public static final int VA_TOP = 0x04;
    /**
     * Вертикальное нижнее выравнивание.
     */
    public static final int VA_BOTTOM = 0x08;
    /**
     * Вертикальное центральное выравнивание.
     */
    public static final int VA_CENTER = 0x0C;
    /**
     * Стиль шрифта - жирный.
     */
    public static final int FS_BOLD = 0x01;
    /**
     * Стиль шрифта - наклонный.
     */
    public static final int FS_ITALIC = 0x02;
    /**
     * Стиль шрифта - подчёркнутый.
     */
    public static final int FS_UNDERLINE = 0x04;
    /**
     * /** Стиль шрифта - надчёркнутый.
     */
    public static final int FS_OVERLINE = 0x08;
    /**
     * Стиль шрифта - зачёркнутый.
     */
    public static final int FS_LINETHROUGH = 0x10;


    /**
     * Клонирование.
     *
     * @return Клон.
     */
    IText clone();

    /**
     * Получить текст.
     *
     * @return Текст.
     */
    public String getText();

    /**
     * Задать текст.
     *
     * @param text Текст.
     */
    public void setText(String text);


    /**
     * Получить название шрифта.
     *
     * @return Задать название шрифта.
     */
    public String getFontName();

    /**
     * Задать название шрифта.
     *
     * @param fontName Название шрифта.
     */
    public void setFontName(String fontName);

    /**
     * Получить стиль шрифта.
     *
     * @return Стиль шрифта.
     */
    public int getFontStyle();

    /**
     * Задать сталь шрифта.
     *
     * @param fontStyle Стиль шрифта.
     */
    public void setFontStyle(int fontStyle);

    /**
     * Получить размер шрифта.
     *
     * @return Размер шрифта.
     */
    public double getFontSize();

    /**
     * Задать размер шрифта.
     *
     * @param fontSize Размер шрифта.
     */
    public void setFontSize(double fontSize);

    /**
     * Получить выравнивание.
     *
     * @return Выранивание.
     */
    public int getAlignment();

    /**
     * Задать выравнивание.
     *
     * @param alignment Выранивание.
     */
    public void setAlignment(int alignment);

    /**
     * Получить цвет шрифта.
     *
     * @return Цвет шрифта.
     */
    public int getColor();

    /**
     * Задать цвет шрифта.
     *
     * @param color Цвет шрифта.
     * @param mask  Маска назначения цвета.
     *              <p>Будут заданы только те биты цвета, которые соответствуют единичным битам маски.
     *              <p>См. {@link IColor#CM_A}, {@link IColor#CM_R}, {@link IColor#CM_G}, {@link IColor#CM_B},
     *              {@link IColor#CM_RGB}, {@link IColor#CM_ARGB}.
     */
    public void setColor(int color, int mask);

    /**
     * Получить Перо окантовки текста.
     *
     * @return Перо акантовки текста.
     */
    public IPen getPen();

    /**
     * Задать перо окантовки текста.
     *
     * @param pen Перо окантовки текста.
     */
    public void setPen(IPen pen);

    /**
     * Получить заливку фона текста.
     *
     * @return Заливка фона текста.
     */
    public IBrush getBrush();

    /**
     * Задать заливку фона текста.
     *
     * @param brush Заливка фона текста.
     */
    public void setBrush(IBrush brush);

}
