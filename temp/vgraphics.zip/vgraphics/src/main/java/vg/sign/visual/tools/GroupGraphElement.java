package vg.sign.visual.tools;

import vg.sign.visual.api.IGraphElement;
import vg.sign.visual.signs.AbstractGroupGraphElement;

import java.util.ArrayList;
import java.util.List;

/**
 * Групповой графический элемент, хранящий группируемые элементы в списке.
 */
public class GroupGraphElement extends AbstractGroupGraphElement {

    /**
     * Список графических элементов.
     */
    protected List<IGraphElement> graphElements = new ArrayList<IGraphElement>();


    /***/
    public GroupGraphElement() {
    }

    /**
     * @param name Название графического элемента.
     */
    public GroupGraphElement(String name) {
        super(name);
    }


    @Override
    public GroupGraphElement clone() {
        GroupGraphElement clone = (GroupGraphElement) super.clone();
        List<IGraphElement> gElements = new ArrayList<IGraphElement>();
        for (IGraphElement ge : graphElements) {
            gElements.add(ge.clone());
        }
        clone.graphElements = new ArrayList<IGraphElement>();
        clone.graphElements.addAll(gElements);
        return clone;
    }

    @Override
    public List<IGraphElement> getElements() {
        return graphElements;
    }

}
