package vg.sign.building.api;


import java.util.Map;

/**
 * Построитель Группового ЭУЗ.
 */
public interface IGroupGraphBuilder extends ISignBuilder {

    /**
     * Получить карту Построителей дочерних ЭУЗ по идентификаторам.
     *
     * @return Список Построителей дочерних ЭУЗ по идентификаторам.
     */
    public Map<String, ISignBuilder> getChildren();

}
