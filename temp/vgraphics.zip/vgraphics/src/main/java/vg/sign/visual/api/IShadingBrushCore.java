package vg.sign.visual.api;


/**
 * Штриховочный элемент заливки.
 *
 */
public interface IShadingBrushCore extends IBrushCore {

    /**
     * Получить штриховку.
     *
     * @return Штриховка.
     */
    public IBrushShading getShading();

    /**
     * Задать штриховку.
     *
     * @param shading Штриховка.
     */
    public void setShading(IBrushShading shading);

}
