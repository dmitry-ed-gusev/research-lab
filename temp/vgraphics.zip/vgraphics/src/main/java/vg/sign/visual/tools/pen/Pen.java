package vg.sign.visual.tools.pen;

import vg.sign.visual.api.IPen;
import vg.sign.visual.api.IPenElement;
import vg.utils.ListReference;

import java.util.ArrayList;
import java.util.List;

/**
 * Перо.
 */
public class Pen implements IPen {

    /**
     * Перечень элементов пера.
     *
     * @author Giller
     */
    public class PenElementsList extends ListReference<IPenElement> implements IPen.IPenElementsList {

        /**
         * Конструктор с входным параметром.
         *
         * @param editable редактируемость перечня элементов.
         */
        public PenElementsList(boolean editable) {
            super(new ArrayList<IPenElement>(), editable);
        }

        @Override
        public boolean isEditable() {
            return this.isReadOnly();
        }
    }


    /**
     * Элементы пера.
     */
//	private List<IPenElement> elements = new ArrayList<IPenElement>();
    private IPenElementsList elements = new PenElementsList(true);


    /***/
    public Pen() {
    }

    /**
     * @param elements Элементы пера.
     */
    public Pen(List<IPenElement> elements) {
        this.elements.addAll(elements);
    }

    /**
     * @param elements Элементы пера.
     */
    public Pen(IPenElement... elements) {
        for (IPenElement e : elements)
            this.elements.add(e);
    }


    @Override
    public Pen clone() {
        try {
            Pen clonedObject = (Pen) super.clone();

//			clonedObject.elements = new ArrayList<IPenElement>();
            clonedObject.elements = new PenElementsList(true);
            for (IPenElement pe : elements)
                clonedObject.elements.add(pe.clone());

            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }


    @Override
    public IPenElementsList getElements() {
        return elements;
    }

}
