package vg.sign.visual.tools;

import vg.sign.visual.api.IBrush;
import vg.sign.visual.api.ILineGraphElement;
import vg.sign.visual.api.IPen;
import vg.sign.visual.api.IText;
import vg.sign.visual.signs.AbstractGraphElement;

/**
 * Графический элемент Фигура.
 */

public class LineGraphElement extends AbstractGraphElement implements ILineGraphElement {

    /**
     * Перо.
     */
    protected IPen pen = null;
    /**
     * Заливка.
     */
    protected IBrush brush = null;
    /**
     * Текст.
     */
    protected IText text = null;
    /**
     * Гладкость линии.
     */
    protected boolean smooth = false;
    /**
     * Замкнутость линии.
     */
    protected boolean closed = false;


    /***/
    public LineGraphElement() {
        this(null, null, null, false, false);
    }

    /**
     * @param pen    Перо.
     * @param brush  Заливка.
     * @param text   Текст.
     * @param smooth Гладкость линии.
     * @param closed Замкнутость.
     */
    public LineGraphElement(IPen pen, IBrush brush, IText text, boolean smooth, boolean closed) {
        super("Фигура");
        this.pen = pen;
        this.brush = brush;
        this.text = text;
        this.smooth = smooth;
        this.closed = closed;
    }


    @Override
    public LineGraphElement clone() {
        LineGraphElement clonedObject = (LineGraphElement) super.clone();
        if (pen != null)
            clonedObject.pen = pen.clone();
        if (brush != null)
            clonedObject.brush = brush.clone();
        if (text != null)
            clonedObject.text = text.clone();
        return clonedObject;
    }


    @Override
    public IPen getPen() {
        return pen;
    }

    @Override
    public void setPen(IPen pen) {
        this.pen = pen;
    }

    @Override
    public IBrush getBrush() {
        return brush;
    }

    @Override
    public void setBrush(IBrush brush) {
        this.brush = brush;
    }

    @Override
    public IText getText() {
        return text;
    }

    @Override
    public void setText(IText text) {
        this.text = text;
    }

    @Override
    public boolean isSmooth() {
        return smooth;
    }

    @Override
    public void setSmooth(boolean smooth) {
        this.smooth = smooth;
    }

    @Override
    public boolean isClosed() {
        return closed;
    }

    @Override
    public void setClosed(boolean closed) {
        this.closed = closed;
    }

}
