package vg.sign.building.builders;

import vg.draw.vobject.VGGroup;
import vg.draw.vobject.VGObject;
import vg.geometry.primitives.BasePoint2D;
import vg.geometry.primitives.BaseRectangle2D;
import vg.sign.building.Geometry;
import vg.sign.building.GroupSignImage;
import vg.sign.building.api.IGeometry;
import vg.sign.building.api.IGroupGraphBuilder;
import vg.sign.building.api.ISignBuilder;
import vg.sign.visual.api.IAnchorPointsList;
import vg.sign.visual.api.IGroupSignVisual;
import vg.sign.visual.api.ISignVisual;

import java.util.HashMap;
import java.util.Map;

/**
 * Построитель группового знака.
 */
public class GroupGraphBuilder extends AbstractSignBuilder implements IGroupGraphBuilder {

    /**
     * Карта построителей дочерних ЭУЗ с идентификаторами Визуальных представлений в ключах.
     */
    private Map<String, ISignBuilder> children = new HashMap<String, ISignBuilder>();

    @Override
    public Map<String, ISignBuilder> getChildren() {
        return children;
    }

    @Override
    public void prepareBuilding(ISignVisual visual) {
        IGroupSignVisual groupVisual = (IGroupSignVisual) visual;

        for (IGroupSignVisual.IChild child : groupVisual.getChildren()) {
            if (child.getVisual() == null) continue;
            ISignBuilder builder = children.get(child.getVisual().getId());
            // If Builder doesn't exist it will be created as default.
            if (builder == null) {
                builder = createBuilder(child.getVisual());
                children.put(child.getVisual().getId(), builder);
            }
            builder.prepareBuilding(child.getVisual());
        }
        super.prepareBuilding(visual);
    }

    @Override
    public void preModify(ISignVisual visual) {
        IGroupSignVisual groupVisual = (IGroupSignVisual) visual;

        for (IGroupSignVisual.IChild child : groupVisual.getChildren()) {
            if (child.getVisual() == null) continue;
            ISignBuilder builder = children.get(child.getVisual().getId());
            builder.preModify(child.getVisual());
        }
        super.preModify(visual);
    }

    @Override
    public VGGroup buildGraphics(ISignVisual visual) {
        IGroupSignVisual groupVisual = (IGroupSignVisual) visual;

        GroupSignImage image = new GroupSignImage();
        image.getChildrenImages().clear();
        //TODO Подумать над тем правильно ли анализировать видимость знака в этом месте, возвращая при этом пустой VG объект.
        if (!visual.isVisible())
            return image;

        // Встроенные знаки.
        for (IGroupSignVisual.IChild child : groupVisual.getChildren()) {
            if (child.getVisual() == null) continue;
            ISignBuilder builder = children.get(child.getVisual().getId());
            VGObject vImage = builder.buildGraphics(child.getVisual());
            if (vImage != null) {
                // The child visual's image is postmodified here, before the postmodification of the group visual's image.
                builder.postModify(vImage);
                image.getChildren().add(vImage);

                // Добавление связки визуального представления и векторного изображения в карту.
                image.getChildrenImages().put(child.getVisual().getId(), vImage);
            }
        }

        VGObject anchorPointsBuilding = buildAnchorPoints(groupVisual.getAnchorPoints(), groupVisual.getAngle());
        if (anchorPointsBuilding != null)
            image.getChildren().add(anchorPointsBuilding);

        image.setAngle(groupVisual.getAngle());
        image.calculate();

        return image;
    }

    @Override
    public IGeometry calculateGeometry(ISignVisual visual, BaseRectangle2D bounds) {
        double diagonal = Math.sqrt(bounds.getWidth() * bounds.getWidth() + bounds.getHeight() * bounds.getHeight());
        return new Geometry(
                visual.getAngle(), bounds.getWidth(), bounds.getHeight(),
                0.0, 0.0,
                diagonal * 0.5, diagonal);
    }

    @Override
    public void prepareForPreview(ISignVisual visual) {
        IAnchorPointsList anchorPointsList = visual.getAnchorPoints();
        if (anchorPointsList.isEmpty()) {
            anchorPointsList.add(new BasePoint2D(0, 0));
        }
        super.prepareForPreview(visual);
    }

}
