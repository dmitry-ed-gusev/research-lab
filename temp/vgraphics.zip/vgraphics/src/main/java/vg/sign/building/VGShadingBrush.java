package vg.sign.building;

import vg.draw.Colors;
import vg.draw.ViewParams;
import vg.draw.painting.IPainter;
import vg.draw.painting.LineParams;
import vg.draw.vobject.VGBasicBrush;
import vg.draw.vobject.VGBrush;
import vg.geometry.GeometryProcessor;
import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BaseFrame2D;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.visual.api.IBrushShading;

import java.util.Arrays;
import java.util.List;

/**
 * Штриховая заливка графической подсистемы.
 */
// TODO Рассмотреть возможность наслдования от VGBasicBrush.
public class VGShadingBrush implements VGBrush {

    /**
     * Цвет заливки.
     */
    private int color;
    /**
     * Толщина линий штриховки.
     */
    private double width;
    /**
     * Штриховка.
     */
    private IBrushShading shading;
    /**
     * Угол в радианах.
     */
    private double angle;


    /**
     * @param color   Цвет заливки.
     * @param width   Толщина линий штриховки.
     * @param shading Штриховка.
     * @param angle   Угол (рад.)
     */
    public VGShadingBrush(int color, double width, IBrushShading shading, double angle) {
        this.color = color;
        this.width = width;
        this.shading = shading;
        this.angle = angle;
    }


    @Override
    public int hashCode() {
        int result = 17;
        result = result * 7 + color;
        result = result * 7 + GeometryUtils.hashCode(width);
        result = result * 7 + shading.hashCode();
        result = result * 7 + GeometryUtils.hashCode(angle);
        return result;
    }


    /**
     * Получить цвет.
     *
     * @return Цвет.
     */
    public int getColor() {
        return color;
    }

    /**
     * Задать цвет.
     *
     * @param color Цвет.
     */
    public void setColor(int color) {
        this.color = color;
    }

    /**
     * Получить толщину линий штриховки.
     *
     * @return Толщина линий штриховки.
     */
    public double getWidth() {
        return width;
    }

    /**
     * Задать толщину линий штриховки.
     *
     * @param width Толщина линий штриховки.
     */
    public void setWidth(double width) {
        this.width = width;
    }

    /**
     * Получить штриховку.
     *
     * @return Штриховка.
     */
    public IBrushShading getShading() {
        return shading;
    }

    /**
     * Задать штриховку.
     *
     * @param shading Штриховка.
     */
    public void setShading(IBrushShading shading) {
        this.shading = shading;
    }

    /**
     * Получить угол.
     *
     * @return Угол (рад.)
     */
    public double getAngle() {
        return angle;
    }

    /**
     * Задать угол (рад.)
     *
     * @param angle Угол.
     */
    public void setAngle(double angle) {
        this.angle = angle;
    }


    @Override
    public void paint(IPainter painter, List<BasePoint2D> points) {
        if (shading == null || shading.getElements().isEmpty()) return;

        if (isPaintDraft((ViewParams) painter.getExtra().get("viewParams"))) {
            VGBasicBrush basicBrush = new VGBasicBrush(Colors.setAlpha(color, Colors.getAlpha(color) >> 3));
            basicBrush.paint(painter, points);
            return;
        }

        paintArea(painter, points);
    }

    /**
     * Отрисовать непосредственно площадь.
     *
     * @param painter Художник.
     * @param points  Точки контура площади.
     */
    private void paintArea(IPainter painter, List<BasePoint2D> points) {
        // Сохраняем маску и задаём новую.
        painter.pushClip();
        painter.setClip(points);

        // Настраиваем цвет и тощину линий.
        painter.setColor(color);
        painter.setLineParams(new LineParams(width));

        // Расчитываем квадрат вокгуг области заливки.
        BaseFrame2D bounds = GeometryUtils.createBoundingFrame(points);
        BasePoint2D center = bounds.getCenter();
        double radius = GeometryUtils.distanceBetweenPoints(bounds.getP1(), bounds.getP2()) * 0.5;

        // Рисуем элементы штриховки.
        for (IBrushShading.IElement element : shading.getElements())
            paintShading(painter, center, radius, element.getSize(), element.getAngle() + angle);

        // Восстанавливаем маску.
        painter.popClip();
    }

    /**
     * Отрисовать элемент штриховки.
     *
     * @param painter Художник.
     * @param center  Центр заливаемой области.
     * @param radius  Радиус заливаемой области.
     * @param size    Размер штриховки.
     * @param angle   Угол штриховки.
     */
    public void paintShading(IPainter painter, BasePoint2D center, double radius, double size, double angle) {
        // Идея: получаем заливаемый квадрат, поворачиваем его вокруг центра на угол штриховки и штрихуем горизонтальными (относительно квадрата) линиями.
        // Первая верхняя линия квадрата.
        BasePoint2D p1 = new BasePoint2D(center).translate(-radius, -radius).rotate(angle, center);
        BasePoint2D p2 = new BasePoint2D(center).translate(radius, -radius).rotate(angle, center);
        // Шаг концов отрезков.
        BasePoint2D s = new BasePoint2D(0.0, size).rotate(angle, 0, 0);
        // Штрихуем горизонтальными (относительно квадрата) линиями сверху вних.
        for (int i = 0, n = (int) (radius * 2.0 / size); i <= n; i++) {
            painter.drawLine(Arrays.asList(p1, p2));
            p1.add(s);
            p2.add(s);
        }
    }

    /**
     * Проверить режим чернойвой отрисовки.
     *
     * @param mmToPx Коэффициент перехода от мм документа к пикселям.
     * @return Признак чернового режима отрисовки.
     */
    public boolean isPaintDraft(double mmToPx) {
        double shadingSizePx = shading.getSize() * mmToPx;
        return shadingSizePx <= 2.0;
    }

    /**
     * Проверить режим чернойвой отрисовки.
     *
     * @param viewParams Параметры вида.
     * @return Признак чернового режима отрисовки.
     */
    public boolean isPaintDraft(ViewParams viewParams) {
        if (viewParams == null) return false;
        return isPaintDraft(GeometryProcessor.transformSize(viewParams.getMmToPx(), 1.0));
    }

}
