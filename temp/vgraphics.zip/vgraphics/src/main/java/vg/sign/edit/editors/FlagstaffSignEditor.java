package vg.sign.edit.editors;

import org.apache.log4j.Logger;
import vg.geometry.cp.AbstractCPoint;
import vg.geometry.cp.CPCalculator;
import vg.geometry.cp.CPoint;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.edit.SignEditFactory;
import vg.sign.edit.api.IControlPoint;
import vg.sign.edit.api.IPredefinedControlPoint;
import vg.sign.edit.api.ISignEditor;
import vg.sign.visual.api.IGroupSignVisual;
import vg.sign.visual.api.ISignVisual;
import vg.sign.visual.signs.FlagstaffSignVisual;
import vg.sign.visual.signs.FormularSignVisual;
import vg.sign.visual.signs.PointSignVisual;

/**
 * Редактор флагштока.
 *
 * @author Giller
 */
public class FlagstaffSignEditor extends GroupSignEditor {

    // current class logger (log4j)
    private static final Logger log = Logger.getLogger(FlagstaffSignEditor.class);

    /**
     * Контрольная точка точки привязки для дочернего точечного знака.
     *
     * @author Giller
     */
    private static class FlagstaffChildAnchorControlPoint extends AbstractCPoint implements IControlPoint {

        /**
         * Автоматически сгенерированный идентификатор.
         */
        private static final long serialVersionUID = -2658851072163126442L;

        /**
         * Дочерний элемент.
         */
        private FlagstaffSignVisual.FlagstaffChild child;
        /**
         * Визуальное представление флагштока.
         */
        private ISignVisual flagstaffSignVisual;

        /**
         * Конструктор с входным параметром.
         *
         * @param visual визуальное представление флагштока.
         * @param child  дочерний элемент.
         */
        public FlagstaffChildAnchorControlPoint(ISignVisual visual, FlagstaffSignVisual.FlagstaffChild child) {
            this.child = child;
            this.flagstaffSignVisual = visual;
        }


        @Override
        public CPoint calculate() {
            if (!flagstaffSignVisual.getAnchorPoints().isEmpty()) {
                BasePoint2D center = flagstaffSignVisual.getAnchorPoints().get(0).getPoint();

                //point.init(center.getX(), center.getY() + child.getOffset() * flagstaffSignVisual.getScale().getY());
                point = new BasePoint2D(center.getX(), center.getY() + child.getOffset() * flagstaffSignVisual.getScale().getY());

                point.rotate(flagstaffSignVisual.getAngle(), center);
            }
            return this;
        }

        @Override
        public CPoint decalculate() {
            // Для того, чтобы правильно расчитать данные, необходимо полчить проекцию к основной линии флагштока.
            // Дочерний знак флагштока может находиться в точке привязки самого флагштога и для этого случая необходимо
            // искусственно создать линию с углом наклона флагштока, на которую будет расчитываться проекция.

            // Первая точка такой линии уже есть - это точка привязки самого флагштога.
            BasePoint2D center = flagstaffSignVisual.getAnchorPoints().get(0).getPoint();

            // Расчёт второй точки линии.
            BasePoint2D p2 = new BasePoint2D(center.getX(), center.getY() + 10);
            //p2.setY(p2.getY() + 10);
            p2.rotate(flagstaffSignVisual.getAngle(), center);

            // Расчет проекции.
            BasePoint2D p = new BasePoint2D(point);
            p = p.project(center, p2);

            p.rotate(-flagstaffSignVisual.getAngle(), center);

            // Запись расчитанных данных с учётом масштабирования.
            child.setOffset((p.getY() - center.getY()) / flagstaffSignVisual.getScale().getY());
            return this;
        }

        @Override
        public boolean isEditable() {
            return true;
        }

        @Override
        public IControlPoint add() {
            return null;
        }

        @Override
        public boolean remove() {
            return false;
        }
    }


    /**
     * Контрольная точка для предопределённых точек дочернего визуального представления.
     *
     * @author Giller
     */
    private class FlagstaffPredefinedControlPoint extends AbstractCPoint implements IPredefinedControlPoint, IControlPoint {

        /**
         * Автоматически сгенерированный идентификатор.
         */
        private static final long serialVersionUID = -7600093790848771364L;
        /**
         * Контрольная точка.
         */
        private IControlPoint cPoint;
        /**
         * Сдвиг вложенного флагштока.
         */
        private BasePoint2D offset;

        /**
         * Конструктор с входными параметрами.
         *
         * @param cPoint контрольная точка над предопределенной точкой.
         * @param offset сдвиг вложенного флагштока.
         */
        public FlagstaffPredefinedControlPoint(IControlPoint cPoint, BasePoint2D offset) {
            this.cPoint = cPoint;
            this.offset = offset;
        }


        @Override
        public CPoint calculate() {
            this.point = new BasePoint2D(cPoint.getX(), cPoint.getY());
            this.point.add(offset);
            return this;
        }

        @Override
        public CPoint decalculate() {
            BasePoint2D res = new BasePoint2D(point).sub(offset);

            cPoint.setX(res.getX());
            cPoint.setY(res.getY());
            cPoint.decalculate();

            return this;
        }

        @Override
        public boolean isEditable() {
            return cPoint.isEditable();
        }

        @Override
        public void setEditable(boolean editable) {
        }

        @Override
        public IControlPoint add() {
            return null;
        }

        @Override
        public boolean remove() {
            return false;
        }

        @Override
        public int getPredefinedPointIndex() {
            // TODO Метод имеет смысл только для PredefinedControlPoint.
            return -1;
        }

    }


    /**
     * Контрольная точка над контрольной точкой, управляющей предопределенной точкой.
     *
     * @author Giller
     */
    private class ControlPointPredefinedCP extends AbstractCPoint implements IPredefinedControlPoint, IControlPoint {

        /**
         * Автоматически сгенерированный идентификатор.
         */
        private static final long serialVersionUID = 789404128166103176L;
        /**
         * Контрольная точка.
         */
        private IControlPoint controlPoint;
        /**
         * Сдвиг по вертикали.
         */
        private double offset;

        /**
         * Конструктор с входными параметрами.
         *
         * @param point  контрольная точка.
         * @param offset смещение соответсвующего дочернего элемента во флгаштоке.
         */
        public ControlPointPredefinedCP(IControlPoint point, double offset) {
            this.controlPoint = point;
            this.offset = offset;
        }


        @Override
        public CPoint calculate() {
            BasePoint2D scaledShift = new BasePoint2D(0, this.offset)
                    .mul(signVisual.getScale()).rotate(signVisual.getAngle(), 0, 0);

            point = new BasePoint2D(controlPoint.getX(), controlPoint.getY());
            point.add(scaledShift);
            return this;
        }

        @Override
        public CPoint decalculate() {
            BasePoint2D scaledShift = new BasePoint2D(0, this.offset)
                    .mul(signVisual.getScale()).rotate(signVisual.getAngle(), 0, 0);

            BasePoint2D resultPoint = point.sub(scaledShift);

            controlPoint.setX(resultPoint.getX());
            controlPoint.setY(resultPoint.getY());

            controlPoint.decalculate();
            return this;
        }

        @Override
        public boolean isEditable() {
            return controlPoint.isEditable();
        }

        @Override
        public IControlPoint add() {
            return null;
        }

        @Override
        public boolean remove() {
            return false;
        }

        @Override
        public int getPredefinedPointIndex() {
            // TODO Метод имеет смысл только для PredefinedControlPoint.
            return -1;
        }

        @Override
        public void setEditable(boolean editable) {
        }

    }


    /**
     * Класс для редактирования дочернего точечного знака.
     *
     * @author Giller
     */
    private class ChildPointSignEditor extends PointSignEditor {

        /**
         * Дочерний элемент
         */
        private FlagstaffSignVisual.FlagstaffChild child;


        /**
         * Конструктор с входным параметром.
         *
         * @param child дочерний элемент.
         */
        public ChildPointSignEditor(FlagstaffSignVisual.FlagstaffChild child) {
            super((PointSignVisual) child.getVisual());
            this.child = child;
        }

        @Override
        public synchronized void calculate() {
            controlPoints.clear();

            ISignEditor pointSignEditor = SignEditFactory.createEditor(getSignVisual());
            pointSignEditor.calculate();

            // Формирование контрольных точек для регулирования смещения дочерних знаков.
            for (int i = 0, n = getSignVisual().getAnchorPoints().size(); i < n; i++)
                controlPoints.add(new FlagstaffChildAnchorControlPoint(FlagstaffSignEditor.this.signVisual, child));

            for (IControlPoint cPoint : pointSignEditor.getControlPoints())
                if (cPoint instanceof IPredefinedControlPoint)
                    controlPoints.add(new ControlPointPredefinedCP(cPoint, child.getOffset()));

            for (IControlPoint cp : controlPoints)
                if (cp == null)
                    log.debug("NULL!!!");
            CPCalculator.calculate(controlPoints);
        }

    }


    /**
     * Класс для редактирования дочернего флагштока.
     *
     * @author Giller
     */
    private class ChildFlagstafSignEditor extends FlagstaffSignEditor {

        /**
         * Дочерний элемент
         */
        private FlagstaffSignVisual.FlagstaffChild child;


        /**
         * Конструктор с входным параметром.
         *
         * @param child дочерний элемент.
         */
        public ChildFlagstafSignEditor(FlagstaffSignVisual.FlagstaffChild child) {
            super((FlagstaffSignVisual) child.getVisual());
            this.child = child;
        }

        @Override
        public synchronized void calculate() {
            this.controlPoints.clear();

            // Добавление точки привязки.
            for (int i = 0, n = getSignVisual().getAnchorPoints().size(); i < n; i++)
                this.controlPoints.add(new FlagstaffChildAnchorControlPoint(FlagstaffSignEditor.this.signVisual, child));

            ISignEditor editor = SignEditFactory.createEditor(getSignVisual());
            editor.calculate();


            BasePoint2D offset = new BasePoint2D(0, this.child.getOffset())
                    .mul(this.child.getVisual().getScale()).rotate(FlagstaffSignEditor.this.signVisual.getAngle(), 0, 0);

            for (IControlPoint cPoint : editor.getControlPoints())
                if (cPoint instanceof IPredefinedControlPoint)
                    this.controlPoints.add(new FlagstaffPredefinedControlPoint(cPoint, offset));


            for (IControlPoint cp : this.controlPoints)
                if (cp == null)
                    log.debug("NULL!!!");
            CPCalculator.calculate(this.controlPoints);
        }

    }


    /**
     * Класс для редактирования дочернего формуляра.
     *
     * @author Giller
     */
    private class ChildFormularSignEditor extends AbstractSignEditor {

        /**
         * Дочерний элемент
         */
        private FlagstaffSignVisual.FlagstaffChild child;

        /**
         * Конструктор с входным параметром.
         *
         * @param child дочерний элемент.
         */
        public ChildFormularSignEditor(FlagstaffSignVisual.FlagstaffChild child) {
            super((FormularSignVisual) child.getVisual());
            this.child = child;
        }

        @Override
        public synchronized void calculate() {
            controlPoints.clear();

            // Формирование контрольных точек для регулирования смещения дочерних знаков.
            for (int i = 0, n = getSignVisual().getAnchorPoints().size(); i < n; i++)
                controlPoints.add(new FlagstaffChildAnchorControlPoint(FlagstaffSignEditor.this.signVisual, child));

            for (IControlPoint cp : controlPoints)
                if (cp == null)
                    log.debug("NULL!!!");
            CPCalculator.calculate(controlPoints);
        }

    }


    /**
     * Конструктор с входным параметром.
     *
     * @param signVisual визуальное графическое представление.
     */
    public FlagstaffSignEditor(ISignVisual signVisual) {
        super((IGroupSignVisual) signVisual);
    }


    @Override
    public synchronized void calculate() {
        controlPoints.clear();

        for (IGroupSignVisual.IChild child : this.getSignVisual().getChildren()) {
            ISignEditor pse = null;

            if (child.getVisual() instanceof PointSignVisual)
                pse = new ChildPointSignEditor((FlagstaffSignVisual.FlagstaffChild) child);

            else if (child.getVisual() instanceof FlagstaffSignVisual)
                pse = new ChildFlagstafSignEditor((FlagstaffSignVisual.FlagstaffChild) child);

            else if (child.getVisual() instanceof FormularSignVisual)
                pse = new ChildFormularSignEditor((FlagstaffSignVisual.FlagstaffChild) child);

            else
                continue;

            pse.calculate();
            controlPoints.addAll(pse.getControlPoints());
        }

        for (int i = 0, n = signVisual.getAnchorPoints().size(); i < n; i++)
            controlPoints.add(new GroupAnchorControlPoint(signVisual, i));

        CPCalculator.calculate(controlPoints);
    }

}

