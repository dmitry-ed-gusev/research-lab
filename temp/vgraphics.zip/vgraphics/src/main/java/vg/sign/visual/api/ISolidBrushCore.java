package vg.sign.visual.api;


/**
 * Основа сплошной заливки.
 */

public interface ISolidBrushCore extends IBrushCore {}
