package vg.sign.visual.api;


/**
 * Цвет.
 *
 */
public interface IColor {

    /**
     * Маска альфа-канала.
     */
    public static final int CM_A = 0xFF000000;
    /**
     * Маска красного канала.
     */
    public static final int CM_R = 0x00FF0000;
    /**
     * Маска зелёного канала.
     */
    public static final int CM_G = 0x0000FF00;
    /**
     * Маска синего канала.
     */
    public static final int CM_B = 0x000000FF;
    /**
     * Маска RGB каналов.
     */
    public static final int CM_RGB = 0x00FFFFFF;
    /**
     * Маска ARGB каналов.
     */
    public static final int CM_ARGB = 0xFFFFFFFF;

}
