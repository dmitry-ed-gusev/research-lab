package vg.sign.building.modifiers;

import vg.sign.building.api.IGroupPreModifier;
import vg.sign.building.api.IPreBuildModifier;
import vg.sign.visual.api.ISignVisual;

import java.util.ArrayList;
import java.util.List;

/**
 * Групповой предварительный модификатор.
 *
 * @author Giller
 */
public class GroupPreModifier extends AbstractPreModifier implements IGroupPreModifier {

    /**
     * Перечень предварительных модификаторов.
     */
    private List<IPreBuildModifier> elements = new ArrayList<IPreBuildModifier>();


    @Override
    public void modify(ISignVisual visual) {
        for (int i = 0; i < elements.size(); ++i)
            elements.get(i).modify(visual);
    }

    @Override
    public List<IPreBuildModifier> getElements() {
        return this.elements;
    }
}
