package vg.sign.visual.signs;

import vg.sign.visual.api.IBrush;
import vg.sign.visual.api.IGraphElement;
import vg.sign.visual.api.IPen;
import vg.sign.visual.api.IText;

import java.util.UUID;

/**
 * Адаптер графического элемента.
 *
 */
public abstract class AbstractGraphElement implements IGraphElement {

    /**
     * ID.
     */
    protected String id;
    /**
     * Название графического элемента
     */
    protected String name = "Графический элемент";
    /**
     * Редактируемость элемента.
     */
    protected boolean editable = true;
    /**
     * Видимость графического элемента.
     */
    protected boolean visible = true;


    /**
     * @param name Наименование графического элемента.
     */
    public AbstractGraphElement(String name) {
        id = UUID.randomUUID().toString();
        this.name = name;
    }

    /***/
    public AbstractGraphElement() {
        id = UUID.randomUUID().toString();
    }


    @Override
    public AbstractGraphElement clone() {
        try {
            AbstractGraphElement clonedObject = (AbstractGraphElement) super.clone();
            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }


    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean isEditable() {
        return editable;
    }

    @Override
    public void setEditable(boolean editable) {
        this.editable = editable;
    }

    @Override
    public boolean isVisible() {
        return visible;
    }

    @Override
    public void setVisible(boolean visible) {
        this.visible = visible;
    }


    @Override
    public IPen getPen() {
        return null;
    }

    @Override
    public void setPen(IPen pen) {
    }

    @Override
    public IBrush getBrush() {
        return null;
    }

    @Override
    public void setBrush(IBrush brush) {
    }

    @Override
    public IText getText() {
        return null;
    }

    @Override
    public void setText(IText text) {
    }

}
