package vg.sign.building.api;

import vg.sign.attributes.api.IAttribute;

import java.util.List;

/**
 * Премодификатор на основе атрибутов.
 */
public interface IAttributesPreBuildModifier extends IPreBuildModifier {

    /**
     * Получить атрибуты.
     *
     * @return Атрибуты.
     */
    public List<IAttribute> getAttributes();

}
