package vg.sign.visual.api;


/**
 * Градиентная основа заливки.
 *
 */
public interface IGradientBrushCore extends IBrushCore {

    /**
     * Получить начальный цвет.
     *
     * @return Начальный цвет.
     * @note Функция аналогична {@link IPenElement#getColor()}.
     */
    public int getColor1();

    /**
     * Задать начальный цвет.
     *
     * @param color Начальный цвет.
     * @param mask  Маска назначения цвета.
     *              <p>Будут заданы только те биты цвета, которые соответствуют единичным битам маски.
     *              <p>См. {@link IColor#CM_A}, {@link IColor#CM_R}, {@link IColor#CM_G}, {@link IColor#CM_B},
     *              {@link IColor#CM_RGB}, {@link IColor#CM_ARGB}.
     * @note Функция аналогична {@link IPenElement#setColor(int, int)}.
     */
    public void setColor1(int color, int mask);

    /**
     * Получить конечный цвет.
     *
     * @return Конечный цвет.
     */
    public int getColor2();

    /**
     * Задать конечный цвет.
     *
     * @param color Конечный цвет.
     * @param mask  Маска назначения цвета.
     *              <p>Будут заданы только те биты цвета, которые соответствуют единичным битам маски.
     *              <p>См. {@link IColor#CM_A}, {@link IColor#CM_R}, {@link IColor#CM_G}, {@link IColor#CM_B},
     *              {@link IColor#CM_RGB}, {@link IColor#CM_ARGB}.
     */
    public void setColor2(int color, int mask);

}
