package vg.sign.visual.api;

import java.util.List;

/**
 * Перо.
 *
 */
public interface IPen extends Cloneable {

    /**
     * Интерфейс перечня элементов пера.
     *
     * @author Giller
     */
    public interface IPenElementsList extends List<IPenElement> {
        /**
         * Получить редактируемость перечня элементов пера.
         *
         * @return редактируемость перечня элементов пера.
         */
        public boolean isEditable();
    }


    /**
     * Клонирование.
     *
     * @return Клон.
     */
    public IPen clone();

    /**
     * Получить список элементов пера.
     *
     * @return Список элементов пера.
     */
    public IPenElementsList getElements();
//	public List<IPenElement> getElements();

}
