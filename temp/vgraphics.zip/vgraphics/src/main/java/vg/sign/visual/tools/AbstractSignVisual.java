package vg.sign.visual.tools;

import vg.geometry.primitives.BasePoint2D;
import vg.sign.visual.api.IAnchorPointsList;
import vg.sign.visual.api.IRootGraphElement;
import vg.sign.visual.api.ISignVisual;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.UUID;

/**
 * Визуальное представление знака.
 */
public abstract class AbstractSignVisual implements ISignVisual /*, Externalizable*/ {

    /***/
    private static final long serialVersionUID = -8239736065890428735L;
    /**
     * Уникальный идентификатор.
     */
    protected String id = UUID.randomUUID().toString();
    /**
     * Точки привязки.
     */
    protected IAnchorPointsList anchorPoints;
    /**
     * Корневой графический элемент.
     */
    protected IRootGraphElement rootGraphElement;
    /**
     * Масштабный коэффициент знака.
     */
    protected BasePoint2D scale = new BasePoint2D(1.0, 1.0);
    /**
     * Угол поворота знака.
     */
    protected double angle = 0.0;
    /**
     * Видимость.
     */
    protected boolean visible = true;
    /**
     * Вращаемость.
     */
    protected boolean rotated = true;
    /**
     * Масштабируемость.
     */
    protected boolean scaled = true;


    @Override
    public AbstractSignVisual clone() {
        try {
            AbstractSignVisual clonedObject = (AbstractSignVisual) super.clone();

            clonedObject.anchorPoints = anchorPoints.clone();
            //clonedObject.scale = scale.clone();

            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }


    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public IAnchorPointsList getAnchorPoints() {
        return anchorPoints;
    }

    @Override
    public IRootGraphElement getRootGraphElement() {
        return rootGraphElement;
    }

    @Override
    public boolean isVisible() {
        return visible;
    }

    @Override
    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    @Override
    public boolean isMirrored() {
        return scale.getX() * scale.getY() < 0;
    }

    @Override
    public void setMirrored(boolean mirrored) {
        if (mirrored != this.isMirrored())
            scale = new BasePoint2D(-scale.getX(), scale.getY());
    }

    @Override
    public BasePoint2D getScale() {
        return scale;
    }

    @Override
    public void setScale(BasePoint2D scale) {
        this.scale = scale;
    }

    @Override
    public double getAngle() {
        return angle;
    }

    @Override
    public void setAngle(double angle) {
        this.angle = angle;
    }

    @Override
    public boolean isRotatable() {
        return this.rotated;
    }

    @Override
    public void setRotatable(boolean rotated) {
        this.rotated = rotated;
    }

    @Override
    public boolean isScalable() {
        return this.scaled;
    }

    @Override
    public void setScalable(boolean scaled) {
        this.scaled = scaled;
    }

    /*
    // todo: !!!!! temporary commented !!!!!
    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        IVisualSource vs = VisualSourceFactory.createBpgdSignVisualSource(out);
        vs.exportSignVisual(this);
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        IVisualSource vs = VisualSourceFactory.createBpgdSignVisualSource(in);
        vs.importSignVisual(this);
    }
    */
}
