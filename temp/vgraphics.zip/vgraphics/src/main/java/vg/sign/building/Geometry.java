package vg.sign.building;

import vg.sign.building.api.IGeometry;

/**
 * Класс с геометрическими характеристиками.
 *
 * @author Giller
 */

public class Geometry implements IGeometry {

    /**
     * Угол.
     */
    private double angle;
    /**
     * Ширина.
     */
    private double width;
    /**
     * Высота.
     */
    private double height;
    /**
     * Длина
     */
    private double length;
    /**
     * Площадь.
     */
    private double space;
    /**
     * Радиус.
     */
    private double radius;
    /**
     * Диагональ.
     */
    private double diagonal;

    // Конструкторы.

    /**
     * Конструктор с входными параметрами.
     *
     * @param angle    угол.
     * @param width    ширина.
     * @param height   высота.
     * @param length   длина.
     * @param space    площадь.
     * @param radius   радиус.
     * @param diagonal диагональ.
     */
    public Geometry(double angle, double width, double height, double length, double space, double radius, double diagonal) {
        this.angle = angle;
        this.width = width;
        this.height = height;
        this.length = length;
        this.space = space;
        this.radius = radius;
        this.diagonal = diagonal;
    }

    // Методы

    /*
     * Получить угол.
     * @return угол.
     */
    @Override
    public double getAngle() {
        return this.angle;
    }

    /*
     * Установить угол.
     * @param angle угол.
     */
    @Override
    public void setAngle(double angle) {
        this.angle = angle;
    }

    /*
     * Получить ширину.
     * @return ширина.
     */
    @Override
    public double getWidth() {
        return this.width;
    }

    /*
     * Установить ширину.
     * @param width ширина.
     */
    @Override
    public void setWidth(double width) {
        this.width = width;
    }

    /*
     * Получить высоту.
     * @return высота.
     */
    @Override
    public double getHeight() {
        return this.height;
    }

    /*
     * Установить высоту.
     * @param height высота.
     */
    @Override
    public void setHeight(double height) {
        this.height = height;
    }

    /*
     * Получить длину.
     * @return длина.
     */
    @Override
    public double getLength() {
        return this.length;
    }

    /*
     * Установить длину.
     * @param length длина.
     */
    @Override
    public void setLength(double length) {
        this.length = length;
    }

    /*
     * Получить площадь.
     * @return площадь.
     */
    @Override
    public double getSpace() {
        return this.space;
    }

    /*
     * Установить площадь.
     * @param space площадь.
     */
    @Override
    public void setSpace(double space) {
        this.space = space;
    }

    /*
     * Получить радиус.
     * @return радиус.
     */
    @Override
    public double getRadius() {
        return this.radius;
    }

    /*
     * Установить радиус.
     * @param radius радиус.
     */
    @Override
    public void setRadius(double radius) {
        this.radius = radius;
    }

    /**
     * Получить диагональ.
     *
     * @return диагональ.
     */
    @Override
    public double getDiagonal() {
        return this.diagonal;
    }

    /**
     * Установить диагональ.
     *
     * @param diagonal диагональ.
     */
    @Override
    public void setDiagonal(double diagonal) {
        this.diagonal = diagonal;
    }
}
