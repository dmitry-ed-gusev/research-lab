package vg.sign.core;

import vg.sign.attributes.api.IAttribute;
import vg.sign.core.api.IGroupSign;
import vg.sign.core.api.ISign;
import vg.sign.generalization.api.IGeneralization;
import vg.sign.placing.api.IPlacingRules;
import vg.sign.visual.api.IGroupSignVisual;
import vg.sign.visual.api.ISignVisual;

import java.util.List;

/**
 * Фабрика знака.
 */
public final class SignFactory {

    private SignFactory() {

    }

    /**
     * Создать знак.
     *
     * @param visual         Визуальное представление знака.
     * @param attrs          перечень атрибутов.
     * @param generalization правила генерализации.
     * @param placingRules   правила нанесения.
     * @param deep           - флаг создания дерева ГЭУЗ.
     *                       Если deep == true и visual - это Визуальное представление Группового ЭУЗ,
     *                       то по дереву Визуального представления будет создано дерево ГЭУЗ.
     * @return Знак.
     */
    public static ISign createSign(ISignVisual visual, List<IAttribute> attrs, IGeneralization generalization, IPlacingRules placingRules, boolean deep) {
        if (visual == null) return null;
        Sign sign;
        if (visual instanceof IGroupSignVisual) {
            // The group sign and his child tree is built here.
            IGroupSignVisual groupVisual = (IGroupSignVisual) visual;
            GroupSign groupSign = new GroupSign(groupVisual);
            sign = groupSign;

            // Building the group sign child tree.
            if (deep)
                for (IGroupSignVisual.IChild child : groupVisual.getChildren()) {
                    ISign childSign = createSign(child.getVisual(), null, null, null, true);
                    if (childSign != null)
                        groupSign.getChildren().add(childSign);
                }
        } else {
            // Simply creating the single Sign;
            sign = new Sign(visual);

        }

        sign.setAttributes(attrs);
        sign.setGeneralization(generalization);
        sign.setPlacingRules(placingRules);

        // Calculating the sign;
        sign.calculate();
        return sign;
    }

    /**
     * Создать знак.
     *
     * @param visual Визуальное представление знака.
     * @return Знак.
     */
    public static ISign createSign(ISignVisual visual) {
        return new Sign(visual);
    }

    /**
     * Создать групповой знак.
     *
     * @param visual Визуальное представление знака.
     * @return Групповой знак.
     */
    public static IGroupSign createGroupSign(ISignVisual visual) {
        return new GroupSign((IGroupSignVisual) visual);
    }

}