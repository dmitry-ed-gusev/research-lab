package vg.sign.attributes.api;


/**
 * Тип атрибута.
 */
public interface IAttributeType extends Cloneable {

    @Override
    public String toString();

    /**
     * Проверить значение атрибута.
     *
     * @param value Значение атрибута.
     * @return Результат проверки.
     */
    public boolean check(IAttributeValue value);

    /**
     * Клонировать объект.
     *
     * @return Клон.
     */
    public IAttributeType clone();

}
