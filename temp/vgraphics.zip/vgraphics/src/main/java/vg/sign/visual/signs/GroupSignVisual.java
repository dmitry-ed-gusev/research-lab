package vg.sign.visual.signs;

import vg.geometry.GeometryUtils;
import vg.sign.visual.api.IAnchorPoint;
import vg.sign.visual.api.IGraphElement;
import vg.sign.visual.api.IGroupSignVisual;
import vg.sign.visual.api.ISignVisual;
import vg.sign.visual.tools.AbstractSignVisual;
import vg.sign.visual.tools.AnchorPointsList;
import vg.sign.visual.tools.RootGraphElement;
import vg.utils.Filter;
import vg.utils.ListReference;

import java.util.AbstractList;
import java.util.List;

/**
 * Групповой знак.
 *
 * @author Giller
 */
public class GroupSignVisual extends AbstractSignVisual implements IGroupSignVisual {

    /**
     * Дочерний элемент.
     *
     * @author Giller
     */
    public static class Child implements IChild {

        /**
         * Визуальное представление знака.
         */
        private ISignVisual visual;
        /**
         * Идентификатор визуального представления.
         */
        private String id;

        /**
         * Конструктор с входным параметром.
         *
         * @param visual визуальное представление знака.
         */
        public Child(ISignVisual visual) {
            if (visual != null)
                this.id = visual.getId();

            this.visual = visual;
        }

        @Override
        public String getSignVisualId() {
            return this.id;
        }

        @Override
        public void setSignVisualId(String id) {
            this.id = id;
        }

        @Override
        public ISignVisual getVisual() {
            return this.visual;
        }

        @Override
        public void setSignVisual(ISignVisual visual) {
            if (visual != null)
                this.id = visual.getId();

            this.visual = visual;
        }

        @Override
        public GroupSignVisual.Child clone() {
            try {
                GroupSignVisual.Child clonedObject = (GroupSignVisual.Child) super.clone();
                clonedObject.visual = visual != null ? visual.clone() : null;
                return clonedObject;
            } catch (CloneNotSupportedException ex) {
                throw new RuntimeException(ex);
            }
        }
    }


    /**
     * Перечень знаков.
     *
     * @author Giller.
     */
    protected class ChildrenList extends ListReference<IChild> implements IChildrenList {

        /**
         * Минимальный размер.
         */
        private int minSize = 0;
        /**
         * Максимальный размер.
         */
        private int maxSize = Integer.MAX_VALUE;
        /**
         * Фильтр.
         */
        private Filter<IChild> filter = null;


        /**
         * @param minSize Минимальное количество элементов.
         * @param maxSize Максимальное количество элементов.
         * @param filter  Фильтр элементов.
         */
        public ChildrenList(int minSize, int maxSize, Filter<IChild> filter) {
            this.minSize = minSize;
            this.maxSize = maxSize;
            this.filter = filter;
        }

        /**
         * @param filter Фильтр элементов.
         */
        public ChildrenList(Filter<IChild> filter) {
            this(0, Integer.MAX_VALUE, filter);
        }

        /***/
        @SuppressWarnings("unchecked")
        public ChildrenList() {
            this(0, Integer.MAX_VALUE, Filter.TRUE);
        }


        @Override
        public int getMaxSize() {
            return maxSize;
        }

        @Override
        public int getMinSize() {
            return minSize;
        }

        @Override
        public Filter<IChild> getFilter() {
            return filter;
        }

        /**
         * Установить фильтр.
         *
         * @param filter фильтр.
         */
        void setFilter(Filter<IChild> filter) {
            this.filter = filter;
        }

        @Override
        public void add(int index, IChild child) {
            // Проверка размера.
            if (size() == this.maxSize)
                throw GeometryUtils.createSizeOutOfBoundsException(size() + 1, minSize, maxSize);
            // Проверка фильтром.
            if (!filter.filter(child))
                throw GeometryUtils.createIllegalArgumentException(child.toString(), child);
            super.add(index, child);
        }

        @Override
        public IChild set(int index, IChild child) {
            // Проверка фильтром.
            if (!filter.filter(child))
                throw GeometryUtils.createIllegalArgumentException(child.toString(), child);
            return super.set(index, child);
        }

    }


    /**
     * Список графических элементов корневого графического элемента Группового ЭУЗ.
     *
     */
    private class SelfGraphElementsList extends AbstractList<IGraphElement> {

        /**
         * Графический элемент для представления null-евой ссылки в объекте ISign.
         */
        private final IGraphElement EMPTY_GRAPH_ELEMENT = new AbstractGraphElement() {
        };

        /***/
        public SelfGraphElementsList() {
        }

        @Override
        public int size() {
            return children.size();
        }

        @Override
        public IGraphElement get(int index) {
            ISignVisual childVisual = children.get(index).getVisual();
            return childVisual != null ? childVisual.getRootGraphElement() : EMPTY_GRAPH_ELEMENT;
        }

        @Override
        public IGraphElement set(int index, IGraphElement element) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean add(IGraphElement e) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean remove(Object o) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void clear() {
            throw new UnsupportedOperationException();
        }

    }


    /**
     * Перечень дочерних знаков.
     */
    protected ChildrenList children = new ChildrenList();
    /**
     * Флаг - является ли группа временной.
     */
    private boolean temporary = false;


    /**
     * Конструктор по умолчанию.
     */
    public GroupSignVisual() {
        anchorPoints = new AnchorPointsList(1, 1);
        rootGraphElement = new RootGraphElement("Групповой ЭУЗ", this, new SelfGraphElementsList());
    }


    @Override
    public GroupSignVisual clone() {
        GroupSignVisual clonedObject = (GroupSignVisual) super.clone();
        cloneGroupSignVisual(clonedObject);
        return clonedObject;
    }

    /**
     * Клонирование специфичных для группы (и разных для разных типов групп) элементов.
     *
     * @param clonedObject Уже созданный клон, в котором надо доклонировать поля.
     */
    protected void cloneGroupSignVisual(GroupSignVisual clonedObject) {
        clonedObject.children = new ChildrenList();
        for (IChild child : children)
            clonedObject.children.add(child.clone());

        clonedObject.rootGraphElement = new RootGraphElement(
                new String(this.rootGraphElement.getName()),
                clonedObject,
                clonedObject.new SelfGraphElementsList());
    }


    @Override
    public List<IChild> getChildren() {
        return this.children;
    }

    @Override
    public boolean isTemporary() {
        return temporary;
    }

    @Override
    public void setTemporary(boolean temporary) {
        this.temporary = temporary;
    }

    @Override
    public void createDefaultSemantics(int index, IAnchorPoint anchorPoint) {
    }

}
