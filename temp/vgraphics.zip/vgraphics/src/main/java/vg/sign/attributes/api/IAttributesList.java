package vg.sign.attributes.api;


import java.util.List;


/**
 * Перечень атрибутов.
 */
public interface IAttributesList extends List<IAttribute> {

    /**
     * Дочерний элемент перечня атрибутов.
     *
     * @author Giller
     */
    public interface IChild extends Cloneable {

        /**
         * Получить идентификатор.
         *
         * @return идентификатор.
         */
        public String getId();

        /**
         * Установить идентификатор.
         *
         * @param id идентификатор.
         */
        public void setId(String id);

        /**
         * Получить перечень атрибутов.
         *
         * @return перечень атрибутов.
         */
        public IAttributesList getAttributesList();

        /**
         * Установить перечень атрибутов.
         *
         * @param attrsList перечень атрибутов.
         */
        public void setAttributesList(IAttributesList attrsList);

        /**
         * Клонирование.
         *
         * @return клон.
         */
        public IChild clone();

    }


    /**
     * Получить перечень дочерних атрибутов.
     *
     * @return перечень дочерних атрибутов.
     */
    public List<IAttributesList.IChild> getChildren();

    /**
     * Получить идентификатор перечня дополнительных признаков.
     *
     * @return идентификатор перечня дополнительных признаков.
     */
    public String getId();

    /**
     * Установить идентификатор перечня дополнительных признаков.
     *
     * @param id идентификатор перечня дополнительных признаков.
     */
    public void setId(String id);

    /**
     * Клонирование перечня атрибутов.
     *
     * @return клон переченя атрибутов.
     */
    public IAttributesList clone();

}
