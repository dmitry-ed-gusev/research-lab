package vg.sign.visual.tools;

import vg.geometry.primitives.BasePoint2D;
import vg.sign.visual.api.IAnchorPoint;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

/**
 * Точка привязки.
 */
public class AnchorPoint implements IAnchorPoint {

    /**
     * Координаты.
     */
    private BasePoint2D point;
    /**
     * Смысловое значение.
     */
    private Map<String, Object> semantic = new HashMap<String, Object>();


    /***/
    public AnchorPoint() {
        this.point = new BasePoint2D();
    }

    /**
     * @param point    Координаты точки.
     * @param semantic Смысловые значения.
     */
    public AnchorPoint(BasePoint2D point, Object... semantic) {
        this.point = point;
        for (int i = 0, n = semantic.length - 1; i < n; i++)
            this.semantic.put(semantic[i].toString(), semantic[i + 1]);
    }

    /**
     * @param point    Координаты точки.
     * @param semantic Смысловые значения.
     */
    public AnchorPoint(BasePoint2D point, Map<String, Object> semantic) {
        this.point = point;
        this.semantic.putAll(semantic);
    }


    @Override
    public AnchorPoint clone() {
        try {
            AnchorPoint clonedObject = (AnchorPoint) super.clone();
            clonedObject.point = new BasePoint2D(point);
            clonedObject.semantic = new HashMap<String, Object>();
            for (String key : this.semantic.keySet()) {
                Object value = this.semantic.get(key);
                if (value != null && value instanceof Cloneable) {
                    clonedObject.semantic.put(new String(key), cloneObject(value));
                } else {
                    clonedObject.semantic.put(new String(key), value);
                }
            }
            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }


    @Override
    public String toString() {
        return point.toString();
    }


    @Override
    public BasePoint2D getPoint() {
        return point;
    }

    @Override
    public void setPoint(BasePoint2D point) {
        this.point = point;
    }

    @Override
    public Map<String, Object> getSemantic() {
        return semantic;
    }

    /**
     * Клонировать объект.
     *
     * @param src Клонируемый объект.
     * @return Клон объекта.
     */
    private static Object cloneObject(Object src) {
        Object clone = null;
        try {
            Class.forName(src.getClass().getName()).getMethod("clone").setAccessible(true);
            clone = Class.forName(src.getClass().getName()).getMethod("clone").invoke(src);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException();
        } catch (SecurityException e) {
            throw new RuntimeException();
        } catch (IllegalAccessException e) {
            throw new RuntimeException();
        } catch (InvocationTargetException e) {
            throw new RuntimeException();
        } catch (NoSuchMethodException e) {
            throw new RuntimeException();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException();
        }
        return clone;
    }

}
