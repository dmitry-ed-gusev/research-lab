package vg.sign.visual.api;


import java.util.Iterator;


/**
 * Интерфейс - маркер для пера группового графического элемента.
 *
 * @author Giller
 */
public interface ISelfPen extends IPen {

    /**
     * Получить сквозной итератор по элементам пера.
     *
     * @return сквозной итератор по элементам пера.
     */
    public Iterator<IPenElement> getThroughIterator();

}
