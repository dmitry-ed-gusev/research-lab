package vg.sign.visual.signs;

import vg.sign.visual.api.ISignVisual;
import vg.utils.Filter;

/**
 * Флагшток.
 *
 * @author Giller
 */
public class FlagstaffSignVisual extends GroupSignVisual {

    /**
     * Дочерний элемент флагштока.
     *
     * @author Giller
     */
    public static class FlagstaffChild extends Child {

        /**
         * Смещение дочернего знака по вертикали относительно точки привязки флагштока.
         */
        private double offset;

        /**
         * Конструктор с входным параметром.
         *
         * @param visual визуальное представление знака.
         */
        public FlagstaffChild(ISignVisual visual) {
            super(visual);
        }

        /**
         * Конструктор с входным параметром.
         *
         * @param visual визуальное представление знака.
         * @param offset свдиг по вертикали.
         */
        public FlagstaffChild(ISignVisual visual, double offset) {
            super(visual);
            this.offset = offset;
        }

        /**
         * Получить смешение по вертикали.
         *
         * @return смещение по вертикали.
         */
        public double getOffset() {
            return this.offset;
        }

        /**
         * Установить смещение по вертикали.
         *
         * @param offset смещение по вертикали.
         */
        public void setOffset(double offset) {
            this.offset = offset;
        }

        @Override
        public FlagstaffSignVisual.FlagstaffChild clone() {
            FlagstaffSignVisual.FlagstaffChild clonedObject = (FlagstaffSignVisual.FlagstaffChild) super.clone();
            clonedObject.offset = offset;
            return clonedObject;
        }

    }

    /**
     * Фильтр для дочерних элементов флагштока.
     *
     * @author Giller
     */
    private class FlagstaffChildFilter implements Filter<IChild> {
        /**
         * Конструктор по умолчанию.
         */
        public FlagstaffChildFilter() {
        }

        @Override
        public boolean filter(IChild child) {
            if (child instanceof FlagstaffChild &&
                    (child.getVisual() instanceof PointSignVisual
                            || child.getVisual() instanceof FlagstaffSignVisual
                            || child.getVisual() instanceof FormularSignVisual
                            || child.getVisual() == null))
                return true;
            return false;
        }
    }


    /**
     * Конструктор по умолчанию.
     */
    public FlagstaffSignVisual() {
        setRotatable(false);
        getRootGraphElement().setName("Совмещённый КП");
        children.setFilter(new FlagstaffChildFilter());
    }

    @Override
    public FlagstaffSignVisual clone() {
        FlagstaffSignVisual clone = (FlagstaffSignVisual) super.clone();
        return clone;
    }

}
