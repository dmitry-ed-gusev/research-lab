package vg.sign.visual.tools;

import vg.sign.visual.api.IGraphElement;
import vg.sign.visual.api.IRootGraphElement;
import vg.sign.visual.api.ISignVisual;

import java.util.List;

/**
 * Корневой Графический элемент Визуалного представления ЭУЗ.
 */
public class RootGraphElement extends GroupGraphElement implements IRootGraphElement {

    /**
     * Визуальное представление ЭУЗ.
     */
    protected ISignVisual parentSignVisual;


    /**
     * Конструктор с входными параметрами.
     *
     * @param name             Название графического элемента.
     * @param parentSignVisual Визуальное представление ЭУЗ.
     * @param elements         Дочерние элементы.
     */
    public RootGraphElement(String name, ISignVisual parentSignVisual, List<IGraphElement> elements) {
        super(name);
        this.parentSignVisual = parentSignVisual;
        this.graphElements = elements;
    }

    @Override
    public RootGraphElement clone() {
        throw new UnsupportedOperationException();
    }

    @Override
    public ISignVisual getParentSignVisual() {
        return parentSignVisual;
    }

}
