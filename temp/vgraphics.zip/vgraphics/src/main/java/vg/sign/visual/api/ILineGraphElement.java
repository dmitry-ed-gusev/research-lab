package vg.sign.visual.api;

/**
 * Грфический элемент, описывающий конкретную фигуру.
 *
 */
public interface ILineGraphElement extends IGraphElement {

    @Override
    public ILineGraphElement clone();

    /**
     * Получить гладкость линии.
     *
     * @return Гладкость линии.
     */
    public boolean isSmooth();

    /**
     * Задать гладкость линии.
     *
     * @param smooth Гладкость линии.
     */
    public void setSmooth(boolean smooth);

    /**
     * Получить признак замкнутости линии.
     *
     * @return Замкнутость линии.
     */
    public boolean isClosed();

    /**
     * Задать замкнутость линии.
     *
     * @param closed Замкнутость линии.
     */
    public void setClosed(boolean closed);

}
