package vg.sign.visual.table;

import vg.sign.visual.api.IText;

/**
 * Текстовое содержимое ячейки.
 *
 * @author Giller
 */
public interface ITextCellContent extends ICellContent {

    /**
     * Получить текст.
     *
     * @return текст.
     */
    public IText getText();

    /**
     * Установить текст.
     *
     * @param text текст.
     */
    public void setText(IText text);

}