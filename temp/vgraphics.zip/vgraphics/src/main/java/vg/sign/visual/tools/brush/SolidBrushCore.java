package vg.sign.visual.tools.brush;


import vg.sign.visual.api.ISolidBrushCore;

/**
 * Сплошная заливка.
 */
public class SolidBrushCore implements ISolidBrushCore {

    @Override
    public SolidBrushCore clone() {
        try {
            SolidBrushCore clonedObject = (SolidBrushCore) super.clone();
            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }

}
