package vg.sign.building.modifiers;

import vg.sign.building.api.IPreBuildModifier;

/**
 * Абстрактный премодификатор.
 */
public abstract class AbstractPreModifier implements IPreBuildModifier {

    /**
     * Флаг включённости модификатора.
     */
    private boolean enabled = true;


    /***/
    public AbstractPreModifier() {
    }


    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

}
