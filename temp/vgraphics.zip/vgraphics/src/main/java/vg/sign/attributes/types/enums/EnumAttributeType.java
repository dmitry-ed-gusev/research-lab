package vg.sign.attributes.types.enums;

import vg.sign.attributes.api.IAttributeType;
import vg.sign.attributes.api.IAttributeValue;

import java.util.ArrayList;
import java.util.List;

/**
 * Тип атрибута: перечисление.
 */
public class EnumAttributeType implements IAttributeType {

    /**
     * Строки.
     */
    private List<String> list;

    /***/
    public EnumAttributeType() {
        this.list = new ArrayList<String>();
    }

    /**
     * @param strings Строки.
     */
    public EnumAttributeType(String... strings) {
        super();
        this.list = new ArrayList<String>();
        for (String s : strings) {
            list.add(s);
        }
    }


    @Override
    public EnumAttributeType clone() {
        try {
            EnumAttributeType clonedObject = (EnumAttributeType) super.clone();
            clonedObject.list = new ArrayList<String>();
            for (String v : list)
                clonedObject.list.add(v);
            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public String toString() {
        return "type=enum: " + list.toString();
    }

    @Override
    public boolean check(IAttributeValue value) {
        return ((value instanceof EnumAttributeValue) && (((EnumAttributeValue) value).getValue() < list.size()));
    }

    /**
     * Получить значения.
     *
     * @return Значения.
     */
    public List<String> getStrings() {
        return list;
    }

    /***/
    public int getListSize() {
        return (this.list == null ? 0 : this.list.size());
    }

    /***/
    public boolean isListEmpty() {
        return (this.list == null ? true : this.list.isEmpty());
    }

}