package vg.sign.building.api;

import vg.draw.vobject.VGObject;

/**
 * Модификатор изображения после построения.
 */
public interface IPostBuildModifier {

    /**
     * Получить флаг включённости модификатора.
     * Данный флаг не влияет на работу модификатора и должен проверяться во внешнем коде.
     *
     * @return Флаг включённости модификатора.
     */
    public boolean isEnabled();

    /**
     * Включить/выключить модификатор.
     * Данный флаг не влияет на работу модификатора и должен проверяться во внешнем коде.
     *
     * @param enabled Флаг включённости модификатора.
     */
    public void setEnabled(boolean enabled);

    /**
     * Модифицировать изображение после построения.
     *
     * @param image Изображение.
     */
    public void modify(VGObject image);

}
