package vg.sign.attributes;

import vg.SignDefaults;
import vg.sign.attributes.api.IAttribute;
import vg.sign.attributes.api.IAttributesList;
import vg.sign.building.api.IAttributesPreBuildModifier;
import vg.sign.building.modifiers.AttributeFormularModifier;

import java.util.Date;
import java.util.List;

/**
 * Реализация фабрики атрибутов.
 * Фабрика реализована в виде утилитного класса (нельзя унаследоваться и создать инстанс).
 */

// todo: temporary commented almost all methods
public final class AttributesFactory {

    private AttributesFactory() {
        // приватный конструктор для неинстанцируемости
    }

/*
    */
/**
     * Создать логический тип атрибута.
     *
     * @return Логический тип атрибута.
     *//*

    public static BooleanAttributeType createBooleanAttributeType() {
        return new BooleanAttributeType();
    }

    */
/**
     * Создать целочисленный тип атрибута.
     *
     * @return Целочисленный тип атрибута.
     *//*

    public static IntegerAttributeType createIntegerAttributeType() {
        return new IntegerAttributeType();
    }

    */
/**
     * Создать дробный тип атрибута.
     *
     * @return Дробный тип атрибута.
     *//*

    public static FloatAttributeType createFloatAttributeType() {
        return new FloatAttributeType();
    }

    */
/**
     * Создать строковый тип атрибута.
     *
     * @return Строковый тип атрибута.
     *//*

    public static StringAttributeType createStringAttributeType() {
        return new StringAttributeType();
    }

    */
/**
     * Создать временной тип атрибута.
     *
     * @return Временной тип атрибута.
     *//*

    public static TimeAttributeType createTimeAttributeType() {
        return new TimeAttributeType();
    }

    */
/**
     * Создать перечислимый тип атрибута.
     *
     * @return Перечислимый тип атрибута.
     *//*

    public static EnumAttributeType createEnumAttributeType() {
        return new EnumAttributeType();
    }

    */
/**
     * Создать перечислимый тип атрибута.
     *
     * @param strings Значения.
     * @return Перечислимый тип атрибута.
     *//*

    public static EnumAttributeType createEnumAttributeType(String... strings) {
        return new EnumAttributeType(strings);
    }

    */
/**
     * Создать логическое значение атрибута.
     *
     * @param value Значение.
     * @return Логическое значение атрибута.
     *//*

    public static BooleanAttributeValue createBooleanAttributeValue(boolean value) {
        return new BooleanAttributeValue(value);
    }

    */
/**
     * Создать целочисленное значение атрибута.
     *
     * @return Целочисленное значение атрибута.
     *//*

    public static IntegerAttributeValue createIntegerAttributeValue() {
        return new IntegerAttributeValue();
    }

    */
/**
     * Создать целочисленное значение атрибута.
     *
     * @param value Значение.
     * @return Целочисленное значение атрибута.
     *//*

    public static IntegerAttributeValue createIntegerAttributeValue(int value) {
        return new IntegerAttributeValue(value);
    }

    */
/**
     * Создать целочисленный тип атрибута.
     *
     * @param minimum Минимальное значение.
     * @param maximum Максимальное значение.
     * @return Целочисленный тип атрибута.
     *//*

    public static IntegerAttributeType createIntegerAttributeType(int minimum, int maximum) {
        return new IntegerAttributeType(minimum, maximum);
    }

    */
/**
     * Создать Дробное значение атрибута.
     *
     * @return Дробное значение атрибута.
     *//*

    public static FloatAttributeValue createFloatAttributeValue() {
        return new FloatAttributeValue();
    }

    */
/**
     * Создать Дробное значение атрибута.
     *
     * @param value Значение.
     * @return Дробное значение атрибута.
     *//*

    public static FloatAttributeValue createFloatAttributeValue(double value) {
        return new FloatAttributeValue(value);
    }

    */
/**
     * Создать дробный тип атрибута.
     *
     * @param minimum Минимальное значение.
     * @param maximum Максимальное значение.
     * @return Дробный тип атрибута.
     *//*

    public static FloatAttributeType createFloatAttributeType(double minimum, double maximum) {
        return new FloatAttributeType(minimum, maximum);
    }

    */
/**
     * Создать дробный тип атрибута.
     *
     * @param minimum        Минимальное значение.
     * @param maximum        Максимальное значение.
     * @param precisionLimit Предел точности.
     * @return Дробный тпи атрибута.
     *//*

    public static FloatAttributeType createFloatAttributeType(double minimum, double maximum, int precisionLimit) {
        return new FloatAttributeType(minimum, maximum, precisionLimit);
    }

    */
/**
     * Создать строковое значение атрибута.
     *
     * @param value Значение.
     * @return Строковое значение атрибута.
     *//*

    public static StringAttributeValue createStringAttributeValue(String value) {
        return new StringAttributeValue(value);
    }

    */
/**
     * Создать временное значение атрибута.
     *
     * @param value Значение.
     * @param mode  Режим отображения.
     * @return Временное значение атрибута.
     *//*

    public static TimeAttributeValue createTimeAttributeValue(Date value, SignDefaults.TimeMode mode) {
        return new TimeAttributeValue(value, mode);
    }

    */
/**
     * Создать перечислимое значение атрибута.
     *
     * @param value Значение.
     * @return Перечислимое значение атрибута.
     *//*

    public static EnumAttributeValue createEnumAttributeValue(int value) {
        return new EnumAttributeValue(value);
    }

    */
/**
     * Создать премодификатор на основе атрибута: признак действия.
     *
     * @param index Значение атрибута по умолчанию.
     * @return Премодификатор на основе атрибута: признак действия.
     *//*

    public static IAttributesPreBuildModifier createActionPreModifier(int index) {
        return new ActionPreModifier(index);
    }

    */
/**
     * Создать премодификатор на основе атрибута: состояние.
     *
     * @param index Значение атрибута по умолчанию.
     * @return Премодификатор на основе атрибута: состояние.
     *//*

    public static IAttributesPreBuildModifier createStatePreModifier(int index) {
        return new StatePreModifier(index);
    }

    */
/**
     * Создать премодификатор на основе атрибута: госпринадлежность.
     *
     * @param index Значение атрибута по умолчанию.
     * @return Премодификатор на основе атрибута: госпринадлежность.
     *//*

    public static IAttributesPreBuildModifier createCountryPreModifier(int index) {
        return new CountryPreModifier(index);
    }

    */
/**
     * Создать атрибут: сокращённое наименование ЭУЗ.
     *
     * @param shortName Сокращённое наименование ЭУЗ.
     * @return Атрибут.
     *//*

    public static ShortNameAttribute createShortNameAttribute(String shortName) {
        return new ShortNameAttribute(shortName);
    }

    */
/**
     * Создать премодификатор на основе атрибута: текст.
     *
     * @param index Индекс текстового элемента.
     * @return Премодификатор на основе атрибута: текст.
     *//*

    public static IAttributesPreBuildModifier createTextModifier(int index) {
        return new TextPreModifier(index);
    }

    */
/**
     * Создать атрибут.
     *
     * @return Атрибут.
     *//*

    public static IAttribute createAttribute() {
        return new Attribute();
    }

    */
/**
     * Создать тип атрибута: госпринадлежность.
     *
     * @return Тип атрибута: госпринадлежность.
     *//*

    public static CountryAttributeType createCountryAttributeType() {
        return new CountryAttributeType();
    }

    */
/**
     * Создать значение атрибута: госпринадлежность.
     *
     * @return Значение атрибута: госпринадлежность.
     *//*

    public static CountryAttributeValue createCountryAttributeValue() {
        return new CountryAttributeValue();
    }

    */
/**
     * Создать тип атрибута: признак действия.
     *
     * @return Тип атрибута: признак действия.
     *//*

    public static ActionAttributeType createActionAttributeType() {
        return new ActionAttributeType();
    }

    */
/**
     * Создать значение атрибута: признак действия.
     *
     * @return Значение атрибута: признак действия.
     *//*

    public static ActionAttributeValue createActionAttributeValue() {
        return new ActionAttributeValue();
    }

    */
/**
     * Создать тип атрибута: состояние.
     *
     * @return Тип атрибута: состояние.
     *//*

    public static StateAttributeType createStateAttributesType() {
        return new StateAttributeType();
    }

    */
/**
     * Создать значение атрибута: состояние.
     *
     * @return Значение атрибута: состояние.
     *//*

    public static StateAttributeValue createStateAttributeValue() {
        return new StateAttributeValue();
    }

    */
/**
     * Создать значение атрибута: госпринадлежность.
     *
     * @param defaultValueIndex Индекс значения по умолчанию.
     * @return Значение атрибута: госпринадлежность.
     *//*

    public static CountryAttributeValue createCountryAttributeValue(int defaultValueIndex) {
        return new CountryAttributeValue(defaultValueIndex);
    }

    */
/**
     * Создать значение атрибута: признак действия.
     *
     * @param defaultValueIndex Индекс значения по умолчанию.
     * @return Значение атрибута: признак действия.
     *//*

    public static ActionAttributeValue createActionAttributeValue(int defaultValueIndex) {
        return new ActionAttributeValue(defaultValueIndex);
    }

    */
/**
     * Создать значение атрибута: состояние.
     *
     * @param defaultValueIndex Индекс значения по умолчанию.
     * @return Значение атрибута: состояние.
     *//*

    public static StateAttributeValue createStateAttributeValue(int defaultValueIndex) {
        return new StateAttributeValue(defaultValueIndex);
    }

    */
/**
     * Создать строковый тип атрибута.
     *
     * @param maxLineLength Максимальная длина строки.
     * @param maxLinesCount Максимальное количество строк.
     * @return Строковый тип атрибута.
     *//*

    public static StringAttributeType createStringAttributeType(int maxLineLength, int maxLinesCount) {
        return new StringAttributeType(maxLineLength, maxLinesCount);
    }

    */
/**
     * Создать атрибут: наименование ЭУЗ.
     *
     * @param EUZName Наименование ЭУЗ.
     * @return Атрибут.
     *//*

    public static EUZNameAttribute createEUZNameAttribute(String EUZName) {
        return new EUZNameAttribute(EUZName);
    }

    */
/**
     * Создать атрибут: наименование ЭУЗ.
     *
     * @param EUZName       Наименование ЭУЗ.
     * @param attributeName Имя атрибута.
     * @return Атрибут.
     *//*

    public static EUZNameAttribute createEUZNameAttribute(String EUZName, String attributeName) {
        return new EUZNameAttribute(EUZName, attributeName);
    }

    */
/**
     * Создать атрибут: условное наименование ЭУЗ.
     *
     * @param name Условное наименование ЭУЗ.
     * @return Атрибут.
     *//*

    public static NameAttribute createNameAttribute(String name) {
        return new NameAttribute(name);
    }

    */
/**
     * Создать атрибут: условное наименование ЭУЗ.
     *
     * @param name          Условное наименование ЭУЗ.
     * @param attributeName Имя атрибута.
     * @return Атрибут.
     *//*

    public static NameAttribute createNameAttribute(String name, String attributeName) {
        return new NameAttribute(name, attributeName);
    }

    */
/**
     * Создать атрибут: сокращённое наименование ЭУЗ.
     *
     * @param shortName     Сокращённое наименование ЭУЗ.
     * @param attributeName Имя атрибута.
     * @return Атрибут.
     *//*

    public static ShortNameAttribute createShortNameAttribute(String shortName, String attributeName) {
        return new ShortNameAttribute(shortName, attributeName);
    }

    */
/**
     * Создать модификатор текста графического элемента по значению атрибута.
     *
     * @return Модификатор текста графического элемента.
     */

    public static IAttributesPreBuildModifier createAttributeFormularModifier() {
        return new AttributeFormularModifier();
    }

/**
     * Создать тип атрибута: класскод.
     *
     * @return Тип атрибута: класскод.
     *//*

    public static ClassCodeAttributeType createClassCodeAttributeType() {
        return new ClassCodeAttributeType();
    }

    */
/**
     * Создать тип атрибута: класскод.
     *
     * @param baseCode Базовый класскод.
     * @param codes    Значения доппрзнаков.
     * @return Значение атрибута: класскод.
     *//*

    public static ClassCodeAttributeType createClassCodeAttributeType(String baseCode, String... codes) {
        return new ClassCodeAttributeType(baseCode, codes);
    }

    */
/**
     * Создать значение атрибута: класскод.
     *
     * @param attributes Атрибуты.
     * @param type       Тип этого атрибута.
     * @return Значение атрибута: класскод.
     *//*

    public static ClassCodeAttributeValue createClassCodeAttributeValue(List<IAttribute> attributes, ClassCodeAttributeType type) {
        return new ClassCodeAttributeValue(attributes, type);
    }

    */
/**
     * Создать тип атрибута: доппризнак.
     *
     * @return Тип атрибута: доппризнак.
     *//*

    public static IAdditionalAttributeType createAdditionalAttributeType() {
        return new AdditionalAttributeType();
    }

    */
/**
     * Создать тип атрибута: доппризнак.
     *
     * @param initialCode Индекс по умолчанию.
     * @return Тип атрибута: доппризнак.
     *//*

    public static IAdditionalAttributeType createAdditionalAttributeType(int initialCode) {
        return new AdditionalAttributeType(initialCode);
    }

    */
/**
     * Создать значение атрибута: доппризнак.
     *
     * @return Значение атрибута: доппризнак.
     *//*

    public static IAdditionalAttributeValue createAdditionalAttributeValue() {
        return new AdditionAttributeValue();
    }

    */
/**
     * Создать значение атрибута: доппризнак.
     *
     * @param code Индекс значения из типа.
     * @return Значение атрибута: доппризнак.
     *//*

    public static IAdditionalAttributeValue createAdditionalAttributeValue(int code) {
        return new AdditionAttributeValue(code);
    }

*/
    /**
     * Создать перечень атрибутов.
     *
     * @return перечень атрибутов.
     */
    public static IAttributesList createAttributesList() {
        return new AttributesList();
    }

    /**
     * Создать дочерний элемент перечня атрибутов.
     *
     * @param attrsList перечень атрибутов.
     * @return дочерний элемент перечня атрибутов.
     */
    public static IAttributesList.IChild createChild(IAttributesList attrsList) {
        return new AttributesList.Child(attrsList);
    }

}