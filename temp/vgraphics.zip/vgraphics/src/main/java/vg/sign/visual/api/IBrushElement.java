package vg.sign.visual.api;

/**
 * Элемент заливки.
 *
 */
public interface IBrushElement extends Cloneable {

    /**
     * Клонирование.
     *
     * @return Клон.
     */
    IBrushElement clone();

    /**
     * Инициализация элемента заливки на основе заданного.
     *
     * @param brushElement элемент заливки для инициализации.
     */
    public void init(IBrushElement brushElement);

    /**
     * Получить цвет заливки.
     *
     * @return Цвет заливки.
     */
    public int getColor();

    /**
     * Задать цвет.
     *
     * @param color Цвет.
     * @param mask  Маска назначения цвета.
     *              <p>Будут заданы только те биты цвета, которые соответствуют единичным битам маски.
     *              <p>См. {@link IColor#CM_A}, {@link IColor#CM_R}, {@link IColor#CM_G}, {@link IColor#CM_B},
     *              {@link IColor#CM_RGB}, {@link IColor#CM_ARGB}.
     */
    public void setColor(int color, int mask);

    /**
     * Получить основу заливки.
     *
     * @return Основа заливки.
     */
    public IBrushCore getCore();

    /**
     * Задать основу заливки.
     *
     * @param core Основа заливки.
     */
    public void setCore(IBrushCore core);

    /**
     * Получить угол (рад.)
     *
     * @return Угол.
     */
    public double getAngle();

    /**
     * Задать угол.
     *
     * @param angle Угол (рад.).
     */
    public void setAngle(double angle);

}
