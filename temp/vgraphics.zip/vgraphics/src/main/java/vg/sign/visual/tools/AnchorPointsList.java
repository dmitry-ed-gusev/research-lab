package vg.sign.visual.tools;

import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.visual.api.IAnchorPoint;
import vg.sign.visual.api.IAnchorPointsList;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

/**
 * Список точек привязки.
 */
public class AnchorPointsList extends AbstractList<IAnchorPoint> implements IAnchorPointsList {

    /**
     * Список точек привязки.
     */
    private List<IAnchorPoint> list = new ArrayList<IAnchorPoint>();
    /**
     * Минимальное количество точек привязки.
     */
    private int minSize = 0;
    /**
     * Максимальное количество точек привязки.
     */
    private int maxSize = Integer.MAX_VALUE;


    /***/
    public AnchorPointsList() {
        this(0, Integer.MAX_VALUE);
    }

    /**
     * @param minSize Минимальное количество точек привязки.
     * @param maxSize Максимальное количество точек привязки.
     */
    public AnchorPointsList(int minSize, int maxSize) {
        this.minSize = minSize;
        this.maxSize = maxSize;
    }


    @Override
    public AnchorPointsList clone() {
        try {
            AnchorPointsList clonedObject = (AnchorPointsList) super.clone();

            clonedObject.list = new ArrayList<IAnchorPoint>();
            for (IAnchorPoint ap : list)
                clonedObject.list.add(ap.clone());

            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }


    @Override
    public int getMinSize() {
        return minSize;
    }

    @Override
    public int getMaxSize() {
        return maxSize;
    }

    @Override
    public int size() {
        return list.size();
    }

    @Override
    public IAnchorPoint get(int index) {
        return list.get(index);
    }

    @Override
    public IAnchorPoint set(int index, IAnchorPoint element) {
        return list.set(index, element);
    }

    @Override
    public BasePoint2D set(int index, BasePoint2D point) {
        IAnchorPoint anchorPoint = list.set(index, new AnchorPoint(point));
        return anchorPoint != null ? anchorPoint.getPoint() : point;
    }

    @Override
    public void add(int index, IAnchorPoint element) {
        if (list.size() >= maxSize)
            throw GeometryUtils.createSizeOutOfBoundsException(list.size() + 1, minSize, maxSize);
        list.add(index, element);
    }

    @Override
    public void add(int index, BasePoint2D point) {
        if (list.size() >= maxSize)
            throw GeometryUtils.createSizeOutOfBoundsException(list.size() + 1, minSize, maxSize);
        list.add(index, new AnchorPoint(point));
    }

    @Override
    public void add(BasePoint2D point) {
        if (list.size() >= maxSize)
            throw GeometryUtils.createSizeOutOfBoundsException(list.size() + 1, minSize, maxSize);
        list.add(new AnchorPoint(point));
    }

    @Override
    public IAnchorPoint remove(int index) {
        if (list.size() <= minSize)
            throw GeometryUtils.createSizeOutOfBoundsException(list.size() - 1, minSize, maxSize);
        return list.remove(index);
    }

    @Override
    public void clear() {
//		if (minSize > 0)
//			throw PlatformUtils.createSizeOutOfBoundsException(0, minSize, maxSize);
        list.clear();
    }

}
