package vg.sign.visual.signs;

import vg.SignDefaults;
import vg.sign.visual.api.*;
import vg.sign.visual.tools.AbstractSignVisual;
import vg.sign.visual.tools.AnchorPointsList;
import vg.sign.visual.tools.GroupGraphElement;
import vg.sign.visual.tools.RootGraphElement;
import vg.sign.visual.tools.pen.Pen;
import vg.sign.visual.tools.pen.PenElement;
import vg.sign.visual.tools.pen.SolidPenCore;

import java.util.ArrayList;
import java.util.List;

/**
 * Позиционный район.
 *
 */
public class PositionAreaSignVisual extends AbstractSignVisual {

    /**
     * Ключ, по которому можно получить знак узла.
     */
    public final static String NODE_SIGN_KEY = "sign";

    /**
     * Графический элемент узла линии.
     *
     */
    private class NodeGraphElement extends AbstractGraphElement {


        /**
         * @param name Наименование.
         */
        public NodeGraphElement(String name) {
            super(name);
        }


        @Override
        public IPen getPen() {
            return PositionAreaSignVisual.this.nodePen;
        }

        @Override
        public void setPen(IPen pen) {
            PositionAreaSignVisual.this.nodePen = pen;
        }

    }

    /**
     * Графический элемент сегмента линии.
     *
     */
    private class SegmentGraphElement extends AbstractGraphElement {


        /**
         * @param name Наименование.
         */
        public SegmentGraphElement(String name) {
            super(name);
        }

        @Override
        public IPen getPen() {
            return PositionAreaSignVisual.this.linePen;
        }

        @Override
        public void setPen(IPen pen) {
            PositionAreaSignVisual.this.linePen = pen;
        }

    }


    /**
     * Контейнер с узловым знаком и коэффициентом масштабирования.
     *
     */
    public static class NodeSign implements Cloneable {

        /**
         * Знак.
         */
        private PointSignVisual visual;
        /**
         * Масштабный коэффициент.
         */
        private double scale;
        /**
         * Угол.
         */
        private double angle;


        /**
         * @param visual Знак.
         * @param scale  Коэффициент масштабирования.
         * @param angle  Угол.
         */
        public NodeSign(PointSignVisual visual, double scale, double angle) {
            this.visual = visual;
            this.scale = scale;
            this.angle = angle;
        }

        /***/
        public NodeSign() {
            this(null, 1.0, 0.0);
        }


        /**
         * Получить масштаб.
         *
         * @return Масштаб.
         */
        public double getScale() {
            return scale;
        }

        /**
         * Задать масштаб.
         *
         * @param scale Масштаб.
         */
        public void setScale(double scale) {
            this.scale = scale;
        }

        /**
         * Получить знак.
         *
         * @return Знак.
         */
        public PointSignVisual getSignVisual() {
            return visual;
        }

        /**
         * Задать знак.
         *
         * @param visual Знак.
         */
        public void setSignVisual(PointSignVisual visual) {
            this.visual = visual;
        }

        @Override
        public NodeSign clone() {
            try {
                NodeSign ns = (NodeSign) super.clone();
                ns.visual = visual != null ? visual.clone() : null;
                return ns;
            } catch (CloneNotSupportedException e) {
                throw new RuntimeException(e);
            }
        }

        /**
         * Получить угол.
         *
         * @return Задать угол.
         */
        public double getAngle() {
            return angle;
        }

        /**
         * Задать угол.
         *
         * @param angle Угол.
         */
        public void setAngle(double angle) {
            this.angle = angle;
        }

    }


    /**
     * Тип знака.
     */
    private SignDefaults.MilitaryAreaType type;
    /**
     * Перо для отрисовки узла.
     */
    private IPen nodePen;
    /**
     * Перо для отрисовки линии.
     */
    private IPen linePen;
    /**
     * Радиус узла.
     */
    private double nodeRadius;
    /**
     * Знак узла по умолчанию.
     */
    private PointSignVisual defaultNodeSignVisual;


    /**
     * @param type            Тип.
     * @param nodePen         Перо узла.
     * @param linePen         Перо линий.
     * @param nodeRadius      Радиус узла.
     * @param defaultNodeSign Знак узла по умолчанию.
     */
    public PositionAreaSignVisual(SignDefaults.MilitaryAreaType type, IPen nodePen, IPen linePen, double nodeRadius, PointSignVisual defaultNodeSign) {
        super();
        this.type = type;
        this.nodePen = nodePen;
        this.linePen = linePen;
        this.nodeRadius = nodeRadius;
        this.anchorPoints = new AnchorPointsList(2, Integer.MAX_VALUE);

        List<IGraphElement> graphElements = new ArrayList<IGraphElement>();
        graphElements.add(new SegmentGraphElement("Соединительные линии"));
        IGroupGraphElement nodes = new GroupGraphElement("Узлы");
        graphElements.add(new NodeGraphElement("Контуры узлов"));
        IGroupGraphElement defaultNode = new GroupGraphElement("Узел по умолчанию");
        nodes.getElements().add(defaultNode);
        if (defaultNodeSignVisual != null) {
            defaultNode.getElements().add(defaultNodeSignVisual.getRootGraphElement());
        }
        graphElements.add(nodes);
        this.rootGraphElement = new RootGraphElement(type == SignDefaults.MilitaryAreaType.POSITION_AREA ? "Позиционный район" : "Район базирования", null, graphElements);

        this.update();
    }

    /***/
    public PositionAreaSignVisual() {
        this(
                SignDefaults.MilitaryAreaType.POSITION_AREA,
                new Pen(new PenElement(new SolidPenCore(), 0xFFFF0000, 0.5, 0.0, 0.0)),
                new Pen(new PenElement(new SolidPenCore(), 0xFFFF0000, 0.5, 0.0, 0.0)),
                5.0,
                null);
    }


    @Override
    public PositionAreaSignVisual clone() {
        PositionAreaSignVisual clone = (PositionAreaSignVisual) super.clone();
        clone.type = this.type;
        if (this.nodePen != null)
            clone.nodePen = this.nodePen.clone();
        if (this.linePen != null)
            clone.linePen = this.linePen.clone();
        clone.defaultNodeSignVisual = (this.defaultNodeSignVisual == null) ? null : this.defaultNodeSignVisual.clone();
        clone.update();
        return clone;
    }

    /**
     * Получить тип района.
     *
     * @return Тип района.
     */
    public SignDefaults.MilitaryAreaType getType() {
        return type;
    }

    /**
     * Задать тип района.
     *
     * @param type Тип района.
     */
    public void setType(SignDefaults.MilitaryAreaType type) {
        this.type = type;
    }

    /**
     * Получить перо отрисовки узла.
     *
     * @return Перо отрисовки узла.
     */
    public IPen getNodePen() {
        return nodePen;
    }

    /**
     * Задать перо отрисовки узла.
     *
     * @param pen Перо отрисовки узла.
     */
    public void setNodePen(IPen pen) {
        this.nodePen = pen;
    }

    /**
     * Получить перо для отрисовки соединительных линий.
     *
     * @return Перо для отрисовки соединительных линий.
     */
    public IPen getLinePen() {
        return linePen;
    }

    /**
     * Задать перо для отрисовки соединительных линий.
     *
     * @param pen Перо для отрисовки соединительных линий.
     */
    public void setLinePen(IPen pen) {
        this.linePen = pen;
    }

    /**
     * Получить радиус узла.
     *
     * @return Радиус узла.
     */
    public double getNodeRadius() {
        return nodeRadius;
    }

    /**
     * Задать радиус узла.
     *
     * @param radius Радиус узла.
     */
    public void setNodeRadius(double radius) {
        this.nodeRadius = radius;
    }

    /**
     * Получить знак узла по умолчанию.
     *
     * @return Знак узла по умолчанию.
     */
    public PointSignVisual getDefaultNodeSign() {
        return defaultNodeSignVisual;
    }

    /**
     * Задать знак узла по умолчанию.
     *
     * @param visual Знак узла по умолчанию.
     */
    public void setDefaultNodeSign(PointSignVisual visual) {
        this.defaultNodeSignVisual = visual;
    }

    /**
     * Обновить данные знака.
     */
    public void update() {
        this.rootGraphElement.setName(type == SignDefaults.MilitaryAreaType.POSITION_AREA ? "Позиционный район" : "Район базирования");

        IGroupGraphElement nodes = (IGroupGraphElement) rootGraphElement.getElements().get(2);
        ((IGroupGraphElement) nodes.getElements().get(0)).getElements().clear();

        if (defaultNodeSignVisual != null) {
            ((IGroupGraphElement) nodes.getElements().get(0)).getElements().add(defaultNodeSignVisual.getRootGraphElement());
        }

        IGraphElement baseSignGraphElement = nodes.getElements().get(0);
        nodes.getElements().clear();
        nodes.getElements().add(baseSignGraphElement);

        int i = 0;
        for (IAnchorPoint ap : anchorPoints) {
            NodeSign container = (NodeSign) ap.getSemantic().get(NODE_SIGN_KEY);
            IGroupGraphElement node = new GroupGraphElement("Узел " + ++i);
            if (container != null) {
                PointSignVisual psv = container.getSignVisual();
                if (psv != null) {
                    IRootGraphElement rge = psv.getRootGraphElement();
                    node.getElements().add(rge);
                }
            }
            nodes.getElements().add(node);
        }
    }

    @Override
    public void createDefaultSemantics(int index, IAnchorPoint anchorPoint) {
        ISignVisual defaultNodeSign = getDefaultNodeSign();
        if (defaultNodeSign != null) {
            anchorPoint.getSemantic().put(NODE_SIGN_KEY, new NodeSign(getDefaultNodeSign().clone(), 1.0, 0.0));
        } else {
            anchorPoint.getSemantic().put(NODE_SIGN_KEY, new NodeSign(null, 1.0, 0.0));
        }
    }

}
