package vg.sign.building.api;

import vg.draw.vobject.VGObject;

/**
 * Интерфейс для работы с графическим элементов с расчитанными параметрами.
 */
public interface ICalculatedGraph {

    /**
     * Получить геометрические характеристики.
     *
     * @return геометрические характеристики.
     */
    public IGeometry getGeometry();

    /**
     * Установить геометрические характеристики.
     *
     * @param geometry геометрические характеристики.
     */
    public void setGemetry(IGeometry geometry);

    /**
     * Получить графический объект.
     *
     * @return графический объект.
     */
    public VGObject getImage();

    /**
     * Установить графический объект.
     *
     * @param gObject графический объект.
     */
    public void setImage(VGObject gObject);
}
