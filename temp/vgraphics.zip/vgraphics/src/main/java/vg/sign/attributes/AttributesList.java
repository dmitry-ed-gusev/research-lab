package vg.sign.attributes;

import vg.sign.attributes.api.IAttribute;
import vg.sign.attributes.api.IAttributesList;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Перечень атрибутов.
 * @author Giller
 */
public class AttributesList extends ArrayList<IAttribute> implements IAttributesList {

    /**
     * Потомок перечня дополнительных признаков.
     *
     * @author Giller
     */
    public static class Child implements IAttributesList.IChild {

        /**
         * Идентификатор потомка.
         */
        private String id = UUID.randomUUID().toString();
        /**
         * Перечень атрибутов.
         */
        private IAttributesList attributesList;

        /**
         * Создание потомка перечня атрибутов.
         *
         * @param attrsList перечень атрибутов.
         */
        public Child(IAttributesList attrsList) {
            this.attributesList = attrsList;
            if (attributesList != null)
                this.id = this.attributesList.getId();
        }

        @Override
        public String getId() {
            return this.id;
        }

        @Override
        public void setId(String id) {
            this.id = id;
        }

        @Override
        public IAttributesList getAttributesList() {
            return this.attributesList;
        }

        @Override
        public void setAttributesList(IAttributesList attrsList) {
            if (attrsList != null)
                this.id = attrsList.getId();
            this.attributesList = attrsList;
        }

        @Override
        public IChild clone() {
            try {
                Child clone = (Child) super.clone();
                if (attributesList != null)
                    clone.attributesList = attributesList.clone();
                else
                    clone.attributesList = null;

                return clone;
            } catch (CloneNotSupportedException e) {
                throw new RuntimeException("Ошибка при клонировании");
            }
        }

    }


    /**
     * Автоматически сгенерированный идентификатор.
     */
    private static final long serialVersionUID = -6696743003010805518L;

    /**
     * Перечень дочерних атрибутов.
     */
    private List<IChild> children = new ArrayList<IAttributesList.IChild>();
    /**
     * Идентификатор перечня атрибутов.
     */
    private String id = UUID.randomUUID().toString();


    @Override
    public List<IAttributesList.IChild> getChildren() {
        return this.children;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public IAttributesList clone() {
        AttributesList clone = new AttributesList();

        for (IAttribute attr : this)
            clone.add(attr.clone());

        clone.id = new String(id);
        for (IAttributesList.IChild ch : this.children)
            clone.getChildren().add(ch.clone());

        return clone;
    }

}
