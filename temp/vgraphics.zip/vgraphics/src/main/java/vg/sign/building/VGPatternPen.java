package vg.sign.building;

import vg.draw.ViewParams;
import vg.draw.painting.IPainter;
import vg.draw.painting.LineParams;
import vg.draw.vobject.VGBasicPen;
import vg.draw.vobject.VGPen;
import vg.geometry.GeometryProcessor;
import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BaseFrame2D;
import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.visual.SignVisualFactory;
import vg.sign.visual.api.IPenPattern;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import static vg.geometry.GeometryDefaults.RAD_TO_GRAD;

/**
 * Шаблонное перо графической подсистемы.
 */
//TODO Рассмотреть возможность наслдования от VGBasicPen.
public class    VGPatternPen implements VGPen {

    /**
     * Абстрактный курсор по линии.
     *
     */
    private static abstract class Cursor {

        /**
         * Индекс начала исследуемого сегмента.
         */
        int begin;
        /**
         * Индекс конца исследуемого сегмента.
         */
        int end;


        /**
         * Конструктор, устанавливающий индексы на первый отрезок.
         */
        Cursor() {
            begin = 0;
            end = 1;
        }


        /**
         * Инициализировать этот курсор другим курсором,
         * т.е. совместить их позиции.
         *
         * @param c Курсор.
         */
        void init(Cursor c) {
            this.begin = c.begin;
            this.end = c.end;
        }

        /**
         * Получить текущую точку под курсором.
         *
         * @return Точка под курсором.
         */
        abstract BasePoint2D point();

        /**
         * Получить следующий сегмент (сместить курсор на следующую позицию).
         *
         * @return Следующий сегмент.
         */
        abstract List<BasePoint2D> next();

    }

    /**
     * Курсор по сегментам линии.
     *
     */
    private static class SegmentsIterable implements Iterable<List<BasePoint2D>> {

        /**
         * Курсор по длине линии.
         *
         */
        private class LengthCursor extends Cursor {

            /**
             * Суммарная длина линии.
             */
            private double lineLength;
            /**
             * Текущая позиция на линии.
             */
            private double position;
            /**
             * Шаг приращения курсора.
             */
            private double step;
            /**
             * Точка под курсором.
             */
            private BasePoint2D point;


            /**
             * @param step Шаг приращения курсора.
             */
            @SuppressWarnings("synthetic-access")
            public LengthCursor(double step) {
                super();
                this.position = 0.0;
                this.step = step;
                this.point = points.get(0);
                this.lineLength = GeometryProcessor.getPolylineLength(points);
            }


            @SuppressWarnings("synthetic-access")
            @Override
            List<BasePoint2D> next() {
                if (GeometryUtils.isNear(position, lineLength)) {
                    return null;
                }
                double offset = position;
                if (position + step < lineLength) {
                    position += step;
                    begin = GeometryProcessor.getPointCountOnPolylineBeforeShift(points, position / lineLength, 0) - 1;
                    end = begin + 1;
                    point = GeometryProcessor.getPointOnPolylineByShift(points, position / lineLength);
                    List<BasePoint2D> list = new ArrayList<BasePoint2D>();
                    for (BasePoint2D p : GeometryProcessor.getSubPolyline(points, 0, offset, step)) {
                        list.add(p);
                    }
                    return list;
                } else {
                    double smallStep = lineLength - position;
                    position = lineLength;
                    end = points.size() - 1;
                    begin = end - 1;
                    point = points.get(end);
                    List<BasePoint2D> list = new ArrayList<BasePoint2D>();
                    for (BasePoint2D p : GeometryProcessor.getSubPolyline(points, 0, offset, smallStep)) {
                        list.add(p);
                    }
                    return list;
                }
            }

            @Override
            BasePoint2D point() {
                return point;
            }

            @SuppressWarnings("synthetic-access")
            @Override
            void init(Cursor c) {
                super.init(c);
                this.point = c.point();
                List<BasePoint2D> line = new ArrayList<BasePoint2D>();
                for (int i = 0; i < end; i++) {
                    line.add(points.get(i));
                }
                double preLength = GeometryProcessor.getPolylineLength(line);
                double rest = GeometryUtils.distanceBetweenPoints(points.get(begin), point);
                this.position = preLength + rest;
            }

        }


        /**
         * Курсор по радиусу. Производит сечение линии в радиусе действия.
         *
         */
        private class RadiusCursor extends Cursor {

            /**
             * Точка под курсором.
             */
            private BasePoint2D point;
            /**
             * Раиус.
             */
            private double radius;
            /**
             * Вспомогательнный флаг.
             */
            boolean started;


            /**
             * @param radius Радиус действия курсора.
             */
            @SuppressWarnings("synthetic-access")
            public RadiusCursor(double radius) {
                super();
                this.radius = radius;
                this.point = points.get(0);
                this.started = false;
            }


            @SuppressWarnings("synthetic-access")
            @Override
            List<BasePoint2D> next() {
                if (point.equals(points.get(points.size() - 1)) && started) {
                    return null;
                }
                started = true;
                List<BasePoint2D> segment = new ArrayList<BasePoint2D>();
                segment.add(point());
                while (end < points.size()) {
                    if (GeometryUtils.distanceBetweenPoints(point(), points.get(end)) > radius) {
                        begin = end - 1;
                        point = getIntersection(point, radius, points.get(begin), points.get(end));
                        segment.add(point());
                        return segment;
                    }
                    end++;
                }
                begin = points.size() - 2;
                end = points.size() - 1;
                point = points.get(points.size() - 1);
                segment.add(point);
                return segment;
            }

            @Override
            BasePoint2D point() {
                return point;
            }

            @Override
            void init(Cursor c) {
                super.init(c);
                this.point = c.point();
            }

        }


        /**
         * Точки линии.
         */
        private List<BasePoint2D> points;
        /**
         * Курсор по радиусу.
         */
        private Cursor radiusCursor;
        /**
         * Курсор по длине.
         */
        private Cursor lengthCursor;
        /**
         * Полученные сегменты.
         */
        private List<List<BasePoint2D>> segments;
        /**
         * Длина сегмента.
         */
        private double size;


        /**
         * @param points   Точки линии.
         * @param baseSize Длина сегмента.
         */
        public SegmentsIterable(List<BasePoint2D> points, double baseSize) {
            this.points = new ArrayList<BasePoint2D>(points.size());
            for (int i = 0; i < points.size(); i++) {
                this.points.add(new BasePoint2D(points.get(i)));
            }
            this.size = baseSize;
            this.radiusCursor = new RadiusCursor(baseSize);
            this.lengthCursor = new LengthCursor(baseSize);
            this.segments = new ArrayList<List<BasePoint2D>>();
            this.initSegments();
        }


        /**
         * Проинициализировать сегменты.
         */
        private void initSegments() {
            List<BasePoint2D> lengthSegment = null;
            List<BasePoint2D> radiusSegment = null;
            while (true) {
                lengthSegment = lengthCursor.next();
                radiusSegment = radiusCursor.next();
                if (lengthSegment == null || radiusSegment == null) {
                    break;
                }
                if (GeometryUtils.distanceBetweenPoints(lengthCursor.point(), radiusCursor.point()) > 0.01 * size) {
                    radiusCursor.init(lengthCursor);
                    segments.add(lengthSegment);
                } else {
                    lengthCursor.init(radiusCursor);
                    segments.add(radiusSegment);
                }
            }
            if (segments.size() > 2) {
                BasePoint2D anchor = GeometryProcessor.nearestPointOnPolyline(points, segments.get(segments.size() - 2).get(0));
                double length = 0.0;
                for (int i = points.size() - 2; i > -1; i--) {
                    BasePoint2D end = points.get(i + 1);
                    BasePoint2D begin = points.get(i);
                    if (GeometryProcessor.isPointOnPolyline(new BasePoint2D(anchor), new BasePoint2D(begin), new BasePoint2D(end))) {
                        length += GeometryUtils.distanceBetweenPoints(end, anchor);
                        break;
                    }
                    length += GeometryUtils.distanceBetweenPoints(end, begin);
                }
                double position = GeometryProcessor.getPolylineLength(points) - length;
                length /= 2.0;
                List<BasePoint2D> preLast = GeometryProcessor.getSubPolyline(points, 0, position, length);
                List<BasePoint2D> last = GeometryProcessor.getSubPolyline(points, 0, position + length, length - 0.01);
                List<BasePoint2D> pl = new ArrayList<BasePoint2D>();
                for (BasePoint2D p : preLast) {
                    pl.add(p);
                }
                List<BasePoint2D> l = new ArrayList<BasePoint2D>();
                for (BasePoint2D p : last) {
                    l.add(p);
                }
                segments.set(segments.size() - 2, pl);
                segments.set(segments.size() - 1, l);
            } else if (segments.size() == 1) {
                segments.set(0, points);
            } else if (segments.size() == 2) {
                double lineLength = GeometryProcessor.getPolylineLength(points);
                List<BasePoint2D> preLast = GeometryProcessor.getSubPolyline(points, 0, 0, lineLength / 2.0);
                List<BasePoint2D> last = GeometryProcessor.getSubPolyline(points, 0, lineLength / 2.0, lineLength / 2.0 - 0.01);
                List<BasePoint2D> pl = new ArrayList<BasePoint2D>();
                for (BasePoint2D p : preLast) {
                    pl.add(p);
                }
                List<BasePoint2D> l = new ArrayList<BasePoint2D>();
                for (BasePoint2D p : last) {
                    l.add(p);
                }
                segments.set(0, pl);
                segments.set(1, l);
            }
        }

        @Override
        public Iterator<List<BasePoint2D>> iterator() {
            return segments.iterator();
        }

    }

    /**
     * Цвет.
     */
    private int color;
    /**
     * Толщина линий.
     */
    private double width;
    /**
     * Шаблон.
     */
    private IPenPattern pattern;

    // Поля для кеширования данных, необходимы для оптимизации отрисовки.
    /**
     * Длина линии при последнем пересчёте.
     */
    private double lastLength;
    /**
     * Последныы сохранённая начальная точка.
     */
    private BasePoint2D lastBeginPoint;
    /**
     * Последняя сохранённая конечная точка.
     */
    private BasePoint2D lastEndPoint;
    /**
     * Сохранённые для отрисовки линии.
     */
    private List<BasePoint2D[]> lines;
    /**
     * Сохранённые для отрисовки фигуры.
     */
    private List<BasePoint2D[]> shapes;
    /**
     * Индексы объединяемых элементов.
     */
    private int[][] concated;
//	/** Флаг объединяемости шаблона. */
//	private boolean isConcatinable;


    /**
     * @param color   Цвет.
     * @param width   Толщина линий.
     * @param pattern Шаблон.
     */
    public VGPatternPen(int color, double width, IPenPattern pattern) {
        this.color = color;
        this.width = width;
        this.pattern = pattern.clone();

        this.lastLength = -1.0;
//		this.isConcatinable = isConcatinable();
        this.lines = new ArrayList<BasePoint2D[]>();
        this.shapes = new ArrayList<BasePoint2D[]>();
        concated = new int[pattern.getElements().size()][];
        for (int i = 0; i < this.pattern.getElements().size(); i++) {
            IPenPattern.IElement e = this.pattern.getElements().get(i);
            concated[i] = getConcated(e);
        }
    }


    @Override
    public int hashCode() {
        int result = 17;
        result = result * 7 + color;
        result = result * 7 + GeometryUtils.hashCode(width);
        result = result * 7 + pattern.hashCode();
        return result;
    }


    /**
     * Получить цвет.
     *
     * @return Цвет.
     */
    public int getColor() {
        return color;
    }

    /**
     * Задать цвет.
     *
     * @param color Цвет.
     */
    public void setColor(int color) {
        this.color = color;
    }

    /**
     * Получить толщину линий.
     *
     * @return Толщина линий.
     */
    public double getWidth() {
        return width;
    }

    /**
     * Задать толщину линий.
     *
     * @param width Толщина линий.
     */
    public void setWidth(double width) {
        this.width = width;
    }

    /**
     * Получить шаблон.
     *
     * @return Шаблон.
     */
    public IPenPattern getPattern() {
        return pattern;
    }

    /**
     * Задать шаблон.
     *
     * @param pattern Шаблон.
     */
    public void setPattern(IPenPattern pattern) {
        this.pattern = pattern;
    }

    @Override
    public void paint(IPainter painter, List<BasePoint2D> points) {
        if (pattern.getElements().size() == 1) {
            IPenPattern.IElement element = pattern.getElements().get(0);
            if (element.getPoints().length == 2) {
                if (element.getPoints()[0].equals(new BasePoint2D()) && element.getPoints()[1].equals(new BasePoint2D(pattern.getSize(), 0))) {
                    VGBasicPen basicPen = new VGBasicPen(color, width);
                    basicPen.paint(painter, points);
                    return;
                }
            }
        }

        if (isPaintDraft((ViewParams) painter.getExtra().get("viewParams"))) {
            double minY = Double.MAX_VALUE;
            double maxY = -Double.MAX_VALUE;
            for (IPenPattern.IElement element : pattern.getElements()) {
                for (BasePoint2D p : element.getPoints()) {
                    double y = p.getY();
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
            double basicWidth = (maxY - minY) * width;
            if (GeometryUtils.isNearZero(basicWidth)) basicWidth = 1.0;
            VGBasicPen basicPen = new VGBasicPen(color, basicWidth);
            basicPen.paint(painter, points);
            return;
        }

        paintLineByPattern(painter, points);
    }

    /**
     * Нарисовать линию.
     *
     * @param painter Художник.
     * @param points  Точки линии.
     */
    private void paintLineByPattern(IPainter painter, List<BasePoint2D> points) {

        if (points.size() < 2) {
            return;
        }
        // Настраиваем Художника.
        painter.setColor(color);
        painter.setLineParams(new LineParams(width));
        if (needForCalculate(points)) {
            calculate(points);
        }
        for (BasePoint2D[] line : lines) {
            painter.drawLine(Arrays.asList(line));
        }

        for (BasePoint2D[] shape : shapes) {
            painter.fillShape(Arrays.asList(shape));
        }

    }

    /**
     * Проверить режим чернойвой отрисовки.
     *
     * @param mmToPx Коэффициент перехода от мм документа к пикселям.
     * @return Признак чернового режима отрисовки.
     */
    public boolean isPaintDraft(double mmToPx) {
        double patternSizePx = pattern.getSize() * mmToPx;
        return patternSizePx <= 4.0;
    }

    /**
     * Проверить режим чернойвой отрисовки.
     *
     * @param viewParams Параметры вида.
     * @return Признак чернового режима отрисовки.
     */
    public boolean isPaintDraft(ViewParams viewParams) {
        if (viewParams == null) return false;
        return isPaintDraft(GeometryProcessor.transformSize(viewParams.getMmToPx(), 1.0));
    }

    /**
     * Проверить, есть ли необходимость пересчитать линию.
     *
     * @param points Точки линии.
     * @return Результат проверки.
     */
    private boolean needForCalculate(List<BasePoint2D> points) {
        return lastBeginPoint == null ||
                lastEndPoint == null ||
                !points.get(0).equals(lastBeginPoint) ||
                !points.get(points.size() - 1).equals(lastEndPoint) ||
                GeometryProcessor.getPolylineLength(points) != lastLength;
    }

    /**
     * Рассчитать шаблоны.
     *
     * @param points Точки линии.
     */
    private void calculate(List<BasePoint2D> points) {
        lines.clear();
        shapes.clear();
        lastLength = GeometryProcessor.getPolylineLength(points);
        lastBeginPoint = (BasePoint2D) points.get(0);
        lastEndPoint = (BasePoint2D) points.get(points.size() - 1);
        double k = width * pattern.getScale();
        double pLength = pattern.getSize() * k;
        if (pLength <= 0.0) return;
        List<IPenPattern> countedPatterns = new ArrayList<IPenPattern>();
        SegmentsIterable iterable = new SegmentsIterable(points, pLength);
        List<List<BasePoint2D>> countedSegments = new ArrayList<List<BasePoint2D>>();
        for (List<BasePoint2D> s : iterable) {
            countedSegments.add(s);
        }
        for (List<BasePoint2D> s : countedSegments) {
            IPenPattern ppClone = pattern.clone();
            if (s.size() > 2) {
                for (int eIndex = 0; eIndex < ppClone.getElements().size(); eIndex++) {
                    IPenPattern.IElement e = ppClone.getElements().get(eIndex);
                    if (canBend(e)) {
                        double segmentLength = GeometryProcessor.getPolylineLength(s);
                        double hScaleFactor = segmentLength / pLength;
                        for (BasePoint2D p : e.getPoints()) {
                            double offset = p.getX() * k * hScaleFactor / segmentLength;
                            BasePoint2D point = GeometryProcessor.getPointOnPolylineByShift(s, offset);
                            double angle = GeometryProcessor.getPolylineTangentAngle(s, offset) + Math.PI / 2.0;
                            BasePoint2D r = new BasePoint2D(point);
                            // todo: !!!!
                            //r.setX(r.getX() + p.getY() * k);
                            //r.rotate(angle, point);
                            //((BasePoint2D) p).init(r);
                        }
                        if (lineIsStraight(Arrays.asList(e.getPoints())) &&
                                pattern.getElements().get(eIndex).getPoints()[0].getY() == pattern.getElements().get(eIndex).getPoints()[pattern.getElements().get(eIndex).getPoints().length - 1].getY()) {
                            List<List<BasePoint2D>> subElements = new ArrayList<List<BasePoint2D>>();
                            for (int i = 1; i < e.getPoints().length; i++) {
                                BasePoint2D pr = e.getPoints()[i - 1];
                                BasePoint2D cr = e.getPoints()[i];
                                BasePoint2D proj1 = GeometryProcessor.nearestPointOnPolyline(s, pr);
                                BasePoint2D proj2 = GeometryProcessor.nearestPointOnPolyline(s, cr);
                                double dist1 = 0.0;
                                double dist2 = 0.0;
                                if (GeometryProcessor.isPointRightOf(pr, s)) {
                                    dist1 = -GeometryUtils.distanceBetweenPoints(pr, proj1);
                                    dist2 = -GeometryUtils.distanceBetweenPoints(cr, proj2);
                                } else {
                                    dist1 = GeometryUtils.distanceBetweenPoints(pr, proj1);
                                    dist2 = GeometryUtils.distanceBetweenPoints(cr, proj2);
                                }
                                double offset = GeometryUtils.distanceBetweenPoints(s.get(0), proj1);
                                double length = GeometryUtils.distanceBetweenPoints(proj1, proj2);
                                List<BasePoint2D> ss = new ArrayList<BasePoint2D>();
                                for (int j = 0; j < s.size(); j++) {
                                    ss.add(new BasePoint2D(s.get(j)));
                                }
                                List<BasePoint2D> subElement = GeometryProcessor.getSubPolyline(ss, 0, offset, length);
                                List<BasePoint2D> shiftedSubElement = GeometryProcessor.shiftPolyline(
                                        new GeometryProcessor.LinearShift(
                                                dist1, dist2),
                                        0,
                                        false,
                                        subElement);
                                if (shiftedSubElement.isEmpty()) {
                                    subElements.add(subElement);
                                } else {
                                    subElements.add(shiftedSubElement);
                                }
                            }
                            List<BasePoint2D> elementPoints = new ArrayList<BasePoint2D>();
                            for (List<BasePoint2D> subElement : subElements) {
                                elementPoints.addAll(subElement);
                            }
                            BasePoint2D pr = null;
                            for (Iterator<BasePoint2D> i = elementPoints.iterator(); i.hasNext(); ) {
                                BasePoint2D cr = i.next();
                                if (cr.equals(pr)) {
                                    i.remove();
                                }
                                pr = cr;
                            }
                            BasePoint2D[] newPoints = new BasePoint2D[elementPoints.size()];
                            int index = 0;
                            for (BasePoint2D p : elementPoints) {
                                newPoints[index++] = p;
                            }
                            e.setPoints(newPoints);
                        }
                    } else {
                        BaseFrame2D f = new BaseFrame2D();
                        f.union(e.getPoints());
                        BasePoint2D p1 = new BasePoint2D();
                        BasePoint2D p2 = new BasePoint2D();
                        double projectionShift = (f.getCenter().getX() * k) / pLength;
                        for (int j = 1; j < s.size(); j++) {
                            p1 = s.get(j - 1);
                            p2 = s.get(j);
                            double shift1 = GeometryProcessor.nearestPointLocationOnPolyline(s, p1);
                            double shift2 = GeometryProcessor.nearestPointLocationOnPolyline(s, p2);
                            if (shift1 <= projectionShift && projectionShift <= shift2) {
                                break;
                            }
                        }
                        BasePoint2D centerProjection = GeometryProcessor.getPointOnPolylineByShift(s, projectionShift);
                        double dist1 = GeometryUtils.distanceBetweenPoints(p1, centerProjection);
                        double dist2 = GeometryUtils.distanceBetweenPoints(centerProjection, p2);
                        double scaleFactor1 = f.getCenter().getX() * k / dist1;
                        double scaleFactor2 = pLength - f.getCenter().getX() * k / dist2;
                        BasePoint2D begin = new BasePoint2D(p1).scale(scaleFactor1, scaleFactor1, centerProjection.getX(), centerProjection.getY());
                        BasePoint2D end = new BasePoint2D(p2).scale(scaleFactor2, scaleFactor2, centerProjection.getX(), centerProjection.getY());
                        BaseMatrix2D m = createMatrix(Arrays.asList(new BasePoint2D[]{begin, end}), true);
                        for (BasePoint2D p : e.getPoints()) {
                            ((BasePoint2D) p).transform(m);
                        }
                    }
                }
            } else {
                BaseMatrix2D m = createMatrix(s, false);
                for (IPenPattern.IElement e : ppClone.getElements()) {
                    for (BasePoint2D p : e.getPoints()) {
                        ((BasePoint2D) p).transform(m);
                    }
                }
            }
            countedPatterns.add(ppClone);
        }
        List<List<BasePoint2D>> lines = new ArrayList<List<BasePoint2D>>(pattern.getElements().size());
        for (int i = 0; i < pattern.getElements().size(); i++) {
            lines.add(new ArrayList<BasePoint2D>());
        }
        for (int i = 0; i < countedPatterns.size(); i++) {
            for (int j = 0; j < concated.length; j++) {
                IPenPattern.IElement e = countedPatterns.get(i).getElements().get(j);
                if (e.getFilled()) {
                    shapes.add(e.getPoints());
                } else {
                    int[] entry = concated[j];
                    // Элемент не связан. Линия начинается и заканчивается.
                    if (entry[0] == -1 && entry[1] == -1) {
                        lines.get(j).addAll(Arrays.asList(e.getPoints()));
                        BasePoint2D[] line = new BasePoint2D[lines.get(j).size()];
                        for (int pointIndex = 0; pointIndex < line.length; pointIndex++) {
                            line[pointIndex] = lines.get(j).get(pointIndex);
                        }
                        this.lines.add(line);
                        lines.get(j).clear();
                        // Элемент связан только справа. Линия начинается.
                    } else if (entry[0] == -1 && entry[1] != -1) {
                        lines.get(j).addAll(Arrays.asList(e.getPoints()));
                        // Элемент связан только слева. Линия заканчивается.
                    } else if (entry[0] != -1 && entry[1] == -1) {
                        List<BasePoint2D> elementPoints = Arrays.asList(e.getPoints());

                        int lastIndex = lines.get(entry[0]).size() - 1;
                        if (lastIndex > -1) {
                            // Получаем среднюю точку между концевыми точками элементов.
                            BasePoint2D linkingPoint = GeometryUtils.absolute(lines.get(entry[0]).get(lastIndex), elementPoints.get(0), 0.5);
                            // Удаляем последнюю точку имеющейся линии.
                            lines.get(entry[0]).remove(lastIndex);
                            // Вместо неё устанавливаем соединительную точку.
                            lines.get(entry[0]).add(linkingPoint);
                            // Добавляем все точки нового элемента, кроме первой.
                            lines.get(entry[0]).addAll(elementPoints.subList(1, elementPoints.size()));
                        } else {
                            lines.get(entry[0]).addAll(elementPoints);
                        }

                        List<BasePoint2D> finishedLine = GeometryUtils.simplifyPolyline(lines.get(entry[0]), 0);
                        BasePoint2D[] line = new BasePoint2D[finishedLine.size()];
                        for (int pointIndex = 0; pointIndex < line.length; pointIndex++) {
                            line[pointIndex] = finishedLine.get(pointIndex);
                        }
                        this.lines.add(line);
                        lines.get(entry[0]).clear();
                        // Элемент связан обеих сторон. Линия продолжается.
                    } else if (entry[0] != -1 && entry[1] != -1) {
                        List<BasePoint2D> elementPoints = Arrays.asList(e.getPoints());
                        int lastIndex = lines.get(entry[0]).size() - 1;
                        if (lastIndex > -1) {
                            // Получаем среднюю точку между концевыми точками элементов.
                            BasePoint2D linkingPoint = GeometryUtils.absolute(lines.get(entry[0]).get(lastIndex), elementPoints.get(0), 0.5);
                            // Удаляем последнюю точку имеющейся линии.
                            lines.get(entry[0]).remove(lastIndex);
                            // Вместо неё устанавливаем соединительную точку.
                            lines.get(entry[0]).add(linkingPoint);
                            // Добавляем все точки нового элемента, кроме первой.
                            lines.get(entry[0]).addAll(elementPoints.subList(1, elementPoints.size()));
                        } else {
                            lines.get(entry[0]).addAll(elementPoints);
                        }
                    }
                }
            }
        }
        for (List<BasePoint2D> pnts : lines) {
            List<BasePoint2D> simplified = GeometryUtils.simplifyPolyline(pnts, 0);
            BasePoint2D[] line = new BasePoint2D[simplified.size()];
            for (int pointIndex = 0; pointIndex < line.length; pointIndex++) {
                line[pointIndex] = simplified.get(pointIndex);
            }
            this.lines.add(line);
        }
        for (IPenPattern pp : countedPatterns) {
            shapes.addAll(addArrows(pp));
        }
    }

//	/**
//	 * Удалить равные точки.
//	 * @param points Исходный список.
//	 * @return Массив точек.
//	 */
//	private SignPoint2D[] removeEqualPoints(List<SignPoint2D> points) {
//		List<Integer> remove = new ArrayList<Integer>();
//		for (int index = 1; index < points.size(); index++) {
//			if (points.get(index - 1).equals(points.get(index))) {
//				remove.add(index - 1);
//			}
//		}
//		SignPoint2D[] newPoints = new SignPoint2D[points.size() - remove.size()];
//		for (int i = 0, j = 0; i < points.size(); i++) {
//			if (!remove.contains(i)) {
//				newPoints[j++] = new SignPoint2D(points.get(i));
//			}
//		}
//		return newPoints;
//	}

    /**
     * Получить индексы элементов, присоединённых слева и справа к этому элементу.
     *
     * @param element Элемент.
     * @return Индексы. Значение -1 говорит о том, что присоединённого элемента нет.
     */
    private int[] getConcated(IPenPattern.IElement element) {
        int[] concated = new int[]{-1, -1};
        if (element.getFilled()) {
            return concated;
        }
        BasePoint2D begin = element.getPoints()[0];
        BasePoint2D end = element.getPoints()[element.getPoints().length - 1];
        if (begin.getX() == 0) {
            for (int i = 0; i < pattern.getElements().size(); i++) {
                IPenPattern.IElement e = pattern.getElements().get(i);
                BasePoint2D checkedEnd = e.getPoints()[e.getPoints().length - 1];
                if (checkedEnd.getX() == pattern.getSize() && checkedEnd.getY() == begin.getY()) {
                    concated[0] = i;
                    break;
                }
            }
        }
        if (end.getX() == pattern.getSize()) {
            for (int i = 0; i < pattern.getElements().size(); i++) {
                IPenPattern.IElement e = pattern.getElements().get(i);
                BasePoint2D checked = e.getPoints()[0];
                if (checked.getX() == 0 && checked.getY() == end.getY()) {
                    concated[1] = i;
                    break;
                }
            }
        }
        return concated;
    }

    /**
     * Отрисовать тестовое изображение.
     *
     * @param painter Художник.
     * @param points  Точки линии.
     * @param bend    Флаг огибания.
     */
    @SuppressWarnings("unused")
    private void paintTest(IPainter painter, List<BasePoint2D> points, boolean bend) {
        int color = painter.getColor();
        LineParams p = new LineParams(painter.getLineParams());
        LineParams c = new LineParams(painter.getLineParams());
        c.setWidth(0.02);
        if (bend) {
            for (int i = 0; i < points.size() - 1; i++) {
                painter.setColor(0xFF0000FF);
                painter.drawLine(Arrays.asList(points.get(i), points.get(i + 1)));
                painter.setLineParams(c);
                painter.setColor(0xFF000000);
                painter.drawLine(GeometryProcessor.createCircle(points.get(i), 0.1));
                painter.setLineParams(p);
            }
            painter.fillShape(GeometryProcessor.createCircle(points.get(0), 0.1));
        } else {
            painter.setColor(0xFFFF0000);
            painter.drawLine(Arrays.asList(points.get(0), points.get(points.size() - 1)));
            painter.setLineParams(c);
            painter.setColor(0xFF000000);
            painter.fillShape(GeometryProcessor.createCircle(points.get(0), 0.1));
            painter.setLineParams(p);
        }
        painter.setColor(color);
    }

    /**
     * Создать матрицу по сегменту. В расчёт берутся начальная и конечная точки сегмента.
     *
     * @param points       Точки сегмента.
     * @param proportional Флаг пропорционального масштабирования.
     * @return Матрица.
     */
    private BaseMatrix2D createMatrix(List<BasePoint2D> points, boolean proportional) {
        BasePoint2D begin = points.get(0);
        BasePoint2D end = points.get(points.size() - 1);
        BaseMatrix2D m = new BaseMatrix2D();
        // todo: !!!
        /*
        if (proportional) {
            m.scale(width * pattern.getScale(), width * pattern.getScale(), 0, 0);
        } else {
            m.scale(GeometryUtils.distanceBetweenPoints(begin, end) / pattern.getSize(), width * pattern.getScale());
        }
        m.rotate(GeometryUtils.angleBetweenPoints(end, begin, null));
        */
        m.translate(begin.getX(), begin.getY());
        return m;
    }

    /**
     * Проверить пригодность точек для использования.
     *
     * @param points Точки.
     * @return Результат проверки.
     */
    private static boolean pointsAreValid(List<? extends BasePoint2D> points) {
        if (points == null) {
            return false;
        }
        for (BasePoint2D p : points) {
            if (p == null) {
                return false;
            }
        }
        return true;
    }

    /**
     * Нарисовать точку.
     *
     * @param painter Художник.
     * @param point   Точка.
     * @param radius  Радиус круга.
     * @param color   Цвет круга.
     */
    @SuppressWarnings("unused")
    private static void testPoint(IPainter painter, BasePoint2D point, double radius, int color) {
        int oldColor = painter.getColor();
        painter.setColor(color);
        painter.fillShape(GeometryProcessor.createCircle(point, radius));
        painter.setColor(oldColor);
    }

    /**
     * Нарисовать линию с восстановлением настроек художника.
     *
     * @param painter Художник.
     * @param points  Точки линии.
     * @param width   Ширина линии.
     * @param color   Цвет линии.
     */
    @SuppressWarnings("unused")
    private static void testLine(IPainter painter, double width, int color, List<? extends BasePoint2D> points) {
        if (!pointsAreValid(points)) {
            return;
        }
        LineParams oldParams = painter.getLineParams();
        LineParams newParams = new LineParams(width);
        int oldColor = painter.getColor();
        painter.setLineParams(newParams);
        painter.setColor(color);
        painter.drawLine(points);
        painter.setLineParams(oldParams);
        painter.setColor(oldColor);
    }

    /**
     * Нарисовать линию с восстановлением настроек художника.
     *
     * @param painter Художник.
     * @param points  Точки линии.
     * @param width   Ширина линии.
     * @param color   Цвет линии.
     */
    @SuppressWarnings("unused")
    private static void testLine(IPainter painter, double width, int color, BasePoint2D... points) {
        if (!pointsAreValid(Arrays.asList(points))) {
            return;
        }
        LineParams oldParams = painter.getLineParams();
        LineParams newParams = new LineParams(width);
        int oldColor = painter.getColor();
        painter.setLineParams(newParams);
        painter.setColor(color);
        painter.drawLine(Arrays.asList(points));
        painter.setLineParams(oldParams);
        painter.setColor(oldColor);
    }

    /**
     * Заполнить фигуру с восстановлением настроек художника.
     *
     * @param painter Художник.
     * @param points  Точки контура.
     * @param color   Цвет фигуры.
     */
    @SuppressWarnings("unused")
    private static void testShape(IPainter painter, int color, List<BasePoint2D> points) {
        if (!pointsAreValid(points)) {
            return;
        }
        int c = painter.getColor();
        painter.setColor(color);
        painter.fillShape(points);
        painter.setColor(c);
    }

    /**
     * Заполнить фигуру с восстановлением настроек художника.
     *
     * @param painter Художник.
     * @param points  Точки контура.
     * @param color   Цвет фигуры.
     */
    @SuppressWarnings("unused")
    private static void testShape(IPainter painter, int color, BasePoint2D... points) {
        if (!pointsAreValid(Arrays.asList(points))) {
            return;
        }
        int c = painter.getColor();
        painter.setColor(color);
        painter.fillShape(Arrays.asList(points));
        painter.setColor(c);
    }

    /**
     * Нарисовать текст.
     *
     * @param painter Художник.
     * @param p1      Начало базовой линии.
     * @param text    Текст.
     */
    @SuppressWarnings("unused")
    private static void testText(IPainter painter, BasePoint2D p1, String text) {
        LineParams oldParams = painter.getLineParams();
        int c = painter.getColor();
        painter.setColor(0xFF000000);
        painter.setFont(Font.DIALOG, Font.PLAIN, 1.0);
        painter.setLineParams(new LineParams(0.05));
        BasePoint2D endPoint = new BasePoint2D(p1).translate(5, -5);
        painter.drawLine(Arrays.asList(p1, endPoint));
        painter.drawString(text, endPoint.getX() + 1, endPoint.getY() - 1);
        painter.setColor(c);
        painter.setLineParams(oldParams);
    }

    /**
     * Проверить возможность огибания линии этим элементом.
     *
     * @param element Элемент.
     * @return Результат проверки.
     */
    private boolean canBend(IPenPattern.IElement element) {
        return !element.getFilled() && !(element.getPoints()[0].equals(element.getPoints()[element.getPoints().length - 1]));
    }

    /**
     * Добавить стрелки.
     *
     * @param pattern Шаблон.
     * @return Точки, образующие стрелку.
     */
    private List<BasePoint2D[]> addArrows(IPenPattern pattern) {
        List<BasePoint2D[]> arrows = new ArrayList<BasePoint2D[]>();
        for (int i = 0; i < pattern.getElements().size(); i++) {

            IPenPattern.IElement element = pattern.getElements().get(i);

            if (element.hasBeginArrow()) {
                cutShortEdgeSegment(element, width / 2.0, true);
//				SignPoint2D point0 = (SignPoint2D)element.getPoints()[0];
//				SignPoint2D point1 = (SignPoint2D)element.getPoints()[1];
//				if (GeometryUtils.distanceBetweenPoints(point0, point1) > width) {
//					element.getPoints()[0] = new SignPoint2D(GeometryUtils.absolute(point1, point0, 1.0 - 1.0 / GeometryUtils.distanceBetweenPoints(point0, point1)));
//				}
                arrows.add(addArrow(pattern, element.getPoints()[1], element.getPoints()[0]));
            }
            if (element.hasEndArrow()) {
                cutShortEdgeSegment(element, width / 2.0, false);
//				SignPoint2D pointPreLast = (SignPoint2D)element.getPoints()[element.getPoints().length - 2];
//				SignPoint2D pointLast = (SignPoint2D)element.getPoints()[element.getPoints().length - 1];
//				if (GeometryUtils.distanceBetweenPoints(pointPreLast, pointLast) > width) {
//					element.getPoints()[element.getPoints().length - 1] = new SignPoint2D(GeometryUtils.absolute(pointPreLast, pointLast, 1.0 - 1.0 / GeometryUtils.distanceBetweenPoints(pointPreLast, pointLast)));
//				}
                arrows.add(addArrow(pattern, element.getPoints()[element.getPoints().length - 2], element.getPoints()[element.getPoints().length - 1]));
            }
        }
        return arrows;
    }

    /**
     * Добавить стрелку.
     *
     * @param pattern    Шаблон.
     * @param beginPoint Начальная точка сегмента со стрелкой.
     * @param endPoint   Конечная точка сегмента со стрелкой.
     * @return Точки, образующие стрелку.
     */
    private BasePoint2D[] addArrow(IPenPattern pattern, BasePoint2D beginPoint, BasePoint2D endPoint) {

        BasePoint2D[] points = new BasePoint2D[3];
        double segmentLength = GeometryUtils.distanceBetweenPoints(beginPoint, endPoint);
        double step = width / segmentLength;

        BasePoint2D arrowBaseCenter = GeometryUtils.absolute(beginPoint, endPoint, 1.0 - (step * 2.0));
        BasePoint2D arrowCenter = GeometryUtils.absolute(beginPoint, endPoint, 1.0 - (step / 2.0));

        points[0] = new BasePoint2D(arrowCenter).rotate(90.0 / RAD_TO_GRAD, arrowBaseCenter);
        points[1] = new BasePoint2D(GeometryUtils.absolute(beginPoint, endPoint, 1 + step));
        points[2] = new BasePoint2D(arrowCenter).rotate(-90.0 / RAD_TO_GRAD, arrowBaseCenter);

        IPenPattern.IElement arrow = SignVisualFactory.createPenPatternElement(true, points);
        pattern.getElements().add(arrow);
        return points;

    }

    /**
     * Обрезать короткий крайний сегмент линии.
     *
     * @param element      Элемент шаблона.
     * @param length       Длина, необходимая сегменту для того, чтобы его не удалять.
     * @param isEndSegment Флаг, указывающий, какой сегмент может быть удалён: конечный или начальный.
     * @return Результат операции: удалён сегмент или нет.
     */
    private boolean cutShortEdgeSegment(IPenPattern.IElement element, double length, boolean isEndSegment) {
        if (element.getPoints().length < 3) {
            return false;
        }
        BasePoint2D begin = null;
        BasePoint2D end = null;
        if (isEndSegment) {
            begin = element.getPoints()[element.getPoints().length - 2];
            end = element.getPoints()[element.getPoints().length - 1];
        } else {
            begin = element.getPoints()[1];
            end = element.getPoints()[0];
        }

        if (GeometryUtils.distanceBetweenPoints(begin, end) < length) {
            List<BasePoint2D> line = new ArrayList<BasePoint2D>();
            for (int i = 0; i < element.getPoints().length; i++) {
                line.add(new BasePoint2D(element.getPoints()[i]));
            }
            double subLineLength = GeometryProcessor.getPolylineLength(line) - width;
            List<BasePoint2D> subLine = GeometryProcessor.getSubPolyline(line, 0, isEndSegment ? width : 0, subLineLength);
            BasePoint2D[] newPoints = new BasePoint2D[subLine.size()];
            for (int i = 0; i < newPoints.length; i++) {
                newPoints[i] = new BasePoint2D(subLine.get(i));
            }
            if (newPoints.length > 1) {
                element.setPoints(newPoints);
                return true;
            }
        }

        return false;
    }

//	/**
//	 * Проверить, является ли шаблон объединяемым.
//	 * @return Флаг объединяемости шаблона.
//	 */
//	private boolean isConcatinable() {
//		int[] array = getEdgeIndices();
//		return array.length > 0 && array[0] > -1 && array[1] > -1;
//	}

//	/**
//	 * Получить индексы элементов шаблона, по которым проводится объединение.
//	 * Левый элемент объединяется с правым элементом предыдущего шаблона,
//	 * правый элемент объединяется с левым элементом следующего шаблона.
//	 * @return Индексы элементов. Размерность массива всегда 2: [left][right]
//	 */
//	private int[] getEdgeIndices() {
//
//		List<Integer> indices = new ArrayList<Integer>();
//		List<Integer> leftIndices = new ArrayList<Integer>();
//		List<Integer> rightIndices = new ArrayList<Integer>();
//		List<IElement> elements = pattern.getElements();
//
//		for (int i = 0; i < elements.size(); i++) {
//			if (elements.get(i).getPoints()[0].getX() == 0.0) {
//				leftIndices.add(i);
//			}
//		}
//
//		for (int i = 0; i < pattern.getElements().size(); i++) {
//			SignPoint2D[] points = elements.get(i).getPoints();
//			if (points[points.length - 1].getX() == pattern.getSize()) {
//				rightIndices.add(i);
//			}
//		}
//
//		for (int i = 0; i < leftIndices.size(); i++) {
//			int left = leftIndices.get(i);
//			SignPoint2D[] leftPoints = elements.get(left).getPoints();
//			for (int j = 0; j < rightIndices.size(); j++) {
//				int right = rightIndices.get(j);
//				SignPoint2D[] rightPoints = elements.get(right).getPoints();
//				if (leftPoints[0].getY() ==	rightPoints[rightPoints.length - 1].getY()) {
//					indices.add(left);
//					indices.add(right);
//					break;
//				}
//			}
//		}
//
//		int[] result = new int[indices.size()];
//		int counter = 0;
//		for (Integer i: indices) {
//			result[counter++] = i.intValue();
//		}
//		return result;
//	}

//	/**
//	 * Получить сплошную линию.
//	 * @param patterns Шаблоны.
//	 * @param index Индекс элементов шаблонов, из которых строится линия.
//	 * @return Линия.
//	 */
//	private SignPoint2D[] getSolidLine(List<IPenPattern> patterns, int index) {
//		if (patterns.size() == 0) {
//			return new SignPoint2D[] {};
//		}
//		int totalCounter = patterns.size() * pattern.getElements().get(index).getPoints().length;
//		List<SignPoint2D> mainLine = new ArrayList<SignPoint2D>(totalCounter);
//		for (SignPoint2D p: patterns.get(0).getElements().get(index).getPoints()) {
//			mainLine.add(p);
//		}
//		boolean mayRemoveJoinPoint = false;
//		for (int i = 1; i < patterns.size(); i++) {
//			IElement current = patterns.get(i).getElements().get(index);
//			for (int j = 1; j < current.getPoints().length; j++) {
//				if (j == 1) {
//					SignPoint2D previousPoint = mainLine.get(mainLine.size() - 2);
//					SignPoint2D currentPoint = current.getPoints()[1];
//					SignPoint2D joinPoint = mainLine.get(mainLine.size() - 1);
//					double angle = SignPoint2D.angleBetweenPoints(previousPoint, joinPoint, currentPoint);
//					if (!GeometryUtils.isNear(angle, Math.PI)) {
//						SignPoint2D intersectionPoint = SignPoint2D.linesIntersection(
//								new SignPoint2D(mainLine.get(mainLine.size() - 2)),
//								new SignPoint2D(joinPoint),
//								new SignPoint2D(current.getPoints()[0]),
//								new SignPoint2D(current.getPoints()[1]));
//						if (intersectionPoint != null) {
//							mainLine.set(mainLine.indexOf(joinPoint), intersectionPoint);
//						}
//					}
//					mayRemoveJoinPoint = GeometryUtils.isNear(SignPoint2D.angleBetweenPoints(previousPoint, joinPoint, currentPoint), Math.PI, 0.0);
//					if (mayRemoveJoinPoint) {
//						mainLine.remove(joinPoint);
//					}
//				}
//				mainLine.add(current.getPoints()[j]);
//			}
//		}
//		SignPoint2D[] points = new SignPoint2D[mainLine.size()];
//		for (int j = 0; j < points.length; j++) {
//			points[j] = mainLine.get(j);
//		}
//		return points;
//	}

//	/**
//	 * Добавить соединённые крайние сегменты линии.
//	 * @param patterns Шабоны.
//	 * @param leftIndex Индекс левого элемента.
//	 * @param rightIndex Индекс правого элемента.
//	 */
//	private void addConcatedEdgeSegments(List<IPenPattern> patterns, int leftIndex, int rightIndex) {
//		lines.add(patterns.get(0).getElements().get(leftIndex).getPoints());
//		for (int i = 1; i < patterns.size(); i++) {
//			IElement previous = patterns.get(i - 1).getElements().get(rightIndex);
//			IElement current = patterns.get(i).getElements().get(leftIndex);
//			int prevPointsNum = previous.getPoints().length;
//			int curPointsNum = current.getPoints().length;
//			SignPoint2D previousPoint = previous.getPoints()[prevPointsNum - 2];//previous.getPoints()[prevPointsNum - 1];
////			SignPoint2D joinPoint = previous.getPoints()[prevPointsNum - 1];//current.getPoints()[0];
//			SignPoint2D currentPoint = current.getPoints()[0];//current.getPoints()[1];
//			SignPoint2D[] newLine = null;
//			double angle = SignPoint2D.angleBetweenPoints(
//					currentPoint,
//					GeometryUtils.absolute(current.getPoints()[0], current.getPoints()[1], 0.5),
//					previousPoint);
//			if (!
////					(
////					GeometryProcessor.isPointOnPolyline(
////							new SignPoint2D(previous.getPoints()[prevPointsNum - 1]),
////							new SignPoint2D(previous.getPoints()[prevPointsNum - 2]),
////							new SignPoint2D(current.getPoints()[1]))// &&
////					GeometryProcessor.isPointOnPolyline(
////							new SignPoint2D(current.getPoints()[0]),
////							new SignPoint2D(previous.getPoints()[prevPointsNum - 2]),
////							new SignPoint2D(current.getPoints()[1]))
////					)
//
//							GeometryUtils.isNear(angle, Math.PI)
//							) {
//
//				SignPoint2D intersectionPoint = SignPoint2D.linesIntersection(
//						new SignPoint2D(previous.getPoints()[prevPointsNum - 2]),
//						new SignPoint2D(previous.getPoints()[prevPointsNum - 1]),
//						new SignPoint2D(current.getPoints()[0]),
//						new SignPoint2D(current.getPoints()[1]));
//				if (intersectionPoint != null) {
//					previous.getPoints()[prevPointsNum - 1] = new SignPoint2D(intersectionPoint);
//				}
//				newLine = null;
//				newLine = new SignPoint2D[prevPointsNum + curPointsNum - 1];
//				for (int j = 0; j < newLine.length; j++) {
//					if (j < prevPointsNum) {
//						newLine[j] = previous.getPoints()[j];
//					} else {
//						int index = j - (prevPointsNum - 1);
//						newLine[j] = current.getPoints()[index];
//					}
//				}
//
//			} else {
//				newLine = null;
//				newLine = new SignPoint2D[prevPointsNum + curPointsNum - 2];
//				for (int j = 0; j < newLine.length; j++) {
//					if (j < prevPointsNum - 1) {
//						newLine[j] = previous.getPoints()[j];
//					} else {
//						int index = j - (prevPointsNum - 1);
//						newLine[j] = current.getPoints()[index + 1];
//					}
//				}
//			}
//			lines.add(newLine);
//		}
//		lines.add(patterns.get(patterns.size() - 1).getElements().get(rightIndex).getPoints());
//	}

//	/**
//	 * Проверить, содержит ли массив значение.
//	 * @param array Массив.
//	 * @param value Значение.
//	 * @return Результат проверки.
//	 */
//	private static boolean arrayContains(int[] array, int value) {
//		for (int i: array) {
//			if (i == value) {
//				return true;
//			}
//		}
//		return false;
//	}

//	/**
//	 * Добавить все остальные элементы.
//	 * @param patterns Шаблоны.
//	 * @param unresolvedIndices Индексы элементов, добавление которых запрещено.
//	 */
//	private void addOtherElements(List<IPenPattern> patterns, int...unresolvedIndices) {
//		for (IPenPattern pp: patterns) {
//			for (int i = 0; i < pp.getElements().size(); i++) {
//				IElement e = pp.getElements().get(i);
//				if (!e.getFilled()) {
//					if (!arrayContains(unresolvedIndices, i)) {
//						lines.add(e.getPoints());
//					}
//				} else {
//					shapes.add(e.getPoints());
//				}
//			}
//		}
//	}

//	/**
//	 * Объединить шаблоны.
//	 * @param patterns Рассчитанные шаблоны.
//	 */
//	private void concatPatterns(List<IPenPattern> patterns) {
//
//		int[] indices = getEdgeIndices();
//
//		for (int i = 0; i < indices.length / 2; i++) {
//			int leftIndex = indices[i * 2];
//			int rightIndex = indices[i * 2 + 1];
//
//			// Возможно слить по одному элементу
//			// каждого шаблона в одну линию.
//			if (leftIndex == rightIndex) {
//				lines.add(getSolidLine(patterns, leftIndex));
//			} else {
//				if (leftIndex < 0 || rightIndex < 0) return;
//				addConcatedEdgeSegments(patterns, leftIndex, rightIndex);
//			}
//
//		}
//		addOtherElements(patterns, indices);
//
//	}

    /**
     * Получить точку пересечения окружности и отрезка.
     *
     * @param center Центр окружности.
     * @param r      Радиус.
     * @param p1     Первая точка.
     * @param p2     Вторая точка.
     * @return Точка пересечения.
     */
    private static BasePoint2D getIntersection(BasePoint2D center, double r, BasePoint2D p1, BasePoint2D p2) {

        // С форума:
        // "
        // Пусть у нас окр. радиуса R, и центр в точке (x0;y0). Отрезок (x1,y1) (x2,y2)
        // тогда решаем кв. уравнение:
        // [x1-x0 + (x2-x1)i]^2 + [y1-y0 + (y2-y1)i]^2 = R^2;
        //
        // Тебе подойдёт два i: i1, i2; Точки пересечения - (x1+(x2-x1)*i; y1+(y2-y1)*i)
        // Где лежат концы - наплевать...
        // В твоём случае тебе надо взять i = max(i1, i2);
        // "

        // "(x2-x1)"
        double xf = p2.getX() - p1.getX();
        // "(y2-y1)"
        double yf = p2.getY() - p1.getY();
        // "x1-x0"
        double xt = p1.getX() - center.getX();
        // "y1-y0"
        double yt = p1.getY() - center.getY();

        // Вычисляем коэффициенты a, b и с квадратного уравнения. n - неизвестная.
        // (xt + xf*n) * (xt + xf*n) + (yt + yf*n) * (yt + yf*n) = r * r;
        // (xt*xt + 2*xt*xf*n + (xf*n)*(xf*n)) + (yt*yt + 2*yf*yt*n + (yf*n)*(yf*n)) = r*r;
        // double xtxt = xt*xt;
        // double 2xtxf = 2*xt*xf;
        // double ytyt = yt*yt;
        // double 2yfyt = 2*yf*yt;
        // (xtxt + 2xtxf*n + (xf*xf*n*n)) + (ytyt + 2yfyt*n + (yf*yf*n*n)) = r * r;
        // double xfxf = xf*xf;
        // double yfyf = yf*yf;
        // xtxt + 2xtxf*n + xfxf*n*n + ytyt + 2yfyt*n + yfyf*n*n = r * r;
        //
        // double a = xfxf + yfyf;
        // double b = 2xtxf + 2ytyf;
        // double c = (xtxt + ytyt) - (r * r);

        double a = (xf * xf) + (yf * yf);
        double b = (2 * xt * xf) + (2 * yt * yf);
        double c = ((xt * xt) + (yt * yt)) - (r * r);
        double discriminant = (b * b) - (4 * a * c);
        double sqrtD = Math.sqrt(discriminant);
        double root1 = (-b + sqrtD) / (2 * a);
        double root2 = (-b - sqrtD) / (2 * a);

        double root = root1 > root2 ? root1 : root2;

        double x = p1.getX() + (xf * root);
        double y = p1.getY() + (yf * root);

        return new BasePoint2D(x, y);
    }

    /**
     * Проверить, является ли линия прямой.
     *
     * @param line Линия.
     * @return Результат проверки.
     */
    private static boolean lineIsStraight(List<BasePoint2D> line) {
        if (line.size() < 2) {
            return false;
        } else if (line.size() == 2) {
            return true;
        } else {
            List<BasePoint2D> sector = Arrays.asList(new BasePoint2D[]{line.get(0), line.get(line.size() - 1)});
            for (int i = 1; i < line.size() - 1; i++) {
                if (!GeometryProcessor.isPointOnPolyline(line.get(i), 0.01, sector)) {
                    return false;
                }
            }
            return true;
        }
    }

//	/**
//	 * Получить точки пересечения окружности на линии.
//	 * @param points Линия.
//	 * @param length Радиус окружности.
//	 * @param resultList Список результирующих точек.
//	 */
//	private static void getPoints(List<SignPoint2D> points, double length, List<SignPoint2D> resultList) {
//		IntRef ref = new IntRef();
//		ref.i = 1;
//		SignPoint2D center = points.get(0);
//		SignPoint2D next = getNext(center, length, points, ref);
//		resultList.add(new SignPoint2D(center));
//		while (next != null) {
//			resultList.add(new SignPoint2D(next));
//			center = next;
//			next = getNext(center, length, points, ref);
//		}
//	}

//	/**
//	 * Получить точки на отрезке, отстоящие друг от друга на равном расстоянии.
//	 * @param begin Начальная точка.
//	 * @param end Конечная точка.
//	 * @param segmentLength Длина сегмента. Если количество отрезков этой длины,
//	 * размещённых на линии, будет дробным числом, произойдёт округление, в результате которого
//	 * длина сегментов результирующей линии не будет совпадать с переданной длиной сегмента.
//	 * @return Точки равных отрезков.
//	 */
//	private static List<SignPoint2D> toSegments(SignPoint2D begin, SignPoint2D end, double segmentLength) {
//		List<SignPoint2D> segments = new ArrayList<SignPoint2D>();
//		double distance = GeometryUtils.distanceBetweenPoints(begin, end);
//		double segmentsNum = distance / segmentLength;
//		double k = segmentsNum / Math.round(segmentsNum);
//		double resultSegmentLength = segmentLength * k;
//		int resultSegmentsNum = (int)Math.round(distance / resultSegmentLength);
//		for (double d = 1.0; d < (double)resultSegmentsNum; d++) {
//			segments.add(new SignPoint2D(GeometryUtils.absolute(begin, end, (resultSegmentLength * d) / distance)));
//		}
//		segments.add(new SignPoint2D(end));
//		return segments;
//	}

//	/**
//	 * Получить результирующую линию.
//	 * @param points Исходная линия.
//	 * @param baseSize Базовый размер отрезка.
//	 * @return Результирующая линия.
//	 */
//	private static List<SignPoint2D> getResultLine(List<SignPoint2D> points, double baseSize) {
//		List<SignPoint2D> resultline = new ArrayList<SignPoint2D>();
//		resultline.add(new SignPoint2D(points.get(0)));
//		IntRef ref = new IntRef();
//		ref.i = 1;
//
//		SignPoint2D last = new SignPoint2D(points.get(0));
//		List<SignPoint2D> nextPart = getNextPart(points, last, baseSize, ref);
//		while (nextPart != null) {
//			resultline.addAll(nextPart);
//			last = nextPart.get(nextPart.size() - 1);
//			nextPart = getNextPart(points, last, baseSize, ref);
//		}
//		return resultline;
//	}

//	/**
//	 * Получить следующую часть полилинии.
//	 * @param points Точки.
//	 * @param begin Точка, от которой начинается поиск.
//	 * @param baseSize Базовый размер шаблона.
//	 * @param ref Ссылка на индекс следующей точки.
//	 * @return Следующая часть полилинии.
//	 */
//	private static List<SignPoint2D> getNextPart(List<SignPoint2D> points, SignPoint2D begin, double baseSize, IntRef ref) {
//		if (ref.i >= points.size()) {
//			return null;
//		}
//		if (GeometryUtils.distanceBetweenPoints(begin, points.get((int)ref.i)) > baseSize * 0.5) {
//			List<SignPoint2D> part = new ArrayList<SignPoint2D>();
//			part.addAll(toSegments(begin, points.get(ref.i), baseSize));
//			ref.i++;
//			return part;
//		} else {
//			for (int i = (int)ref.i; i < points.size(); i++) {
//				ref.i = i;
//				if (GeometryUtils.distanceBetweenPoints(begin, points.get((int)ref.i)) > baseSize) {
//					SignPoint2D intersection = new SignPoint2D(getIntersection(begin, baseSize, points.get((int)ref.i - 1), points.get((int)ref.i)));
//					List<SignPoint2D> part = new ArrayList<SignPoint2D>();
//					part.add(intersection);
//					return part;
//				}
//			}
//			if ((int)ref.i == (int)points.size() - 1) {
//				ref.i++;
//				List<SignPoint2D> part = new ArrayList<SignPoint2D>();
//				part.add(new SignPoint2D(points.get(points.size() - 1)));
//				return part;
//			}
//		}
//		return null;
//	}

//	/**
//	 * Получить следующую точку.
//	 * @param c Центра окружности.
//	 * @param r Радиус.
//	 * @param points Линия.
//	 * @param ref Ссылка на значение индекса, с которого следует начинать отсчёт.
//	 * @return Точка пересечения окружности и линии.
//	 */
//	private static SignPoint2D getNext(SignPoint2D c, double r, List<SignPoint2D> points, IntRef ref) {
//		int pointsSize = points.size();
//		double distance = 0.0;
//		for (int i = ref.i; i < pointsSize; i++) {
//			SignPoint2D current = points.get(i);
//			distance = GeometryUtils.distanceBetweenPoints(c, current);
//			if (distance >= r) {
//				if (ref.i < i) {
//					ref.i = i;
//					return getIntersection(c, r, points.get(i - 1), current);
//				} else {
//					ref.i = i;
//					return GeometryUtils.absolute(c, current, r / distance);
//				}
//			}
//		}
//		return null;
//	}

//	/**
//	 * Скоректировать размер последнего сегмента.
//	 * @param line Линия.
//	 */
//	private void correctLastSegment(List<SignPoint2D> line) {
//		if (GeometryUtils.distanceBetweenPoints(line.get(line.size() - 1 - 1),
//				line.get(line.size() - 1)) < pattern.getSize() / 2.0) {
//			line.remove(line.size() - 1 - 1);
//		}
//	}

}
