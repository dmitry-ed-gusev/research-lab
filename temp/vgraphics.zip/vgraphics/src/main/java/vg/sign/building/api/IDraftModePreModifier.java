package vg.sign.building.api;

import vg.sign.edit.api.ISignEditor;

/**
 * Интерфейс модификатора для чернового отображения.
 */
public interface IDraftModePreModifier extends IPreBuildModifier {

    /**
     * Получить правила редактирования.
     *
     * @return правила редактирования.
     */
    public ISignEditor getSignEditor();

    /**
     * Установить правила редактирования.
     *
     * @param signEditor правила редактирования.
     */
    public void setSignEditor(ISignEditor signEditor);
}
