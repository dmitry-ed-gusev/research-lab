package vg.sign.visual.tools.pen;

import vg.sign.visual.api.ISolidPenCore;

/**
 * Сплошное перо.
 */

public class SolidPenCore implements ISolidPenCore {

    /***/
    public SolidPenCore() {
    }


    @Override
    public SolidPenCore clone() {
        try {
            SolidPenCore clonedObject = (SolidPenCore) super.clone();
            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }

}
