package vg.sign.attributes.types.enums;

import vg.sign.attributes.api.IAttributeType;
import vg.sign.attributes.api.IAttributeValue;

/**
 * Значение атрибута: перечисление.
 */
public class EnumAttributeValue implements IAttributeValue {

    /**
     * Индекс элемента в перечислении.
     */
    protected int value;


    /***/
    public EnumAttributeValue() {
        this.value = 0;
    }

    /**
     * @param value Индекс элемента в перечислении.
     */
    public EnumAttributeValue(int value) {
        super();
        this.value = value;
    }


    @Override
    public String toString() {
        return String.valueOf(value);
    }

    @Override
    public EnumAttributeValue clone() {
        try {
            EnumAttributeValue clonedObject = (EnumAttributeValue) super.clone();
            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public IAttributeValue convert(IAttributeType type) {
        // todo: temporary commented
        /*
        if (type instanceof IntegerAttributeType) {
            IntegerAttributeValue newValue = new IntegerAttributeValue();
            newValue.setValue(value);
            return newValue;
        } else if (type instanceof StringAttributeType) {
            StringAttributeValue newValue = new StringAttributeValue();
            newValue.setValue("" + value);
            return newValue;
        } else if (type instanceof TimeAttributeType) {
            TimeAttributeValue newValue = new TimeAttributeValue();
            return newValue;
        }
        */
        return null;
    }

    /**
     * Получить значение.
     *
     * @return Значение.
     */
    public int getValue() {
        return value;
    }

    /**
     * Задать значение.
     *
     * @param value Значение.
     */
    public void setValue(int value) {
        this.value = value;
    }

}
