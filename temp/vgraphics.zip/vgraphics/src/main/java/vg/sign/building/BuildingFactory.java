package vg.sign.building;

import vg.draw.vobject.VGBrush;
import vg.draw.vobject.VGObject;
import vg.draw.vobject.VGPen;
import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.building.api.*;
import vg.sign.building.builders.AbstractSignBuilder;
import vg.sign.building.modifiers.ContourPostModifier;
import vg.sign.building.modifiers.DraftModePreModifier;
import vg.sign.building.modifiers.GroupPreModifier;
import vg.sign.visual.api.ISignVisual;
import vg.sign.visual.signs.PointSignVisual;

import java.util.List;

/**
 * Фабрика компонента построителя.
 */
public final class BuildingFactory {

    private BuildingFactory() {
        // неинстанцируемость
    }

    /**
     * Создать построитель площадного знака.
     *
     * @return Построитель площадного знака.
     */
    /*public static ISignBuilder createAreaGraphBuilder() {
        return new AreaGraphBuilder();
    }

    *//**
     * Создать построитель линейного знака.
     *
     * @return Построитель линейного знака.
     *//*
    public static ISignBuilder createLineGraphBuilder() {
        return new LineGraphBuilder();
    }

    *//**
     * Создать построитель точечного знака.
     *
     * @return Построитель точечного знака.
     *//*
    public static ISignBuilder createPointGraphBuilder() {
        return new PointGraphBuilder();
    }

    *//**
     * Создать интерфейс для работы с графическим элементов с расчитанными параметрами.
     *
     * @return Интерфейс для работы с графическим элементов с расчитанными параметрами.
     *//*
    public static ICalculatedGraph createCalculatedGraph() {
        return new CalculatedGraph();
    }
*/
/*
    */
/**
     * Создать модификатор чернового отображения.
     *
     * @return Модификатор чернового отображения.
     */
    public static IDraftModePreModifier createDraftModePreModifier() {
        return new DraftModePreModifier();
    }

/**
     * Создать групповой предварительный модификатор.
     *
     * @return Групповой предварительный модификатор.
     */
    public static IGroupPreModifier createGroupPreModifier() {
        return new GroupPreModifier();
    }

/**
     * Создать мигающий предварительный модификатор.
     *
     * @param element   Очередной премодификатор.
     * @param intervals Временные интервалы мигания.
     * @return Мигающий предварительный модификатор.
     *//*

    public static IPreBuildModifier createBlinkPreModifier(IPreBuildModifier element, double... intervals) {
        return new BlinkPreModifier(element, intervals);
    }

    */
/**
     * Создать рамочный постмодификатор.
     *
     * @return Рамочный постмодификатор.
     *//*

    public static IPostBuildModifier createBoundsPostModifier() {
        return new BoundsPostModifier();
    }

    */
/**
     * Создать контурный модификатор.
     *
     * @return Контурный модификатор.
     */
    public static IContourModePostModifier createContourPostModifier() {
        return new ContourPostModifier();
    }

/**
     * Создать групповой постмодификатор.
     *
     * @return Групповой постмодификатор.
     *//*

    public static IGroupPostModifier createGroupPostModifier() {
        return new GroupPostModifier();
    }

    */
/**
     * Создать мигающий постмодификатор.
     *
     * @param element   Очередной постмодификатор.
     * @param intervals Временные интервалы мигания.
     * @return Мигающий постмодификатор.
     *//*

    public static IPostBuildModifier createBlinkPostModifier(IPostBuildModifier element, double... intervals) {
        return new BlinkPostModifier(element, intervals);
    }

    */
/**
     * Создать постмодификатор, меняющий цвет изображения.
     *
     * @param color Цвет.
     * @param mask  Маска.
     * @return Цветовой постмодификатор.
     *//*

    public static IPostBuildModifier createColorPostModifier(int color, int mask) {
        return new ColorPostModifier(color, mask);
    }

    */
/**
     * Создать растеризатор.
     *
     * @return Растеризатор.
     *//*

    public static IEuzRasterizer createEuzRasterizer() {
        return new EuzRasterizer();
    }
*/

    /**
     * Создать построитель для визуального представления знака.
     *
     * @param signVisual Визуальное представление знака.
     * @return Построитель знака.
     */
    public static ISignBuilder createBuilder(ISignVisual signVisual) {
        return AbstractSignBuilder.createBuilder(signVisual);
    }

/*
    */
/**
     * Создать перо на основе ЭУЗ.
     *
     * @param psv Точечный ЭУЗ.
     * @return Перо на основе ЭУЗ.
     *//*

    public static VGPen createVGEuzPen(PointSignVisual psv) {
        return new VGEuzPen(psv);
    }

    */
/**
     * Создать Заливку наоснове ЭУЗ.
     *
     * @param psv Точечный ЭУЗ.
     * @return Заливка на основе ЭУЗ.
     *//*

    public static VGBrush createVGEuzBrush(PointSignVisual psv) {
        return new VGEuzBrush(psv);
    }

    */
/**
     * Создать перо с шаблоном.
     *
     * @param pp    Шаблон.
     * @param width Ширина.
     * @param color Цвет.
     * @return Перо с шаблоном.
     *//*

    public static VGPen createVGPatternPen(IPenPattern pp, double width, int color) {
        return new VGPatternPen(color, width, pp);
    }

    */
/**
     * Создать заливку со штриховкой.
     *
     * @param color Цвет.
     * @param width Ширина линий.
     * @param bs    Штриховка.
     * @param angle Угол заливки.
     * @return Заливка со штриховкой.
     *//*

    public static VGBrush createVGShadingBrush(int color, double width, IBrushShading bs, double angle) {
        return new VGShadingBrush(color, width, bs, angle);
    }

    */
/**
     * Построить графический элемент.
     *
     * @param graphElement     Графический элемент.
     * @param predefinedPoints Предопределённые точки.
     * @param matrix           Матрица перехода из локальной с.к. знака в с.к. документа.
     * @param angle            Угол знака.
     * @return Изображение графического элемента.
     *//*

    public static VGObject buildGraphElement(IGraphElement graphElement, List<BasePoint2D> predefinedPoints, BaseMatrix2D matrix, double angle) {
        return PointGraphBuilder.buildGraphElement(graphElement, predefinedPoints, matrix, angle);
    }
*/

}