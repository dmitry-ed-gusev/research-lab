package vg.sign.edit.api;

/**
 * Интерфейс для контрольной точки для редактирования разрывов и положения точечных знаков на линейном.
 *
 * @author Giller
 */
public interface IPositionControlPoint {

    /**
     * Получить позицию точки на прямой в %-ах от 0 до 1.
     *
     * @return позиция точки на прямой.
     */
    public double getPositionOnLine();

}
