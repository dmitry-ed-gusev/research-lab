package vg.sign.edit;

import vg.sign.edit.api.ISignEditor;
import vg.sign.edit.editors.FlagstaffSignEditor;
import vg.sign.edit.editors.GroupSignEditor;
import vg.sign.edit.editors.PointSignEditor;
import vg.sign.visual.api.IGroupSignVisual;
import vg.sign.visual.api.ISignVisual;
import vg.sign.visual.signs.FlagstaffSignVisual;
import vg.sign.visual.signs.LineSignVisual;
import vg.sign.visual.signs.PointSignVisual;
import vg.sign.visual.signs.TableSignVisual;

/**
 * Фабрика объектов компонента Editing.
 */
public final class SignEditFactory {

    private SignEditFactory() {
        // неинстанцируемость
    }

    /**
     * Создать типизированный редактор.
     *
     * @param visual Визуальное представление.
     * @return Типизированный редактор.
     */
    // TODO заменить полиморфизмом - методом getInstance() в ISignEditor
    public static ISignEditor createEditor(ISignVisual visual) {

        return visual instanceof PointSignVisual ? new PointSignEditor((PointSignVisual) visual) :
                //visual instanceof LineSignVisual ? new LineSignEditor((LineSignVisual) visual) :
                        //visual instanceof TableSignVisual ? new TableSignEditor(visual) :
                                visual instanceof FlagstaffSignVisual ? new FlagstaffSignEditor((FlagstaffSignVisual) visual) :
                                        //visual instanceof DemarkLineSignVisual ? new DemarkLineSignEditor((DemarkLineSignVisual) visual) :
                                          //      visual instanceof LeaderSignVisual ? new LeaderSignEditor((LeaderSignVisual) visual) :
                                            //            visual instanceof ILinkingLineSignVisual ? new LinkingLineSignEditor((ILinkingLineSignVisual) visual) :
                                                                visual instanceof IGroupSignVisual ? new GroupSignEditor((IGroupSignVisual) visual) :
                                              //                          visual instanceof ObservationAreaSignVisual ? new ObservationAreaSignEditor(visual) :
                                                //                                visual instanceof ThrustSignVisual ? new ThrustSignEditor(visual) :
                                                  //                                      visual instanceof FireStripeSignVisual ? new FireStripeSignEditor(visual) :
                                                    //                                            visual instanceof PositionAreaSignVisual ? new PositionAreaSignEditor(visual) :
                                                                                                       // visual instanceof StripSignVisual ? new StripSignEditor(visual) :
                                                                                                                null;

    }

}