package vg.sign.building.modifiers;

import vg.sign.attributes.api.IAttribute;
import vg.sign.attributes.types.enums.EnumAttributeType;
import vg.sign.attributes.types.enums.EnumAttributeValue;
import vg.sign.building.api.IAttributesPreBuildModifier;
import vg.sign.visual.api.IGraphElement;
import vg.sign.visual.api.IGroupGraphElement;
import vg.sign.visual.api.ISignVisual;
import vg.sign.visual.api.IText;
import vg.sign.visual.signs.TableSignVisual;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * Премодификатор текста графического элемента по значению атрибута.
 */
public class AttributeFormularModifier implements IAttributesPreBuildModifier {

    /**
     * Флаг включённости.
     */
    private boolean enabled = true;
    /**
     * Атрибуты.
     */
    private List<IAttribute> attributes;


    /***/
    public AttributeFormularModifier() {
        this.attributes = new ArrayList<IAttribute>();
    }


    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }


    @Override
    public void modify(ISignVisual visual) {
        if (visual instanceof TableSignVisual) {
            ((TableSignVisual) visual).calculate();
        }
        Map<String, IGraphElement> graphElementsMap = graphElementsAsMap(visual.getRootGraphElement());
        List<IAttribute> list = attributesAsList();
        for (IAttribute a : list) {
            String geID = a.getGraphElementID();
            IGraphElement ge = graphElementsMap.get(geID);
            if (ge != null) {
                IText text = ge.getText();
                if (text != null) {
                    if (a.getType() instanceof EnumAttributeType) {
                        List<String> strings = ((EnumAttributeType) a.getType()).getStrings();
                        if (strings.isEmpty()) {
                            text.setText("");
                        } else {
                            int index = ((EnumAttributeValue) a.getValue()).getValue();
                            if (index == -1 || index > strings.size()) {
                                text.setText(strings.get(0));
                            } else {
                                text.setText(strings.get(index));
                            }
                        }
                    }

                    // todo: temporary commented!!!
                    /*
                    else if (a.getType() instanceof IAdditionalAttributeType) {
                        IAdditionalAttributeType type = (IAdditionalAttributeType) a.getType();
                        IAdditionalAttributeValue value = (IAdditionalAttributeValue) a.getValue();
                        List<Entry<String, String>> values = type.getValues();
                        if (values.isEmpty()) {
                            text.setText("");
                        } else {
                            int index = value.getValue();
                            if (index > -1 && index < values.size()) {
                                text.setText(values.get(index).getValue());
                            } else {
                                text.setText(values.get(0).getValue());
                            }
                        }
                    } */
                    else {
                        text.setText(a.getValue().toString());
                    }
                    graphElementsMap.get(geID).setText(text);
                }
            }
        }
    }

    @Override
    public List<IAttribute> getAttributes() {
        return attributes;
    }

    /**
     * Отобразить дерево графических элементов в карту.
     *
     * @param graphElement Дерево графических элементов.
     * @return Карта.
     */
    private Map<String, IGraphElement> graphElementsAsMap(IGraphElement graphElement) {
        Map<String, IGraphElement> map = new Hashtable<String, IGraphElement>();
        if (graphElement != null && graphElement.getText() != null && graphElement.getText().getText() != null) {
            map.put(graphElement.getId(), graphElement);
        }
        if (graphElement instanceof IGroupGraphElement) {
            for (IGraphElement ge : ((IGroupGraphElement) graphElement).getElements()) {
                map.putAll(graphElementsAsMap(ge));
            }
        }
        return map;
    }

    /**
     * Получить атрибуты в виде списка.
     *
     * @return Атрибуты в виде списка.
     */
    private List<IAttribute> attributesAsList() {
        List<IAttribute> list = new ArrayList<IAttribute>();
        for (IAttribute a : attributes) {
            list.addAll(attributesAsList(a));
        }
        return list;
    }

    /**
     * Отобразить атрибуты в список.
     *
     * @param attribute Атрибуты.
     * @return Список атрибутов.
     */
    private List<IAttribute> attributesAsList(IAttribute attribute) {
        List<IAttribute> list = new ArrayList<IAttribute>();
        if (attribute.getGraphElementID() != null) {
            list.add(attribute);
        }
        for (IAttribute a : attribute.getChildren()) {
            list.addAll(attributesAsList(a));
        }
        return list;
    }

}
