package vg.sign.generalization;

import vg.geometry.GeometryProcessor;
import vg.geometry.cp.AbstractCPoint;
import vg.geometry.cp.CPoint;
import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.edit.api.*;
import vg.sign.generalization.api.IGeneralization;
import vg.sign.generalization.api.IGeneralizationModifier;
import vg.sign.visual.api.IAnchorPoint;
import vg.sign.visual.api.IAnchorPointsList;
import vg.sign.visual.api.ISignVisual;
import vg.sign.visual.signs.DemarkLineSignVisual;
import vg.sign.visual.signs.LineSignVisual;
import vg.sign.visual.signs.PointSignVisual;
import vg.sign.visual.signs.PositionAreaSignVisual;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Модификатор ЭУЗ по правилам генерализации.
 *
 * @author Giller
 */
public class GeneralizationModifier implements IGeneralizationModifier {

    /**
     * Контрольная точка для предопределённой точки.
     *
     * @author Giller
     */
    private class ModifiedPredefinedPoint extends AbstractCPoint implements IControlPoint, IPredefinedControlPoint {

        /** */
        private static final long serialVersionUID = -7916383677835512489L;
        /**
         * Текущее визуальное представление точечного знака.
         */
        PointSignVisual pointSignVisual;
        /**
         * Индекс предопредёлнной точки для управления.
         */
        int predefinedPointIndex;


        /**
         * Конструктор по умолчанию.
         *
         * @param pointSignVisual      визуальное представление знака.
         * @param predefinedPointIndex индекс предопредёлнной точки для управления..
         */
        public ModifiedPredefinedPoint(PointSignVisual pointSignVisual, int predefinedPointIndex) {
            this.pointSignVisual = pointSignVisual;
            this.predefinedPointIndex = predefinedPointIndex;
            this.dependencies.add(getPredefinedPoint());
            this.calculate();
        }

        @Override
        public CPoint calculate() {
            // Необходимо вызвать перерасчет внутренней точки.
            getPredefinedPoint().calculate();

            BaseMatrix2D toDocumentMatrix = getToDocumentMatrix(pointSignVisual);
            CPoint cp = this.getPredefinedPoint();
            point = new BasePoint2D(toDocumentMatrix.transformPoint(new BasePoint2D(cp.getX(), cp.getY())));
            return this;
        }

        @Override
        public CPoint decalculate() {
            BaseMatrix2D fromDocumentMatrix = getToDocumentMatrix(pointSignVisual).invert();
            BasePoint2D point = fromDocumentMatrix.transformPoint(this.point);
            PointSignVisual.AbstractPredefinedPoint predefinedPoint = getPredefinedPoint();
            predefinedPoint.setX(point.getX());
            predefinedPoint.setY(point.getY());

            // Необходимо вызвать обратный расчет внутренней точки.
            predefinedPoint.decalculate();
            return this;
        }

        @Override
        public int getPredefinedPointIndex() {
            return predefinedPointIndex;
        }

        /**
         * Получить предопределённую точку.
         *
         * @return получить предопределённу. точку.
         */
        private PointSignVisual.AbstractPredefinedPoint getPredefinedPoint() {
            return pointSignVisual.getPredefinedPoints().get(predefinedPointIndex);
        }

        @Override
        public boolean isEditable() {
            return getPredefinedPoint().isEditable();
        }

        @Override
        public void setEditable(boolean editable) {
            getPredefinedPoint().setEditable(editable);
        }

        @Override
        public IControlPoint add() {
            return null;
        }

        @Override
        public boolean remove() {
            return false;
        }

    }


    // TODO Идея скопирована из редактора линейного знака.

    /**
     * Контрольная точка размера разрыва.
     *
     */
    private class ModifyBreakSizeControlPoint extends AbstractCPoint implements IControlPoint, IPositionControlPoint, IBreakSizeControlPoint {
        /***/
        private static final long serialVersionUID = -4607756937490369575L;
        /**
         * Индекс разрыва.
         */
        private int index;
        /**
         * Сторона разрыва (начало - false, конец - true).
         */
        private boolean side;
        /**
         * Визуализация линейного знака.
         */
        private LineSignVisual lineSV;
        /**
         * Коэффициент масштабирования генерализации.
         */
        private double genCoefficient;

        /**
         * Создание контрольной точки для размера разрыва.
         *
         * @param lineSV         визуализация линейного знака.
         * @param index          Индекс разрыва.
         * @param side           Сторона разрыва (начало - false, конец - true).
         * @param genCoefficient коэффициент масштабирования генерализации.
         */
        public ModifyBreakSizeControlPoint(LineSignVisual lineSV, int index, boolean side, double genCoefficient) {
            this.index = index;
            this.side = side;
            this.lineSV = lineSV;
            this.genCoefficient = genCoefficient;
            this.calculate();
        }

        @Override
        public boolean isEditable() {
            return true;
        }

        @Override
        public CPoint calculate() {
            List<BasePoint2D> linePoints = getLinePoints();
            double lineLength = GeometryProcessor.getPolylineLength(linePoints);
            LineSignVisual.LineBreak lineBreak = this.lineSV.getLineBreaks().get(this.index);
            BasePoint2D pointOnLine = GeometryProcessor.getPointOnPolylineByShift(
                    linePoints,
                    lineBreak.getPosition() + this.genCoefficient * Math.abs(lineBreak.getWidth() * 0.5 / lineLength) * (this.side ? 1.0 : -1.0));
            point = new BasePoint2D(pointOnLine);
            return this;
        }

        @Override
        public CPoint decalculate() {
            List<BasePoint2D> linePoints = getLinePoints();
            BasePoint2D pointOnLine = point;
            double position = GeometryProcessor.nearestPointLocationOnPolyline(linePoints, pointOnLine);
            double lineLength = GeometryProcessor.getPolylineLength(linePoints);
            LineSignVisual.LineBreak lineBreak = this.lineSV.getLineBreaks().get(this.index);

            double width = Math.abs(lineBreak.getPosition() - position) * 2.0 * lineLength;
            lineBreak.setWidth(width / this.genCoefficient);
            return this;
        }

        @Override
        public double getPositionOnLine() {
            List<BasePoint2D> linePoints = getLinePoints();
            double lineLength = GeometryProcessor.getPolylineLength(linePoints);
            LineSignVisual.LineBreak lineBreak = this.lineSV.getLineBreaks().get(this.index);
            return lineBreak.getPosition() + Math.abs(lineBreak.getWidth() * 0.5 / lineLength) * (this.side ? 1.0 : -1.0);
        }

        @Override
        public IControlPoint add() {
            return null;
        }

        @Override
        public boolean remove() {
            return false;
        }

        /**
         * Получить точки линии.
         *
         * @return точки линии.
         */
        private List<BasePoint2D> getLinePoints() {
            return buildLinePointsFromAP(this.lineSV.getAnchorPoints(), this.lineSV.isSmooth(), false);
        }

        /**
         * Получить точки фигуры.
         *
         * @param anchorPoints Точки привязки знака.
         * @param smooth       Сглаженность линии.
         * @param closed       Замкнутость линии.
         * @return Расчитанные точки линии.
         * @note Скопировано из SignEditor.
         */
        private List<BasePoint2D> buildLinePointsFromAP(List<IAnchorPoint> anchorPoints, boolean smooth, boolean closed) {
            List<BasePoint2D> basePoints = new ArrayList<BasePoint2D>(anchorPoints.size());
            for (IAnchorPoint ap : anchorPoints)
                basePoints.add(ap.getPoint());
            return this.buildLinePoints(basePoints, smooth, closed);
        }

        /**
         * Получить точки фигуры.
         *
         * @param basePoints Базовые точки линии.
         * @param smooth     Сглаженность линии.
         * @param closed     Замкнутость линии.
         * @return Расчитанные точки линии.
         * @note Скопировано из SignEditor.buildLinePoints(List, boolean, boolean).
         */
        private List<BasePoint2D> buildLinePoints(List<? extends BasePoint2D> basePoints, boolean smooth, boolean closed) {
            if (smooth) {
                List<BasePoint2D> referencePoints = new ArrayList<BasePoint2D>();
                for (BasePoint2D bp : basePoints)
                    referencePoints.add(new BasePoint2D(bp));
                List<BasePoint2D> linePoints = new ArrayList<BasePoint2D>();
                GeometryProcessor.getSplinePoints(linePoints, referencePoints, GeometryProcessor.ST_CUBIC, closed);
                return (List) linePoints;
            } else {
                List<BasePoint2D> linePoints = new ArrayList<BasePoint2D>();
                for (BasePoint2D bp : basePoints)
                    linePoints.add(new BasePoint2D(bp));
                if (closed && !linePoints.isEmpty() && !linePoints.get(0).equals(linePoints.get(linePoints.size() - 1)))
                    linePoints.add(new BasePoint2D(linePoints.get(0)));
                return linePoints;
            }
        }
    }


    /**
     * Флаг включённости.
     */
    private boolean enabled = true;
    /**
     * Рабочий масштаб.
     */
    private double workScale;
    /**
     * Генерализация.
     */
    private IGeneralization generalization;
    /**
     * Ссылка на оригинальное визуальное представление.
     */
    private ISignEditor signEditor;


    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }


    @Override
    public void modify(ISignVisual visual) {
        if (generalization == null)
            return;

        if (!generalization.getVisibility((int) workScale)) {
            visual.setVisible(false);
            return;
        } else
            visual.setVisible(true);

        double k = this.generalization.getCoefficient((int) workScale);
        BasePoint2D p = visual.getScale();
        visual.setScale(new BasePoint2D(p.getX() * k, p.getY() * k));

        // Корректировка контрольных предопределённых точек.
        if (visual instanceof PointSignVisual) {
            PointSignVisual pointSignVisual = (PointSignVisual) this.signEditor.getSignVisual();
            List<PointSignVisual.AbstractPredefinedPoint> predefinedPoints = pointSignVisual.getPredefinedPoints();
            for (int i = 0; i < this.signEditor.getControlPoints().size(); ++i) {
                IControlPoint cp = this.signEditor.getControlPoints().get(i);
                Iterator<CPoint> iterator = cp.getDependencies().iterator();
                if (!iterator.hasNext()) continue;
                CPoint prePoint = iterator.next();
                if (!(prePoint instanceof PointSignVisual.AbstractPredefinedPoint)) continue;
                for (int j = 0, n = predefinedPoints.size(); j < n; j++)
                    if (prePoint == predefinedPoints.get(j))
                        this.signEditor.getControlPoints().set(i, new ModifiedPredefinedPoint(pointSignVisual, j));
            }

        } else if (visual instanceof LineSignVisual) {
            LineSignVisual lineSV = (LineSignVisual) visual;
            for (LineSignVisual.LinkedSign linkedSign : lineSV.getLinkedSigns()) {
                p = linkedSign.getSign().getScale();
                linkedSign.getSign().setScale(new BasePoint2D(p.getX() * k, p.getY() * k));
            }

            for (LineSignVisual.LineBreak lineBreak : lineSV.getLineBreaks())
                lineBreak.setWidth(lineBreak.getWidth() * k);

            // Переопределение контрольных точек для размера разрывов.
            // С учетом коэффециента масштабирования от генерализации.
            lineSV = (LineSignVisual) this.signEditor.getSignVisual();
            Iterator<LineSignVisual.LineBreak> it = lineSV.getLineBreaks().iterator();
            if (it.hasNext()) {
                LineSignVisual.LineBreak curBreak = it.next();
                boolean secondSide = false;
                for (int i = 0; i < this.signEditor.getControlPoints().size(); ++i) {
                    IControlPoint cp = this.signEditor.getControlPoints().get(i);
                    if (cp instanceof IBreakSizeControlPoint) {
                        this.signEditor.getControlPoints().set(i, new ModifyBreakSizeControlPoint(lineSV, lineSV.getLineBreaks().indexOf(curBreak), secondSide, k));
                        if (secondSide) {
                            if (it.hasNext())
                                curBreak = it.next();
                            else
                                break;
                        }
                        secondSide = !secondSide;
                    }
                }
            }

        } else if (visual instanceof PositionAreaSignVisual) {
            PositionAreaSignVisual posAreaSV = (PositionAreaSignVisual) visual;
            posAreaSV.setNodeRadius(posAreaSV.getNodeRadius() * k);

        } else if (visual instanceof DemarkLineSignVisual) {
            DemarkLineSignVisual demLineSV = (DemarkLineSignVisual) visual;
            demLineSV.setNodesRadius(demLineSV.getNodesRadius() * k);
        }
    }

    @Override
    public double getWorkScale() {
        return this.workScale;
    }

    @Override
    public void setWorkScale(double workScale) {
        this.workScale = workScale;
    }

    @Override
    public IGeneralization getGeneralization() {
        return this.generalization;
    }

    @Override
    public void setGeneralization(IGeneralization generalization) {
        this.generalization = generalization;
    }

    @Override
    public ISignEditor getSignEditor() {
        return this.signEditor;
    }

    @Override
    public void setSignEditor(ISignEditor signEditor) {
        this.signEditor = signEditor;
    }

    /**
     * Получить матрицу преобразования точки в документ.
     *
     * @param pointSV точечное представление знака.
     * @return матрица преобразования точки в документ.
     */
    BaseMatrix2D getToDocumentMatrix(PointSignVisual pointSV) {
        IAnchorPointsList anchorPoints = pointSV.getAnchorPoints();
        BasePoint2D anchorPoint =
                !anchorPoints.isEmpty() ?
                        anchorPoints.get(0).getPoint() :
                        new BasePoint2D(0.0, 0.0);

        double k = this.generalization.getCoefficient((int) workScale);
        BasePoint2D scale;
        if (this.generalization != null)
            scale = new BasePoint2D(pointSV.getScale().getX() * k, pointSV.getScale().getY() * k);
        else
            scale = new BasePoint2D(pointSV.getScale().getX(), pointSV.getScale().getY());

        return new BaseMatrix2D()
                // Ось Y знака направлена вверх, а ось Y холста - вниз; Учитываем это:
                .scale(1.0, -1.0, 0, 0)
                // Трансформации знака:
                .scale(scale.getX(), scale.getY(), 0, 0)
                .rotate(pointSV.getAngle(), 0, 0)
                // Перемещение к точке привязки:
                .translate(anchorPoint);
    }

}
