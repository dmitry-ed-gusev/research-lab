package vg.sign.visual;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.visual.api.*;
import vg.sign.visual.signs.AbstractGroupGraphElement;
import vg.sign.visual.signs.FlagstaffSignVisual;
import vg.sign.visual.signs.PointSignVisual;
import vg.sign.visual.tools.CircleGraphElement;
import vg.sign.visual.tools.LineGraphElement;
import vg.sign.visual.tools.Text;
import vg.sign.visual.tools.brush.Brush;
import vg.sign.visual.tools.brush.BrushElement;
import vg.sign.visual.tools.brush.SolidBrushCore;
import vg.sign.visual.tools.pen.PatternPenCore;
import vg.sign.visual.tools.pen.Pen;
import vg.sign.visual.tools.pen.PenElement;
import vg.sign.visual.tools.pen.SolidPenCore;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Фабрика объектов компонента Visual.
 */

public final class SignVisualFactory {

    private final static Log LOG = LogFactory.getLog(SignVisualFactory.class);

    static {
        LOG.debug("SignVisualFactory loaded.");
    }

    private SignVisualFactory() {
        // неинстанцируемость
    }

    /**
     * Создать точечный знак.
     *
     * @return Точечный знак.
     */
    public static PointSignVisual createPointSignVisual() {
        return new PointSignVisual();
    }

/*
    */
/**
     * Создать линейный знак.
     *
     * @return Линейный знак.
     *//*

    public static LineSignVisual createLineSignVisual() {
        return new LineSignVisual();
    }

    */
/**
     * Создать площадной знак.
     *
     * @return Площадной знак.
     *//*

    public static AreaSignVisual createAreaSignVisual() {
        return new AreaSignVisual();
    }

    */
/**
     * Создать таблицу.
     *
     * @param rows    количество строк.
     * @param columns количество столбцов.
     * @return таблица размерами rows x columns.
     *//*

    public static TableSignVisual createTableSignVisual(int rows, int columns) {
        return new TableSignVisual(rows, columns);
    }

    */
/**
     * Создать текстовый контент ячейки.
     *
     * @param text текст.
     * @return текстовый контент ячейки.
     *//*

    public static ITextCellContent createTextCellContent(IText text) {
        return new TextCellContent(text);
    }

    */
/**
     * Создать контент-знак для ячейки.
     *
     * @param visual визуальное представление знака.
     * @return контент-знак для ячейки.
     *//*

    public static IEuzCellContent createEuzCellContent(ISignVisual visual) {
        return new EuzCellContent(visual);
    }

    */
/**
     * Создать спец.знак - полоса.
     *
     * @return Спец.знак - полоса.
     *//*

    public static StripSignVisual createStripSignVisual() {
        return new StripSignVisual();
    }

    */
/**
     * Создать спец. знак - район наблюдения.
     *
     * @return Спец.знак - район наблюдения.
     *//*

    public static ObservationAreaSignVisual createObservationAreaSignVisual() {
        return new ObservationAreaSignVisual();
    }

    */
/**
     * Создать формуляр.
     *
     * @return Формуляр.
     *//*

    public static FormularSignVisual createFormularSignVisual() {
        return new FormularSignVisual();
    }

    */
/**
     * Создать разграничительную линию.
     *
     * @return Разграничительная линия.
     *//*

    public static DemarkLineSignVisual createDemarkLineSignVisual() {
        return new DemarkLineSignVisual();
    }

    */
/**
     * Создать Направление удара.
     *
     * @return Направление удара.
     *//*

    public static ThrustSignVisual createThrustSignVisual() {
        return new ThrustSignVisual();
    }

    */
/**
     * Создать промежуточную точку направления удара.
     *
     * @return промежуточная точка направления удара.
     *//*

    public static ThrustSignVisual.IntermediatePoint createIntermediatePoint() {
        return new ThrustSignVisual.IntermediatePoint(0, 0);
    }

    */
/**
     * Создать геометрию для визуализации удара.
     *
     * @param thrustSV визуализация удара.
     * @return геометрия для визуализации удара.
     *//*

    public static ThrustSignVisual.Geometry createThrustGeometry(ThrustSignVisual thrustSV) {
        return new ThrustSignVisual.Geometry(thrustSV);
    }

    */
/**
     * Создать смысловое значение Направление удара.
     *
     * @return Смысловое значение Направление удара.
     *//*

    public static ThrustSignVisual.Direction createThrustDirection() {
        return new ThrustSignVisual.Direction();
    }

    */
/**
     * Создать групповой знак.
     *
     * @return групповой знак.
     *//*

    public static IGroupSignVisual createGroupSignVisual() {
        return new GroupSignVisual();
    }

    */
/**
     * Создать дочерний элемент для группового знака.
     *
     * @param visual визуальное представление дочернего знака.
     * @return дочерний элемент для группового знака.
     *//*

    public static IGroupSignVisual.IChild createChild(ISignVisual visual) {
        return new GroupSignVisual.Child(visual);
    }

    */
/**
     * Создать выноску.
     *
     * @return выноска.
     *//*

    public static LeaderSignVisual createLeaderSignVisual() {
        return new LeaderSignVisual();
    }

    */
/**
     * Создать дочерний элемент выноски.
     *
     * @param visual визуальное представление знака.
     * @return дочерний элемент выноски.
     *//*

    public static LeaderSignVisual.LeaderChild createLeaderChild(ISignVisual visual) {
        return new LeaderSignVisual.LeaderChild(visual);
    }

    */
/**
     * Создать дочерний элемент выноски.
     *
     * @param visual визуальное представление знака.
     * @param offset смещение в миллиметрах.
     * @return дочерний элемент выноски.
     *//*

    public static LeaderSignVisual.LeaderChild createLeaderChild(ISignVisual visual, BasePoint2D offset) {
        return new LeaderSignVisual.LeaderChild(visual, offset);
    }

    */
/**
     * Создать флагшток.
     *
     * @return флагшток.
     */
    public static FlagstaffSignVisual createFlagstaffSignVisual() {
        return new FlagstaffSignVisual();
    }

/**
     * Создать дочерний элемент флагштока.
     *
     * @param visual визуальное представление знака.
     * @return дочерний элемент флагштока.
     */
/*
    public static FlagstaffSignVisual.FlagstaffChild createFlagstaffChild(ISignVisual visual) {
        return new FlagstaffSignVisual.FlagstaffChild(visual);
    }
*/

/**
     * Создать дочерний элемент флагштока.
     *
     * @param visual визуальное представление знака.
     * @param offset смещение в миллиметрах по вертикали вверх
     * @return дочерний элемент флагштока.
     */
    public static FlagstaffSignVisual.FlagstaffChild createFlagstaffChild(ISignVisual visual, double offset) {
        return new FlagstaffSignVisual.FlagstaffChild(visual, offset);
    }

/**
     * Создать знак "Соединительная линия".
     *
     * @return знак "Соединительная линия".
     *//*

    public static LinkingLineSignVisual createLinkingLineSignVisual() {
        return new LinkingLineSignVisual();
    }

    */
/**
     * Создать соединительную линию для знака "Соединительная линия".
     *
     * @param signIndex1  Индекс первого знака.
     * @param pointIndex1 Индекс точки первого знака.
     *                    <p> Если -1, то берётся точка привязки у знака, если 0 и больше, то берётся соответствующая предопределенная точка.
     * @param signIndex2  Индекс второго знака.
     * @param pointIndex2 Индекс точки второго знака.
     *                    <p> Если -1, то берётся точка привязки у знака, если 0 и больше, то берётся соответствующая предопределенная точка.
     * @param pen         Перо соединительной линии.
     * @return соединительная линия.
     *//*

    public static LinkingLineSignVisual.Line createLine(int signIndex1, int pointIndex1, int signIndex2, int pointIndex2, IPen pen) {
        return new LinkingLineSignVisual.Line(signIndex1, pointIndex1, signIndex2, pointIndex2, pen);
    }

    */
/**
     * Создать спец.знак - огневая полоса.
     *
     * @return Спец.знак - огневая полоса.
     *//*

    public static FireStripeSignVisual createFireStripeSignVisual() {
        return new FireStripeSignVisual();
    }

    */
/**
     * Создать позиционный район.
     *
     * @return Позиционный район.
     *//*

    public static PositionAreaSignVisual createPositionAreaSignVisual() {
        return new PositionAreaSignVisual();
    }

    */
/**
     * Создать контейнер знака для узла позиционного района.
     *
     * @return Контейнер знака для узла позиционного района.
     *//*

    public static PositionAreaSignVisual.NodeSign createNodeSign() {
        return new PositionAreaSignVisual.NodeSign();
    }

    */
/**
     * Создать точку привязки.
     *
     * @return Точка привязки.
     *//*

    public static IAnchorPoint createAnchorPoint() {
        return new AnchorPoint();
    }

    */
/**
     * Создать точку привязки.
     *
     * @param point    Координаты точки привязки.
     * @param semantic Смысловые значения (пары ключ-значение).
     * @return Точка привязки.
     *//*

    public static IAnchorPoint createAnchorPoint(BasePoint2D point, Object... semantic) {
        return new AnchorPoint(point, semantic);
    }

    */
/**
     * Создать точку привязки.
     *
     * @param point    Координаты точки привязки.
     * @param semantic Смысловые значения (пары ключ-значение).
     * @return Точка привязки.
     *//*

    public static IAnchorPoint createAnchorPoint(BasePoint2D point, Map<String, Object> semantic) {
        return new AnchorPoint(point, semantic);
    }

    */
/**
     * Создать список точек привязки.
     *
     * @param minSize Минимальное количество точек привязки.
     * @param maxSize Максимальное количество точек привязки.
     * @return Список точек привязки.
     *//*

    public static IAnchorPointsList createAnchorPointsList(int minSize, int maxSize) {
        return new AnchorPointsList(minSize, maxSize);
    }

    */
/**
     * Создать абсолютную предопределённую точку.
     *
     * @param editable Редактируемость точки.
     * @param x        X-координата точки.
     * @param y        X-координата точки.
     * @return Абсолютная предопределённая точка.
     */
    public static PointSignVisual.AbstractPredefinedPoint createAbsolutePredefinedPoint(
            boolean editable, double x, double y) {
        return new PointSignVisual.AbsolutePredefinedPoint(editable, x, y);
    }

/**
     * Создать смещённую точку.
     *
     * @param editable Редактируемость точки.
     * @param visual   Визуальное представление-владелец точки.
     * @param ppIndex  Индекс предопределённой точки.
     * @param dx       Смещение по X.
     * @param dy       Смещение по Y.
     * @return Смещённая точка.
     */
    public static PointSignVisual.AbstractPredefinedPoint createDisplacementPredefinedPoint(
            boolean editable, PointSignVisual visual, int ppIndex, double dx, double dy) {
        return ((PointSignVisual) visual).new DisplacementPredefinedPoint(editable, ppIndex, dx, dy);
    }

/**
     * Создать относительную точку.
     *
     * @param editable Редактируемость точки.
     * @param visual   Визуальное представление-владелец точки.
     * @param ppIndex1 Индекс первой предопределённой точки.
     * @param ppIndex2 Индекс второй предопределённой точки.
     * @param t        Коэффициент. (0 - первая точка, 1 - вторая точка).
     * @return Относительная точка.
     */
    public static PointSignVisual.AbstractPredefinedPoint createRelativePredefinedPoint(
            boolean editable, PointSignVisual visual, int ppIndex1, int ppIndex2, double t) {
        return ((PointSignVisual) visual).new RelativePredefinedPoint(editable, ppIndex1, ppIndex2, t);
    }

/**
     * Создать раздельно-относительную по X и Y точку.
     *
     * @param editable Редактируемость точки.
     * @param visual   Визуальное представление-владелец точки.
     * @param ppIndex1 Индекс первой предопределённой точки.
     * @param ppIndex2 Индекс второй предопределённой точки.
     * @param tx       Коэффициент по X. (0 - первая точка, 1 - вторая точка).
     * @param ty       Коэффициент по Y. (0 - первая точка, 1 - вторая точка).
     * @return Раздельно-относительная по X и Y точка.
     */
    public static PointSignVisual.AbstractPredefinedPoint createXYRelativePredefinedPoint(
            boolean editable, PointSignVisual visual, int ppIndex1, int ppIndex2, double tx, double ty) {
        return ((PointSignVisual) visual).new XYRelativePredefinedPoint(editable, ppIndex1, ppIndex2, tx, ty);
    }

/**
     * Создать линейный графический элемент.
     *
     * @return Линейный графический элемент.
     */
    public static ILineGraphElement createLineGraphElement() {
        return new LineGraphElement();
    }

/**
     * Создать графический элемент дуга.
     *
     * @return Графический элемент дуга.
     */

    public static ICircleGraphElement createCircleGraphElement() {
        return new CircleGraphElement();
    }

/**
     * Создать коннектор точечного знака к линейному.
     *
     * @return Коннектор точечного знака к линейному.
     *//*

    public static LineSignVisual.LinkedSign createLinkedSign() {
        return new LineSignVisual.LinkedSign();
    }

    */
/**
     * Создать разрыв линии.
     *
     * @return Разрыв линии.
     *//*

    public static LineSignVisual.LineBreak createLineBreak() {
        return new LineSignVisual.LineBreak();
    }

    */

     /**
     * Create a Pen.
     * @return Pen instance.
     */
    public static IPen createPen() {
        return new Pen();
    }


/**
     * Создать элемент пера.
     *
     * @return Элемент пера.
     */

    public static IPenElement createPenElement() {
        return new PenElement();
    }

/**
     * Создать сплошной сардечник пера.
     *
     * @return Сплошной сардечник пера.
     */

    public static ISolidPenCore createSolidPenCore() {
        return new SolidPenCore();
    }

/**
     * Создать шаблонный сердечник пера.
     *
     * @return Шаблонный сердечник пера.
     *//*

    public static IPatternPenCore createPatternPenCore() {
        return new PatternPenCore();
    }

    */
/**
     * Создать шаблонный сердечник пера.
     *
     * @param pattern Шаблон.
     * @return Шаблонный сердечник пера.
     *//*

    public static IPatternPenCore createPatternPenCore(IPenPattern pattern) {
        return new PatternPenCore(pattern);
    }

    */
/**
     * Создать шаблон пера.
     *
     * @return Шаблон пера.
     *//*

    public static IPenPattern createPenPattern() {
        return new PatternPenCore.PenPattern();
    }

    */
/**
     * Создать элемента шаблона пера.
     *
     * @return Элемента шаблона пера.
     */
    public static IPenPattern.IElement createPenPatternElement() {
        return new PatternPenCore.PenPattern.Element();
    }

/**
     * Создать заливку.
     *
     * @return Заливка.
     */
    public static IBrush createBrush() {
        return new Brush();
    }

/**
     * Создать элемент заливки.
     *
     * @return Элемент заливки.
     */
    public static IBrushElement createBrushElement() {
        return new BrushElement();
    }

/**
     * Создать сплошную основу заливки.
     *
     * @return Сплошная основа заливки.
     */
    public static ISolidBrushCore createSolidBrushCore() {
        return new SolidBrushCore();
    }

/**
     * Создать штриховую основу заливки.
     *
     * @return Штриховая основа заливки.
     *//*

    public static IShadingBrushCore createShadingBrushCore() {
        return new ShadingBrushCore();
    }

    */
/**
     * Создать штриховую основу заливки.
     *
     * @param shading Штриховка.
     * @return Штриховая основа заливки.
     *//*

    public static IShadingBrushCore createShadingBrushCore(IBrushShading shading) {
        return new ShadingBrushCore(shading);
    }

    */
/**
     * Создать штриховку заливки.
     *
     * @return Штриховка заливки.
     *//*

    public static IBrushShading createBrushShading() {
        return new ShadingBrushCore.Shading();
    }

    */
/**
     * Создать штриховку заливки.
     *
     * @param size     Размер штриховки в мм.
     * @param elements Элементы штриховки - пары (расстояние (%), угол (рад.)).
     *                 <p>Расстояние задаётся относительно базового размера.
     *                 Угол задаётся относительно горизонтали.
     * @return Штриховка заливки.
     *//*

    public static IBrushShading createBrushShading(double size, double... elements) {
        return new ShadingBrushCore.Shading(size, elements);
    }

    */
/**
     * Создать элемент штриховки заливки.
     *
     * @return Элемент штриховки заливки.
     *//*

    public static IBrushShading.IElement createBrushShadingElement() {
        return new ShadingBrushCore.Shading.Element();
    }

    */
/**
     * Создать текст.
     *
     * @return Текст.
     */
    public static IText createText() {
        return new Text();
    }

/**
     * Создать итератор Дерева графических элементов по всем не групповым Графическим элементам.
     *
     * @param graphElementsIterator Итератор графических элементов.
     * @return Итератор Дерева графических элементов по всем не групповым Графическим элементам.
     */
    public static Iterator<IGraphElement> createThroughGraphElementIterator(Iterator<IGraphElement> graphElementsIterator) {
        return new AbstractGroupGraphElement.ThroughGraphElementsIterator(graphElementsIterator);
    }

/**
     * Создать итератор Дерева графических элементов по всем не групповым Элементам пера.
     *
     * @param graphElementsIterator Итератор графических элементов.
     * @return Итератор Дерева графических элементов по всем не групповым Элементам пера.
     */
    public static Iterator<IPenElement> createThroughPenElementIterator(Iterator<IGraphElement> graphElementsIterator) {
        return new AbstractGroupGraphElement.ThroughPenElementsIterator(graphElementsIterator);
    }

/**
     * Создать итератор Дерева графических элементов по всем не групповым Элементам заливки.
     *
     * @param graphElementsIterator Итератор графических элементов.
     * @return Итератор Дерева графических элементов по всем не групповым Элементам заливки.
     */
    public static Iterator<IBrushElement> createThroughBrushElementIterator(Iterator<IGraphElement> graphElementsIterator) {
        return new AbstractGroupGraphElement.ThroughBrushElementsIterator(graphElementsIterator);
    }

/**
     * Создать итератор Дерева графических элементов по всем не групповым Текстам.
     *
     * @param graphElementsIterator Итератор графических элементов.
     * @return Итератор Дерева графических элементов по всем не групповым Текстам.
     */
    public static Iterator<IText> createThroughTextIterator(Iterator<IGraphElement> graphElementsIterator) {
        return new AbstractGroupGraphElement.ThroughTextIterator(graphElementsIterator);
    }

/**
     * Создать групповой графический элемент.
     *
     * @param name Название Графического элемента.
     * @return групповой графический элемент.
     *//*

    public static IGroupGraphElement createGroupGraphElement(String name) {
        return new GroupGraphElement(name);
    }

    */
/**
     * Создать градиентную основу заливки.
     *
     * @return Градиентная основа заливки.
     *//*

    public static IGradientBrushCore createGradientBrushCore() {
        return new GradientBrushCore();
    }

    */
/**
     * Создать ядро пера на основе ЭУЗ.
     *
     * @return Ядро пера на основе ЭУЗ.
     *//*

    public static IEuzPenCore createEuzPenCore() {
        return new EuzPenCore();
    }

    */
/**
     * Создать ядро пера на основе ЭУЗ.
     *
     * @param visual ЭУЗ.
     * @return Ядро пера на основе ЭУЗ.
     *//*

    public static IEuzPenCore createEuzPenCore(PointSignVisual visual) {
        return new EuzPenCore(visual);
    }

    */
/**
     * Создать основу кисти на основе ЭУЗ.
     *
     * @return Основу кисти на основе ЭУЗ.
     *//*

    public static IEuzBrushCore createEuzBrushCore() {
        return new EuzBrushCore();
    }

    */
/**
     * Создать основу кисти на основе ЭУЗ.
     *
     * @param visual ЭУЗ.
     * @return Основу кисти на основе ЭУЗ.
     *//*

    public static IEuzBrushCore createEuzBrushCore(PointSignVisual visual) {
        return new EuzBrushCore(visual);
    }

    */
/**
     * Создать шаблон пера.
     *
     * @param size     Размер.
     * @param scale    Коэффициент масштабирования.
     * @param elements Элементы шаблона.
     * @return Шаблон пера.
     *//*

    public static IPenPattern createPenPattern(double size, double scale, IPenPattern.IElement... elements) {
        return new PatternPenCore.PenPattern(size, scale, elements);
    }

    */
/**
     * Создать элемента шаблона пера.
     *
     * @param filled      Флаг залитости.
     * @param coordinates Координаты в формате [x, y].
     * @return Элемента шаблона пера.
     */
    public static IPenPattern.IElement createPenPatternElement(boolean filled, double... coordinates) {
        return new PatternPenCore.PenPattern.Element(filled, coordinates);
    }

/**
     * Создать элемента шаблона пера.
     *
     * @param filled Флаг залитости.
     * @param points Точки.
     * @return Элемента шаблона пера.
     */
    public static IPenPattern.IElement createPenPatternElement(boolean filled, BasePoint2D... points) {
        return new PatternPenCore.PenPattern.Element(filled, points);
    }

/**
     * Создать элемента шаблона пера.
     *
     * @param filled Флаг залитости.
     * @param points Точки.
     * @return Элемента шаблона пера.
     *//*

    public static IPenPattern.IElement createPenPatternElement(boolean filled, List<BasePoint2D> points) {
        BasePoint2D[] array = new BasePoint2D[points.size()];

        for (int i = 0; i < array.length; i++) {
            array[i] = new BasePoint2D(points.get(i));
        }

        return new PatternPenCore.PenPattern.Element(filled, array);
    }

    */
/**
     * Получить КЕУЗ-2012.
     *
     * @return КЭУЗ-2012.
     *//*

    public static IKeuz createKeuz2012() {
        return new Keuz2012();
    }

    */
/**
     * Создать миллиметровый преобразователь координат.
     *
     * @return Миллиметровый преобразователь координат.
     *//*

    public static ISrs createMmSrs() {
        return MmSrs.INSTANCE;
    }
*/

}