package vg.sign.visual.api;

/**
 * Интерфейс уборщика мусора.
 *
 * @author Giller
 */
public interface IGarbageCleaner {

    /**
     * Очистить старые данные.
     */
    public void cleanOldSignUtils();

}