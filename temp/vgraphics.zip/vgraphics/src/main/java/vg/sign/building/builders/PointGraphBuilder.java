package vg.sign.building.builders;

import vg.draw.vobject.VGGroup;
import vg.draw.vobject.VGObject;
import vg.draw.vobject.VGPoint;
import vg.geometry.GeometryProcessor;
import vg.geometry.GeometryUtils;
import vg.geometry.cp.CPCalculator;
import vg.geometry.cp.CPoint;
import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;
import vg.geometry.primitives.BaseRectangle2D;
import vg.sign.building.Geometry;
import vg.sign.building.api.IGeometry;
import vg.sign.visual.api.*;
import vg.sign.visual.signs.AreaSignVisual;
import vg.sign.visual.signs.PointSignVisual;

import java.util.ArrayList;
import java.util.List;

/**
 * Построитель точечного знака.
 */
public class PointGraphBuilder extends AbstractSignBuilder {

    @Override
    public void prepareBuilding(ISignVisual visual) {
        if (!(visual instanceof PointSignVisual))
            throw GeometryUtils.createIllegalArgumentException("visual", visual, PointSignVisual.class);
        PointSignVisual pointVisual = (PointSignVisual) visual;
        // Predefined points.
        List<PointSignVisual.AbstractPredefinedPoint> allPredefinedPoints = pointVisual.getPredefinedPoints();
        // Calculating the predefinedPoints before using them.
        CPCalculator.calculate(allPredefinedPoints);
    }

    @Override
    public VGGroup buildGraphics(ISignVisual visual) {
        if (!(visual instanceof PointSignVisual))
            throw GeometryUtils.createIllegalArgumentException("visual", visual, PointSignVisual.class);
        PointSignVisual pointVisual = (PointSignVisual) visual;

        VGGroup image = new VGGroup();
        //TODO Подумать над тем правильно ли анализировать видимость знака в этом месте, возвращая при этом пустой VG объект.
        if (!visual.isVisible())
            return image;

        // Predefined points.
        List<PointSignVisual.AbstractPredefinedPoint> allPredefinedPoints = pointVisual.getPredefinedPoints();

        // Матрица перехода из локальной с.к. знака в с.к. документа.
        BaseMatrix2D matrix = pointVisual.getToDocumentMatrix();

        // Заполнение графических элементов контрольными точками и их расчёт.
        List<BasePoint2D> gePredefinedPoints = new ArrayList<BasePoint2D>(allPredefinedPoints.size());
        for (int i = 0, ni = pointVisual.getGraphElements().size(); i < ni; i++) {
            IGraphElement graphElement = pointVisual.getGraphElements().get(i);
            List<Integer> predefinedPointsIndices = pointVisual.getPredefinedPointIndices().get(i);
            gePredefinedPoints.clear();

            for (int j = 0, nj = predefinedPointsIndices.size(); j < nj; j++) {
                CPoint cp = allPredefinedPoints.get(predefinedPointsIndices.get(j));
                gePredefinedPoints.add(new BasePoint2D(cp.getX(), cp.getY()));
            }

            if (graphElement.isVisible()) {
                // Задаём правильный размер шрифта.
                // Меняем его прямо в объекте. Это безопасно, т.к. здесь работаем с копией исходных данных.
                if (graphElement.getText() != null) {
                    graphElement.getText().setFontSize(graphElement.getText().getFontSize() * visual.getScale().getY());
                    graphElement.getText().setAlignment(
                            correctTextAligment(
                                    graphElement.getText().getAlignment(),
                                    visual.getScale()));
                }

                VGObject geImage = buildGraphElement(graphElement, gePredefinedPoints, matrix, visual.getAngle());
                if (geImage != null)
                    image.getChildren().add(geImage);

            } else {
                List<VGPoint> points = this.buildUnVisibleGraphElement(graphElement, gePredefinedPoints, matrix, visual.getAngle());
                for (int j = 0; j < points.size(); ++j)
                    image.getChildren().add(points.get(j));
            }
        } // end of for

        VGObject anchorPointsBuilding = buildAnchorPoints(visual.getAnchorPoints(), visual.getAngle());
        if (anchorPointsBuilding != null)
            image.getChildren().add(anchorPointsBuilding);

        image.setAngle(visual.getAngle());
        image.calculate();

        return image;
    }

    /**
     * Откорректировать выравнивание текста в зависиости от масштабирования.
     * <p> При отрицательных значениях X и Y инвертирует соответствующее выравнивание.
     *
     * @param aligment выравнивание.
     * @param scale    масштабирование.
     * @return откорректированное выравнивание.
     */
    private int correctTextAligment(int aligment, BasePoint2D scale) {
        if (scale.getX() < 0) {
            int ha = 0;
            switch (aligment & 0x03) {
                case IText.HA_LEFT:
                    ha |= IText.HA_RIGHT;
                    break;
                case IText.HA_RIGHT:
                    ha |= IText.HA_LEFT;
                    break;
                default:
                    ha |= IText.HA_CENTER;
                    break;
            }
            aligment = (aligment & 0x0C) | ha;
        }

        if (scale.getY() < 0) {
            int va = 0;
            switch (aligment & 0x0C) {
                case IText.VA_TOP:
                    va |= IText.VA_BOTTOM;
                    break;
                case IText.VA_BOTTOM:
                    va |= IText.VA_TOP;
                    break;
                default:
                    va |= IText.VA_CENTER;
                    break;
            }
            aligment = (aligment & 0x03) | va;
        }

        return aligment;
    }


    /**
     * Построить графический элемент.
     *
     * @param graphElement     Графический элемент.
     * @param predefinedPoints Предопределённые точки.
     * @param matrix           Матрица перехода из локальной с.к. знака в с.к. документа.
     * @param angle            Угол знака.
     * @return Изображение графического элемента.
     */
    public static VGObject buildGraphElement(IGraphElement graphElement, List<BasePoint2D> predefinedPoints, BaseMatrix2D matrix, double angle) {
        if (graphElement instanceof ICircleGraphElement) {

            ICircleGraphElement circleGraphElement = (ICircleGraphElement) graphElement;

            if (predefinedPoints.size() < 2) return null;
            BasePoint2D p1 = predefinedPoints.get(0);
            BasePoint2D p2 = predefinedPoints.get(1);

            List<BasePoint2D> linePoints = GeometryProcessor.createEllipse(
                    new BasePoint2D(p1).add(p2).mul(0.5, 0.5),
                    (p2.getX() - p1.getX()) * 0.5, (p2.getY() - p1.getY()) * 0.5,
                    0.0,
                    circleGraphElement.getBeginAngle(), circleGraphElement.getEndAngle(),
                    circleGraphElement.isSmooth() ? 33 : 9);
            if (circleGraphElement.isClosed())
                linePoints.add(new BasePoint2D(linePoints.get(0)));
            for (BasePoint2D lp : linePoints)
                lp.transform(matrix);
            VGObject shape = buildShape(linePoints, circleGraphElement.getPen(), circleGraphElement.getBrush(), circleGraphElement.getText(), angle);

            return shape;

        } else if (graphElement instanceof ILineGraphElement) {

            ILineGraphElement lineGraphElement = (ILineGraphElement) graphElement;

            List<BasePoint2D> transformedPredefinedPoints = new ArrayList<BasePoint2D>(predefinedPoints.size());
            for (BasePoint2D pp : predefinedPoints)
                transformedPredefinedPoints.add(matrix.transformPoint(pp));

            List<BasePoint2D> linePoints = buildLinePoints(
                    transformedPredefinedPoints,
                    lineGraphElement.isSmooth(),
                    lineGraphElement.isClosed());
            VGObject shape = buildShape(linePoints, lineGraphElement.getPen(), lineGraphElement.getBrush(), lineGraphElement.getText(), angle);

            return shape;

        } else {
            return null;
        }
    }

    /**
     * Построить невидимый графический элемент в виде перечня узловых точек.
     *
     * @param graphElement     Графический элемент.
     * @param predefinedPoints Предопределённые точки.
     * @param matrix           Матрица перехода из локальной с.к. знака в с.к. документа.
     * @param angle            Угол знака.
     * @return невидимый графический элемент в виде перечня узловых точек.
     */
    private List<VGPoint> buildUnVisibleGraphElement(IGraphElement graphElement, List<BasePoint2D> predefinedPoints, BaseMatrix2D matrix, double angle) {

        List<VGPoint> vgPoints = new ArrayList<VGPoint>();

        if (graphElement instanceof ICircleGraphElement) {

            ICircleGraphElement circleGraphElement = (ICircleGraphElement) graphElement;

            if (predefinedPoints.size() < 2) return null;
            BasePoint2D p1 = predefinedPoints.get(0);
            BasePoint2D p2 = predefinedPoints.get(1);

            List<BasePoint2D> linePoints = GeometryProcessor.createEllipse(
                    new BasePoint2D(p1).add(p2).mul(0.5, 0.5),
                    (p2.getX() - p1.getX()) * 0.5, (p2.getY() - p1.getY()) * 0.5,
                    0.0,
                    circleGraphElement.getBeginAngle(), circleGraphElement.getEndAngle(),
                    circleGraphElement.isSmooth() ? 33 : 9);
            for (BasePoint2D lp : linePoints)
                lp.transform(matrix);
//			VGObject shape = buildShape(linePoints, circleGraphElement.getPen(), circleGraphElement.getBrush(), circleGraphElement.getText(), angle);

            for (int i = 0; i < linePoints.size(); ++i)
                vgPoints.add(new VGPoint(linePoints.get(i)));

//			return shape;

        } else if (graphElement instanceof ILineGraphElement) {

            ILineGraphElement lineGraphElement = (ILineGraphElement) graphElement;

            List<BasePoint2D> transformedPredefinedPoints = new ArrayList<BasePoint2D>(predefinedPoints.size());
            for (BasePoint2D pp : predefinedPoints)
                transformedPredefinedPoints.add(matrix.transformPoint(pp));

            List<BasePoint2D> linePoints = buildLinePoints(
                    transformedPredefinedPoints,
                    lineGraphElement.isSmooth(),
                    lineGraphElement.isClosed());
//			VGObject shape = buildShape(linePoints, lineGraphElement.getPen(), lineGraphElement.getBrush(), lineGraphElement.getText(), angle);

            for (int i = 0; i < linePoints.size(); ++i)
                vgPoints.add(new VGPoint(linePoints.get(i)));

//			return shape;

        }

        return vgPoints;
    }

    @Override
    public IGeometry calculateGeometry(ISignVisual visual, BaseRectangle2D bounds) {
        if (!(visual instanceof PointSignVisual))
            throw GeometryUtils.createIllegalArgumentException("visual", visual, AreaSignVisual.class);


        double diagonal = Math.sqrt(bounds.getWidth() * bounds.getWidth() + bounds.getHeight() * bounds.getHeight());
        double length = 0;
        double space = 0;

        return new Geometry(
                bounds.getAngle(),
                bounds.getWidth(),
                bounds.getHeight(),
                length,
                space,
                diagonal / 2.0,
                diagonal);
    }

    @Override
    public void prepareForPreview(ISignVisual visual) {
        IAnchorPointsList anchorPointsList = visual.getAnchorPoints();
        if (anchorPointsList.isEmpty()) {
            // Установка знака в начало координат.
            anchorPointsList.add(new BasePoint2D());
        }
        super.prepareForPreview(visual);
    }

}
