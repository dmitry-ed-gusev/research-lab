package vg.sign.visual.tools;

import vg.draw.Colors;
import vg.sign.visual.api.IBrush;
import vg.sign.visual.api.IPen;
import vg.sign.visual.api.IText;

import java.awt.*;

/**
 * Текст.
 */
public class Text implements IText {

    /**
     * Текст.
     */
    private String text;
    /**
     * Цвет.
     */
    private int color;
    /**
     * Название шрифта.
     */
    private String fontName;
    /**
     * Стиль шрифта.
     */
    private int fontStyle;
    /**
     * Размер шрифта.
     */
    private double fontSize;
    /**
     * Выравнивание.
     */
    private int alignment;
    /**
     * Контур вокруг текста.
     */
    private IPen pen;
    /**
     * Заливка под текстом.
     */
    private IBrush brush;


    /** */
    public Text() {
        this("", 0xFF000000, null, 0, 16, 0, null, null);
    }

    /**
     * @param text Текст.
     */
    public Text(String text) {
        this(text, 0xFF000000, null, 0, 16, 0, null, null);
    }

    /**
     * @param text  Текст.
     * @param color Цвет шрифта.
     */
    public Text(String text, int color) {
        this(text, color, null, 0, 16, 0, null, null);
    }

    /**
     * @param text      Текст.
     * @param color     Цвет шрифта.
     * @param textPen   Контур вокруг текста.
     * @param textBrush Заливка од текстом.
     */
    public Text(String text, int color, IPen textPen, IBrush textBrush) {
        this(text, color, null, 0, 16, 0, textPen, textBrush);
    }

    /**
     * @param text      Текст.
     * @param color     Цвет шрифта.
     * @param fontName  Название шрифта.
     * @param fontStyle Стиль шрифта.
     * @param fontSize  Размер шрифта.
     * @param alignment Выравнивание.
     */
    public Text(String text, int color, String fontName, int fontStyle, double fontSize, int alignment) {
        this(text, color, fontName, fontStyle, fontSize, alignment, null, null);
    }

    /**
     * @param text      Текст.
     * @param color     Цвет шрифта.
     * @param fontName  Название шрифта.
     * @param fontStyle Стиль шрифта.
     * @param fontSize  Размер шрифта.
     * @param alignment Выравнивание.
     * @param textPen   Контур вокруг текста.
     * @param textBrush Заливка од текстом.
     */
    public Text(String text, int color, String fontName, int fontStyle, double fontSize, int alignment, IPen textPen, IBrush textBrush) {
        this.text = text;
        this.color = color;
        this.fontName = fontName != null ? fontName : Font.SANS_SERIF;
        this.fontStyle = fontStyle;
        this.fontSize = fontSize;
        this.alignment = alignment;
        this.pen = textPen;
        this.brush = textBrush;
    }


    @Override
    public Text clone() {
        try {
            Text clonedObject = (Text) super.clone();

            if (pen != null)
                clonedObject.pen = pen.clone();
            if (brush != null)
                clonedObject.brush = brush.clone();
            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }


    @Override
    public String getText() {
        return text;
    }

    @Override
    public void setText(String text) {
        this.text = text;
    }

    @Override
    public String getFontName() {
        return fontName;
    }

    @Override
    public void setFontName(String fontName) {
        this.fontName = fontName;
    }

    @Override
    public int getFontStyle() {
        return fontStyle;
    }

    @Override
    public void setFontStyle(int fontStyle) {
        this.fontStyle = fontStyle;
    }

    @Override
    public double getFontSize() {
        return fontSize;
    }

    @Override
    public void setFontSize(double fontSize) {
        this.fontSize = fontSize;
    }

    @Override
    public int getAlignment() {
        return alignment;
    }

    @Override
    public void setAlignment(int alignment) {
        this.alignment = alignment;
    }

    @Override
    public int getColor() {
        return color;
    }

    @Override
    public void setColor(int color, int mask) {
        this.color = Colors.setColor(this.color, color, mask);
    }

    @Override
    public IPen getPen() {
        return pen;
    }

    @Override
    public void setPen(IPen pen) {
        this.pen = pen;
    }

    @Override
    public IBrush getBrush() {
        return brush;
    }

    @Override
    public void setBrush(IBrush brush) {
        this.brush = brush;
    }

}
