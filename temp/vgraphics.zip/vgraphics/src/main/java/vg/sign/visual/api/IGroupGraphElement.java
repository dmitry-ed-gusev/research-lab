package vg.sign.visual.api;

import java.util.List;


/**
 * Групповой графический элемент.
 *
 */
public interface IGroupGraphElement extends IGraphElement, ICircleGraphElement {

    /**
     * Получить список дочерних элементов.
     *
     * @return Список дочерних элементов.
     */
    List<IGraphElement> getElements();

}
