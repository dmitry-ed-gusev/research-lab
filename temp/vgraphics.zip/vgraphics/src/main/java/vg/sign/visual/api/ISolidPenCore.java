package vg.sign.visual.api;


/**
 * Сердечник сплошного непрерывного пера.
 *
 */
public interface ISolidPenCore extends IPenCore {

    // TODO Разобраться где эти свойства должны быть в Элементе пера или здесь.
//	/**
//	 * Получить тип сочленения сегментов.
//	 * @return Тип сочленения сегментов.
//	 */
//	public int getJoin();
//
//	/**
//	 * Задать тип сочленения сегментов.
//	 * @param join Тип сочленения сегментов.
//	 */
//	public void setJoin(int join);
//
//	/**
//	 * Получить тип окончания линии.
//	 * @return Тип окончания линии.
//	 */
//	public int getCap();
//
//	/**
//	 * Задать тип окончания линии..
//	 * @param cap Тип окончания линии.
//	 */
//	public void setCap(int cap);

}
