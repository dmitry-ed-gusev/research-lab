package vg.sign.building;

import vg.draw.vobject.VGGroup;
import vg.draw.vobject.VGObject;
import vg.sign.building.api.IGroupSignImage;

import java.util.HashMap;
import java.util.Map;

/**
 * Групповое векторное изображение.
 *
 * @author Giller
 */
public class GroupSignImage extends VGGroup implements IGroupSignImage {

    /**
     * Карта дочерних векторных изображений по идетификатору визуального представления.
     */
    private Map<String, VGObject> childMap = new HashMap<String, VGObject>();


    @Override
    public int hashCode() {
        int result = super.hashCode();
        for (Map.Entry<String, VGObject> entry : childMap.entrySet()) {
            result = result * 7 + entry.getKey().hashCode();
            result = result * 7 + entry.getValue().hashCode();
        }
        return result;
    }


    /*
     * Получить карту дочерних векторных изображений по идетификатору визуального представления.
     * @return карта дочерних векторных изображений по идетификатору визуального представления.
     */
    @Override
    public Map<String, VGObject> getChildrenImages() {
        return this.childMap;
    }

}
