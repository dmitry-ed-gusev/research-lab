package vg.sign.core.api;

import vg.geometry.primitives.BasePoint2D;
import vg.sign.building.api.IGroupGraphBuilder;
import vg.sign.visual.api.IGroupSignVisual;

import java.util.List;

/**
 * Интерфейс группового знака.
 *
 * @author Giller
 */
public interface IGroupSign extends ISign {

    @Override
    public IGroupSign clone();

    /**
     * Получить перечень знаков.
     *
     * @return перечень знаков.
     */
    public List<ISign> getChildren();

    // TODO Скорее всего место этому методу в компоненте геометрии.

    /**
     * Получить дочерний знак по точке.
     *
     * @param point точка.
     * @param delta максимальное отклонение.
     * @return дочерний знак, null - если знак по точке определить не удалось.
     */
    public ISign getChild(BasePoint2D point, double delta);

    @Override
    public IGroupGraphBuilder getBuilder();

    @Override
    public IGroupSignVisual getVisual();

}
