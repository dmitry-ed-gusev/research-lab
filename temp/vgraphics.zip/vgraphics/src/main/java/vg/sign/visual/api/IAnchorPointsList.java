package vg.sign.visual.api;

import vg.geometry.primitives.BasePoint2D;

import java.util.List;

/**
 * Список точек привязки.
 *
 */
public interface IAnchorPointsList extends List<IAnchorPoint>, Cloneable {

    /**
     * Клонирование.
     *
     * @return Клон.
     */
    IAnchorPointsList clone();

    /**
     * Получить минимальное количество точек привязки.
     *
     * @return Минимальное количество точек привязки..
     */
    public int getMinSize();

    /**
     * Получить максимальное количество точек привязки.
     *
     * @return Максимальное количество точек привязки.
     */
    public int getMaxSize();

    /**
     * Задать точку привязки без смыслового значения.
     *
     * @param index Индекс точки.
     * @param point Точка.
     * @return Старое значение точки привязки.
     */
    public BasePoint2D set(int index, BasePoint2D point);

    /**
     * Добавить точку привязки без смыслового значения.
     *
     * @param index Индекс точки привязки.
     * @param point Точка.
     */
    public void add(int index, BasePoint2D point);

    /**
     * Добавить точку привязки без смыслового значения в конец списка.
     *
     * @param point Точка.
     */
    public void add(BasePoint2D point);

}
