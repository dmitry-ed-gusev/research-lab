package vg.sign.visual.signs;

import vg.sign.visual.api.IAnchorPoint;
import vg.sign.visual.api.IGraphElement;
import vg.sign.visual.api.IPen;
import vg.sign.visual.tools.AbstractSignVisual;
import vg.sign.visual.tools.AnchorPointsList;
import vg.sign.visual.tools.RootGraphElement;
import vg.sign.visual.tools.pen.Pen;
import vg.sign.visual.tools.pen.PenElement;
import vg.sign.visual.tools.pen.SolidPenCore;
import vg.utils.ListReference;

import java.util.ArrayList;
import java.util.List;

/**
 * Разграничительная линия.
 *
 */
public class DemarkLineSignVisual extends AbstractSignVisual {

    /**
     * Ключ к флагу включения узла.
     */
    public final static String INCLUSION_KEY = "inclusion";


    /**
     * Графический элемент узла линии.
     *
     */
    private class NodeGraphElement extends AbstractGraphElement {

        /**
         * @param name Наименование.
         */
        public NodeGraphElement(String name) {
            super(name);
        }


        @Override
        public NodeGraphElement clone() {
            NodeGraphElement clone = (NodeGraphElement) super.clone();
            return clone;
        }

        @Override
        public boolean isEditable() {
            return true;
        }

        @Override
        public IPen getPen() {
            return DemarkLineSignVisual.this.nodesPen;
        }

        @Override
        public void setPen(IPen pen) {
            DemarkLineSignVisual.this.nodesPen = pen;
        }

    }

    /**
     * Графический элемент сегмента линии.
     *
     */
    private class SegmentGraphElement extends AbstractGraphElement {

        /**
         * @param name Наименование.
         */
        public SegmentGraphElement(String name) {
            super(name);
        }


        @Override
        public SegmentGraphElement clone() {
            SegmentGraphElement clone = (SegmentGraphElement) super.clone();
            return clone;
        }

        @Override
        public boolean isEditable() {
            return true;
        }

        @Override
        public IPen getPen() {
            return DemarkLineSignVisual.this.segmentsPen;
        }

        @Override
        public void setPen(IPen pen) {
            DemarkLineSignVisual.this.segmentsPen = pen;
        }

    }

    /**
     * Перо для отрисовки сегментов линии.
     */
    private IPen segmentsPen;
    /**
     * Перо для отрисовки узлов.
     */
    private IPen nodesPen;
    /**
     * Радиус узлов.
     */
    private double nodesRadius;

    /***/
    public DemarkLineSignVisual() {
        nodesRadius = 5;
        segmentsPen = new Pen(new PenElement(new SolidPenCore(), 0xFFFF0000, 1.0));
        nodesPen = new Pen(new PenElement(new SolidPenCore(), 0xFFFF0000, 1.0));
        List<IGraphElement> elements = new ArrayList<IGraphElement>();
        elements.add(new SegmentGraphElement("Сегменты линии"));
        elements.add(new NodeGraphElement("Узлы"));
        rootGraphElement = new RootGraphElement("Разграничительная линия", this, new ListReference<IGraphElement>(elements, false));
        anchorPoints = new AnchorPointsList(2, Integer.MAX_VALUE);
    }

    /**
     * Получить перо для отрисовки сегментов.
     *
     * @return Перо для отрисовки сегментов.
     */
    public IPen getSegmentsPen() {
        return segmentsPen;
    }

    /**
     * Задать перо для отрисовки сегментов.
     *
     * @param segmentsPen Перо для отрисовки сегментов.
     */
    public void setSegmentsPen(IPen segmentsPen) {
        this.segmentsPen = segmentsPen;
    }

    /**
     * Получить перо для отрисовки узлов.
     *
     * @return Перо для отрисовки узлов.
     */
    public IPen getNodesPen() {
        return nodesPen;
    }

    /**
     * Задать перо для отрисовки узлов.
     *
     * @param nodesPen Перо для отрисвоки узлов.
     */
    public void setNodesPen(IPen nodesPen) {
        this.nodesPen = nodesPen;
    }

    /**
     * Получить радиус узлов.
     *
     * @return Радиус узлов.
     */
    public double getNodesRadius() {
        return nodesRadius;
    }

    /**
     * Задать радиус узлов.
     *
     * @param nodesRadius Радиус узлов.
     */
    public void setNodesRadius(double nodesRadius) {
        this.nodesRadius = nodesRadius;
    }

    @Override
    public void createDefaultSemantics(int index, IAnchorPoint anchorPoint) {
        anchorPoint.getSemantic().put(INCLUSION_KEY, true);
    }

    @Override
    public DemarkLineSignVisual clone() {
        DemarkLineSignVisual clone = (DemarkLineSignVisual) super.clone();
        if (nodesPen != null)
            clone.nodesPen = nodesPen.clone();
        if (segmentsPen != null)
            clone.segmentsPen = segmentsPen.clone();
        clone.nodesRadius = nodesRadius;
        List<IGraphElement> elements = new ArrayList<IGraphElement>();
        elements.add(clone.new SegmentGraphElement("Сегменты линии"));
        elements.add(clone.new NodeGraphElement("Узлы"));
        clone.rootGraphElement = new RootGraphElement("Разграничительная линия", clone, new ListReference<IGraphElement>(elements, false));
        return clone;
    }

}