package vg.sign.visual.signs;

import vg.geometry.GeometryDefaults;
import vg.sign.visual.api.*;
import vg.sign.visual.tools.AbstractSignVisual;
import vg.sign.visual.tools.AnchorPointsList;
import vg.sign.visual.tools.RootGraphElement;
import vg.sign.visual.tools.Text;
import vg.sign.visual.tools.brush.Brush;
import vg.sign.visual.tools.pen.Pen;
import vg.sign.visual.tools.pen.PenElement;
import vg.sign.visual.tools.pen.SolidPenCore;

import java.awt.*;
import java.util.AbstractList;
import java.util.UUID;

/**
 * Текстовый формуляр.
 *
 */
public class FormularSignVisual extends AbstractSignVisual {

    /**
     * Внутренний список графических элементов.
     *
     */
    private class SelfGraphElementsList extends AbstractList<IGraphElement> {

        /**
         * Элементы.
         */
        private IGraphElement[] elements = new IGraphElement[5];


        /***/
        public SelfGraphElementsList() {
            elements[0] = new SelfTextGraphElement("Верхний текст", GeometryDefaults.ElementAlignment.TOP);
            elements[1] = new SelfTextGraphElement("Нижний текст", GeometryDefaults.ElementAlignment.BOTTOM);
            elements[2] = new SelfTextGraphElement("Левый текст", GeometryDefaults.ElementAlignment.LEFT);
            elements[3] = new SelfTextGraphElement("Правый текст", GeometryDefaults.ElementAlignment.RIGHT);
            elements[4] = new SelfLineGraphElement("Линия");
        }


        @Override
        public IGraphElement get(int index) {
            return elements[index];
        }

        @Override
        public int size() {
            return elements.length;
        }

    }


    /**
     * Текстовый графический элемент.
     *
     */
    private class SelfTextGraphElement extends AbstractGraphElement {

        /**
         * Расположение в знаке.
         */
        private GeometryDefaults.ElementAlignment location;


        /**
         * @param name     Наименование.
         * @param location Расположение.
         */
        public SelfTextGraphElement(String name, GeometryDefaults.ElementAlignment location) {
            this.name = name;
            this.location = location;
            switch (location) {
                case BOTTOM:
                    this.id = "bottom";
                    break;
                case LEFT:
                    this.id = "left";
                    break;
                case RIGHT:
                    this.id = "right";
                    break;
                case TOP:
                    this.id = "top";
                    break;
            }
        }


        @Override
        public SelfTextGraphElement clone() {
            SelfTextGraphElement clone = (SelfTextGraphElement) super.clone();
            return clone;
        }

        @Override
        public boolean isVisible() {
            return FormularSignVisual.this.visible;
        }

        @Override
        public void setVisible(boolean visible) {
            FormularSignVisual.this.visible = visible;
        }

        @Override
        public IText getText() {
            switch (location) {
                case TOP:
                    return FormularSignVisual.this.top;
                case BOTTOM:
                    return FormularSignVisual.this.bottom;
                case LEFT:
                    return FormularSignVisual.this.left;
                case RIGHT:
                    return FormularSignVisual.this.right;
                default:
                    return null;
            }
        }

        @Override
        public void setText(IText text) {
            switch (location) {
                case TOP:
                    FormularSignVisual.this.top = text;
                    break;
                case BOTTOM:
                    FormularSignVisual.this.bottom = text;
                    break;
                case LEFT:
                    FormularSignVisual.this.left = text;
                    break;
                case RIGHT:
                    FormularSignVisual.this.right = text;
                    break;
                default:
            }
        }

    }


    /**
     * Графический элемент для доступа к перу.
     *
     */
    private class SelfLineGraphElement extends AbstractGraphElement {

        /**
         * @param name Наименование.
         */
        public SelfLineGraphElement(String name) {
            this.name = name;
            this.id = UUID.randomUUID().toString();
        }


        @Override
        public SelfLineGraphElement clone() {
            SelfLineGraphElement clone = (SelfLineGraphElement) super.clone();
            return clone;
        }

        @Override
        public IPen getPen() {
            return FormularSignVisual.this.linesPen;
        }

        @Override
        public void setPen(IPen pen) {
            FormularSignVisual.this.linesPen = pen;
        }

    }


    /**
     * Верхний текст.
     */
    private IText top;
    /**
     * Нижний текст.
     */
    private IText bottom;
    /**
     * Левый текст.
     */
    private IText left;
    /**
     * Правый текст.
     */
    private IText right;
    /**
     * Перо, отрисовывающее линии знака.
     */
    private IPen linesPen;
    /**
     * Флаг наличия описывающей окружности.
     */
    private boolean inCircle;


    /***/
    public FormularSignVisual() {
        top = new Text("", 0xFFFFFFFF, Font.DIALOG, Font.PLAIN, 4, IText.HA_CENTER | IText.VA_CENTER, new Pen(), new Brush());
        bottom = new Text("", 0xFFFFFFFF, Font.DIALOG, Font.PLAIN, 4, IText.HA_CENTER | IText.VA_CENTER, new Pen(), new Brush());
        left = new Text("", 0xFFFFFFFF, Font.DIALOG, Font.PLAIN, 4, IText.HA_CENTER | IText.VA_CENTER, new Pen(), new Brush());
        right = new Text("", 0xFFFFFFFF, Font.DIALOG, Font.PLAIN, 4, IText.HA_CENTER | IText.VA_CENTER, new Pen(), new Brush());
        linesPen = new Pen(new PenElement(new SolidPenCore(), 0xFF000000, 0.16));
        inCircle = false;
        anchorPoints = new AnchorPointsList(1, 1);
        rootGraphElement = new RootGraphElement("Формуляр", this, new SelfGraphElementsList());
    }


    @Override
    public FormularSignVisual clone() {
        FormularSignVisual clone = (FormularSignVisual) super.clone();
        if (top != null) {
            clone.top = top.clone();
        }
        if (bottom != null) {
            clone.bottom = bottom.clone();
        }
        if (left != null) {
            clone.left = left.clone();
        }
        if (right != null) {
            clone.right = right.clone();
        }
        clone.anchorPoints = new AnchorPointsList(1, 1);
        if (!anchorPoints.isEmpty()) {
            clone.anchorPoints.add(anchorPoints.get(0).clone());
        }

        clone.rootGraphElement = new RootGraphElement("Формуляр", clone, clone.new SelfGraphElementsList());
        if (linesPen != null)
            clone.linesPen = linesPen.clone();

        return clone;
    }

    @Override
    public IRootGraphElement getRootGraphElement() {
        return rootGraphElement;
    }

    /**
     * Получить верхний текст.
     *
     * @return Верхний текст.
     */
    public IText getTopText() {
        return top;
    }

    /**
     * Задать верхний текст.
     *
     * @param text Текст.
     */
    public void setTopText(IText text) {
        top = text;
    }

    /**
     * Получить нижний текст.
     *
     * @return Нижний текст.
     */
    public IText getBottomText() {
        return bottom;
    }

    /**
     * Задать нижний текст.
     *
     * @param text Текст.
     */
    public void setBottomText(IText text) {
        bottom = text;
    }

    /**
     * Получить левый текст.
     *
     * @return Левый текст.
     */
    public IText getLeftText() {
        return left;
    }

    /**
     * Задать левый текст.
     *
     * @param text Левый текст.
     */
    public void setLeftText(IText text) {
        left = text;
    }

    /**
     * Получить правый текст.
     *
     * @return Правый текст.
     */
    public IText getRightText() {
        return right;
    }

    /**
     * Задат правый текст
     *
     * @param text Правый текст.
     */
    public void setRightText(IText text) {
        right = text;
    }

    /**
     * Получить флаг наличия окружности.
     *
     * @return Флаг наличия окружности.
     */
    public boolean isInCircle() {
        return inCircle;
    }

    /**
     * Задать флаг наличия окружности.
     *
     * @param inCircle Флаг наличия окружности.
     */
    public void setInCircle(boolean inCircle) {
        this.inCircle = inCircle;
    }

    /**
     * Получить перо, отрисовывающее линии знака.
     *
     * @return Перо, отрисовывающее линии знака.
     */
    public IPen getLinesPen() {
        return linesPen;
    }

    /**
     * Задать перо, отрисовывающее линии знака.
     *
     * @param pen Перо, отрисовывающее линии знака.
     */
    public void setLinesPen(IPen pen) {
        this.linesPen = pen;
    }

    @Override
    public void createDefaultSemantics(int index, IAnchorPoint anchorPoint) {
    }

}
