package vg.sign.generalization.api;

import vg.sign.building.api.IPreBuildModifier;
import vg.sign.edit.api.ISignEditor;

/**
 * Модификатор ЭУЗ по правилам генерализации.
 *
 * @author Giller
 */
public interface IGeneralizationModifier extends IPreBuildModifier {

    /**
     * Получить рабочее масштабирование.
     *
     * @return рабочее масштабирование.
     */
    public double getWorkScale();

    /**
     * Установить рабочее масштабирование.
     *
     * @param workScale рабочее масштабировние.
     */
    public void setWorkScale(double workScale);

    /**
     * Получить генерализацию.
     *
     * @return генерализация.
     */
    public IGeneralization getGeneralization();

    /**
     * Установить генерализацию.
     *
     * @param generalization генерализация.
     */
    public void setGeneralization(IGeneralization generalization);

    /**
     * Получить правила редактирования знака.
     *
     * @return правила редактирования знака.
     */
    public ISignEditor getSignEditor();

    /**
     * Установить правила редактирования знака.
     *
     * @param signEditor правила редактирования знака.
     */
    public void setSignEditor(ISignEditor signEditor);
}
