package vg.sign.edit.api;

/**
 * Интерфейс Контрольной точки, управляющей Точкой привязки.
 */
public interface IAnchorControlPoint extends IControlPoint {

    /**
     * Получить индекс управляемой Точки привязки.
     *
     * @return Индекс управляемой Точки привязки.
     */
    public int getAnchorPointIndex();

}
