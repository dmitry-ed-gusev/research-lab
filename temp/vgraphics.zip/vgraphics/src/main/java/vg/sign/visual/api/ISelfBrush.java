package vg.sign.visual.api;


import java.util.Iterator;


/**
 * Интерфейс - маркер для заливки группового графического элемента.
 *
 * @author Giller
 */
public interface ISelfBrush extends IBrush {

    /**
     * Получить сквозной итератор по элементам заливки.
     *
     * @return сквозной итератор по элементам заливки.
     */
    public Iterator<IBrushElement> getThroughIterator();

}
