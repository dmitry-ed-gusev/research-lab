package vg.sign.edit.editors;

import vg.geometry.cp.CPCalculator;
import vg.geometry.cp.CPoint;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.edit.SignEditFactory;
import vg.sign.edit.api.IGroupSignEditor;
import vg.sign.edit.api.ISignEditor;
import vg.sign.visual.api.IAnchorPoint;
import vg.sign.visual.api.IGroupSignVisual;
import vg.sign.visual.api.ISignVisual;

/**
 * Редактор группового знака.
 *
 * @author Giller
 */
public class GroupSignEditor extends AbstractSignEditor implements IGroupSignEditor {

    /**
     * Контрольная точка для управления точкой привязки группового знака.
     *
     * @author Giller
     */
    protected class GroupAnchorControlPoint extends AnchorControlPoint {

        /**
         * Автоматически сгенерированный идентификатор.
         */
        private static final long serialVersionUID = 5215405883974216667L;

        /**
         * Конструктор с входными параметрами.
         *
         * @param visual визуальное представление знака.
         * @param index  индекс.
         */
        public GroupAnchorControlPoint(ISignVisual visual, int index) {
            super(visual, index);
        }

        @Override
        public CPoint calculate() {
            return super.calculate();
        }

        @Override
        public CPoint decalculate() {
            BasePoint2D p2d = (BasePoint2D) visual.getAnchorPoints().get(0).getPoint();
            ISignEditor pse = SignEditFactory.createEditor(visual);
            pse.translate(p2d.sub(point).mul(-1, -1));
            return super.decalculate();
        }
    }


    /**
     * Конструктор с входными параметрами.
     *
     * @param signVisual визуальное представление группового знака.
     */
    public GroupSignEditor(IGroupSignVisual signVisual) {
        super(signVisual);
    }

    @Override
    public IGroupSignVisual getSignVisual() {
        return (IGroupSignVisual) super.getSignVisual();
    }

    @Override
    public synchronized void calculate() {
        controlPoints.clear();

        for (IGroupSignVisual.IChild child : this.getSignVisual().getChildren()) {
            if (child.getVisual() == null) continue;
            ISignEditor pse = SignEditFactory.createEditor(child.getVisual());
            pse.calculate();
            controlPoints.addAll(pse.getControlPoints());

            for (int i = 0; i < child.getVisual().getAnchorPoints().size(); ++i)
                if (child.getVisual() instanceof IGroupSignVisual)
                    controlPoints.add(new GroupAnchorControlPoint(child.getVisual(), i));
                else
                    controlPoints.add(new AnchorControlPoint(child.getVisual(), i));
        }

        for (int i = 0, n = signVisual.getAnchorPoints().size(); i < n; i++)
            controlPoints.add(new GroupAnchorControlPoint(signVisual, i));

        CPCalculator.calculate(controlPoints);
    }

    @Override
    public void translate(BasePoint2D translation) {
        super.translate(translation);

        for (IGroupSignVisual.IChild sv : getSignVisual().getChildren()) {
            if (sv.getVisual() == null) continue;
            ISignEditor editor = SignEditFactory.createEditor(sv.getVisual());
            editor.translate(translation);
        }
    }

    @Override
    public void rotate(double angle, BasePoint2D center) {
        // Сохранение старой координаты точки привязки.
        BasePoint2D oldAnchorPoint = new BasePoint2D(getSignVisual().getAnchorPoints().get(0).getPoint());
        super.rotate(angle, center);

        // Если знак поворачиваемый, то все знаки по честному поворачиваются.
        if (getSignVisual().isRotatable()) {
            for (IGroupSignVisual.IChild sv : getSignVisual().getChildren()) {
                if (sv.getVisual() == null) continue;
                ISignEditor editor = SignEditFactory.createEditor(sv.getVisual());
                editor.rotate(angle, center);
            }

            // Если знак неповорачиваемый, то все знаки смещаются на разницу точки привзяки.
        } else {
            BasePoint2D newAnchorPoint = new BasePoint2D(getSignVisual().getAnchorPoints().get(0).getPoint());
            BasePoint2D diff = newAnchorPoint.sub(oldAnchorPoint);
            this.moveChildren(diff);
        }

    }

    @Override
    public void scale(BasePoint2D center, BasePoint2D scale, double angle) {
        // Сохранение старой координаты точки привязки.
        BasePoint2D oldAnchorPoint = new BasePoint2D(getSignVisual().getAnchorPoints().get(0).getPoint());
        super.scale(center, scale, angle);

        // Если знак масштабируемый, то все его дочерние знаки по честному масштабируются.
        if (getSignVisual().isScalable()) {
            for (IGroupSignVisual.IChild sv : getSignVisual().getChildren()) {
                if (sv.getVisual() == null) continue;
                ISignEditor editor = SignEditFactory.createEditor(sv.getVisual());
                editor.scale(center, scale, angle);
            }

            // Если знак не масштабируется, то все его дочерние элементы смещаются на разницу точки привязки.
        } else {
            BasePoint2D newAnchorPoint = new BasePoint2D(getSignVisual().getAnchorPoints().get(0).getPoint());
            BasePoint2D diff = newAnchorPoint.sub(oldAnchorPoint);
            this.moveChildren(diff);
        }
    }

    /**
     * Переместить всех потомков знака.
     *
     * @param diff величина перемещения.
     */
    private void moveChildren(BasePoint2D diff) {
        for (IGroupSignVisual.IChild sv : getSignVisual().getChildren()) {
            if (sv.getVisual() == null) continue;
            for (IAnchorPoint ap : sv.getVisual().getAnchorPoints())
                ap.setPoint(new BasePoint2D(ap.getPoint()).add(diff));
        }
    }

}
