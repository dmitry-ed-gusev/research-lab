package vg.sign.visual.api;


import vg.utils.Filter;

import java.util.List;

/**
 * Визуальное представление группового знака.
 *
 * @author Giller
 */
public interface IGroupSignVisual extends ISignVisual {

    /**
     * Интерфейс дочернего элемента.
     *
     * @author Giller
     */
    public interface IChild extends Cloneable {

        /**
         * Получить идентификатор визуального представления.
         *
         * @return идентификатор визуального представления.
         */
        public String getSignVisualId();

        /**
         * Установить идентификатор визуального представления.
         *
         * @param id идентификатор визуального представления.
         */
        public void setSignVisualId(String id);

        /**
         * Получить визуальное предствление.
         *
         * @return визуальное представление.
         */
        public ISignVisual getVisual();

        /**
         * Установить визуальное представление.
         *
         * @param visual визуальное представление.
         */
        public void setSignVisual(ISignVisual visual);

        /**
         * Клонирование.
         *
         * @return клон.
         */
        public IChild clone();

    }


    /**
     * Интерфейс переченя знаков.
     *
     * @author Giller
     */
    public interface IChildrenList extends List<IChild> {
        /**
         * Получить минимальный размер списка.
         *
         * @return минимальный размер списка.
         */
        public int getMinSize();

        /**
         * Получить максимальный размер списка.
         *
         * @return максимальный размер списка.
         */
        public int getMaxSize();

        /**
         * Получить фильтр.
         *
         * @return фильтр.
         */
        public Filter<IChild> getFilter();
    }

    /**
     * Получить перечень знаков.
     *
     * @return перечень знаков.
     */
    public List<IChild> getChildren();

    @Override
    public IGroupSignVisual clone();

    /**
     * Является ли временной группой.
     *
     * @return Если true, то групповой знак является временной группой и false, в обратном случае.
     */
    public boolean isTemporary();

    /**
     * Задать значения флага для определения временной группы.
     *
     * @param temporary Если true, то групповой знак является временной группой и false, в обратном случае.
     */
    public void setTemporary(boolean temporary);

}
