package vg.sign.edit.api;

/**
 * 14.06.2015 Интерфейс создан для единообразия иерархии visual/editor/builder.
 * @author Gusev D.
*/
public interface IGroupSignEditor extends ISignEditor {

}
