package vg.sign.visual.api;

import vg.sign.visual.signs.PointSignVisual;

/**
 * Сердечник пера с шаблоном в виде ЭУЗ.
 *
 */
public interface IEuzPenCore extends IPenCore {

    /**
     * Получить ЭУЗ шаблона.
     *
     * @return ЭУЗ шаблона.
     */
    public PointSignVisual getEuz();

    /**
     * Задать ЭУЗ шаблона.
     *
     * @param euz ЭУЗ шаблона.
     */
    public void setEuz(PointSignVisual euz);

}
