package vg.sign.visual.api;


/**
 * Корневой Графический элемент Визуалного представления ЭУЗ.
 *
 */
public interface IRootGraphElement extends IGroupGraphElement {

    /**
     * Получить Визуальное представление ЭУЗ.
     *
     * @return Визуальное представление ЭУЗ.
     */
    public ISignVisual getParentSignVisual();

}
