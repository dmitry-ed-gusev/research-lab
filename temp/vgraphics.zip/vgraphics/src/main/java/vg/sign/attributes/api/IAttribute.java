package vg.sign.attributes.api;

import java.util.List;

public interface IAttribute extends Cloneable {

    /**
     * Клонировать атрибут.
     *
     * @return Клон.
     */
    public IAttribute clone();

    @Override
    public String toString();

    /**
     * Получить имя атрибута.
     *
     * @return Имя атрибута.
     */
    public String getName();

    /**
     * Задать имя атрибута.
     *
     * @param name Имя атрибута.
     */
    public void setName(String name);

    /**
     * Получить ID ассоциированного с этим атрибутом графического элемента.
     *
     * @return ID ассоциированного с этим атрибутом графического элемента.
     */
    public String getGraphElementID();

    /**
     * Задать ID ассоциированного с этим атрибутом графического элемента.
     *
     * @param ID ассоциированного с этим атрибутом графического элемента.
     */
    public void setGraphElementID(String ID);

    /**
     * Получить тип атрибута.
     *
     * @return Тип атрибута.
     */
    public IAttributeType getType();

    /**
     * Задать тип атрибута.
     *
     * @param type Тип атрибута.
     */
    public void setType(IAttributeType type);

    /**
     * Получить значение атрибута.
     *
     * @return Значение атрибута.
     */
    public IAttributeValue getValue();

    /**
     * Задать значение атрибута.
     *
     * @param value Значение атрибута.
     */
    public void setValue(IAttributeValue value);

    /**
     * Получить список дочерних атрибутов.
     *
     * @return Дочерние атрибуты.
     */
    public List<IAttribute> getChildren();

}
