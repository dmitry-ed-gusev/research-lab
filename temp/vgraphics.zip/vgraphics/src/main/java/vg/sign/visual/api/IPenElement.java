package vg.sign.visual.api;

import vg.geometry.GeometryDefaults;

/**
 * Элемент пера.
 *
 */
public interface IPenElement extends Cloneable {

    /**
     * Клонирование.
     *
     * @return Клон.
     */
    IPenElement clone();

    /**
     * Инициализация элемента пера на основе заданного.
     *
     * @param penElement элемент пера для инициализации.
     */
    public void init(IPenElement penElement);

    /**
     * Получить цвет.
     *
     * @return Цвет.
     */
    public int getColor();

    /**
     * Задать цвет.
     *
     * @param color Цвет.
     * @param mask  Маска назначения цвета.
     *              <p>Будут заданы только те биты цвета, которые соответствуют единичным битам маски.
     *              <p>См. {@link IColor#CM_A}, {@link IColor#CM_R}, {@link IColor#CM_G}, {@link IColor#CM_B},
     *              {@link IColor#CM_RGB}, {@link IColor#CM_ARGB}.
     */
    public void setColor(int color, int mask);

    /**
     * Получить толщину линии.
     *
     * @return Толщина.
     */
    public double getWidth();

    /**
     * Задать толщину линии.
     *
     * @param width Толщина.
     */
    public void setWidth(double width);

    /**
     * Получить тип окончаний линии.
     *
     * @return Тип окончаний линии.
     */
    public GeometryDefaults.LineCapType getCap();

    /**
     * Задать тип окончаний линии.
     *
     * @param cap Тип окончаний линии.
     */
    public void setCap(GeometryDefaults.LineCapType cap);

    /**
     * Получить тип сочленения отрезков полилинии.
     *
     * @return Тип сочленения отрезков полилинии.
     */
    public GeometryDefaults.LinesJoinType getJoin();

    /**
     * Задать тип сочленения отрезков полилинии.
     *
     * @param join Тип сочленения отрезков полилинии.
     */
    public void setJoin(GeometryDefaults.LinesJoinType join);

    /**
     * Получить ограничение длины угла при угловом сочленении.
     *
     * @return Ограничение длины угла при угловом сочленении.
     */
    public double getMiterLimit();

    /**
     * Задать ограничение длины угла при угловом сочленении.
     *
     * @param miterLimit Ограничение длины угла при угловом сочленении.
     */
    public void setMiterLimit(double miterLimit);

    /**
     * Получить начальную стрелку.
     *
     * @return Начальная стрелка.
     */
    public GeometryDefaults.LineArrowType getBeginArrow();

    /**
     * Задать начальную стрелку.
     *
     * @param arrow Начальная стрелка.
     */
    public void setBeginArrow(GeometryDefaults.LineArrowType arrow);

    /**
     * Получить конечную стрелку.
     *
     * @return Конечная стрелка.
     */
    public GeometryDefaults.LineArrowType getEndArrow();

    /**
     * Задать конечную стрелку.
     *
     * @param arrow Конечная стрелка.
     */
    public void setEndArrow(GeometryDefaults.LineArrowType arrow);

    /**
     * Получить смещение.
     *
     * @return Смещение.
     */
    public double getShift();

    /**
     * Задать смещение.
     *
     * @param shift Смещение.
     */
    public void setShift(double shift);

    /**
     * Получить полосу.
     *
     * @return Полоса.
     */
    public double getStrip();

    /**
     * Задать полосу.
     *
     * @param strip Полоса.
     */
    public void setStrip(double strip);

    /**
     * Получить сердечник пера.
     *
     * @return Сердечник пера.
     */
    public IPenCore getCore();

    /**
     * Задать сердечник пера.
     *
     * @param core Сердечник пера.
     */
    public void setCore(IPenCore core);

}
