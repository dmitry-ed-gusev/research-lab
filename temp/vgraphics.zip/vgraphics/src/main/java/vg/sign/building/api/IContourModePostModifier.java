package vg.sign.building.api;


/**
 * Модификатор контурного режима отображения.
 */
public interface IContourModePostModifier extends IPostBuildModifier {}
