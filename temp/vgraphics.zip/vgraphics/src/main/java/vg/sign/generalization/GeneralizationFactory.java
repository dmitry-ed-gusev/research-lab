package vg.sign.generalization;

import vg.sign.generalization.api.IGeneralization;
import vg.sign.generalization.api.IGeneralizationModifier;

/**
 * Фабрика для работы с компонентой генерализации.
 *
 * @author Giller
 */
public final class GeneralizationFactory {

    private GeneralizationFactory() {
        // non-instanceability
    }

 /*   *//**
     * Создать генерализацию.
     *
     * @return генерализация.
     *//*
    public static IGeneralization createGeneralization() {
        return new Generalization();
    }

    *//**
     * Создать группу генерализций.
     *
     * @return группа генерализаций.
     *//*
    public static IGeneralizationsList createGeneralizationList() {
        return new GeneralizationsList();
    }

    *//**
     * Создать дочерний элемент генерализации.
     *
     * @param generalization дочерняя генерализация.
     * @return дочерний элемент генерализации.
     *//*
    public static IGeneralizationsList.IChild createChild(IGeneralizationsList generalization) {
        return new GeneralizationsList.Child(generalization);
    }

    *//**
     * Создать параметр генерализации.
     *
     * @return параметр генерализации.
     *//*
    public static IGeneralization.IParameter createGeneralizationParameter() {
        return new Generalization.Parameter();
    }

    *//**
     * Создать параметр.
     *
     * @param scale         масштаб.
     * @param coefficient   коэффициент.
     * @param visibility    видимость.
     * @param interpolation интерполяционность.
     * @return параметр.
     *//*
    public static IGeneralization.IParameter createGeneralizationParameter(int scale, double coefficient, boolean visibility, boolean interpolation) {
        return new Generalization.Parameter(scale, coefficient, visibility, interpolation);
    }

 */   /**
     * Создать модификатор генерализации.
     *
     * @return модификатор генерализации.
     */
    public static IGeneralizationModifier createGeneralizationModifier() {
        return new GeneralizationModifier();
    }

}