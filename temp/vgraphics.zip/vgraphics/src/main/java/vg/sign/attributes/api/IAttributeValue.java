package vg.sign.attributes.api;


/**
 * Значение атрибута.
 */
public interface IAttributeValue extends Cloneable {

    /**
     * Клонировать объект.
     *
     * @return Клон.
     */
    public IAttributeValue clone();

    /**
     * Конвертировать тип атрибута в значение.
     *
     * @param type Тип атрибута.
     * @return Значение атрибута.
     */
    public IAttributeValue convert(IAttributeType type);

}
