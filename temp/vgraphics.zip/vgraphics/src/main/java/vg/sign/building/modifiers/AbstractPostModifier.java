package vg.sign.building.modifiers;

import vg.sign.building.api.IPostBuildModifier;

/**
 * Абстрактный постмодификатор.
 */
public abstract class AbstractPostModifier implements IPostBuildModifier {

    /**
     * Флаг включённости модификатора.
     */
    private boolean enabled = true;


    /***/
    public AbstractPostModifier() {
    }


    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

}
