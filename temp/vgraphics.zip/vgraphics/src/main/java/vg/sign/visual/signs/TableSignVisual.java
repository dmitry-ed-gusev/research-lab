package vg.sign.visual.signs;

import vg.geometry.primitives.BasePoint2D;
import vg.sign.visual.api.*;
import vg.sign.visual.table.ICellContent;
import vg.sign.visual.table.ITextCellContent;
import vg.sign.visual.tools.*;
import vg.sign.visual.tools.brush.Brush;
import vg.sign.visual.tools.brush.BrushElement;
import vg.sign.visual.tools.brush.SolidBrushCore;
import vg.sign.visual.tools.pen.Pen;
import vg.sign.visual.tools.pen.PenElement;
import vg.sign.visual.tools.pen.SolidPenCore;
import vg.utils.ListReference;

import java.util.*;

/**
 * Таблица.
 *
 * @author Giller
 */

// TODO: classes Row/Column were private...

public class TableSignVisual extends AbstractSignVisual {

    /**
     * Ячейка таблицы.
     *
     * @author Giller
     */
    public class Cell implements Cloneable {

        /**
         * Перо левой границы.
         */
        private IPen leftPen;
        /**
         * Перо правой границы.
         */
        private IPen rightPen;
        /**
         * Перо верхней границы.
         */
        private IPen topPen;
        /**
         * Перо нижней границы.
         */
        private IPen bottomPen;
        /**
         * Заливка.
         */
        private IBrush brush;
        /**
         * Количество перекрываемых ячеек по горизонтали.
         */
        private int colSpan = 1;
        /**
         * Количество перекрываемых ячеек по вертикали.
         */
        private int rowSpan = 1;
        /**
         * Содержимое ячейки.
         */
        private ICellContent content;


        /**
         * Конструктор по умолчанию.
         */
        public Cell() {
            leftPen = new Pen(new PenElement(new SolidPenCore(), 0xFF000000, 0.5));
            rightPen = new Pen(new PenElement(new SolidPenCore(), 0xFF000000, 0.5));
            topPen = new Pen(new PenElement(new SolidPenCore(), 0xFF000000, 0.5));
            bottomPen = new Pen(new PenElement(new SolidPenCore(), 0xFF000000, 0.5));

            brush = new Brush(new BrushElement(new SolidBrushCore(), 0x20FFFF00));
        }

        /**
         * Конструктор с входным параметром.
         *
         * @param cell ячейка.
         */
        public Cell(Cell cell) {
            leftPen = new Pen();
            rightPen = new Pen();
            topPen = new Pen();
            bottomPen = new Pen();
            this.init(cell);
        }

        /**
         * Проинициализировать ячейку на основе данной.
         * <p> Производится клонирование всех данных ячейки (перья, заливка, контент, объединение ячеек).
         *
         * @param cell ячейка на основе которой будет производиться инициализация.
         * @return ячейка.
         */
        public Cell init(Cell cell) {
            if (cell.getLeftPen() != null)
                this.initPen(this.leftPen, cell.getLeftPen());
            else
                this.leftPen.getElements().clear();

            if (cell.getRightPen() != null)
                this.initPen(this.rightPen, cell.getRightPen());
            else
                this.rightPen.getElements().clear();

            if (cell.getTopPen() != null)
                this.initPen(this.topPen, cell.getTopPen());
            else
                this.topPen.getElements().clear();

            if (cell.getBottomPen() != null)
                this.initPen(this.bottomPen, cell.getBottomPen());
            else
                this.bottomPen.getElements().clear();

            if (cell.getBrush() != null)
                this.brush = cell.getBrush().clone();
            else
                this.brush = null;

            this.rowSpan = cell.getRowSpan();
            this.colSpan = cell.getColSpan();

            if (cell.getCellContent() != null)
                this.content = cell.getCellContent().clone();
            else
                this.content = null;

            return this;
        }

        /**
         * Инициализация пера на основе другого пера.
         * <p> Не создаётся новый эземпляр пера, меняются только элементы пера.
         *
         * @param initPen инициализируемое перо.
         * @param dataPen перо источник, на основе которого будет производиться инициализация.
         */
        private void initPen(IPen initPen, IPen dataPen) {
            initPen.getElements().clear();
            for (IPenElement penEl : dataPen.getElements())
                initPen.getElements().add(penEl.clone());
        }

        /**
         * Получить перо левой границы ячейки.
         *
         * @return перо левой границы ячейки.
         */
        public IPen getLeftPen() {
            return this.leftPen;
        }

        /**
         * Установить перо левой границы ячейки.
         *
         * @param pen перо левой границы ячейки.
         */
        public void setLeftPen(IPen pen) {
            // При установке пера необходимо так же его поставить в смежную с текущей ячейкой.
            if (this.leftPen == pen)
                return;

            this.leftPen = pen;

            int index = cells.indexOf(this);
            if (index != -1 && columnCount > 0 && index % columnCount != 0)
                cells.get(index - 1).setRightPen(pen);
        }

        /**
         * Получить перо правой границы ячейки.
         *
         * @return перо правой границы ячейки.
         */
        public IPen getRightPen() {
            return this.rightPen;
        }

        /**
         * Установить перо правой границы ячейки.
         *
         * @param pen перо правой границы ячейки.
         */
        public void setRightPen(IPen pen) {
            // При установке пера необходимо так же его поставить в смежную с текущей ячейкой.
            if (this.rightPen == pen)
                return;

            this.rightPen = pen;

            int index = cells.indexOf(this);
            if (index != -1 && columnCount > 0 && index % columnCount != columnCount - 1)
                cells.get(index + 1).setLeftPen(pen);
        }

        /**
         * Получить перо верхней границы ячейки.
         *
         * @return перо верхней границы ячейки.
         */
        public IPen getTopPen() {
            return this.topPen;
        }

        /**
         * Установить перо верхней границы ячейки.
         *
         * @param pen перо верхней границы ячейки.
         */
        public void setTopPen(IPen pen) {
            // При установке пера необходимо так же его поставить в смежную с текущей ячейкой.
            if (this.topPen == pen)
                return;

            this.topPen = pen;

            int index = cells.indexOf(this);
            if (index != -1 && columnCount > 0 && index / columnCount > 0)
                cells.get(index - columnCount).setBottomPen(pen);
        }

        /**
         * Получить перо нижней границы ячейки.
         *
         * @return перо нижней границы ячейки.
         */
        public IPen getBottomPen() {
            return this.bottomPen;
        }

        /**
         * Установить перо нижней границы ячейки.
         *
         * @param pen перо нижней границы ячейки.
         */
        public void setBottomPen(IPen pen) {
            // При установке пера необходимо так же его поставить в смежную с текущей ячейкой.
            if (this.bottomPen == pen)
                return;

            this.bottomPen = pen;

            int index = cells.indexOf(this);
            if (index != -1 && columnCount > 0 && index / columnCount < rowCount - 1)
                cells.get(index + columnCount).setTopPen(pen);
        }

        /**
         * Получить заливку.
         *
         * @return заливка.
         */
        public IBrush getBrush() {
            return this.brush;
        }

        /**
         * Установить заливку.
         *
         * @param brush заливка.
         */
        public void setBrush(IBrush brush) {
            this.brush = brush;
        }

        /**
         * Получить количество перекрытых ячеек по горизонтали.
         *
         * @return количество перекрытых ячеек по горизонтали.
         */
        public int getColSpan() {
            return this.colSpan;
        }

        /**
         * Установить количество перекрытых ячеек по горизонтали.
         *
         * @param colSpan количество перекрытых ячеек по горизонтали.
         */
        public void setColSpan(int colSpan) {
            this.colSpan = colSpan;
        }

        /**
         * Получить количество перекрытых ячеек по вертикали.
         *
         * @return количество перекрытых ячеек по вертикали.
         */
        public int getRowSpan() {
            return this.rowSpan;
        }

        /**
         * Установить количество перекрытых ячеек по вертикали.
         *
         * @param rowSpan количество перекрытых ячеек по вертикали.
         */
        public void setRowSpan(int rowSpan) {
            this.rowSpan = rowSpan;
        }

        /**
         * Получить содержимое ячейки.
         *
         * @return содержимое ячейки.
         */
        public ICellContent getCellContent() {
            return this.content;
        }

        /**
         * Установить содержимое ячейки.
         *
         * @param content содержимое ячейки.
         */
        public void setCellContent(ICellContent content) {
            this.content = content;
        }

        /**
         * Получить размеры ячейки.
         *
         * @return размеры ячейки.
         */
        public BasePoint2D getSize() {
            int index = TableSignVisual.this.cells.indexOf(this);
            int rowIndex = index / columns.size();
            int colIndex = index - rowIndex * columns.size();

            return new BasePoint2D(columns.get(colIndex).getWidth(), rows.get(rowIndex).getHeight());
        }

        /**
         * Клонирование.
         *
         * @return клон.
         */
        public Cell clone() {
            return new Cell().init(this);
        }

    }


    /**
     * Строка.
     *
     * @author Giller
     */
    public class Row implements Cloneable {

        /**
         * Перечень ячеек в строке.
         *
         * @author Giller
         */
        private class RowCellList extends ListReference<Cell> {

            /**
             * Конструктор по умолчнию.
             *
             * @param cells перечень ячеек.
             **/
            public RowCellList(List<Cell> cells) {
                super(cells, false);
            }

        }

        /**
         * Высота строки.
         */
        private double height;
        /**
         * Получить перечень ячеек в строке.
         */
        private List<Cell> rowCells;

        /**
         * Конструктор с входными параметрами.
         *
         * @param height высота строки.
         * @param cells  перечень ячеек.
         */
        public Row(double height, List<Cell> cells) {
            rowCells = new RowCellList(cells);
            this.height = height;
        }

        /**
         * Получить высоту строки.
         *
         * @return высота строки.
         */
        public double getHeight() {
            return this.height;
        }

        /**
         * Установить высоту строки.
         *
         * @param height высота строки.
         */
        public void setHeight(double height) {
            this.height = height;
        }

        /**
         * Получить перечень ячеек.
         *
         * @return перечень ячеек.
         */
        public List<Cell> getCells() {
            return this.rowCells;
        }

        /**
         * Клонирование.
         *
         * @return клон.
         */
        public Row clone() {
            List<Cell> tCells = new ArrayList<Cell>();
            for (Cell cell : rowCells)
                tCells.add(new Cell(cell));

            Row clone = new Row(this.height, tCells);
            return clone;
        }
    }


    /**
     * Столбец.
     *
     * @author Giller
     */
    public class Column implements Cloneable {

        /**
         * Перечень ячеек в строке.
         *
         * @author Giller
         */
        private class ColumnCellList extends ListReference<Cell> {

            /**
             * Конструктор с входным параметром.
             *
             * @param cells перечень ячеек.
             */
            public ColumnCellList(List<Cell> cells) {
                super(cells, false);
            }

        }

        /**
         * Высота строки.
         */
        private double width;
        /**
         * Перечень ячеек столбца.
         */
        private List<Cell> columnsCells;

        /**
         * Конструктор с входными параметрами.
         *
         * @param width ширина столбца.
         * @param cells перечень ячеек.
         */
        public Column(double width, List<Cell> cells) {
            columnsCells = new ColumnCellList(cells);
            this.width = width;
        }

        /**
         * Получить ширину столбца.
         *
         * @return ширина столбца.
         */
        public double getWidth() {
            return this.width;
        }

        /**
         * Установить ширину столбца.
         *
         * @param width ширина столбца.
         */
        public void setWidth(double width) {
            this.width = width;
        }

        /**
         * Получить перечень ячеек.
         *
         * @return перечень ячеек.
         */
        public List<Cell> getCells() {
            return this.columnsCells;
        }

        /**
         * Клонирование.
         *
         * @return клон.
         */
        public Column clone() {
            List<Cell> tCells = new ArrayList<Cell>();
            for (Cell cell : this.columnsCells)
                tCells.add(new Cell(cell));

            Column column = new Column(this.width, tCells);
            return column;
        }

    }


    /**
     * Перечень строк.
     * <p> При добавлении/удалении через методы Rows так же корректируется размер таблицы.
     *
     * @author Giller
     */
    private class Rows extends AbstractList<Row> {

        /**
         * Перечень строк.
         */
        List<Row> rRows = new ArrayList<Row>();

        /**
         * Конструктор по умолчанию.
         */
        public Rows() {
        }

        @Override
        public Row get(int index) {
            return rRows.get(index);
        }

        @Override
        public int size() {
            return rRows.size();
        }

        @Override
        public void add(int index, Row row) {
            addRow(index, row);

            int rowIndex = index;
            List<Cell> cells = new ArrayList<Cell>();
            for (int i = 0; i < columnCount; ++i)
                cells.add(TableSignVisual.this.cells.get(rowIndex * columnCount + i));

            double height = DEFAULT_ROW_HEIGHT;
            if (row != null)
                height = row.getHeight();

            rRows.add(index, new Row(height, cells));

//			TableSignVisual.this.calculate();
        }

        @Override
        public Row set(int index, Row row) {
            Row tableRow = rRows.get(index);

            for (int i = 0; i < tableRow.getCells().size() && i < row.getCells().size(); ++i)
                tableRow.getCells().get(i).init(row.getCells().get(i));

            return tableRow;
        }

        @Override
        public Row remove(int index) {
            removeRow(index);
            rRows.remove(index);
//			TableSignVisual.this.calculate();
            return null;
        }

        @Override
        public boolean remove(Object o) {
            Row row = (Row) o;
            int indexOf = rRows.indexOf(row);

            if (indexOf >= 0)
                this.remove(indexOf);

            return true;
        }

        @Override
        public void clear() {
            rRows.clear();
            TableSignVisual.this.columns.cColumns.clear();
            TableSignVisual.this.clear();
        }

    }


    /**
     * Класс для работы с перечнем столбцов.
     * <p> При добавлении/удалении через методы Columns так же корректируется размер таблицы.
     *
     * @author Giller
     */
    private class Columns extends AbstractList<Column> {
        /**
         * Перечень столбцов.
         */
        List<Column> cColumns = new ArrayList<Column>();

        /**
         * Конструктор по умолчанию.
         */
        public Columns() {
        }

        @Override
        public Column get(int index) {
            return cColumns.get(index);
        }

        @Override
        public int size() {
            return cColumns.size();
        }

        @Override
        public void add(int index, Column column) {
            addColumn(index, column);

            List<Cell> cells = new ArrayList<Cell>();
            for (int i = 0; i < rowCount; ++i)
                cells.add(TableSignVisual.this.cells.get(i * columnCount + index));

            double width = DEFAULT_COLUMN_WIDTH;
            if (column != null)
                width = column.getWidth();

            cColumns.add(index, new Column(width, cells));

//			TableSignVisual.this.calculate();
        }

        @Override
        public Column set(int index, Column column) {
            Column tableColumn = cColumns.get(index);

            for (int i = 0; i < tableColumn.getCells().size() && i < column.getCells().size(); ++i)
                tableColumn.getCells().get(i).init(column.getCells().get(i));

            return tableColumn;
        }

        @Override
        public Column remove(int index) {
            removeColumn(index);
            cColumns.remove(index);
//			TableSignVisual.this.calculate();
            return null;
        }

        @Override
        public boolean remove(Object o) {
            int indexOf = cColumns.indexOf(o);
            if (indexOf >= 0)
                this.remove(indexOf);

            return true;
        }

        @Override
        public void clear() {
            cColumns.clear();
            TableSignVisual.this.rows.rRows.clear();
            TableSignVisual.this.clear();
        }

    }


    /**
     * Графический элемент для ячейки.
     * <p> Переопределенны методы получения заливки.
     * Это сделано из-за того, что в графическом элементе ячейки сожержатся линии границы (каждая в отдельности).
     * А заливка будет относится к заливке самой ячейки (а не каждой линии границы отдельно).
     * Сама заливка обрабатывается уже в построителе, здесь она нужна для изменения её параметров через дерево графических элементов.
     *
     * @author Giller
     */
    class CellGraphElement extends GroupGraphElement {

        /**
         * Ячейка.
         */
        private Cell cell;

        /**
         * Конструктор с входными параметрами.
         *
         * @param cell ячейка.
         */
        public CellGraphElement(Cell cell) {
            this.cell = cell;
        }

        @Override
        public IBrush getBrush() {
            return this.cell.getBrush();
        }

        @Override
        public void setBrush(IBrush brush) {
            this.cell.setBrush(brush);
        }

        @Override
        public GroupGraphElement clone() {
            CellGraphElement clone = (CellGraphElement) super.clone();
            clone.cell = cell.clone();
            return clone;
        }

        @Override
        public IText getText() {
            if (cell.getCellContent() instanceof ITextCellContent)
                return ((ITextCellContent) cell.getCellContent()).getText();

            return null;
        }

        @Override
        public void setText(IText text) {
            if (cell.getCellContent() instanceof ITextCellContent)
                ((ITextCellContent) cell.getCellContent()).setText(text);
        }

        @Override
        public boolean equals(Object obj) {
            return obj instanceof CellGraphElement && ((CellGraphElement) obj).cell == this.cell;
        }

    }


    /**
     * Графический элемент для ячейки, которая покрывает другие ячейки.
     *
     * @author Gillers
     */
    class CellSpanGraphElement extends GroupGraphElement {

        /**
         * Ячейка.
         */
        private Cell cell;

        /**
         * Конструктор с входным параметром.
         *
         * @param cellIndex индекc ячейки, покрывающей другие ячейки.
         */
        public CellSpanGraphElement(int cellIndex) {
            this.cell = TableSignVisual.this.cells.get(cellIndex);

            int rowIndex = cellIndex / columnCount + 1;
            int colIndex = cellIndex % columnCount + 1;

            // Корректировка покрытия. На случай если ячейка перекрывает ячеек больше, чем есть в самой таблице.
            int rowSpan = this.cell.getRowSpan() < 1 ? 1 : this.cell.getRowSpan();
            if (rowCount < rowIndex + (rowSpan - 1))
                rowSpan = (rowCount - rowIndex) + 1;

            int colSpan = this.cell.getColSpan() < 1 ? 1 : this.cell.getColSpan();
            if (columnCount < colIndex + (colSpan - 1))
                colSpan = (columnCount - colIndex) + 1;

            setName("Ячейка объединённая "
                    + rowIndex + (rowSpan > 1 ? " - " + (int) (rowIndex + rowSpan - 1) : "")
                    + ", "
                    + colIndex + (colSpan > 1 ? " - " + (int) (colIndex + colSpan - 1) : "")
                    + " (перо, заливка, текст)");

            // Инициализация графических элементов.
            this.getElements().clear();

            // Инициализация верхней границы.
            List<Cell> cells = new ArrayList<Cell>();
            for (int i = 0; i <= colSpan - 1; ++i)
                cells.add(TableSignVisual.this.cells.get(cellIndex + i));

            IGroupGraphElement topContour = new GroupGraphElement("Верхняя граница (перо)");
            TableSignVisual.this.calculateCellsTopContourGraphElement(topContour, cells);

            // Иницилазиция нижней границы.
            cells = new ArrayList<Cell>();
            for (int i = 0; i <= colSpan - 1; ++i)
                cells.add(TableSignVisual.this.cells.get(cellIndex + i + (rowSpan - 1) * columnCount));

            IGroupGraphElement bottomContour = new GroupGraphElement("Нижняя граница (перо)");
            TableSignVisual.this.calculateCellsBottomContourGraphElement(bottomContour, cells);

            // Инициализация левой границы.
            cells = new ArrayList<Cell>();
            for (int i = 0; i <= rowSpan - 1; ++i)
                cells.add(TableSignVisual.this.cells.get(cellIndex + i * columnCount));

            IGroupGraphElement leftContour = new GroupGraphElement("Левая граница (перо)");
            TableSignVisual.this.calculateCellsLeftContourGraphElement(leftContour, cells);

            // Инициализация правой границы.
            cells = new ArrayList<Cell>();
            for (int i = 0; i <= rowSpan - 1; ++i)
                cells.add(TableSignVisual.this.cells.get(cellIndex + (colSpan - 1) + i * columnCount));

            IGroupGraphElement rightContour = new GroupGraphElement("Правая граница (перо)");
            TableSignVisual.this.calculateCellsRightContourGraphElement(rightContour, cells);

            IGroupGraphElement contourGraphElement = new GroupGraphElement("Контур (перо)");

            contourGraphElement.getElements().add(leftContour);
            contourGraphElement.getElements().add(rightContour);
            contourGraphElement.getElements().add(topContour);
            contourGraphElement.getElements().add(bottomContour);

            this.getElements().add(contourGraphElement);

//			if (cell.getCellContent() != null)
//				this.getElements().add(cell.getCellContent().getGraphElement());
        }

        @Override
        public IText getText() {
            if (cell.getCellContent() instanceof ITextCellContent)
                return ((ITextCellContent) cell.getCellContent()).getText();

            return null;
        }

        @Override
        public void setText(IText text) {
            if (cell.getCellContent() instanceof ITextCellContent)
                ((ITextCellContent) cell.getCellContent()).setText(text);
        }

        @Override
        public IBrush getBrush() {
            return this.cell.getBrush();
        }

        @Override
        public void setBrush(IBrush brush) {
            cell.setBrush(brush);
        }

        @Override
        public boolean equals(Object obj) {
            return obj instanceof CellSpanGraphElement && ((CellSpanGraphElement) obj).cell == this.cell;
        }

    }


    /**
     * Графический элемент линии решетки.
     *
     * @author Giller
     */
    private class GridLineGraphElement extends LineGraphElement {

        /**
         * Создание графического элемента для линии решетки.
         *
         * @param pen    перо.
         * @param brush  заливка.
         * @param text   текст.
         * @param smooth сглаженность.
         * @param closed замкнутость.
         */
        public GridLineGraphElement(IPen pen, IBrush brush, IText text, boolean smooth, boolean closed) {
            super(pen, brush, text, smooth, closed);
        }

        @Override
        public void setPen(IPen pen) {
        }

        @Override
        public void setBrush(IBrush brush) {
        }

        @Override
        public IBrush getBrush() {
            return null;
        }

        @Override
        public void setText(IText text) {
        }

        @Override
        public IText getText() {
            return null;
        }

        @Override
        public void setClosed(boolean closed) {
        }

        @Override
        public boolean isClosed() {
            return false;
        }

        @Override
        public void setSmooth(boolean smooth) {
        }

        @Override
        public boolean isSmooth() {
            return false;
        }

    }


    /**
     * Поставщик графических элементов.
     *
     * @author Giller
     */
    private class GraphElementProvider implements IGarbageCleaner {

        /**
         * Поставщик графических элементов ячеек.
         *
         * @author Giller
         */
        private class CellGEProvider implements IGarbageCleaner {
            /**
             * Графические элементы левых границ.
             */
            private Map<Cell, IGraphElement> cellLeftLines = new HashMap<Cell, IGraphElement>();
            /**
             * Графические элементы правых границ.
             */
            private Map<Cell, IGraphElement> cellRightLines = new HashMap<Cell, IGraphElement>();
            /**
             * Графические элементы верхних границ.
             */
            private Map<Cell, IGraphElement> cellTopLines = new HashMap<Cell, IGraphElement>();
            /**
             * Графические элементы нижних границ.
             */
            private Map<Cell, IGraphElement> cellBottomLines = new HashMap<Cell, IGraphElement>();

            /**
             * Графические элементы левых границ.
             */
            private Map<Cell, IGraphElement> cellLeftInfoLines = new HashMap<Cell, IGraphElement>();
            /**
             * Графические элементы правых границ.
             */
            private Map<Cell, IGraphElement> cellRightInfoLines = new HashMap<Cell, IGraphElement>();
            /**
             * Графические элементы верхних границ.
             */
            private Map<Cell, IGraphElement> cellTopInfoLines = new HashMap<Cell, IGraphElement>();
            /**
             * Графические элементы нижних границ.
             */
            private Map<Cell, IGraphElement> cellBottomInfoLines = new HashMap<Cell, IGraphElement>();

            /**
             * Создание поставщика графических элементов для ячеек.
             */
            public CellGEProvider() {
            }

            /**
             * Получить графический элемент левой границы ячейки.
             *
             * @param cell ячейка.
             * @return графический элемент левой границы ячейки.
             */
            public IGraphElement getCellLeftInfoLineGE(Cell cell) {
                if (cellLeftInfoLines.get(cell) == null)
                    cellLeftInfoLines.put(cell, new GridLineGraphElement(cell.getLeftPen(), null, null, false, false));
                return cellLeftInfoLines.get(cell);
            }

            /**
             * Получить графический элемент правой границы ячейки.
             *
             * @param cell ячейка.
             * @return графический элемент правой границы ячейки.
             */
            public IGraphElement getCellRightInfoLineGE(Cell cell) {
                if (cellRightInfoLines.get(cell) == null)
                    cellRightInfoLines.put(cell, new GridLineGraphElement(cell.getRightPen(), null, null, false, false));
                return cellRightInfoLines.get(cell);
            }

            /**
             * Получить графический элемент верхней границы ячейки.
             *
             * @param cell ячейка.
             * @return графический элемент верхней границы ячейки.
             */
            public IGraphElement getCellTopInfoLineGE(Cell cell) {
                if (cellTopInfoLines.get(cell) == null)
                    cellTopInfoLines.put(cell, new GridLineGraphElement(cell.getTopPen(), null, null, false, false));
                return cellTopInfoLines.get(cell);
            }

            /**
             * Получить графический элемент нижней границы ячейки.
             *
             * @param cell ячейка.
             * @return графический элемент нижней границы ячейки.
             */
            public IGraphElement getCellBottomInfoLineGE(Cell cell) {
                if (cellBottomInfoLines.get(cell) == null)
                    cellBottomInfoLines.put(cell, new GridLineGraphElement(cell.getBottomPen(), null, null, false, false));
                return cellBottomInfoLines.get(cell);
            }

            /**
             * Получить графический элемент левой границы ячейки.
             *
             * @param cell ячейка.
             * @return графический элемент левой границы ячейки.
             */
            public IGraphElement getCellLeftLineGE(Cell cell) {
                if (cellLeftLines.get(cell) == null) {
                    cellLeftLines.put(cell, new GridLineGraphElement(cell.getLeftPen(), null, null, false, false));
                    cellLeftLines.get(cell).setName("Левая граница (перо)");
                }
                return cellLeftLines.get(cell);
            }

            /**
             * Получить графический элемент правой границы ячейки.
             *
             * @param cell ячейка.
             * @return графический элемент правой границы ячейки.
             */
            public IGraphElement getCellRightLineGE(Cell cell) {
                if (cellRightLines.get(cell) == null) {
                    cellRightLines.put(cell, new GridLineGraphElement(cell.getRightPen(), null, null, false, false));
                    cellRightLines.get(cell).setName("Правая граница (перо)");
                }
                return cellRightLines.get(cell);
            }

            /**
             * Получить графический элемент верхней границы ячейки.
             *
             * @param cell ячейка.
             * @return графический элемент верхней границы ячейки.
             */
            public IGraphElement getCellTopLineGE(Cell cell) {
                if (cellTopLines.get(cell) == null) {
                    cellTopLines.put(cell, new GridLineGraphElement(cell.getTopPen(), null, null, false, false));
                    cellTopLines.get(cell).setName("Верхняя граница (перо)");
                }
                return cellTopLines.get(cell);
            }

            /**
             * Получить графический элемент нижней границы ячейки.
             *
             * @param cell ячейка.
             * @return графический элемент нижней границы ячейки.
             */
            public IGraphElement getCellBottomLineGE(Cell cell) {
                if (cellBottomLines.get(cell) == null) {
                    cellBottomLines.put(cell, new GridLineGraphElement(cell.getBottomPen(), null, null, false, false));
                    cellBottomLines.get(cell).setName("Нижняя граница (перо)");
                }
                return cellBottomLines.get(cell);
            }

            @Override
            public void cleanOldSignUtils() {
                List<Cell> cells = TableSignVisual.this.cells;

                removeOldSignUtils(cells, cellLeftLines);
                removeOldSignUtils(cells, cellRightLines);
                removeOldSignUtils(cells, cellTopLines);
                removeOldSignUtils(cells, cellBottomLines);
                removeOldSignUtils(cells, cellLeftInfoLines);
                removeOldSignUtils(cells, cellRightInfoLines);
                removeOldSignUtils(cells, cellTopInfoLines);
                removeOldSignUtils(cells, cellBottomInfoLines);
            }

        }


        /**
         * Поставщик графических элементов строки.
         *
         * @author Giller
         */
        private class RowGEProvider implements IGarbageCleaner {
            // Contour.
            /**
             * Графические элементы для контуров строк.
             */
            private Map<Row, IGroupGraphElement> rowsContourGElements = new HashMap<Row, IGroupGraphElement>();
            /**
             * Графические элементы для строк.
             */
            private Map<Row, IGroupGraphElement> rowsGElements = new HashMap<Row, IGroupGraphElement>();
            /**
             * Графические элементы правых границ строк.
             */
            private Map<Row, IGraphElement> rowRightLinesGElements = new HashMap<Row, IGraphElement>();
            /**
             * Графические элементы левых границ строк.
             */
            private Map<Row, IGraphElement> rowLeftLinesGElements = new HashMap<Row, IGraphElement>();
            /**
             * Графические элементы для верхнего контура строк.
             */
            private Map<Row, IGroupGraphElement> rowTopLinesContourGElements = new HashMap<Row, IGroupGraphElement>();
            /**
             * Графические элементы для нижнего контура строк.
             */
            private Map<Row, IGroupGraphElement> rowBottomLinesContourGElements = new HashMap<Row, IGroupGraphElement>();

            // Row cells.
            /**
             * Графические элементы для узла с ячейками строк.
             */
            private Map<Row, IGroupGraphElement> rowsCellsGElements = new HashMap<Row, IGroupGraphElement>();

            // Row cells contours.
            /**
             * Графические элементы контура ячеек в строке.
             */
            private Map<Row, IGroupGraphElement> rowsCellsContoursGElements = new HashMap<Row, IGroupGraphElement>();
            /**
             * Графические элементы для левых границ ячеек в строке.
             */
            private Map<Row, IGroupGraphElement> rowsLeftCellsLinesGElements = new HashMap<Row, IGroupGraphElement>();
            /**
             * Графические элементы для правых границ ячеек в строке.
             */
            private Map<Row, IGroupGraphElement> rowsRightCellsLinesGElements = new HashMap<Row, IGroupGraphElement>();
            /**
             * Графические элементы для верхних границ ячеек в строке.
             */
            private Map<Row, IGroupGraphElement> rowsTopCellsLinesGElements = new HashMap<Row, IGroupGraphElement>();
            /**
             * Графические элементы для нижних границ ячеек в строке.
             */
            private Map<Row, IGroupGraphElement> rowsBottomCellsLinesGElements = new HashMap<Row, IGroupGraphElement>();

            /**
             * Создание поставщика графичес ких элементов.
             */
            public RowGEProvider() {
            }

            /**
             * Получить графический элемент для строки.
             *
             * @param row строка.
             * @return графический элемент для строки.
             */
            public IGroupGraphElement getRowGE(Row row) {
                if (rowsGElements.get(row) == null)
                    rowsGElements.put(row, new GroupGraphElement());
                return rowsGElements.get(row);
            }

            /**
             * Получить графичекий элемент для контура строки.
             *
             * @param row строка.
             * @return графичекий элемент для контура строки.
             */
            public IGroupGraphElement getRowContourGE(Row row) {
                if (rowsContourGElements.get(row) == null)
                    rowsContourGElements.put(row, new GroupGraphElement("Контур"));
                return rowsContourGElements.get(row);
            }

            /**
             * Получить графический элмент для верхней линии строки.
             *
             * @param row строка.
             * @return графический элмент для верхней линии строки.
             */
            public IGroupGraphElement getRowTopLineGE(Row row) {
                if (rowTopLinesContourGElements.get(row) == null)
                    rowTopLinesContourGElements.put(row, new GroupGraphElement("Верхняя граница"));
                return rowTopLinesContourGElements.get(row);
            }

            /**
             * Получить графический	элемент для нижней линии строки.
             *
             * @param row строка.
             * @return графический    элемент для нижней линии строки.
             */
            public IGroupGraphElement getRowBottomLineGE(Row row) {
                if (rowBottomLinesContourGElements.get(row) == null)
                    rowBottomLinesContourGElements.put(row, new GroupGraphElement("Нижняя граница"));
                return rowBottomLinesContourGElements.get(row);
            }

            /**
             * Получить графический элемент левой лнии строки.
             *
             * @param row строка.
             * @return графический элемент левой лнии строки.
             */
            public IGraphElement getRowLeftLineGE(Row row) {
                if (rowLeftLinesGElements.get(row) == null)
                    rowLeftLinesGElements.put(row, new GridLineGraphElement(row.getCells().get(0).getLeftPen(), null, null, false, false));
                return rowLeftLinesGElements.get(row);
            }

            /**
             * Получить графический элемент правой лнии строки.
             *
             * @param row строка.
             * @return графический элемент правой лнии строки.
             */
            public IGraphElement getRowRightLineGE(Row row) {
                if (rowRightLinesGElements.get(row) == null)
                    rowRightLinesGElements.put(row, new GridLineGraphElement(row.getCells().get(row.getCells().size() - 1).getLeftPen(), null, null, false, false));
                return rowRightLinesGElements.get(row);
            }

            /**
             * Получить графический элемент для ячеек строки.
             *
             * @param row строка.
             * @return графический элемент для ячеек строки.
             */
            public IGroupGraphElement getRowCellsGE(Row row) {
                if (rowsCellsGElements.get(row) == null)
                    rowsCellsGElements.put(row, new GroupGraphElement("Ячейки (перо, заливка, текст)"));
                return rowsCellsGElements.get(row);
            }

            /**
             * Получить графический элемент контура для ячеек.
             *
             * @param row строка.
             * @return графический элемент контура для ячеек.
             */
            public IGroupGraphElement getRowCellsContour(Row row) {
                if (rowsCellsContoursGElements.get(row) == null)
                    rowsCellsContoursGElements.put(row, new GroupGraphElement("Контур (перо)"));
                return rowsCellsContoursGElements.get(row);
            }

            /**
             * Получить графический элемент для левых границ ячеек строки.
             *
             * @param row строка.
             * @return графический элемент для левых границ ячеек строки.
             */
            public IGroupGraphElement getLeftCellsLinesGE(Row row) {
                if (rowsLeftCellsLinesGElements.get(row) == null)
                    rowsLeftCellsLinesGElements.put(row, new GroupGraphElement("Левая граница (перо)"));
                return rowsLeftCellsLinesGElements.get(row);
            }

            /**
             * Получить графический элемент для правых границ ячеек строки.
             *
             * @param row строка.
             * @return графический элемент для правых границ ячеек строки.
             */
            public IGroupGraphElement getRightCellsLinesGE(Row row) {
                if (rowsRightCellsLinesGElements.get(row) == null)
                    rowsRightCellsLinesGElements.put(row, new GroupGraphElement("Правая граница (перо)"));
                return rowsRightCellsLinesGElements.get(row);
            }

            /**
             * Получить графический элемент для верхних границ ячеек строки.
             *
             * @param row строка.
             * @return графический элемент для верхних границ ячеек строки.
             */
            public IGroupGraphElement getTopCellsLinesGE(Row row) {
                if (rowsTopCellsLinesGElements.get(row) == null)
                    rowsTopCellsLinesGElements.put(row, new GroupGraphElement("Верхняя граница (перо)"));
                return rowsTopCellsLinesGElements.get(row);
            }

            /**
             * Получить графический элемент для нижних границ ячеек строки.
             *
             * @param row строка.
             * @return графический элемент для нижних границ ячеек строки.
             */
            public IGroupGraphElement getBottomCellsLinesGE(Row row) {
                if (rowsBottomCellsLinesGElements.get(row) == null)
                    rowsBottomCellsLinesGElements.put(row, new GroupGraphElement("Нижняя граница (перо)"));
                return rowsBottomCellsLinesGElements.get(row);
            }

            @Override
            public void cleanOldSignUtils() {
                List<Row> rows = TableSignVisual.this.rows;

                removeOldSignUtils(rows, rowsContourGElements);
                removeOldSignUtils(rows, rowsGElements);
                removeOldSignUtils(rows, rowRightLinesGElements);
                removeOldSignUtils(rows, rowLeftLinesGElements);
                removeOldSignUtils(rows, rowTopLinesContourGElements);
                removeOldSignUtils(rows, rowBottomLinesContourGElements);
                removeOldSignUtils(rows, rowsCellsGElements);
                removeOldSignUtils(rows, rowsCellsContoursGElements);
                removeOldSignUtils(rows, rowsLeftCellsLinesGElements);
                removeOldSignUtils(rows, rowsRightCellsLinesGElements);
                removeOldSignUtils(rows, rowsTopCellsLinesGElements);
                removeOldSignUtils(rows, rowsBottomCellsLinesGElements);

            }
        }


        /**
         * Поставщик графических элементов для столбца.
         *
         * @author Giller
         */
        class ColumnGEProvider implements IGarbageCleaner {
            // Contour.
            /**
             * Графические элементы для контуров столбцов.
             */
            private Map<Column, IGroupGraphElement> colsContourGElements = new HashMap<Column, IGroupGraphElement>();
            /**
             * Графические элементы для столбцов.
             */
            private Map<Column, IGroupGraphElement> colsGElements = new HashMap<Column, IGroupGraphElement>();
            /**
             * Графические элементы правых границ столбцов.
             */
            private Map<Column, IGroupGraphElement> colRightLinesGElements = new HashMap<Column, IGroupGraphElement>();
            /**
             * Графические элементы левых границ столбцов.
             */
            private Map<Column, IGroupGraphElement> colLeftLinesGElements = new HashMap<Column, IGroupGraphElement>();
            /**
             * Графические элементы для верхнего контура столбцов.
             */
            private Map<Column, IGraphElement> colTopLinesContourGElements = new HashMap<Column, IGraphElement>();
            /**
             * Графические элементы для нижнего контура столбцов.
             */
            private Map<Column, IGraphElement> colBottomLinesContourGElements = new HashMap<Column, IGraphElement>();

            // Row cells.
            /**
             * Графические элементы для узла с ячейками столбцов.
             */
            private Map<Column, IGroupGraphElement> colsCellsGElements = new HashMap<Column, IGroupGraphElement>();

            // Row cells contours.
            /**
             * Графические элементы контура ячеек в столбце.
             */
            private Map<Column, IGroupGraphElement> colsCellsContoursGElements = new HashMap<Column, IGroupGraphElement>();
            /**
             * Графические элементы для левых границ ячеек в столбце.
             */
            private Map<Column, IGroupGraphElement> colsLeftCellsLinesGElements = new HashMap<Column, IGroupGraphElement>();
            /**
             * Графические элементы для правых границ ячеек в столбце.
             */
            private Map<Column, IGroupGraphElement> colsRightCellsLinesGElements = new HashMap<Column, IGroupGraphElement>();
            /**
             * Графические элементы для верхних границ ячеек в столбце.
             */
            private Map<Column, IGroupGraphElement> colsTopCellsLinesGElements = new HashMap<Column, IGroupGraphElement>();
            /**
             * Графические элементы для нижних границ ячеек в столбце.
             */
            private Map<Column, IGroupGraphElement> colsBottomCellsLinesGElements = new HashMap<Column, IGroupGraphElement>();

            /**
             * Создание поставщика графических элементов.
             */
            public ColumnGEProvider() {
            }

            /**
             * Получить графический элемент для столбца.
             *
             * @param col столбец.
             * @return графический элемент для столбца.
             */
            public IGroupGraphElement getColumnGE(Column col) {
                if (colsGElements.get(col) == null)
                    colsGElements.put(col, new GroupGraphElement());
                return colsGElements.get(col);
            }

            /**
             * Получить графичекий элемент для контура столбца.
             *
             * @param col столбец.
             * @return графичекий элемент для контура столбца.
             */
            public IGroupGraphElement getColumnContourGE(Column col) {
                if (colsContourGElements.get(col) == null)
                    colsContourGElements.put(col, new GroupGraphElement("Контур"));
                return colsContourGElements.get(col);
            }

            /**
             * Получить графический элмент для верхней линии столбца.
             *
             * @param col столбец.
             * @return графический элмент для верхней линии столбца.
             */
            public IGraphElement getColumnTopLineGE(Column col) {
                if (colTopLinesContourGElements.get(col) == null)
                    colTopLinesContourGElements.put(col, new GridLineGraphElement(col.getCells().get(0).getTopPen(), null, null, false, false));
                return colTopLinesContourGElements.get(col);
            }

            /**
             * Получить графический	элемент для нижней линии столбца.
             *
             * @param col столбец.
             * @return графический    элемент для нижней линии столбца.
             */
            public IGraphElement getColumnBottomLineGE(Column col) {
                if (colBottomLinesContourGElements.get(col) == null)
                    colBottomLinesContourGElements.put(col, new GridLineGraphElement(col.getCells().get(col.getCells().size() - 1).getBottomPen(), null, null, false, false));
                return colBottomLinesContourGElements.get(col);
            }

            /**
             * Получить графический элемент левой линии столбца.
             *
             * @param col столбец.
             * @return графический элемент левой линии столбца.
             */
            public IGroupGraphElement getColumnLeftLineGE(Column col) {
                if (colLeftLinesGElements.get(col) == null)
                    colLeftLinesGElements.put(col, new GroupGraphElement("Левая граница"));
                return colLeftLinesGElements.get(col);
            }

            /**
             * Получить графический элемент правой линии столбца.
             *
             * @param col столбец.
             * @return графический элемент правой линии столбца.
             */
            public IGroupGraphElement getColumnRightLineGE(Column col) {
                if (colRightLinesGElements.get(col) == null)
                    colRightLinesGElements.put(col, new GroupGraphElement("Правая граница"));
                return colRightLinesGElements.get(col);
            }

            /**
             * Получить графический элемент для ячеек столбца.
             *
             * @param col столбец.
             * @return графический элемент для ячеек столбца.
             */
            public IGroupGraphElement getColumnCellsGE(Column col) {
                if (colsCellsGElements.get(col) == null)
                    colsCellsGElements.put(col, new GroupGraphElement("Ячейки (перо, заливка, текст)"));
                return colsCellsGElements.get(col);
            }

            /**
             * Получить графический элемент контура для ячеек.
             *
             * @param col столбец.
             * @return графический элемент контура для ячеек.
             */
            public IGroupGraphElement getColumnCellsContour(Column col) {
                if (colsCellsContoursGElements.get(col) == null)
                    colsCellsContoursGElements.put(col, new GroupGraphElement("Контур (перо)"));
                return colsCellsContoursGElements.get(col);
            }

            /**
             * Получить графический элемент для левых границ ячеек столбца.
             *
             * @param col столбец.
             * @return графический элемент для левых границ ячеек столбца.
             */
            public IGroupGraphElement getLeftCellsLinesGE(Column col) {
                if (colsLeftCellsLinesGElements.get(col) == null)
                    colsLeftCellsLinesGElements.put(col, new GroupGraphElement("Левая граница (перо)"));
                return colsLeftCellsLinesGElements.get(col);
            }

            /**
             * Получить графический элемент для правых границ ячеек трстолбцаоки.
             *
             * @param col строка.
             * @return графический элемент для правых границ ячеек столбца.
             */
            public IGroupGraphElement getRightCellsLinesGE(Column col) {
                if (colsRightCellsLinesGElements.get(col) == null)
                    colsRightCellsLinesGElements.put(col, new GroupGraphElement("Правая граница (перо)"));
                return colsRightCellsLinesGElements.get(col);
            }

            /**
             * Получить графический элемент для верхних границ ячеек столбца.
             *
             * @param col столбец.
             * @return графический элемент для верхних границ ячеек столбца.
             */
            public IGroupGraphElement getTopCellsLinesGE(Column col) {
                if (colsTopCellsLinesGElements.get(col) == null)
                    colsTopCellsLinesGElements.put(col, new GroupGraphElement("Верхняя граница (перо)"));
                return colsTopCellsLinesGElements.get(col);
            }

            /**
             * Получить графический элемент для нижних границ ячеек столбца.
             *
             * @param col столбец.
             * @return графический элемент для нижних границ ячеек столбца.
             */
            public IGroupGraphElement getBottomCellsLinesGE(Column col) {
                if (colsBottomCellsLinesGElements.get(col) == null)
                    colsBottomCellsLinesGElements.put(col, new GroupGraphElement("Нижняя граница (перо)"));
                return colsBottomCellsLinesGElements.get(col);
            }

            @Override
            public void cleanOldSignUtils() {
                List<Column> cols = TableSignVisual.this.columns;

                removeOldSignUtils(cols, colsContourGElements);
                removeOldSignUtils(cols, colsGElements);
                removeOldSignUtils(cols, colRightLinesGElements);
                removeOldSignUtils(cols, colLeftLinesGElements);
                removeOldSignUtils(cols, colTopLinesContourGElements);
                removeOldSignUtils(cols, colBottomLinesContourGElements);
                removeOldSignUtils(cols, colsCellsGElements);
                removeOldSignUtils(cols, colsCellsContoursGElements);
                removeOldSignUtils(cols, colsLeftCellsLinesGElements);
                removeOldSignUtils(cols, colsRightCellsLinesGElements);
                removeOldSignUtils(cols, colsTopCellsLinesGElements);
                removeOldSignUtils(cols, colsBottomCellsLinesGElements);
            }
        }

        /**
         * Поставщик графических элементов для ячеек.
         */
        private CellGEProvider cellGEProvider = new CellGEProvider();
        /**
         * Поставщик графических элементов для строки.
         */
        private RowGEProvider rowGEProvider = new RowGEProvider();
        /**
         * Поставщик графических элементов для столбца.
         */
        private ColumnGEProvider colGEProvider = new ColumnGEProvider();

        /**
         * Создание поставщика графических элементов.
         */
        public GraphElementProvider() {
        }

        /**
         * Получить поставщик графических элементов для ячейки.
         *
         * @return поставщик графических элементов для ячейки.
         */
        public CellGEProvider getCellGEProvider() {
            return this.cellGEProvider;
        }

        /**
         * Получить поставщик графических элементов для строк.
         *
         * @return поставщик графических элементов для строк.
         */
        public RowGEProvider getRowGEProvider() {
            return this.rowGEProvider;
        }

        /**
         * Получить поставщик графических элементов для столбца.
         *
         * @return поставщик графических элементов для столбца.
         */
        public ColumnGEProvider getColumnGEProvider() {
            return this.colGEProvider;
        }

        @Override
        public void cleanOldSignUtils() {
            this.cellGEProvider.cleanOldSignUtils();
            this.rowGEProvider.cleanOldSignUtils();
            this.colGEProvider.cleanOldSignUtils();
        }

    }


    /**
     * Ширина столбцов по умолчанию.
     */
    static double DEFAULT_COLUMN_WIDTH = 30;
    /**
     * Высота строк по кмолчанию.
     */
    static double DEFAULT_ROW_HEIGHT = 30;

    /**
     * Общий перечень ячеек.
     */
    List<Cell> cells = new ArrayList<Cell>();
    // TODO ? Есть ещё альтернативный вариант: создать плоский список перьев ячеек аналогично плоскому списку самих ячеек.
    // И в ячейках в методах getPen получить перо из плоского списка перьев, расчитывая позицию относительно координат самой ячейки.
    /**
     * Перечень строк.
     */
    Rows rows;
    /**
     * Перечень столбцов.
     */
    Columns columns;

    /**
     * Количество строк.
     */
    int rowCount;
    /**
     * Количество колонок.
     */
    int columnCount;

    /**
     * Перечень графических элементов.
     */
    private List<IGraphElement> graphElements = new ArrayList<IGraphElement>();

    /**
     * Поставщик графических элементов.
     */
    private GraphElementProvider provider = new GraphElementProvider();


    /**
     * Конструктор с входными параметрами.
     *
     * @param rowCount количество строк.
     * @param colCount количество столбцов.
     */
    public TableSignVisual(int rowCount, int colCount) {
        anchorPoints = new AnchorPointsList(1, 1);
        rootGraphElement = new RootGraphElement("Таблица", this, graphElements);
        this.initBaseGraphElements();

        this.rows = new Rows();
        this.columns = new Columns();

        for (int i = 0; i < rowCount; ++i) {
            List<Cell> cells = new ArrayList<Cell>();
            for (int j = 0; j < colCount; ++j)
                cells.add(new Cell());

            this.rows.add(new Row(DEFAULT_ROW_HEIGHT, cells));
        }
    }

    /**
     * Получить перечень строк.
     *
     * @return перечень строк.
     */
    public List<Row> getRows() {
        return this.rows;
    }

    /**
     * Получить перечень столбцов.
     *
     * @return перечень столбцов.
     */
    public List<Column> getColumns() {
        return this.columns;
    }

    @Override
    public TableSignVisual clone() {
        TableSignVisual cloneT = (TableSignVisual) super.clone();
        cloneT.cells = new ArrayList<Cell>();

        cloneT.rowCount = 0;
        cloneT.columnCount = 0;
        cloneT.rows = cloneT.new Rows();
        cloneT.columns = cloneT.new Columns();

        cloneT.graphElements = new ArrayList<IGraphElement>();
        cloneT.rootGraphElement = new RootGraphElement("Таблица", this, cloneT.graphElements);
        cloneT.initBaseGraphElements();

        for (Row row : this.rows) {
            List<Cell> cells = new ArrayList<Cell>();
            for (Cell cell : row.getCells())
                cells.add(cloneT.createCell().init(cell));
            cloneT.getRows().add(cloneT.createRow(row.getHeight(), cells));
        }

        Iterator<Column> columnIt = this.columns.iterator();
        for (Column cloneColumn : cloneT.getColumns())
            cloneColumn.setWidth(columnIt.next().getWidth());

        return cloneT;
    }

    /**
     * Создать ячейку.
     *
     * @return ячейка.
     */
    public Cell createCell() {
        return new Cell();
    }

    /**
     * Создать строку.
     *
     * @param height высота строки.
     * @param cells  перечень ячеек строки.
     * @return строка.
     */
    public Row createRow(double height, List<Cell> cells) {
        return new Row(height, cells);
    }

    /**
     * Создать столбец.
     *
     * @param width ширина столбца.
     * @param cells перечень ячеек столбца.
     * @return столбец.
     */
    public Column createColumn(double width, List<Cell> cells) {
        return new Column(width, cells);
    }


    // Методы расчета дерева графических элементов.

    /**
     * Инициализация графических элементов.
     */
    private void initBaseGraphElements() {
        IGroupGraphElement contour = new GroupGraphElement("Контур (перо, заливка)");
        this.initBaseContour(contour);

        // Порядок важен. Если требуется его поменять, то так же учесть новый порядок в методе calculate.
        graphElements.add(contour);
        graphElements.add(new GroupGraphElement("Строки (перо, заливка, текст)"));
        graphElements.add(new GroupGraphElement("Столбцы (перо, заливка, текст)"));
    }

    /**
     * Инициализация основных графических элементов контура.
     *
     * @param contour корневой графический элемент для контура.
     */
    private void initBaseContour(IGroupGraphElement contour) {
        contour.getElements().add(new GroupGraphElement("Левая граница"));
        contour.getElements().add(new GroupGraphElement("Правая граница"));
        contour.getElements().add(new GroupGraphElement("Верхняя граница"));
        contour.getElements().add(new GroupGraphElement("Нижняя граница"));
    }

    /**
     * Произвести рачеты.
     * <p> Производится расчет графического дерева.
     */
    public void calculate() {
        int cellVisible[] = this.calculateCellsVisible();

        // Очистка старых данных.
        provider.cleanOldSignUtils();

        this.calculateTableContour((IGroupGraphElement) graphElements.get(0), cellVisible);
        this.calculateRows((IGroupGraphElement) graphElements.get(1), cellVisible);
        this.calculateColumns((IGroupGraphElement) graphElements.get(2), cellVisible);
    }

    /**
     * Удалить старые данные.
     *
     * @param actualSignUtils актуальные даннык.
     * @param store           хранилище данных.
     */
    public static <R, GE> void removeOldSignUtils(List<R> actualSignUtils, Map<R, GE> store) {
        Set<R> oldSignUtils = new HashSet<R>();
        for (R row : store.keySet())
            if (!actualSignUtils.contains(row))
                oldSignUtils.add(row);
        store.keySet().removeAll(oldSignUtils);
    }

    /**
     * Расчитать дерево контура таблицы.
     *
     * @param tableContour корневой графический элемент дерева контура таблицы.
     * @param cellsVisible маркеры видимости ячеек.
     */
    private void calculateTableContour(IGroupGraphElement tableContour, int cellsVisible[]) {
        if (tableContour.getElements().size() < 4)
            throw new RuntimeException("Для расчета конутра требуются 4 дочерних гр. элемента: левая, правая, верхняя и нижняя границы.");

        if (rowCount == 0 || columnCount == 0)
            return;

        IGroupGraphElement leftLineGE = (IGroupGraphElement) tableContour.getElements().get(0);
        IGroupGraphElement rightLineGE = (IGroupGraphElement) tableContour.getElements().get(1);
        IGroupGraphElement topLineGE = (IGroupGraphElement) tableContour.getElements().get(2);
        IGroupGraphElement bottomLineGE = (IGroupGraphElement) tableContour.getElements().get(3);

        leftLineGE.getElements().clear();
        rightLineGE.getElements().clear();
        topLineGE.getElements().clear();
        bottomLineGE.getElements().clear();

        GraphElementProvider.CellGEProvider geProvider = provider.getCellGEProvider();

        // Левая граница.
        Column column = columns.get(0);
        int num = 1;
        for (Cell cell : column.getCells()) {
            IGraphElement lineGE = geProvider.getCellLeftInfoLineGE(cell);
            lineGE.setName("Левая граница ячейки " + num + ", " + 1);
            leftLineGE.getElements().add(lineGE);
            ++num;
        }

        // Правая граница
        column = columns.get(columns.size() - 1);
        num = 1;
        for (Cell cell : column.getCells()) {
            IGraphElement lineGE = geProvider.getCellRightInfoLineGE(cell);
            lineGE.setName("Правая граница ячейки " + num + ", " + (columns.size()));
            rightLineGE.getElements().add(lineGE);
            ++num;
        }

        // Верхняя граница
        Row row = rows.get(0);
        num = 1;
        for (Cell cell : row.getCells()) {
            IGraphElement lineGE = geProvider.getCellTopInfoLineGE(cell);
            lineGE.setName("Верхняя граница ячейки " + 1 + ", " + num);
            topLineGE.getElements().add(lineGE);
            ++num;
        }

        // Нижняя граница
        row = rows.get(rows.size() - 1);
        num = 1;
        for (Cell cell : row.getCells()) {
            IGraphElement lineGE = geProvider.getCellBottomInfoLineGE(cell);
            lineGE.setName("Нижняя граница ячейки " + rows.size() + ", " + num);
            bottomLineGE.getElements().add(lineGE);
            ++num;
        }

    }

    /**
     * Расчитать дерево графических элементов из столбцов.
     *
     * @param columnsGE    корневой графический элемент дерева графических элементов из столбцов.
     * @param cellsVisible видимость ячеек (Перекрытие).
     *                     <p> Используется при построении дерева графических элементов, предварительно вычисляется методом calculateCellVisible.
     *                     <p> Значение элемента массива в диапазоне[-n, 0] означает, что соответсвующая ячейка перекрыта ячейкой с индексом абсолютной величины значения элемента.
     *                     1 - означает, что ячейка не перекрыта.
     */
    private void calculateColumns(IGroupGraphElement columnsGE, final int cellsVisible[]) {
        columnsGE.getElements().clear();

        GraphElementProvider.ColumnGEProvider colGEProvider = provider.getColumnGEProvider();
        GraphElementProvider.CellGEProvider cellGEProvider = provider.getCellGEProvider();

        int num = 1;
        for (Column column : columns) {
            IGroupGraphElement columnGE = colGEProvider.getColumnGE(column); //new GroupGraphElement("Столбец " + num + " (перо, заливка, текст)");
            columnGE.setName("Столбец " + num + " (перо, заливка, текст)");
            columnGE.getElements().clear();

            // Контур столбца
            IGroupGraphElement conoturGE = colGEProvider.getColumnContourGE(column); //new GroupGraphElement("Контур");
            conoturGE.getElements().clear();

            // Дерево графичеких элементов контура строки
            Cell topCell = column.getCells().get(0);
            Cell bottomCell = column.getCells().get(column.getCells().size() - 1);
            IGraphElement topColLine = colGEProvider.getColumnTopLineGE(column); //new LineGraphElement(topCell.getTopPen(), null, null, false, false);
            IGraphElement bottomColLine = colGEProvider.getColumnBottomLineGE(column); //new LineGraphElement(bottomCell.getBottomPen(), null, null, false, false);
            IGroupGraphElement leftColLine = colGEProvider.getColumnLeftLineGE(column); //new GroupGraphElement("Левая граница");
            IGroupGraphElement rightColLine = colGEProvider.getColumnRightLineGE(column); //new GroupGraphElement("Правая граница");
            leftColLine.getElements().clear();
            rightColLine.getElements().clear();

            int cellIndex = 1;
            for (Cell cell : column.getCells()) {
                if (cellNotInColSpan(cell, cellsVisible)) {
                    IGraphElement lineGE = cellGEProvider.getCellLeftInfoLineGE(cell); //new LineGraphElement(cell.getLeftPen(), null, null, false, false);
                    lineGE.setName("Левая граница ячейки " + cellIndex + ", " + num);
                    leftColLine.getElements().add(lineGE);

                    lineGE = cellGEProvider.getCellRightInfoLineGE(cell); //new LineGraphElement(cell.getRightPen(), null, null, false, false);
                    lineGE.setName("Правая граница ячейки " + cellIndex + ", " + num);
                    rightColLine.getElements().add(lineGE);
                }
                ++cellIndex;
            }

            if (!leftColLine.getElements().isEmpty())
                conoturGE.getElements().add(leftColLine);

            if (!rightColLine.getElements().isEmpty())
                conoturGE.getElements().add(rightColLine);

            if (cellNotInColSpan(topCell, cellsVisible)) {
                conoturGE.getElements().add(topColLine);
                topColLine.setName("Верхняя граница");
            }

            if (cellNotInColSpan(bottomCell, cellsVisible)) {
                conoturGE.getElements().add(bottomColLine);
                bottomColLine.setName("Нижняя граница");
            }

            // Дерево графических элементов ячееки.
            IGroupGraphElement cellsGE = colGEProvider.getColumnCellsGE(column); // new GroupGraphElement("Ячейки (перо, заливка, текст)");
            cellsGE.getElements().clear();

            // Контур ячеек.
            IGroupGraphElement cellsContourGE = colGEProvider.getColumnCellsContour(column); // new GroupGraphElement("Контур (перо)");
            cellsContourGE.getElements().clear();

            IGroupGraphElement leftCellsContourGE = colGEProvider.getLeftCellsLinesGE(column); // new GroupGraphElement("Левая граница (перо)");
            IGroupGraphElement rightCellsContourGE = colGEProvider.getRightCellsLinesGE(column); // new GroupGraphElement("Правая граница (перо)");
            IGroupGraphElement topCellsContourGE = colGEProvider.getTopCellsLinesGE(column); // new GroupGraphElement("Верхняя граница (перо)");
            IGroupGraphElement bottomCellsContourGE = colGEProvider.getBottomCellsLinesGE(column); // new GroupGraphElement("Нижняя граница (перо)");
            leftCellsContourGE.getElements().clear();
            rightCellsContourGE.getElements().clear();
            topCellsContourGE.getElements().clear();
            bottomCellsContourGE.getElements().clear();

            this.calculateCellsLeftContourGraphElement(leftCellsContourGE, column.getCells());
            this.calculateCellsRightContourGraphElement(rightCellsContourGE, column.getCells());
            this.calculateCellsTopContourGraphElement(topCellsContourGE, column.getCells());
            this.calculateCellsBottomContourGraphElement(bottomCellsContourGE, column.getCells());

            cellsContourGE.getElements().add(leftCellsContourGE);
            cellsContourGE.getElements().add(rightCellsContourGE);
            cellsContourGE.getElements().add(topCellsContourGE);
            cellsContourGE.getElements().add(bottomCellsContourGE);

            cellsGE.getElements().add(cellsContourGE);

            for (Cell cell : column.getCells()) {
                IGroupGraphElement cellGE = this.calculateCellGraphElement(cell, cellsVisible);
                if (!cellsGE.getElements().contains(cellGE))
                    cellsGE.getElements().add(cellGE);
            }

            columnGE.getElements().add(conoturGE);
            columnGE.getElements().add(cellsGE);

            columnsGE.getElements().add(columnGE);

            ++num;
        }
    }

    /**
     * Проверить является ли ячейка частью объединения ячеек по горизонтали.
     *
     * @param cell    ячейка.
     * @param visible массив маркеров с перекрытием ячеек.
     * @return true - ячейка является частью объединения ячеек по горизонтали; false - иначе.
     */
    private boolean cellNotInColSpan(Cell cell, int visible[]) {
        int cellIndex = cells.indexOf(cell);
        if (visible[cellIndex] <= 0) {
            Cell spanCell = cells.get(Math.abs(visible[cellIndex]));
            if (spanCell.getColSpan() == 1)
                return true;
        } else if (cell.getColSpan() == 1)
            return true;

        return false;
    }

    /**
     * Расчитать дерево графических элементов из строк.
     *
     * @param rowsGE       корневой графический элемент дерева графических элементов.
     * @param cellsVisible видимость ячеек (Перекрытие).
     *                     <p> Используется при построении дерева графических элементов, предварительно вычисляется методом calculateCellVisible.
     *                     <p> Значение элемента массива в диапазоне[-n, 0] означает, что соответсвующая ячейка перекрыта ячейкой с индексом абсолютной величины значения элемента.
     *                     1 - означает, что ячейка не перекрыта.
     */
    private void calculateRows(IGroupGraphElement rowsGE, int cellsVisible[]) {
        rowsGE.getElements().clear();

        GraphElementProvider.RowGEProvider rowGEProvider = provider.getRowGEProvider();
        GraphElementProvider.CellGEProvider cellGEProvider = provider.getCellGEProvider();

        int num = 1;
        for (Row row : rows) {
            IGroupGraphElement rowGE = rowGEProvider.getRowGE(row);
            rowGE.setName("Строка " + num + " (перо, заливка, текст)");
            rowGE.getElements().clear();

            // Дерево графичеких элементов контура строки.
            IGroupGraphElement contourGE = rowGEProvider.getRowContourGE(row);
            contourGE.getElements().clear();

            Cell leftCell = row.getCells().get(0);
            Cell rightCell = row.getCells().get(row.getCells().size() - 1);

            rowGEProvider.getRowLeftLineGE(row).setName("Левая граница");
            rowGEProvider.getRowRightLineGE(row).setName("Правая граница");

            IGroupGraphElement topRowLine = rowGEProvider.getRowTopLineGE(row);
            topRowLine.getElements().clear();

            IGroupGraphElement bottomRowLine = rowGEProvider.getRowBottomLineGE(row);
            bottomRowLine.getElements().clear();

            int cellIndex = 1;
            for (Cell cell : row.getCells()) {
                if (cellNotInRowSpan(cell, cellsVisible)) {
                    IGraphElement lineGE = cellGEProvider.getCellTopInfoLineGE(cell);
                    lineGE.setName("Верхняя граница ячейки " + num + ", " + cellIndex);
                    topRowLine.getElements().add(lineGE);

                    lineGE = cellGEProvider.getCellBottomInfoLineGE(cell);
                    lineGE.setName("Нижняя граница ячейки " + num + ", " + cellIndex);
                    bottomRowLine.getElements().add(lineGE);
                }
                ++cellIndex;
            }

            if (cellNotInRowSpan(leftCell, cellsVisible))
                contourGE.getElements().add(rowGEProvider.getRowLeftLineGE(row));
//				contourGE.getElements().add(provider.getCellLeftLineGE(leftCell));

            if (cellNotInRowSpan(rightCell, cellsVisible))
                contourGE.getElements().add(rowGEProvider.getRowRightLineGE(row));
//				contourGE.getElements().add(provider.getCellRightLineGE(rightCell));

            if (!topRowLine.getElements().isEmpty())
                contourGE.getElements().add(topRowLine);

            if (!bottomRowLine.getElements().isEmpty())
                contourGE.getElements().add(bottomRowLine);

            // Дерево графических элементов ячеек.
            IGroupGraphElement cellsGE = rowGEProvider.getRowCellsGE(row);
            cellsGE.getElements().clear();
            // Контур ячеек.
            IGroupGraphElement cellsContourGE = rowGEProvider.getRowCellsContour(row);//new GroupGraphElement("Контур (перо)");
            cellsContourGE.getElements().clear();

            IGroupGraphElement leftCellsContourGE = rowGEProvider.getLeftCellsLinesGE(row); //new GroupGraphElement("Левая граница (перо)");
            IGroupGraphElement rightCellsContourGE = rowGEProvider.getRightCellsLinesGE(row); //new GroupGraphElement("Правая граница (перо)");
            IGroupGraphElement topCellsContourGE = rowGEProvider.getTopCellsLinesGE(row); //new GroupGraphElement("Верхняя граница (перо)");
            IGroupGraphElement bottomCellsContourGE = rowGEProvider.getBottomCellsLinesGE(row); //new GroupGraphElement("Нижняя граница (перо)");
            leftCellsContourGE.getElements().clear();
            rightCellsContourGE.getElements().clear();
            topCellsContourGE.getElements().clear();
            bottomCellsContourGE.getElements().clear();

            this.calculateCellsLeftContourGraphElement(leftCellsContourGE, row.getCells());
            this.calculateCellsRightContourGraphElement(rightCellsContourGE, row.getCells());
            this.calculateCellsTopContourGraphElement(topCellsContourGE, row.getCells());
            this.calculateCellsBottomContourGraphElement(bottomCellsContourGE, row.getCells());

            cellsContourGE.getElements().add(leftCellsContourGE);
            cellsContourGE.getElements().add(rightCellsContourGE);
            cellsContourGE.getElements().add(topCellsContourGE);
            cellsContourGE.getElements().add(bottomCellsContourGE);

            cellsGE.getElements().add(cellsContourGE);

            for (Cell cell : row.getCells()) {
                IGroupGraphElement cellGE = this.calculateCellGraphElement(cell, cellsVisible);
                if (!cellsGE.getElements().contains(cellGE))
                    cellsGE.getElements().add(cellGE);
            }

            rowGE.getElements().add(contourGE);
            rowGE.getElements().add(cellsGE);

            rowsGE.getElements().add(rowGE);

            ++num;
        }
    }

    /**
     * Проверить является ли ячейка частью объединения ячеек по вертикали.
     *
     * @param cell    ячейка.
     * @param visible массив маркеров с перекрытием ячеек.
     * @return true - ячейка является частью объединения ячеек по вертикали; false - иначе.
     */
    private boolean cellNotInRowSpan(Cell cell, int visible[]) {
        int cellIndex = cells.indexOf(cell);
        if (visible[cellIndex] <= 0) {
            Cell spanCell = cells.get(Math.abs(visible[cellIndex]));
            if (spanCell.getRowSpan() == 1)
                return true;
        } else if (cell.getRowSpan() == 1)
            return true;

        return false;
    }

    /**
     * Расчитать графический элемент - контур левых границ перечня ячеек.
     *
     * @param leftContourCellGE графический элемент.
     * @param cells             перечень ячеек.
     */
    void calculateCellsLeftContourGraphElement(IGroupGraphElement leftContourCellGE, List<Cell> cells) {
        GraphElementProvider.CellGEProvider cellGEProvider = provider.getCellGEProvider();

        for (Cell cell : cells) {
            int cellIndex = this.cells.indexOf(cell);
            int rowIndex = cellIndex / columnCount + 1;
            int colIndex = cellIndex % columnCount + 1;

            IGraphElement leftLineGE = cellGEProvider.getCellLeftInfoLineGE(cell);//new LineGraphElement(cell.getLeftPen(), null, null, false, false);
            leftLineGE.setName("Левая граница ячейки " + rowIndex + ", " + colIndex + "(перо)");
            leftContourCellGE.getElements().add(leftLineGE);
        }
    }

    /**
     * Расчитать графический элемент - контур правых границ перечня ячеек.
     *
     * @param rightContourCellGE графический элемент.
     * @param cells              перечень ячеек.
     */
    void calculateCellsRightContourGraphElement(IGroupGraphElement rightContourCellGE, List<Cell> cells) {
        GraphElementProvider.CellGEProvider cellGEProvider = provider.getCellGEProvider();

        for (Cell cell : cells) {
            int cellIndex = this.cells.indexOf(cell);
            int rowIndex = cellIndex / columnCount + 1;
            int colIndex = cellIndex % columnCount + 1;

            IGraphElement rightLineGE = cellGEProvider.getCellRightInfoLineGE(cell);//new LineGraphElement(cell.getRightPen(), null, null, false, false);
            rightLineGE.setName("Правая граница ячейки " + rowIndex + ", " + colIndex + "(перо)");
            rightContourCellGE.getElements().add(rightLineGE);
        }
    }

    /**
     * Расчитать графический элемент - контур верхних границ перечня ячеек.
     *
     * @param topContourCellGE графический элемент.
     * @param cells            перечень ячеек.
     */
    void calculateCellsTopContourGraphElement(IGroupGraphElement topContourCellGE, List<Cell> cells) {
        GraphElementProvider.CellGEProvider cellGEProvider = provider.getCellGEProvider();

        for (Cell cell : cells) {
            int cellIndex = this.cells.indexOf(cell);
            int rowIndex = cellIndex / columnCount + 1;
            int colIndex = cellIndex % columnCount + 1;

            IGraphElement topLineGE = cellGEProvider.getCellTopInfoLineGE(cell); //new LineGraphElement(cell.getTopPen(), null, null, false, false);
            topLineGE.setName("Верхняя граница ячейки " + rowIndex + ", " + colIndex + "(перо)");
            topContourCellGE.getElements().add(topLineGE);
        }
    }

    /**
     * Расчитать графический элемент - контур нижних границ перечня ячеек.
     *
     * @param bottomContourCellGE графический элемент.
     * @param cells               перечень ячеек.
     */
    void calculateCellsBottomContourGraphElement(IGroupGraphElement bottomContourCellGE, List<Cell> cells) {
        GraphElementProvider.CellGEProvider cellGEProvider = provider.getCellGEProvider();

        for (Cell cell : cells) {
            int cellIndex = this.cells.indexOf(cell);
            int rowIndex = cellIndex / columnCount + 1;
            int colIndex = cellIndex % columnCount + 1;

            IGraphElement bottomLineGE = cellGEProvider.getCellBottomInfoLineGE(cell); //new LineGraphElement(cell.getBottomPen(), null, null, false, false);
            bottomLineGE.setName("Нижняя граница ячейки " + rowIndex + ", " + colIndex + "(перо)");
            bottomContourCellGE.getElements().add(bottomLineGE);
        }
    }

    /**
     * Расчитать дерево графических элементов ячейки.
     *
     * @param cell         ячейка.
     * @param cellsVisible видимость ячеек.
     * @return корневой элемент графических элементов ячейки.
     */
    private IGroupGraphElement calculateCellGraphElement(Cell cell, int cellsVisible[]) {
        IGroupGraphElement cellGE;

        int globalCellIndex = -1;

        if (cellsVisible[cells.indexOf(cell)] <= 0) {
            globalCellIndex = Math.abs(cellsVisible[cells.indexOf(cell)]);
            cellGE = new CellSpanGraphElement(globalCellIndex);

        } else if (isSpanCell(cell)) {
            globalCellIndex = cells.indexOf(cell);
            cellGE = new CellSpanGraphElement(globalCellIndex);

        } else {
            GraphElementProvider.CellGEProvider cellGEProvider = provider.getCellGEProvider();

            globalCellIndex = cells.indexOf(cell);
            int rowIndex = globalCellIndex / columnCount + 1;
            int colIndex = globalCellIndex % columnCount + 1;

            cellGE = new CellGraphElement(cell);
            cellGE.setName("Ячейка " + rowIndex + ", " + colIndex + " (перо, заливка, текст)");

            IGroupGraphElement cellContourGE = new GroupGraphElement("Контур");

            IGraphElement leftLineGE = cellGEProvider.getCellLeftLineGE(cell);//new LineGraphElement(cell.getLeftPen(), null, null, false, false);
//			leftLineGE.setName("Левая граница (перо)");
            IGraphElement rightLineGE = cellGEProvider.getCellRightLineGE(cell); //new LineGraphElement(cell.getRightPen(), null, null, false, false);
//			rightLineGE.setName("Правая граница (перо)");
            IGraphElement topLineGE = cellGEProvider.getCellTopLineGE(cell); //new LineGraphElement(cell.getTopPen(), null, null, false, false);
//			topLineGE.setName("Верхняя граница (перо)");
            IGraphElement bottomtLineGE = cellGEProvider.getCellBottomLineGE(cell); //new LineGraphElement(cell.getBottomPen(), null, null, false, false);
//			bottomtLineGE.setName("Нижняя граница (перо)");

            cellContourGE.getElements().add(leftLineGE);
            cellContourGE.getElements().add(rightLineGE);
            cellContourGE.getElements().add(topLineGE);
            cellContourGE.getElements().add(bottomtLineGE);

            cellGE.getElements().add(cellContourGE);
        }

        if (globalCellIndex >= 0) {
            ICellContent content = cells.get(globalCellIndex).getCellContent();
            if (content != null) {
                cellGE.getElements().add(content.getGraphElement());
                cellGE.setId("c" + content.getId());
            }
        }

        return cellGE;
    }

    /**
     * Расчитать перекрытые ячейки.
     *
     * @return целочисленный массив.
     * <p> Значение элемента массива в диапазоне[-n, 0] означает, что соответствующая ячейка перекрыта ячейкой с индексом абсолютной величины значения элемента.
     * 1 - означает, что ячейка не перекрыта.
     */
    //TODO ? Компонент управления геометрии.
    public int[] calculateCellsVisible() {
        int cellVisibles[] = new int[cells.size()];
        for (int i = 0; i < cells.size(); ++i)
            cellVisibles[i] = 1;

        for (int i = 0; i < cells.size(); ++i) {
            Cell cell = cells.get(i);
            int cellColumn = i % columns.size();
            int cellRow = i / columns.size();

            if (cellVisibles[i] > 0 && isSpanCell(cell)) {
                // Метки на перекрытые ячейки.
                for (int j = 0; j <= cell.getColSpan() - 1 && cellColumn + j < columnCount; ++j)
                    for (int k = 0; k <= cell.getRowSpan() - 1 && cellRow + k < rowCount; ++k)
                        cellVisibles[i + j + k * columnCount] = -i;

                for (int j = 0; j <= cell.getRowSpan() - 1 && cellRow + j < rowCount; ++j)
                    for (int k = 0; k <= cell.getColSpan() - 1 && cellColumn + k < columnCount; ++k)
                        cellVisibles[i + j * columnCount + k] = -i;

                cellVisibles[i] = 1;
            }
        }

        return cellVisibles;
    }

    /**
     * Покрывает ли заданная ячейка какие-либо другие ячейки.
     *
     * @param cell ячейка.
     * @return true - ячейка покрывает другие, false - ячейка не покрывает другие ячейки.
     */
    private boolean isSpanCell(Cell cell) {
        if (cell.getRowSpan() > 1 || cell.getColSpan() > 1)
            return true;

        return false;
    }


    // Методы добавления/удаления строк, столбцов.

    /**
     * Добавить строку.
     * <p> Строка добавляется только в виде ячеек.
     * После проделанной операции необходимо сформировать строку
     * на основе добавленных ячеек и добавить её в перечень строк.
     *
     * @param index индекс для добавления.
     * @param row   строка.
     */
    void addRow(int index, Row row) {
        ++rowCount;

        index = index * columnCount;

        // Если добавляемая строка == null, то добавляем пустую строку.
        if (row == null) {
            // Если в таблицы не было до этого ячеек, то добавляется одна ячейка.
            if (columnCount == 0)
                ++columnCount;

            for (int i = 0; i < columnCount; ++i, ++index)
                this.cells.add(index, new Cell());

        } else {
            if (columnCount == 0)
                columnCount = row.getCells().size();

            Iterator<Cell> it = row.getCells().iterator();

            // Если добавляемая строка содержит достаточное количество ячеек, то копируем их данные в новой строке.
            if (row.getCells().size() >= columnCount)
                for (int i = 0; i < columnCount; ++i, ++index)
                    this.cells.add(index, new Cell(it.next()));
            else {
                // Если входная строка содержит недостаточное количество ячеек, то оставшиеся заполняются по укмолчанию.
                while (it.hasNext()) {
                    this.cells.add(index, new Cell(it.next()));
                    ++index;
                }

                while (index % columnCount != 0) {
                    this.cells.add(index, new Cell());
                    ++index;
                }
            }
        }

        correctCellPens();
        // Так же необходимо обновить перечень ячеек для столбцов.
        reInitColumns();
    }

    /**
     * Добавить строку в конец таблицы.
     * <p> Строка добавляется только в виде ячеек.
     * После проделанной операции необходимо сформировать строку
     * на основе добавленных ячеек и добавить её в перечень строк.
     *
     * @param row строка.
     */
    void addRow(Row row) {
        this.addRow(rowCount, row);
    }

    /**
     * Удалить строку.
     *
     * @param index индекс строки.
     */
    void removeRow(int index) {
        --rowCount;

        for (int i = 0; i < columnCount; ++i)
            cells.remove(index * columnCount);

        if (cells.isEmpty())
            columnCount = 0;

        correctCellPens();
        reInitColumns();
    }

    /**
     * Добавить столбец.
     * <p> Столбец добавляется только в виде ячеек.
     * После проделанной операции необходимо сформировать столбец ({@link Column})
     * на основе добавленных ячеек и добавить его в перечень столбцов {@link  TableSignVisual#columns}.
     *
     * @param column столбец.
     */
    void addColumn(Column column) {
        this.addColumn(columnCount, column);
    }

    /**
     * Добавить столбец по индексу.
     * <p> Столбец добавляется только в виде ячеек.
     * После проделанной операции необходимо сформировать столбец ({@link Column})
     * на основе добавленных ячеек и добавить его в перечень столбцов {@link  TableSignVisual#columns}.
     *
     * @param index  индекс колонки.
     * @param column колонка.
     */
    void addColumn(int index, Column column) {
        ++columnCount;

        // Если добавляемая строка == null, то добавляем пустую строку.
        if (column == null) {
            // Если в таблице до этого не было ячеек.
            if (rowCount == 0)
                ++rowCount;

            for (int i = 0; i < rowCount; ++i)
                this.cells.add(index + i * columnCount, new Cell());

        } else {
            // Если в таблице до этого не было ячеек.
            if (rowCount == 0)
                rowCount = column.getCells().size();

            Iterator<Cell> it = column.getCells().iterator();

            // Если добавляемая колонка содержит достаточное количество ячеек, то копируем их данные в новой строке.
            if (column.getCells().size() >= rowCount)
                for (int i = 0; i < rowCount; ++i)
                    this.cells.add(index + i * columnCount, new Cell(it.next()));
            else {
                // Если входная колонка содержит недостаточное количество ячеек, то оставшиеся заполняются по умолчанию.
                int i = 0;
                while (it.hasNext()) {
                    this.cells.add(index + i * columnCount, new Cell(it.next()));
                    ++i;
                }

                int defCellCount = rowCount - column.getCells().size();
                while (defCellCount > 0) {
                    this.cells.add(index + i * columnCount, new Cell());
                    ++i;
                    --defCellCount;
                }
            }
        }

        correctCellPens();
        // Обновление перечня ячеек для строк.
        reInitRows();
    }

    /**
     * Удалить колонку.
     *
     * @param index индекс колонки.
     */
    void removeColumn(int index) {
        for (int i = rowCount - 1; i >= 0; --i)
            cells.remove(columnCount * i + index);

        --columnCount;

        if (cells.isEmpty())
            rowCount = 0;

        correctCellPens();
        reInitRows();
    }

    /**
     * Очистить таблицу.
     * <p> Удаление всех ячеек таблицы.
     */
    void clear() {
        columnCount = 0;
        rowCount = 0;
        cells.clear();
        calculate();
    }

    /**
     * Переинициализация столбцов {@link  TableSignVisual#columns}.
     * <p> Формирует перечень столбцов на основе текущего перечня ячеек {@link  TableSignVisual#cells}.
     */
    void reInitColumns() {
        // Сохранение размеров колонок.
        List<Double> widths = new ArrayList<Double>();
        for (Column col : columns)
            widths.add(col.getWidth());

        // Инициализация колонок.
        columns = new Columns();
        for (int i = 0; i < columnCount; ++i) {
            List<Cell> listCells = new ArrayList<Cell>();
            for (int j = 0; j < rowCount; ++j)
                listCells.add(cells.get(i + j * columnCount));

            double colWidth = DEFAULT_COLUMN_WIDTH;
            if (i < widths.size())
                colWidth = widths.get(i);

            this.columns.cColumns.add(new Column(colWidth, listCells));
        }
    }

    /**
     * Переинициализация строк {@link  TableSignVisual#rows}.
     * <p> Формирует перечень строк на основе текущего перечня ячеек {@link TableSignVisual#cells}.
     */
    void reInitRows() {
        // Сохранение размеров строк.
        List<Double> heights = new ArrayList<Double>();
        for (Row row : rows)
            heights.add(row.getHeight());

        // Инициализация строк.
        rows = new Rows();
        for (int i = 0; i < rowCount; ++i) {
            List<Cell> listCells = new ArrayList<Cell>();
            for (int j = 0; j < columnCount; ++j)
                listCells.add(cells.get(i * columnCount + j));

            double rowHeight = DEFAULT_ROW_HEIGHT;
            if (i < heights.size())
                rowHeight = heights.get(i);

            this.rows.rRows.add(new Row(rowHeight, listCells));
        }
    }

    /**
     * Корректировка перьев ячеек {@link  TableSignVisual#cells}.
     */
    private void correctCellPens() {
        for (int i = 0; i < cells.size(); ++i) {
            if (i % columnCount > 0)
                cells.get(i).setLeftPen(cells.get(i - 1).getRightPen());

            if (i >= columnCount)
                cells.get(i).setTopPen(cells.get(i - columnCount).getBottomPen());
        }
    }

    /**
     * Получить ячейку таблицы по точке.
     *
     * @param point точка.
     *              <p> точка имеет координаты в мм документа.
     * @return ячейка таблицы, null - если ячейку не удалось найти по заданным координатам.
     */
    //TODO ? Компонент управления геометрии.
    public Cell getCellByPoint(BasePoint2D point) {
        BasePoint2D tableLTPoint = this.getAnchorPoints().get(0).getPoint();
        // Локальная координата мыши с учетом угла поворота.
        point = new BasePoint2D(point).rotate(-getAngle(), tableLTPoint).sub(tableLTPoint);

        BasePoint2D scale = getScale();
        double tWidth = 0;
        double tHeight = 0;
        for (Column column : getColumns()) {
            tWidth += column.getWidth() * scale.getX();
        }
        for (Row row : getRows()) {
            tHeight += row.getHeight() * scale.getY();
        }
        if (point.getX() < 0 || tWidth < point.getX() || point.getY() < 0 || tHeight < point.getY()) {
            return null;
        }

        int horizontal = 0;
        double width = point.getX();

        for (Column column : getColumns()) {
            if (width > column.getWidth() * scale.getX()) {
                width -= column.getWidth() * scale.getX();
                ++horizontal;
            } else {
                break;
            }
        }

        int vertical = 0;
        double height = point.getY();

        for (Row row : getRows()) {
            if (height > row.getHeight() * scale.getY()) {
                height -= row.getHeight() * scale.getY();
                ++vertical;
            } else {
                break;
            }
        }

        Cell cell = getRows().get(vertical).getCells().get(horizontal);
        Cell coveringCell = getCoveringCell(cell, this);

        return coveringCell != null ? coveringCell : cell;

    }

    /**
     * Получить ячейку, перекрывающую заданную.
     *
     * @param cell            ячейка, для которой анализируется перекрытость.
     * @param tableSignVisual визуальное представление таблицы.
     *                        <p> Не может = null. При = null выкидывает исключение.
     * @return ячейка, которая перекрывает заданную, null - если заданная ячейка не перекрыта какой-либо другой.
     */
    private Cell getCoveringCell(Cell cell, TableSignVisual tableSignVisual) {
        if (cell == null)
            throw new IllegalArgumentException("cell == null");

        // Формирование сквозного перечня ячеек таблицы.
        List<Cell> cells = new ArrayList<Cell>();
        for (Row row : tableSignVisual.getRows())
            for (Cell tmpCell : row.getCells())
                cells.add(tmpCell);

        // Вычисление видимости/перекрытия ячеек.
        int cellVisibles[] = tableSignVisual.calculateCellsVisible();
        int cellIndex = cells.indexOf(cell);

        if (cellVisibles[cellIndex] <= 0)
            return cells.get(Math.abs(cellVisibles[cellIndex]));

        return null;
    }

    @Override
    public void createDefaultSemantics(int index, IAnchorPoint anchorPoint) {
    }

}