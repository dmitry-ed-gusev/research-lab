package vg.sign.visual.api;

/**
 * Шаблонный сердечник пера.
 *
 */
public interface IPatternPenCore extends IPenCore {

    /**
     * Получить шаблон.
     *
     * @return Шаблон.
     */
    public IPenPattern getPattern();

    /**
     * Задать шаблон.
     *
     * @param pattern Шаблон.
     */
    public void setPattern(IPenPattern pattern);

}
