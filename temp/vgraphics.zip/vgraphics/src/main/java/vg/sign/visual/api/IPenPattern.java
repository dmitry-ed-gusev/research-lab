package vg.sign.visual.api;

import vg.geometry.primitives.BasePoint2D;

import java.util.List;

/**
 * Шаблон пера.
 *
 */
public interface IPenPattern extends Cloneable {

    /**
     * Элемент шаблона пера.
     * <p>Представляет собой отрезок в относительных по ширине шаблона единицах.
     * Т.е. x=0 - начало шаблона на линии, x=1 - конец шаблона,
     * x=-0.5 - пол-ширины шаблона назад по линии, x=1,5 - заход на следующий шаблон на пол-ширины.
     *
     */
    public interface IElement extends Cloneable {
        /**
         * Клонирование.
         *
         * @return Клон.
         */
        IElement clone();

        /**
         * Получить точки.
         *
         * @return Точки.
         */
        public BasePoint2D[] getPoints();

        /**
         * Задать точки.
         *
         * @param points Точки.
         */
        public void setPoints(BasePoint2D[] points);

        /**
         * Получить флаг залитости.
         *
         * @return Флаг залитости.
         */
        public boolean getFilled();

        /**
         * Задать флаг залитости.
         *
         * @param filled Флаг залитости.
         */
        public void setFilled(boolean filled);

        /**
         * Получить наличие начальной стрелки.
         *
         * @return Наличие начальной стрелки.
         */
        public boolean hasBeginArrow();

        /**
         * Задать наличие начальной стрелки.
         *
         * @param exists Наличие начальной стрелки.
         */
        public void setBeginArrow(boolean exists);

        /**
         * Получить наличие конечной стрелки.
         *
         * @return Наличие конечной стрелки.
         */
        public boolean hasEndArrow();

        /**
         * Задать наличие конечной стрелки.
         *
         * @param exists Наличие конечной стрелки.
         */
        public void setEndArrow(boolean exists);

    }


    /**
     * Клонирование.
     *
     * @return Клон.
     */
    public IPenPattern clone();

    /**
     * Получить список элементов шаблона.
     *
     * @return Список элементов шаблона.
     */
    public List<IElement> getElements();

    /**
     * Получить размер.
     *
     * @return Размер.
     */
    public double getSize();

    /**
     * Задать размер.
     *
     * @param size Размер.
     */
    public void setSize(double size);

    /**
     * Получить множитель размера.
     *
     * @return Множитель размера.
     */
    public double getScale();

    /**
     * Задать множитель размера.
     *
     * @param factor Множитель размера.
     */
    public void setScale(double factor);

}
