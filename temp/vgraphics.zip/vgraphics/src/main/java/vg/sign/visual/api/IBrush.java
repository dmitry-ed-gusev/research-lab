package vg.sign.visual.api;

import java.util.List;

/**
 * Заливка.
 *
 */
public interface IBrush extends Cloneable {

    /**
     * Интерфейс перечня элементов кисти.
     *
     * @author Giller
     */
    public interface IBrushElementsList extends List<IBrushElement> {

        /**
         * Получить редактируемость перечня элементов кисти.
         *
         * @return редактируемость перечня элементов кисти.
         */
        public boolean isEditable();
    }


    /**
     * Клонирование.
     *
     * @return Клон.
     */
    IBrush clone();

    /**
     * Получить список элементов заливки.
     *
     * @return Список элементов заливки.
     */
    public IBrushElementsList getElements();
//	public List<IBrushElement> getElements();

}
