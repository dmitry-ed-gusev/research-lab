package vg.sign.building.api;

import vg.draw.vobject.VGObject;

import java.util.Map;

/**
 * Групповое векторное изображение.
 */
public interface IGroupSignImage extends VGObject {

    /**
     * Получить карту дочерних векторных изображений по идетификатору визуального представления.
     * "Идентификатор визуального представления" - "Векторное изображение".
     *
     * @return карта дочерних векторных изображений по идетификатору визуального представления.
     */
    public Map<String, VGObject> getChildrenImages();

}
