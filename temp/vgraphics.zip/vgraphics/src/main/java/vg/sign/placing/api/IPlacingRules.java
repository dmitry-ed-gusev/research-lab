package vg.sign.placing.api;

import vg.SignDefaults;

import java.util.Set;


/**
 * Правила нанесения.
 */
public interface IPlacingRules extends Cloneable {

    /**
     * Получить минимальное количество точек.
     *
     * @return Минимальное количество точек.
     */
    public int getMinAnchorPointCount();

    /**
     * Задать минимальное количество точек.
     *
     * @param minAnchorPointCount Минимальное количество точек.
     */
    public void setMinAnchorPointCount(int minAnchorPointCount);

    /**
     * Получить максимальное количесвто точек.
     *
     * @return Максимальное количество точек.
     */
    public int getMaxAnchorPointCount();

    /**
     * Задать максимальное количесвто точек.
     *
     * @param maxAnchorPointCount Максимальное количество точек.
     */
    public void setMaxAnchorPointCount(int maxAnchorPointCount);

    /**
     * Получить фигуры нанесения.
     *
     * @return Фигуры нанесения.
     */
    public Set<SignDefaults.PlacingFigure> getFigures();

    /**
     * Клонировать объект.
     *
     * @return Клон.
     */
    public IPlacingRules clone();

}
