package vg.sign.visual.api;

/**
 * Графический элемент окружности (эллипса, дуги).
 *
 */
public interface ICircleGraphElement extends ILineGraphElement {

    @Override
    public ICircleGraphElement clone();

    /**
     * Получить начальный угол дуги (относительно угла первого радиуса).
     *
     * @return Начальный угол дуги (относительно угла первого радиуса).
     */
    public double getBeginAngle();

    /**
     * Задать начальный угол дуги (относительно угла первого радиуса).
     *
     * @param beginAngle Начальный угол дуги (относительно угла первого радиуса).
     */
    public void setBeginAngle(double beginAngle);

    /**
     * Получить конечный угол дуги (относительно угла первого радиуса).
     *
     * @return Конечный угол дуги (относительно угла первого радиуса).
     */
    public double getEndAngle();

    /**
     * Задать конечный угол дуги (относительно угла первого радиуса).
     *
     * @param endAngle Конечный угол дуги (относительно угла первого радиуса).
     */
    public void setEndAngle(double endAngle);

}
