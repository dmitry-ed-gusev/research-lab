package vg.sign.core;

import vg.draw.vobject.VGObject;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.building.api.IGroupGraphBuilder;
import vg.sign.building.api.IGroupSignImage;
import vg.sign.core.api.IGroupSign;
import vg.sign.core.api.ISign;
import vg.sign.visual.api.IGroupSignVisual;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Групповой знак.
 */
public class GroupSign extends Sign implements IGroupSign {

    /**
     * Дочерние знаки.
     */
    private List<ISign> children = new ArrayList<ISign>();


    /**
     * Конструктор по умолчанию.
     */
    public GroupSign() {
        super();
    }

    /**
     * @param visual Визуальное представление Знака.
     */
    public GroupSign(IGroupSignVisual visual) {
        super(visual);
    }


    @Override
    public GroupSign clone() {
        GroupSign clonedObject = (GroupSign) super.clone();

        IGroupSignVisual signVisual = clonedObject.getVisual();

        clonedObject.children = new ArrayList<ISign>();
        for (int i = 0, n = signVisual.getChildren().size(); i < n; i++) {
            ISign childSign = children.get(i).clone();
            clonedObject.children.add(childSign);
            signVisual.getChildren().get(i).setSignVisual(childSign.getVisual());
        }

        return clonedObject;
    }


    @Override
    public IGroupSignVisual getVisual() {
        return (IGroupSignVisual) visual;
    }

    @Override
    public List<ISign> getChildren() {
        return children;
    }

    @Override
    public IGroupGraphBuilder getBuilder() {
        return (IGroupGraphBuilder) super.getBuilder();
    }


    @Override
    public void calculate() {
        // todo: tmp comment!!!
        /*
        if (visual instanceof LeaderSignVisual)
            ((LeaderSignVisual) visual).calculate();

        else if (visual instanceof ILinkingLineSignVisual)
            ((ILinkingLineSignVisual) visual).calculate();
        */

        IGroupGraphBuilder builder = getBuilder();
        for (ISign sign : children) {
            sign.calculate();
            builder.getChildren().put(sign.getVisual().getId(), sign.getBuilder());
        }
        super.calculate();
    }

    @Override
    public ISign getChild(BasePoint2D point, double delta) {
//		double delta = 0.0;

        // Анализ попадания точки внутри группового знака.
        if (getVisual() instanceof IGroupSignVisual) {
            Map<String, VGObject> childrenMap = ((IGroupSignImage) getImage()).getChildrenImages();

            // Проход по всем векторным изображениям.
            for (String key : childrenMap.keySet())
                // Если векторное изображение захватывает исходную точку.
                if (childrenMap.get(key).containsPoint(point, delta))
                    // Определяется дочерний знак с исходным векторным изображением по идентификатору.
                    for (ISign sign : getChildren())
                        if (key.equals(sign.getVisual().getId()))
                            return sign;
        }

        return null;
    }


    /**
     * Разделение знака на составляющие.
     * <p>При разделении в список сначала попадает sign, затем, если он групповой, его дочерние знаки со своими дочерними знаками.
     * Т.е. реализуется рекурсивный обход дерева.
     * <p>При разделении группового знака из него удаляются дочерние элементы,
     * а в элементах IChild его визуального представления зануляются ссылки на дочерние визуальные представления,
     * при этом сами IChild остаются в визуальном представлении (это нужно для восстановления).
     *
     * @param sign Разделяемый знак.
     * @return Список знаков, образовывавших дерево группового знака.
     */
    public static List<ISign> splitSign(ISign sign) {
        List<ISign> splittedSigns = new ArrayList<ISign>();
        return splitSign(splittedSigns, sign);
    }

    /**
     * Разделение знака на составляющие.
     *
     * @param splittedSigns Список составных частей.
     *                      Если null, то будет создан новый список.
     *                      Этот список и возвращается из метода.
     * @param sign          Разделяемый знак.
     * @return Список составных частей.
     * Возвращается splittedSigns.
     */
    private static List<ISign> splitSign(List<ISign> splittedSigns, ISign sign) {
        splittedSigns.add(sign);

        if (!(sign instanceof IGroupSign)) return splittedSigns;

        IGroupSign groupSign = (IGroupSign) sign;

        Iterator<ISign> signChildrenIterator = groupSign.getChildren().iterator();
        Iterator<IGroupSignVisual.IChild> visualChildrenIterator = groupSign.getVisual().getChildren().iterator();

        while (visualChildrenIterator.hasNext()) {
            ISign signChild = signChildrenIterator.next();
            splitSign(splittedSigns, signChild);
            IGroupSignVisual.IChild visualChild = visualChildrenIterator.next();
            visualChild.setSignVisual(null);
        }
        groupSign.getChildren().clear();

        return splittedSigns;
    }

    /**
     * Соединение ранее разделённого знака.
     * <p>Собирает обратно ранее разделённый методом {@link #splitSign(ISign)} знак.
     *
     * @param splittedSigns Список составных частей дерева группового знака.
     * @return Собранный из составных частей знак.
     */
    public static ISign joinSign(List<ISign> splittedSigns) {
        return joinSign(splittedSigns.iterator());
    }

    /**
     * Соединение ранее разделённого знака.
     *
     * @param splittedSignsIterator Итератор по списку составных частей.
     * @return Собранный из составных частей знак.
     */
    private static ISign joinSign(Iterator<ISign> splittedSignsIterator) {
        ISign sign = splittedSignsIterator.next();

        if (!(sign instanceof IGroupSign)) return sign;

        IGroupSign groupSign = (IGroupSign) sign;

        List<ISign> signChildren = groupSign.getChildren();
        Iterator<IGroupSignVisual.IChild> visualChildrenIterator = groupSign.getVisual().getChildren().iterator();

        while (visualChildrenIterator.hasNext()) {
            ISign signChild = joinSign(splittedSignsIterator);
            signChildren.add(signChild);
            IGroupSignVisual.IChild visualChild = visualChildrenIterator.next();
            visualChild.setSignVisual(signChild.getVisual());
        }

        return groupSign;
    }

}
