package vg.sign.building.api;

import vg.draw.vobject.VGGroup;
import vg.draw.vobject.VGObject;
import vg.geometry.primitives.BaseRectangle2D;
import vg.sign.visual.api.ISignVisual;

import java.util.List;

/**
 * Построитель изображений знаков.
 */
public interface ISignBuilder {

    /**
     * Получить список модификаторов визуального представления перед построением.
     *
     * @return Список модификаторов визуального представления перед построением.
     */
    public List<IPreBuildModifier> getPreBuildModifiers();

    /**
     * Получить список модификаторов изображения после построения.
     *
     * @return Список модификаторов изображения после построения.
     */
    public List<IPostBuildModifier> getPostBuildModifiers();

    /**
     * Построить изображение.
     * <p>Построение делится на 5 этапов:
     * <ul>
     * <li>Подготовка исходного Визуального представления (prepareBuilding);
     * <li>Премодификация копии Визуального представления (preModify);
     * <li>Построение изображения (buildGraphics);
     * <li>Постмодификация изображения (postModify);
     * <li>Вычисление геометрические характеристик (calculateGeometry).
     * </ul>
     *
     * @param visual Визуальное построение.
     * @return Построенное изображение.
     */
    public ICalculatedGraph build(ISignVisual visual);

    /**
     * Подготвка для эскиза.
     *
     * @param visual визуальное представление знака.
     */
    public void prepareForPreview(ISignVisual visual);

    /**
     * Подготовка исходного Визуального представления к построению.
     *
     * @param visual Исходное Визуальное представление.
     */
    public void prepareBuilding(ISignVisual visual);

    /**
     * Премодификация копии Визуального представления.
     *
     * @param visual Копия визуального представления.
     */
    public void preModify(ISignVisual visual);

    /**
     * Построить уже модифицированное графическое представление.
     *
     * @param visual Уже модифицированное графическое представление.
     * @return Ещё не модифицированное построенное изображение.
     */
    public abstract VGGroup buildGraphics(ISignVisual visual);

    /**
     * Постмодификация изображения.
     *
     * @param image Изображение.
     */
    public void postModify(VGObject image);

    /**
     * Вычислить геометрические параметры.
     *
     * @param signVisual визуальное представление знака.
     * @param bounds     рамка.
     * @return геометрические параметры.
     */
    public abstract IGeometry calculateGeometry(ISignVisual signVisual, BaseRectangle2D bounds);

}