package vg.sign.visual.tools;

import vg.sign.visual.api.IBrush;
import vg.sign.visual.api.ICircleGraphElement;
import vg.sign.visual.api.IPen;
import vg.sign.visual.api.IText;

/**
 * Графический элемент окружности (эллипса, дуги).
 */
public class CircleGraphElement extends LineGraphElement implements ICircleGraphElement {

    /**
     * Начальный угол дуги (относительно угла первого радиуса).
     */
    protected double beginAngle;
    /**
     * Конечный угол дуги (относительно угла первого радиуса).
     */
    protected double endAngle;


    /***/
    public CircleGraphElement() {
        this(null, null, null, 0.0, 0.0);
        this.name = "Окружность";
    }

    /**
     * @param pen        Перо.
     * @param brush      Заливка.
     * @param text       Текст.
     * @param beginAngle Начальный угол дуги.
     * @param endAngle   Конечный угол дуги.
     *                   <p> Если начальный и конечный углы совпадают, то рисоваться будет полная окружность/эллипс.
     */
    public CircleGraphElement(IPen pen, IBrush brush, IText text, double beginAngle, double endAngle) {
        super(pen, brush, text, true, true);
        this.beginAngle = beginAngle;
        this.endAngle = endAngle;
    }


    @Override
    public CircleGraphElement clone() {
        CircleGraphElement clonedObject = (CircleGraphElement) super.clone();
        return clonedObject;
    }


    @Override
    public double getBeginAngle() {
        return beginAngle;
    }

    @Override
    public void setBeginAngle(double beginAngle) {
        this.beginAngle = beginAngle;
    }

    @Override
    public double getEndAngle() {
        return endAngle;
    }

    @Override
    public void setEndAngle(double endAngle) {
        this.endAngle = endAngle;
    }

}
