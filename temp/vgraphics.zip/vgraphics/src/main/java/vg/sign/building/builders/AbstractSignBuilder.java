package vg.sign.building.builders;

import vg.draw.vobject.*;
import vg.geometry.GeometryDefaults;
import vg.geometry.GeometryProcessor;
import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BaseFrame2D;
import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.building.*;
import vg.sign.building.api.*;
import vg.sign.visual.api.*;
import vg.sign.visual.signs.*;

import java.util.ArrayList;
import java.util.List;

import static vg.geometry.GeometryDefaults.POLYLINE_PRECISION;

/**
 * Абстрактный построитель знаков.
 */
public abstract class AbstractSignBuilder implements ISignBuilder {

    /**
     * Создать построитель знака для указанного визуального представления.
     *
     * @param visual Визуальное представление.
     * @return Построитель знака.
     */
    public static ISignBuilder createBuilder(ISignVisual visual) {

        return visual instanceof PointSignVisual ? new PointGraphBuilder() :
                //visual instanceof LineSignVisual ? new LineGraphBuilder() :
                  //      visual instanceof AreaSignVisual ? new AreaGraphBuilder() :
                                visual instanceof FlagstaffSignVisual ? new FlagstaffGraphBuilder() :
                    //                    visual instanceof ILinkingLineSignVisual ? new LinkingLineGraphBuilder() :
                      //                          visual instanceof LeaderSignVisual ? new LeaderGraphBuilder() :
                                                        visual instanceof IGroupSignVisual ? new GroupGraphBuilder() :
                        //                                        visual instanceof FormularSignVisual ? new FormularGraphBuilder() :
                          //                                              visual instanceof DemarkLineSignVisual ? new DemarkLineGraphBuilder() :
                            //                                                    visual instanceof StripSignVisual ? new StripGraphBuilder() :
                              //                                                          visual instanceof FireStripeSignVisual ? new FireStripeGraphBuilder() :
                                //                                                                visual instanceof PositionAreaSignVisual ? new PositionAreaGraphBuilder() :
                                  //                                                                      visual instanceof ObservationAreaSignVisual ? new ObservationAreaGraphBuilder() :
                                    //                                                                            visual instanceof TableSignVisual ? new TableGraphBuilder() :
                                      //                                                                                  visual instanceof ThrustSignVisual ? new ThrustGraphBuilder() :
                                                                                                                                null;
    }

    /**
     * Получить точки фигуры.
     *
     * @param basePoints Базовые точки линии.
     * @param smooth     Сглаженность линии.
     * @param closed     Замкнутость линии.
     * @return Расчитанные точки линии.
     */
    public static List<BasePoint2D> buildLinePoints(List<? extends BasePoint2D> basePoints, boolean smooth, boolean closed) {
        List<BasePoint2D> linePoints;
        if (smooth) {
            List<BasePoint2D> referencePoints = new ArrayList<BasePoint2D>(basePoints.size());
            for (BasePoint2D bp : basePoints)
                referencePoints.add(new BasePoint2D(bp));
            linePoints = new ArrayList<BasePoint2D>(basePoints.size() * 10);
            GeometryProcessor.getSplinePoints((List<BasePoint2D>) (List) linePoints, referencePoints, GeometryProcessor.ST_CUBIC, closed);
        } else {
            linePoints = new ArrayList<BasePoint2D>(basePoints.size());
            for (BasePoint2D bp : basePoints)
                linePoints.add(new BasePoint2D(bp));
            if (closed && !linePoints.isEmpty() && !linePoints.get(0).equals(linePoints.get(linePoints.size() - 1)))
                linePoints.add(new BasePoint2D(linePoints.get(0)));
        }
        linePoints = GeometryUtils.simplifyPolyline(linePoints, 0.1);
        return linePoints;
    }

    /**
     * Построить невидимый графический объект, занимающий габариты точек привязки.
     *
     * @param anchorPoints Точки привязки.
     * @param angle        Угол.
     * @return Габаритный невидимый объект вокруг точек привязки.
     * Если перечень точек привязок пуст, то возвращает null.
     */
    public static VGObject buildAnchorPoints(List<IAnchorPoint> anchorPoints, double angle) {
        if (anchorPoints.isEmpty())
            return null;

        VGGroup image = new VGGroup();
        for (IAnchorPoint ap : anchorPoints) {
            image.getChildren().add(new VGPoint(ap.getPoint()));
            image.setAngle(angle);
        }
        image.setAngle(angle);
        return image;
    }

    /**
     * Построить изображение фигуры.
     *
     * @param linePoints Рассчитанные точи линии.
     * @param pen        перо.
     * @param brush      заливка.
     * @param text       Текст.
     * @param angle      Угол.
     * @return Изображение фигуры.
     * Данный метод возвращает null, ни одна составляющая изображения фигуры не смогла быть построена.
     * Контуры строятся тогда, когда количество точек больше или равно 2, перо не null и содержит хотя бы один элемент пера.
     * Заливки строятся тогда, когда количество точек больше или равно 3, заливка не null и содержит хотя бы один элемент заливки.
     * Текст строится тогда, когда количество точек больше или равно 1, текст не null и не пуст.
     */
    public static VGObject buildShape(List<? extends BasePoint2D> linePoints, IPen pen, IBrush brush, IText text, double angle) {

        if (linePoints.isEmpty())
            return null;

        List<List<? extends BasePoint2D>> penPoints = null;
        List<IPenElement> penElements = null;
        linePoints = GeometryUtils.simplifyPolyline(linePoints, POLYLINE_PRECISION);
        VGGroup shape = new VGGroup();
        if (pen != null && !pen.getElements().isEmpty() && linePoints.size() >= 2) {
            penPoints = new ArrayList<List<? extends BasePoint2D>>(pen.getElements().size() * 2);
            penElements = new ArrayList<IPenElement>(pen.getElements().size() * 2);
            for (IPenElement penElement : pen.getElements()) {
                double shift = penElement.getShift();
                double strip = penElement.getStrip();
                if (GeometryUtils.isNearZero(strip)) {
                    if (GeometryUtils.isNearZero(shift)) {
                        List<BasePoint2D> points = new ArrayList<BasePoint2D>(linePoints.size());
                        for (BasePoint2D p : linePoints)
                            points.add(new BasePoint2D(p));
                        penPoints.add(points);
                        penElements.add(penElement);

                        addArrows(shape, penElement, points);

                    } else {
                        List<BasePoint2D> points = GeometryProcessor.shiftPolyline(shift, 0.0, true, linePoints);
                        penPoints.add(points);
                        penElements.add(penElement);

                        addArrows(shape, penElement, points);
                    }
                } else {
                    List<BasePoint2D> points = GeometryProcessor.shiftPolyline(shift + strip * 0.5, 0.0, true, linePoints);
                    penPoints.add(points);
                    penElements.add(penElement);

                    addArrows(shape, penElement, points);

                    points = GeometryProcessor.shiftPolyline(shift - strip * 0.5, 0.0, true, linePoints);
                    penPoints.add(points);
                    penElements.add(penElement);

                    addArrows(shape, penElement, points);
                }
            }
        }

        List<BasePoint2D> brushPoints = null;
        if (brush != null && !brush.getElements().isEmpty() && linePoints.size() >= 3) {
            brushPoints = new ArrayList<BasePoint2D>(linePoints.size());
            if (penPoints != null) {
                int bestLineIndex = 0;
                double bestLineLength = GeometryProcessor.getPolylineLength(penPoints.get(0));
                for (int i = 1, n = penPoints.size(); i < n; i++) {
                    double length = GeometryProcessor.getPolylineLength(penPoints.get(i));
                    if (length < bestLineLength) {
                        bestLineIndex = i;
                        bestLineLength = length;
                    }
                }
                for (BasePoint2D p : penPoints.get(bestLineIndex)) {
                    brushPoints.add(new BasePoint2D(p));
                }
            } else {
                for (BasePoint2D p : linePoints) {
                    brushPoints.add(new BasePoint2D(p));
                }
            }
        }


        if (brushPoints != null) {
            VGObject brushShape = new VGShape(null, buildBrush(brush), brushPoints);
            brushShape.setAngle(angle);
            shape.getChildren().add(brushShape);
        }
        if (penPoints != null && penElements != null) {
            for (int i = 0, n = penElements.size(); i < n; i++) {
                List<? extends BasePoint2D> pp = penPoints.get(i);
                IPenElement pe = penElements.get(i);
                VGObject penShape = new VGShape(buildPen(pe), null, pp);
                penShape.setAngle(angle);
                shape.getChildren().add(penShape);
            }
        }
        if (text != null && text.getText() != null && !text.getText().isEmpty() && linePoints.size() >= 1) {
            BaseFrame2D frame = new BaseFrame2D();
            for (BasePoint2D bp : linePoints)
                frame.union(new BasePoint2D(bp).rotate(-angle, 0, 0));
            VGText textShape = new VGText(
                    text.getText(),
                    text.getFontName(), text.getFontStyle(), text.getFontSize(), text.getAlignment(),
                    null, null, buildPen(text.getPen()), buildBrush(text.getBrush()), text.getColor(),
                    frame.getP1().rotate(angle, 0, 0), frame.getP2().rotate(angle, 0, 0));
            textShape.setAngle(angle);
            shape.getChildren().add(textShape);
        }
        shape.setAngle(angle);

        return !shape.getChildren().isEmpty() ? shape : null;
    }

    /**
     * Добавить стрелки.
     *
     * @param shape Фигура, в которую добавляются стрелки.
     * @param pe    Элемент пера, из которого берётся информация о стрелках.
     * @param line  Линия, по точкам которой расссчитываются стрелки.
     */
    private static void addArrows(VGGroup shape, IPenElement pe, List<BasePoint2D> line) {
        if (line.size() < 2) return;
        addArrow(shape, pe, line, true);
        addArrow(shape, pe, line, false);
    }

    /**
     * Добавить стрелку.
     *
     * @param shape   Фигура, в которую добавляется стрелка.
     * @param pe      Элемент пера, из которого берётся информация о стрелке.
     * @param line    Линия, по точкам которой расссчитывается стрелка.
     * @param isBegin Флаг, указывающий, начальная стрелка или конечная.
     */
    private static void addArrow(VGGroup shape, IPenElement pe, List<BasePoint2D> line, boolean isBegin) {
        if (pe == null || line.size() < 2)
            return;

        if (isBegin && pe.getBeginArrow() != GeometryDefaults.LineArrowType.NONE)
            prepareBeginLine(line, pe.getWidth() * 3);
        else if (pe.getEndArrow() != GeometryDefaults.LineArrowType.NONE)
            prepareEndLine(line, pe.getWidth() * 3);

        List<BasePoint2D> arrow = getArrowPoints(new ArrayList<BasePoint2D>(line), pe, isBegin);

        if (arrow != null) {
            shape.getChildren().add(getArrowImage(pe, arrow, isBegin));
            processLine(line, pe.getWidth(), isBegin, getArrowLinkPoint(arrow));
        }
    }

    /**
     * Подготовка линии перед добавлением стрелки в конце.
     *
     * @param points   точки линии.
     * @param distance максимально допустимая дистанция между точками.
     * @return точки линии.
     * <p> Обрабатывает окончание линии на предмет скопления множества точек рядом с точкой окончания.
     */
    private static List<BasePoint2D> prepareEndLine(List<BasePoint2D> points, double distance) {
        BasePoint2D end = points.get(points.size() - 1);
        points.remove(points.size() - 1);

        for (int i = points.size() - 1; i > 0; --i) {
            if (end.distanceToPoint(points.get(i)) < distance)
                points.remove(i);
            else
                break;
        }

        points.add(end);

        return points;
    }

    /**
     * Подготовка линии перед добавлением стрелки в начало.
     *
     * @param points   точки линии.
     * @param distance максимально допустимая дистанция между точками.
     * @return точки линии.
     * <p> Обрабатывает начало линии на предмет скопления множества точек рядом с точкой начала.
     */
    private static List<BasePoint2D> prepareBeginLine(List<BasePoint2D> points, double distance) {
        BasePoint2D begin = points.get(0);

        for (int i = 1; i < points.size() - 1; ++i) {

            if (begin.distanceToPoint(points.get(i)) < distance) {
                points.remove(i);
                --i;
            } else
                break;
        }

        return points;
    }

    /**
     * Получить стрелку на основе линии и пера.
     *
     * @param pe          Перо.
     * @param arrowPoints Точки стрелки.
     * @param isBegin     Флаг, указывающий, начальная стрелка или конечная.
     * @return Стрелка.
     */
    private static VGObject getArrowImage(IPenElement pe, List<BasePoint2D> arrowPoints, boolean isBegin) {
        VGObject arrow = null;
        if (isBegin) {
            if (pe.getBeginArrow() != null) {
                if (pe.getBeginArrow() == GeometryDefaults.LineArrowType.SOLID) {
                    arrow = new VGShape(
                            null,
                            new VGBasicBrush(pe.getColor()),
                            arrowPoints);
                } else if (pe.getBeginArrow() == GeometryDefaults.LineArrowType.STICK) {
                    arrow = new VGShape(
                            new VGBasicPen(pe.getColor(), pe.getWidth()),
                            null,
                            arrowPoints);
                }
            }
        } else {
            if (pe.getEndArrow() != null) {
                if (pe.getEndArrow() == GeometryDefaults.LineArrowType.SOLID) {
                    arrow = new VGShape(
                            null,
                            new VGBasicBrush(pe.getColor()),
                            arrowPoints);
                } else if (pe.getEndArrow() == GeometryDefaults.LineArrowType.STICK) {
                    arrow = new VGShape(
                            new VGBasicPen(pe.getColor(), pe.getWidth()),
                            null,
                            arrowPoints);
                }
            }
        }
        return arrow;
    }

    /**
     * Получить точки стрелки.
     *
     * @param line    Линия, на которой расположена стрелка.
     * @param pe      Элемент пера, откуда берутся данные о стрелках.
     * @param isBegin Флаг, указывающий, начальную или конечную стрелку нужно рассчитать.
     * @return Точки стрелки.
     */
    private static List<BasePoint2D> getArrowPoints(List<BasePoint2D> line, IPenElement pe, boolean isBegin) {
        if (line.size() < 2) return null;
        if (isBegin) {
            if (pe.getBeginArrow() == null || pe.getBeginArrow() == GeometryDefaults.LineArrowType.NONE) {
                return null;
            }
            List<BasePoint2D> arrowPoints = getArrowPoints(
                    line.get(1),
                    line.get(0),
                    pe.getWidth());
            if (pe.getBeginArrow() == GeometryDefaults.LineArrowType.STICK) {
                arrowPoints = GeometryProcessor.shiftPolyline(-pe.getWidth() / 2.0, pe.getWidth() * 2.0, false, arrowPoints);
            }
            return arrowPoints;
        } else {
            if (pe.getEndArrow() == null || pe.getEndArrow() == GeometryDefaults.LineArrowType.NONE) {
                return null;
            }
            List<BasePoint2D> arrowPoints = getArrowPoints(
                    line.get(line.size() - 2),
                    line.get(line.size() - 1),
                    pe.getWidth());
            if (pe.getEndArrow() == GeometryDefaults.LineArrowType.STICK) {
                arrowPoints = GeometryProcessor.shiftPolyline(-pe.getWidth() / 2.0, pe.getWidth() * 2.0, false, arrowPoints);
            }
            return arrowPoints;
        }
    }

    /**
     * Обрезать линию (в соответствии с наличием стрелок).
     *
     * @param line           Линия.
     * @param width          Ширина.
     * @param isBegin        Флаг, указвающий, начальная стрелка рассчитывается или конечная.
     * @param arrowLinkPoint Точка соединения стрелки и линии.
     */
    private static void processLine(List<BasePoint2D> line, double width, boolean isBegin, BasePoint2D arrowLinkPoint) {
        BasePoint2D begin;
        BasePoint2D end;
        if (isBegin) {
            begin = new BasePoint2D(line.get(1));
            end = new BasePoint2D(line.get(0));
        } else {
            begin = new BasePoint2D(line.get(line.size() - 2));
            end = new BasePoint2D(line.get(line.size() - 1));
        }
        double segmentlength = GeometryUtils.distanceBetweenPoints(end, begin);
        if (width < segmentlength) {
            double shift = width * 1.5 / segmentlength;
            line.set(isBegin ? 0 : line.size() - 1, new BasePoint2D(GeometryUtils.absolute(end, begin, shift)));
        } else {
            double subPolyLineLength = GeometryProcessor.getPolylineLength(line) - width;
            List<BasePoint2D> newLine = GeometryProcessor.getSubPolyline(line, 0, isBegin ? width : 0, subPolyLineLength);
            line.clear();
            line.addAll(newLine);
            if (!line.isEmpty()) {
                line.set(isBegin ? 0 : line.size() - 1, arrowLinkPoint);
            }
        }
    }

    /**
     * Получить точки стрелки.
     *
     * @param begin Начало сегмента, на котором расположена стрелка.
     * @param end   Конец сегмента, на котором расположена стрелка.
     * @param width Ширина линии.
     * @return Точки стрелки.
     */
    private static List<BasePoint2D> getArrowPoints(BasePoint2D begin, BasePoint2D end, double width) {
        double distance = GeometryUtils.distanceBetweenPoints(begin, end);
        BasePoint2D arrowBegin = GeometryUtils.absolute(begin, end, 1.0 - ((width * 6.0) / distance));
        BasePoint2D arrowEnd = new BasePoint2D(end);
        List<BasePoint2D> arrowPoints = new ArrayList<BasePoint2D>();
        double angle = GeometryUtils.angleBetweenPoints(arrowEnd, arrowBegin, null);
        BaseMatrix2D m = new BaseMatrix2D().translate(arrowBegin).rotate(angle, arrowBegin);
        BasePoint2D p1 = new BasePoint2D(0.0, width * 2.0).transform(m);
        BasePoint2D p2 = new BasePoint2D(width * 6.0, 0.0).transform(m);
        BasePoint2D p3 = new BasePoint2D(0.0, -width * 2.0).transform(m);
        arrowPoints.add(p1);
        arrowPoints.add(p2);
        arrowPoints.add(p3);
        return arrowPoints;
    }

    /**
     * Получить точку соединения стрелки и линии.
     *
     * @param arrow Точки стрелки.
     * @return Центр стрелки.
     */
    private static BasePoint2D getArrowLinkPoint(List<BasePoint2D> arrow) {
        BasePoint2D arrowBaseCenter = GeometryUtils.absolute(arrow.get(0), arrow.get(2), 0.5);
        return GeometryUtils.absolute(arrowBaseCenter, arrow.get(1), 0.33);
    }


    /**
     * Построить перо.
     *
     * @param visualPen Перо графического элемента.
     * @return Перо графической подсистемы.
     */
    public static VGPen buildPen(IPen visualPen) {
        if (visualPen == null) return null;
        VGGroupPen pen = new VGGroupPen();
        for (IPenElement vpe : visualPen.getElements())
            pen.getChildren().add(buildPen(vpe));
        return pen;
    }

    /**
     * Построить перо.
     *
     * @param visualPen Перо графического элемента.
     * @return Перо графической подсистемы.
     */
    public static VGPen buildPen(IPenElement visualPen) {
        if (visualPen == null) return null;
        VGPen pen = null;
        if (visualPen.getCore() instanceof IPatternPenCore) {
            pen = new VGPatternPen(
                    visualPen.getColor(),
                    visualPen.getWidth(),
                    ((IPatternPenCore) visualPen.getCore()).getPattern());
        } else if (visualPen.getCore() instanceof ISolidPenCore) {
            GeometryDefaults.LineCapType cap = null;
            switch (visualPen.getCap()) {
                case BUTT:
                    cap = GeometryDefaults.LineCapType.BUTT;
                    break;
                case SQUARE:
                    cap = GeometryDefaults.LineCapType.SQUARE;
                    break;
                case ROUND:
                    cap = GeometryDefaults.LineCapType.ROUND;
                    break;
            }
            GeometryDefaults.LinesJoinType join = null;
            switch (visualPen.getJoin()) {
                case MITTER:
                    join = GeometryDefaults.LinesJoinType.MITTER;
                    break;
                case BEVEL:
                    join = GeometryDefaults.LinesJoinType.BEVEL;
                    break;
                case ROUND:
                    join = GeometryDefaults.LinesJoinType.ROUND;
                    break;
            }
            double miterLimit = visualPen.getMiterLimit();
            if (miterLimit <= 0.0) miterLimit = 5.0;
            pen = new VGBasicPen(visualPen.getColor(), visualPen.getWidth(), cap, join, miterLimit);
        } else if (visualPen.getCore() instanceof IEuzPenCore) {
            PointSignVisual sv = ((IEuzPenCore) visualPen.getCore()).getEuz();
            sv.getAnchorPoints().clear();
            sv.getAnchorPoints().add(new BasePoint2D(0.0, 0.0));
            sv.setAngle(0);
            pen = new VGEuzPen(sv);
        }
        return pen;
    }

    /**
     * Построить заливку.
     *
     * @param visualBrush Заливка графического элемента.
     * @return Заливка графической подсистемы.
     */
    public static VGBrush buildBrush(IBrush visualBrush) {
        if (visualBrush == null) return null;
        VGGroupBrush brush = new VGGroupBrush();
        for (IBrushElement vbe : visualBrush.getElements())
            brush.getChildren().add(buildBrush(vbe));
        return brush;
    }

    /**
     * Построить заливку.
     *
     * @param visualBrush Заливка графического элемента.
     * @return Заливка графической подсистемы.
     */
    public static VGBrush buildBrush(IBrushElement visualBrush) {

        if (visualBrush == null) return null;
        VGBrush brush;
        if (visualBrush.getCore() instanceof IShadingBrushCore) {
            brush = new VGShadingBrush(visualBrush.getColor(), 0.1, ((IShadingBrushCore) visualBrush.getCore()).getShading(), visualBrush.getAngle());
        } else if (visualBrush.getCore() instanceof IGradientBrushCore) {
            IGradientBrushCore bc = (IGradientBrushCore) visualBrush.getCore();
            brush = new VGLinearGradientBrush(bc.getColor1(), bc.getColor2(), visualBrush.getAngle());
        } else if (visualBrush.getCore() instanceof IEuzBrushCore) {
            PointSignVisual sv = ((IEuzBrushCore) visualBrush.getCore()).getEuz().clone();
            sv.getAnchorPoints().clear();
            sv.getAnchorPoints().add(new BasePoint2D(0.0, 0.0));
            sv.setAngle(visualBrush.getAngle());
            brush = new VGEuzBrush(sv);
        } else {
            brush = new VGBasicBrush(visualBrush.getColor());
        }
        return brush;

    }


    /**
     * Модификаторы перед построением.
     */
    protected List<IPreBuildModifier> preBuildModifiers = new ArrayList<IPreBuildModifier>();
    /**
     * Модификаторы после построения.
     */
    protected List<IPostBuildModifier> postBuildModifiers = new ArrayList<IPostBuildModifier>();


    @Override
    public List<IPreBuildModifier> getPreBuildModifiers() {
        return preBuildModifiers;
    }

    @Override
    public List<IPostBuildModifier> getPostBuildModifiers() {
        return postBuildModifiers;
    }


    @Override
    public ICalculatedGraph build(ISignVisual visual) {
        if (visual instanceof IGroupSignVisual)
            visual.getClass();

        prepareBuilding(visual);
        visual = visual.clone();
        preModify(visual);
        VGGroup image = buildGraphics(visual);
        postModify(image);
        IGeometry geometry = calculateGeometry(visual, image.getBounds());

        ICalculatedGraph calculatedGraph = new CalculatedGraph();
        calculatedGraph.setImage(image);
        calculatedGraph.setGemetry(geometry);

        return calculatedGraph;
    }


    @Override
    public void prepareForPreview(ISignVisual visual) {
        prepareForPreview(visual, visual.getRootGraphElement());
    }

    /**
     * Настройка графических элементов для эскиза знака.
     *
     * @param visual           Визуальное представление.
     * @param rootGraphElement Корневой графический элемент.
     */
    public void prepareForPreview(ISignVisual visual, IRootGraphElement rootGraphElement) {
        List<IGraphElement> graphElementList = rootGraphElement.getElements();
        final double WIDTH_PEN = 0.2;
        for (IGraphElement graphElement : graphElementList) {
            if (graphElement instanceof IRootGraphElement)
                prepareForPreview(visual, (IRootGraphElement) graphElement);
            IPen pen = graphElement.getPen();
            if (pen == null)
                continue;
            List<IPenElement> penElementsList = pen.getElements();
            for (IPenElement penElement : penElementsList)
                penElement.setWidth(WIDTH_PEN);
        }
    }

    @Override
    public void prepareBuilding(ISignVisual visual) {
    }

    @Override
    public void preModify(ISignVisual visual) {
        for (IPreBuildModifier bm : preBuildModifiers)
            if (bm.isEnabled())
                bm.modify(visual);
    }

    @Override
    public void postModify(VGObject image) {
        for (IPostBuildModifier bm : postBuildModifiers)
            if (bm.isEnabled())
                bm.modify(image);
    }
}
