package vg.sign.visual.api;

import java.util.List;


/**
/**
 * Штриховка.
 *
 */
public interface IBrushShading extends Cloneable {

    /**
     * Элемент штриховки.
     * <p>Элемент штриховки задаёт семейство параллельных линий.
     *
     */
    public interface IElement extends Cloneable {
        /**
         * Клонирование.
         *
         * @return Клон.
         */
        public IElement clone();

        /**
         * Получить расстояние между линиями штриховки.
         *
         * @return Расстояние между линиями штриховки (% относительно базового размера).
         */
        public double getSize();

        /**
         * Задать расстояние между линиями штриховки.
         *
         * @param size Расстояние между линиями штриховки (% относительно базового размера).
         */
        public void setSize(double size);

        /**
         * Получить угол наклона штриховки.
         *
         * @return Угол наклона штриховки.
         */
        public double getAngle();

        /**
         * Задать угол наклона штриховки.
         *
         * @param angle Угол наклона штриховки.
         */
        public void setAngle(double angle);
    }


    /**
     * Клонирование.
     *
     * @return Клон.
     */
    public IBrushShading clone();

    /**
     * Получить базовый размер штриховки.
     *
     * @return Базовый размер штриховки.
     */
    public double getSize();

    /**
     * Задать базовый размер штриховки.
     *
     * @param size Базовый размер штриховки.
     */
    public void setSize(double size);

    /**
     * Получить список элементов штриховки.
     *
     * @return Список элементов штриховки.
     */
    public List<IElement> getElements();

}
