package vg.sign.building.builders;

import vg.draw.vobject.VGGroup;
import vg.geometry.primitives.BasePoint2D;
import vg.geometry.primitives.BaseRectangle2D;
import vg.sign.building.BuildingFactory;
import vg.sign.building.api.ISignBuilder;
import vg.sign.visual.api.IGroupSignVisual;
import vg.sign.visual.api.ISignVisual;
import vg.sign.visual.signs.FlagstaffSignVisual;

import java.util.*;

/**
 * Построитель флагштока.
 */
public class FlagstaffGraphBuilder extends GroupGraphBuilder {

    /**
     * Сравниватель дочерних элементов флагштока по смещениям.
     *
     * @author Giller
     */
    private class ShiftChildComparator implements Comparator<IGroupSignVisual.IChild> {

        /**
         * Конструктор по умолчанию.
         */
        public ShiftChildComparator() {
        }

        @Override
        public int compare(IGroupSignVisual.IChild ch1, IGroupSignVisual.IChild ch2) {
            if (ch1 instanceof FlagstaffSignVisual.FlagstaffChild && ch2 instanceof FlagstaffSignVisual.FlagstaffChild) {
                double child1Shift = ((FlagstaffSignVisual.FlagstaffChild) ch1).getOffset();
                double child2Shift = ((FlagstaffSignVisual.FlagstaffChild) ch2).getOffset();

                if (child1Shift > child2Shift)
                    return 1;
                else if (child1Shift == child2Shift)
                    return 0;
                else
                    return -1;
            } else
                throw new RuntimeException("ShiftChildComparator предназначен для IFlagstaffChild");
        }

    }


    @Override
    public void prepareBuilding(ISignVisual visual) {
        // Все знаки получают точку привязки равную точки привязки флагштока.
        FlagstaffSignVisual sv = (FlagstaffSignVisual) visual;

        if (!sv.getAnchorPoints().isEmpty()) {
            BasePoint2D center = sv.getAnchorPoints().get(0).getPoint();

            for (IGroupSignVisual.IChild child : sv.getChildren()) {
                if (child.getVisual() == null)
                    continue;
                child.getVisual().getAnchorPoints().set(0, new BasePoint2D(center));
            }
        }

        super.prepareBuilding(visual);
    }

    @Override
    public void preModify(ISignVisual visual) {
        // Все дочерние знаки сдвигаются на величину сдвига.
        FlagstaffSignVisual lsv = (FlagstaffSignVisual) visual;

        if (!lsv.getAnchorPoints().isEmpty()) {
            BasePoint2D p = lsv.getAnchorPoints().get(0).getPoint();

            // Поворот и масштабирование сдвигов.
            List<BasePoint2D> shiftedPoints = new ArrayList<BasePoint2D>();
            for (IGroupSignVisual.IChild child : lsv.getChildren()) {
                if (child.getVisual() == null)
                    continue;
                FlagstaffSignVisual.FlagstaffChild flagstaffChild = (FlagstaffSignVisual.FlagstaffChild) child;
                BasePoint2D rotatePoint = new BasePoint2D(p.getX(), p.getY() + flagstaffChild.getOffset() * lsv.getScale().getY());
                rotatePoint.rotate(visual.getAngle(), p);
                shiftedPoints.add(new BasePoint2D(rotatePoint.getX() - p.getX(), rotatePoint.getY() - p.getY()));
            }

            Iterator<BasePoint2D> it = shiftedPoints.iterator();
            for (IGroupSignVisual.IChild child : lsv.getChildren()) {
                if (child.getVisual() == null)
                    continue;
                BasePoint2D shiftedPoint = it.next();
                child.getVisual().getAnchorPoints().set(0, new BasePoint2D(p.getX() + shiftedPoint.getX(), p.getY() + shiftedPoint.getY()));
            }
        }

        super.preModify(visual);
    }

    @Override
    public VGGroup buildGraphics(ISignVisual visual) {
        // Сортировка дочерних элементов по смещению.
        Collections.sort(((FlagstaffSignVisual) visual).getChildren(), new ShiftChildComparator());
        return super.buildGraphics(visual);
    }

    /**
     * Выравнивание внутренних знаков по вертикали.
     * <p> Самый нижний знак будет иметь координаты флагштока.
     * Остальные знаки будут вплотную располагаться сверху друг на друге.
     *
     * @param visual выравнивание по вертикали.
     */
    public void alignVertically(ISignVisual visual) {
        FlagstaffSignVisual flagStaff = (FlagstaffSignVisual) visual;
        if (flagStaff == null || flagStaff.getAnchorPoints().isEmpty() || flagStaff.getChildren().isEmpty())
            return;

        // Над списком дочерних знаков планируются различные манипуляции.
        // Для этого список содается отдельно, но сами экземпляры вложенных знаков остаются оригинальными.
        List<IGroupSignVisual.IChild> children = new ArrayList<IGroupSignVisual.IChild>();
        for (IGroupSignVisual.IChild child : flagStaff.getChildren())
            children.add(child);

        Collections.sort(children, new ShiftChildComparator());
        Collections.reverse(children);

        List<BaseRectangle2D> frames = new ArrayList<BaseRectangle2D>(children.size());
        for (IGroupSignVisual.IChild child : children) {
            IGroupSignVisual.IChild childClone = child.clone();
            childClone.getVisual().setAngle(childClone.getVisual().getAngle() - flagStaff.getAngle());
            ISignBuilder builder = BuildingFactory.createBuilder(childClone.getVisual());
            frames.add(this.calculateVerticalBounds(builder.build(childClone.getVisual()).getImage().getBounds(), 0));
        }

        double currentShift = 0;
        FlagstaffSignVisual.FlagstaffChild flagstaffChild = (FlagstaffSignVisual.FlagstaffChild) children.get(0);
        flagstaffChild.setOffset(0);

        BasePoint2D anchPoint = flagstaffChild.getVisual().getAnchorPoints().get(0).getPoint();
        currentShift -= Math.abs(anchPoint.getY() - frames.get(0).getTLP().getY());

        for (int i = 1; i < children.size(); ++i) {
            flagstaffChild = (FlagstaffSignVisual.FlagstaffChild) children.get(i);
            anchPoint = flagstaffChild.getVisual().getAnchorPoints().get(0).getPoint();

            currentShift -= frames.get(i).getHeight() - Math.abs(anchPoint.getY() - frames.get(i).getTLP().getY());
            flagstaffChild.setOffset(currentShift);
            currentShift -= Math.abs(anchPoint.getY() - frames.get(i).getTLP().getY());
        }
    }

    /**
     * Вычислить рамку без угла наклона.
     * <p> Используется в выравнивании флагштока для учета угла наклона вложенных знаков при расчете их рамки.
     *
     * @param bounds рамка под углом наклона.
     * @param angle  внешний угол наклона.
     * @return рамка без угла наклона.
     */
    private BaseRectangle2D calculateVerticalBounds(BaseRectangle2D bounds, double angle) {
        //bounds = bounds.clone();
        //((BaseRectangle2D) bounds).setAngle(bounds.getAngle() - angle);
        //BasePoint2D border[] = bounds.getPoints();

        BaseRectangle2D tmpRectangle = new BaseRectangle2D(bounds);
        tmpRectangle.setAngle(bounds.getAngle() - angle);
        BasePoint2D border[] = tmpRectangle.getPoints();

        List<BasePoint2D> points = Arrays.asList(border);
        BasePoint2D newTlp = points.get(0);
        //BasePoint2D newRbp = new BasePoint2D(points.get(2));
        BasePoint2D newRbp = points.get(2);

        double tlpX = newTlp.getX();
        double tlpY = newTlp.getY();
        double rbpX = newRbp.getX();
        double rbpY = newRbp.getY();

        for (BasePoint2D p : points) {
            if (p.getX() < /*newTlp.getX()*/ tlpX)
                //newTlp.setX(p.getX());
                tlpX = p.getX();

            if (p.getY() < /*newTlp.getY()*/ tlpY)
                //newTlp.setY(p.getY());
                tlpY = p.getY();

            if (p.getX() > /*newRbp.getX()*/ rbpX)
                //newRbp.setX(p.getX());
                rbpX = p.getX();

            if (p.getY() > /*newRbp.getY()*/ rbpY)
                //newRbp.setY(p.getY());
                rbpY = p.getY();
        }

        return new BaseRectangle2D(newTlp, newRbp.sub(newTlp), angle);
    }

}
