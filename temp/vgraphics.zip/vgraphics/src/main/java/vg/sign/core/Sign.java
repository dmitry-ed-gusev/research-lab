package vg.sign.core;

import vg.draw.vobject.VGObject;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.attributes.AttributesFactory;
import vg.sign.attributes.api.IAttribute;
import vg.sign.building.BuildingFactory;
import vg.sign.building.api.*;
import vg.sign.core.api.ISign;
import vg.sign.edit.SignEditFactory;
import vg.sign.edit.api.ISignEditor;
import vg.sign.generalization.GeneralizationFactory;
import vg.sign.generalization.api.IGeneralization;
import vg.sign.generalization.api.IGeneralizationModifier;
import vg.sign.placing.api.IPlacingRules;
import vg.sign.visual.api.ISignVisual;
import vg.sign.visual.signs.TableSignVisual;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * ЭУЗ ОО (шкурка).
 */
public class Sign implements ISign {

    /**
     * Визуальное представление.
     */
    protected ISignVisual visual;
    /**
     * Построитель.
     */
    protected ISignBuilder builder;
    /**
     * Построенное изображение и геометрия.
     */
    protected ICalculatedGraph graph;
    /**
     * Средства редактирования.
     */
    protected ISignEditor editor;
    /**
     * Атрибуты знака.
     */
    protected List<IAttribute> attributes;
    /**
     * Генерализация знака.
     */
    protected IGeneralization generalization;
    /**
     * Правила нанесения.
     */
    protected IPlacingRules placingRules;
    /**
     * Внешние данные, связанные со Знаком.
     */
    protected Object externalSignUtils;

    /**
     * Премодификаторы по атрибутам.
     */
    private IGroupPreModifier attributesModifiers;
    /**
     * Модификатор гереализации.
     */
    IGeneralizationModifier generalizationModifier;
    /**
     * Премодификатор текста по значениям атрибутов.
     */
    private IAttributesPreBuildModifier attributeFormularModifier;
    /**
     * Черновой премодификатор.
     */
    private IDraftModePreModifier draftModifier;
    /**
     * Контурный постмодификатор.
     */
    private IContourModePostModifier contourModifier;

    /**
     * Вкл./Выкл. черновой режим.
     */
    public static boolean draftMode = false;
    /**
     * Вкл./Выкл. контурный режим.
     */
    public static boolean contourMode = false;


    /**
     * Конструктор по умолчанию.
     * <p> Необходим для сериализации.
     */
    public Sign() {
    }

    /**
     * @param visual Визуальное представление.
     */
    public Sign(ISignVisual visual) {
        this.visual = visual;
        this.initBuilderAndEditor();
    }

    /**
     * Инициализация построителя и редактора.
     */
    private void initBuilderAndEditor() {
        this.editor = SignEditFactory.createEditor(visual);
        this.builder = BuildingFactory.createBuilder(visual);

//		generalization = SignComponent.generalizationFactory.createGeneralization();
//		initGeneralization(generalization);

        attributesModifiers = BuildingFactory.createGroupPreModifier();
        builder.getPreBuildModifiers().add(attributesModifiers);

        attributeFormularModifier = AttributesFactory.createAttributeFormularModifier();
        builder.getPreBuildModifiers().add(attributeFormularModifier);

        generalizationModifier = GeneralizationFactory.createGeneralizationModifier();
        generalizationModifier.setSignEditor(editor);
        builder.getPreBuildModifiers().add(this.generalizationModifier);

        draftModifier = BuildingFactory.createDraftModePreModifier();
        draftModifier.setSignEditor(editor);
        draftModifier.setEnabled(false);
        builder.getPreBuildModifiers().add(draftModifier);

        contourModifier = BuildingFactory.createContourPostModifier();
        contourModifier.setEnabled(false);
        builder.getPostBuildModifiers().add(contourModifier);
    }


    @Override
    public ISignVisual getVisual() {
        return visual;
    }

    @Override
    public void setVisual(ISignVisual visual) {
        this.visual = visual;
        this.initBuilderAndEditor();
    }

    @Override
    public ISignEditor getEditor() {
        return editor;
    }

    @Override
    public ISignBuilder getBuilder() {
        return builder;
    }

    @Override
    public VGObject getImage() {
        return graph != null ? graph.getImage() : null;
    }

    @Override
    public IGeometry getGeometry() {
        return graph != null ? graph.getGeometry() : null;
    }

    @Override
    public List<IAttribute> getAttributes() {
        return attributes;
    }

    @Override
    public void setAttributes(List<IAttribute> attributes) {
        this.attributes = attributes;
    }

    @Override
    public Sign clone() {
        try {
            Sign sign = (Sign) super.clone();

            sign.visual = visual.clone();

            if (generalization != null)
                sign.generalization = generalization.clone();

            if (placingRules != null)
                sign.placingRules = placingRules.clone();

            if (attributes != null) {
                sign.attributes = AttributesFactory.createAttributesList();
                for (IAttribute a : attributes)
                    sign.attributes.add(a.clone());
            }

            sign.initBuilderAndEditor();

            sign.calculate();

            return sign;
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public IGeneralization getGeneralization() {
        return this.generalization;
    }

    @Override
    public void setGeneralization(IGeneralization generalization) {
        this.generalization = generalization;
        generalizationModifier.setGeneralization(generalization);
    }

    @Override
    public IGeneralizationModifier getGeneralizationModifier() {
        return this.generalizationModifier;
    }

    @Override
    public IPlacingRules getPlacingRules() {
        return placingRules;
    }

    @Override
    public void setPlacingRules(IPlacingRules placingRules) {
        this.placingRules = placingRules;
    }


    @Override
    public Object getExternalSignUtils() {
        return externalSignUtils;
    }

    @Override
    public void setExternalSignUtils(Object data) {
        this.externalSignUtils = data;
    }


    @Override
    public void calculate() {
        if (visual instanceof TableSignVisual)
            ((TableSignVisual) visual).calculate();

        if (attributes != null)
            linkClassCodes(attributes);

        if (editor != null) {
            editor.calculate();
        }
        if (builder != null) {
            createModifiers();
            graph = builder.build(visual);
        }
    }

    /**
     * Привязать Атрибуты типа Класскод к списку Атрибутов.
     *
     * @param attributes Список Атрибутов.
     */
    public static void linkClassCodes(List<IAttribute> attributes) {
        linkClassCodes(attributes, attributes);
    }

    /**
     * Привязать Атрибуты типа Класскод к списку Атрибутов.
     *
     * @param allAttributes  Общий список Атрибутов (к которому прозводится привязка).
     * @param currAttributes Список Атрибутов в котором производится поиск Класскодов.
     */
    private static void linkClassCodes(List<IAttribute> allAttributes, List<IAttribute> currAttributes) {

        // todo: tmp commented
        throw new IllegalStateException("temporary commented");
        /*
        for (IAttribute attribute : currAttributes) {
            if (attribute.getValue() instanceof ClassCodeAttributeValue)
                ((ClassCodeAttributeValue) attribute.getValue()).setAttributes(allAttributes);
            linkClassCodes(allAttributes, attribute.getChildren());
        }
        */
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {

        // todo: tmp commented
        throw new IllegalStateException("temporary commented");

        //ISignSource zipSignSource = SignSourceFactory.createZipSignSource((ObjectInputStream) in);
        //zipSignSource.importSign(this);
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {

        // todo: tmp commented
        throw new IllegalStateException("temporary commented");

        //ISignSource zipSignSource = SignSourceFactory.createZipSignSource((ObjectOutputStream) out);
        //zipSignSource.exportSign(this);
    }

    /**
     * Создать модификаторы.
     */
    private void createModifiers() {
        createPredefinedAttributesModifier();
        createAttributeFormularModifier();
        createPaintModeModifiers();
    }

    /**
     * Создать модиффикатор текста графических элементов по значению атрибута.
     */
    private void createAttributeFormularModifier() {
        attributeFormularModifier.getAttributes().clear();

        if (attributes != null)
            attributeFormularModifier.getAttributes().addAll(attributes);
    }

    /**
     * Создать групповой премодификатор на основе атрибутов госпринадлежности, признака действия, состояния.
     */
    private void createPredefinedAttributesModifier() {
        attributesModifiers.getElements().clear();
        if (attributes == null)
            return;

        List<IPreBuildModifier> modifiers = attributesModifiers.getElements();

        // todo: tmp commented
        throw new IllegalStateException("temporary commented");

        /*
        for (IAttribute a : attributes) {
            if (a.getType() instanceof CountryAttributeType) {
                int value = ((CountryAttributeType) a.getType()).getInitialValue();
                IAttributesPreBuildModifier country = AttributesFactory.createCountryPreModifier(value);
                country.getAttributes().add(a);
                modifiers.add(country);
            }
            if (a.getType() instanceof ActionAttributeType) {
                int value = ((ActionAttributeType) a.getType()).getInitialValue();
                IAttributesPreBuildModifier action = AttributesFactory.createActionPreModifier(value);
                action.getAttributes().add(a);
                modifiers.add(action);
            }
            if (a.getType() instanceof StateAttributeType) {
                int value = ((StateAttributeType) a.getType()).getInitialValue();
                IAttributesPreBuildModifier state = AttributesFactory.createStatePreModifier(value);
                state.getAttributes().add(a);
                modifiers.add(state);
            }
        }
        */
    }

    /**
     * Настроить модификаторы чернового и контурного режимов отображения ЭУЗ.
     */
    private void createPaintModeModifiers() {
        draftModifier.setEnabled(draftMode);
        contourModifier.setEnabled(contourMode);
    }

    /**
     * Получить верхний знак по точке.
     *
     * @param signs Список знаков.
     * @param point Точка.
     * @param delta Допустимое отклонение.
     * @return Знак, содержащий точку или null.
     */
    // TODO method moved from SignComponent
    public static ISign getSignByPoint(List<ISign> signs, BasePoint2D point, double delta) {
        List<ISign> foundSigns = Sign.getSignsByPoint(signs, point, delta);
        return !foundSigns.isEmpty() ? foundSigns.get(foundSigns.size() - 1) : null;
    }

    /**
     * Получить знаки по точке.
     *
     * @param signs Список знаков.
     * @param point Точка.
     * @param delta Допустимое отклонение.
     * @return Знаки, содержащие точку.
     */
    // TODO method moved from SignComponent
    public static List<ISign> getSignsByPoint(List<ISign> signs, BasePoint2D point, double delta) {
        List<ISign> foundSigns = new ArrayList<ISign>();
        for (ISign sign : signs) {
            if (sign.getImage().containsPoint(point, delta))
                foundSigns.add(sign);
        }
        return foundSigns;
    }

//	/**
//	 * Инициализировать генерализацию.
//	 * @param gRef Ссылка на объект генерализации.
//	 */
//	private void initGeneralization(IGeneralization gRef) {
//		IGeneralizationFactory generalizationFactory = SignComponent.generalizationFactory;
//
//		IGeneralization.IParameter p = generalizationFactory.createGeneralizationParameter(20000000, 1.0, true, true);
//		gRef.getParameters().add(p);
//
//		p = generalizationFactory.createGeneralizationParameter(10000000, 1.0, true, true);
//		gRef.getParameters().add(p);
//
//		p = generalizationFactory.createGeneralizationParameter(5000000, 1.0, true, true);
//		gRef.getParameters().add(p);
//
//		p = generalizationFactory.createGeneralizationParameter(2000000, 1.0, true, true);
//		gRef.getParameters().add(p);
//
//		p = generalizationFactory.createGeneralizationParameter(1000000, 1.0, true, true);
//		gRef.getParameters().add(p);
//
//		p = generalizationFactory.createGeneralizationParameter(500000, 1.0, true, true);
//		gRef.getParameters().add(p);
//
//		p = generalizationFactory.createGeneralizationParameter(200000, 1.0, true, true);
//		gRef.getParameters().add(p);
//
//		p = generalizationFactory.createGeneralizationParameter(100000, 1.0, true, true);
//		gRef.getParameters().add(p);
//
//		p = generalizationFactory.createGeneralizationParameter(50000, 1.0, true, true);
//		gRef.getParameters().add(p);
//
//		p = generalizationFactory.createGeneralizationParameter(25000, 1.0, true, true);
//		gRef.getParameters().add(p);
//
//		p = generalizationFactory.createGeneralizationParameter(10000, 1.0, true, true);
//		gRef.getParameters().add(p);
//
//		p = generalizationFactory.createGeneralizationParameter(5000, 1.0, true, true);
//		gRef.getParameters().add(p);
//
//		p = generalizationFactory.createGeneralizationParameter(2000, 1.0, true, true);
//		gRef.getParameters().add(p);
//
//		p = generalizationFactory.createGeneralizationParameter(0, 1.0, true, true);
//		gRef.getParameters().add(p);
//	}

}
