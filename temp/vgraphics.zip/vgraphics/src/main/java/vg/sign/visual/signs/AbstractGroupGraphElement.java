package vg.sign.visual.signs;

import vg.geometry.GeometryDefaults;
import vg.geometry.GeometryUtils;
import vg.sign.visual.api.*;

import java.util.*;

/**
 * Абстрактный групповой графический элемент.
 * <p>Здесь реализована вся логика работы группового графического элемента.
 * Не определён лишь источник группируемых графических элементов.
 *
 */
public abstract class AbstractGroupGraphElement extends AbstractGraphElement implements IGroupGraphElement {

    /**
     * Итератор Дерева графических элементов по всем не групповым Графическим элементам.
     *
     */
    public static class ThroughGraphElementsIterator implements Iterator<IGraphElement> {

        /**
         * Итератор по графическим элементам.
         */
        private Iterator<IGraphElement> graphElementIterator;
        /**
         * Стек итераторов.
         */
        private Stack<Iterator<IGraphElement>> graphElementIteratorStack = new Stack<Iterator<IGraphElement>>();
        /**
         * Текущий графический элемент.
         */
        private IGraphElement currentGraphElement;
        /**
         * Флаг прохождения только по редактируемым графическим элементам
         */
        private boolean onlyEditable;
        /**
         * Включение графических элементов таблицы.
         */
        private boolean tableGEOn;

        /**
         * @param graphElementsIterator Итератор по графическим элементам.
         */
        public ThroughGraphElementsIterator(Iterator<IGraphElement> graphElementsIterator) {
            this.graphElementIterator = graphElementsIterator;
            this.onlyEditable = false;
            next();
        }

        /**
         * @param graphElementsIterator Итератор по графическим элементам.
         * @param onlyEditable          Флаг прохождения только по редактируемым графическим элементам.
         */
        public ThroughGraphElementsIterator(Iterator<IGraphElement> graphElementsIterator, boolean onlyEditable) {
            this.graphElementIterator = graphElementsIterator;
            this.onlyEditable = onlyEditable;
            next();
        }

        /**
         * @param graphElementsIterator итератор по графическим элементам.
         * @param onlyEditable          флаг прохождения только по редактируемым графическим элементам.
         * @param tableGEOn             флаг для прохождения по специальным групповм графическим элементам в таблице.
         */
        public ThroughGraphElementsIterator(Iterator<IGraphElement> graphElementsIterator, boolean onlyEditable, boolean tableGEOn) {
            this.graphElementIterator = graphElementsIterator;
            this.onlyEditable = onlyEditable;
            this.tableGEOn = tableGEOn;
            next();
        }

        /**
         * @param graphElements Графические элементы.
         */
        public ThroughGraphElementsIterator(Collection<IGraphElement> graphElements) {
            this(graphElements.iterator());
        }

        @Override
        public boolean hasNext() {
            return currentGraphElement != null;
        }

        @Override
        public IGraphElement next() {
            IGraphElement returnGraphElement = currentGraphElement;
            currentGraphElement = null;
            while (currentGraphElement == null) {
                if (!graphElementIterator.hasNext()) {
                    // Если элементы закончились, то берём итератор предыдущего уровня дерева, если он есть.
                    // Если нету, то на этом и всё.
                    if (graphElementIteratorStack.isEmpty()) {
                        break;
                    } else {
                        graphElementIterator = graphElementIteratorStack.pop();
                        continue;
                    }
                }
                IGraphElement graphElement = graphElementIterator.next();

                if (graphElement != null) {
                    // Если попался групповой элемент, то переходим на его уровень и начинаем перебирать его элементы.
                    // Итератор текущего уровня сохраняем в стеке.
                    if (graphElement instanceof IGroupGraphElement &&
                            !(tableGEOn && (graphElement instanceof TableSignVisual.CellGraphElement || graphElement instanceof TableSignVisual.CellSpanGraphElement))) {
                        graphElementIteratorStack.push(graphElementIterator);
                        graphElementIterator = ((IGroupGraphElement) graphElement).getElements().iterator();
                    } else {
                        if (onlyEditable && !graphElement.isEditable())
                            continue;
                        currentGraphElement = graphElement;
                        break;
                    }
                }
            }
            return returnGraphElement;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

    }


    /**
     * Итератор Дерева графических элементов по всем не групповым Элементам пера.
     *
     */
    public static class ThroughPenElementsIterator implements Iterator<IPenElement> {

        /**
         * Итератор по графическим элементам.
         */
        private Iterator<IGraphElement> graphElementsIterator;
        /**
         * Текущий итератор по элементам пера.
         */
        private Iterator<IPenElement> penElementsIterator;
        /**
         * Текущий элемент пера.
         */
        private IPenElement currentPenElement;
        /**
         * Флаг прохождения только по редактируемым графическим элементам
         */
        private boolean onlyEditable;

        /**
         * @param graphElementsIterator Итератор по графическим элементам.
         */
        public ThroughPenElementsIterator(Iterator<IGraphElement> graphElementsIterator) {
            this.graphElementsIterator = graphElementsIterator;
            this.onlyEditable = false;
            next();
        }

        /**
         * @param graphElementsIterator Итератор по графическим элементам.
         * @param onlyEditable          флаг прохождения только по редактируемым графическим элементам.
         */
        public ThroughPenElementsIterator(Iterator<IGraphElement> graphElementsIterator, boolean onlyEditable) {
            this.graphElementsIterator = graphElementsIterator;
            this.onlyEditable = onlyEditable;
            next();
        }

        /**
         * @param graphElements Графические элементы.
         */
        public ThroughPenElementsIterator(Collection<IGraphElement> graphElements) {
            this(graphElements.iterator());
        }

        @Override
        public boolean hasNext() {
            return currentPenElement != null;
        }

        @Override
        public IPenElement next() {
            IPenElement returnPenElement = currentPenElement;
            currentPenElement = null;
            ce:
            while (currentPenElement == null) {
                while (penElementsIterator == null || !penElementsIterator.hasNext()) {
                    if (!graphElementsIterator.hasNext()) break ce;
                    IGraphElement graphElement = graphElementsIterator.next();

                    if (onlyEditable && !graphElement.isEditable())
                        continue;

                    IPen pen = graphElement.getPen();
                    if (pen != null) {
                        penElementsIterator = pen.getElements().iterator();
                        break;
                    }
                }
                if (penElementsIterator.hasNext()) {
                    IPenElement penElement = penElementsIterator.next();
                    if (penElement != null) {
                        currentPenElement = penElement;
                        break;
                    }
                }
            }
            return returnPenElement;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

    }

    /**
     * Дерева графических элементов по всем не групповым Элементам заливки.
     *
     */
    public static class ThroughBrushElementsIterator implements Iterator<IBrushElement> {

        /**
         * Итератор по графическим элементам.
         */
        private Iterator<IGraphElement> graphElementsIterator;
        /**
         * Текущий итератор по элементам заливки.
         */
        private Iterator<IBrushElement> brushElementsIterator;
        /**
         * Текущий элемент заливки.
         */
        private IBrushElement currentBrushElement;
        /**
         * Флаг прохождения только по редактируемым графическим элементам
         */
        private boolean onlyEditable;

        /**
         * @param graphElementsIterator Итератор по графическим элементам.
         */
        public ThroughBrushElementsIterator(Iterator<IGraphElement> graphElementsIterator) {
            this.graphElementsIterator = graphElementsIterator;
            this.onlyEditable = false;
            next();
        }

        /**
         * @param graphElementsIterator Итератор по графическим элементам.
         * @param onlyEditable          флаг прохождения только по редактируемым графическим элементам.
         */
        public ThroughBrushElementsIterator(Iterator<IGraphElement> graphElementsIterator, boolean onlyEditable) {
            this.graphElementsIterator = graphElementsIterator;
            this.onlyEditable = onlyEditable;
            next();
        }

        /**
         * @param graphElements Графические элементы.
         */
        public ThroughBrushElementsIterator(Collection<IGraphElement> graphElements) {
            this(graphElements.iterator());
        }

        @Override
        public boolean hasNext() {
            return currentBrushElement != null;
        }

        @Override
        public IBrushElement next() {
            IBrushElement returnBrushElement = currentBrushElement;
            currentBrushElement = null;
            ce:
            while (currentBrushElement == null) {
                while (brushElementsIterator == null || !brushElementsIterator.hasNext()) {
                    if (!graphElementsIterator.hasNext()) break ce;
                    IGraphElement graphElement = graphElementsIterator.next();

                    if (onlyEditable && !graphElement.isEditable())
                        continue;

                    IBrush brush = graphElement.getBrush();
                    if (brush != null) {
                        brushElementsIterator = brush.getElements().iterator();
                        break;
                    }
                }
                if (brushElementsIterator.hasNext()) {
                    IBrushElement brushElement = brushElementsIterator.next();
                    if (brushElement != null) {
                        currentBrushElement = brushElement;
                        break;
                    }
                }
            }
            return returnBrushElement;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

    }

    /**
     * Итератор Дерева графических элементов по всем не групповым Текстам.
     *
     */
    public static class ThroughTextIterator implements Iterator<IText> {

        /**
         * Итератор по графическим элементам.
         */
        private Iterator<IGraphElement> graphElementsIterator;
        /**
         * Текущий текст.
         */
        private IText currentText;
        /**
         * Флаг прохождения только по редактируемым графическим элементам
         */
        private boolean onlyEditable;

        /**
         * @param graphElementsIterator Итератор по графическим элементам.
         */
        public ThroughTextIterator(Iterator<IGraphElement> graphElementsIterator) {
            this.graphElementsIterator = graphElementsIterator;
            this.onlyEditable = false;
            next();
        }

        /**
         * @param graphElementsIterator Итератор по графическим элементам.
         * @param onlyEditable          флаг прохождения только по редактируемым графическим элементам.
         */
        public ThroughTextIterator(Iterator<IGraphElement> graphElementsIterator, boolean onlyEditable) {
            this.graphElementsIterator = graphElementsIterator;
            this.onlyEditable = onlyEditable;
            next();
        }

        /**
         * @param graphElements Графические элементы.
         */
        public ThroughTextIterator(Collection<IGraphElement> graphElements) {
            this(graphElements.iterator());
        }

        @Override
        public boolean hasNext() {
            return currentText != null;
        }

        @Override
        public IText next() {
            IText returnText = currentText;
            currentText = null;
            while (currentText == null) {
                if (!graphElementsIterator.hasNext()) break;
                IGraphElement graphElement = graphElementsIterator.next();

                if (onlyEditable && !graphElement.isEditable())
                    continue;

                IText text = graphElement.getText();
                if (text != null) {
                    currentText = text;
                    break;
                }
            }
            return returnText;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

    }


    /**
     * Групповое перо.
     *
     */
    private class SelfPen implements ISelfPen {

        /**
         * Список элементов пера.
         * <p>Содержит один элемент, когда список графических элементов не пуст
         * и не содержит ни одного элемента пера в противном случае.
         *
         */
        private class SelfElementsList extends AbstractList<IPenElement> implements IPenElementsList {

            /**
             * Групповой элемент пера.
             */
            private SelfPenElement element = new SelfPenElement();

            /** */
            public SelfElementsList() {
            }

            @Override
            public IPenElement get(int index) {
                int size = size();
                if (index < 0 || index >= size)
                    throw GeometryUtils.createIndexOutOfBoundsException(index, size);
                return element;
            }

            @Override
            public int size() {
                Iterator<IPenElement> iterator = new SelfPenElementIterator(false);
                return iterator.hasNext() ? 1 : 0;
            }

            @Override
            public boolean isEditable() {
                return false;
            }
        }


        /**
         * Элементы пера.
         */
        private IPen.IPenElementsList elements = new SelfElementsList();


        /** */
        public SelfPen() {
        }


        @Override
        public AbstractGroupGraphElement.SelfPen clone() {
            throw new UnsupportedOperationException();
        }


        @Override
        public IPen.IPenElementsList getElements() {
            return elements;
        }

        @Override
        public Iterator<IPenElement> getThroughIterator() {
            return new ThroughPenElementsIterator(new ThroughGraphElementsIterator(AbstractGroupGraphElement.this.getElements().iterator()));
        }

    }


    /**
     * Групповой элемент пера.
     *
     */
    private class SelfPenElement implements IPenElement {

        /** */
        public SelfPenElement() {
        }


        @Override
        public AbstractGroupGraphElement.SelfPenElement clone() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void init(IPenElement penElement) {
            throw new UnsupportedOperationException();
        }


        @Override
        public int getColor() {
            Iterator<IPenElement> iterator = new SelfPenElementIterator();
            return iterator.hasNext() ? iterator.next().getColor() : 0x00000000;
        }

        @Override
        public void setColor(int color, int mask) {
            Iterator<IPenElement> iterator = new SelfPenElementIterator(editable);

            while (iterator.hasNext())
                iterator.next().setColor(color, mask);
        }

        @Override
        public double getWidth() {
            Iterator<IPenElement> iterator = new SelfPenElementIterator();
            return iterator.hasNext() ? iterator.next().getWidth() : 0.0;
        }

        @Override
        public void setWidth(double width) {
            Iterator<IPenElement> iterator = new SelfPenElementIterator(editable);

            while (iterator.hasNext())
                iterator.next().setWidth(width);
        }

        @Override
        public double getShift() {
            Iterator<IPenElement> iterator = new SelfPenElementIterator();
            return iterator.hasNext() ? iterator.next().getShift() : 0.0;
        }

        @Override
        public void setShift(double shift) {
            Iterator<IPenElement> iterator = new SelfPenElementIterator(editable);

            while (iterator.hasNext())
                iterator.next().setShift(shift);
        }

        @Override
        public double getStrip() {
            Iterator<IPenElement> iterator = new SelfPenElementIterator();
            return iterator.hasNext() ? iterator.next().getStrip() : 0.0;
        }

        @Override
        public void setStrip(double strip) {
            Iterator<IPenElement> iterator = new SelfPenElementIterator(editable);

            while (iterator.hasNext())
                iterator.next().setStrip(strip);
        }

        @Override
        public IPenCore getCore() {
            Iterator<IPenElement> iterator = new SelfPenElementIterator();
            return iterator.hasNext() ? iterator.next().getCore() : null;
        }


        @Override
        public void setCore(IPenCore core) {
            Iterator<IPenElement> iterator = new SelfPenElementIterator(editable);

            while (iterator.hasNext())
                iterator.next().setCore(core.clone());
        }


        @Override
        public GeometryDefaults.LineCapType getCap() {
            Iterator<IPenElement> iterator = new SelfPenElementIterator();
            return iterator.hasNext() ? iterator.next().getCap() : null;
        }


        @Override
        public void setCap(GeometryDefaults.LineCapType cap) {
            Iterator<IPenElement> iterator = new SelfPenElementIterator(editable);

            while (iterator.hasNext())
                iterator.next().setCap(cap);
        }


        @Override
        public GeometryDefaults.LinesJoinType getJoin() {
            Iterator<IPenElement> iterator = new SelfPenElementIterator();
            return iterator.hasNext() ? iterator.next().getJoin() : null;
        }


        @Override
        public void setJoin(GeometryDefaults.LinesJoinType join) {
            Iterator<IPenElement> iterator = new SelfPenElementIterator(editable);

            while (iterator.hasNext())
                iterator.next().setJoin(join);
        }


        @Override
        public double getMiterLimit() {
            Iterator<IPenElement> iterator = new SelfPenElementIterator();
            return iterator.hasNext() ? iterator.next().getMiterLimit() : null;
        }


        @Override
        public void setMiterLimit(double miterLimit) {
            Iterator<IPenElement> iterator = new SelfPenElementIterator(editable);

            while (iterator.hasNext())
                iterator.next().setMiterLimit(miterLimit);
        }


        @Override
        public GeometryDefaults.LineArrowType getBeginArrow() {
            Iterator<IPenElement> iterator = new SelfPenElementIterator();
            return iterator.hasNext() ? iterator.next().getBeginArrow() : null;
        }


        @Override
        public void setBeginArrow(GeometryDefaults.LineArrowType arrow) {
            Iterator<IPenElement> iterator = new SelfPenElementIterator(editable);

            while (iterator.hasNext())
                iterator.next().setBeginArrow(arrow);
        }


        @Override
        public GeometryDefaults.LineArrowType getEndArrow() {
            Iterator<IPenElement> iterator = new SelfPenElementIterator();
            return iterator.hasNext() ? iterator.next().getEndArrow() : null;
        }


        @Override
        public void setEndArrow(GeometryDefaults.LineArrowType arrow) {
            Iterator<IPenElement> iterator = new SelfPenElementIterator(editable);

            while (iterator.hasNext())
                iterator.next().setEndArrow(arrow);
        }

    }


    /**
     * Итератор по всем элементам пера графических элементов.
     *
     */
    private class SelfPenElementIterator implements Iterator<IPenElement> {

        /**
         * Итератор по графическим элементам.
         */
        private Iterator<IGraphElement> graphElementIterator;
        /**
         * Итератор по элементам пера графического элемента.
         */
        private Iterator<IPenElement> penElementIterator;
        /**
         * Следующий элемент пера.
         */
        private IPenElement penElement;
        /**
         * Флаг прохождения только по редактируемым графическим элементам.
         */
        private boolean onlyEditable;

        /**  */
        public SelfPenElementIterator() {
            graphElementIterator = AbstractGroupGraphElement.this.getElements().iterator();
            this.onlyEditable = false;
            next();
        }

        /**
         * @param onlyEditable флаг прохождения только по редактируемым графическим элементам.
         **/
        public SelfPenElementIterator(boolean onlyEditable) {
            graphElementIterator = AbstractGroupGraphElement.this.getElements().iterator();
            this.onlyEditable = onlyEditable;
            next();
        }

        @Override
        public boolean hasNext() {
            return penElement != null;
        }

        @Override
        public IPenElement next() {
            IPenElement currentPenElement = penElement;

            penElement = null;
            if (penElementIterator != null && penElementIterator.hasNext()) {
                penElement = penElementIterator.next();
            } else {
                penElementIterator = null;
                while (graphElementIterator.hasNext()) {
                    IGraphElement gElement = graphElementIterator.next();
                    if (onlyEditable && !gElement.isEditable())
                        continue;

                    IPen pen = gElement.getPen();
                    if (pen != null) {
                        penElementIterator = pen.getElements().iterator();
                        if (penElementIterator.hasNext()) {
                            penElement = penElementIterator.next();
                            break;
                        } else {
                            penElementIterator = null;
                        }
                    }
                }
            }

            return currentPenElement;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }


    /**
     * Групповая заливка.
     *
     */
    private class SelfBrush implements ISelfBrush {

        /**
         * Список элементов заливки.
         *
         */
        private class SelfElementsList extends AbstractList<IBrushElement> implements IBrush.IBrushElementsList {

            /**
             * Элемент заливки.
             */
            private SelfBrushElement element = new SelfBrushElement();

            /** */
            public SelfElementsList() {
            }

            @Override
            public IBrushElement get(int index) {
                int size = size();
                if (index < 0 || index >= size)
                    throw GeometryUtils.createIndexOutOfBoundsException(index, size);
                return element;
            }

            @Override
            public int size() {
                Iterator<IBrushElement> iterator = new SelfBrushElementIterator(false);
                return iterator.hasNext() ? 1 : 0;
            }

            @Override
            public boolean isEditable() {
                return false;
            }
        }


        /**
         * Элементы заливки.
         */
        private IBrushElementsList elements = new SelfElementsList();


        /** */
        public SelfBrush() {
        }


        @Override
        public AbstractGroupGraphElement.SelfBrush clone() {
            throw new UnsupportedOperationException();
        }


        @Override
        public IBrushElementsList getElements() {
            return elements;
        }

        @Override
        public Iterator<IBrushElement> getThroughIterator() {
            return new ThroughBrushElementsIterator(
                    new ThroughGraphElementsIterator(
                            AbstractGroupGraphElement.this.getElements().iterator(),
                            false,
                            true));
        }

    }


    /**
     * Групповой элементы заливки.
     *
     */
    private class SelfBrushElement implements IBrushElement {

        /** */
        public SelfBrushElement() {
        }


        @Override
        public AbstractGroupGraphElement.SelfBrushElement clone() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void init(IBrushElement brushElement) {
            throw new UnsupportedOperationException();
        }


        @Override
        public int getColor() {
            Iterator<IBrushElement> iterator = new SelfBrushElementIterator();
            return iterator.hasNext() ? iterator.next().getColor() : 0x00000000;
        }

        @Override
        public void setColor(int color, int mask) {
            Iterator<IBrushElement> iterator = new SelfBrushElementIterator(editable);

            while (iterator.hasNext())
                iterator.next().setColor(color, mask);
        }

        @Override
        public IBrushCore getCore() {
            Iterator<IBrushElement> iterator = new SelfBrushElementIterator();
            return iterator.hasNext() ? iterator.next().getCore() : null;
        }

        @Override
        public void setCore(IBrushCore core) {
            Iterator<IBrushElement> iterator = new SelfBrushElementIterator(editable);

            while (iterator.hasNext())
                iterator.next().setCore(core.clone());
        }


        @Override
        public double getAngle() {
            Iterator<IBrushElement> iterator = new SelfBrushElementIterator();
            return iterator.hasNext() ? iterator.next().getAngle() : 0.0;
        }


        @Override
        public void setAngle(double angle) {
            Iterator<IBrushElement> iterator = new SelfBrushElementIterator(editable);
            while (iterator.hasNext())
                iterator.next().setAngle(angle);
        }

    }


    /**
     * Итератор по всем элементам заливки графических элементов.
     *
     */
    private class SelfBrushElementIterator implements Iterator<IBrushElement> {

        /**
         * Итератор по графическим элементам.
         */
        private Iterator<IGraphElement> graphElementIterator;
        /**
         * Итератор по элементам заливки.
         */
        private Iterator<IBrushElement> brushElementIterator;
        /**
         * Следующий элемент заливки.
         */
        private IBrushElement brushElement;
        /**
         * Флаг прохождения только по редактируемым графическим элементам.
         */
        private boolean onlyEditable;


        /** */
        public SelfBrushElementIterator() {
            graphElementIterator = AbstractGroupGraphElement.this.getElements().iterator();
            this.onlyEditable = false;
            next();
        }

        /**
         * @param onlyEditable флаг прохождения только по редактируемым графическим элементам.
         **/
        public SelfBrushElementIterator(boolean onlyEditable) {
            graphElementIterator = AbstractGroupGraphElement.this.getElements().iterator();
            this.onlyEditable = onlyEditable;
            next();
        }

        @Override
        public boolean hasNext() {
            return brushElement != null;
        }

        @Override
        public synchronized IBrushElement next() {
            IBrushElement currentBrushElement = brushElement;

            brushElement = null;
            if (brushElementIterator != null && brushElementIterator.hasNext()) {
                brushElement = brushElementIterator.next();
            } else {
                brushElementIterator = null;
                while (graphElementIterator.hasNext()) {
                    IGraphElement gElement = graphElementIterator.next();

                    if (onlyEditable && !gElement.isEditable())
                        continue;

                    IBrush brush = gElement.getBrush();
                    if (brush != null) {
                        brushElementIterator = brush.getElements().iterator();
                        if (brushElementIterator.hasNext()) {
                            brushElement = brushElementIterator.next();
                            break;
                        } else {
                            brushElementIterator = null;
                        }
                    }
                }
            }

            return currentBrushElement;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

    }


    /**
     * Групповое перо.
     */
    private SelfPen pen = new SelfPen();
    /**
     * Групповое перо.
     */
    private SelfBrush brush = new SelfBrush();


    /***/
    public AbstractGroupGraphElement() {
        this("Группа");
    }

    /**
     * @param name Название графического элемента.
     */
    public AbstractGroupGraphElement(String name) {
        this.name = name;
        this.id = UUID.randomUUID().toString();
    }


    @Override
    public AbstractGroupGraphElement clone() {
        AbstractGroupGraphElement clonedObject = (AbstractGroupGraphElement) super.clone();

        clonedObject.pen = clonedObject.new SelfPen();
        clonedObject.brush = clonedObject.new SelfBrush();

        return clonedObject;
    }


    @Override
    public IPen getPen() {
        return pen;
    }

    @Override
    public void setPen(IPen pen) {
        throw new UnsupportedOperationException();
    }

    @Override
    public IBrush getBrush() {
        return brush;
    }

    @Override
    public void setBrush(IBrush brush) {
        throw new UnsupportedOperationException();
    }

    @Override
    public IText getText() {
        return null;
    }

    @Override
    public void setText(IText text) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean isSmooth() {
        for (IGraphElement ge : getElements())
            if (ge instanceof ILineGraphElement)
                return ((ILineGraphElement) ge).isSmooth();
        return false;
    }

    @Override
    public void setSmooth(boolean smooth) {
        for (IGraphElement ge : getElements())
            if (ge instanceof ILineGraphElement)
                ((ILineGraphElement) ge).setSmooth(smooth);
    }

    @Override
    public boolean isClosed() {
        for (IGraphElement ge : getElements())
            if (ge instanceof ILineGraphElement)
                return ((ILineGraphElement) ge).isClosed();
        return false;
    }

    @Override
    public void setClosed(boolean closed) {
        for (IGraphElement ge : getElements())
            if (ge instanceof ILineGraphElement)
                ((ILineGraphElement) ge).setClosed(closed);
    }

    @Override
    public double getBeginAngle() {
        for (IGraphElement ge : getElements())
            if (ge instanceof ICircleGraphElement)
                return ((ICircleGraphElement) ge).getBeginAngle();
        return 0.0;
    }

    @Override
    public void setBeginAngle(double beginAngle) {
        for (IGraphElement ge : getElements())
            if (ge instanceof ICircleGraphElement)
                ((ICircleGraphElement) ge).setBeginAngle(beginAngle);
    }

    @Override
    public double getEndAngle() {
        for (IGraphElement ge : getElements())
            if (ge instanceof ICircleGraphElement)
                return ((ICircleGraphElement) ge).getBeginAngle();
        return 0.0;
    }

    @Override
    public void setEndAngle(double endAngle) {
        for (IGraphElement ge : getElements())
            if (ge instanceof ICircleGraphElement)
                ((ICircleGraphElement) ge).setEndAngle(endAngle);
    }


    @Override
    public abstract List<IGraphElement> getElements();

}
