package vg.sign.edit.api;

import vg.geometry.primitives.BasePoint2D;
import vg.sign.visual.api.ISignVisual;

import java.util.List;

/**
 * Средства редактирования ЭУЗ ОО.
 */
public interface ISignEditor {

    /**
     * Получить контрольные точки.
     *
     * @return Контрольные точки.
     */
    public List<IControlPoint> getControlPoints();

    /**
     * Расчитать редактор.
     */
    public void calculate();

    /**
     * Получить визуальное представление.
     *
     * @return Визуальное представление.
     */
    public ISignVisual getSignVisual();

    /**
     * Переместить знак.
     *
     * @param translation точка перемещения.
     */
    public void translate(BasePoint2D translation);

    /**
     * Повернуть знак.
     *
     * @param angle  угол поворота.
     * @param center центр поворота.
     */
    public void rotate(double angle, BasePoint2D center);

    /**
     * Масштабировать знак.
     *
     * @param center центр масштабирования.
     * @param scale  коэффициент масштабирования.
     * @param angle  направление масштабирования.
     */
    public void scale(BasePoint2D center, BasePoint2D scale, double angle);

    /**
     * Отобразить зеркально знак.
     */
    public void mirror();

}

