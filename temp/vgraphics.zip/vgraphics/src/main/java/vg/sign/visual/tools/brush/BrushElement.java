package vg.sign.visual.tools.brush;

import vg.draw.Colors;
import vg.sign.visual.api.IBrushCore;
import vg.sign.visual.api.IBrushElement;

/**
 * Сплошная заливка.
 */

public class BrushElement implements IBrushElement {

    /**
     * Основа заливки.
     */
    private IBrushCore core;
    /**
     * Цвет заливки.
     */
    private int color;
    /**
     * Угол в радианах.
     */
    private double angle;


    /**
     * Конструктор чёрной непрозрачной заливки.
     */
    public BrushElement() {
        this(new SolidBrushCore(), 0xFF000000);
    }

    /**
     * @param core Основа заливки.
     */
    public BrushElement(IBrushCore core) {
        this(core, 0xFF000000, 0.0);
    }

    /**
     * @param core  Основа заливки.
     * @param color Цвет.
     */
    public BrushElement(IBrushCore core, int color) {
        this(core, color, 0.0);
    }

    /**
     * @param core  Основа заливки.
     * @param color Цвет.
     * @param angle Угол (рад.)
     */
    public BrushElement(IBrushCore core, int color, double angle) {
        this.core = core;
        this.color = color;
        this.angle = angle;
    }


    @Override
    public BrushElement clone() {
        try {
            BrushElement clonedObject = (BrushElement) super.clone();
            clonedObject.core = core.clone();
            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void init(IBrushElement brushElement) {
        this.color = brushElement.getColor();
        this.angle = brushElement.getAngle();
        this.core = brushElement.getCore().clone();
    }


    @Override
    public int getColor() {
        return color;
    }

    @Override
    public void setColor(int color, int mask) {
        this.color = Colors.setColor(this.color, color, mask);
    }

    @Override
    public IBrushCore getCore() {
        return core;
    }

    @Override
    public void setCore(IBrushCore core) {
        this.core = core;
    }

    @Override
    public double getAngle() {
        return angle;
    }

    @Override
    public void setAngle(double angle) {
        this.angle = angle;
    }

}
