package vg.sign.visual.signs;

import vg.sign.visual.api.*;
import vg.sign.visual.tools.AbstractSignVisual;
import vg.sign.visual.tools.AnchorPointsList;
import vg.sign.visual.tools.RootGraphElement;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Визуальное представление линейного знака.
 *
 */
public class LineSignVisual extends AbstractSignVisual {

    /**
     * Список графических элементов Линейного ЭУЗ.
     *
     */
    private class SelfLineGraphElementsList extends AbstractList<IGraphElement> {

        /**
         * Линейный графический элемент Линейного ЭУЗ.
         */
        SelfLineGraphElement selfLineGraphElement = new SelfLineGraphElement();

        /***/
        public SelfLineGraphElementsList() {
        }

        @Override
        public int size() {
            return 1 + linkedSigns.size();
        }

        @Override
        public IGraphElement get(int index) {
            switch (index) {
                case 0:
                    return selfLineGraphElement;
                default:
                    return linkedSigns.get(index - 1).getSign().getRootGraphElement();
            }
        }

    }

    /**
     * Линейный графический элемент Линейного ЭУЗ.
     *
     */
    private class SelfLineGraphElement implements ILineGraphElement {

        /**
         * Название графического элемента
         */
        protected String name = "Фигура";
        /**
         * ID.
         */
        private String id;


        /***/
        public SelfLineGraphElement() {
            this.id = UUID.randomUUID().toString();
        }


        @Override
        public LineSignVisual.SelfLineGraphElement clone() {
            try {
                LineSignVisual.SelfLineGraphElement clonedObject = (LineSignVisual.SelfLineGraphElement) super.clone();
                clonedObject.id = id;
                return clonedObject;
            } catch (CloneNotSupportedException ex) {
                throw new RuntimeException(ex);
            }
        }

        @Override
        public boolean isVisible() {
            return lineVisible;
        }

        @Override
        public void setVisible(boolean visible) {
            lineVisible = visible;
        }

        @Override
        public boolean isEditable() {
            return editable;
        }

        @Override
        public void setEditable(boolean editable) {
            LineSignVisual.this.editable = editable;
        }

        @Override
        public IPen getPen() {
            return LineSignVisual.this.pen;
        }

        @Override
        public void setPen(IPen pen) {
            LineSignVisual.this.pen = pen;
        }

        @Override
        public IBrush getBrush() {
            return null;
        }

        @Override
        public void setBrush(IBrush brush) {
        }

        @Override
        public IText getText() {
            return null;
        }

        @Override
        public void setText(IText text) {
        }

        @Override
        public boolean isSmooth() {
            return LineSignVisual.this.smooth;
        }

        @Override
        public void setSmooth(boolean smooth) {
            LineSignVisual.this.smooth = smooth;
        }

        @Override
        public boolean isClosed() {
            return false;
        }

        @Override
        public void setClosed(boolean closed) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getName() {
            return this.name;
        }

        @Override
        public void setName(String name) {
            this.name = name;
        }

        @Override
        public String getId() {
            return id;
        }

        @Override
        public void setId(String id) {
            this.id = id;
        }

    }


    /**
     * Разрыв линии.
     *
     */
    public static class LineBreak implements Cloneable {

        /**
         * Положение центра разрыва.
         */
        private double position;
        /**
         * Ширина разрыва.
         */
        private double width;


        /***/
        public LineBreak() {
            this(0.0, 0.0);
        }

        /**
         * @param position Положение центра ([0; 1]).
         * @param width    Длина (мм).
         */
        public LineBreak(double position, double width) {
            this.position = position;
            this.width = width;
        }


        /**
         * Клонировать.
         *
         * @return Клон.
         */
        public LineSignVisual.LineBreak clone() {
            try {
                LineSignVisual.LineBreak clonedObject = (LineSignVisual.LineBreak) super.clone();
                return clonedObject;
            } catch (CloneNotSupportedException ex) {
                throw new RuntimeException(ex);
            }
        }

        /**
         * Получить положение центра.
         *
         * @return Положение центра (%).
         */
        public double getPosition() {
            return position;
        }

        /**
         * Задать положение центра.
         *
         * @param position Положение центра (%).
         */
        public void setPosition(double position) {
            this.position = position;
        }

        /**
         * Получить ширину.
         *
         * @return Ширина (мм).
         */
        public double getWidth() {
            return width;
        }

        /**
         * Задать ширину.
         *
         * @param width Ширина (мм).
         */
        public void setWidth(double width) {
            this.width = width;
        }

    }


    /**
     * Присоединённый к линейному знаку точечный знак.
     *
     */
    public static class LinkedSign implements Cloneable {

        /**
         * Знак.
         */
        private PointSignVisual sign;
        /**
         * Положение знака (%).
         */
        private double position;
        /**
         * Угол наклона знака от нормали (рад).
         */
        private double angle;
        /**
         * Флаг удерживания знака сверху линии.
         */
        private boolean keepOnTop = false;


        /***/
        public LinkedSign() {
            this(null, 0.0, 0.0);
        }

        /**
         * @param sign     Знак.
         * @param position Положение знака (%).
         * @param angle    Угол наклона знака от нормали (рад).
         */
        public LinkedSign(PointSignVisual sign, double position, double angle) {
            this.sign = sign;
            this.position = position;
            this.angle = angle;
        }


        /**
         * Клонирование.
         *
         * @return Клон.
         */
        public LineSignVisual.LinkedSign clone() {
            try {
                LineSignVisual.LinkedSign clonedObject = (LineSignVisual.LinkedSign) super.clone();

                clonedObject.sign = sign.clone();

                return clonedObject;
            } catch (CloneNotSupportedException ex) {
                throw new RuntimeException(ex);
            }
        }

        /**
         * Получить знак.
         *
         * @return Знак.
         */
        public PointSignVisual getSign() {
            return sign;
        }

        /**
         * Задать знак.
         *
         * @param sign Знак.
         */
        public void setSign(PointSignVisual sign) {
            this.sign = sign;
        }

        /**
         * Получить положение знака.
         *
         * @return Положение знака (%).
         */
        public double getPosition() {
            return position;
        }

        /**
         * Задать положение знака.
         *
         * @param position Положение знака (%).
         */
        public void setPosition(double position) {
            this.position = position;
        }

        /**
         * Получить угол наклона знака от нормали.
         *
         * @return Угол наклона знака от нормали (рад).
         */
        public double getAngle() {
            return angle;
        }

        /**
         * Задать угол наклона знака от нормали.
         *
         * @param angle Угол наклона знака от нормали (рад).
         */
        public void setAngle(double angle) {
            this.angle = angle;
        }

        /**
         * Флаг удержания знака с верхней стороны линии.
         *
         * @return true - знак удерживается с верхней стороны линии, false - иначе.
         */
        public boolean isKeepOnTop() {
            return this.keepOnTop;
        }

        /**
         * Установить флаг удержания знака с верхней стороны линии.
         *
         * @param keepOnTop флаг удержания знака с верхней стороны линии.
         */
        public void setKeepOnTop(boolean keepOnTop) {
            this.keepOnTop = keepOnTop;
        }

    }


    /**
     * Гладкость.
     */
    boolean smooth = false;
    /**
     * Перо.
     */
    IPen pen = null;
    // TODO Рассмотреть возможность переноса lineVisible в SelfLineGraphElement.
    /**
     * Видимость основного линейного графического элемента.
     */
    boolean lineVisible = true;
    /**
     * Редактируемость основного линейного графического элемента.
     */
    boolean editable = true;
    /**
     * Разрывы.
     */
    List<LineBreak> lineBreaks = new ArrayList<LineBreak>();
    /**
     * Список встроенных знаков.
     */
    List<LinkedSign> linkedSigns = new ArrayList<LinkedSign>();


    /***/
    public LineSignVisual() {
        anchorPoints = new AnchorPointsList(2, Integer.MAX_VALUE);
        rootGraphElement = new RootGraphElement(
                "Линейный ЭУЗ",
                this,
                new SelfLineGraphElementsList());
    }


    @Override
    public LineSignVisual clone() {
        LineSignVisual clonedObject = (LineSignVisual) super.clone();

        if (pen != null)
            clonedObject.pen = pen.clone();

        clonedObject.lineBreaks = new ArrayList<LineBreak>();
        for (LineBreak lb : lineBreaks)
            clonedObject.lineBreaks.add(lb.clone());

        clonedObject.linkedSigns = new ArrayList<LinkedSign>();
        for (LinkedSign ls : linkedSigns)
            clonedObject.linkedSigns.add(ls.clone());

        clonedObject.rootGraphElement = new RootGraphElement(
                "Линейный ЭУЗ",
                clonedObject,
                clonedObject.new SelfLineGraphElementsList());

        return clonedObject;
    }


    /**
     * Получить сглаженность линии.
     *
     * @return Сглаженность линии.
     */
    public boolean isSmooth() {
        return smooth;
    }

    /**
     * Задать сглаженность линии.
     *
     * @param smooth Сглаженность линии.
     */
    public void setSmooth(boolean smooth) {
        this.smooth = smooth;
    }

    /**
     * Получить перо линии.
     *
     * @return Перо линии.
     */
    public IPen getPen() {
        return pen;
    }

    /**
     * Задать перо линии.
     *
     * @param pen Перо линии.
     */
    public void setPen(IPen pen) {
        this.pen = pen;
    }

    /**
     * Получить список разрывов линии.
     * <p>Через этот список можно управлять разрывами.
     *
     * @return Список разрывов линии.
     */
    public List<LineBreak> getLineBreaks() {
        return lineBreaks;
    }

    /**
     * Получить список присоединённых точечных знаков.
     * <p>Через этот список можно управлять присоединёнными точечными знаками.
     *
     * @return Список присоединённых точечных знаков.
     */
    public List<LinkedSign> getLinkedSigns() {
        return linkedSigns;
    }

    @Override
    public void createDefaultSemantics(int index, IAnchorPoint anchorPoint) {
    }

}
