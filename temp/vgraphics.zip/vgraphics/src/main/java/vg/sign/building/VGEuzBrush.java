package vg.sign.building;

import vg.draw.painting.IPainter;
import vg.draw.vobject.VGBrush;
import vg.draw.vobject.VGGroup;
import vg.geometry.GeometryProcessor;
import vg.geometry.primitives.BaseFrame2D;
import vg.geometry.primitives.BasePoint2D;
import vg.geometry.primitives.BaseRectangle2D;
import vg.sign.building.builders.PointGraphBuilder;
import vg.sign.visual.signs.PointSignVisual;

import java.util.List;

/**
 * Кисть на основе ЭУЗ графической подсистемы.
 */
public class VGEuzBrush implements VGBrush {

    /**
     * Знак.
     */
    private VGGroup image;
//	/**
//	 * Смещение точки привязки внутри изображения знака
//	 * относительно левого верхнего угла.
//	 */
//	private IPoint2D shift;


    /**
     * @param sv ЭУЗ.
     */
    public VGEuzBrush(PointSignVisual sv) {
        PointSignVisual clone = sv.clone();
        if (clone.getAnchorPoints().isEmpty()) {
            clone.getAnchorPoints().add(new BasePoint2D());
        } else {
            clone.getAnchorPoints().set(0, new BasePoint2D());
        }
        PointGraphBuilder pb = new PointGraphBuilder();
        this.image = pb.buildGraphics(clone);
    }


    @Override
    public int hashCode() {
        int result = 17;
        result = result * 7 + image.hashCode();
        return result;
    }


    @Override
    public void paint(IPainter painter, List<BasePoint2D> points) {
        BaseRectangle2D segmentBounds = image.getBounds();
        BasePoint2D segmentSize = new BasePoint2D(segmentBounds.getWidth(), segmentBounds.getHeight());
        BaseRectangle2D euzBounds = new BaseRectangle2D();
        euzBounds.init(new BaseFrame2D().union(points));
        BasePoint2D basePoint = euzBounds.getTLP();
        for (int i = 0; i < euzBounds.getWidth() / segmentSize.getX(); i++) {
            for (int j = 0; j < euzBounds.getHeight() / segmentSize.getY(); j++) {
                BasePoint2D currentPoint = new BasePoint2D(basePoint.getX() + (segmentSize.getX() * (double) i),
                        basePoint.getY() + (segmentSize.getY() * (double) j));
                if (GeometryProcessor.isPointInsidePolygon(currentPoint, points)) {
                    painter.pushTransform();
                    painter.translate(currentPoint.getX(), currentPoint.getY());
                    image.paint(painter);
                    painter.popTransform();
                }
            }
        }
    }

}
