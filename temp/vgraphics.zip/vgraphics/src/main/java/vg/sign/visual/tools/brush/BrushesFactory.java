package vg.sign.visual.tools.brush;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Factory for creating brushes of different styles.
 * Created by gusevdm on 11/23/2016.
 */

public final class BrushesFactory {

    private static final Log LOG = LogFactory.getLog(BrushesFactory.class);

    static {
        LOG.debug("BrushesFactory loaded.");
    }

    private BrushesFactory() {} // non-instantiability

}
