package vg.sign.building;

import vg.draw.painting.IPainter;
import vg.draw.vobject.VGGroup;
import vg.draw.vobject.VGPen;
import vg.geometry.GeometryProcessor;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.building.builders.PointGraphBuilder;
import vg.sign.visual.signs.PointSignVisual;

import java.util.List;

/**
 * Перо на основе ЭУЗ графической подсистемы.
 */
public class VGEuzPen implements VGPen {

    /**
     * Знак.
     */
    private VGGroup image;


    /**
     * @param sv Изображение знака.
     */
    public VGEuzPen(PointSignVisual sv) {
        PointGraphBuilder pb = new PointGraphBuilder();
        this.image = pb.buildGraphics(sv);
    }


    @Override
    public int hashCode() {
        int result = 17;
        result = result * 7 + image.hashCode();
        return result;
    }


    @Override
    public void paint(IPainter painter, List<BasePoint2D> points) {
        double width = image.getBounds().getWidth();
        double lineLength = GeometryProcessor.getPolylineLength(points);
        int svNum = (int) (lineLength / width);
        double stepLength = lineLength / (double) svNum;
        for (int i = 0; i < svNum; i++) {
            // TODO оптимизировать
            BasePoint2D location = GeometryProcessor.getPointOnPolylineByShift(points, ((double) i * stepLength) / lineLength);
            double angle = GeometryProcessor.getPolylineTangentAngle(points, ((double) i * stepLength) / lineLength);
            painter.pushTransform();
            painter.translate(location.getX(), location.getY());
            painter.rotate(angle);
            image.paint(painter);
            painter.popTransform();
        }
    }

}
