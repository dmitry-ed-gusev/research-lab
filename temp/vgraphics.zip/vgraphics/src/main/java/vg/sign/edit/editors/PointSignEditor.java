package vg.sign.edit.editors;

import vg.geometry.GeometryUtils;
import vg.geometry.cp.AbstractCPoint;
import vg.geometry.cp.CPCalculator;
import vg.geometry.cp.CPoint;
import vg.geometry.primitives.BaseFrame2D;
import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.edit.api.IControlPoint;
import vg.sign.edit.api.IPredefinedControlPoint;
import vg.sign.visual.api.ICircleGraphElement;
import vg.sign.visual.api.IGraphElement;
import vg.sign.visual.signs.PointSignVisual;

import java.util.*;

/**
 * Редактор точечного знака.
 */
public class PointSignEditor extends AbstractSignEditor {

    /**
     * Контрольная точка, управляющаяя предопределённой точкой.
     *
     */
    public static class PredefinedControlPoint extends AbstractCPoint implements IControlPoint, IPredefinedControlPoint {

        /**
         * Набор зависимостей точки.
         *
         */
        private class SelfDependencies extends AbstractSet<CPoint> {

            /**
             * Итератор по единственной зависимости.
             *
             */
            private class SelfIterator implements Iterator<CPoint> {

                /**
                 * Индекс зависимости.
                 */
                int dependencyIndex = 0;

                /***/
                public SelfIterator() {
                }

                @Override
                public boolean hasNext() {
                    return dependencyIndex == 0;
                }

                @Override
                public CPoint next() {
                    if (dependencyIndex != 0) throw new NoSuchElementException();
                    dependencyIndex++;
                    return getPredefinedPoint();
                }

                @Override
                public void remove() {
                    throw new UnsupportedOperationException();
                }

            }

            /***/
            public SelfDependencies() {
            }

            @Override
            public int size() {
                return 1;
            }

            @Override
            public Iterator<CPoint> iterator() {
                return new SelfIterator();
            }
        }

        /***/
        private static final long serialVersionUID = -8469181535876742166L;

        /**
         * Визуальное представление знака.
         */
        PointSignVisual visual;
        /**
         * Индекс предопределённой точки.
         */
        int index;
        /**
         * Редактируемость контрольной точки
         */
        boolean editable;

        /**
         * @param visual   Визуальное представление знака.
         * @param index    Индекс предопределённой точки.
         * @param editable Редактируемость контрольной точки.
         */
        public PredefinedControlPoint(PointSignVisual visual, int index, boolean editable) {
            this.visual = visual;
            this.index = index;
            this.editable = editable;
            this.dependencies = new SelfDependencies();
        }

        @Override
        public String toString() {
            return String.format("PredefinedCP {%s}", visual.getPredefinedPoints().get(index));
        }

        @Override
        public CPoint calculate() {
            BaseMatrix2D toDocumentMatrix = visual.getToDocumentMatrix();
            CPoint cp = getPredefinedPoint();

            //point.init(toDocumentMatrix.transformPoint(new BasePoint2D(cp.getX(), cp.getY())));
            point = new BasePoint2D(toDocumentMatrix.transformPoint(new BasePoint2D(cp.getX(), cp.getY())));

            return this;
        }

        @Override
        public CPoint decalculate() {
            BaseMatrix2D fromDocumentMatrix = visual.getToDocumentMatrix().invert();
            BasePoint2D point = fromDocumentMatrix.transformPoint(this.point);
            PointSignVisual.AbstractPredefinedPoint predefinedPoint = getPredefinedPoint();
            predefinedPoint.setX(point.getX());
            predefinedPoint.setY(point.getY());
            predefinedPoint.decalculate();
            return this;
        }

        @Override
        public boolean isEditable() {
            return this.editable && getPredefinedPoint().isEditable();
        }

        /**
         * Установить редактируемость контрольнйо точки.
         *
         * @param editable редактируемость контрольной точки.
         */
        @Override
        public void setEditable(boolean editable) {
            this.editable = editable;
        }

        /**
         * Получить предопределённую точку.
         *
         * @return Предопределённая точка.
         */
        PointSignVisual.AbstractPredefinedPoint getPredefinedPoint() {
            return visual.getPredefinedPoints().get(index);
        }

        @Override
        public int getPredefinedPointIndex() {
            return index;
        }

        @Override
        public IControlPoint add() {
            return null;
        }

        @Override
        public boolean remove() {
            return false;
        }

    }


    /**
     * Контрольная точка, управляющая начальным и конечным углом дуги.
     *
     */
    public static class CircleAngleControlPoint extends AbstractCPoint implements IControlPoint {

        /** */
        private static final long serialVersionUID = -2085563453302542924L;
        /**
         * Графический элемент дуга.
         */
        ICircleGraphElement circleGraphElement;
        /**
         * Если индекс равен 1 - контрольная точка начального угла, 2 - конечного угла.
         */
        int index;
        /**
         * Визуальное представление знака.
         */
        PointSignVisual signVisual;


        /**
         * Конструктор.
         *
         * @param signVisual         Визуальное представление знака.
         * @param circleGraphElement Графический элемент дуга.
         * @param index              Индекс контрольной точки.
         */
        public CircleAngleControlPoint(PointSignVisual signVisual, ICircleGraphElement circleGraphElement, int index) {
            this.signVisual = signVisual;
            this.circleGraphElement = circleGraphElement;
            this.index = index;
        }

        @Override
        public boolean remove() {
            return false;
        }

        ;

        @Override
        public CPoint decalculate() {
            BaseMatrix2D fromDocumentMatrix = signVisual.getToDocumentMatrix().invert();
            BasePoint2D point = fromDocumentMatrix.transformPoint(this.point);
            BaseFrame2D frame2d = getFrame2D();
            BasePoint2D center = frame2d.getCenter();

            // Вычисляем координаты контрольной точки по данным.
            double curAngle = index == 1 ? circleGraphElement.getBeginAngle() : circleGraphElement.getEndAngle();
            BasePoint2D prevPoint = new BasePoint2D(center.getX() + frame2d.getWidth() / 2.0 * Math.cos(curAngle), center.getY() + frame2d.getHeight() / 2.0 * Math.sin(curAngle));

            double deltaAngle = GeometryUtils.angleBetweenPoints(point, center, prevPoint);
            deltaAngle = deltaAngle * (frame2d.getP1().getY() > frame2d.getP2().getY() ? -1 : 1) * (frame2d.getP2().getX() < frame2d.getP1().getX() ? -1 : 1);
            double angle = curAngle + deltaAngle;
            angle = GeometryUtils.mod(0, 2 * Math.PI, angle);

            if (index == 1)
                circleGraphElement.setBeginAngle(angle);
            else
                circleGraphElement.setEndAngle(angle);
            return this;
        }

        @Override
        public IControlPoint add() {
            return null;
        }

        @Override
        public CPoint calculate() {
            double a = index == 1 ? circleGraphElement.getBeginAngle() : circleGraphElement.getEndAngle();
            BaseFrame2D frame = getFrame2D();
            BasePoint2D center = frame.getCenter();
            BaseMatrix2D toDocumentMatrix = signVisual.getToDocumentMatrix();
            BasePoint2D origPoint = new BasePoint2D(center.getX() + frame.getWidth() / 2.0 * Math.cos(a), center.getY() + frame.getHeight() / 2.0 * Math.sin(a));

            //point.init(toDocumentMatrix.transformPoint(origPoint));
            point = new BasePoint2D(toDocumentMatrix.transformPoint(origPoint));
            return this;
        }

        @Override
        public boolean isEditable() {
            return circleGraphElement.isEditable();
        }

        /**
         * Получить описывающий фрейм для дуги.
         *
         * @return Фрейм.
         */
        protected BaseFrame2D getFrame2D() {
            List<PointSignVisual.AbstractPredefinedPoint> predefinedPoints = getPredefinedPointList();
            if (predefinedPoints == null) {
                return null;
            }
            CPoint cp1 = predefinedPoints.get(0);
            CPoint cp2 = predefinedPoints.get(1);
            return new BaseFrame2D(new BasePoint2D(cp1.getX(), cp1.getY()), new BasePoint2D(cp2.getX(), cp2.getY()));
        }

        /**
         * Получить список из двух предопределенных точек, описывающих фрейм дуги.
         *
         * @return Список предопределенных точек.
         */
        protected List<PointSignVisual.AbstractPredefinedPoint> getPredefinedPointList() {
            List<PointSignVisual.AbstractPredefinedPoint> predefinedPoints = signVisual.getPredefinedPoints();
            int graphElemIndex = signVisual.getGraphElements().indexOf(circleGraphElement);
            if (graphElemIndex != -1) {
                List<PointSignVisual.AbstractPredefinedPoint> points = new ArrayList<PointSignVisual.AbstractPredefinedPoint>();
                List<Integer> predefinedPointIndes = signVisual.getPredefinedPointIndices().get(graphElemIndex);
                if (predefinedPointIndes.size() == 2) {
                    for (Integer i : predefinedPointIndes)
                        points.add(predefinedPoints.get(i));
                    return points;
                }
            }
            return null;
        }
    }


    /**
     * @param visual Визуальное представление точечного знака.
     */
    public PointSignEditor(PointSignVisual visual) {
        super(visual);
    }


    @Override
    public PointSignVisual getSignVisual() {
        return (PointSignVisual) super.getSignVisual();
    }


    @Override
    public synchronized void calculate() {
        controlPoints.clear();
        for (int i = 0, n = getSignVisual().getPredefinedPoints().size(); i < n; i++) {
            controlPoints.add(new PredefinedControlPoint(getSignVisual(), i, this.isPointEditable(getSignVisual(), i)));
        }
        for (int i = 0, n = getSignVisual().getAnchorPoints().size(); i < n; i++) {
            controlPoints.add(new AnchorControlPoint(getSignVisual(), i));
        }

        List<IGraphElement> graphElementList = ((PointSignVisual) signVisual).getRootGraphElement().getElements();
        for (IGraphElement graphElement : graphElementList) {
            if (graphElement instanceof ICircleGraphElement) {
                PointSignVisual pointSignVisual = (PointSignVisual) signVisual;
                controlPoints.add(new CircleAngleControlPoint(pointSignVisual, (ICircleGraphElement) graphElement, 1));
                controlPoints.add(new CircleAngleControlPoint(pointSignVisual, (ICircleGraphElement) graphElement, 2));
            }
        }

        CPCalculator.calculate(controlPoints);
    }

    /**
     * Проверить принадлежит ли точка редактируемому графическому элементу.
     *
     * @param signVisual графическое представление знака.
     * @param pointIndex индекс предопределенной точки.
     * @return true, если предопределенная точка принадлежит редактируемому графическому элементу, false - иначе.
     */
    protected boolean isPointEditable(PointSignVisual signVisual, int pointIndex) {
        List<IGraphElement> elements = signVisual.getGraphElements();
        List<List<Integer>> indexes = signVisual.getPredefinedPointIndices();

        for (int i = 0; i < indexes.size(); ++i)
            if (indexes.get(i).contains(pointIndex) && !elements.get(i).isEditable())
                return false;

        return true;
    }
}
