package vg.sign.edit.api;


/**
 * Интерфес контрольной точки для управления предопределённой точкой.
 *
 * @author Giller
 */
public interface IPredefinedControlPoint {

    /**
     * Получить индекс предопределенной точки.
     *
     * @return Индекс Индекс предопределенной точки.
     */
    public int getPredefinedPointIndex();

    /**
     * Задать редактируемость точки.
     *
     * @param editable Редактируемость точки.
     */
    public void setEditable(boolean editable);
}
