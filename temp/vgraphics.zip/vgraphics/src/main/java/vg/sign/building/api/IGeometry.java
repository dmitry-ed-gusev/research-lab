package vg.sign.building.api;


/**
 * Интерфейс для работы с геометрическими параметрами.
 *
 * @author Giller
 */
public interface IGeometry {
    /**
     * Получить угол.
     *
     * @return угол.
     */
    public double getAngle();

    /**
     * Установить угол.
     *
     * @param angle угол.
     */
    public void setAngle(double angle);

    /**
     * Получить ширину.
     *
     * @return ширина.
     */
    public double getWidth();

    /**
     * Установить ширину.
     *
     * @param width ширина.
     */
    public void setWidth(double width);

    /**
     * Получить высоту.
     *
     * @return высота.
     */
    public double getHeight();

    /**
     * Установить высоту.
     *
     * @param height высота.
     */
    public void setHeight(double height);

    /**
     * Получить длину.
     *
     * @return длина.
     */
    public double getLength();

    /**
     * Установить длину.
     *
     * @param length длина.
     */
    public void setLength(double length);

    /**
     * Получить площадь.
     *
     * @return площадь.
     */
    public double getSpace();

    /**
     * Установить площадь.
     *
     * @param space площадь.
     */
    public void setSpace(double space);

    /**
     * Получить радиус.
     *
     * @return радиус.
     */
    public double getRadius();

    /**
     * Установить радиус.
     *
     * @param radius радиус.
     */
    public void setRadius(double radius);

    /**
     * Получить диагональ.
     *
     * @return диагональ.
     */
    public double getDiagonal();

    /**
     * Установить диагональ.
     *
     * @param diagonal диагональ.
     */
    public void setDiagonal(double diagonal);
}
