package vg.sign.building.modifiers;

import vg.geometry.GeometryProcessor;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.building.api.IDraftModePreModifier;
import vg.sign.edit.api.IControlPoint;
import vg.sign.edit.api.ILinkedSignAngleControlPoint;
import vg.sign.edit.api.IPositionControlPoint;
import vg.sign.edit.api.ISignEditor;
import vg.sign.visual.SignVisualFactory;
import vg.sign.visual.api.*;
import vg.sign.visual.signs.LineSignVisual;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Модификатор чернового отображения.
 * <p>Имеет следующий эффект:
 * <ol>
 * <li>Шаблонные перья и заливки переводятся в сплошные.
 * <li>Альфа канал устанавливается в FF, за исключением случая, когда он был 00.
 * <li>Сглаженые линии становятся ломаными.
 * <ol>
 *
 */
public class DraftModePreModifier extends AbstractPreModifier implements IDraftModePreModifier {

    /**
     * Правила редактирования знака.
     */
    private ISignEditor signEditor;


    @Override
    public void modify(ISignVisual visual) {
        IRootGraphElement rootGraphElement = visual.getRootGraphElement();

        rootGraphElement.setSmooth(false);

        Iterator<IPenElement> penElementsIterator =
                SignVisualFactory.createThroughPenElementIterator(
                        SignVisualFactory.createThroughGraphElementIterator(
                                rootGraphElement.getElements().iterator()));
        while (penElementsIterator.hasNext()) {
            modifyPenElement(penElementsIterator.next());
        }

        Iterator<IBrushElement> brushElementsIterator =
                SignVisualFactory.createThroughBrushElementIterator(
                        SignVisualFactory.createThroughGraphElementIterator(
                                rootGraphElement.getElements().iterator()));
        while (brushElementsIterator.hasNext()) {
            modifyBrushElement(brushElementsIterator.next());
        }

        Iterator<IText> textElementsIterator =
                SignVisualFactory.createThroughTextIterator(
                        SignVisualFactory.createThroughGraphElementIterator(
                                rootGraphElement.getElements().iterator()));
        while (textElementsIterator.hasNext()) {
            modifyText(textElementsIterator.next());
        }

        // Преобразовние контрольных точек в линейном знаке.
        if (visual instanceof LineSignVisual) {
            LineSignVisual lineVisual = (LineSignVisual) visual;

            for (IControlPoint cp : this.signEditor.getControlPoints()) {
                if (cp instanceof ILinkedSignAngleControlPoint) {
                    ILinkedSignAngleControlPoint slopeACP = (ILinkedSignAngleControlPoint) cp;

                    BasePoint2D pointOnLine = GeometryProcessor.getPointOnPolylineByShift(
                            this.createDraftPolyLine(lineVisual.getAnchorPoints()),
                            slopeACP.getPositionOnLine());
                    BasePoint2D markerPoint = new BasePoint2D(pointOnLine)
                            .add(0.0, 5.0)
                            .rotate(
                                    GeometryProcessor.getPolylineTangentAngle(this.createDraftPolyLine(lineVisual.getAnchorPoints()), slopeACP.getPositionOnLine()) + slopeACP.getSlopeAngle() + Math.PI,
                                    pointOnLine);

                    cp.setX(markerPoint.getX());
                    cp.setY(markerPoint.getY());

                } else if (cp instanceof IPositionControlPoint) {
                    IPositionControlPoint posCP = (IPositionControlPoint) cp;
                    BasePoint2D pointOnLine = GeometryProcessor.getPointOnPolylineByShift(
                            this.createDraftPolyLine(lineVisual.getAnchorPoints()),
                            posCP.getPositionOnLine());

                    cp.setX(pointOnLine.getX());
                    cp.setY(pointOnLine.getY());
                }
            }
        }
    }

    @Override
    public ISignEditor getSignEditor() {
        return this.signEditor;
    }

    @Override
    public void setSignEditor(ISignEditor signEditor) {
        this.signEditor = signEditor;
    }

    /**
     * Модифицировать элемент пера.
     *
     * @param penElement Элемент пера.
     */
    private void modifyPenElement(IPenElement penElement) {
        penElement.setCore(SignVisualFactory.createSolidPenCore());
        penElement.setColor(modifyColor(penElement.getColor()), IColor.CM_ARGB);
    }

    /**
     * Модифицировать элемент заливки.
     *
     * @param brushElement Элемент заливки.
     */
    private void modifyBrushElement(IBrushElement brushElement) {
        brushElement.setCore(SignVisualFactory.createSolidBrushCore());
        brushElement.setColor(modifyColor(brushElement.getColor()), IColor.CM_ARGB);
    }

    /**
     * Модифицировать текст.
     *
     * @param text текст.
     */
    private void modifyText(IText text) {
        IPen pen = text.getPen();
        if (pen != null) {
            for (IPenElement penElement : pen.getElements())
                modifyPenElement(penElement);
        }
        IBrush brush = text.getBrush();
        if (brush != null) {
            for (IBrushElement brushElement : brush.getElements())
                modifyBrushElement(brushElement);
        }
        text.setColor(modifyColor(text.getColor()), IColor.CM_ARGB);
    }

    /**
     * Модифицировать цвет.
     *
     * @param color цвет.
     * @return Модифицированный цвет.
     */
    private int modifyColor(int color) {
        if ((color & 0xFF000000) != 0) color |= 0xFF000000;
        return color;
    }

    /**
     * Сформировать полилинию для чернового отображения.
     *
     * @param points точки.
     * @return полилиния.
     */
    private List<BasePoint2D> createDraftPolyLine(IAnchorPointsList points) {
        List<BasePoint2D> rez = new ArrayList<BasePoint2D>();

        for (IAnchorPoint p : points)
            rez.add(p.getPoint());

        return rez;
    }
}
