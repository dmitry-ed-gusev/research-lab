package vg.sign.generalization.api;


import java.util.Set;


/**
 * Интерфейс для работы с генерализацией ЭУЗ.
 *
 * @author Giller
 */
public interface IGeneralization extends Cloneable {

    /**
     * Параметр генерализации ЭУЗ.
     *
     * @author Giller
     */
    interface IParameter extends Cloneable {
        /**
         * Получить масштабирование.
         *
         * @return масштабирование.
         */
        public int getScale();

        /**
         * Установить масштабирование.
         *
         * @param scale масштабирование.
         */
        public void setScale(int scale);

        /**
         * Получить коэффициент.
         *
         * @return коэффициент.
         */
        public double getCoefficient();

        /**
         * Установить коэффициент.
         *
         * @param coefficient коэффициент.
         */
        public void setCoefficient(double coefficient);

        /**
         * Получить видимость.
         *
         * @return видимость.
         */
        public boolean getVisibility();

        /**
         * Установить видимость.
         *
         * @param visibility видимость.
         */
        public void setVisibility(boolean visibility);

        /**
         * Получить интерполяционность.
         *
         * @return интерполяционность
         */
        public boolean getInterpolation();

        /**
         * Установить интерполяционность.
         *
         * @param interpolation интерполяционность.
         */
        public void setInterpolation(boolean interpolation);

        /**
         * Клонирование параметра.
         *
         * @return клон параметра.
         */
        public IParameter clone();

    }


    /**
     * Получить перечень параметров.
     *
     * @return перечень параметров.
     */
    public Set<IParameter> getParameters();

    /**
     * Получить доступность генерализации.
     *
     * @return доступность генерализации.
     */
    public boolean isEnabled();

    /**
     * Установить доступность генерализации.
     *
     * @param enabled доступность генерализации.
     */
    public void setEnabled(boolean enabled);

    /**
     * Получить фиксацию размера.
     *
     * @return фиксация размера.
     */
    public boolean isFixedSize();

    /**
     * Установить фиксированный размер.
     *
     * @param fixedSize фиксированный размер.
     */
    public void setFixedSize(boolean fixedSize);

    /**
     * Получить базовый масштаб.
     *
     * @return базовый масштаб.
     */
    public int getBaseScale();

    /**
     * Установить базовый масштаб.
     *
     * @param baseScale базовый масштаб.
     */
    public void setBaseScale(int baseScale);

    /**
     * Получить коэффициент.
     *
     * @param scale масштаб.
     * @return коэффициент.
     */
    public double getCoefficient(int scale);

    /**
     * Получить видимость.
     *
     * @param scale масштаб.
     * @return видимость.
     */
    public boolean getVisibility(int scale);

    /**
     * Клонирование.
     *
     * @return Клон.
     */
    public IGeneralization clone();
}
