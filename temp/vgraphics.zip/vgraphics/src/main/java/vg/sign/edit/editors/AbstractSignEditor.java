package vg.sign.edit.editors;

import vg.geometry.GeometryProcessor;
import vg.geometry.GeometryUtils;
import vg.geometry.cp.AbstractCPoint;
import vg.geometry.cp.CPCalculator;
import vg.geometry.cp.CPoint;
import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.edit.api.IAnchorControlPoint;
import vg.sign.edit.api.IControlPoint;
import vg.sign.edit.api.ISignEditor;
import vg.sign.visual.api.IAnchorPoint;
import vg.sign.visual.api.IAnchorPointsList;
import vg.sign.visual.api.ISignVisual;

import java.util.ArrayList;
import java.util.List;

/**
 * Редактор знака.
 */
public abstract class AbstractSignEditor implements ISignEditor {

    /**
     * Контрольная точка управляющаяя точкой привязки.
     *
     */
    public class AnchorControlPoint extends AbstractCPoint implements IAnchorControlPoint {

        /**
         * Автоматически сгенерированный идентификатор.
         */
        private static final long serialVersionUID = 8644424777713344648L;
        /**
         * Визуальное представление.
         */
        ISignVisual visual;
        /**
         * Индекс точки привязки.
         */
        int index;

        /**
         * @param visual Визуальное представление.
         * @param index  Индекс точки привязки.
         */
        public AnchorControlPoint(ISignVisual visual, int index) {
            this.visual = visual;
            this.index = index;
        }

        @Override
        public String toString() {
            return String.format("AnchorCP {%s}", visual.getAnchorPoints().get(index));
        }

        @Override
        public CPoint calculate() {
            point = new BasePoint2D(getAnchorPoint().getPoint());
            return this;
        }

        @Override
        public CPoint decalculate() {
            getAnchorPoint().setPoint(new BasePoint2D(point));
            return this;
        }

        @Override
        public boolean isEditable() {
            return true;
        }

        @Override
        public int getAnchorPointIndex() {
            return index;
        }

        /**
         * Получить точку привязки.
         *
         * @return Точка привязки.
         */
        IAnchorPoint getAnchorPoint() {
            return visual.getAnchorPoints().get(index);
        }

        @Override
        public IControlPoint add() {
            if (visual.getAnchorPoints().size() == visual.getAnchorPoints().getMaxSize())
                return null;

            visual.getAnchorPoints().add(index + 1, visual.getAnchorPoints().get(index).clone());
            incrementAnchorPointIndexesInCP(index + 1);

            AnchorControlPoint cp = new AnchorControlPoint(visual, index + 1);
            controlPoints.add(controlPoints.indexOf(this) + 1, cp);

            return cp;
        }

        @Override
        public boolean remove() {
            if (visual.getAnchorPoints().size() == visual.getAnchorPoints().getMinSize())
                return false;

            visual.getAnchorPoints().remove(index);
            controlPoints.remove(this);
            decrementAnchorPointIndexesInCP(index);

            return true;
        }

    }

    /**
     * Получить точки фигуры.
     *
     * @param basePoints Базовые точки линии.
     * @param smooth     Сглаженность линии.
     * @param closed     Замкнутость линии.
     * @return Расчитанные точки линии.
     * @note Скопировано из AbstractGraphBuilder.buildLinePoints(List, boolean, boolean).
     */
    public List<BasePoint2D> buildLinePoints(List<? extends BasePoint2D> basePoints, boolean smooth, boolean closed) {
        if (smooth) {
            List<BasePoint2D> referencePoints = new ArrayList<BasePoint2D>();
            for (BasePoint2D bp : basePoints)
                referencePoints.add(new BasePoint2D(bp));
            List<BasePoint2D> linePoints = new ArrayList<BasePoint2D>();
            GeometryProcessor.getSplinePoints(linePoints, referencePoints, GeometryProcessor.ST_CUBIC, closed);
            return (List) linePoints;
        } else {
            List<BasePoint2D> linePoints = new ArrayList<BasePoint2D>();
            for (BasePoint2D bp : basePoints)
                linePoints.add(new BasePoint2D(bp));
            if (closed && !linePoints.isEmpty() && !linePoints.get(0).equals(linePoints.get(linePoints.size() - 1)))
                linePoints.add(linePoints.get(0));
            return linePoints;
        }
    }

    /**
     * Получить точки фигуры.
     *
     * @param anchorPoints Точки привязки знака.
     * @param smooth       Сглаженность линии.
     * @param closed       Замкнутость линии.
     * @return Расчитанные точки линии.
     */
    public List<BasePoint2D> buildLinePointsFromAP(List<IAnchorPoint> anchorPoints, boolean smooth, boolean closed) {
        List<BasePoint2D> basePoints = new ArrayList<BasePoint2D>(anchorPoints.size());
        for (IAnchorPoint ap : anchorPoints)
            basePoints.add(ap.getPoint());
        return buildLinePoints(basePoints, smooth, closed);
    }


    /**
     * Визуальное представление.
     */
    protected ISignVisual signVisual;
    /**
     * Контрольные точки.
     */
    protected List<IControlPoint> controlPoints = new ArrayList<IControlPoint>();


    /**
     * @param signVisual Визуальное представление.
     */
    public AbstractSignEditor(ISignVisual signVisual) {
        this.signVisual = signVisual;
    }


    @Override
    public ISignVisual getSignVisual() {
        return signVisual;
    }

    @Override
    public List<IControlPoint> getControlPoints() {
        return controlPoints;
    }


    @Override
    public synchronized void calculate() {
        controlPoints.clear();
        for (int i = 0, n = signVisual.getAnchorPoints().size(); i < n; i++)
            controlPoints.add(new AnchorControlPoint(signVisual, i));
        CPCalculator.calculate(controlPoints);
    }

    @Override
    public void rotate(double angle, BasePoint2D center) {
        // Трансформация для вращения точек привязки и маркера.
        BaseMatrix2D anchorPointRotation = new BaseMatrix2D().rotate(angle, center);

        // Новый угол знака, если знак можно вращать.
        if (signVisual.isRotatable())
            signVisual.setAngle(GeometryUtils.mod(0.0, Math.PI * 2.0, signVisual.getAngle() + angle));

        IAnchorPointsList anchorPoints = signVisual.getAnchorPoints();
        if (!anchorPoints.isEmpty()) {
            if (signVisual.isRotatable()) {
                // Все точки привязки просто поворачиваются.
                for (IAnchorPoint ap : anchorPoints)
                    ap.setPoint(anchorPointRotation.transformPoint(ap.getPoint()));
            } else {
                // Точки привязки просто смещаются на разницу вращения первой точки.
                IAnchorPoint fap = anchorPoints.get(0);
                BasePoint2D diff = anchorPointRotation.transformPoint(fap.getPoint()).sub(fap.getPoint());

                for (IAnchorPoint ap : anchorPoints)
                    ap.setPoint(new BasePoint2D(ap.getPoint()).add(diff));
            }
        }
    }

    @Override
    public void scale(BasePoint2D center, BasePoint2D scale, double angle) {
        BaseMatrix2D anchorPointScale = new BaseMatrix2D()
                .translate(-center.getX(), -center.getY())
                .rotate(-angle, 0, 0)
                .scale(scale, scale)
                .rotate(angle, 0, 0)
                .translate(center.getX(), center.getY());

        if (signVisual.isScalable()) {
            // Указание нового коэффициента масштабирования.
            signVisual.setScale(new BasePoint2D(signVisual.getScale()).scale(scale.getX(), scale.getY(), 0, 0));

            // Масштабирование всех точек привязок.
            for (IAnchorPoint ap : signVisual.getAnchorPoints())
                ap.setPoint(anchorPointScale.transformPoint(ap.getPoint()));

        } else {
            // Необходимо все точки привязки сдвинуть на разницу между первой точкой
            // привязки и отмасштабированной первой точкой привязки.
            if (!signVisual.getAnchorPoints().isEmpty()) {
                IAnchorPoint fap = signVisual.getAnchorPoints().get(0);
                BasePoint2D diff = anchorPointScale.transformPoint(fap.getPoint()).sub(fap.getPoint());

                for (IAnchorPoint ap : signVisual.getAnchorPoints())
                    ap.setPoint(new BasePoint2D(ap.getPoint()).add(diff));
            }
        }

    }

    @Override
    public void translate(BasePoint2D translation) {
        for (IAnchorPoint ap : signVisual.getAnchorPoints())
            ap.setPoint(new BasePoint2D(ap.getPoint()).add(translation));
    }

    @Override
    public void mirror() {
        if (getSignVisual().isScalable() && getSignVisual().getAnchorPoints().size() > 0) {
            BasePoint2D center = this.getMirrorCenter();
            BasePoint2D scale = new BasePoint2D(-1.0, 1.0);
            double angle = getSignVisual().getAngle();
            this.scale(center, scale, angle);
        }
    }

    /**
     * Получить центр для зеркалирования.
     *
     * @return центр для зеркалирования.
     */
    private BasePoint2D getMirrorCenter() {
        BasePoint2D res = new BasePoint2D();

        IAnchorPointsList anchorPoints = getSignVisual().getAnchorPoints();
        for (IAnchorPoint anchorPoint : anchorPoints)
            res.add(anchorPoint.getPoint());

        return res.div(anchorPoints.size(), anchorPoints.size());
    }

    /**
     * Инкрементирование индексов точек привязки у контрольных точек.
     * <p> Используется при добавлении контрольной точки, управляющей точкой привязки.
     *
     * @param startPointIndex индекс контрольной точки, начиная с которой будет производиться инкрементирование индекса.
     */
    void incrementAnchorPointIndexesInCP(int startPointIndex) {
        for (int i = 0; i < controlPoints.size(); ++i)
            if (controlPoints.get(i) instanceof AnchorControlPoint) {
                AnchorControlPoint cp = (AnchorControlPoint) controlPoints.get(i);
                if (cp.index >= startPointIndex)
                    cp.index++;
            }
    }

    /**
     * Декрементирование индексов точек привязки у контрольных точек.
     * <p> Используется при удалении контрольной точки, управляющей точкой привязки.
     *
     * @param startPointIndex индекс контрольной точки, начиная с которой будет производиться декрементирование индекса.
     */
    void decrementAnchorPointIndexesInCP(int startPointIndex) {
        for (int i = 0; i < controlPoints.size(); ++i)
            if (controlPoints.get(i) instanceof AnchorControlPoint) {
                AnchorControlPoint cp = (AnchorControlPoint) controlPoints.get(i);
                if (cp.index >= startPointIndex)
                    cp.index--;
            }
    }
}
