package vg.sign.core.api;

import vg.draw.vobject.VGObject;
import vg.sign.attributes.api.IAttribute;
import vg.sign.building.api.IGeometry;
import vg.sign.building.api.ISignBuilder;
import vg.sign.edit.api.ISignEditor;
import vg.sign.generalization.api.IGeneralization;
import vg.sign.generalization.api.IGeneralizationModifier;
import vg.sign.placing.api.IPlacingRules;
import vg.sign.visual.api.ISignVisual;

import java.io.Externalizable;
import java.util.List;

/**
 * Интерфейс ЭУЗ.
 */

// todo: all commented methods - commented temporary!!!

public interface ISign extends Cloneable, Externalizable {

    /**
     * Получить геометрические характеристики ЭУЗ.
     *
     * @return Геометрические характеристики ЭУЗ.
     */
    IGeometry getGeometry();

    /**
     * Получить Визуальное представление.
     *
     * @return Визуальное представление.
     */
    ISignVisual getVisual();

    /**
     * Получить построенное изображение.
     *
     * @return Построенное изображение.
     */
    VGObject getImage();

    /**
     * Клонировать ЭУЗ.
     *
     * @return Клон.
     */
    ISign clone();

    /**
     * Получить атрибуты знака.
     *
     * @return Атрибуты знака.
     */
    List<IAttribute> getAttributes();

    /**
     * Установить атрибуты.
     *
     * @param attributes перечень атрибутов.
     */
    public void setAttributes(List<IAttribute> attributes);

    /**
     * Получить редактор.
     *
     * @return Редактор.
     */
    ISignEditor getEditor();

    /**
     * Получить генерализацию.
     *
     * @return генерализация.
     */
    IGeneralization getGeneralization();

    /**
     * Получить правила нанесения.
     *
     * @return Правила нанесения.
     */
    IPlacingRules getPlacingRules();

    /**
     * Расчитать/построить ЭУЗ.
     */
    void calculate();

    /**
     * Установить визуальное представление знака.
     *
     * @param visual визуальное представление знака.
     */
    public void setVisual(ISignVisual visual);

    /**
     * Установить генерализацию.
     *
     * @param generalization генерализация.
     */
    public void setGeneralization(IGeneralization generalization);

    /**
     * Получить построитель.
     *
     * @return Построитель.
     */
    public ISignBuilder getBuilder();

    /**
     * Получить модификатор генерализации.
     *
     * @return модификатор генерализации.
     */
    public IGeneralizationModifier getGeneralizationModifier();

    /**
     * Получить внешние данные, связанные со Знаком.
     *
     * @return Внешние данные, связанные со знаком
     */
    public Object getExternalSignUtils();

    /**
     * Задать внешние данные, связанные со Знаком.
     *
     * @param data Внешние данные, связанные со Знаком.
     */
    public void setExternalSignUtils(Object data);

    /**
     * Задать правила нанесения.
     *
     * @param placingRules Правила нанесения.
     */
    public void setPlacingRules(IPlacingRules placingRules);

}
