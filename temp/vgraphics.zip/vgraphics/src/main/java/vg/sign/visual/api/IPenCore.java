package vg.sign.visual.api;

/**
 * Сердечник пера.
 *
 */
public interface IPenCore extends Cloneable {

    /**
     * Клонирование.
     *
     * @return Клон.
     */
    // todo: remove cloning!
    public IPenCore clone();

}
