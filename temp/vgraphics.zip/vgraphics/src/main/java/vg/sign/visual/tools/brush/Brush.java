package vg.sign.visual.tools.brush;

import vg.sign.visual.api.IBrush;
import vg.sign.visual.api.IBrushElement;
import vg.utils.ListReference;

import java.util.ArrayList;
import java.util.List;

/**
 * Заливка.
 */
public class Brush implements IBrush {

    /**
     * Перечень элементов пера.
     *
     * @author Giller
     */
    public class BrushElementsList extends ListReference<IBrushElement> implements IBrushElementsList {

        /**
         * Конструктор с входными парметрами.
         *
         * @param editable редактируемость перечня пера.
         */
        public BrushElementsList(boolean editable) {
            super(new ArrayList<IBrushElement>(), editable);
        }

        @Override
        public boolean isEditable() {
            return this.isReadOnly();
        }
    }


    /**
     * Элементы заливки.
     */
    private IBrushElementsList elements = new BrushElementsList(true);


    /** */
    public Brush() {
    }

    /**
     * @param elements Элементы заливки.
     */
    public Brush(List<IBrushElement> elements) {
        this.elements.addAll(elements);
    }

    /**
     * @param elements Элементы заливки.
     */
    public Brush(IBrushElement... elements) {
        for (IBrushElement e : elements)
            this.elements.add(e);
    }


    @Override
    public Brush clone() {
        try {
            Brush clonedObject = (Brush) super.clone();

//			clonedObject.elements = new ArrayList<IBrushElement>();
            clonedObject.elements = new BrushElementsList(true);
            for (IBrushElement be : elements)
                clonedObject.elements.add(be.clone());

            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }


    @Override
    public IBrushElementsList getElements() {
        return elements;
    }

}
