package vg.sign.visual.signs;

import vg.sign.visual.api.*;
import vg.sign.visual.tools.AbstractSignVisual;
import vg.sign.visual.tools.AnchorPointsList;
import vg.sign.visual.tools.RootGraphElement;
import vg.utils.ListReference;

import java.util.Arrays;
import java.util.UUID;

/**
 * Визуальное представление площадного знака.
 *
 */
public class AreaSignVisual extends AbstractSignVisual {

    /**
     * Площадной графический элемент Площадного ЭУЗ.
     *
     */
    private class SelfAreaGraphElement implements ILineGraphElement {

        /**
         * Название графического элемента
         */
        protected String name = "Фигура";
        /**
         * ID
         */
        private String id;

        /***/
        public SelfAreaGraphElement() {
            this.id = UUID.randomUUID().toString();
        }

        @Override
        public AreaSignVisual.SelfAreaGraphElement clone() {
            try {
                AreaSignVisual.SelfAreaGraphElement clonedObject = (AreaSignVisual.SelfAreaGraphElement) super.clone();
                clonedObject.id = id;
                return clonedObject;
            } catch (CloneNotSupportedException ex) {
                throw new RuntimeException(ex);
            }
        }

        @Override
        public boolean isVisible() {
            return lineVisible;
        }

        @Override
        public void setVisible(boolean visible) {
            lineVisible = visible;
        }

        @Override
        public boolean isEditable() {
            return editable;
        }

        @Override
        public void setEditable(boolean editable) {
            AreaSignVisual.this.editable = editable;
        }

        @Override
        public IPen getPen() {
            return AreaSignVisual.this.pen;
        }

        @Override
        public void setPen(IPen pen) {
            AreaSignVisual.this.pen = pen;
        }

        @Override
        public IBrush getBrush() {
            return AreaSignVisual.this.brush;
        }

        @Override
        public void setBrush(IBrush brush) {
            AreaSignVisual.this.brush = brush;
        }

        @Override
        public IText getText() {
            return null;
        }

        @Override
        public void setText(IText text) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isSmooth() {
            return AreaSignVisual.this.smooth;
        }

        @Override
        public void setSmooth(boolean smooth) {
            AreaSignVisual.this.smooth = smooth;
        }

        @Override
        public boolean isClosed() {
            return true;
        }

        @Override
        public void setClosed(boolean closed) {
        }

        @Override
        public String getName() {
            return this.name;
        }

        @Override
        public void setName(String name) {
            this.name = name;
        }

        @Override
        public String getId() {
            return id;
        }

        @Override
        public void setId(String id) {
            this.id = id;
        }

    }


    /**
     * Гладкость.
     */
    boolean smooth = false;
    /**
     * Перо.
     */
    IPen pen = null;
    /**
     * Заливка.
     */
    IBrush brush = null;
    // TODO Рассмотреть возможность добавления lineVisible в SelfAreaGraphElement.
    /**
     * Видимость графического элемента.
     */
    boolean lineVisible = true;
    /**
     * Редактируемость элемента
     */
    boolean editable = true;


    /***/
    public AreaSignVisual() {
        anchorPoints = new AnchorPointsList(3, Integer.MAX_VALUE);
        rootGraphElement = new RootGraphElement(
                "Площадной ЭУЗ",
                this,
                new ListReference<IGraphElement>(Arrays.asList((IGraphElement) new SelfAreaGraphElement()), false));
    }


    @Override
    public AreaSignVisual clone() {
        AreaSignVisual clonedObject = (AreaSignVisual) super.clone();

        if (pen != null)
            clonedObject.pen = pen.clone();

        if (brush != null)
            clonedObject.brush = brush.clone();

        clonedObject.rootGraphElement = new RootGraphElement(
                "Площадной ЭУЗ",
                clonedObject,
                new ListReference<IGraphElement>(Arrays.asList((IGraphElement) clonedObject.new SelfAreaGraphElement()), false));

        return clonedObject;
    }

    /**
     * Получить сглаженность линии контура.
     *
     * @return Сглаженность линии контура.
     */
    public boolean isSmooth() {
        return smooth;
    }

    /**
     * Задать сглаженность линии контура.
     *
     * @param smooth Сглаженность линии контура.
     */
    public void setSmooth(boolean smooth) {
        this.smooth = smooth;
    }

    /**
     * Получить перо контура.
     *
     * @return Перо контура.
     */
    public IPen getPen() {
        return pen;
    }

    /**
     * Задать перо контура.
     *
     * @param pen Перо контура.
     */
    public void setPen(IPen pen) {
        this.pen = pen;
    }

    /**
     * Получить заливку площади.
     *
     * @return Заливка площади.
     */
    public IBrush getBrush() {
        return brush;
    }

    /**
     * Задать заливку площади.
     *
     * @param brush Заливка площади.
     */
    public void setBrush(IBrush brush) {
        this.brush = brush;
    }

    @Override
    public void createDefaultSemantics(int index, IAnchorPoint anchorPoint) {
    }

}