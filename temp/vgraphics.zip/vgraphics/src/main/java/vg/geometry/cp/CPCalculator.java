package vg.geometry.cp;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * Tool for auto calculating points.
 */

public class CPCalculator {

    /**
     * Расчитать точки с учётом зависимостей.
     *
     * @param cpoints Sergei Tumanov
     */
    public static void calculate(Collection<? extends CPoint> cpoints) {
        Set<Integer> calculatingPointsIds = new HashSet<Integer>();
        Set<Integer> calculatedPointsIds = new HashSet<Integer>();

        for (CPoint cpoint : cpoints)
            calculate(cpoint, calculatingPointsIds, calculatedPointsIds);
    }

    /**
     * Расчёт точки с зависимостями.
     *
     * @param cpoint               Точка.
     * @param calculatingPointsIds Набор расчитывающихся в данный момент точек.
     *                             Нужен для обнаружения циклических зависимостей.
     * @param calculatedPointsIds  Набор уже расчитанных точек.
     *                             Нужен, чтобы не считать точку несколько раз, когда от неё зависят несколько точек.
     */
    private static void calculate(CPoint cpoint, Set<Integer> calculatingPointsIds, Set<Integer> calculatedPointsIds) {
        // Using the identityHashCode, bacause SignPoint2D.hashCode is overriden, but CPoint.hashCode not.
        Integer id = System.identityHashCode(cpoint);

        // If point is calculatED, do nothing.
        if (calculatedPointsIds.contains(id))
            return;
        // If point is calculatING, it is cyclic dependency.
        if (calculatingPointsIds.contains(id))
            throw new RuntimeException("Cyclic dependencies.");
        // Registering the point as calculatING.
        calculatingPointsIds.add(id);

        // Calculating the dependencies.
        for (CPoint dependency : cpoint.getDependencies())
            calculate(dependency, calculatingPointsIds, calculatedPointsIds);
        // Calculating the point.
        cpoint.calculate();

        // Unregistering the point as calculatING.
        calculatingPointsIds.remove(id);
        // Registering the point as calculatED.
        calculatedPointsIds.add(id);
    }


    /**
     * Получить все зависимости точки.
     *
     * @param cpoint Точка.
     * @return Набор зависимостей точки.
     */
    public static Set<CPoint> getDependencies(CPoint cpoint) {
        return getDependencies(cpoint, null, true);
    }

    /**
     * Получить зависимости точки.
     *
     * @param cpoint  Точка.
     * @param cpoints Список корневых точек.
     *                Если не null, то в набор зависимостей попадут только точки из этого списка.
     * @param deep    Искать вглубь.
     *                Если cpoints не null и а deep - false, то будут искаться только непосредственные зависимости из cpoints.
     *                Если cpoints - null, то этот флаг не используется.
     * @return Набор зависимостей.
     */
    public static Set<CPoint> getDependencies(CPoint cpoint, Collection<? extends CPoint> cpoints, boolean deep) {
        Set<CPoint> dependencies = new HashSet<CPoint>();
        Set<CPoint> dependents = new HashSet<CPoint>();
        getDependencies(cpoint, cpoints, deep, dependencies, dependents);
        return dependencies;
    }

    /**
     * Поиск зависимостей точки.
     *
     * @param cpoint       Точка.
     * @param cpoints      Корневые точки.
     * @param deep         Искать вглубину. Если cpoints - null, то этот флаг не используется.
     * @param dependencies Набор найденых зависимостей.
     * @param dependents   Набор зависимых (от зависимостей) точек в текущей ветке поиска.
     */
    private static void getDependencies(CPoint cpoint, Collection<? extends CPoint> cpoints, boolean deep, Set<CPoint> dependencies, Set<CPoint> dependents) {
        dependents.add(cpoint);
        for (CPoint d : cpoint.getDependencies()) {
            if (dependents.contains(d))
                throw new RuntimeException("Cyclic dependency: " + cpoint + " -> " + d);
            if (cpoints == null) {
                dependencies.add(d);
            } else {
                if (cpoints.contains(d)) {
                    dependencies.add(d);
                    if (!deep) continue;
                }
            }
            getDependencies(d, cpoints, deep, dependencies, dependents);
        }
        dependents.remove(cpoint);
    }


    /**
     * Поиск обратных зависимостей (точек, которые зависят от данной).
     *
     * @param cpoint  Точка.
     * @param cpoints Набор корневых точек.
     * @param deep    Искать вглубину.
     *                Если этот флаг - false, то будут найдены только непосредственные зависимости.
     * @return Наблор точек, зависящих от данной точки.
     */
    public static Set<CPoint> getInverseDependencies(CPoint cpoint, Collection<? extends CPoint> cpoints, boolean deep) {
        Set<CPoint> inverseDependencies = new HashSet<CPoint>();
        for (CPoint cp : cpoints) {
            if (cp == cpoint) continue;
            if (containsDependency(cp, cpoint, cpoints, deep))
                inverseDependencies.add(cp);
        }
        return inverseDependencies;
    }

    /**
     * Проверка, зависит ли точка тот указанной зависимости.
     *
     * @param cpoint     Точка.
     * @param dependency Зависимость.
     * @param cpoints    Набор корневых точек.
     * @param deep       Поиск вглубину.
     * @return Признак соответствия зависимости.
     */
    private static boolean containsDependency(CPoint cpoint, CPoint dependency, Collection<? extends CPoint> cpoints, boolean deep) {
        for (CPoint d : cpoint.getDependencies()) {
            if (d == dependency) return true;
            if (deep || !cpoints.contains(d))
                if (containsDependency(d, dependency, cpoints, deep))
                    return true;
        }
        return false;
    }

}