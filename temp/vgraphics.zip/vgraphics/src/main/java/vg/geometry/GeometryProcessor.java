package vg.geometry;

import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;
import vg.geometry.primitives.BaseRectangle2D;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Geometry processor.
 */
public class GeometryProcessor {

    /**
     * Код линейного сплайна.
     */
    public static final int ST_LINEAR = 1;
    /**
     * Код кубического сплайна.
     */
    public static final int ST_CUBIC = 3;

    /**
     * Малое значение (float).
     */
    public static double SMALL_FLOAT = 0.000001;
    /**
     * Разница по умолчанию.
     */
    public static double DEFAULT_DELTA = 2.0;

    /**
     * Порядок матриц для определения точек кубического сплайна.
     */
    public static int MATRIX_DIMENSION_TO_DEFINE_CUBIC_SPLINE_POINTS = 4;

    /**
     * Число точек в сегменте кубического сплайна.
     */
    public static int CUBIC_SPLINE_SEGMENT_POINT_COUNT = 11;


    /**
     * Смещение.
     */
    public static interface Shift {

        /**
         * Получить смещение.
         *
         * @param t Значение, по которому рассчитывается смещение.
         * @return Смещение.
         */
        public double getShift(double t);

        /**
         * Проверить, является ли текущее смещение нулевым.
         *
         * @return Флаг равенства смещения нулю.
         */
        public boolean isZero();
    }

    /**
     * Постоянное смещение.
     */
    public static class ConstShift implements Shift {

        /**
         * Значение смещения.
         */
        double shift = 0.0;

        /**
         * @param shift Значение смещения.
         */
        public ConstShift(double shift) {
            this.shift = shift;
        }

        @Override
        public double getShift(double t) {
            return shift;
        }

        @Override
        public boolean isZero() {
            return GeometryUtils.isNearZero(shift);
        }
    }

    /**
     * Линейное смещение.
     */
    public static class LinearShift implements Shift {

        /**
         * Начальное смещение.
         */
        double beginShift = 0.0;
        /**
         * Конечное смещение.
         */
        double endShift = 0.0;

        /**
         * @param beginShift Начальное смещение.
         * @param endShift   Конечное смещение.
         */
        public LinearShift(double beginShift, double endShift) {
            this.beginShift = beginShift;
            this.endShift = endShift;
        }

        @Override
        public double getShift(double t) {
            return beginShift + t * (endShift - beginShift);
        }

        @Override
        public boolean isZero() {
            return beginShift * beginShift < 1e-12 && endShift * endShift < 1e-12;
        }
    }

    /**
     * Получить точки кубического сплайна.
     *
     * @param splinePoints     Список, под результат.
     *                         <p> Если null, то будет создан новый пустой список.
     * @param basePoint1       Начальная точка.
     * @param controlPoint1    Первая контрольная точка.
     * @param controlPoint2    Вторая контрольная точка.
     * @param basePoint2       Конечная точка.
     * @param numberOfSegments Количество сегментов.
     * @return Список с точками кубического сплайна.
     */
    public static List<BasePoint2D> getCubicSplinePoints(
            List<BasePoint2D> splinePoints,
            BasePoint2D basePoint1, BasePoint2D controlPoint1,
            BasePoint2D controlPoint2, BasePoint2D basePoint2,
            int numberOfSegments) {

        if (splinePoints == null) splinePoints = new ArrayList<BasePoint2D>(numberOfSegments + 1);

        double bx1 = basePoint1.getX();
        double by1 = basePoint1.getY();
        double cx1 = controlPoint1.getX();
        double cy1 = controlPoint1.getY();
        double cx2 = controlPoint2.getX();
        double cy2 = controlPoint2.getY();
        double bx2 = basePoint2.getX();
        double by2 = basePoint2.getY();

        for (int i = 0; i <= numberOfSegments; i++) {
            double t = (double) i / numberOfSegments;
            double d = 1 - t;
            double x = d * d * d * bx1 + 3 * t * d * d * cx1 + 3 * t * t * d * cx2 + t * t * t * bx2;
            double y = d * d * d * by1 + 3 * t * d * d * cy1 + 3 * t * t * d * cy2 + t * t * t * by2;
            splinePoints.add(new BasePoint2D(x, y));
        }

        return splinePoints;

    }


    /**
     * Получить точки сплайна.
     *
     * @param splinePoints    массив точек сплайна.
     * @param referencePoints исходные точки.
     * @param splineType      тип сплайна.
     * @param isClosed        флаг замкнутости.
     */
    public static void getSplinePoints(
            List<BasePoint2D> splinePoints,
            List<BasePoint2D> referencePoints,
            int splineType,
            boolean isClosed) {

        // В данном случае метод simplifyPolyline вернет список SignPoint2D. Преобразование безопасно.
        referencePoints = (List) GeometryUtils.simplifyPolyline(referencePoints, GeometryDefaults.POLYLINE_PRECISION);

        if (isClosed) {
            if (referencePoints.size() > 0 &&
                    !(referencePoints.get(0).distanceToPoint(referencePoints.get(referencePoints.size() - 1)) < 1e-3))
                referencePoints.add(referencePoints.get(0));
            getClosedSplinePoints(splinePoints, referencePoints, splineType);
        } else {
            getOpenedSplinePoints(splinePoints, referencePoints, splineType);
        }
    }

    /**
     * Проверить, лежит ли точка на полилинии, описываемой массивом точек.
     *
     * @param point          Проверяемая точка.
     * @param delta          Разница, при превышении которой точка считается находящейся вне линии.
     * @param polylinePoints Точки полилинии.
     * @return Флаг принадлежности точки полилинии.
     */
    public static boolean isPointOnPolyline(BasePoint2D point, double delta, List<? extends BasePoint2D> polylinePoints) {
        BasePoint2D nearestPoint = nearestPointOnPolyline(polylinePoints, point);
        return nearestPoint != null && nearestPoint.distanceToPoint(point) < delta;
    }

    /**
     * Проверить нахождение точки на полилинии.
     *
     * @param point          Точка, принадлежность которой полилинии проверяется.
     * @param polylinePoints Точки полилинии.
     * @return Флаг принадлежности точки полилинии.
     */
    public static boolean isPointOnPolyline(BasePoint2D point, List<? extends BasePoint2D> polylinePoints) {
        return isPointOnPolyline(point, DEFAULT_DELTA, polylinePoints);
    }

    /**
     * Проверить, лежит ли точка на полилинии, описываемой массивом точек.
     *
     * @param point          Проверяемая точка.
     * @param delta          Разница, при превышении которой точка считается находящейся вне линии.
     * @param polylinePoints Массив точек полилинии.
     * @return Флаг принадлежности точки полилинии.
     */
    public static boolean isPointOnPolyline(BasePoint2D point, double delta, BasePoint2D... polylinePoints) {
        List<BasePoint2D> points = new ArrayList<BasePoint2D>(polylinePoints.length);
        for (BasePoint2D p : polylinePoints) points.add(p);
        return isPointOnPolyline(point, delta, points);
    }

    /**
     * Проверить нахождение точки на полилинии.
     *
     * @param point          Точка, нахождение которой на полилинии проверяется.
     * @param polylinePoints Точки полилинии.
     * @return Флаг принадлежности точки полилинии.
     */
    public static boolean isPointOnPolyline(BasePoint2D point, BasePoint2D... polylinePoints) {
        return isPointOnPolyline(point, DEFAULT_DELTA, polylinePoints);
    }

    /**
     * Проверить, лежит ли точка внутри полигона.
     *
     * @param point         проверяемая точка.
     * @param polygonPoints точки полигона.
     * @return trueб если точка находится внутри полигона и false, в обратном
     * случае.
     */
    public static boolean isPointInsidePolygon(BasePoint2D point, List<? extends BasePoint2D> polygonPoints) {
        if (polygonPoints.size() == 0)
            return false;

        double sum = 0.0;
        double fi = 0.0;
        double prevLineSegmentLen = 0.0;
        double curLineSegmentLen = 0.0;
        double d = 0.0;
        double d1 = 0.0;

        BasePoint2D prevPoint = polygonPoints.get(0);
        BasePoint2D curPoint = new BasePoint2D();

        // Счётчик.
        int i = 0;
        // Количество точек.
        int s = polygonPoints.size();
        // Количество итераций цикла.w
        // Если последняя точка не совпадает с первой, то цикл на 1 итерацию будет длиннее.
        int n = polygonPoints.get(0).equals(polygonPoints.get(s - 1)) ? s : s + 1;
        // Цикл тестирования.
        for (i = 0; i < n; i++) {
            curPoint = polygonPoints.get(i % s);

            prevLineSegmentLen = GeometryUtils.distanceBetweenPoints(point, prevPoint);
            curLineSegmentLen = GeometryUtils.distanceBetweenPoints(point, curPoint);

            if (Math.abs(prevLineSegmentLen) < SMALL_FLOAT
                    || Math.abs(curLineSegmentLen) < SMALL_FLOAT) {
                return true;
            }

            d = (prevPoint.getX() - point.getX()) * (curPoint.getY() - point.getY())
                    - (prevPoint.getY() - point.getY()) * (curPoint.getX() - point.getX());
            d1 = ((prevPoint.getX() - point.getX()) * (curPoint.getX() - point.getX())
                    + (prevPoint.getY() - point.getY()) * (curPoint.getY() - point.getY()))
                    / (prevLineSegmentLen * curLineSegmentLen);

            if (d1 > 1.0) {
                d1 = 1.0;
            }

            if (d1 < -1.0) {
                d1 = -1.0;
            }

            fi = Math.acos(d1);

            if (Math.abs(fi - Math.PI) < 0.01) {
                return true;
            }

            if (d > 0.0) {
                sum += fi;
            } else if (d < 0.0) {
                sum -= fi;
            }

            prevPoint = curPoint;
        }

        if (Math.abs(Math.abs(sum) - 2 * Math.PI) < 1) {
            return true;
        }

        return false;
    }

    /**
     * Проверить, находится ли точка внутри окружности.
     *
     * @param point         Точка.
     * @param center        Центр окружности.
     * @param radius        Радиус окружности.
     * @param includeRadius Флаг включения радуиса в круг.
     * @param delta         Расстояние до радиуса, при котором точка считается включённой.
     * @return true, если точка находится в пределах круга и false, если нет.
     */
    public static boolean isPointInCircle(BasePoint2D point, BasePoint2D center, double radius, boolean includeRadius, double delta) {
        if (includeRadius) {
            return point.distanceToPoint(center) <= radius + delta;
        } else {
            return point.distanceToPoint(center) < radius;
        }
    }

    /**
     * Положение точки по отношению к прямой.
     *
     * @param p1 Точка, положение которой рассчитыввается.
     * @param p2 Первая точка прямой.
     * @param p3 Вторая точка прямой.
     * @return 0 - точка лежит на прямой, >0 точка лежит в правой полуплоскости,
     * <0 - в левой.
     */
    public static double pointAtLine(BasePoint2D p1, BasePoint2D p2, BasePoint2D p3) {
        double sa = (p3.getX() - p1.getX()) * (p2.getY() - p1.getY())
                - (p3.getY() - p1.getY()) * (p2.getX() - p1.getX());// v[0] *
        // w[1] -
        // w[0] *
        // v[1];
        if (sa > SMALL_FLOAT)
            return 1; // точка слева
        if (sa < -SMALL_FLOAT)
            return -1; // точка справа
        return 0; // точка на прямой

    }

    /**
     * Получить массив точек замкнутового сплайна.
     *
     * @param closedSplinePoints массив точек сплайна.
     * @param refPoints          массив исходных точек.
     * @param splineType         тип сплайна. Тип Сплайна только кубический
     */
    public static void getClosedSplinePoints(
            List<BasePoint2D> closedSplinePoints,
            List<BasePoint2D> refPoints,
            int splineType) {
        closedSplinePoints.clear();

        if (refPoints.size() == 0) {
            return;
        }

        switch (splineType) {
            case ST_CUBIC: { //stCubic
                double[][] matrU = new double[MATRIX_DIMENSION_TO_DEFINE_CUBIC_SPLINE_POINTS][MATRIX_DIMENSION_TO_DEFINE_CUBIC_SPLINE_POINTS];
                double v0x = 0.0;
                double v0y = 0.0;

                int refPointCount = refPoints.size();

                if (refPointCount < 4) {
                    closedSplinePoints = refPoints;
                    return;
                }

                double prevLineSegmentLength = 0.0;
                double nextLineSegmentLength = 0.0;
                int i = 0;
                double tempVar = 0.0;
                for (i = 0; i < (refPointCount - 1); i++) {
                    matrU[0][0] = refPoints.get(i).getX();
                    matrU[0][1] = refPoints.get(i).getY();
                    matrU[1][0] = refPoints.get(i + 1).getX();
                    matrU[1][1] = refPoints.get(i + 1).getY();
                    if (i == 0) {
                        prevLineSegmentLength = GeometryUtils.distanceBetweenPoints(refPoints.get(0), refPoints.get(refPointCount - 2));
                        nextLineSegmentLength = GeometryUtils.distanceBetweenPoints(refPoints.get(0), refPoints.get(1));

                        tempVar = nextLineSegmentLength
                                / (prevLineSegmentLength + nextLineSegmentLength);

                        matrU[2][0] = (refPoints.get(1).getX() - refPoints.get(
                                refPointCount - 2).getX())
                                * tempVar;
                        matrU[2][1] = (refPoints.get(1).getY() - refPoints.get(
                                refPointCount - 2).getY())
                                * tempVar;
                        v0x = matrU[2][0];
                        v0y = matrU[2][1];
                    } else {
                        if (i == (refPointCount - 2)) {
                            prevLineSegmentLength = GeometryUtils.distanceBetweenPoints(refPoints.get(refPointCount - 2), refPoints.get(refPointCount - 3));
                            nextLineSegmentLength = GeometryUtils.distanceBetweenPoints(refPoints.get(refPointCount - 2), refPoints.get(0));

                            tempVar = nextLineSegmentLength
                                    / (prevLineSegmentLength + nextLineSegmentLength);

                            matrU[2][0] = (refPoints.get(0).getX() - refPoints.get(
                                    refPointCount - 3).getX())
                                    * tempVar;
                            matrU[2][1] = (refPoints.get(0).getY() - refPoints.get(
                                    refPointCount - 3).getY())
                                    * tempVar;
                        } else {
                            prevLineSegmentLength = GeometryUtils.distanceBetweenPoints(refPoints.get(i), refPoints.get(i - 1));
                            nextLineSegmentLength = GeometryUtils.distanceBetweenPoints(refPoints.get(i), refPoints.get(i + 1));

                            tempVar = nextLineSegmentLength
                                    / (prevLineSegmentLength + nextLineSegmentLength);

                            matrU[2][0] = (refPoints.get(i + 1).getX() - refPoints
                                    .get(i - 1).getX()) * tempVar;
                            matrU[2][1] = (refPoints.get(i + 1).getY() - refPoints
                                    .get(i - 1).getY()) * tempVar;
                        }
                    }

                    if (i == (refPointCount - 2)) {
                        matrU[3][0] = v0x;
                        matrU[3][1] = v0y;
                    } else {
                        prevLineSegmentLength = GeometryUtils.distanceBetweenPoints(refPoints.get(i + 1), refPoints.get(i));
                        nextLineSegmentLength = GeometryUtils.distanceBetweenPoints(refPoints.get(i + 1), refPoints.get(i + 2));

                        tempVar = nextLineSegmentLength
                                / (prevLineSegmentLength + nextLineSegmentLength);

                        matrU[3][0] = (refPoints.get(i + 2).getX() - refPoints.get(
                                i).getX())
                                * tempVar;
                        matrU[3][1] = (refPoints.get(i + 2).getY() - refPoints.get(
                                i).getY())
                                * tempVar;
                    }

                    calculateCubicSplineSegmentPoints(matrU, closedSplinePoints);
                }
            }
            break;

            default:
            case ST_LINEAR: { //stLinear
                for (BasePoint2D point : refPoints) {
                    closedSplinePoints.add(new BasePoint2D(point));
                }
            }
            break;
        }


        if (closedSplinePoints.get(closedSplinePoints.size() - 1) != refPoints.get(0)) {
            closedSplinePoints.add(refPoints.get(0));
        }
    }


    /**
     * Повернуть точку относительно заданной оси.
     *
     * @param point       точка.
     * @param centerPoint ось вращения.
     * @param angle       угол.
     */
    //public static void rotatePoint(BasePoint2D point, BasePoint2D centerPoint, double angle) {
    //    point.rotate(angle, centerPoint);
    //}

    // TODO разобраться со значениями

    /**
     * Рассчитать точки кубического сплайна.
     *
     * @param matrU             <Разобраться> Матрица.
     * @param cubicSplinePoints Точки кубического сплайна.
     */
    public static void calculateCubicSplineSegmentPoints(
            double[][] matrU,
            List<BasePoint2D> cubicSplinePoints) {
        double[][] invQ1 = {{1.0, 0.0, 0.0, 0.0}, {0.0, 0.0, 1.0, 0.0},
                {-3.0, 3.0, -2.0, -1.0}, {2.0, -2.0, 1.0, 1.0}};

        if (CUBIC_SPLINE_SEGMENT_POINT_COUNT - 1 == 0) {
            return;
        }

        double[][] matrS = new double[MATRIX_DIMENSION_TO_DEFINE_CUBIC_SPLINE_POINTS][MATRIX_DIMENSION_TO_DEFINE_CUBIC_SPLINE_POINTS];

        double step = 1.0 / (CUBIC_SPLINE_SEGMENT_POINT_COUNT - 1);

        mulMatr(MATRIX_DIMENSION_TO_DEFINE_CUBIC_SPLINE_POINTS,
                MATRIX_DIMENSION_TO_DEFINE_CUBIC_SPLINE_POINTS,
                MATRIX_DIMENSION_TO_DEFINE_CUBIC_SPLINE_POINTS,
                invQ1, matrU, matrS);

        double x = 0.0;
        double y = 0.0;
        double t1 = 0.0;
        double t2 = 0.0;
        double t3 = 0.0;

        while (t1 <= 1) {
            x = matrS[0][0] + t1 * matrS[1][0] + t2 * matrS[2][0] + t3 * matrS[3][0];
            y = matrS[0][1] + t1 * matrS[1][1] + t2 * matrS[2][1] + t3 * matrS[3][1];

            cubicSplinePoints.add(new BasePoint2D(x, y));

            t1 += step;
            t2 = t1 * t1;
            t3 = t2 * t1;
        }
    }

    // TODO разобраться со значениями.

    /**
     * Умножение матриц.
     *
     * @param rowNum1 число строк.
     * @param common  <Разобраться>
     * @param colNum2 число столбцов.
     * @param matr1   матрица первая.
     * @param matr2   матрица вторая.
     * @param resMatr результат операции.
     */
    private static void mulMatr(int rowNum1, int common, int colNum2,
                                double[][] matr1, double[][] matr2, double[][] resMatr) {
        double temp = 0.0;

        int i = 0;
        int j = 0;
        int k = 0;

        for (i = 0; i < rowNum1; ++i) {
            for (j = 0; j < colNum2; ++j) {
                temp = matr1[i][0] * matr2[0][j];

                for (k = 1; k < common; ++k) {
                    temp += matr1[i][k] * matr2[k][j];
                }

                resMatr[i][j] = temp;
            }
        }
    }

    /**
     * Получить матрицу по точкам сплайна.
     *
     * @param matrU           матрица.
     * @param referencePoints точки сплайна
     * @param i               с какой точки сплайна вести отсчёт.
     */
    public static void getOpenCubicSplineMatrU(
            double[][] matrU,
            List<BasePoint2D> referencePoints,
            int i) {

        int referencePointCount = referencePoints.size();

        BasePoint2D pp = i > 0 ? referencePoints.get(i - 1) : null;
        BasePoint2D cp = referencePoints.get(i);
        BasePoint2D np = referencePoints.get(i + 1);
        BasePoint2D nnp = i < referencePointCount - 2 ? referencePoints.get(i + 2) : null;

        matrU[0][0] = cp.getX();
        matrU[0][1] = cp.getY();
        matrU[1][0] = np.getX();
        matrU[1][1] = np.getY();

        if (i == 0) {
            matrU[2][0] = 0;
            matrU[2][1] = 0;
        } else {
            double prevLineSegmentLength = cp.distanceToPoint(pp);
            double nextLineSegmentLength = np.distanceToPoint(cp);
            double tempVar = nextLineSegmentLength / (prevLineSegmentLength + nextLineSegmentLength);
            matrU[2][0] = (np.getX() - pp.getX()) * tempVar;
            matrU[2][1] = (np.getY() - pp.getY()) * tempVar;
        }

        if (i == (referencePointCount - 2)) {
            matrU[3][0] = 0;
            matrU[3][1] = 0;
        } else {
            double prevLineSegmentLength = np.distanceToPoint(cp);
            double nextLineSegmentLength = nnp.distanceToPoint(np);
            double tempVar = nextLineSegmentLength / (prevLineSegmentLength + nextLineSegmentLength);
            matrU[3][0] = (nnp.getX() - cp.getX()) * tempVar;
            matrU[3][1] = (nnp.getY() - cp.getY()) * tempVar;
        }

    }

    /**
     * Получить массив точек незамкнутого сплайна.
     *
     * @param splinePoints    массив точек.
     * @param referencePoints исходный массив точек.
     * @param splineType      тип сплайна.
     */
    public static void getOpenedSplinePoints(
            List<BasePoint2D> splinePoints,
            List<BasePoint2D> referencePoints,
            int splineType) {
        splinePoints.clear();

        if (referencePoints.size() == 0) {
            return;
        }

        if (splineType == ST_LINEAR) { //SplineType.stLinear
            for (int i = 0; i < referencePoints.size(); ++i) {
                BasePoint2D point = new BasePoint2D(referencePoints.get(i).getX(),
                        referencePoints.get(i).getY());
                splinePoints.add(point);
            }
            return;
        }

        if (splineType == ST_CUBIC) { //SplineType.stCubic
            double[][] matrU = new double[MATRIX_DIMENSION_TO_DEFINE_CUBIC_SPLINE_POINTS][MATRIX_DIMENSION_TO_DEFINE_CUBIC_SPLINE_POINTS];

            int referencePointCount = referencePoints.size();
            if (referencePointCount < 3) {
                // splinePoints = referencePoints;
                for (int i = 0; i < referencePoints.size(); ++i) {
                    BasePoint2D point = new BasePoint2D(referencePoints.get(i).getX(),
                            referencePoints.get(i).getY());
                    splinePoints.add(point);
                }
                return;
            }

            for (int i = 0; i < (referencePointCount - 1); i++) {
                getOpenCubicSplineMatrU(matrU, referencePoints, i);
                calculateCubicSplineSegmentPoints(matrU, splinePoints);
            }

            if (splinePoints.get(splinePoints.size() - 1) != referencePoints
                    .get(referencePoints.size() - 1)) {
                splinePoints
                        .add(referencePoints.get(referencePoints.size() - 1));
            }
        }
    }

    /**
     * Получить точку полилинии с заданным смещением относительно начала.
     *
     * @param polylinePoints массив точек полилинии.
     * @param offset         относительное смещение [0; 1].
     * @return смещенную точку.
     */
    public static BasePoint2D getPointOnPolylineByShift(
            List<? extends BasePoint2D> polylinePoints, double offset) {

        BasePoint2D result = new BasePoint2D(0.0, 0.0);

        if (polylinePoints.size() == 0)
            return result;

        if (offset <= 0.0)
            return new BasePoint2D(polylinePoints.get(0));

        if (offset >= 1.0)
            return new BasePoint2D(polylinePoints.get(polylinePoints.size() - 1));

        double polylineLen = getPolylineLength(polylinePoints);
        if (polylineLen < SMALL_FLOAT)
            return new BasePoint2D(polylinePoints.get(0));

        double currSegmentTotalLen = 0.0;
        double currSegmentLen = 0.0;

        if (polylinePoints.size() == 1)
            return new BasePoint2D(polylinePoints.get(0));

        for (int i = 0; i < polylinePoints.size() - 1; i++) {
            BasePoint2D p0 = polylinePoints.get(i);
            BasePoint2D p1 = polylinePoints.get(i + 1);
            currSegmentLen = GeometryUtils.distanceBetweenPoints(p0, p1);
            currSegmentTotalLen += currSegmentLen;
            if (currSegmentTotalLen / polylineLen > offset) {
                offset = 1.0 - (currSegmentTotalLen / polylineLen - offset) * polylineLen / currSegmentLen;
                result = GeometryUtils.absolute(p0, p1, offset);
                break;
            }
        }

        return result;
    }

    /**
     * Получить длину полилинии, описываемой точками.
     *
     * @param polylinePoints массив точек.
     * @return длина полилинии.
     */
    public static double getPolylineLength(List<? extends BasePoint2D> polylinePoints) {
        if (polylinePoints.size() < 2) return 0.0;
        double length = 0.0;
        BasePoint2D begin = polylinePoints.get(0);
        for (int i = 1, n = polylinePoints.size(); i < n; i++) {
            BasePoint2D end = polylinePoints.get(i);
            length += GeometryUtils.distanceBetweenPoints(begin, end);
            begin = end;
        }
        return length;
    }

    /**
     * Получить площадь фигуры.
     *
     * @param areaPoints точки фигуры.
     * @return площадь.
     */
    public static double getAreaSpace(List<? extends BasePoint2D> areaPoints) {
        double s = 0.0;

        for (int i = 1; i < areaPoints.size(); ++i) {
            BasePoint2D p1 = areaPoints.get(i);
            BasePoint2D p0 = areaPoints.get(i - 1);
            s += (p1.getX() - p0.getX()) * (p1.getY() + p0.getY()) / 2.0;
        }

        if (areaPoints.size() > 1) {
            BasePoint2D p1 = areaPoints.get(0);
            BasePoint2D p0 = areaPoints.get(areaPoints.size() - 1);
            s += (p1.getX() - p0.getX()) * (p1.getY() + p0.getY()) / 2.0;
        }

        return Math.abs(s);
    }

    /**
     * Получить ориентированный угол наклона касательной к полилинии в точке,
     * смещенной на относительно начала полилинии. Угол в радианах.
     *
     * @param polylinePoints - точки полилинии
     * @param offset         - смещение
     * @return Угол наклона.
     */
    public static double getPolylineTangentAngle(List<? extends BasePoint2D> polylinePoints, double offset) {

        if (polylinePoints.size() < 2) return 0.0;

        double length = getPolylineLength(polylinePoints);
        double targetLength = length * offset;
        double currentLength = 0.0;
        BasePoint2D begin = null;
        BasePoint2D end = polylinePoints.get(0);
        for (int i = 1, n = polylinePoints.size(); i < n; i++) {
            BasePoint2D point = polylinePoints.get(i);
            if (point.equals(end)) continue;
            begin = end;
            end = point;
            currentLength += GeometryUtils.distanceBetweenPoints(begin, end);
            if (currentLength >= targetLength) break;
        }

        if (begin != null && end != null) {
            double angle = GeometryUtils.mod(0.0, Math.PI * 2, GeometryUtils.angleBetweenPoints(end, begin, null));
            return angle;
        } else {
            return 0.0;
        }
    }

    /**
     * Получить количество точек на полилинии от ее начала до заданного
     * смещения.
     *
     * @param polylinePoints  массив точек полилинии.
     * @param offset          смещение.
     * @param startPointIndex Индекс начальной точки.
     * @return количество точек.
     */
    public static int getPointCountOnPolylineBeforeShift(
            List<BasePoint2D> polylinePoints, double offset,
            int startPointIndex) {

        int result = 0;

        if (offset < 0.0)
            return result;

        int polylinePointCount = polylinePoints.size();

        if (polylinePointCount == 0)
            return result;

        if (offset > 1.0) {
            result = polylinePointCount;
            return result;
        }

        double polylineLength = getPolylineLength(polylinePoints);
        if (polylineLength < SMALL_FLOAT)
            return result;

        if (startPointIndex >= polylinePointCount)
            return result;

        ArrayList<BasePoint2D> polylineBeforeStartPointPoints = new ArrayList<BasePoint2D>();
        for (int i = 0; i <= startPointIndex; i++) {
            polylineBeforeStartPointPoints.add(polylinePoints.get(i));
        }

        double currentFragmentLength = 0.0;

        currentFragmentLength = getPolylineLength(polylineBeforeStartPointPoints);
        if (((currentFragmentLength / polylineLength) > offset))
            return result;

        result = 1;
        double currentSegmentLength = 0.0;
        int count = polylinePointCount - 1;
        for (int i = startPointIndex; i < count; i++) {
            currentSegmentLength = GeometryUtils.distanceBetweenPoints(polylinePoints.get(i), polylinePoints.get(i + 1));
            currentFragmentLength += currentSegmentLength;
            if (((currentFragmentLength / polylineLength) > offset))
                break;

            result++;
        }

        return result;
    }


    /**
     * Преобразовать размер (вдоль оси X).
     *
     * @param transformation Преобразование.
     * @param size           Исходный размер.
     * @return Преобразованный размер.
     */
   public static double transformSize(BaseMatrix2D transformation, double size) {
        BasePoint2D p0 = transformation.transformPoint(new BasePoint2D(0, 0));
        BasePoint2D p1 = transformation.transformPoint(new BasePoint2D(size, 0));
        return GeometryUtils.distanceBetweenPoints(p0, p1);
    }

    /**
     * Получить точку пересечения прямых.
     *
     * @param x00 Координата x первой точки первой прямой.
     * @param y00 Координата y первой точки первой прямой.
     * @param x01 Координата x второй точки первой прямой.
     * @param y01 Координата y второй точки первой прямой.
     * @param x10 Координата x первой точки второй прямой.
     * @param y10 Координата y первой точки второй прямой.
     * @param x11 Координата x второй точки второй прямой.
     * @param y11 Координата y второй точки второй прямой.
     * @return Точка пересечения прямых или null.
     */
    public static BasePoint2D linesIntersection(
            double x00, double y00,
            double x01, double y01,
            double x10, double y10,
            double x11, double y11) {
        double a0 = y00 - y01;
        double b0 = x01 - x00;
        double c0 = x00 * y01 - x01 * y00;
        double a1 = y10 - y11;
        double b1 = x11 - x10;
        double c1 = x10 * y11 - x11 * y10;

        double n = a0 * b1 - a1 * b0;
        if (n * n < 1e-12) return null;

        double x = (b0 * c1 - b1 * c0) / n;
        double y = (a1 * c0 - a0 * c1) / n;

        return new BasePoint2D(x, y);
    }

    /**
     * Пересечение прямых.
     *
     * @param p00 Точка задающая первую прямую.
     * @param p01 Точка задающая первую прямую.
     * @param p10 Точка задающая вторую прямую.
     * @param p11 Точка задающая вторую прямую.
     * @return Точка пересечения прямых или null.
     */
    public static BasePoint2D linesIntersection(BasePoint2D p00, BasePoint2D p01, BasePoint2D p10, BasePoint2D p11) {
        return linesIntersection(
                p00.getX(), p00.getY(),
                p01.getX(), p01.getY(),
                p10.getX(), p10.getY(),
                p11.getX(), p11.getY());
    }

    /**
     * Пересечение прямых.
     *
     * @param p00 Точка задающая первую прямую.
     * @param p01 Точка задающая первую прямую.
     * @param p10 Точка задающая вторую прямую.
     * @param p11 Точка задающая вторую прямую.
     * @param b00 Первая линия ограничена первой точкой.
     * @param b01 Первая линия ограничена второй точкой.
     * @param b10 Вторая линия ограничена первой точкой.
     * @param b11 Вторая линия ограничена второй точкой.
     * @return Точка пересечения прямых или null.
     */
    public static BasePoint2D linesIntersection(
            BasePoint2D p00, BasePoint2D p01, BasePoint2D p10, BasePoint2D p11,
            boolean b00, boolean b01, boolean b10, boolean b11) {
        // Перечение прямых.
        BasePoint2D ip = linesIntersection(p00, p01, p10, p11);
        if (ip == null) return null;
        // Определение попадания точки пересечения в габариты отрезков.
        boolean b0 = checkPointForLineBounds(ip, p00, p01, b00, b01);
        boolean b1 = checkPointForLineBounds(ip, p10, p11, b10, b11);
        if (!(b0 && b1)) return null;
        // Результат.
        return ip;
    }


    /**
     * Пересечение отрезков.
     *
     * @param p00 Точка задающая первую прямую.
     * @param p01 Точка задающая первую прямую.
     * @param p10 Точка задающая вторую прямую.
     * @param p11 Точка задающая вторую прямую.
     * @return Точка пересечения отрезков или null.
     */
    public static BasePoint2D sectorsIntersection(BasePoint2D p00, BasePoint2D p01, BasePoint2D p10, BasePoint2D p11) {
        return linesIntersection(p00, p01, p10, p11, true, true, true, true);
    }


    /**
     * Порверка попадания точки в габариты линии (отрезка, луча, прямой).
     *
     * @param p  Точка.
     * @param p0 Первая точка линии.
     * @param p1 Вторая точка линии.
     * @param b0 Линия ограничена первой точкой.
     * @param b1 Линия ограничена второй точкой.
     * @return Признак попадания точки в габариты линии.
     */
    public static boolean checkPointForLineBounds(BasePoint2D p, BasePoint2D p0, BasePoint2D p1, boolean b0, boolean b1) {
        if (!b0 && !b1) return true;

        double x = p.getX();
        double y = p.getY();
        double x0 = p0.getX();
        double y0 = p0.getY();
        double x1 = p1.getX();
        double y1 = p1.getY();

        double kx = x1 != x0 ? (x - x0) / (x1 - x0) : 0.5;
        double ky = y1 != y0 ? (y - y0) / (y1 - y0) : 0.5;

        boolean result = false;
        if (b0 && b1) {
            result = (kx >= 0.0 && kx <= 1.0) && (ky >= 0.0 && ky <= 1.0);
        } else {
            result = (b0 && kx >= 0.0 || b1 && kx <= 1.0) && (b0 && ky >= 0.0 || b1 && ky <= 1.0);
        }
        return result;
    }


    /**
     * Получить расстояние от точки до линии, заданной двумя точками.
     *
     * @param p0 Первая точка линии.
     * @param p1 Вторая точка линии.
     * @param p  Точка, расстояние от которой до линии рассчитывается.
     * @return Расстояние от точки до линии.
     */
    public static double distanceToLine(BasePoint2D p0, BasePoint2D p1, BasePoint2D p) {
        double x0 = p0.getX();
        double y0 = p0.getY();
        double x1 = p1.getX() - x0;
        double y1 = p1.getY() - y0;
        double x = p.getX() - x0;
        double y = p.getY() - y0;

        double d = (x1 * y - y1 * x) / Math.sqrt(x1 * x1 + y1 * y1);
        return d >= 0.0 ? d : -d;
    }

    /**
     * Поучить ближайшую точку на линии, заданной двумя точками.
     *
     * @param p0 Первая точка линии.
     * @param p1 Вторая точка линии.
     * @param p  Точка, ближайшую точку к которой имщем.
     * @return Ближайшая точка линии.
     * null, Если p0 и p1 равны (линия не определена).
     */
    public static BasePoint2D nearestPointOnLine(BasePoint2D p0, BasePoint2D p1, BasePoint2D p) {
        if (p0.equals(p1)) {
            return new BasePoint2D(p0);
        }

        double projection = new BasePoint2D(p).projection(p0, p1);
        return GeometryUtils.absolute(p0, p1, projection);
    }

    /**
     * Получить ближайшую точку сектора, заданного точками.
     *
     * @param p0 Первая точка сектора.
     * @param p1 Вторая точка сектора.
     * @param p  Точка, ближайшую точку к которой ищем.
     * @return Ближайшая точка сектора.
     */
    public static BasePoint2D nearestPointOnSector(BasePoint2D p0, BasePoint2D p1, BasePoint2D p) {
        if (p0.equals(p1)) {
            return new BasePoint2D(p0);
        }

        double projection = new BasePoint2D(p).projection(p0, p1);
        if (projection <= 0.0) {
            return new BasePoint2D(p0);
        } else if (projection > 1.0) {
            return new BasePoint2D(p1);
        } else {
            return GeometryUtils.absolute(p0, p1, projection);
        }
    }

    /**
     * Получить ближайшую точку на полилинии.
     *
     * @param polylinePoints Точки полилинии.
     * @param point          Внешняя точка.
     * @return Точка на полилинии, ближайшая к внешней.
     */
    public static BasePoint2D nearestPointOnPolyline(List<? extends BasePoint2D> polylinePoints, BasePoint2D point) {
//		if (polylinePoints.size() == 0) return null;
//		else if (polylinePoints.size() == 1) return new SignPoint2D(polylinePoints.get(0));
//
//		SignPoint2D nearestPoint = null;
//		double minDistance = Double.MAX_VALUE;
//
//		SignPoint2D p0 = null;
//		SignPoint2D p1 = polylinePoints.get(0);
//		for (int i = 1, n = polylinePoints.size(); i < n; i++) {
//			p0 = p1;
//			p1 = polylinePoints.get(i);
//			SignPoint2D p = nearestPointOnSector(p0, p1, point);
//			double d = p.distance(point);
//			if (d < minDistance) {
//				nearestPoint = p;
//				minDistance = d;
//			}
//		}

        Iterator<? extends BasePoint2D> pointsIterator = polylinePoints.iterator();

        if (!pointsIterator.hasNext())
            return null;

        BasePoint2D p1 = pointsIterator.next();

        if (!pointsIterator.hasNext())
            return new BasePoint2D(p1);

        double x = point.getX();
        double y = point.getY();

        double x0, y0;
        double x1 = p1.getX();
        double y1 = p1.getY();

        // Квадрат расстояния.
        double minDistance = (x1 - x) * (x1 - x) + (y1 - y) * (y1 - y);
        double nearestX = p1.getX();
        double nearestY = p1.getY();

        while (pointsIterator.hasNext()) {
            x0 = x1;
            y0 = y1;
            p1 = pointsIterator.next();
            x1 = p1.getX();
            y1 = p1.getY();

            double nx, ny;

            double dx = x1 - x0;
            double dy = y1 - y0;
            double projection = ((x - x0) * dx + (y - y0) * dy) / (dx * dx + dy * dy);
            if (projection <= 0.0) {
                continue;
            } else if (projection >= 1.0) {
                nx = x1;
                ny = y1;
            } else {
                nx = x0 + dx * projection;
                ny = y0 + dy * projection;
            }

            double nd = (x - nx) * (x - nx) + (y - ny) * (y - ny);
            if (nd < minDistance) {
                minDistance = nd;
                nearestX = nx;
                nearestY = ny;
            }
        }

        return new BasePoint2D(nearestX, nearestY);
    }


    /**
     * Получить положение ближайшей точки на полилинии относительно её начала и конца.
     *
     * @param polylinePoints Точки полилинии.
     * @param point          Внешняя точка.
     * @return Положение ближайшей точки на полилинии относительно её начала и конца [0.0; 1.0].
     */
    public static double nearestPointLocationOnPolyline(List<? extends BasePoint2D> polylinePoints, BasePoint2D point) {
        if (polylinePoints.size() == 0) return Double.NaN;
        else if (polylinePoints.size() == 1) return 0.0;

        double minDistance = Double.MAX_VALUE;
        double nearestPointLocation = 0.0;
        double lineLength = 0.0;

        BasePoint2D p0 = null;
        BasePoint2D p1 = polylinePoints.get(0);
        for (int i = 1, n = polylinePoints.size(); i < n; i++) {
            p0 = p1;
            p1 = polylinePoints.get(i);
            double distance = GeometryUtils.distanceBetweenPoints(p0, p1);
            BasePoint2D p = nearestPointOnSector(p0, p1, point);
            double d = p.distanceToPoint(point);
            if (d < minDistance) {
                minDistance = d;
                BasePoint2D tp = GeometryUtils.relative(p0, p1, p);
                double t = Math.abs(p1.getX() - p0.getX()) > Math.abs(p1.getY() - p0.getY()) ? tp.getX() : tp.getY();
                nearestPointLocation = lineLength + distance * t;
            }
            lineLength += distance;
        }

        nearestPointLocation /= lineLength;

        return nearestPointLocation;
    }


    /**
     * Получить зеркальное отражение точки относительно прямой, заданной двумя точками.
     *
     * @param p1               Первая точка прямой.
     * @param p2               Вторая точка прямой.
     * @param reflectablePoint Отражаемая точка.
     * @return Отражённая точка.
     */
    /*
    public static BasePoint2D oppositeMirrorReflect(BasePoint2D p1, BasePoint2D p2, BasePoint2D reflectablePoint) {
        BasePoint2D intersectionPoint = nearestPointOnLine(p1, p2, reflectablePoint);
        BasePoint2D translation = new BasePoint2D(new BasePoint2D(reflectablePoint).sub(intersectionPoint));
        BasePoint2D resultPoint = new BasePoint2D(new BasePoint2D(intersectionPoint).translate(translation.mul(-1)));
        return resultPoint;
    }
    */

    /**
     * Точки касания линий, соединяющих две окружности.
     *
     * @param c0 Центр первой окружности.
     * @param r0 Радиус первой окружности.
     * @param c1 Центр второй окружности.
     * @param r1 Радиус второй окружности.
     * @return Точки касания линий, соединяющих две окружности.
     * <p>Результат составляют 8 точек (4 пары точек):
     * первые две пары точек описывают две внешние (не пересекающиеся) касательные, соединяющие окружности,
     * вторые две пары точек описывают две внутренние (пересекающиеся) касательные, соединяющие окружности.
     * <p>Если существование внешних касательных невозможно (одна окружность полностью лежит во второй), то первые четыре точки будут null.
     * <p>Если существование внутренних касательных невозможно (расстояние между окружностями меньше суммы из радиусов), то последние четыре точки будут null.
     */
    // todo: !!!!
    public static BasePoint2D[] circlesTangentPoints(BasePoint2D c0, double r0, BasePoint2D c1, double r1) {
        // Результат.
        BasePoint2D[] points = new BasePoint2D[8];

        // Центры окружностей в виде удобных классов.
        BasePoint2D pc0 = new BasePoint2D(c0);
        BasePoint2D pc1 = new BasePoint2D(c1);
        // Начальные точки на окружностях в виде удобных классов.
        BasePoint2D pr0 = new BasePoint2D(c0).add(r0, 0.0);
        BasePoint2D pr1 = new BasePoint2D(c1).add(r1, 0.0);

        // Расстояние между центрами окружностей.
        double distance = pc1.distanceToPoint(pc0);
        // Угол наклона отрезка, соединяющего центры окружностей.
        double distanceAngle = pc1.angle(pc0);
        // Отношение радиусов к расстоянию между центрами.
        double t;
        // Аркосинус(t).
        double ac;
        // Угол точки касания к окружности.
        double a;

        // Точки внешних касательных.
        t = (r1 - r0) / distance;
        if (GeometryUtils.isIn(t, -1.0, 1.0)) {
            ac = Math.acos(t);

            a = distanceAngle + Math.PI - ac;
            points[0] = new BasePoint2D(pr0).rotate(a, c0);
            points[1] = new BasePoint2D(pr1).rotate(a, c1);

            a = distanceAngle + Math.PI + ac;
            points[2] = new BasePoint2D(pr0).rotate(a, c0);
            points[3] = new BasePoint2D(pr1).rotate(a, c1);
        }

        // Точки внутренних касательных.
        t = (r1 + r0) / distance;
        if (GeometryUtils.isIn(t, -1.0, 1.0)) {
            ac = Math.acos(t);

            a = distanceAngle + ac;
            points[4] = new BasePoint2D(pr0).rotate(a, c0);
            points[5] = new BasePoint2D(pr1).rotate(a + Math.PI, c1);

            a = distanceAngle - ac;
            points[6] = new BasePoint2D(pr0).rotate(a, c0);
            points[7] = new BasePoint2D(pr1).rotate(a + Math.PI, c1);
        }

        return points;
    }

    /**
     * Расчитать смещённую линию.
     *
     * @param shift       Смещение.
     * @param mitterLimit Обрезать длинные острые углы.
     * @param antiStitch  Обрезать петли.
     * @param polyline    Точки полилинии.
     * @return Точки смещённой полилинии.
     */
    public static List<BasePoint2D> shiftPolyline(Shift shift, double mitterLimit, boolean antiStitch, List<? extends BasePoint2D> polyline) {
        /**
         * Информаци о петле.
         */
        class Stitch {
            /** Индекс исходной точки. */
            public int srcIndex;
            /** Индекс смещённой точки. */
            public int shiftedIndex;
            /** Точка пересечения направляющей смещения и сегментом смещённой полилинии. */
            public BasePoint2D guideIntersection;

            public Stitch(int srcIndex, int shiftedIndex, BasePoint2D guideIntersection) {
                this.srcIndex = srcIndex;
                this.shiftedIndex = shiftedIndex;
                this.guideIntersection = guideIntersection;
            }

            @Override
            public String toString() {
                return String.format("%d, %d, %s", srcIndex, shiftedIndex, guideIntersection);
            }
        }


        // Смещённая полилиния.
        List<BasePoint2D> shiftedPolyline = new ArrayList<BasePoint2D>(polyline.size());

        // Если смещение нулевое или меньше двух точек, то делать здесь нечего.
        if (shift.isZero() || polyline.size() < 2) {
            for (BasePoint2D p : polyline)
                shiftedPolyline.add(new BasePoint2D(p));
            return shiftedPolyline;
        }

        // На каждой итерации работаем с двумя сегментами полилинии.
        // Начало первого сегмента, общая для двух сегментов точка, конец второго сегмента:
        BasePoint2D p0, p1 = null, p2;
        // Смещённые точки сегментов:
        BasePoint2D sp0 = null, sp10 = null, sp1, sp12, sp2;
        // Исходная и смещённая общие точки сегментов с предыдущей итерации:
        // Необходимы для обнаружения петли.
        BasePoint2D pp1 = null, psp1 = null;
        // Длина исходной линии и относительные положения точек на линии.
        double polylineLength = getPolylineLength(polyline);
        double t0, t1 = 0.0, t2;

        // Петли.
        List<Stitch> stitches = new ArrayList<Stitch>();

        // Первая точка.
        p0 = new BasePoint2D(polyline.get(0));
        t0 = 0.0;

        // Идём по сегментам, начиная со второго.
        for (int i = 1, n = polyline.size(); i < n; i++) {
            BasePoint2D point = new BasePoint2D(polyline.get(i));

            if (p1 == null) {
                // Собираем информацию о первом сегменте.

                // Если текущая точка совпадает с предыдущей, игнорируем её.
                if (point.equals(p0)) continue;

                // Переназначаем переменные для следующей итерации.
                pp1 = p0;
                p1 = point;
                t1 = (t0 * polylineLength + p1.distanceToPoint(p0)) / polylineLength;
                sp0 = new BasePoint2D(p0).translateOrtho(shift.getShift(t0), p1);
                sp10 = new BasePoint2D(p1).translateOrtho(-shift.getShift(t1), p0);
                psp1 = sp0;
                sp1 = sp10;

                // Добавляем смещённую точку в смещённую полилинию.
                shiftedPolyline.add(sp0);

            } else {
                // Обрабатываем остальные сегменты полилинии.

                // Если текущая точка совпадает с предыдущей, игнорируем её.
                if (point.equals(p1)) continue;

                // Получаем второй отрезок и расчитываем его смещение.
                p2 = point;
                t2 = (t1 * polylineLength + p2.distanceToPoint(p1)) / polylineLength;
                sp12 = new BasePoint2D(p1).translateOrtho(shift.getShift(t1), p2);
                sp2 = new BasePoint2D(p2).translateOrtho(-shift.getShift(t2), p1);

                // Расчитываем точку пересечения смещённых отрезков (смещённую угловую точку).
                sp1 = linesIntersection(sp0, sp10, sp2, sp12);

                // Флаг обрезания длинного угла.
                boolean cutMitter = false;

                if (sp1 == null) {
                    // Отрезки оказались параллельными.

                    // Получаем точку обрезки длинного (здась бесконечного) угла.
                    double d = p0.distanceToPoint(p1);
                    sp1 = GeometryUtils.absolute(GeometryUtils.average(p0, sp0), GeometryUtils.average(p1, sp10), (d + shift.getShift(t1)) / d);
                    cutMitter = true;

                } else {
                    // Сегменты успешно пересеклись.

                    if (mitterLimit > 0) {
                        // Модуль смещения (необходим для обрезания длинных углов).
                        double absShift = Math.abs(shift.getShift(t1));
                        // Определяем параметры обрезания длинного угла.
                        // Длинность угла определяется из растояния между смещённой и несмещённой точками.
                        // При этом обрезается только внешний угол.
                        double d = p1.distanceToPoint(sp1);
                        if (d / absShift > mitterLimit && sp1.distanceToPoint(p0) > p1.distanceToPoint(p0)) {
                            sp1 = GeometryUtils.absolute(p1, sp1, mitterLimit * absShift / d);
                            cutMitter = true;
                        }
                    }

                }

                // Обрезаем длинный угол.
                // todo: commented temporary!!!
                /*
                if (cutMitter) {
                    BasePoint2D sp1n = new BasePoint2D(p1).rotateOrtho(sp1);
                    BasePoint2D sp1o = sp1;
                    sp1 = linesIntersection(sp0, sp10, sp1o, sp1n);
                    shiftedPolyline.add(sp1);
                    sp1 = linesIntersection(sp2, sp12, sp1o, sp1n);
                }
                */

                // Добавляем смещённую точку в смещённую полилинию.
                shiftedPolyline.add(sp1);

                // Если включена защита от петель, определяем наличие петли и её параметры.
                if (antiStitch && psp1 != null) {
                    if (sectorsIntersection(pp1, psp1, p1, sp1) != null) {
                        BasePoint2D guideIntersection = null;
                        if (psp1 != sp0) // Игнорируем петлю, не являющуюся петлёй для второй итерации.
                            guideIntersection = linesIntersection(pp1, psp1, sp12, sp2, true, true, false, false);
                        stitches.add(new Stitch(i - 1, shiftedPolyline.size() - 1, guideIntersection));
                    }
                }

                // Готовимся к следующей итерации: второй отрезок становится первым.
                p0 = p1;
                sp0 = sp12;
                pp1 = p1;
                p1 = p2;
                sp10 = sp2;
                psp1 = sp1;

                t0 = t1;
                t1 = t2;
            }
        }

        // Запоминаем последнюю смещённую точку.
        // sp10 может быть null, если ни одна итерация цикла смещения полноценно не закончилась.
        if (sp10 != null)
            shiftedPolyline.add(sp10);

        // Проверяем замкнутость.
        int shiftedPolylineSize = shiftedPolyline.size();
        boolean closed = shiftedPolylineSize >= 3 && polyline.get(0).equals(polyline.get(polyline.size() - 1));
        // Замыкаем линию.
        if (closed) {
            // Последние точки.
            sp0 = shiftedPolyline.get(shiftedPolylineSize - 2);
            sp10 = shiftedPolyline.get(shiftedPolylineSize - 1);
            // Первые точки.
            sp12 = shiftedPolyline.get(0);
            sp2 = shiftedPolyline.get(1);

            // Пересечение последнего сегмента с первым.
            p1 = new BasePoint2D(polyline.get(0));
            sp1 = linesIntersection(sp0, sp10, sp2, sp12);

            // todo: commented temporary!!!
            /*
            if (sp1 != null) {
                shiftedPolyline.get(0).init(sp1);
                shiftedPolyline.get(shiftedPolylineSize - 1).init(sp1);
            }
            */

            // Обнаруживаем последнюю петлю.
            if (antiStitch && sp1 != null && psp1 != null) {
                if (sectorsIntersection(pp1, psp1, p1, sp1) != null) {
                    stitches.add(new Stitch(polyline.size() - 1, shiftedPolylineSize - 1, null));
                }
            }
        }

        // Старый антипетельный функционал.
        // вызываем только если найдены петли.
        // todo: commented temporary!!!
        /*
        if (antiStitch && !stitches.isEmpty()) {
            //Дополнительная проверка точек
            checkPointsDistance(polyline, shiftedPolyline, Math.abs((shift.getShift(0.0) + shift.getShift(1.0)) * 0.5));
            for (int i = 1, n = shiftedPolyline.size() - 1; i < n; i++) {
                if (shiftedPolyline.get(i - 1).isNear(shiftedPolyline.get(i), 0.1)) {
                    shiftedPolyline.remove(i);
                    i--;
                    n--;
                }
            }
        }
        */

//		// Новый антипетельный функционал
//		if (antiStitch) {
//
//			org.radar.z22.service.GlobalLogger.debug("Stitches:%s", GeometryUtils.join(stitches, "", "\n\t", ""));
//
//			int sn = stitches.size();
//			int fsi = 0;
//			int dpi = 0;
//
//			if (closed && stitches.size() > 1) {
//				Stitch stitch = stitches.get(fsi);
//				for (int i = 1; i < sn; i++) {
//					int psi = sn - i;
//					Stitch prevStitch = stitches.get(psi);
//					if (prevStitch.shiftedIndex == shiftedPolylineSize - i) {
//						org.radar.z22.service.GlobalLogger.debug("ps: %d/%d, %d, {%s}, %d/%d", i, sn, psi, prevStitch, shiftedPolylineSize - i, shiftedPolylineSize);
//						fsi = psi;
//					} else break;
//				}
//			}
//
//			si: for (int si = 0; si < sn; si++) {
//
//				Stitch stitch = stitches.get((si + fsi) % sn);
//				Stitch nextStitch = stitches.get((si + fsi + 1) % sn);
//
//				org.radar.z22.service.GlobalLogger.debug("si: %d; %d:{%s}, %d:{%s}", si, (si + fsi) % sn, stitch, (si + fsi + 1) % sn, nextStitch);
//
//				int esi = -1;
//				int nsi = -1;
//				SignPoint2D intersectionPoint = null;
//
//				if (stitch.guideIntersection != null) {
//					esi = stitch.shiftedIndex - dpi - 2;
//					nsi = stitch.shiftedIndex - dpi;
//					SignPoint2D ep0 = shiftedPolyline.get(esi);
//					SignPoint2D ep1 = shiftedPolyline.get(esi + 1);
//					sp0 = shiftedPolyline.get(stitch.shiftedIndex - dpi);
//					sp1 = shiftedPolyline.get((stitch.shiftedIndex - dpi + 1) % shiftedPolylineSize);
//					intersectionPoint = linesIntersection(ep0, ep1, sp0, sp1, true, false, false, false);
//					org.radar.z22.service.GlobalLogger.debug("A. %s, %d, %s", stitch.guideIntersection, esi, intersectionPoint);
//				}
//
//				if (intersectionPoint == null) {
//
//					np: for (int npi = 0; npi < shiftedPolylineSize; npi++) {
//
//						int sspi0 = (npi + stitch.srcIndex) % polyline.size();
//						int snpi0 = (npi + stitch.shiftedIndex - dpi) % shiftedPolylineSize;
//						int snpi1 = (npi + stitch.shiftedIndex - dpi + 1) % shiftedPolylineSize;
//
//						org.radar.z22.service.GlobalLogger.debug("np: %d; %d, %d, %d", npi, sspi0, snpi0, snpi1);
//
//						if (nextStitch.shiftedIndex - dpi == snpi1) {
//							si++;
//							org.radar.z22.service.GlobalLogger.debug("si++: %d", si);
//							continue si;
//						}
//
//						p0 = shiftedPolyline.get(sspi0);
//						sp0 = shiftedPolyline.get(snpi0);
//						sp1 = shiftedPolyline.get(snpi1);
//
//						for (int epi = 0; epi < shiftedPolylineSize; epi++) {
//
//							int sepi0 = (shiftedPolylineSize + stitch.shiftedIndex - dpi - epi - 1) % shiftedPolylineSize;
//							int sepi1 = (shiftedPolylineSize + stitch.shiftedIndex - dpi - epi) % shiftedPolylineSize;
//
//							org.radar.z22.service.GlobalLogger.debug("ep: %d; %d, %d", epi, sepi0, sepi1);
//
//							SignPoint2D ep0 = shiftedPolyline.get(sepi0);
//							SignPoint2D ep1 = shiftedPolyline.get(sepi1);
//
//							boolean curSegBeginBound = linesIntersection(p0, sp0, ep0, ep1, true, true, true, true) == null;
//							intersectionPoint = linesIntersection(sp0, sp1, ep0, ep1, curSegBeginBound, true, true, true);
//							if (intersectionPoint != null) {
//								org.radar.z22.service.GlobalLogger.debug("B. %b, %s", curSegBeginBound, intersectionPoint);
//								nsi = snpi0;
//								esi = sepi0;
//								break np;
//							}
//
//						}
//
//					}
//				}
//
//				if (intersectionPoint != null) {
//					org.radar.z22.service.GlobalLogger.debug("RESULT: %d, %d, %d", stitch.shiftedIndex, nsi, esi);
//					shiftedPolyline.set(nsi, intersectionPoint);
//					boolean throughtClosingPoint = false;
//					for (int i = esi + 1; i != nsi; i = (i + 1) % shiftedPolylineSize) {
//						org.radar.z22.service.GlobalLogger.debug("-a-: %d/%d -> %d/%d", i, shiftedPolylineSize, i - 1, shiftedPolylineSize - 1);
//						shiftedPolyline.remove(i--);
//						shiftedPolylineSize--;
//						if (i < nsi) {
//							org.radar.z22.service.GlobalLogger.debug("-b-: %d, %d -> %d, %d", nsi, nsi - 1, dpi, dpi + 1);
//							nsi--;
//							dpi++;
//						} else {
//							throughtClosingPoint = true;
//						}
//					}
//					if (throughtClosingPoint)
//						shiftedPolyline.add(intersectionPoint);
//				}
//
//			}
//
//		}

//		org.radar.z22.service.GlobalLogger.debug("Shifted polyline:\n\t%s", GeometryUtils.join(shiftedPolyline, "\n\t", "", ""));

        return shiftedPolyline;
    }

    /**
     * Расчитать смещённую линию.
     *
     * @param shift       Смещение.
     * @param mitterLimit Обрезать длинные острые углы.
     * @param antiStitch  Обрезать петли.
     * @param polyline    Точки полилинии.
     * @return Точки смещённой полилинии.
     */
    public static List<BasePoint2D> shiftPolyline(double shift, double mitterLimit, boolean antiStitch, List<? extends BasePoint2D> polyline) {
        return shiftPolyline(new ConstShift(shift), mitterLimit, antiStitch, polyline);
    }


    /**
     * Вырезать кусок из полилинии.
     *
     * @param polyline     Полилиния.
     * @param segmentIndex Индекс сегмента для поиска начало вырезаемой части.
     * @param offset       Смещение точки отрезания от начала сегмента в мм.
     * @param length       Длина вырезаемой части линии в мм.
     * @return Точки вырезанной линии.
     */
    public static List<BasePoint2D> getSubPolyline(List<? extends BasePoint2D> polyline, int segmentIndex, double offset, double length) {
        List<BasePoint2D> subPolyline = new ArrayList<BasePoint2D>();

        if (segmentIndex < 0) segmentIndex = 0;
        if (segmentIndex >= polyline.size() - 1) return subPolyline;

        int numberOfPoints = polyline.size();
        int index = segmentIndex + 1;
        BasePoint2D p1 = null;
        BasePoint2D p2 = polyline.get(segmentIndex);
        double currentLength = 0.0;

        for (; index < numberOfPoints; index++) {
            p1 = p2;
            p2 = polyline.get(index);
            currentLength += GeometryUtils.distanceBetweenPoints(p1, p2);
            if (currentLength > offset) break;
        }
        if (currentLength < offset) return subPolyline;

        p1 = GeometryUtils.absolute(p2, p1, (currentLength - offset) / GeometryUtils.distanceBetweenPoints(p2, p1));
        subPolyline.add(new BasePoint2D(p1));
        currentLength = GeometryUtils.distanceBetweenPoints(p2, p1);
        index++;

        for (; index < numberOfPoints && currentLength < length; index++) {
            p1 = p2;
            p2 = polyline.get(index);
            currentLength += GeometryUtils.distanceBetweenPoints(p1, p2);
            subPolyline.add(new BasePoint2D(p1));
        }
        if (currentLength < length) return subPolyline;

        p1 = GeometryUtils.absolute(p2, p1, (currentLength - length) / GeometryUtils.distanceBetweenPoints(p2, p1));
        subPolyline.add(new BasePoint2D(p1));

        return subPolyline;
    }


    /**
     * Проверка расстояния между точками.
     *
     * @param patternPolylinePoints Исходные точки.
     * @param testPolylinePoints    Проверяемые точки.
     * @param distance              максимально допустимое растояние между точками .
     */
    /*
    private static void checkPointsDistance(List<? extends BasePoint2D> patternPolylinePoints, List<? extends BasePoint2D> testPolylinePoints, double distance) {

        for (int i = 0; i < testPolylinePoints.size(); ++i) {
            BasePoint2D p1 = testPolylinePoints.get(i);

            if (!isGoodPoint(p1, patternPolylinePoints, distance)) {
                if (!transformPoint(testPolylinePoints, i, patternPolylinePoints, distance)) {
                    testPolylinePoints.remove(i);
                    --i;
                }
            }
        }
    }
    */

    // TODO разобраться со значениями.

    /**
     * Трансформаия точек.
     *
     * @param patternPolylinePoints Исходные точки.
     * @param testPolylinePoints    Проверяемые точки.
     * @param index                 <Разобраться>
     * @param distance              Максимально допустимое растояние между точками.
     * @return Результат операции.
     */
    /*
    private static boolean transformPoint(List<? extends BasePoint2D> testPolylinePoints, int index, List<? extends BasePoint2D> patternPolylinePoints, double distance) {
        //Случаи удаления точки ----->
        if (testPolylinePoints.size() <= 1) {
            return false;
        }

        //Если с краю и рядом нету хороших точек --->
        if (index == 0 && !isGoodPoint(testPolylinePoints.get(index + 1), patternPolylinePoints, distance)) {
            return false;
        }

        if (index == testPolylinePoints.size() - 1 && !isGoodPoint(testPolylinePoints.get(index - 1), patternPolylinePoints, distance)) {
            return false;
        }
        //<---
        //Если рядом нету хороших точек
        if (index != 0 && index != testPolylinePoints.size() - 1 && !isGoodPoint(testPolylinePoints.get(index - 1), patternPolylinePoints, distance) && !isGoodPoint(testPolylinePoints.get(index + 1), patternPolylinePoints, distance)) {
            return false;
        }
        //<-----

        //Случаи трансформации точки ----->
        //Если побокам хорошие точки, то исходную точку перемещаем в сторону двух соседних пропорционально расстоянию до каждой из них
        if (index != 0 && index != testPolylinePoints.size() - 1 && isGoodPoint(testPolylinePoints.get(index - 1), patternPolylinePoints, distance) && isGoodPoint(testPolylinePoints.get(index + 1), patternPolylinePoints, distance)) {
            if (correctXY(testPolylinePoints.get(index - 1), testPolylinePoints.get(index + 1), testPolylinePoints.get(index), patternPolylinePoints, distance)) {
                return true;
            } else {
                return false;
            }
        } else {

            if (index == 0 && correctXY(testPolylinePoints.get(index + 1), testPolylinePoints.get(index), patternPolylinePoints, distance)) {
                return true;
            }

            if (index == testPolylinePoints.size() - 1 && correctXY(testPolylinePoints.get(index - 1), testPolylinePoints.get(index), patternPolylinePoints, distance)) {
                return true;
            }


            if (index != 0 && index != testPolylinePoints.size() - 1 && correctXY(testPolylinePoints.get(index - 1), testPolylinePoints.get(index + 1), testPolylinePoints.get(index), patternPolylinePoints, distance)) {
                return true;
            }

            if (index != 0 && correctXY(testPolylinePoints.get(index - 1), testPolylinePoints.get(index), patternPolylinePoints, distance)) {
                return true;
            }

            if (index != testPolylinePoints.size() - 1 && correctXY(testPolylinePoints.get(index + 1), testPolylinePoints.get(index), patternPolylinePoints, distance)) {
                return true;
            }

            return false;

        }
        //<-----
//		return false;
    }
    */

    /**
     * Формирование проверки центральной точки образованной из двух точек.
     *
     * @param p1                    Первая точка.
     * @param p2                    Вторая точка.
     * @param ptransform            Точка трансформирования.
     * @param patternPolylinePoints Исходные точки.
     * @param distance              Расстояние между точками.
     * @return Результат операции.
     */
    /*
    private static boolean correctXY(BasePoint2D p1, BasePoint2D p2, BasePoint2D ptransform, List<? extends BasePoint2D> patternPolylinePoints, double distance) {

        //Формирование центральной точки прямой
        BasePoint2D pcenter = new BasePoint2D((p1.getX() + p2.getX()) / 2.0, (p1.getY() + p2.getY()) / 2.0);
        if (!isGoodPoint(pcenter, patternPolylinePoints, distance)) {
            return false;
        }

        return correctXY(pcenter, ptransform, patternPolylinePoints, distance);

    }
    */

    /**
     * Проверка центральных точек на соответствие дистанционному критерию.
     *
     * @param pcenter               - центральная точка.
     * @param ptransform            - точка трансформирования
     * @param patternPolylinePoints - исходные точки.
     * @param distance              растояние - между точками.
     * @return Результат операции.
     */
    /*
    private static boolean correctXY(BasePoint2D pcenter, BasePoint2D ptransform, List<? extends BasePoint2D> patternPolylinePoints, double distance) {

        BasePoint2D c = getCenter(pcenter, ptransform);
        BasePoint2D last = new BasePoint2D();
        boolean f = false;

        for (int i = 0; i < 10; ++i) {
            if (isGoodPoint(c, patternPolylinePoints, distance)) {
                last.setX(c.getX());
                last.setY(c.getY());

                c = getCenter(c, ptransform);
                f = true;
                //return true;
            } else {
                c = getCenter(c, pcenter);
            }
        }

        if (f) {
            ptransform.setX(last.getX());
            ptransform.setY(last.getY());

            return true;
        }

        return false;

//		//SignPoint2D center;
//
//		double step = 10.0;
//
//		for( int i = 0; i < step ; ++i )
//		{
//			ptransform.setX( ptransform.getX() - width/step  );
//			ptransform.setY( ptransform.getY() - height/step  );
//
//			if( isGoodPoint(ptransform, patternPolylinePoints, distance) )
//			{
//				return true;
//			}
//		}
//
//		return false;
    }
     */

    /**
     * Взять точку, расположенную между двумя заданными.
     *
     * @param p1 - первая точка.
     * @param p2 - вторая точка.
     * @return точка, рассположенная между двумя заданными.
     */
    private static BasePoint2D getCenter(BasePoint2D p1, BasePoint2D p2) {
        return new BasePoint2D((p1.getX() + p2.getX()) / 2.0, (p1.getY() + p2.getY()) / 2.0);
    }

    /**
     * Проверка соответсвут ли точка дистанционному критерию.
     *
     * @param p                     - проверяемая точка.
     * @param patternPolylinePoints - Исходные точки.
     * @param distance              - растояние между точками.
     * @return результат проверки.
     */
    private static boolean isGoodPoint(BasePoint2D p, List<? extends BasePoint2D> patternPolylinePoints, double distance) {
        BasePoint2D p1;
        BasePoint2D p2;
        BasePoint2D pointIn;
        double minx, maxx, miny, maxy;

        for (int i = 0; i < patternPolylinePoints.size(); ++i) {
            if (GeometryUtils.distanceBetweenPoints(p, patternPolylinePoints.get(i)) + 0.01 < distance) {
                return false;
            }

            if (i != 0) {
                p1 = patternPolylinePoints.get(i - 1);
                p2 = patternPolylinePoints.get(i);
                pointIn = new BasePoint2D(p).project(p1, p2);

                if (p1.getX() < p2.getX()) {
                    minx = p1.getX();
                    maxx = p2.getX();
                } else {
                    minx = p2.getX();
                    maxx = p1.getX();
                }

                if (p1.getY() < p2.getY()) {
                    miny = p1.getY();
                    maxy = p2.getY();
                } else {
                    miny = p2.getY();
                    maxy = p1.getY();
                }

                if (pointIn.getX() >= minx && pointIn.getX() <= maxx
                        && pointIn.getY() >= miny && pointIn.getY() <= maxy
                        && pointIn.distanceToPoint(p) + 0.01 < distance) {
                    return false;
                }
            }
        }

        return true;
    }


    //-------------------------------------------------------------------------
    // Функции создания точек примитивов
    //-------------------------------------------------------------------------

    /**
     * Создать окружность.
     *
     * @param cx             Координата x центра.
     * @param cy             Координата y центра.
     * @param radius         Радиус.
     * @param beginAngle     Начальный угол.
     * @param endAngle       Конечный угол.
     * @param numberOfPoints Количество точек.
     * @return Точки полилинии.
     */
    public static List<BasePoint2D> createCircle(
            double cx, double cy, double radius,
            double beginAngle, double endAngle,
            int numberOfPoints) {
        List<BasePoint2D> shape = new ArrayList<BasePoint2D>(numberOfPoints);

        if (GeometryUtils.isNear(beginAngle, endAngle))
            endAngle += Math.PI * 2;

        double da = (endAngle - beginAngle) / (numberOfPoints - 1);
        double a = beginAngle;
        for (int i = 0; i < numberOfPoints; i++) {
            shape.add(new BasePoint2D(cx + radius * Math.cos(a), cy + radius * Math.sin(a)));
            a += da;
        }

        return shape;
    }

    /**
     * Создать окружность.
     *
     * @param center         Центр.
     * @param radius         Радиус.
     * @param beginAngle     Начальный угол.
     * @param endAngle       Конечный угол.
     * @param numberOfPoints Количесвто точек.
     * @return Точки окружности.
     */
    public static List<BasePoint2D> createCircle(
            BasePoint2D center, double radius,
            double beginAngle, double endAngle,
            int numberOfPoints) {
        return createCircle(center.getX(), center.getY(), radius, beginAngle, endAngle, numberOfPoints);
    }

    /**
     * Создать окружность.
     *
     * @param cx             Координата x центра.
     * @param cy             Координата y центра.
     * @param radius         Радиус.
     * @param numberOfPoints Количество точек.
     * @return Точки окружности.
     */
    public static List<BasePoint2D> createCircle(
            double cx, double cy, double radius,
            int numberOfPoints) {
        return createCircle(cy, cx, radius, 0.0, 0.0, numberOfPoints);
    }

    /**
     * Создать окружность.
     *
     * @param center         Центр.
     * @param radius         Радиус.
     * @param numberOfPoints Количество точек.
     * @return Точки окружности.
     */
    public static List<BasePoint2D> createCircle(
            BasePoint2D center, double radius,
            int numberOfPoints) {
        return createCircle(center.getX(), center.getY(), radius, 0.0, 0.0, numberOfPoints);
    }

    /**
     * Создать окружность по 16 точкам.
     *
     * @param cx     Координата x центра.
     * @param cy     Координата y центра.
     * @param radius Радиус.
     * @return Точки окружности.
     */
    public static List<BasePoint2D> createCircle(
            double cx, double cy, double radius) {
        return createCircle(cx, cy, radius, 0.0, 0.0, 16);
    }

    /**
     * Создать окружность по 16 точкам.
     *
     * @param center Центр.
     * @param radius Радиус.
     * @return Точки окружности.
     */
    public static List<BasePoint2D> createCircle(
            BasePoint2D center, double radius) {
        return createCircle(center.getX(), center.getY(), radius, 0.0, 0.0, 16);
    }

    /**
     * Создать окружность по 16 точкам.
     *
     * @param cx         Координата x центра.
     * @param cy         Координата y центра.
     * @param radius     Радиус.
     * @param beginAngle Начальный угол.
     * @param endAngle   Конечный угол.
     * @return Точки окружности.
     */
    public static List<BasePoint2D> createCircle(
            double cx, double cy, double radius,
            double beginAngle, double endAngle) {
        return createCircle(cx, cy, radius, beginAngle, endAngle, 16);
    }

    /**
     * Создать окружность по 16 точкам.
     *
     * @param center     Центр.
     * @param radius     Радиус.
     * @param beginAngle Начальный угол.
     * @param endAngle   Конечный угол.
     * @return Точки окружности.
     */
    public static List<BasePoint2D> createCircle(
            BasePoint2D center, double radius,
            double beginAngle, double endAngle) {
        return createCircle(center.getX(), center.getY(), radius, beginAngle, endAngle, 16);
    }

    /**
     * Создать еллипс.
     *
     * @param cx             Координата x центра.
     * @param cy             Координата y центра.
     * @param radius1        Первый радиус.
     * @param radius2        Второй радиус.
     * @param angle          Угол первого радиуса.
     * @param beginAngle     Начальный угол.
     * @param endAngle       Конечный угол.
     * @param numberOfPoints Количество точек.
     * @return Точки полилинии.
     */
    public static List<BasePoint2D> createEllipse(
            double cx, double cy, double radius1, double radius2,
            double angle,
            double beginAngle, double endAngle,
            int numberOfPoints) {
        List<BasePoint2D> shape = new ArrayList<BasePoint2D>(numberOfPoints);

        double angularLength = GeometryUtils.mod(0.0, Math.PI * 2.0, endAngle - beginAngle);
        beginAngle = GeometryUtils.mod(0.0, Math.PI * 2.0, beginAngle);
        endAngle = beginAngle + angularLength;
        if (GeometryUtils.isNear(beginAngle, endAngle))
            endAngle += Math.PI * 2;

        double da = (endAngle - beginAngle) / (numberOfPoints - 1);
        double a = beginAngle;
        for (int i = 0; i < numberOfPoints; i++) {
            shape.add(new BasePoint2D(cx + radius1 * Math.cos(a), cy + radius2 * Math.sin(a)));
            a += da;
        }

        angle = GeometryUtils.mod(0.0, Math.PI * 2.0, angle);
        if (!GeometryUtils.isNearZero(angle))
            for (BasePoint2D p : shape)
                p.rotate(angle, cx, cy);

        return shape;
    }

    /**
     * Создать еллипс.
     *
     * @param center         Центр.
     * @param radius1        Первый радиус.
     * @param radius2        Второй радиус.
     * @param angle          Угол первого радиуса.
     * @param beginAngle     Начальный угол.
     * @param endAngle       Конечный угол.
     * @param numberOfPoints Количество точек.
     * @return Точки полилинии.
     */
    public static List<BasePoint2D> createEllipse(
            BasePoint2D center, double radius1, double radius2,
            double angle,
            double beginAngle, double endAngle,
            int numberOfPoints) {
        return createEllipse(center.getX(), center.getY(), radius1, radius2, angle, beginAngle, endAngle, numberOfPoints);
    }


    /**
     * Создать точки прямоугольника по координатам угловых точек.
     *
     * @param x1 Координата x первой точки.
     * @param y1 Координата y первой точки.
     * @param x2 Координата x второй точки.
     * @param y2 Координата y второй точки.
     * @return Точки прямоугольника.
     */
    public static List<BasePoint2D> createRectanglePP(double x1, double y1, double x2, double y2) {
        List<BasePoint2D> shape = new ArrayList<BasePoint2D>();
        shape.add(new BasePoint2D(x1, y1));
        shape.add(new BasePoint2D(x2, y1));
        shape.add(new BasePoint2D(x2, y2));
        shape.add(new BasePoint2D(x1, y2));
        shape.add(new BasePoint2D(x1, y1));
        return shape;
    }

    /**
     * Создать точки прямоугольника по кординатам угловых точек.
     *
     * @param p1 1-я угловая точка.
     * @param p2 2-я угловая точка.
     * @return Точки прямоугольника.
     */
    public static List<BasePoint2D> createRectanglePP(BasePoint2D p1, BasePoint2D p2) {
        return createRectanglePP(p1.getX(), p1.getY(), p2.getX(), p2.getY());
    }

    /**
     * Создать точки прямоугольника по угловой точке и размерам.
     *
     * @param p1   Угловая точка.
     * @param size Размеры.
     * @return Точки прямоугольника.
     */
    public static List<BasePoint2D> createRectanglePS(BasePoint2D p1, BasePoint2D size) {
        return createRectanglePP(p1.getX(), p1.getY(), p1.getX() + size.getX(), p1.getY() + size.getY());
    }

  /*  *//**
     * Создать точки прямоугольника на основе прямоугольника {@link BaseFrame2D}
     *
     * @param frame Прямоугольник {@link BaseFrame2D}.
     * @return Точки прямоугольника.
     *//*
    public static List<BasePoint2D> createRectangleF(BaseFrame2D frame) {
        return createRectanglePP(frame.getP1(), frame.getP2());
    }

    *//**
     * Создать точки прямоугольника на основе прямоугольника {@link BaseRectangle2D}
     *
     * @param rectangle Прямоугольник {@link BaseRectangle2D}.
     * @return Точки прямоугольника.
     */
    public static List<BasePoint2D> createRectangleR(BaseRectangle2D rectangle) {
        BasePoint2D[] points = rectangle.getPoints();
        List<BasePoint2D> shape = new ArrayList<BasePoint2D>();
        shape.add(points[0]);
        shape.add(points[2]);
        shape.add(points[4]);
        shape.add(points[6]);
        shape.add(points[0]);
        return shape;
    }

    /**
     * Проверить, лежит ли точка справа от прямой, образованной двумя точками.
     *
     * @param checkPoint Проверяемая точка.
     * @param begin      Первая точка.
     * @param end        Вторая точка.
     * @return Результат проверки. Направление (право/лево) рассчитывается отностиельно
     * направления, заданного начальной и конечной точками.
     */
    public static boolean isPointRightOf(BasePoint2D checkPoint, BasePoint2D begin, BasePoint2D end) {
        return GeometryUtils.angleBetweenPoints(checkPoint, begin, end) > Math.PI;
    }

    /**
     * Проверить, лежит ли точка справа от полилинии.
     *
     * @param checkPoint Проверяемая точка.
     * @param points     Полилиния.
     * @return Результат проверки. Направление (право/лево) рассчитывается отностиельно
     * направления, заданного начальной и конечной точками.
     */
    public static boolean isPointRightOf(BasePoint2D checkPoint, List<BasePoint2D> points) {
        double offset = nearestPointLocationOnPolyline(points, checkPoint);
        for (int i = 1; i < points.size(); i++) {
            double beginOffset = nearestPointLocationOnPolyline(points, points.get(i - 1));
            double endOffset = nearestPointLocationOnPolyline(points, points.get(i));
            if (beginOffset <= offset && offset <= endOffset) {
                return isPointRightOf(checkPoint, points.get(i - 1), points.get(i));
            }
        }
        if (offset < 0) {
            return isPointRightOf(checkPoint, points.get(0), points.get(1));
        } else {
            // offset > 1
            int preLast = points.size() - 2;
            int last = points.size() - 1;
            return isPointRightOf(checkPoint, points.get(preLast), points.get(last));
        }
    }

 /*   *//**
         * Относительное смещение точки между вершинами прямоугольника.
         *
         * @param r Прямоугольник.
         * @param p Точка, для которой считается смещение.
         * @return Относительное смещение.
         *//*
        public static BasePoint2D relative(BaseRectangle2D r, BasePoint2D p) {
            BasePoint2D p1 = r.getTLP();
            BasePoint2D p2 = new BasePoint2D(p1).add(r.getSize());
            double angle = r.getAngle();
            return GeometryUtils.relative(p1, p2, new BasePoint2D(p).rotate(-angle, p1));
        }

        *//**
         * Абсолютное положение точки по относительному смещению между вершинами прямоугольника.
         *
         * @param r Прямоугольник.
         * @param p Точка.
         * @return Абсолютное положение тоски.
         *//*
        public static BasePoint2D absolute(BaseRectangle2D r, BasePoint2D p) {
            BasePoint2D p1 = r.getTLP();
            BasePoint2D p2 = new BasePoint2D(p1).add(r.getSize());
            double angle = r.getAngle();
            return GeometryUtils.absolute(p1, p2, p).rotate(angle, p1);
        }
*/
}