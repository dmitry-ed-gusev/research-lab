package vg.geometry.cp;

import vg.geometry.primitives.BasePoint2D;

/**
 * Displaced point, related to other point.
 */

public class DisplacementCPoint extends AbsoluteCPoint {

    /***/
    private static final long serialVersionUID = -7358121744807052485L;

    /**
     * Точка, относительно которой смещается данная.
     */
    protected CPoint p0;
    /**
     * Смещение.
     */
    protected BasePoint2D d = new BasePoint2D();


    /**
     * @param p0 Точка, относительно которой смещается данная.
     * @param d  Смещение (мм, мм).
     */
    public DisplacementCPoint(CPoint p0, BasePoint2D d) {
        this.p0 = p0;

        //this.d.init(d);
        this.d = d;

        dependencies.add(p0);
    }

    /**
     * @param p0 Точка, относительно которой смещается данная.
     * @param dx Смещение по X (мм).
     * @param dy Смещение по Y (мм).
     */
    public DisplacementCPoint(CPoint p0, double dx, double dy) {
        this.p0 = p0;

        //this.d.init(dx, dy);
        this.d = new BasePoint2D(dx, dy);

        dependencies.add(p0);
    }


    @Override
    public CPoint calculate() {

        //point.init(new BasePoint2D(p0.getX(), p0.getY())).add(d);
        this.point = new BasePoint2D(p0.getX(), p0.getY()).add(d);

        return this;
    }

    @Override
    public CPoint decalculate() {

        //d.init(point).sub(new BasePoint2D(p0.getX(), p0.getY()));
        this.d = new BasePoint2D(point).sub(new BasePoint2D(p0.getX(), p0.getY()));

        return this;
    }


    /**
     * Получить точку отсчёта.
     *
     * @return Точка отсчёта.
     */
    public CPoint getP0() {
        return p0;
    }

    /**
     * Задать точку отсчёта.
     *
     * @param p0 Точка отсчёта.
     */
    public void setP0(CPoint p0) {
        dependencies.remove(this.p0);
        this.p0 = p0;
        dependencies.add(p0);
    }

    /**
     * Получить смещение.
     *
     * @return Смещение.
     */
    public BasePoint2D getD() {
        return d;
    }

    /**
     * Задать смещение.
     *
     * @param d Смещение.
     */
    public void setD(BasePoint2D d) {

        //this.d.init(d);
        this.d = d;

    }

}
