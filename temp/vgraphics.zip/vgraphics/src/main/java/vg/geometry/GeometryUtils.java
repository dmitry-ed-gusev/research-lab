package vg.geometry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import vg.geometry.primitives.BaseFrame2D;
import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;
import vg.utils.TextLinesIterator;

import java.awt.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Array;
import java.util.*;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Utility class for geometry/primitives.
 */

// TODO сделать методы null-safe (принимающие null объекты в качестве параметров)

public final class GeometryUtils {

    // current class logger (log4j)
    private static final Log log = LogFactory.getLog(GeometryUtils.class);
    // string values that should be interpreted as boolean TRUE value
    private static final List<String> strBooleanTrue = Collections.unmodifiableList(Arrays.asList("true", "on", "yes", "1"));


    private GeometryUtils() {} // non-instanceability

    /**
     * Абсолютное положение точки по относительному смещению.
     *
     * @param p1 Первая точка.
     * @param p2 Вторая точка.
     * @param tx Относительное смещение по X.
     * @param ty Относительное смещение по Y.
     * @return Абсолютное положение точки по относительному смещению между первой и второй точками.
     */
    public static BasePoint2D absolute(BasePoint2D p1, BasePoint2D p2, double tx, double ty) {
        return new BasePoint2D(
                p1.getX() * (1.0 - tx) + p2.getX() * tx,
                p1.getY() * (1.0 - ty) + p2.getY() * ty);
    }

    /**
     * Абсолютное положение точки по относительному смещению.
     *
     * @param p1 Первая точка.
     * @param p2 Вторая точка.
     * @param t  Относительное смещение.
     * @return Абсолютное положение точки по относительному смещению между первой и второй точками.
     */
    public static BasePoint2D absolute(BasePoint2D p1, BasePoint2D p2, double t) {
        return GeometryUtils.absolute(p1, p2, t, t);
    }

    /**
     * Абсолютное положение точки по относительному смещению.
     *
     * @param p1 Первая точка.
     * @param p2 Вторая точка.
     * @param t  Относительное смещение.
     * @return Абсолютное положение точки по относительному смещению между первой и второй точками.
     */
    public static BasePoint2D absolute(BasePoint2D p1, BasePoint2D p2, BasePoint2D t) {
        return GeometryUtils.absolute(p1, p2, t.getX(), t.getY());
    }

    /**
     * Среднее арифметическое точек.
     *
     * @param points Список точек.
     * @return Среднее арифметическое точек.
     */
    public static BasePoint2D average(BasePoint2D... points) {
        BasePoint2D average = new BasePoint2D();
        if (points != null && points.length > 0) {
            // summarize all points
            int counter = 0;
            for (BasePoint2D point : points) {
                if (point != null) {
                    average.add(point);
                    counter++;
                }
            }
            // divide
            average.div(counter, counter);
        } // end if
        return average;
    }

    /**
     * Среднее арифметическое точек.
     *
     * @param points Список точек.
     * @return Среднее арифметическое точек.
     */
    public static BasePoint2D average(Collection<? extends BasePoint2D> points) {
        return GeometryUtils.average(points.toArray(new BasePoint2D[points.size()]));
    }

    /**
     * Проверяет, установлены ли в field все указанные во flag биты.
     *
     * @param field Битовое поле.
     * @param flag  Проверяемые биты.
     * @return Возвращает true, если все единичные биты во flag установлены в field.
     */
    public static boolean isOn(int field, int flag) {
        return (field & flag) == flag;
    }

    /**
     * Проверяет, сброшены ли в field все указанные во flag биты.
     *
     * @param field Битовое поле.
     * @param flag  Проверяемые биты.
     * @return Возвращает true, если все единичные биты во flag сброшены в field.
     */
    public static boolean isOff(int field, int flag) {
        return (field & flag) == 0;
    }

    /**
     * Установить биты (и 0, и 1) по маске.
     *
     * @param field Битовое поле.
     * @param mask  Маска.
     * @param value Значние битов.
     * @return (f & ~m) | (v & m).
     */
    public static int set(int field, int mask, int value) {
        return (field & ~mask) | (value & mask);
    }

    /**
     * Установить или сбросить флаг.
     *
     * @param field Битовое поле.
     * @param flag  Флаг.
     * @param value Значение битов флага.
     * @return Новое значение.
     */
    public static int set(int field, int flag, boolean value) {
        if (value) {
            return (field | flag); // установка битов field по маске flag
        } else {
            return field & ~flag; // сброс битов field по маске flag
        }
    }

    /**
     * Создать битовое поле по значениям битов.
     *
     * @param bits Значения битов начиная с нулевого.
     * @return Битовое поле.
     */
    public static int createBits(boolean... bits) {
        int value = 0;
        for (int i = 0, n = bits.length < 32 ? bits.length : 32; i < n; i++)
            if (bits[i]) value |= 1 << i;
        return value;
    }

    /**
     * Получить значение бита.
     *
     * @param field Битовое поле.
     * @param index Индекс бита.
     * @return Значение бита.
     */
    public static boolean getBit(int field, int index) {
        return isOn(field, 1 << index);
    }

    /**
     * Циклический сдвиг.
     *
     * @param value Исходное значение.
     * @param shift Сдвиг. Если >0, то сдвиг в сторону старших разрядов, если <0, то сдвиг в сторону младших разрядов.
     * @return Сдвинутое число.
     */
    public static int cyclicShift(int value, int shift) {
        return shift > 0 ? (value << shift) | (value >>> (32 - shift)) :
                shift < 0 ? (value >>> shift) | (value << (32 - shift)) :
                        value;
    }

    /**
     * Создать исключения неверного типа параметра функции.
     *
     * @param varName       Имя переменной.
     * @param var           Переменная.
     * @param demandClasses Требуемый типы.
     * @return Исключение неверного типа параметра функции.
     */
    public static IllegalArgumentException createIllegalArgumentException(String varName, Object var, Class<?>... demandClasses) {
        return new IllegalArgumentException(String.format(
                "Illegal type of %s:%s, must be %s",
                varName,
                var != null ? var.getClass().getName() : "null",
                demandClasses.length == 1 ? "an " + demandClasses[0].getName() : "one from [" + Arrays.toString(demandClasses) + "]"));
    }

    /**
     * Создать исключение выхода за допустимые границы индекса.
     *
     * @param size  Размер.
     * @param index Индекс.
     * @return Исключение выхода за допустимые границы индекса.
     */
    public static IndexOutOfBoundsException createIndexOutOfBoundsException(
            int index, int size) {
        return new IndexOutOfBoundsException(String.format(
                "Index %d out of bounds %d", index, size));
    }

    /**
     * Создать исключение выхода за допустимые границы индекса.
     *
     * @param size    Размер.
     * @param minSize Минимальный размер.
     * @param maxSize Максимальный размер.
     * @return Исключение выхода за допустимые границы индекса.
     */
    public static IndexOutOfBoundsException createSizeOutOfBoundsException(
            int size, int minSize, int maxSize) {
        return new IndexOutOfBoundsException(String.format(
                "Size %d out of bounds [%d; %d]", size, minSize, maxSize));
    }

    /**
     * Матрица перемещения.
     *
     * @param tx Смещение по оси X.
     * @param ty Смещение по оси Y.
     * @return Матрица перемещения.
     */
    public static BaseMatrix2D translation(double tx, double ty) {
        return new BaseMatrix2D(1, 0, tx, 0, 1, ty);
    }

    /**
     * Матрица масштабирования.
     *
     * @param sx Масштабный коэффициент по оси X.
     * @param sy Масштабный коэффициент по оси Y.
     * @return Матрица масштабирования.
     */
    public static BaseMatrix2D scalation(double sx, double sy) {
        return new BaseMatrix2D(sx, 0, 0, 0, sy, 0);
    }

    /**
     * Матрица поворота.
     *
     * @param a Угол поворота.
     * @return Матрица поворота.
     */
    public static BaseMatrix2D rotation(double a) {
        double s = Math.sin(a);
        double c = Math.cos(a);
        return new BaseMatrix2D(c, -s, 0, s, c, 0);
    }

    /**
     * Относительное смещение точки.
     *
     * @param p1 Первая точка.
     * @param p2 Вторая точка.
     * @param p  Точка, для которой считается относительное смещение между первой и второй.
     * @return Относительное смещение точки между первой и второй.
     */
    public static BasePoint2D relative(BasePoint2D p1, BasePoint2D p2, BasePoint2D p) {
        return new BasePoint2D(
                GeometryUtils.relative(p1.getX(), p2.getX(), p.getX()),
                GeometryUtils.relative(p1.getY(), p2.getY(), p.getY()));
    }

    /**
     * Расстояние между двумя точками.
     *
     * @param x0 X первой точки.
     * @param y0 Y первой точки.
     * @param x1 X второй точки.
     * @param y1 Y второй точки.
     * @return Расстояние между двумя точками.
     */
    public static double distanceBetweenPoints(double x0, double y0, double x1, double y1) {
        double dx = x1 - x0;
        double dy = y1 - y0;
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Расстояние между двумя точками.
     *
     * @param p0 Первая точка.
     * @param p1 Вторая точка.
     * @return Расстояние между двумя точками.
     */
    public static double distanceBetweenPoints(BasePoint2D p0, BasePoint2D p1) {
        double result;
        if (p0 != null && p1 != null) {
            result = GeometryUtils.distanceBetweenPoints(p0.getX(), p0.getY(), p1.getX(), p1.getY());
        } else {
            result = 0;
        }
        return result;
    }

    /**
     * Угол от точки z до точки p относительно центра c.
     * <p>Другими словами, это угол ZCP.
     * <p>Если ось X направлена вправо, а ось Y - вниз, то положительный угол будет по часовой стрелке.
     *
     * @param p Целевая точка.
     * @param c Центр угла. Если null, то в качестве центра будет использоваться точка (0.0; 0.0).
     * @param z Нулевая точка отсчёта. Если null, то вместо неё будет использоваться горизонталь.
     * @return Угол от z до p относительно центра c.
     */
    public static double angleBetweenPoints(BasePoint2D p, BasePoint2D c, BasePoint2D z) {
        // Центр угла.
        double cx = 0.0;
        double cy = 0.0;
        if (c != null) {
            cx = c.getX();
            cy = c.getY();
        }
        // Угол нулевого вектора (вектора отсчёта).
        double za = 0.0;
        if (z != null) {
            za = Math.atan2(z.getY() - cy, z.getX() - cx);
        }
        // Угол целевого вектора.
        double pa = Math.atan2(p.getY() - cy, p.getX() - cx);
        // Приведение угла в диапазон [0; 2*pi).
        return GeometryUtils.mod(0, Math.PI * 2, pa - za);
    }

    /**
     * Получить точку пересечения прямых, заданных двумя точками.
     *
     * @param p00 Первая точка первой линии.
     * @param p01 Вторая точка первой линии.
     * @param p10 Первая точка второй линии.
     * @param p11 Вторая точка второй линии.
     * @return Точка пересечения прямых или null, если прямые параллельны.
     */
    public static BasePoint2D linesIntersection(BasePoint2D p00, BasePoint2D p01, BasePoint2D p10, BasePoint2D p11) {
        double a0 = p00.getY() - p01.getY();
        double b0 = p01.getX() - p00.getX();
        double c0 = p00.getX() * p01.getY() - p01.getX() * p00.getY();
        double a1 = p10.getY() - p11.getY();
        double b1 = p11.getX() - p10.getX();
        double c1 = p10.getX() * p11.getY() - p11.getX() * p10.getY();

        double n = a0 * b1 - a1 * b0;
        if (GeometryUtils.isNearZero(n))
            return null;

        double x = (b0 * c1 - b1 * c0) / n;
        double y = (a1 * c0 - a0 * c1) / n;

        return new BasePoint2D(x, y);
    }

    /**
     * Получить точку пересечения отрезков.
     *
     * @param p00 Первая точка первого отрезка.
     * @param p01 Вторая точка первого отрезка.
     * @param p10 Первая точка второго отрезка.
     * @param p11 Вторая точка второго отрезка.
     * @return Точка пересечения отрезков или null, если отрезки не пересекаются.
     */
    public static BasePoint2D sectorsIntersections(BasePoint2D p00, BasePoint2D p01, BasePoint2D p10, BasePoint2D p11) {
        BasePoint2D ip = linesIntersection(p00, p01, p10, p11);
        if (ip == null)
            return null;
        if (!GeometryUtils.isIn(ip.getX(), p00.getX(), p01.getX()) || !GeometryUtils.isIn(ip.getX(), p10.getX(), p11.getX()))
            return null;
        return ip;
    }

    /**
     * Проверить, содержит ли прямоугольник переданную точку.
     *
     * @param f Прямоугольник.
     * @param p Точка.
     * @return Флаг принадлежности точки прямоугольнику.
     */
    public static boolean containsPoint(BaseFrame2D f, BasePoint2D p) {
        double x = p.getX();
        double y = p.getY();
        BasePoint2D p1 = f.getP1();
        double x1 = p1.getX();
        double y1 = p1.getY();
        BasePoint2D p2 = f.getP2();
        double x2 = p2.getX();
        double y2 = p2.getY();
        return (x >= x1 && x <= x2 || x >= x2 && x <= x1) && (y >= y1 && y <= y2 || y >= y2 && y <= y1);
    }

    /**
     * Создать прямоугольную область по набору точек.
     *
     * @param points массив точек.
     * @return созданный фрейм.
     */
    public static BaseFrame2D createBoundingFrame(BasePoint2D... points) {
        if (points == null || points.length == 0)
            return new BaseFrame2D();

        double minX = points[0].getX();
        double minY = points[0].getY();
        double maxX = minX;
        double maxY = minY;

        for (BasePoint2D p : points) {
            double x = p.getX();
            double y = p.getY();
            if (x < minX)
                minX = x;
            if (x > maxX)
                maxX = x;
            if (y < minY)
                minY = y;
            if (y > maxY)
                maxY = y;
        }

        return new BaseFrame2D(minX, minY, maxX, maxY);
    }

    /**
     * Создать фрейм, обрамляющий точки.
     *
     * @param points Точки, для которых строится обрамляющий фрейм.
     * @return Обрамляющий фрейм.
     */
    public static BaseFrame2D createBoundingFrame(Collection<? extends BasePoint2D> points) {
        return createBoundingFrame(points.toArray(new BasePoint2D[points.size()]));
    }

    /**
     * Упростить полилинию.
     *
     * @param polyline Точки полилинии.
     * @param delta    Отклоние до которого точки удаляются.
     * @return Упрощённая полилиния.
     */
    public static List<BasePoint2D> simplifyPolyline(List<? extends BasePoint2D> polyline, double delta) {
        // Количество точек исходной полилинии.
        int polylineSize = polyline.size();

        // Если точек меньше трёх, то и не чего упрощать.
        if (polylineSize < 2) {
            return new ArrayList<BasePoint2D>(polyline);
        }

        // Упрощённая полилиния.
        List<BasePoint2D> simplePolyline = new ArrayList<BasePoint2D>(polylineSize);

        // Итератор по точкам линии.
        Iterator<? extends BasePoint2D> polylineIterator = polyline.iterator();

        // Далее будет необходим квадрат дельты.
        delta *= delta;

        // Предпредыдущая точка.
        BasePoint2D p0 = polylineIterator.next();
        double x0 = p0.getX();
        double y0 = p0.getY();
        // Предыдущая точка.
        BasePoint2D p1 = polylineIterator.next();
        double x1 = p1.getX();
        double y1 = p1.getY();
        // Расстояние между кооринатами предпоследней и последней точек.
        double dx0 = x0 - x1;
        double dy0 = y0 - y1;
        double d0 = dx0 * dx0 + dy0 * dy0;
        // Проигнорированная точка.
        BasePoint2D ip = null;
        double xi = 0.0;
        double yi = 0.0;

        // Добавляем первые две точки.
        simplePolyline.add(p0);
        simplePolyline.add(p1);

        // Основной расчёт.
        while (polylineIterator.hasNext()) {
            // Текущая точка.
            BasePoint2D p = polylineIterator.next();
            double x = p.getX();
            double y = p.getY();

            // Если близка к предыдущей, игнорируем её и не запоминаем.
            double dx = x - x1;
            double dy = y - y1;
            double d = dx * dx + dy * dy;
            if (d < delta) {
                continue;
            }

            // Если текущая точка лежит около линии, проходящей через предпредыдущую и предыдущую, то игнорируем её (но запоминаем - она потом заменит предыдущую точку).
            double a = dx0 * dy - dy0 * dx;
            if (a * a / d0 < delta) {
                ip = p;
                xi = ip.getX();
                yi = ip.getY();
                continue;
            }

            // Обычная точка, просто добавляем её.

            // Но сначала заменяем последнюю точку проигнорированной.
            if (ip != null) {
                // Добаляем проигнорированную точку только если она удалена от текущей.
                dx0 = xi - x;
                dy0 = yi - y;
                d0 = dx0 * dx0 + dy0 * dy0;
                if (d0 >= delta) {
                    simplePolyline.set(simplePolyline.size() - 1, ip);
                    // Обновляем текущую разность координат (для замены переменных в конце итерации).
                    dx = dx0;
                    dy = dy0;
                    d = d0;
                }
                // Забываем игнорированную точку в любом случае.
                ip = null;
            }

            // Теперь добавляем текущую.
            simplePolyline.add(p);

            // Заменяем переменные.
            p0 = p1;
            x0 = x1;
            y0 = y1;

            p1 = p;
            x1 = x;
            y1 = y;

            dx0 = dx;
            dy0 = dy;
            d0 = d;
        }

        // Если осталась игнорированная точка, добавляем её.
        if (ip != null) {
            simplePolyline.add(ip);
        }

        return simplePolyline;
    }

    /**
     * Влючить или отключить сглаживание в графическом контексте.
     *
     * @param g     Графический контекст.
     * @param value Флаг сглаживания.
     */
    public static void setSmoothing(Graphics g, boolean value) {
        if (!(g instanceof Graphics2D)) return;
        ((Graphics2D) g).setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                value ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_DEFAULT);
    }

    /**
     * Получить значение сглаживания.
     *
     * @param g Графический контекст.
     * @return Флаг сглаживания.
     */
    public static boolean getSmoothing(Graphics g) {
        if (!(g instanceof Graphics2D)) return false;
        return ((Graphics2D) g).getRenderingHint(RenderingHints.KEY_ANTIALIASING) == RenderingHints.VALUE_ANTIALIAS_ON;
    }

    /**
     * Относительное время с точностью до наносекунд.
     * <p>Это не текущее время от 1970 года.
     * <p>Можно использовать для временных замеров.
     *
     * @return Относительное время с точностью до наносекунд.
     */
    public static double nanoTime() {
        return System.nanoTime() * 1e-9;
    }

    /**
     * Прочитать поток полностью.
     *
     * @param stream Поток.
     * @return Массив считанных байт.
     * @throws IOException      В случае ошибки чтения.
     * @throws OutOfMemoryError В случае, если данных в потоке оказалось больше, чем возможно выделить памяти.
     *                          <p>Для считывания данных необходимо в два раза больше памяти, чем занимают полезные данные.
     */
    public static byte[] readFully(InputStream stream) throws IOException {
        // 1M
        final int BUFFER_SIZE = 1 << 20;

        // Считтанные блоки данных.
        List<byte[]> dataBlocks = new ArrayList<byte[]>();

        // Буфер для чтения данных.
        byte[] buffer = new byte[BUFFER_SIZE];
        int bufferPosition = 0;
        // Считывание.
        while (true) {
            // Буфер может быть не полностью заполнен при считывании.
            int readLength = stream.read(buffer, bufferPosition, BUFFER_SIZE - bufferPosition);
            // -1 в случае конца потока.
            if (readLength == -1) {
                break;
            }
            // Новая позиция для считывания в буфере.
            bufferPosition += readLength;
            // Если буфер заполнен полностью, складываем его в список считанных блоков и создаём новый буфер.
            if (bufferPosition == BUFFER_SIZE) {
                dataBlocks.add(buffer);
                buffer = new byte[BUFFER_SIZE];
                bufferPosition = 0;
            }
        }

        // Блок результирующих данных.
        byte[] data = new byte[dataBlocks.size() * BUFFER_SIZE + bufferPosition];
        int dataPosition = 0;
        // Копируем полностью заполненные блоки.
        for (byte[] block : dataBlocks) {
            System.arraycopy(block, 0, data, dataPosition, BUFFER_SIZE);
            dataPosition += BUFFER_SIZE;
        }
        // Копируем прочитанные данные из последнего буфера.
        System.arraycopy(buffer, 0, data, dataPosition, bufferPosition);

        return data;
    }

    /**
     * Прочитать весь текст из потока.
     *
     * @param reader Поток.
     * @return Прочтённый текст.
     * @throws RuntimeException(IOException) В случае ошибок ввода-вывода.
     */
    public static String readText(Reader reader) {
        TextLinesIterator iterator = new TextLinesIterator(reader);
        StringBuilder stringBuilder = new StringBuilder();
        while (iterator.hasNext())
            stringBuilder.append(iterator.next());
        return stringBuilder.toString();
    }

    /**
     * Шаблон для вещественных чисел с указанием длины целой и дробной частей.
     *
     * @param canBeNegative    Возможность отрицательности числа.
     * @param integerLength    Количество цифр целой части.
     * @param fractionalLength Количество цифр вещественной части.
     * @return Регульярное выражение шаблона.
     */
    public static final String RE_FLOAT(boolean canBeNegative, int integerLength, int fractionalLength) {
        String regExp = "";
        if (canBeNegative) regExp += "[\\+\\-]?";
        if (integerLength > 0) regExp += "\\d{0," + integerLength + "}";
        else regExp += "0";
        if (fractionalLength > 0) regExp += "(?:[\\.\\,]\\d{0," + fractionalLength + "})?";
        return regExp;
    }

    /**
     * Заменить участок строки фрагментом.
     *
     * @param source   Исходная строка.
     * @param begin    Начало участка.
     * @param end      Конец участка (не включительно, начало + длина)
     * @param fragment Вставляемый фрагмент.
     * @return Изменённая строка.
     */
    public static String replace(String source, int begin, int end, String fragment) {
        return source.substring(0, begin) + fragment + source.substring(end);
    }

    /**
     * Поиск подстроки по регулярному выражению.
     *
     * @param str     Входная строка.
     * @param pattern Шблон регулярного выражения.
     * @return Если синтаксис регулярного выражения неверный, null. Если шаблон не найден, пустой
     * массив. Если что-то найдено, то массив со строкой, соответствующей шаблону по индексу 0 и
     * строками, соответствующими группам по остальным индексам.
     */
    public static String[] regexpFind(String str, String pattern) {
        Pattern rePattern = null;
        try {
            rePattern = Pattern.compile(pattern);
        } catch (PatternSyntaxException ex) {
            log.error(ex);
            return null;
        }
        Matcher reMatcher = rePattern.matcher(str);
        if (!reMatcher.find()) {
            return new String[0];
        }
        String[] result = new String[1 + reMatcher.groupCount()];
        for (int i = 0; i < result.length; i++)
            result[i] = reMatcher.group(i);
        return result;
    }

    /**
     * Проверка, удовлетворяет ли строка регулярному выражению.
     *
     * @param str     Строка.
     * @param pattern Регулярное выражение.
     * @return Признак того, что строка удовлетворяет регулярному выражению.
     */
    public static boolean regexpCheck(String str, String pattern) {
        Pattern rePattern = null;
        try {
            rePattern = Pattern.compile(pattern);
        } catch (PatternSyntaxException ex) {
            log.error(ex);
            return false;
        }
        Matcher reMatcher = rePattern.matcher(str);
        return reMatcher.matches();
    }

    /**
     * Преобразование шаблона имён файлов в регулярное выражение.
     * <p>Пример шаблонов: *.png, name+.txt, name?.txt.
     *
     * @param wildcard Шаблон имён файлов.
     * @return Регулярное выражение.
     */
    public static String wildcardToRegexp(String wildcard) {
        String regexp = wildcard;
        regexp = regexp.replace(".", "\\.");
        regexp = regexp.replace("*", ".*");
        regexp = regexp.replace("+", ".+");
        regexp = regexp.replace("?", ".?");
        return regexp;
    }

    /**
     * Проверка строки на соответствие шаблону имён фалов.
     *
     * @param str     Строка.
     * @param pattern Шаблон.
     * @return Признак соответствия строки шаблону.
     */
    public static boolean wildcardCheck(String str, String pattern) {
        return regexpCheck(str, wildcardToRegexp(pattern));
    }


    /**
     * Получить индекс объекта в списке или массиве.
     *
     * @param list   Список или массив.
     * @param object Искомый объект.
     * @return Индекс объекта в списке или массиве.
     */
    public static int indexOf(Object list, Object object) {
        if (list instanceof Collection) {
            Iterator<?> iterator = ((Collection<?>) list).iterator();
            int index = 0;
            while (iterator.hasNext()) {
                Object element = iterator.next();
                if (element == null && object == null || element != null
                        && element.equals(object))
                    return index;
                index++;
            }
            return -1;
        } else if (list.getClass().isArray()) {
            int length = Array.getLength(list);
            for (int index = 0; index < length; index++) {
                Object element = Array.get(list, index);
                if (element == null && object == null || element != null
                        && element.equals(object))
                    return index;
            }
            return -1;
        } else
            return -1;
    }

    /**
     * Преобразование строки в целое число.
     *
     * @param str          Строка для преобразования.
     * @param defaultValue Значение по умолчанию.
     * @param radix        Основание системы счисления.
     * @return Значение, полученое из преобразования, или значение по умолчанию,
     * если преобразование не удалось.
     */
    public static int stringToInt(String str, int defaultValue, int radix) {
        try {
            return Integer.parseInt(str, radix);
        } catch (NumberFormatException ex) {
            log.warn("Can't convert string to integer!", ex);
            return defaultValue;
        }
    }

    /**
     * Преобразование строки в целое число.
     *
     * @param str          Строка для преобразования.
     * @param defaultValue Значение по умолчанию.
     * @return Значение, полученое из преобразования, или значение по умолчанию,
     * если преобразование не удалось.
     */
    public static int stringToInt(String str, int defaultValue) {
        return stringToInt(str, defaultValue, 10);
    }

    /**
     * Преобразование строки в целое число.
     *
     * @param str Строка для преобразования.
     * @return Значение, полученое из преобразования, или 0, если преобразование не удалось.
     */
    public static int stringToInt(String str) {
        return stringToInt(str, 0, 10);
    }

    /**
     * Преобразование строки в число с плавающей точкой.
     *
     * @param str          Строка для преобразования.
     * @param defaultValue Значение по умолчанию.
     * @return Значение, полученое из преобразования, или значение по умолчанию, если преобразование не удалось.
     */
    public static double stringToDouble(String str, double defaultValue) {
        try {
            // String.valueOf gives us null-safety
            return Double.parseDouble(String.valueOf(str).replace(',', '.'));
        } catch (NumberFormatException ex) {
            log.warn("Can't convert string to double!", ex);
            return defaultValue;
        }
    }

    /**
     * Преобразование строки в число с плавающей точкой.
     *
     * @param str Строка для преобразования.
     * @return Значение, полученое из преобразования, или 0.0, если
     * преобразование не удалось.
     */
    public static double stringToDouble(String str) {
        return GeometryUtils.stringToDouble(str, 0.0);
    }

    /**
     * Преобразование строки во флаг (логическое значение ИСТИНА/ЛОЖЬ). Как значение ИСТИНА интерпретируются
     * следующие строки: "true", "on", "yes", "1". Все остальные - ЛОЖЬ (также и пустая и null-строка).
     * Метод не чувствителен к регистру символов.
     *
     * @param str Строка для преобразования.
     * @return Значение, полученое после преобразования.
     */
    public static boolean stringToBoolean(String str) {
        // String.valueOf() - if str=null, we don't get NPE!
        return GeometryUtils.strBooleanTrue.contains(String.valueOf(str).toLowerCase());
    }

    /**
     * Модуль числа.
     *
     * @param min Нижняя граница.
     * @param max Верхняя граница.
     * @param x   Число.
     * @return Число взятое по модулю, заданному границами.
     */
    public static double mod(double min, double max, double x) {
        x -= min;
        x %= max - min;
        if (x < 0) x += max - min;
        x += min;
        return x;
    }

    /**
     * Относительное значение.
     *
     * @param x1 Точка отсчёта.
     * @param x2 Точка назначения.
     * @param t  Относительное смещение (коэффициент).
     * @return Относительное значение.
     */
    public static double absolute(double x1, double x2, double t) {
        return x1 + t * (x2 - x1);
    }

    /**
     * Относительное смещение (коэффициент).
     *
     * @param x1 Точка отсчёта.
     * @param x2 Точка назначения.
     * @param x  Значение, для которого вычисляется смещение.
     * @return Относительное смещение.
     */
    public static double relative(double x1, double x2, double x) {
        return (x - x1) / (x2 - x1);
    }

    /**
     * Проверка, находится ли число x в пределах d от c (abs(x-c)<abs(d));
     *
     * @param x Тестируемое число.
     * @param c Центр проверки.
     * @param d Дистанция от центра.
     * @return Признак близости чисел.
     */
    public static boolean isNear(double x, double c, double d) {
        double xc = x - c;
        return xc * xc < d * d;
    }

    /**
     * Проверка, находится ли число x около c;
     *
     * @param x Тестируемое число.
     * @param c Центр проверки.
     * @return Признак близости чисел.
     */
    public static boolean isNear(double x, double c) {
        double xc = x - c;
        return xc * xc < 1e-12;
    }

    /**
     * Проверка, находится ли число x в пределах d от 0.0;
     *
     * @param x Тестируемое число.
     * @param d Дистанция от центра.
     * @return Признак близости числа к нулю.
     */
    public static boolean isNearZero(double x, double d) {
        return x * x < d * d;
    }

    /**
     * Проверка, находится ли число x около 0.0;
     *
     * @param x Тестируемое число.
     * @return Признак близости числа к нулю.
     */
    public static boolean isNearZero(double x) {
        return x * x < 1e-12;
    }

    /**
     * Проверка, находится ли точка x в отрезке [x1, x2]
     *
     * @param x  Точка.
     * @param x1 Конец отрезка (включительно).
     * @param x2 Конец отрезка (включительно).
     * @return Признак попадания x в отрезок [x1, x2];
     */
    public static boolean isIn(double x, double x1, double x2) {
        return x >= x1 && x <= x2 || x >= x2 && x <= x1;
    }

    /**
     * Расчёт вписывающего коэффициента.
     *
     * @param areaWidth    Ширина описывающей области.
     * @param areaHeight   Высота описывающей области.
     * @param objectWidth  Ширина вписываемого объекта.
     * @param objectHeight Высота вписываемого объекта.
     * @return Пропорциональный коэффициент вписывания объекта в область.
     */
    public static double fit(double areaWidth, double areaHeight,
                             double objectWidth, double objectHeight) {
        double areaAR = areaWidth / areaHeight;
        double objectAR = objectWidth / objectHeight;
        return objectAR > areaAR ? areaWidth / objectWidth : areaHeight
                / objectHeight;
    }

    /**
     * Распаковать вещественное число из byte.
     *
     * @param min   Минимальное значение вещественного числа.
     * @param max   Максимальное значение вещественного числа.
     * @param value Вещественного число, упакованное в byte.
     * @return Вещественного число, распакованное из byte.
     */
    public static double byteToFloat(double min, double max, byte value) {
        if (min > max) { // меняем значения местами если min > max
            double t = min;
            min = max;
            max = t;
        }
        // распаковка
        double floatValue = (value - Byte.MIN_VALUE) / (Byte.MAX_VALUE + 1.0 - Byte.MIN_VALUE);
        floatValue = min + floatValue * (max - min);
        // результат
        return floatValue;

    }

    /**
     * Конфертирование массива из float[] в double[].
     *
     * @param farray Исходный массив.
     * @return Результирующий массив.
     */
    public static double[] floatToDouble(float[] farray) {
        if (farray == null) return null;
        double[] darray = new double[farray.length];
        for (int i = 0; i < farray.length; i++)
            darray[i] = farray[i];
        return darray;
    }

    /**
     * Конфертирование массива из double[] в float[].
     *
     * @param darray Исходный массив.
     * @return Результирующий массив.
     */
    public static float[] doubleToFloat(double[] darray) {
        if (darray == null) return null;
        float[] farray = new float[darray.length];
        for (int i = 0; i < darray.length; i++)
            farray[i] = (float) darray[i];
        return farray;
    }

    /**
     * Вычислить хеш код.
     *
     * @param value Значение.
     * @return Хеш код значения.
     */
    public static int hashCode(boolean value) {
        return value ? 1231 : 1237;
    }

    /**
     * Вычислить хеш код.
     *
     * @param value Значение.
     * @return Хеш код значения.
     */
    public static int hashCode(double value) {
        long bits = Double.doubleToLongBits(value);
        return (int) (bits ^ (bits >>> 32));
    }

}