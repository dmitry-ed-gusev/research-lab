package vg.geometry;

/**
 * Basic interface for transforming primitive objects.
 * @author Gusev Dmitry
 */

public interface ITransformable <T> {

    /**
     * Rotate object by angle (double) with rotate center at [0; 0].
     * @param angle double
     * @return T
     */
    //T rotate(double angle);

    /**
     * Rotate object by double angle with rotate center at double [x;y].
     * @param angle double
     * @param rotateCenterX double
     * @param rotateCenterY double
     * @return T
     */
    T rotate (double angle, double rotateCenterX, double rotateCenterY);

    /**
     * Scale object by [scaleX; scaleY] and using scale center [scaleCenterX; scaleCenterY].
     * @param scaleX double
     * @param scaleY double
     * @param scaleCenterX double
     * @param scaleCenterY double
     * @return T
     */
    T scale (double scaleX, double scaleY, double scaleCenterX, double scaleCenterY);

    /**
     * Scale object by scale (both x and y) using scale center [scaleCenterX; scaleCenterY].
     * @param scaleXY double
     * @param scaleCenterX double
     * @param scaleCenterY double
     * @return T
     */
    //T scale(double scaleXY, double scaleCenterX, double scaleCenterY);

    /**
     * Scale object by [scaleX; scaleY].
     * @param scaleX double scale by x
     * @param scaleY double scale by y
     * @return T
     */
    //T scale(double scaleX, double scaleY);

    /**
     * Scale object by scale (both x and y).
     * @param scaleXY double x-y scale
     * @return T
     */
    //T scale(double scaleXY);

    /**
     * Move object by adding to coordinates [translateX, translateY].
     * @param translateX double offset by x.
     * @param translateY double offset by y.
     * @return T new moved object.
     */
    T translate(double translateX, double translateY);

    /**
     * Трансформировать объект матрицей.
     * @param t Матрица.
     * @return Этот же объект.
     */
    // todo: remove link to matrix???
    //T transform(BaseMatrix2D t);

}