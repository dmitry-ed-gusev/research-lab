package vg.geometry.cp;

import java.util.List;

/**
 * Link by index to calculated point from list.
 */

public class ListCPointReference extends AbstractCPointReference {

    /***/
    private static final long serialVersionUID = -3308609461413825558L;

    /**
     * Список, на который ссылается данная точка.
     */
    private List<? extends CPoint> list;
    /**
     * Индекс точки в списке.
     */
    private int index;


    /**
     * @param list  Список, на который ссылается данная точка.
     * @param index Индекс точки в списке.
     */
    public ListCPointReference(List<? extends CPoint> list, int index) {
        this.list = list;
        this.index = index;
    }


    @Override
    public CPoint getReferent() {
        return list.get(index);
    }


    /**
     * Получить список.
     *
     * @return Список.
     */
    public List<? extends CPoint> getList() {
        return list;
    }

    /**
     * Задать список.
     *
     * @param list Список.
     */
    public void setList(List<? extends CPoint> list) {
        this.list = list;
    }

    /**
     * Получить индекс в списке.
     *
     * @return Индекс в списке.
     */
    public int getIndex() {
        return index;
    }

    /**
     * Задать индекс в списке.
     *
     * @param index Индекс в списке.
     */
    public void setIndex(int index) {
        this.index = index;
    }

}
