package vg.geometry.primitives;

import vg.geometry.GeometryUtils;

import java.awt.*;

/**
 * Класс, который описывает шрифт. Расширяет (наследует) стандартный шрифт AWT.
 */

// todo: what is purpose of this class???
public class BaseFont2D extends Font {

    /**
     * Механизм сериализации.
     */
    private static final long serialVersionUID = 632164094198871971L;

    /**
     * Расширенный стиль шрифта - Подчёркнутый.
     */
    public static final int UNDERLINE = 0x4;
    /**
     * Расширенный стиль шрифта - Вычеркнутый (Зачеркнутый).
     */
    public static final int STRIKEOUT = 0x08;
    /**
     * Расширенный стиль шрифта - Надчёркнутый.
     */
    public static final int OVERLINE = 0x10;

    /**
     * Расширенный стиль.
     */
    private int xstyle;
    /**
     * Вещественный размер.
     */
    private double fsize;
    /**
     * Толщина линий подчёркивания, зачёркивания и надчёркивания.
     */
    private double lineWidth;

    /**
     * @param name  Название шрифта.
     * @param style Стиль шрифта.
     * @param size  Размер шрифта.
     */
    public BaseFont2D(String name, int style, double size) {
        super(name, style & 0x03, (int) Math.round(size));
        this.xstyle = style;
        this.fsize = size;
        this.lineWidth = size / 10.0;
    }

    /**
     * Копирующий конструктор.
     *
     * @param font Копируемый шрифт.
     */
    public BaseFont2D(Font font) {
        this(font.getName(), font.getStyle(), font.getSize2D());
    }

    /**
     * Копирующий конструктор.
     *
     * @param font  Копируемый шрифт.
     * @param scale Машстабный коэффициент размера.
     */
    public BaseFont2D(Font font, double scale) {
        this(font.getName(), font.getStyle(), font.getSize2D() * scale);
    }

    /**
     * Получить стиль шрифта.
     *
     * @return стиль шрифта.
     */
    public int getXStyle() {
        return xstyle;
    }

    /**
     * Получить размер шрифта.
     *
     * @return размер шрифта.
     */
    public double getFSize() {
        return fsize;
    }

    /**
     * Получить признак приподнятости шрифта
     *
     * @return признак приподнятости шрифта
     */
    public boolean isOverline() {
        return GeometryUtils.isOn(xstyle, OVERLINE);
    }

    /**
     * Получить признак зачеркивания шрифта
     *
     * @return признак зачеркивания шрифта
     */
    public boolean isStrikeout() {
        return GeometryUtils.isOn(xstyle, STRIKEOUT);
    }

    /**
     * Получить признак подчеркивания шрифта
     *
     * @return признак подчеркивания шрифта
     */
    public boolean isUnderline() {
        return GeometryUtils.isOn(xstyle, UNDERLINE);
    }

    /**
     * Ширина линии шрифта.
     *
     * @return ширину линии.
     */
    public double getLineWidth() {
        return lineWidth;
    }

    @Override
    public String toString() {
        return String.format("Font: {'%s', %02X, %f, %f}", getName(), getXStyle(), getFSize(), getLineWidth());
    }

    /**
     * Проверка идентичности.
     *
     * @param o ОБъект.
     * @return Признак идентичности.
     */
    @Override
    public boolean equals(Object o) {

        if (this == o) { // same object
            return true;
        }

        if (!(o instanceof BaseFont2D)) { // not instance - exit!
            return false;
        }

        BaseFont2D font2D = (BaseFont2D) o; // cast class and check state
        return this.fsize == font2D.fsize &&
                this.lineWidth == font2D.lineWidth &&
                this.xstyle == font2D.xstyle &&
                this.name.equals(font2D.name) &&
                this.pointSize == font2D.pointSize &&
                this.size == font2D.size &&
                this.style == font2D.style;
    }

}