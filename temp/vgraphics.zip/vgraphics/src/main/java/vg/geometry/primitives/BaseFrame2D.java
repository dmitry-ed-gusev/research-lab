package vg.geometry.primitives;

import vg.geometry.ITransformable;

import java.util.Arrays;
import java.util.Collection;

/**
 * Rectangle area on the plane. Set up by two points - top left point and bottom right point.
 * Rotate angle is 0 (not rotated).
 * <p>
 *     It's immutable class instances.
 * </p>
 * @author Gusev Dmitry, DG
 */
public class BaseFrame2D implements ITransformable<BaseFrame2D> {

    /** Top left coordinate. */
    private final BasePoint2D p1;
    private final double width;
    private final double height;


    /**
     * Create base frame.
     * <p>
     *     Top left & bottom right coordinates will be created by defaults.
     * </p>
     */
    public BaseFrame2D() {
        this.p1 = new BasePoint2D();
        this.width = 0.0;
        this.height = 0.0;
    }

    /**
     * Create base frame.
     * @param topLeft top left coordinate.
     * @param bottomRight bottom right coordinate.
     */
    public BaseFrame2D(BasePoint2D topLeft, BasePoint2D bottomRight) {
        if (topLeft == null || bottomRight == null) {
            throw new IllegalArgumentException("Any input parameter can not be null");
        }
        this.p1 = topLeft;
        this.width = bottomRight.getX() - topLeft.getX();
        this.height = bottomRight.getY() - topLeft.getY();
    }

    public BaseFrame2D(BasePoint2D topLeft, double width, double height) {
        if (topLeft == null) {
            throw new IllegalArgumentException("Any input parameter can not be null");
        }
        this.p1 = topLeft;
        this.width = width;
        this.height = height;
    }

    /**
     * Create base frame.
     * @param tlX top left horizontal coordinate.
     * @param tlY top left vertical coordinate.
     * @param brX bottom right horizontal coordinate.
     * @param brY bottom right vertical coordinate.
     */
    public BaseFrame2D(double tlX, double tlY, double brX, double brY) {
        this(new BasePoint2D(tlX, tlY), new BasePoint2D(brX, brY));
    }

    /**
     * Create frame based on specified frame.
     * @param frame as base for creation frame.
     */
    public BaseFrame2D(BaseFrame2D frame) {
        this(frame.getP1(), frame.getP2());
    }

    /**
     * Get top vertical coordinate.
     * @return top vertical coordinate.
     */
    public double getTopY() {
        return p1.getY();
    }

    /**
     * Get left horizontal coordinate.
     * @return left horizontal coordinate.
     */
    public double getLeftX() {
        return p1.getX();
    }

    /**
     * Get bottom vertical coordinate.
     * @return bottom vertical coordinate.
     */
    public double getBottomY() {
        return p1.getY() - height;
    }

    /**
     * Get right horizontal coordinate.
     * @return right horizontal coordinate.
     */
    public double getRightX() {
        return p1.getX() + width;
    }

    @Override
    public BaseFrame2D translate(double x, double y) {
        return new BaseFrame2D(p1, width, height);
    }

    public BaseFrame2D translate(BasePoint2D p) {
        return translate(p.getX(), p.getY());
    }

    @Override
    public BaseFrame2D scale(double kx, double ky, double cx, double cy) {
        return new BaseFrame2D(this.p1.scale(kx, ky, cx, cy), width, height);
    }

    //@Override
    //public BaseFrame2D scale(BasePoint2D k, BasePoint2D c) {
    //    return scale(k.getX(), k.getY(), c.getX(), c.getY());
    //}

    //@Override
    //public BaseFrame2D scale(double k, double cx, double cy) {
    //    return scale(k, k, cx, cy);
    //}

    //@Override
    //public BaseFrame2D scale(double k, BasePoint2D c) {
    //    return scale(k, c.getX(), c.getY());
    //}

    //@Override
    //public BaseFrame2D scale(double kx, double ky) {
    //    return new BaseFrame2D(
    //            this.p1.scale(kx, ky),
    //            this.p2.scale(kx, ky));
    //}

    //@Override
    //public BaseFrame2D scale(BasePoint2D k) {
    //    return scale(k.getX(), k.getY());
    //}

    //@Override
    //public BaseFrame2D scale(double k) {
    //    return scale(k, k);
    //}

    @Override
    public BaseFrame2D rotate(double a, double cx, double cy) {
        return new BaseFrame2D(p1.rotate(a, cx, cy), width, height);
    }

    //@Override
    //public BaseFrame2D rotate(double a, BasePoint2D c) {
    //    return rotate(a, c.getX(), c.getY());
    //}

    //@Override
    //public BaseFrame2D rotate(double a) {
    //    return new BaseFrame2D(this.p1.rotate(a), this.p2.rotate(a));
    //}

    //@Override
    //public BaseFrame2D transform(BaseMatrix2D t) {
    //    return new BaseFrame2D(this.p1.transform(t), this.p2.transform(t));
    //}

    /**
     * Join with specified frame.
     * @param f for joining.
     * @return joined frame.
     */
    public BaseFrame2D union(BaseFrame2D f) {
        return union(f.getP1(), f.getP2());
    }

    /**
     * Join with specified point.
     * @param p for joining.
     * @return base frame.
     */
    public BaseFrame2D union(BasePoint2D p) {
        normalize();

        double ttlX = this.p1.getX();
        double ttlY = this.p1.getY();
        double tbrX = this.p1.getX() + width;
        double tbrY = this.p1.getY() + height;

        double pX = p.getX();
        double pY = p.getY();

        if (pX < ttlX) {
            ttlX = pX;
        }
        if (pY < ttlY) {
            ttlY = pY;
        }
        if (pX > tbrX) {
            tbrX = pX;
        }
        if (pY > tbrY) {
            tbrY = pY;
        }

        return new BaseFrame2D(ttlX, ttlY, tbrX, tbrY);
    }

    /**
     * Join frame with specified points.
     * @param points for join.
     * @return joined frame.
     */
    public BaseFrame2D union(BasePoint2D... points) {
        return this.union(Arrays.asList(points));
    }

    /**
     * Join frame with specified points.
     * @param points for joining.
     * @return base frame.
     */
    public BaseFrame2D union(Collection<? extends BasePoint2D> points) {
        BaseFrame2D res = new BaseFrame2D(this);
        for (BasePoint2D p: points) {
            res = res.union(p);
        }
        return res;
    }

    /**
     * Normalize frame.
     * <p>
     *      Correct coordinates for real top left and bottom right coordinates.
     * </p>
     * @return normalised frame.
     */
    public BaseFrame2D normalize() {
        double tlX = p1.getX();
        double tlY = p1.getY();
        double brX = p1.getX() + width;
        double brY = p1.getY() + height;

        if (tlX > brX) {
            double tmp = tlX;
            tlX = brX;
            brX = tmp;
        }
        if (tlY > brY) {
            double tmp = tlY;
            tlY = brY;
            brY = tmp;
        }

        return new BaseFrame2D(tlX, tlY, brX, brY);
    }

    /**
     * Check intersects with specified frame.
     * @param frame for checking specified.
     * @return <code>true</code> - if it has intersection, <code>false</code> - in other way.
     */
    public boolean intersects(BaseFrame2D frame) {
        BasePoint2D fp1 = frame.getP1();
        BasePoint2D fp2 = frame.getP2();

        double x1 = p1.getX();
        double y1 = p1.getY();
        double x2 = p1.getX() + width;
        double y2 = p1.getY() + height;
        double fx1 = fp1.getX();
        double fy1 = fp1.getY();
        double fx2 = fp2.getX();
        double fy2 = fp2.getY();

        return ((x1 >= fx1 || x2 >= fx2) && (x1 <= fx1 || x2 <= fx2) || (x1 >= fx2 || x2 >= fx1) && (x1 <= fx2 || x2 <= fx1)) &&
                ((y1 >= fy1 || y2 >= fy2) && (y1 <= fy1 || y2 <= fy2) || (y1 >= fy2 || y2 >= fy1) && (y1 <= fy2 || y2 <= fy1));
    }

    @Override
    public String toString() {
        return String.format("(%s, %s)", getP1(), getP2());
    }

    /**
     * Check containing specified point.
     * @param p for checking.
     * @return <code>true</code> - if this frame contains the point, <code>false</code> - other way.
     */
    public boolean containsPoint(BasePoint2D p) {
        double x = p.getX();
        double y = p.getY();
        double x1 = p1.getX();
        double y1 = p1.getY();
        double x2 = p1.getX() + width;
        double y2 = p1.getY() + height;
        return (x >= x1 && x <= x2 || x >= x2 && x <= x1) && (y >= y1 && y <= y2 || y >= y2 && y <= y1);
    }

    /**
     * Get top left coordinate.
     * @return top left coordinate.
     */
    public BasePoint2D getP1() {
        return this.p1;
    }

    /**
     * Get bottom right coordinate.
     * @return bottom right coordinate.
     */
    public BasePoint2D getP2() {
        return this.p1.add(width, height);
    }

    /**
     * Get frame size.
     * @return size as 2d-point.
     */
    public BasePoint2D getSize() {
        return new BasePoint2D(getWidth(), getHeight());
    }

    /**
     * Get frame width.
     * @return frame width.
     */
    public double getWidth() {
        return width;
    }

    /**
     * Get frame height.
     * @return frame height.
     */
    public double getHeight() {
        return height;
    }

    /**
     * Get frame center.
     * @return frame center as 2d-point.
     */
    public BasePoint2D getCenter() {
        return this.p1.add(width / 2, height / 2);
    }

}