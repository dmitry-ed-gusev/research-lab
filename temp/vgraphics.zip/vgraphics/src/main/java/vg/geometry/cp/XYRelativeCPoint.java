package vg.geometry.cp;

import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BasePoint2D;

/**
 * Точка располагающаяся между двумя точками по раздельным смещениям по X и Y.
 */

public class XYRelativeCPoint extends AbstractCPoint {

    /***/
    private static final long serialVersionUID = -455068745082125121L;

    /**
     * Первая точка.
     */
    protected CPoint p0;
    /**
     * Вторая точка.
     */
    protected CPoint p1;
    /**
     * Смещение по X и Y (%, %).
     */
    protected BasePoint2D t = new BasePoint2D();


    /**
     * @param p0 Первая точка.
     * @param p1 Вторая точка.
     * @param t  Смещение по X и Y (%, %).
     */
    public XYRelativeCPoint(CPoint p0, CPoint p1, BasePoint2D t) {
        this.p0 = p0;
        this.p1 = p1;

        //this.t.init(t);
        this.t = t;

        dependencies.add(p0);
        dependencies.add(p1);
    }

    /**
     * @param p0 Первая точка.
     * @param p1 Вторая точка.
     * @param tx Смещение по X (%).
     * @param ty Смещение по Y (%).
     */
    public XYRelativeCPoint(CPoint p0, CPoint p1, double tx, double ty) {
        this.p0 = p0;
        this.p1 = p1;

        //this.t.init(tx, ty);
        this.t = new BasePoint2D(tx, ty);

        dependencies.add(p0);
        dependencies.add(p1);
    }


    @Override
    public CPoint calculate() {
        BasePoint2D pointP0 = new BasePoint2D(p0.getX(), p0.getY());
        BasePoint2D pointP1 = new BasePoint2D(p1.getX(), p1.getY());

        //point.init(GeometryUtils.absolute(pointP0, pointP1, t));
        this.point = GeometryUtils.absolute(pointP0, pointP1, t);

        return this;
    }

    @Override
    public CPoint decalculate() {
        BasePoint2D pointP0 = new BasePoint2D(p0.getX(), p0.getY());
        BasePoint2D pointP1 = new BasePoint2D(p1.getX(), p1.getY());

        //t.init(GeometryUtils.relative(pointP0, pointP1, point));
        this.t = GeometryUtils.relative(pointP0, pointP1, point);

        return this;
    }


    /**
     * Получить первую точку отсчёта.
     *
     * @return Первая точка отсчёта.
     */
    public CPoint getP0() {
        return p0;
    }

    /**
     * Задать первую точку отсчёта.
     *
     * @param p0 Первая точка отсчёта.
     */
    public void setP0(CPoint p0) {
        this.p0 = p0;
    }

    /**
     * Получить вторую точку отсчёта.
     *
     * @return Вторая точка отсчёта.
     */
    public CPoint getP1() {
        return p1;
    }

    /**
     * Задать вторую точку отсчёта.
     *
     * @param p1 Вторая точка отсчёта.
     */
    public void setP1(CPoint p1) {
        this.p1 = p1;
    }

    /**
     * Получить относительное смещение между точками.
     *
     * @return Относительное смещение между точками.
     */
    public BasePoint2D getT() {
        return t;
    }

    /**
     * Задать относительное смещение между точками.
     *
     * @param t Относительное смещение между точками.
     */
    public void setT(BasePoint2D t) {
        //this.t.init(t);
        this.t = t;
    }

}
