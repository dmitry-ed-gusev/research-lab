package vg.geometry.primitives;


import vg.geometry.GeometryUtils;
import vg.geometry.ITransformable;

import java.io.Serializable;

import static vg.geometry.GeometryDefaults.GEOMETRY_PRECISION;


/**
 * Point on the plane (radius vector: [0;0] -> [x;y]). Class is immutable.
 * No one method changes the state - they all return new objects.
 * See additional materials:
 *  - https://habrahabr.ru/post/131931/
 *
 * @author Gusev Dmitry.
 */

public class BasePoint2D implements Serializable, ITransformable<BasePoint2D> {

    private static final long serialVersionUID = 1L;

    private final double x;
    private final double y;

    /** Default constructor - point [0;0]. */
    public BasePoint2D() {
        x = 0.0;
        y = 0.0;
    }

    /**
     * Constructor for predefined point - [x;y]. If trying to create undefined point with one
     * of coordinates like Infinite/NaN throws exception.
     */
    public BasePoint2D(double x, double y) {
        if (!Double.isFinite(x) || !Double.isFinite(y)) { // no for infinity and NaN
            throw new IllegalArgumentException(
                    String.format("Can't create point with infinite coordinates [%s; %s]!", x, y));
        }
        this.x = x;
        this.y = y;
    }

    /**
     * Copying constructor. If source point for copy is null -
     * throws IllegalArgumentException (fail fast behavior).
     * @param point BasePoint2D source for copy.
    */
    public BasePoint2D(BasePoint2D point) {
        if (point == null) {
            throw new IllegalArgumentException("Can't create new point based on null BasePoint2D!");
        }
        this.x = point.getX();
        this.y = point.getY();
    }

    @Override
    @SuppressWarnings({"SimplifiableIfStatement", "MethodWithMultipleReturnPoints"})
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        BasePoint2D other = (BasePoint2D) obj;

        if (Double.compare(other.getX(), getX()) != 0) return false;
        return Double.compare(other.getY(), getY()) == 0;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        temp = Double.doubleToLongBits(this.getX());
        result = (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(this.getY());
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    @Override
    public String toString() {
        //return String.format("[%.6f, %.6f]", x, y);
        return String.format("[%s, %s]", x, y);
    }

    /**
     * Add coordinates to current point. Return new point (this point is immutable).
     * @param x double adder to X
     * @param y double adder to Y
     * @return BasePoint2D new point
     */
    public BasePoint2D add(double x, double y) {
        return new BasePoint2D(this.getX() + x, this.getY() + y);
    }

    /**
     * Add point to the current point. Return new point (this class is immutable).
     * Method is fail-fast - if point is null IllegalArgumentException will be thrown.
     * @param point BasePoint2D added point
     * @return BasePoint2D new point
     */
    public BasePoint2D add(BasePoint2D point) {
        if (point == null) {
            throw new IllegalArgumentException("Can't add null point!");
        }
        return this.add(point.getX(), point.getY());
    }

    /**
     * Substract coordinates from point. Return new point.
     * @param x double substraction value x
     * @param y double substraction value y
     * @return BasePoint2D
     */
    public BasePoint2D sub(double x, double y) {
        return new BasePoint2D(this.getX() - x, this.getY() - y);
    }

    /**
     * Substract point form this point. Return new point.
     * Method is fail-fast - if substracted point is null method throws IllegalArgumentException.
     * @param subPoint BasePoint2D
     * @return BasePoint2D
     */
    public BasePoint2D sub(BasePoint2D subPoint) {
        if (subPoint == null) {
            throw new IllegalArgumentException("Can't substract null point!");
        }
        return this.sub(subPoint.getX(), subPoint.getY());
    }

    /**
     * Multiply point. Return new point.
     * @param factorX double multiplier by X
     * @param factorY double multiplier by Y
     * @return BasePoint2D
     */
    public BasePoint2D mul(double factorX, double factorY) {
        return new BasePoint2D(this.getX() * factorX, this.getY() * factorY);
    }

    /**
     * Multiply point by point. Return new point.
     * If input point is null - throw IllegalArgumentException (fail-fast).
     * @param point BasePoint2D factor
     * @return BasePoint2D
     */
    public BasePoint2D mul(BasePoint2D point) {
        if (point == null) {
            throw new IllegalArgumentException("Can't multiply by null point!");
        }
        return this.mul(point.getX(), point.getY());
    }

    /**
     * Divide point coordinates [x;y] by dividers [divX; divY]. Return new point.
     * @param divX double divider by x.
     * @param divY double divider by y.
     * @return BasePoint2D
     */
    public BasePoint2D div(double divX, double divY) {
        return new BasePoint2D(this.getX() / divX, this.getY() / divY);
    }

    /**
     * Divide one point (coordinates [x;y]) by other point. Return new point.
     * Implement fail-fast behavior - if divider point is null, will throw IllegalArgumentException.
     * @param pointDivider BasePoint2D point divider
     * @return BasePoint2D
     */
    public BasePoint2D div(BasePoint2D pointDivider) {
        if (pointDivider == null) {
            throw new IllegalArgumentException("Can't divide by null point!");
        }
        return this.div(pointDivider.getX(), pointDivider.getY());
    }

    /**
     * Rotate radius vector on pi/2 angle around [0; 0] counter-clockwise.
     * Return new BasePoint2D (new radius vector).
     * @return BasePoint2D
     */
    public BasePoint2D rotateOrtho() {
        return new BasePoint2D(-this.getY(), this.getX());
    }

    /**
     * Rotate radius vector on pi/2 angle around point [x, y] counter-clockwise.
     * Return new BasePoint2D (new radius vector).
     * @param center BasePoint2D rotation center
     * @return BasePoint2D
     */
    public BasePoint2D rotateOrtho(BasePoint2D center) {
        if (center == null) {
            throw new IllegalArgumentException("Can't rotate point around null point!");
        }
        return this.sub(center).rotateOrtho().add(center);
    }

    @Override
    public BasePoint2D rotate(double angle, double rotateCenterX, double rotateCenterY) {
        // move point to origin [0; 0]
        BasePoint2D point = this.sub(rotateCenterX, rotateCenterY);
        // calculate sinus/cosinus
        double sin = Math.sin(angle);
        double cos = Math.cos(angle);
        // rotate point around origin [0; 0]
        double newX = point.getX() * cos - point.getY() * sin;
        double newY = point.getY() * cos + point.getX() * sin;
        // move point back from origin and return it
        return new BasePoint2D(newX, newY).add(rotateCenterX, rotateCenterY);
    }

    /**
     * Rotate point by double angle and rotation center at BasePoint2D.
     * Method is fail-fast - if point is null, method throws IllegalArgumentException.
     * @param angle double rotation angle
     * @param rotateCenterPoint BasePoint2D rotation center
     */
    public BasePoint2D rotate(double angle, BasePoint2D rotateCenterPoint) {
        if (rotateCenterPoint == null) {
            throw new IllegalArgumentException("Can't rotate around null point!");
        }
        return this.rotate(angle, rotateCenterPoint.getX(), rotateCenterPoint.getY());
    }

    @Override
    public BasePoint2D scale(double scaleX, double scaleY, double scaleCenterX, double scaleCenterY) {
        double x = (this.getX() - scaleCenterX) * scaleX + scaleCenterX;
        double y = (this.getY() - scaleCenterY) * scaleY + scaleCenterY;
        return new BasePoint2D(x, y);
    }

    @Override
    public BasePoint2D translate(double translateX, double translateY) {
        return new BasePoint2D(this.getX() + translateX, this.getY() + translateY);
    }

    /**
     * Move point orthogonal to vector (line) [direction point->curent point] - line defined by two points - direction point
     * and current point. Moving point clockwise. If directionPoint is null - throws {@link IllegalArgumentException}.
     * If direction point is the same with current point - throws {@link IllegalStateException}.
     * @param distance double move value
     * @param directionPoint BasePoint2D direction, that is orthogonal to point move direction
     * @return Эта точка.
     */
    public BasePoint2D translateOrtho(double distance, BasePoint2D directionPoint) {

        if (directionPoint == null) { // check direction point
            throw new IllegalArgumentException("Can't move orthogonal to null point!");
        }

        if (this.equals(directionPoint)) { // check equality for current and direction point
            throw new IllegalStateException("Can't translate orthogonal to itself (current point equals to direction point)!");
        }

        double dx = directionPoint.getX() - this.x;
        double dy = directionPoint.getY() - this.y;
        double d = Math.sqrt(dx * dx + dy * dy);
        double tmpDouble = distance / d;
        return new BasePoint2D(this.x - tmpDouble * dy, this.y + tmpDouble * dx);
    }

    //@Override
    // todo: !!!!
    public BasePoint2D transform(BaseMatrix2D t) {
        double[] m = t.getMatrix();
        double oldX = x;
        double oldY = y;
        //x = m[0] * oldX + m[1] * oldY + m[2];
        //y = m[3] * oldX + m[4] * oldY + m[5];
        return this;
    }

    /**
     * Create inverted point. Return new point.
     * @return BasePoint2D inverted point
     */
    public BasePoint2D invert() {
        return new BasePoint2D((this.getX() == 0 ? this.getX() : 1.0 / this.getX()),
                (this.getY() == 0 ? this.getY() : 1.0 / this.getY()));
    }

    /**
     * Return distance to other point [px; py].
     * @param px double other point x coordinate.
     * @param py double other point y coordinate.
     * @return double distance
     */
    public double distanceToPoint(double px, double py) {
        double dx = px - this.getX();
        double dy = py - this.getY();
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Return distance to other point BasePoint2D. Method is fail-safe - if other point is null,
     * method will throw IllegalArgumentException.
     * @param point BasePoint2D
     * @return double distance
     */
    public double distanceToPoint(BasePoint2D point) {
        if (point == null) {
            throw new IllegalArgumentException("Can't calculate distance to null point!");
        }
        return this.distanceToPoint(point.getX(), point.getY());
    }

    /**
     * Return distance to line represented by two ppints (BasePoint2D).
     * Method is fail-fast - if one/both of points that represented line is null,
     * new IllegalArgumentException will be thrown.
     * @param point0 BasePoint2D first line point.
     * @param point1 BasePoint2D second line point.
     * @return double distance to line
     */
    // todo: !!!
    public double distanceToLine(BasePoint2D point0, BasePoint2D point1) {
        if (point0 == null || point1 == null) { // fail-fast behavior
            throw new IllegalArgumentException(String.format("One of line points P0->[%s] or P1->[%s] is null!", point0, point1));
        }
        BasePoint2D direction  = point1.sub(point0);
        BasePoint2D point      = this.sub(point0);
        BasePoint2D projection = point.project(direction);
        return projection.distanceToPoint(point);
    }

    /**
     * Check closeness to specified point p. If specified point is null,
     * method throws {@link IllegalArgumentException}.
     * @param p BasePoint2D point for closeness check
     * @return boolean true/false check result
     */
    public boolean isNear(BasePoint2D p) {
        if (p == null) {
            throw new IllegalArgumentException("Can't check closeness to null point!");
        }
        return this.isNear(p.getX(), p.getY());
    }

    /**
     * Check closeness to specified point [px, py].
     * @param px double x-coordinate
     * @param py double y-coordinate
     * @return boolean true/false - check result
     */
    public boolean isNear(double px, double py) {
        return this.distanceToPoint(px, py) < GEOMETRY_PRECISION;
    }

    /**
     * Return length of current radius-vector [origin, current point].
     * @return double radius-vector length.
     */
    public double length() {
        return this.distanceToPoint(0, 0);
    }

    /**
     * Normalize current vector (origin -> current point) and return new vector (point).
     * If current point is origin (length = 0) - throw IllegalStateException.
     * @return BasePoint2D normalized vector (with length = 1)
     */
    public BasePoint2D normalize() {
        if (this.length() == 0) {
            throw new IllegalStateException("Can't normalize zero-length vector!");
        }
        double length = this.length();
        return this.div(length, length);
    }

    /**
     * Отношение длины проекции этого вектора на указанный к длине указанного вектора.
     *
     * @param begin Начало вектора, на который производится проецирование.
     * @param end   Конец вектора, на который производится проецирование.
     * @return Отношение длины проекции этого вектора на указанный к длине указанного вектора.
     */
    // todo: !!!
    public double projection(BasePoint2D begin, BasePoint2D end) {
        double dx = begin.getX();
        double dy = begin.getY();
        double vx = this.x - dx;
        double vy = this.y - dy;
        dx = end.getX() - dx;
        dy = end.getY() - dy;
        return BasePoint2D.projection(vx, vy, dx, dy);
    }

    /**
     * Project current point (vector [0;0]->current) on vector (direction) begin->end. Return [x; y] coordinates
     * of projection for curent point (vector ending point) on vector begin->end (assumes, that current vector
     * begin point is [0; 0] - origin). If one/both of begin/end is null, throws IllegalArgumentException.
     * @param begin BasePoint2D start point of vector for projection (target)
     * @param end BasePoint2D end point of vector for projection (target)
     * @return BasePoint2D projection of current point on vector begin->end.
     */
    // todo: if end point is [0;0] - we get NaN in projection()!
    // todo: example -> http://ru.onlinemschool.com/math/library/vector/projection/ (for test calculations).
    public BasePoint2D project(BasePoint2D begin, BasePoint2D end) {
        if (begin == null || end == null) {
            throw new IllegalArgumentException(String.format("One of points begin [%s] or end [%s] is null!", begin, end));
        }
        double bx = begin.getX();
        double by = begin.getY();
        double dx = end.getX() - bx;
        double dy = end.getY() - by;
        double projection = BasePoint2D.projection(this.x - bx, this.y - by, dx, dy);
        return new BasePoint2D(projection * dx + bx, projection * dy + by);
    }

    /**
     * Project current point (vector [0;0]->current) on vector (direction) [0;0]->v. Return [x; y] coordinates
     * of projection for curent point (vector ending point) on vector [0;0]->v (assumes, that current vector
     * begin point is [0; 0] - origin). If vectort v is null, throws IllegalArgumentException.
     * @param v BasePoint2D end point of vector for projection (target)
     * @return BasePoint2D projection of current point on vector begin->end.
     */
    public BasePoint2D project(BasePoint2D v) {
        return this.project(new BasePoint2D(0, 0), v);
    }

    /**
     * Relation length of vector's v (vx, vy) projection on vector d (dx, dy) to vector's d (dx, dy) length.
     * @param vx double x of vector v
     * @param vy double y of vector v
     * @param dx double x of vector d
     * @param dy double y of vector d
     * @return double
     */
    private static double projection(double vx, double vy, double dx, double dy) {
        return (vx * dx + vy * dy) / (dx * dx + dy * dy);
    }

    /**
     * Проекция этого вектора на нормаль к вектору {begin, end}.
     *
     * @param begin Начало вектора, на нормаль которого проецируется данный вектор.
     * @param end   Конец вектора, на нормаль которого проецируется данный вектор.
     * @return Проекция этого вектора на нормаль к вектору {begin, end}.
     */
    // todo: !!!
    public BasePoint2D normale(BasePoint2D begin, BasePoint2D end) {
        return sub(begin).project(new BasePoint2D(end.getX() - begin.getX(), end.getY() - begin.getY()).rotateOrtho()).add(begin);
    }

    /**
     * Calculates angle (larger one, counted counter-clockwise) between vectors: vector [startPoint; endPoint]
     * and vector [startPoint; this]. Angle calculated in radians. If one of points p or startPoint is null,
     * method throws IllegalArgumentException.
     * @param endPoint BasePoint2D end of count vector
     * @param startPoint BasePoint2D start of count vector
     * @return double angle in radians between [startPoint; endPoint] and [startPoint; this]
     */
    public double angle(BasePoint2D endPoint, BasePoint2D startPoint) {
        if (endPoint == null || startPoint == null) { // fail-fast
            throw new IllegalArgumentException(String.format("One of points endPoint [%s] or startPoint [%s] is null!", endPoint, startPoint));
        }
        double ta = Math.atan2(this.y - startPoint.getY(), this.x - startPoint.getX());
        double pa = Math.atan2(endPoint.getY() - startPoint.getY(), endPoint.getX() - startPoint.getX());
        return GeometryUtils.mod(0, Math.PI * 2, ta - pa);
    }

    /**
     * Calculates angle (larger one, counted counter-clockwise) in radians between vector [0; 0]->[1; 0] and
     * vector [startPoint]->[this]. If startpoint is null, throws IllegalArgumentException.
     * @param startPoint BasePoint2D start point of vector
     * @return double angle in radians betwen mentioned vectors
     */
    public double angle(BasePoint2D startPoint) {
        if (startPoint == null) {
            throw new IllegalArgumentException("Start point is null!");
        }
        double ta = Math.atan2(this.y - startPoint.getY(), this.x - startPoint.getX());
        return GeometryUtils.mod(0, Math.PI * 2, ta);
    }

}