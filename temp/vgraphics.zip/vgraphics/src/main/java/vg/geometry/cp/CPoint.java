package vg.geometry.cp;


import vg.geometry.primitives.BasePoint2D;

import java.io.Serializable;
import java.util.Set;


/**
 * Вычисляемая точка.
 * <p>Служит для преобразования некоторых данных в координаты на плоскости и обратно.
 * <p>Преобразования выполняются <b>только</b> в методах {@link #calculate()} и {@link #decalculate()}
 * b <b>никогда</b> в методах getX(), getY(), setX(), setY().
 */
public interface CPoint extends Serializable {

    //@Override
    public CPoint clone();


    /**
     * Задать X.
     *
     * @param x Координата X.
     */
    public void setX(double x);

    /***/
    public double getX();

    /**
     * Задать Y.
     *
     * @param y Координата Y.
     */
    public void setY(double y);

    /***/
    public double getY();

    /**
     * Расчитать точку.
     * <p>Преобразовать данные, контролируемые этой точкой в координаты.
     *
     * @return Эта точка.
     */
    public CPoint calculate();

    /**
     * Произвести обратный расчёт.
     * <p>Преобразовать координаты точки в котролируемые ей данные.
     *
     * @return Эта точка.
     */
    public CPoint decalculate();

    /**
     * Получить точки, от которых зависит эта точка.
     * <p>Необходимы для правильного порядка автоматического расчёта. См. {@link CPCalculator#calculate(java.util.Collection)}.
     *
     * @return Точки, от которых зависит эта точка.
     */
    public Set<CPoint> getDependencies();

    /**
     * Уточнённая по типу проверка эквивалентности точек.
     *
     * @param p Другая точка.
     * @return Признак эквивалентности точек.
     */
    public boolean equals(BasePoint2D p);

}