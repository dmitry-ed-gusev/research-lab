package vg.geometry.cp;

import vg.geometry.GeometryProcessor;
import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BasePoint2D;

/**
 * Point on line between two other points.
 */

public class RelativeCPoint extends AbstractCPoint {

    /***/
    private static final long serialVersionUID = 5380412367176589246L;

    /**
     * Первая точка.
     */
    protected CPoint p0;
    /**
     * Вторая точка.
     */
    protected CPoint p1;
    /**
     * Смещение (%).
     */
    protected double t;


    /**
     * @param p0 Первая точка.
     * @param p1 Вторая точка.
     * @param t  Смещение (%).
     */
    public RelativeCPoint(CPoint p0, CPoint p1, double t) {
        this.p0 = p0;
        this.p1 = p1;
        this.t = t;
        dependencies.add(p0);
        dependencies.add(p1);
    }


    @Override
    public CPoint calculate() {
        BasePoint2D pointP0 = new BasePoint2D(p0.getX(), p0.getY());
        BasePoint2D pointP1 = new BasePoint2D(p1.getX(), p1.getY());

        //point.init(GeometryUtils.absolute(pointP0, pointP1, t));
        this.point = GeometryUtils.absolute(pointP0, pointP1, t);

        return this;
    }

    @Override
    public CPoint decalculate() {
        BasePoint2D pointP0 = new BasePoint2D(p0.getX(), p0.getY());
        BasePoint2D pointP1 = new BasePoint2D(p1.getX(), p1.getY());
        BasePoint2D nearestPoint = GeometryProcessor.nearestPointOnLine(pointP0, pointP1, point);
        if (nearestPoint != null) {
            if (Math.abs(p1.getX() - p0.getX()) > Math.abs(p1.getY() - p0.getY()))
                t = GeometryUtils.relative(p0.getX(), p1.getX(), nearestPoint.getX());
            else
                t = GeometryUtils.relative(p0.getY(), p1.getY(), nearestPoint.getY());
        }
        return this;
    }

    /**
     * Получить первую точку отсчёта.
     *
     * @return Первая точка отсчёта.
     */
    public CPoint getP0() {
        return p0;
    }

    /**
     * Задать первую точку отсчёта.
     *
     * @param p0 Первая точка отсчёта.
     */
    public void setP0(CPoint p0) {
        this.p0 = p0;
    }

    /**
     * Получить вторую точку отсчёта.
     *
     * @return Вторая точка отсчёта.
     */
    public CPoint getP1() {
        return p1;
    }

    /**
     * Задать вторую точку отсчёта.
     *
     * @param p1 Вторая точка отсчёта.
     */
    public void setP1(CPoint p1) {
        this.p1 = p1;
    }

    /**
     * Получить относительное смещение между точками.
     *
     * @return Относительное смещение между точками.
     */
    public double getT() {
        return t;
    }

    /**
     * Задать относительное смещение между точками.
     *
     * @param t Относительное смещение между точками.
     */
    public void setT(double t) {
        this.t = t;
    }

}
