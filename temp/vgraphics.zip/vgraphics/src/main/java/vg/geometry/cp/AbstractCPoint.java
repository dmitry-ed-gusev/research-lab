package vg.geometry.cp;

import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BasePoint2D;

import java.util.HashSet;
import java.util.Set;


/**
 * Abstract calculated point.
 */

public abstract class AbstractCPoint implements CPoint {

    /***/
    private static final long serialVersionUID = 8627391526676377035L;

    /**
     * Текущие координаты.
     */
    protected BasePoint2D point = new BasePoint2D();
    /**
     * Зависимости.
     */
    protected Set<CPoint> dependencies = new HashSet<CPoint>();


    /***/
    public AbstractCPoint() {
        init(0.0, 0.0);
    }

    /**
     * @param x Текущая координата X.
     * @param y Текущая координата Y.
     */
    public AbstractCPoint(double x, double y) {
        init(x, y);
    }

    /**
     * @param p Текущие координаты.
     */
    public AbstractCPoint(BasePoint2D p) {
        init(p);
    }


    @Override
    public AbstractCPoint clone() {
        try {
            AbstractCPoint clonedObject = (AbstractCPoint) super.clone();

            clonedObject.point = new BasePoint2D(point);

            clonedObject.dependencies = new HashSet<CPoint>();
            for (CPoint cp : dependencies) {
                clonedObject.dependencies.add(cp.clone());
            }

            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof AbstractCPoint))
            return false;
        AbstractCPoint other = (AbstractCPoint) obj;

        return point.equals(other.point) &&
                dependencies.equals(other.dependencies);
    }

    @Override
    public boolean equals(BasePoint2D p) {
        return point.equals(p);
    }

    @Override
    public int hashCode() {
        int result = 71;
        result ^= point.hashCode();
        for (CPoint p : dependencies)
            result = GeometryUtils.cyclicShift(result, 3) ^ p.hashCode();
        return result;
    }


    /**
     * Обнулить текущие координаты.
     *
     * @return Эта точка.
     */
    public AbstractCPoint init() {
        //point.init();
        this.point = new BasePoint2D();
        return this;
    }

    /**
     * Задать текущие координаты.
     *
     * @param x Текущая координата X.
     * @param y Текущая координата Y.
     * @return Эта точка.
     */
    public AbstractCPoint init(double x, double y) {
        //point.init(x, y);
        this.point = new BasePoint2D(x, y);
        return this;
    }

    /**
     * Задать текущие координаты.
     *
     * @param p Текущие координаты.
     * @return Эта точка.
     */
    public AbstractCPoint init(BasePoint2D p) {
        //point.init(p);
        this.point = new BasePoint2D(p);
        return this;
    }


    @Override
    public double getX() {
        return point.getX();
    }

    @Override
    public void setX(double x) {
        //point.setX(x);
        this.point = new BasePoint2D(x, this.point.getY());
    }

    @Override
    public double getY() {
        return point.getY();
    }

    @Override
    public void setY(double y) {
        //point.setY(y);
        this.point = new BasePoint2D(this.point.getX(), y);
    }


    @Override
    public Set<CPoint> getDependencies() {
        return dependencies;
    }

}
