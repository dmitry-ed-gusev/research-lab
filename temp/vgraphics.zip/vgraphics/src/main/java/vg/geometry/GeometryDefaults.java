package vg.geometry;

import java.awt.*;

/**
 * Geometry defaults.
 * @author Gusev D.
 */

public interface GeometryDefaults {

    /** Precision for geometry operations/values. */
    double GEOMETRY_PRECISION = 1e-12;
    /** Polyline precision */
    double POLYLINE_PRECISION = 1e-6;

    /**
     * Множитель преобразования дюймов в милиметры.
     */
    public static final double INC_TO_MM = 25.4;
    /**
     * Множитель преобразования дюймов в метры.
     */
    public static final double INC_TO_M = INC_TO_MM / 1000.0;
    /**
     * Множитель преобразования типографских пунктов в дюймы.
     */
    public static final double PT_TO_INC = 1.0 / 72.0;
    /**
     * Множитель преобразования типографских пунктов в милиметры.
     */
    public static final double PT_TO_MM = PT_TO_INC * INC_TO_MM;
    /**
     * Множитель преобразования радиан в градусы.
     */
    public static final double RAD_TO_GRAD = 180.0 / Math.PI;
    /**
     * Шаблон для вещественных чисел.
     */
    public static final String RE_FLOAT = "[\\+\\-]?\\d*[\\.\\,]?\\d*";
    /**
     * Шаблон для положительных вещественных чисел.
     */
    public static final String RE_POS_FLOAT = "\\d*[\\.\\,]?\\d*";
    /**
     * Шаблон для целых чисел.
     */
    public static final String RE_INTEGER = "[\\+\\-]?(?:(?:0)|(?:[1-9]\\d*))?";
    /**
     * Шаблон для положительных целых чисел.
     */
    public static final String RE_POS_INTEGER = "(?:(?:0)|(?:[1-9]\\d*))?";
    /**
     * Разделитель, используемый в многострочном тексте.
     */
    public static final String RE_LINE_SEPARATOR = "(?:\\r\\n)|(?:\\n)|(?:\\r)";

    /** Разрешение экрана в точках на дюйм (значение с плавающей точкой). */
    // TODO 29.04.2015 баг - если запустить в никсах без X-сервера, дает ошибку, исправлено в проекте [COMMON] - взять оттуда!
    //public static double RESOLUTION_DPI_DOUBLE = Toolkit.getDefaultToolkit().getScreenResolution();
    /** Разрешение экрана в точках на дюйм (целочисленное значение). */
    //public static int RESOLUTION_DPI_INT = (int) RESOLUTION_DPI_DOUBLE;
    /** Разрешение экрана в точках на миллиметр. */
    //public static double RESOLUTION_DPMM = RESOLUTION_DPI_INT / INC_TO_MM;

    /** Line cap type. */
    enum LineCapType {BUTT, SQUARE, ROUND;

        /**
         * Возвращает тип окончания по целому значению. Значения привязаны к java.awt.BasicStroke.
         */
        public static LineCapType getCapTypeByValue(int value) {
            LineCapType result;
            switch (value) {
                case BasicStroke.CAP_BUTT:
                    result = LineCapType.BUTT;
                    break;
                case BasicStroke.CAP_ROUND:
                    result = LineCapType.ROUND;
                    break;
                case BasicStroke.CAP_SQUARE:
                    result = LineCapType.SQUARE;
                    break;
                default:
                    result = null;
            }
            return result;
        }
    }

    /** Lines join type. */
    enum LinesJoinType {BEVEL, MITTER, ROUND;

        /**
         * Возвращает тип сочленения отрезков по целому значению.
         * Значения привязаны к java.awt.BasicStroke.
         */
        public static LinesJoinType getJoinTypeByValue(int value) {
            LinesJoinType result;
            switch (value) {
                case BasicStroke.JOIN_BEVEL:
                    result = LinesJoinType.BEVEL;
                    break;
                case BasicStroke.JOIN_MITER:
                    result = LinesJoinType.MITTER;
                    break;
                case BasicStroke.JOIN_ROUND:
                    result = LinesJoinType.ROUND;
                    break;
                default:
                    result = null;
            }
            return result;
        }
    }

    /** Line arrow type. */
    enum LineArrowType {NONE, SOLID, STICK}

    /** Horizontal element placement. */
    enum ElementHAlignment {LEFT, RIGHT, CENTER}

    /** Vertical element placement. */
    enum ElementVAlignment {TOP, BOTTOM, CENTER}

    /** Element placement. */
    enum ElementAlignment {TOP, BOTTOM, LEFT, RIGHT}

}