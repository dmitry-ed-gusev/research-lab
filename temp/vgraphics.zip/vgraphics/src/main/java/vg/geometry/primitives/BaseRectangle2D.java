package vg.geometry.primitives;

import vg.geometry.GeometryUtils;
import vg.geometry.ITransformable;

import java.io.Serializable;

/**
 * Rectangle area on the plane with any rotate degree.
 * <pre>
 * TL----T----TR ^
 * |           | |
 * L     C     R H
 * |           | |
 * BL----B----BR v
 * <&lt;-----W-----&gt;
 * </pre>
 */

public class BaseRectangle2D implements Serializable, ITransformable<BaseRectangle2D> {

    private static final long serialVersionUID = 1L;

    private BasePoint2D tlP;    // top left point of rectangle
    private double      width;  // rectangle width
    private double      height; // rectangle height
    private double      angle;  // rectangle rotation angle

    /**
     * Constructor.
     * @param tlX    X-координата вернего левого угла.
     * @param tlY    Y-координата вернего левого угла.
     * @param width  Ширина.
     * @param height Высота.
     * @param angle  Угол поворота.
     */
    public BaseRectangle2D(double tlX, double tlY, double width, double height, double angle) {
        this.tlP = new BasePoint2D(tlX, tlY);
        this.width = width;
        this.height = height;
        this.angle = angle;
    }

    /**
     * Создание прямоугольной области.
     *
     * @param tlP   Верхний левый угол.
     * @param size  Размер.
     * @param angle Угол поворота.
     */
    public BaseRectangle2D(BasePoint2D tlP, BasePoint2D size, double angle) {
        this(tlP.getX(), tlP.getY(), size.getX(), size.getY(), angle);
    }

    /**
     * Создание прямоугольной области.
     */
    public BaseRectangle2D() {
        this(0, 0, 0, 0, 0);
    }

    /**
     * Создание прямоугольной области.
     *
     * @param tlP    Верхний левый угол.
     * @param width  Ширина.
     * @param height Высота.
     * @param angle  Угол поворота.
     */
    public BaseRectangle2D(BasePoint2D tlP, double width, double height, double angle) {
        this.tlP = tlP;
        this.width = width;
        this.height = height;
        this.angle = angle;
    }

    /**
     * Создание прямоугольной области.
     * @param r Копируемая прямоугольная область.
     */
    //public Rectangle2D(Rectangle2D r) {
    //	this(r.tlP.getX(), r.tlP.getY(), r.width, r.height, r.angle);
    //}

    /**
     * Создание прямоугольной области.
     *
     * @param r Копируемая прямоугольная область.
     */
    public BaseRectangle2D(BaseRectangle2D r) {
        this(r.getTLP().getX(), r.getTLP().getY(), r.getWidth(), r.getHeight(), r.getAngle());
    }

    /**
     * Создание прямоугольной области.
     *
     * @param frame Фрейм.
     * @param angle угол поворота.
     */
    public BaseRectangle2D(BaseFrame2D frame, double angle) {
        this(frame.getP1().getX(), frame.getP1().getY(),
                frame.getSize().getX(), frame.getSize().getY(), angle);
    }

    /**
     * Создание прямоугольной области.
     *
     * @param frame Фрейм.
     */
    public BaseRectangle2D(BaseFrame2D frame) {
        this(frame, 0);
    }

    @Override
    public BaseRectangle2D clone() {
        try {
            BaseRectangle2D clonedObject = (BaseRectangle2D) super.clone();
            clonedObject.tlP = new BasePoint2D(tlP);
            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (obj == null)
            return false;
        if (obj.getClass() != getClass())
            return false;
        BaseRectangle2D other = (BaseRectangle2D) obj;

        return tlP.equals(other.tlP) &&
                width == other.width &&
                height == other.height &&
                angle == other.angle;
    }

    @Override
    public int hashCode() {
        int result = 17;
        result ^= tlP.hashCode();
        result = GeometryUtils.cyclicShift(result, 19);
        result ^= GeometryUtils.hashCode(width);
        result = GeometryUtils.cyclicShift(result, 17);
        result ^= GeometryUtils.hashCode(height);
        result = GeometryUtils.cyclicShift(result, 11);
        result ^= GeometryUtils.hashCode(angle);
        return result;
    }

    @Override
    public String toString() {
        return String.format("{%s, %f x %f, %f}", tlP, width, height, angle);
    }

    /**
     * Инициализация приямойгольной области.
     *
     * @param tlX    X-координата вернего левого угла.
     * @param tlY    Y-координата вернего левого угла.
     * @param width  Ширина.
     * @param height Высота.
     * @param angle  Угол поворота.
     * @return this.
     */
    public BaseRectangle2D init(double tlX, double tlY, double width,
                                double height, double angle) {
        // todo: commented temporary!!!
        //this.tlP.init(tlX, tlY);
        this.width = width;
        this.height = height;
        this.angle = angle;
        return this;
    }

    /**
     * Инициализация приямойгольной области.
     *
     * @param tlP   Верхний левый угол.
     * @param size  Размер.
     * @param angle Угол поворота.
     * @return this.
     */
    public BaseRectangle2D init(BasePoint2D tlP, BasePoint2D size, double angle) {
        return init(tlP.getX(), tlP.getY(), size.getX(), size.getY(), angle);
    }

    /**
     * Инициализация приямойгольной области.
     *
     * @return this.
     */
    public BaseRectangle2D init() {
        return init(0, 0, 0, 0, 0);
    }

    /**
     * Инициализация приямойгольной области.
     *
     * @param r Копируемая прямоугольная область.
     * @return this.
     */
    public BaseRectangle2D init(BaseRectangle2D r) {
        return init(
                r.getTLP().getX(), r.getTLP().getY(),
                r.getWidth(), r.getHeight(), r.getAngle());
    }

    /**
     * Инициализация приямойгольной области.
     *
     * @param frame Фрейм.
     * @param angle угол поворота.
     * @return this.
     */
    public BaseRectangle2D init(BaseFrame2D frame, double angle) {
        return init(
                frame.getP1().getX(), frame.getP1().getY(),
                frame.getWidth(), frame.getHeight(), angle);
    }

    /**
     * Инициализация приямойгольной области.s
     *
     * @param frame Фрейм.
     * @return this.
     */
    public BaseRectangle2D init(BaseFrame2D frame) {
        return init(frame, 0);
    }

    /**
     * Получение верхней левой точки.
     *
     * @return Верхняя левая точка.
     */
    public BasePoint2D getTLP() {
        return new BasePoint2D(tlP);
    }

    /**
     * Установка верхней левой точки.
     *
     * @param tlP Верхняя левая точка.
     */
    public void setTlP(BasePoint2D tlP) {
        this.tlP = new BasePoint2D(tlP);
    }

    /**
     * Получение верхней точки.
     *
     * @return Верхняя точка.
     */
    public BasePoint2D getTP() {
        return new BasePoint2D(tlP).translate(width * 0.5, 0).rotate(angle, tlP);
    }

    /**
     * Получение верхней правой точки.
     *
     * @return Верхняя правая точка.
     */
    public BasePoint2D getTRP() {
        return new BasePoint2D(tlP).translate(width, 0).rotate(angle, tlP);
    }

    /**
     * Получение правой точки.
     *
     * @return Правая точка.
     */
    public BasePoint2D getRP() {
        return new BasePoint2D(tlP).translate(width, height * 0.5).rotate(angle, tlP);
    }

    /**
     * Получение нижней правой точки.
     *
     * @return Нижняя правая точка.
     */
    public BasePoint2D getBRP() {
        return new BasePoint2D(tlP).translate(width, height).rotate(angle, tlP);
    }

    /**
     * Получение нижней точки.
     *
     * @return Нижняя точка.
     */
    public BasePoint2D getBP() {
        return new BasePoint2D(tlP).translate(width * 0.5, height).rotate(angle, tlP);
    }

    /**
     * Получение нижней левой точки.
     *
     * @return Нижняя левая точка.
     */
    public BasePoint2D getBLP() {
        return new BasePoint2D(tlP).translate(0, height).rotate(angle, tlP);
    }

    /**
     * Получение левой точки.
     *
     * @return Левая точка.
     */
    public BasePoint2D getLP() {
        return new BasePoint2D(tlP).translate(0, height * 0.5).rotate(angle, tlP);
    }

    /**
     * Получение центра.
     *
     * @return Центр.
     */
    public BasePoint2D getCenter() {
        return getTLP().add(getBRP()).mul(0.5, 0.5);
    }

    /**
     * Получение точек прямоугольника.
     *
     * @return [TL, T, TR, R, BR, B, BL, L].
     */
    public BasePoint2D[] getPoints() {
        return new BasePoint2D[]{getTLP(), getTP(), getTRP(), getRP(), getBRP(),
                getBP(), getBLP(), getLP()};
    }

    /**
     * Получение точки по индексу.
     *
     * @param index Индекс точки в массиве [TL, T, TR, R, BR, B, BL, L].
     * @return Точка прямоугольника.
     */
    public BasePoint2D getPoint(int index) {
        switch (index) {
            case 0:
                return getTLP();
            case 1:
                return getTP();
            case 2:
                return getTRP();
            case 3:
                return getRP();
            case 4:
                return getBRP();
            case 5:
                return getBP();
            case 6:
                return getBLP();
            case 7:
                return getLP();
            default:
                return null;
        }
    }

    /**
     * Получить точку в прямоугольнике по относительному смещению от TLP до BRP с учётом угла наклона.
     *
     * @param tx Относительно смещение по X.
     * @param ty Относительно смещение по Y.
     * @return Точка в прямоугольнике по относительному смещению от TLP до BRP с учётом угла наклона.
     */
    public BasePoint2D getPoint(double tx, double ty) {
        return GeometryUtils.absolute(tlP, new BasePoint2D(tlP).add(width, height), tx, ty).rotate(angle, tlP);
    }

    /**
     * Получить точку в прямоугольнике по относительному смещению от TLP до BRP с учётом угла наклона.
     *
     * @param t Относительно смещение.
     * @return Точка в прямоугольнике по относительному смещению от TLP до BRP с учётом угла наклона.
     */
    public BasePoint2D getPoint(BasePoint2D t) {
        return getPoint(t.getX(), t.getY());
    }

    /**
     * Получение ширины прямоугольника.
     *
     * @return Ширина прямоугольника.
     */
    public double getWidth() {
        return width;
    }

    /**
     * Установка ширины прямоугольника.
     *
     * @param width Ширина прямоугольника.
     */
    public void setWidth(double width) {
        this.width = width;
    }

    /**
     * Получение высоты прямоугольника.
     *
     * @return Высоты прямоугольника.
     */
    public double getHeight() {
        return height;
    }

    /**
     * Установка ширины прямоугольника.
     *
     * @param height Ширина прямоугольника.
     */
    public void setHeight(double height) {
        this.height = height;
    }

    /**
     * Получение размера прямоугольника.
     *
     * @return Размер прямоугольника.
     */
    public BasePoint2D getSize() {
        return new BasePoint2D(width, height);
    }

    /**
     * Получение абсолютного размера прямоугольника.
     *
     * @return Абсолютный размер прямоугольника.
     */
    public BasePoint2D getAbsSize() {
        return new BasePoint2D(Math.abs(width), Math.abs(height));
    }

    /**
     * Установка размера приямоугольника.
     *
     * @param width  Ширина.
     * @param height Высота.
     */
    public void setSize(double width, double height) {
        this.width = width;
        this.height = height;
    }

    /**
     * Установка размера приямоугольника.
     *
     * @param size Размер.
     */
    public void setSize(BasePoint2D size) {
        this.width = size.getX();
        this.height = size.getY();
    }

    /**
     * Получение угла поворота.
     *
     * @return Угол поворота.
     */
    public double getAngle() {
        return angle;
    }

    /**
     * Установка угла поворота.
     *
     * @param angle Угол поворота.
     */
    public void setAngle(double angle) {
        this.angle = angle;
    }

    /**
     * Определить находится ли точка p в прямоугольной области
     *
     * @param p Точка, принадлежность которой проверяется.
     * @return Флаг принадлежности точки этому прямоугольнику.
     */
    public boolean intersect(BasePoint2D p) {
        BaseRectangle2D rect = this.clone();
        rect.rotate(-getAngle(), 0, 0);
        double ymin = Math.min(rect.getTP().getY(), rect.getBP().getY());
        double ymax = Math.max(rect.getTP().getY(), rect.getBP().getY());
        double xmin = Math.min(rect.getRP().getX(), rect.getLP().getX());
        double xmax = Math.max(rect.getRP().getX(), rect.getLP().getX());
        return (ymin <= p.getY() && p.getY() <= ymax && p.getX() >= xmin && p
                .getX() <= xmax);
    }

    @Override
    public BaseRectangle2D translate(double x, double y) {
        tlP.translate(x, y);
        return this;
    }

    //@Override
    public BaseRectangle2D translate(BasePoint2D p) {
        return translate(p.getX(), p.getY());
    }

    @Override
    public BaseRectangle2D scale(double kx, double ky, double cx, double cy) {
        tlP.translate(-cx, -cy)
                .rotate(-angle, 0, 0)
                .scale(kx, ky, 0, 0)
                .rotate(angle, 0, 0)
                .translate(cx, cy);
        width *= kx;
        height *= ky;
        return this;
    }

    /*
    @Override
    public BaseRectangle2D scale(double k, double cx, double cy) {
        return scale(k, k, cx, cy);
    }

    @Override
    public BaseRectangle2D scale(double kx, double ky) {
        return scale(kx, ky, 0, 0);
    }

    @Override
    public BaseRectangle2D scale(double k) {
        return scale(k, k, 0, 0);
    }
    */

    //@Override
    public BaseRectangle2D scale(BasePoint2D k, BasePoint2D c) {
        return scale(k.getX(), k.getY(), c.getX(), c.getY());
    }

    //@Override
    public BaseRectangle2D scale(BasePoint2D k) {
        return scale(k.getX(), k.getY(), 0, 0);
    }

    //@Override
    public BaseRectangle2D scale(double k, BasePoint2D c) {
        return scale(k, k, c.getX(), c.getY());
    }

    //@Override
    //public BaseRectangle2D rotate(double a) {
    //    tlP.rotate(a);
    //    angle += a;
    //    return this;
    //}

    @Override
    public BaseRectangle2D rotate(double a, double cx, double cy) {
        tlP.rotate(a, cx, cy);
        angle += a;
        return this;
    }

    //@Override
    public BaseRectangle2D rotate(double a, BasePoint2D c) {
        return rotate(a, c.getX(), c.getY());
    }

    //@Override
    public BaseRectangle2D transform(BaseMatrix2D t) {
        BasePoint2D trP = getTRP().transform(t);
        BasePoint2D blP = getBLP().transform(t);
        this.tlP.transform(t);
        this.width = trP.distanceToPoint(tlP);
        this.height = width != 0.0 ? blP.distanceToLine(tlP, trP) : blP.distanceToPoint(tlP);
        this.angle = trP.angle(tlP);
        return this;
    }

    /**
     * Расширить прямоугольник.
     *
     * @param left   Расширение влево.
     * @param right  Расширение вправо.
     * @param top    Расширение вверх.
     * @param bottom Расширение вниз.
     * @return Этот прямоугольник.
     */
    public BaseRectangle2D extend(double left, double right, double top, double bottom) {
//		tlP.rotate(-angle).translate(-left, -top).rotate(angle);

        double s = Math.sin(angle);
        double c = Math.cos(angle);
        tlP.add(top * s - left * c, -left * s - top * c);

        width += left + right;
        height += top + bottom;

        return this;
    }

    /**
     * Расширить прямоугольник.
     *
     * @param horizontal Расширение влево и вправо.
     * @param vertical   Расширение вверх и вниз.
     * @return Этот прямоугольник.
     */
    public BaseRectangle2D extend(double horizontal, double vertical) {
//		extend(horizontal, horizontal, vertical, vertical);

        double s = Math.sin(angle);
        double c = Math.cos(angle);
        tlP.add(vertical * s - horizontal * c, -horizontal * s - vertical * c);

        width += horizontal * 2;
        height += vertical * 2;

        return this;
    }

    /**
     * Расширить прямоугольник.
     *
     * @param extent Расширение влево, вправо, вверх и вниз.
     * @return Расширенный прямоугольник.
     */
    public BaseRectangle2D extend(double extent) {
//		extend(extent, extent, extent, extent);

        double s = Math.sin(angle);
        double c = Math.cos(angle);
        tlP.add(extent * (s - c), extent * (-s - c));

        width += extent * 2;
        height += extent * 2;

        return this;
    }

    /**
     * Масштабирование точкой.
     *
     * @param sp Исходная точка.
     * @param tp Целевая точка.
     * @param cp Центр масштабирования.
     * @return Этот прямоугольник, отмасштабированный.
     */
    public BaseRectangle2D scaleWithPoint(BasePoint2D sp, BasePoint2D tp, BasePoint2D cp) {
        sp = new BasePoint2D(sp).sub(cp).rotate(-angle, 0, 0);
        tp = new BasePoint2D(tp).sub(cp).rotate(-angle, 0, 0);

        double kx = 1.0;
        if (!GeometryUtils.isNearZero(sp.getX(), getWidth() * 1e-3))
            kx = tp.getX() / sp.getX();
        double ky = 1.0;
        if (!GeometryUtils.isNearZero(sp.getY(), getHeight() * 1e-3))
            ky = tp.getY() / sp.getY();

        return scale(kx, ky, cp.getX(), cp.getY());
    }

    /**
     * Маштабирование за верхнюю левую точку.
     *
     * @param tp Целевая точка.
     * @return this.
     */
    public BaseRectangle2D scaleWithTLP(BasePoint2D tp) {
        return scaleWithPoint(getTLP(), tp, getBRP());
    }

    /**
     * Маштабирование за верхнюю точку.
     *
     * @param tp Целевая точка.
     * @return this.
     */
    public BaseRectangle2D scaleWithTP(BasePoint2D tp) {
        return scaleWithPoint(getTP(), tp, getBP());
    }

    /**
     * Маштабирование за верхнюю правую точку.
     *
     * @param tp Целевая точка.
     * @return this.
     */
    public BaseRectangle2D scaleWithTRP(BasePoint2D tp) {
        return scaleWithPoint(getTRP(), tp, getBLP());
    }

    /**
     * Маштабирование за правую точку.
     *
     * @param tp Целевая точка.
     * @return this.
     */
    public BaseRectangle2D scaleWithRP(BasePoint2D tp) {
        return scaleWithPoint(getRP(), tp, getLP());
    }

    /**
     * Маштабирование за нижнюю правую точку.
     *
     * @param tp Целевая точка.
     * @return this.
     */
    public BaseRectangle2D scaleWithBRP(BasePoint2D tp) {
        return scaleWithPoint(getBRP(), tp, getTLP());
    }

    /**
     * Маштабирование за нижнюю точку.
     *
     * @param tp Целевая точка.
     * @return this.
     */
    public BaseRectangle2D scaleWithBP(BasePoint2D tp) {
        return scaleWithPoint(getBP(), tp, getTP());
    }

    /**
     * Маштабирование за нижнюю левую точку.
     *
     * @param tp Целевая точка.
     * @return this.
     */
    public BaseRectangle2D scaleWithBLP(BasePoint2D tp) {
        return scaleWithPoint(getBLP(), tp, getTRP());
    }

    /**
     * Маштабирование за левую точку.
     *
     * @param tp Целевая точка.
     * @return this.
     */
    public BaseRectangle2D scaleWithLP(BasePoint2D tp) {
        return scaleWithPoint(getLP(), tp, getRP());
    }

    /**
     * Получить габариты прямоугольника.
     *
     * @return Габариты прямоугольника.
     */
    public BaseFrame2D getBounds() {
        double s = Math.sin(angle);
        double c = Math.cos(angle);

        double dx1 = height * s;
        double dx2 = width * c;
        double dy1 = height * c;
        double dy2 = width * s;

        double cx = tlP.getX();
        double cy = tlP.getY();

        if ((s >= 0) == (c >= 0)) {
            if (s > 0) {
                return new BaseFrame2D(cx - dx1, cy, cx + dx2, cy + dy1 + dy2);
            } else {
                return new BaseFrame2D(cx + dx2, cy + dy1 + dy2, cx - dx1, cy);
            }
        } else {
            if (s > 0) {
                return new BaseFrame2D(cx - dx1 + dx2, cy + dy1, cx, cy + dy2);
            } else {
                return new BaseFrame2D(cx, cy + dy2, cx - dx1 + dx2, cy + dy1);
            }
        }
    }

    /**
     * Получить прямоугольник {@link BaseFrame2D}, построенный по точкам этого прямоугольника.
     *
     * @return Прямоугольник {@link BaseFrame2D}, построенный по точкам этого прямоугольника.
     */
    public BaseFrame2D getFrame() {
        return new BaseFrame2D(new BasePoint2D(tlP), new BasePoint2D(tlP).add(getWidth(),
                getHeight()));
    }

    /**
     * Проверить, попадпет ли точка в данный прямоугольник.
     *
     * @param p Проверяемая точка.
     * @return Признак попадания точки в прямоугольник.
     */
    public boolean contains(BasePoint2D p) {
//		return clone().rotate(-angle).getBounds().containsPoint(new SignPoint2D(p).rotate(-angle));

        // Угол прямоугольника.
        double rx = tlP.getX();
        double ry = tlP.getY();

        // Точка в с.к. с центром в угле прямоугольника.
        double px = p.getX() - rx;
        double py = p.getY() - ry;

        // Синус и косинус угла прямоугольника.
        double s = Math.sin(angle);
        double c = Math.cos(angle);

        // Точка в с.к. прямоугольника.
        // Поворот на -angle. Поэтому синус для rpx взят с +, а для rpy с -.
        double rpx = px * c + py * s;
        double rpy = px * -s + py * c;

        // Проверяем попадание во фрейм в ск.к прямоугольника.
        return (rpx >= 0 && rpx <= width || rpx >= width && rpx <= 0) && (rpy >= 0 && rpy <= height || rpy >= height && rpy <= 0);
    }
}