package vg.geometry.cp;


import vg.geometry.primitives.BasePoint2D;

/**
 * Absolute point.
 */

public class AbsoluteCPoint extends AbstractCPoint {

    /***/
    private static final long serialVersionUID = -4300120369078084930L;


    /**
     * Абсолютная точка с нулевыми координатами.
     */
    public AbsoluteCPoint() {
    }

    /**
     * @param x Координата X.
     * @param y Координата Y.
     */
    public AbsoluteCPoint(double x, double y) {
        super(x, y);
    }

    /**
     * @param p Координаты.
     */
    public AbsoluteCPoint(BasePoint2D p) {
        super(p);
    }


    @Override
    public AbsoluteCPoint clone() {
        AbsoluteCPoint clonedObject = (AbsoluteCPoint) super.clone();
        return clonedObject;
    }


    @Override
    public CPoint calculate() {
        return this;
    }

    @Override
    public CPoint decalculate() {
        return this;
    }

}
