package vg.geometry.cp;


import vg.geometry.primitives.BasePoint2D;

import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Reference to calculated point
 */

public abstract class AbstractCPointReference implements CPoint {

    /**
     * Список зависимостей ссылочной точки.
     */
    private class SelfDependenciesSet extends AbstractSet<CPoint> {

        /**
         * Итератор по точке-зависимости.
         */
        private class SelfIterator implements Iterator<CPoint> {
            /**
             * Следующий элемент.
             */
            CPoint next = getReferent();

            /***/
            public SelfIterator() {
            }

            @Override
            public boolean hasNext() {
                return next != null;
            }

            @Override
            public CPoint next() {
                CPoint returnValue = next;
                next = null;
                return returnValue;
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }

        }

        /***/
        public SelfDependenciesSet() {
        }

        @Override
        public Iterator<CPoint> iterator() {
            return new SelfIterator();
        }

        @Override
        public int size() {
            return getReferent() == null ? 0 : 1;
        }

    }


    /**  */
    private static final long serialVersionUID = -413362075319416313L;

    /**
     * Список зависимостей.
     */
    private SelfDependenciesSet dependencies = new SelfDependenciesSet();


    /**
     * Получить точку, на которую ссылается данная.
     *
     * @return Точка, на которую ссылается данная.
     */
    public abstract CPoint getReferent();


    @Override
    public AbstractCPointReference clone() {
        try {
            AbstractCPointReference clonedObject = (AbstractCPointReference) super.clone();
            return clonedObject;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }


    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof AbstractCPoint))
            return false;
        AbstractCPointReference other = (AbstractCPointReference) obj;

        CPoint referent = getReferent();
        CPoint otherReferent = other.getReferent();
        return (referent != null ? referent.equals(otherReferent) : otherReferent == null);
    }

    @Override
    public boolean equals(BasePoint2D p) {
        return getReferent().equals(p);
    }

    @Override
    public int hashCode() {
        int result = 61521;
        result ^= getReferent().hashCode();
        return result;
    }


    @Override
    public double getX() {
        return getReferent().getX();
    }

    @Override
    public void setX(double x) {
        getReferent().setX(x);
    }

    @Override
    public double getY() {
        return getReferent().getY();
    }

    @Override
    public void setY(double y) {
        getReferent().setY(y);
    }

    @Override
    public CPoint calculate() {
        getReferent().calculate();
        return this;
    }

    @Override
    public CPoint decalculate() {
        getReferent().decalculate();
        return this;
    }

    @Override
    public Set<CPoint> getDependencies() {
        return dependencies;
    }

}
