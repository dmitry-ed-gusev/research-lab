package vg.geometry.primitives;

import vg.geometry.ITransformable;

import java.util.Arrays;

/**
 * Матрица аффинных преобразований на плоскости (матричный оператор):
 * <pre>
 * [xx, yx, tx,
 *  xy, yy, ty,
 *  0,  0,  1]
 * </pre>
 * <p>
 * <p>(xx, xy) - координаты новой оси X
 * <p>(yx, yy) - координаты новой оси Y
 * <p>(tx, ty) - координаты нового центра
 * Класс неизменяемый (immutable). Ни один из методов не изменяет внутреннего состояния класса.
 * Класс также является null-safe - корректно обрабатываются объекты-параметры типа null, при
 * получении такого параметра возвращается значение по умолчанию (матрица или точка соответственно
 * методу).
 */

public class BaseMatrix2D implements ITransformable<BaseMatrix2D> {

    /**
     * Механизм сериализации.
     */
    private static final long serialVersionUID = -4113218471444611472L;
    // размерность матрицы (длина массива)
    private static final int MATRIX_SIZE = 6;

    /**
     * Непосредственно матрица.
     */
    private double[] matrix;

    /**
     * Создание матрицы трансформирования.
     *
     * @param xx Координата x новой оси x.
     * @param yx Координата y новой оси x.
     * @param xy Координата x новой оси y.
     * @param yy Координата y новой оси y.
     * @param tx Координата x центра.
     * @param ty Координата y центра.
     */
    public BaseMatrix2D(double xx, double yx, double tx, double xy, double yy, double ty) {
        this.matrix = new double[]{xx, yx, tx, xy, yy, ty};
    }

    /**
     * Создание единичной матрицы (матрицы по умолчанию) трансформирования.
     */
    public BaseMatrix2D() {
        this.matrix = new double[]{1.0, 0.0, 0.0, 0.0, 1.0, 0.0};
    }

    /**
     * Копирующий конструктор для создания матрицы трансформирования на основе массива.
     *
     * @param matrix Матрица, по которой трансформируется эта матрица. Если она пуста (NULL) или
     */
    public BaseMatrix2D(double[] matrix) {
        this.matrix = new double[MATRIX_SIZE];
        if (matrix != null && matrix.length == MATRIX_SIZE) { // если аргумент ок - инициализация
            System.arraycopy(matrix, 0, this.matrix, 0, MATRIX_SIZE);
        }
    }

    /**
     * Копирующий конструктор для создания матрицы трансформирования на основе другой матрицы.
     *
     * @param matrix Матрица, по которой трансформируется эта матрица.
     */
    public BaseMatrix2D(BaseMatrix2D matrix) {
        this.matrix = new double[MATRIX_SIZE];
        if (matrix != null) {
            System.arraycopy(matrix.getMatrix(), 0, this.matrix, 0, MATRIX_SIZE);
        }
    }

    /**
     * Получение элементов матрицы. Метод возвращает копию внутреннего массива матрицы.
     *
     * @return double[] копия содержимого матрицы.
     */
    public double[] getMatrix() {
        double[] matrix = new double[MATRIX_SIZE];
        System.arraycopy(this.matrix, 0, matrix, 0, MATRIX_SIZE);
        return matrix;
    }


    @Override
    public String toString() {
        return Arrays.toString(this.matrix);
    }

    /**
     * Переместить матрицу.
     *
     * @param x Смещение по X.
     * @param y Смещение по Y.
     * @return Эта матрица.
     */
    @Override
    public BaseMatrix2D translate(double x, double y) {
        double[] matrix = this.getMatrix();
        matrix[2] += x;
        matrix[5] += y;
        return new BaseMatrix2D(matrix);
    }

    /**
     * Переместить матрицу.
     *
     * @param p Смещение.
     * @return Эта матрица.
     */
    //@Override
    public BaseMatrix2D translate(BasePoint2D p) {
        BaseMatrix2D result;
        if (p != null) {
            result = this.translate(p.getX(), p.getY());
        } else {
            result = new BaseMatrix2D();
        }
        return result;
    }

    /**
     * Масштабировать матрицу относительно точки.
     *
     * @param kx Коэффициент масштабирования по оси OX.
     * @param ky Коэффициент масштабирования по оси OY.
     * @param cx Координата X центра масштабирования.
     * @param cy Координата Y центра масштабирования.
     * @return Эта матрица.
     */
    @Override
    public BaseMatrix2D scale(double kx, double ky, double cx, double cy) {
        double[] matrix = this.getMatrix();
        matrix[0] *= kx;
        matrix[1] *= kx;
        matrix[2] = matrix[2] * kx + cx * (1 - kx);
        matrix[3] *= ky;
        matrix[4] *= ky;
        matrix[5] = matrix[5] * ky + cy * (1 - ky);
        return new BaseMatrix2D(matrix);
    }

    /**
     * Масштабировать матрицу относительно точки.
     *
     * @param k Коэффициент масштабирования.
     * @param c Центр масштабирования.
     * @return Эта матрица.
     */
    //@Override
    public BaseMatrix2D scale(BasePoint2D k, BasePoint2D c) {
        BaseMatrix2D result;
        if (k != null && c != null) {
            result = this.scale(k.getX(), k.getY(), c.getX(), c.getY());
        } else {
            result = new BaseMatrix2D();
        }
        return result;
    }

    /**
     * Масштабировать матрицу относительно точки.
     *
     * @param k  Коэффициент масштабирования.
     * @param cx Координата X центра масштабирования.
     * @param cy Координата Y центра масштабирования.
     * @return Эта матрица.
     */
    //@Override
    //public BaseMatrix2D scale(double k, double cx, double cy) {
    //    return this.scale(k, k, cx, cy);
    //}

    /**
     * Масштабировать матрицу относительно точки.
     *
     * @param k Коэффициент масштабирования.
     * @return Эта матрица.
     */
    //@Override
    public BaseMatrix2D scale(double k, BasePoint2D c) {
        BaseMatrix2D result;
        if (c != null) {
            result = this.scale(k, k, c.getX(), c.getY());
        } else {
            result = new BaseMatrix2D();
        }
        return result;
    }

    /**
     * Масштабировать матрицу.
     *
     * @param kx Коэффициент масштабирования по оси OX.
     * @param ky Коэффициент масштабирования по оси OY.
     * @return Эта матрица.
     */
    //@Override
    //public BaseMatrix2D scale(double kx, double ky) {
    //    return this.scale(kx, ky, 0, 0);
    //}

    /**
     * Масштабировать матрицу.
     *
     * @param k Коэффициент масштабирования.
     * @return Эта матрица.
     */
    //@Override
    /*
    public BaseMatrix2D scale(BasePoint2D k) {
        BaseMatrix2D result;
        if (k != null) {
            result = this.scale(k.getX(), k.getY());
        } else {
            result = new BaseMatrix2D();
        }
        return result;
    }
    */

    /**
     * Масштабировать матрицу.
     *
     * @param k Коэффициент масштабирования.
     * @return Эта матрица.
     */
    //@Override
    //public BaseMatrix2D scale(double k) {
    //    return this.scale(k, k);
    //}

    /**
     * Повернуть матрицу относительно точки.
     *
     * @param a  Угол поворота.
     * @param cx Координата X центра вращения.
     * @param cy Координата Y центра вращения.
     * @return Эта матрица.
     */
    @Override
    public BaseMatrix2D rotate(double a, double cx, double cy) {
        double s = Math.sin(a);
        double c = Math.cos(a);
        // берем текущую матрицу
        double[] matrix = this.getMatrix();
        double xx = matrix[0];
        double yx = matrix[1];
        double tx = matrix[2];
        double xy = matrix[3];
        double yy = matrix[4];
        double ty = matrix[5];
        // выполняем преобразования
        matrix[0] = xx * c - xy * s;
        matrix[1] = yx * c - yy * s;
        matrix[2] = tx * c - ty * s + cy * s + cx * (1 - c);
        matrix[3] = xx * s + xy * c;
        matrix[4] = yx * s + yy * c;
        matrix[5] = tx * s + ty * c - cx * s + cy * (1 - c);
        // результат
        return new BaseMatrix2D(matrix);
    }

    /**
     * Повернуть матрицу относительно точки.
     *
     * @param a  Угол поворота.
     * @param cp Центр вращения.
     * @return Эта матрица.
     */
    //@Override
    public BaseMatrix2D rotate(double a, BasePoint2D cp) {
        BaseMatrix2D result;
        if (cp != null) {
            result = this.rotate(a, cp.getX(), cp.getY());
        } else {
            result = new BaseMatrix2D();
        }
        return result;
    }

    /**
     * Повернуть матрицу.
     *
     * @param a Угол поворота.
     * @return Эта матрица.
     */
    //@Override
    //public BaseMatrix2D rotate(double a) {
    //    return this.rotate(a, 0, 0);
    //}

    /**
     * Трансформировать матрицу.
     *
     * @param t Оператор.
     * @return Эта матрица.
     */
   // @Override
    public BaseMatrix2D transform(BaseMatrix2D t) {
        BaseMatrix2D result;

        if (t != null) {
            // берем матрицу-параметр
            double[] tmatrix = t.getMatrix();
            double txx = tmatrix[0];
            double tyx = tmatrix[1];
            double ttx = tmatrix[2];
            double txy = tmatrix[3];
            double tyy = tmatrix[4];
            double tty = tmatrix[5];
            // берем текущую матрицу
            double[] matrix = this.getMatrix();
            double xx = matrix[0];
            double yx = matrix[1];
            double tx = matrix[2];
            double xy = matrix[3];
            double yy = matrix[4];
            double ty = matrix[5];
            // выполняем преобразования
            matrix[0] = xx * txx + xy * tyx;
            matrix[1] = yx * txx + yy * tyx;
            matrix[2] = tx * txx + ty * tyx + ttx;
            matrix[3] = xx * txy + xy * tyy;
            matrix[4] = yx * txy + yy * tyy;
            matrix[5] = tx * txy + ty * tyy + tty;
            // результат
            result = new BaseMatrix2D(matrix);
        } else {
            result = new BaseMatrix2D();
        }
        return result;
    }

    /**
     * Инвертировать матрицу.
     *
     * @return Эта матрица.
     */
    public BaseMatrix2D invert() {
        // берем текущую матрицу
        double[] matrix = this.getMatrix();
        double xx = matrix[0];
        double yx = matrix[1];
        double tx = matrix[2];
        double xy = matrix[3];
        double yy = matrix[4];
        double ty = matrix[5];
        // выполняем преобразования
        double idet = 1.0 / (xx * yy - yx * xy);
        matrix[0] = yy * idet;
        matrix[1] = -yx * idet;
        matrix[2] = (yx * ty - tx * yy) * idet;
        matrix[3] = -xy * idet;
        matrix[4] = xx * idet;
        matrix[5] = -(xx * ty - tx * xy) * idet;
        // возвращаем результат
        return new BaseMatrix2D(matrix);
    }

    /**
     * Трансформация точки.
     *
     * @param point Точка (не меняется).
     * @return Новая точка.
     */
    public BasePoint2D transformPoint(BasePoint2D point) {
        BasePoint2D result;
        if (point != null) {
            double x = point.getX();
            double y = point.getY();
            result = new BasePoint2D(x * matrix[0] + y * matrix[1] + matrix[2], x * matrix[3] + y * matrix[4] + matrix[5]);
        } else {
            result = new BasePoint2D();
        }
        return result;
    }

    /**
     * Трансформация размера.
     * <p>transformSize(s) = transformPoint(s) - transformPoint((0; 0)).
     *
     * @param size Размер (не меняется)
     * @return Новый размер.
     */
    public BasePoint2D transformSize(BasePoint2D size) {
        BasePoint2D result;
        if (size != null) {
            double x = size.getX();
            double y = size.getY();
            result = new BasePoint2D(x * matrix[0] + y * matrix[1], x * matrix[3] + y * matrix[4]);
        } else {
            result = new BasePoint2D();
        }
        return result;
    }

}