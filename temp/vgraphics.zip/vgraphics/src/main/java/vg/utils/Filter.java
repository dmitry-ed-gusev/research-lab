package vg.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Фильтры объектов. Данную функциональность используют компоненты ЭУЗ/БЭУЗ.
 *
 * @param <T> Тип объекта.
 */
public interface Filter<T> {

    /**
     * Вспомогательные функции.
     *
     */
    public static class Utils {

        /**
         * Выбрать из коллекции все элементы, удовлетворяющие фильтру.
         *
         * @param filter Фильтр.
         * @param list   Коллекция элементов.
         * @return Элементы коллекции, удовлетворяющие фильтру.
         */
        public static <T> List<T> selectAll(Filter<T> filter, Collection<T> list) {
            List<T> selected = new ArrayList<T>();
            for (T element : list)
                if (filter.filter(element))
                    selected.add(element);
            return selected;
        }

        /**
         * Выбрать из коллекции первый элемент, удовлетворяющий фильтру.
         *
         * @param filter Фильтр.
         * @param list   Коллекция элементов.
         * @return Первый элементы коллекции, удовлетворяющий фильтру.
         */
        public static <T> T selectFirst(Filter<T> filter, Collection<T> list) {
            for (T element : list)
                if (filter.filter(element))
                    return element;
            return null;
        }

        /**
         * Выбрать из коллекции последний элемент, удовлетворяющий фильтру.
         *
         * @param filter Фильтр.
         * @param list   Коллекция элементов.
         * @return Последний элементы коллекции, удовлетворяющий фильтру.
         */
        public static <T> T selectLast(Filter<T> filter, Collection<T> list) {
            T selected = null;
            for (T element : list)
                if (filter.filter(element))
                    selected = element;
            return selected;
        }

    }


    /**
     * True.
     */
    @SuppressWarnings("rawtypes")
    public static final True TRUE = new True<Object>();

    /**
     * False.
     */
    @SuppressWarnings("rawtypes")
    public static final False FALSE = new False<Object>();


    /**
     * Групповой фильтр.
     *
     * @param <T> Тип объекта.
     */
    public abstract static class Group<T> implements Filter<T> {
        /**
         * Список фильтров группы.
         */
        protected List<Filter<? super T>> filters = new ArrayList<Filter<? super T>>();
        /**
         * Значение по умолчанию, которое используется, если список фильтров пуст.
         */
        protected boolean initial = false;

        /**
         * @param filters Фильтры.
         */
        public Group(Filter<? super T>... filters) {
            for (Filter<? super T> f : filters)
                this.filters.add(f);
        }

        /**
         * @param filters Фильтры.
         */
        public Group(Collection<? extends Filter<? super T>> filters) {
            this.filters.addAll(filters);
        }

        /**
         * Получить фильтр по индексу.
         *
         * @param index Индекс фильтра.
         * @return Фильтр.
         */
        public Filter<? super T> getFilter(int index) {
            return filters.get(index);
        }

        /**
         * Установить фильтр по индексу.
         *
         * @param index  Индекс.
         * @param filter Фильтр.
         * @return Старый фильтр по индексу.
         */
        public Filter<? super T> setFilter(int index, Filter<? super T> filter) {
            return filters.set(index, filter);
        }

        /**
         * Добавить фильтр в конец.
         *
         * @param filter Фильтр.
         */
        public void addFilter(Filter<? super T> filter) {
            filters.add(filter);
        }

        /**
         * Добавить фильтр по индексу.
         *
         * @param index  Индекс.
         * @param filter Фильтр.
         */
        public void addFilter(int index, Filter<? super T> filter) {
            filters.add(index, filter);
        }

        /**
         * Удалить фильтр.
         *
         * @param filter Фильтр.
         */
        public void removeFilter(Filter<? super T> filter) {
            filters.remove(filter);
        }

        /**
         * Удалить фильтр по индексу.
         *
         * @param index Индекс.
         * @return Удалёный фильтр.
         */
        public Filter<? super T> removeFilter(int index) {
            return filters.remove(index);
        }

        /**
         * Очистить список фильтров.
         */
        public void clear() {
            filters.clear();
        }

        /**
         * Получить число фильтров в списке.
         *
         * @return Число фильтров.
         */
        public int getNumberOfFilters() {
            return filters.size();
        }

        /**
         * Получить значение по умолчанию, которое используется, если фильтров нет.
         *
         * @return Значение по умолчанию.
         */
        public boolean getInitial() {
            return initial;
        }

        /**
         * Установить значение по умолчанию, которое используется, если фильтров нет.
         *
         * @param initial Значение по умолчанию.
         */
        public void setInitial(boolean initial) {
            this.initial = initial;
        }
    }

    /**
     * Константа ИСТИНА.
     *
     * @param <T> Тип объекта.
     */
    public static class True<T> implements Filter<T> {
        @Override
        public <OT extends T> boolean filter(OT object) {
            return true;
        }

        ;
    }

    /**
     * Константа ЛОЖЬ.
     *
     * @param <T> Тип объекта.
     */
    public static class False<T> implements Filter<T> {
        @Override
        public <OT extends T> boolean filter(OT object) {
            return false;
        }

        ;
    }

    /**
     * Логическое НЕ(x).
     *
     * @param <T> Тип объекта.
     */
    public static class Not<T> implements Filter<T> {
        /**
         * Инвертируемый фильтр.
         */
        private Filter<? super T> filter;

        /**
         * @param filter Фильтр.
         */
        public Not(Filter<? super T> filter) {
            this.filter = filter;
        }

        @Override
        public <OT extends T> boolean filter(OT object) {
            return filter != null ? !filter.filter(object) : false;
        }

        /**
         * Получить фильтр.
         *
         * @return Фильтр.
         */
        public Filter<? super T> getFilter() {
            return filter;
        }

        /**
         * Установить фильтр.
         *
         * @param filter Фильтр.
         */
        public void setFilter(Filter<? super T> filter) {
            this.filter = filter;
        }
    }

    /**
     * Логическое ИЛИ([x]).
     *
     * @param <T> Тип объекта.
     */
    public static class Or<T> extends Group<T> {
        /**
         * @param filters Фильтры.
         */
        public Or(Filter<? super T>... filters) {
            super(filters);
        }

        /**
         * @param filters Фильтры.
         */
        public Or(Collection<? extends Filter<? super T>> filters) {
            super(filters);
        }

        @Override
        public <OT extends T> boolean filter(OT object) {
            if (filters.isEmpty())
                return initial;
            for (Filter<? super T> f : filters)
                if (f.filter(object))
                    return true;
            return false;
        }

        ;
    }

    /**
     * Логическое И([x]).
     *
     * @param <T> Тип объекта.
     */
    public static class And<T> extends Group<T> {
        /**
         * @param filters Фильтры.
         */
        public And(Filter<? super T>... filters) {
            super(filters);
        }

        /**
         * @param filters Фильтры.
         */
        public And(Collection<? extends Filter<? super T>> filters) {
            super(filters);
        }

        @Override
        public <OT extends T> boolean filter(OT object) {
            if (filters.isEmpty())
                return initial;
            for (Filter<? super T> f : filters)
                if (!f.filter(object))
                    return false;
            return true;
        }

        ;
    }

    /**
     * Исключающее ИСКЛ.ИЛИ([x]).
     *
     * @param <T> Тип объекта.
     */
    public static class Xor<T> extends Group<T> {
        /**
         * @param filters Фильтры.
         */
        public Xor(Filter<? super T>... filters) {
            super(filters);
        }

        /**
         * @param filters Фильтры.
         */
        public Xor(Collection<? extends Filter<? super T>> filters) {
            super(filters);
        }

        @Override
        public <OT extends T> boolean filter(OT object) {
            if (filters.isEmpty())
                return initial;
            boolean result = false;
            for (Filter<? super T> f : filters)
                result = f.filter(object) != result;
            return result;
        }

        ;
    }

    /**
     * Логическое НЕ(ИЛИ([x])).
     *
     * @param <T> Тип объекта.
     */
    public static class Nor<T> extends Group<T> {
        /**
         * @param filters Фильтры.
         */
        public Nor(Filter<? super T>... filters) {
            super(filters);
        }

        /**
         * @param filters Фильтры.
         */
        public Nor(Collection<? extends Filter<? super T>> filters) {
            super(filters);
        }

        @Override
        public <OT extends T> boolean filter(OT object) {
            if (filters.isEmpty())
                return initial;
            for (Filter<? super T> f : filters)
                if (f.filter(object))
                    return false;
            return true;
        }

        ;
    }

    /**
     * Логическое НЕ(И([x])).
     *
     * @param <T> Тип объекта.
     */
    public static class Nand<T> extends Group<T> {
        /**
         * @param filters Фильтры.
         */
        public Nand(Filter<? super T>... filters) {
            super(filters);
        }

        /**
         * @param filters Фильтры.
         */
        public Nand(Collection<? extends Filter<? super T>> filters) {
            super(filters);
        }

        @Override
        public <OT extends T> boolean filter(OT object) {
            if (filters.isEmpty())
                return initial;
            for (Filter<? super T> f : filters)
                if (!f.filter(object))
                    return true;
            return false;
        }

        ;
    }

    /**
     * Ссылка.
     *
     * @param <T> Тип объекта.
     */
    public static class Ref<T> implements Filter<T> {
        /**
         * Фильтр, на который ссылается данный фильтр.
         */
        protected Filter<? super T> filter;
        /**
         * Значение по умолчанию, которое возвращается, если фильтр-референт не задан.
         */
        protected boolean initial;

        /**
         * @param filter Фильтр.
         */
        public Ref(Filter<? super T> filter) {
            this(filter, false);
        }

        /**
         * @param filter  Фильтр.
         * @param initial Значение по умолчанию.
         */
        public Ref(Filter<? super T> filter, boolean initial) {
            this.filter = filter;
            this.initial = initial;
        }

        /**
         * Получить фильтр.
         *
         * @return Фильтр.
         */
        public Filter<? super T> getFilter() {
            return filter;
        }

        /**
         * Установить фильтр.
         *
         * @param filter Фильтр.
         */
        public void setFilter(Filter<? super T> filter) {
            this.filter = filter;
        }

        /**
         * Получить значение по умолчанию.
         *
         * @return Значение по умолчанию.
         */
        public boolean getInitial() {
            return initial;
        }

        /**
         * Задать значение по умолчанию.
         *
         * @param initial Значение по умолчанию.
         */
        public void setInitial(boolean initial) {
            this.initial = initial;
        }

        @Override
        public <OT extends T> boolean filter(OT object) {
            return filter != null ? filter.filter(object) : initial;
        }

        ;
    }


    /**
     * Проверка, удовлетворяет ли объект фильтру.
     *
     * @param <OT>   Тип объекта.
     * @param object Объект.
     * @return Признак того, что объект удовлетворяет фильтру.
     */
    public <OT extends T> boolean filter(OT object);

}