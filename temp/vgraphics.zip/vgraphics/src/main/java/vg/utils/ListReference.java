package vg.utils;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

/**
 * Список ссылок различного типа. Список типизированный (generic).
 * В основе списка лежит коллекция ArrayList.
 *
 * @param <E> Тип элементов списка.
 */
// TODO сделать класс immutable???
// todo: unnecessary class !!!

public class ListReference<E> extends AbstractList<E> {

    /**
     * Список.
     */
    private List<E> list;
    /**
     * Редактируемость списка.
     */
    private boolean editable;

    /** */
    public ListReference() {
        this(new ArrayList<E>());
    }

    /**
     * @param list     Список.
     * @param editable Возможность редактирования списка.
     */
    public ListReference(List<E> list, boolean editable) {
        this.list = list;
        this.editable = editable;
    }

    /**
     * @param list Список с возможностью редактирования.
     */
    public ListReference(List<E> list) {
        this(list, true);
    }

    /**
     * Получить список.
     *
     * @return Список.
     */
    public List<E> getList() {
        return list;
    }

    /**
     * Проверка на возможность редактирования.
     *
     * @return Возможность редактирования списка.
     */
    public boolean isReadOnly() {
        return editable;
    }

    @Override
    public E get(int index) {
        return list.get(index);
    }

    @Override
    public int size() {
        return list.size();
    }

    @Override
    public void add(int index, E element) {
        if (editable)
            list.add(index, element);
    }

    ;

    @Override
    public E set(int index, E element) {
        if (editable)
            return list.set(index, element);
        else
            return null;
    }

    ;

    @Override
    public E remove(int index) {
        if (editable)
            return list.remove(index);
        else
            return null;
    }

    @Override
    public void clear() {
        if (editable)
            list.clear();
    }

}
