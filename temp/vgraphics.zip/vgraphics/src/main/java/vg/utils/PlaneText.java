package vg.utils;

import org.apache.log4j.Logger;
import vg.geometry.GeometryDefaults;
import vg.geometry.GeometryUtils;

import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.font.LineMetrics;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static vg.geometry.GeometryDefaults.RE_LINE_SEPARATOR;

/**
 * Класс для расчёта метрик многострочный текста.
 * <p>Текст имеет свою внутреннюю точку отсчёта
 * и в зависимости от выравнивания он может располагаться слева от неё, справа, сверху или посередине.
 * Если установлено выравнивание по левому краю, то точка будет слева от текста,
 * если по правому, то справа, если по центру, то в центре.
 * Аналогично и для выравнивания по-вертикали.
 * <p>После задания параметров текста (шрифт, выравнивание и др.) необходимо вызвать его обсчёт методом calculate().
 *
 */
public final class PlaneText implements Cloneable, Serializable {

    /**
     * Параметры строки текста.
     *
     */
    public static final class Line implements Cloneable, Serializable {

        /**  */
        private static final long serialVersionUID = -7248976393144143794L;

        /**
         * Текст строки.
         */
        private String text;
        /**
         * Габариты строки.
         */
        private Rectangle2D bounds;


        /** */
        protected Line() {
        }

        /**
         * @param text   Текст строки.
         * @param bounds Габариты строки.
         */
        protected Line(String text, Rectangle2D bounds) {
            this.text = text;
            this.bounds = bounds;
        }


        @Override
        public PlaneText.Line clone() {
            try {
                PlaneText.Line clone = (PlaneText.Line) super.clone();
                clone.bounds = (Rectangle2D) bounds.clone();
                return clone;
            } catch (CloneNotSupportedException ex) {
                throw new RuntimeException(ex);
            }
        }

        /**
         * Получить текст строки.
         *
         * @return Текст строки.
         */
        public String getText() {
            return text;
        }

        /**
         * Получить габариты строки.
         *
         * @return Габариты строки.
         */
        public Rectangle2D getBounds() {
            return bounds;
        }

        /**
         * Проверка на попадание точки в строку.
         *
         * @param x Координата X.
         * @param y Координата Y.
         * @return Признак попадания точки в строку.
         */
        public boolean containsPoint(double x, double y) {
            return GeometryUtils.isIn(x, bounds.getMinX(), bounds.getMaxX())
                    && GeometryUtils.isIn(y, bounds.getMinY(), bounds.getMaxY());
        }

    }

    /**  */
    private static final long serialVersionUID = 7365900074667430433L;

    /**
     * Многострочный текст.
     */
    private String text;
    /**
     * Шрифт.
     */
    private Font font;
    /**
     * Контекст рендеринга шрифтов.
     */
    private transient FontRenderContext fontRenderContext;
    /**
     * Горизонтальное выравнивание.
     */
    private GeometryDefaults.ElementHAlignment hAlignment;
    /**
     * Вертикальное выравнивание.
     */
    private GeometryDefaults.ElementVAlignment vAlignment;

    /**
     * Строки текста.
     */
    private List<Line> lines = new ArrayList<Line>();
    /**
     * Метрики шрифта.
     */
    private transient LineMetrics metrics;
    /**
     * Габариты всего текста.
     */
    private Rectangle2D bounds;


    /** */
    public PlaneText() {
        this(null, null, null, null);
    }

    /**
     * @param text       Многострочный текст.
     * @param font       Шрифт.
     * @param hAlignment Горизонтальное выравнивание.
     * @param vAlignment Вертикальное выравнивание.
     */
    public PlaneText(String text, Font font, GeometryDefaults.ElementHAlignment hAlignment, GeometryDefaults.ElementVAlignment vAlignment) {
        init(text, font, hAlignment, vAlignment);
    }


    @Override
    public PlaneText clone() {
        try {
            PlaneText clone = (PlaneText) super.clone();

            // Клонируем строки.
            clone.lines = new ArrayList<PlaneText.Line>();
            for (Line l : lines)
                clone.lines.add(l.clone());

            // Клонируем габариты.
            clone.bounds = bounds != null ? (Rectangle2D) bounds.clone() : null;

            return clone;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }


    /**
     * Инициализация параметров текста.
     *
     * @param text       Текст.
     * @param font       Шрифт.
     * @param hAlignment Горизонтальное выравнивание.
     * @param vAlignment Вертикальное выравнивание.
     */
    public void init(String text, Font font, GeometryDefaults.ElementHAlignment hAlignment, GeometryDefaults.ElementVAlignment vAlignment) {
        this.text = text;
        this.font = font;
        this.hAlignment = hAlignment;
        this.vAlignment = vAlignment;
    }

    /**
     * Получение текста.
     *
     * @return Текст.
     */
    public String getText() {
        return text;
    }

    /**
     * Задание текста.
     *
     * @param text Текст.
     */
    public void setText(String text) {
        this.text = text;
    }

    /**
     * Получение шрифта.
     *
     * @return Шрифт.
     */
    public Font getFont() {
        return font;
    }

    /**
     * Задание шрифта.
     *
     * @param font Шрифт.
     */
    public void setFont(Font font) {
        this.font = font;
    }

    /**
     * Получение контекста рендеринга шрифтов.
     *
     * @return Контекст рендеринга шрифтов.
     */
    public FontRenderContext getFontRenderContext() {
        return fontRenderContext;
    }

    /**
     * Задание контекста рендеринга шрифтов.
     *
     * @param fontRenderContext Контекст рендеринга шрифтов.
     */
    public void setFontRenderContext(FontRenderContext fontRenderContext) {
        this.fontRenderContext = fontRenderContext;
    }

    /**
     * Получение горизонтального выравнивания.
     *
     * @return Горизонтальное выравнивание.
     */
    public GeometryDefaults.ElementHAlignment getHAlign() {
        return hAlignment;
    }

    /**
     * Задание горизонтального выравнивания.
     *
     * @param hAlignment Горизонтального выравнивание.
     */
    public void setHAlign(GeometryDefaults.ElementHAlignment hAlignment) {
        this.hAlignment = hAlignment;
    }

    /**
     * Получение вертикального выравнивания.
     *
     * @return Вертикальное выравнивание.
     */
    public GeometryDefaults.ElementVAlignment getVAlign() {
        return vAlignment;
    }

    /**
     * Задание вертикального выравнивания.
     *
     * @param vAlignment Вертикальное выравнивание.
     */
    public void setVAlign(GeometryDefaults.ElementVAlignment vAlignment) {
        this.vAlignment = vAlignment;
    }


    /**
     * Получение строк текста.
     *
     * @return Строки текста.
     */
    public List<Line> getLines() {
        return lines;
    }

    /**
     * Получение габаритов текста.
     *
     * @return Габариты текста.
     */
    public Rectangle2D getBounds() {
        return bounds;
    }


    /**
     * Получение нижнего выпуска символов.
     * <p>Это расстояние между нижней границей строки и базовой линией (для романских алфавитов).
     *
     * @return Нижний выпуск символов.
     */
    public double getDescent() {
        if (metrics == null)
            return 0.0;
        return metrics.getDescent();
    }

    /**
     * Получение верхнего выпуска символов.
     * <p>Это расстояние между базовой линией и верхней кромки заглавных букв и цифр.
     *
     * @return Верхний выпуск.
     */
    public double getAscent() {
        if (metrics == null)
            return 0.0;
        return metrics.getAscent();
    }

    /**
     * Получение отступа строк.
     * <p>Это рекомендуемое расстояние между верхней кромкой заглавных букв и нижней кромкой предыдущей строки.
     * Это рекомендуемое расстояние между строками, а также пространство, где располагаются надстрочные символы.
     *
     * @return Отступ строк.
     */
    public double getLeading() {
        if (metrics == null)
            return 0.0;
        return metrics.getLeading();
    }

    /**
     * Получение смещения линии зачёркивания относительно базовой линии.
     *
     * @return Смещение линии зачёркивания.
     */
    public double getStrikethroughOffset() {
        if (metrics == null)
            return 0.0;
        return metrics.getStrikethroughOffset();
    }

    /**
     * Получение смещения линии подчёркивания относительно базовой линии.
     *
     * @return Смещение линии подчёркивания.
     */
    public double getUnderlineOffset() {
        if (metrics == null)
            return 0.0;
        return metrics.getUnderlineOffset();
    }

    /**
     * Получение смещения линии надчёркивания относительно базовой линии.
     *
     * @return Смещение линии надчёркивания.
     */
    public double getOverlineOffset() {
        if (metrics == null)
            return 0.0;
        return getUnderlineOffset() - getAscent();
    }

    /**
     * Получение толщины линий подчёркивания, зачёркивания и надчёркивания.
     *
     * @return Толщина линий подчёркивания, зачёркивания и надчёркивания.
     */
    public double getLineThickness() {
        return metrics.getUnderlineThickness();
    }


    /**
     * Общёт текста.
     */
    public void calculate() {
        // Обнуляем данные.
        lines.clear();
        metrics = null;
        bounds = null;

        // Проверям исходные данные.
        if (text == null || font == null || hAlignment == null || vAlignment == null) {
            Logger.getLogger(PlaneText.class).warn("No input data.");
            return;
        }

        // Формируем рендерер шрифтов.
        if (fontRenderContext == null)
            fontRenderContext = new FontRenderContext(new AffineTransform(), true, true);

        // получаем метрику строк текста.
        metrics = font.getLineMetrics("Šj", fontRenderContext);

        // Разбиваем исходный текст на строки.
        String[] linesTextes = text.split(RE_LINE_SEPARATOR);

        // Расчитываем габариты текста.
        Rectangle2D[] linesBounds = new Rectangle2D[linesTextes.length];
        double textWidth = 0.0;
        double textHeight = 0.0;
        for (int i = 0; i < linesTextes.length; i++) {
            String lineText = linesTextes[i];
            Rectangle2D lineBounds = font.getStringBounds(lineText, fontRenderContext);
            linesBounds[i] = lineBounds;
            textWidth = Math.max(textWidth, lineBounds.getWidth());
            textHeight += lineBounds.getHeight();
        }
        bounds = alignTextBounds(textWidth, textHeight);

        // Расчитываем строки.
        for (int i = 0; i < linesTextes.length; i++) {
            String lineText = linesTextes[i];
            Rectangle2D lineBounds = linesBounds[i];
            lineBounds = alingLineBounds(lineBounds.getWidth(), lineBounds.getHeight(), i);
            lines.add(new Line(lineText, lineBounds));
        }
    }

    /**
     * Расчитать рамку всего текста по габаритам и выравниванию.
     *
     * @param width  Ширина текста.
     * @param height Высота текста.
     * @return Рамка текста.
     */
    private Rectangle2D alignTextBounds(double width, double height) {
        Point2D ra = getRelativeAnchor();
        double x = ra.getX() * (-width);
        double y = ra.getY() * (-height);
        return new Rectangle2D.Double(x, y, width, height);
    }

    /**
     * Расчитать рамку строки по её габаритам, индексу и выравниванию.
     *
     * @param width     Ширина строки.
     * @param height    Высота строки.
     * @param lineIndex Индекс строки.
     * @return Габариты строки.
     */
    private Rectangle2D alingLineBounds(double width, double height, int lineIndex) {
        double x = 0.0;
        double y = 0.0;
        switch (hAlignment) {
            case LEFT:
                x = 0.0;
                break;
            case RIGHT:
                x = -width;
                break;
            case CENTER:
            default:
                x = -width * 0.5;
                break;
        }
        y = this.bounds.getY() + height * lineIndex;
        return new Rectangle2D.Double(x, y, width, height);
    }


    /**
     * Проверка попадания точки в текст (строки текста).
     * <p>Точка должна попадать в одну из строк, попадания в габариты текста недостаточно.
     *
     * @param x Координата X.
     * @param y Координата Y.
     * @return Признак попадания точки та текст.
     */
    public boolean containsPoint(double x, double y) {
        // Если не расчитаны, то и нечего определять.
        if (bounds == null || lines == null)
            return false;
        // Если точка не попадает в габариты текста, то не попадает и в его строки.
        if (!GeometryUtils.isIn(x, bounds.getMinX(), bounds.getMaxX())
                || !GeometryUtils.isIn(y, bounds.getMinY(), bounds.getMaxY()))
            return false;
        // Ищем строку, в которую попадает точка.
        for (Line line : lines)
            if (line.containsPoint(x, y))
                return true;
        // Ничего не нашли.
        return false;
    }

    /**
     * Проверка попадания точки в текст.
     *
     * @param point Точка.
     * @return Признак попадания точки в текст.
     */
    public boolean containsPoint(Point2D point) {
        return containsPoint(point.getX(), point.getY());
    }


    /**
     * Получить относительное смещение точки выравнивания текста в рамке.
     * <p>Если текст необходимо разместить в рамке, то необходимо определить точку его отсчёта в этой рамке.
     * Данный коэффициент по X и Y [0, 1.0] указывает на относительное смещение точки привязки текста в рамке.
     *
     * @return относительное смещение точки выравнивания текста в рамке.
     */
    public Point2D getRelativeAnchor() {
        double x = 0.0;
        double y = 0.0;
        switch (hAlignment) {
            case LEFT:
                x = 0.0;
                break;
            case RIGHT:
                x = 1.0;
                break;
            case CENTER:
            default:
                x = 0.5;
                break;
        }
        switch (vAlignment) {
            case TOP:
                y = 0.0;
                break;
            case BOTTOM:
                y = 1.0;
                break;
            case CENTER:
            default:
                y = 0.5;
                break;
        }
        return new Point2D.Double(x, y);
    }


    /**
     * Получение растра текста.
     *
     * @param bgColor Цвет фона всей области текста (не только для строк).
     * @param fgColor Цвет текста.
     * @return Изображение с текстом.
     */
    public BufferedImage getImage(int bgColor, int fgColor) {
        // Ширина и высота изображения.
        int width = (int) Math.round(bounds.getWidth());
        if (width <= 0)
            width = 1;
        int height = (int) Math.round(bounds.getHeight());
        if (height <= 0)
            height = 1;

        // Создаём изображение.
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

        // Настраиваем графический контекст.
        Graphics2D g = image.createGraphics();
        // Сглаживание.
        g.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                fontRenderContext.isAntiAliased() ?
                        RenderingHints.VALUE_ANTIALIAS_ON :
                        RenderingHints.VALUE_ANTIALIAS_OFF);
        // Сглаживание по метрикам.
        g.setRenderingHint(
                RenderingHints.KEY_FRACTIONALMETRICS,
                fontRenderContext.usesFractionalMetrics() ?
                        RenderingHints.VALUE_FRACTIONALMETRICS_ON :
                        RenderingHints.VALUE_FRACTIONALMETRICS_OFF);

        // Сохраняем старый цвет
        // Это делаеться для того что цвета подчёркивания и зачёркивания текста не совпадали.
        // Так что параметр fgColor который передаёться в метод сейчас не используеться.
        Color oldColor = g.getColor();

        // Заливаем фон.
        g.setColor(new Color(bgColor, true));
        g.fillRect(0, 0, width, height);

        // Востанавливаем старый цвет
        g.setColor(oldColor);
        g.setFont(font);


        // Определяем точку отсчёта текста.
        Point2D relativeAnchor = getRelativeAnchor();
        g.translate(width * relativeAnchor.getX(), height * relativeAnchor.getY());

        // Выводим строки.
        for (PlaneText.Line line : lines) {
            bounds = line.getBounds();
            float x = (float) bounds.getMinX();
            float y = (float) (bounds.getMaxY() - getDescent());
            g.drawString(line.getText(), x, y);
        }


        return image;
    }

}
