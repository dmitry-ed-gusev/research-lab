package vg.utils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.Iterator;

/**
 * Итератор по строкам текста в потоке.
 */
public class TextLinesIterator implements Iterator<String> {

    /**
     * Ридер.
     */
    private BufferedReader reader;
    /**
     * Текущая прочитанная строка.
     */
    private String line;

    /**
     * @param stream Поток.
     */
    public TextLinesIterator(InputStream stream) {
        this(stream, null);
    }

    /**
     * @param stream   Поток.
     * @param encoding Кодировка.
     */
    public TextLinesIterator(InputStream stream, String encoding) {
        if (encoding == null) encoding = Charset.defaultCharset().name();
        try {
            reader = new BufferedReader(new InputStreamReader(new BufferedInputStream(stream), encoding));
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        next();
    }

    /**
     * @param reader Поток.
     */
    public TextLinesIterator(Reader reader) {
        this.reader = reader instanceof BufferedReader ?
                (BufferedReader) reader :
                new BufferedReader(reader);
        next();
    }

    @Override
    public boolean hasNext() {
        return line != null;
    }

    @Override
    public String next() {
        String returnLine = line;
        try {
            line = reader.readLine();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        return returnLine;
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }

    /**
     * Закрыть входной поток.
     */
    public void close() {
        try {
            reader.close();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

}