package vg;

import org.apache.log4j.Logger;
import vg.draw.AWTPainter;
import vg.geometry.GeometryDefaults;
import vg.geometry.primitives.BasePoint2D;
import vg.sign.building.builders.FlagstaffGraphBuilder;
import vg.sign.core.SignFactory;
import vg.sign.core.api.IGroupSign;
import vg.sign.core.api.ISign;
import vg.sign.visual.SignVisualFactory;
import vg.sign.visual.api.*;
import vg.sign.visual.signs.FlagstaffSignVisual;
import vg.sign.visual.signs.PointSignVisual;
import vg.sign.visual.tools.AnchorPoint;
import vg.sign.visual.tools.pen.PensFactory;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.List;

/**
 * Simple application, that draws some signs.
 * @author Gusev Dmitrii.
 */

public class VGraphics extends JFrame {

    private static final Logger log = Logger.getLogger(VGraphics.class);

    /** Main frame constructor. */
    public VGraphics() {
        setContentPane(new DrawPane());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);
        setVisible(true);
    }

    //create a component that you can actually draw on.
    class DrawPane extends JPanel {

        public DrawPane() {
            log.debug("VGraphics() working.");
        }

        public void paintComponent(Graphics g) {
            log.debug("VGraphics.paintComponent() working.");
            //draw on g here e.g.
            //g.fillRect(20, 20, 150, 200);

            FlagstaffSignVisual flagstaffSignVisual = SignVisualFactory.createFlagstaffSignVisual();
            IGroupSign groupSign = SignFactory.createGroupSign(flagstaffSignVisual);

            // Вычисление точки привязки для группового знака.
            //SignPoint2D mainP = this.createAnchorPointForGroup(selectionSigns);
            flagstaffSignVisual.getAnchorPoints().add(new BasePoint2D(150, 100));

            // Формирование дочерних элементов.
            PointSignVisual psv = VGraphics.createPointSign();
            psv.getAnchorPoints().add(new AnchorPoint(new BasePoint2D(0, 0)));

            ISign sign = SignFactory.createSign(psv);
            FlagstaffSignVisual.FlagstaffChild child = SignVisualFactory.createFlagstaffChild(psv, 0);
            flagstaffSignVisual.getChildren().add(child);
            groupSign.getChildren().add(sign);

            FlagstaffGraphBuilder builder = (FlagstaffGraphBuilder) groupSign.getBuilder();
            // Выравнивание знаков по вертикали.
            builder.alignVertically(flagstaffSignVisual);

            groupSign.calculate();

            AWTPainter painter = new AWTPainter((Graphics2D) g);
            painter.initialize();

            groupSign.getImage().paint(painter);
			
        }
    }

    public static PointSignVisual createPointSign() {
        int colorMask = 0xFFFFFFFF;

        PointSignVisual pointSign = SignVisualFactory.createPointSignVisual();//new PointSignVisual();
        List<IGraphElement> graphElements = pointSign.getGraphElements();

        // creating part of arc
        IGraphElement gElement = SignVisualFactory.createCircleGraphElement();
        ((ICircleGraphElement) gElement).setEndAngle(Math.PI + Math.PI / 4);

        IPen pen = PensFactory.createSolidPen(0x40FF0000, 1.0);

        IBrushCore bCore = SignVisualFactory.createSolidBrushCore();
        IBrushElement be = SignVisualFactory.createBrushElement();
        be.setColor(0x40FFFF00, colorMask);
        be.setCore(bCore);
        IBrush brush = SignVisualFactory.createBrush();
        brush.getElements().add(be);

        IPen textPen = PensFactory.createSolidPen(0x57555522, 1.0);

        IBrush textBrush = SignVisualFactory.createBrush();
        IBrushElement textBrushElement = SignVisualFactory.createBrushElement();
        IBrushCore textBrushCore = SignVisualFactory.createSolidBrushCore();
        textBrushElement.setColor(0x57555522, colorMask);
        textBrushElement.setCore(textBrushCore);
        textBrush.getElements().add(textBrushElement);

        IText text = SignVisualFactory.createText();
        text.setText(" Tdfdsfsdf ");
        text.setPen(textPen);
        text.setBrush(textBrush);
        text.setAlignment(IText.HA_RIGHT | IText.VA_BOTTOM);
        text.setFontSize(12);
        text.setFontStyle(0);

        gElement.setPen(pen);
        gElement.setBrush(brush);
        gElement.setText(text);

        graphElements.add(gElement);

        // Creating element of Flagstaff sign -> flag
        gElement = SignVisualFactory.createLineGraphElement();

        IPen line2Pen = PensFactory.createSolidPen(0xFF000000, 0.2);

        IBrush line2Brush = SignVisualFactory.createBrush();
        IBrushElement line2be = SignVisualFactory.createBrushElement();
        IBrushCore line2bc = SignVisualFactory.createSolidBrushCore();
        line2be.setCore(line2bc);
        line2be.setColor(0x400000FF, colorMask);
        line2Brush.getElements().add(line2be);

        IText line1Text = SignVisualFactory.createText();
        line1Text.setText(" xxx русские буквы xxx ");
        line1Text.setColor(0xFF800000, colorMask);
        line1Text.setFontStyle(0);
        line1Text.setFontSize(12);
        line1Text.setAlignment(IText.HA_LEFT);

        gElement = SignVisualFactory.createLineGraphElement();
        gElement.setPen(line2Pen);
        gElement.setBrush(line2Brush);
        gElement.setText(line1Text);

        graphElements.add(gElement);

        // Creating element of Flagstaff sign -> flagpole
        gElement = SignVisualFactory.createLineGraphElement();

        IPen line1Pen = SignVisualFactory.createPen();

        IPenCore line1PenCore = SignVisualFactory.createSolidPenCore();
        IPenElement line1PenElement = SignVisualFactory.createPenElement();
        line1PenElement.setCore(line1PenCore);
        line1PenElement.setColor(0xFFFF00FF, colorMask);
        line1PenElement.setWidth(2);
        line1PenElement.setCap(GeometryDefaults.LineCapType.BUTT);
        line1PenElement.setJoin(GeometryDefaults.LinesJoinType.MITTER);
        line1PenElement.setBeginArrow(GeometryDefaults.LineArrowType.NONE);
        line1PenElement.setEndArrow(GeometryDefaults.LineArrowType.NONE);
        line1Pen.getElements().add(line1PenElement);

        IBrush line1Brush = SignVisualFactory.createBrush();
        IBrushCore line1BrushCore = SignVisualFactory.createSolidBrushCore();
        IBrushElement line1BrushElement = SignVisualFactory.createBrushElement();
        line1BrushElement.setCore(line1BrushCore);
        line1BrushElement.setColor(0xFF0000FF, colorMask);
        line1Brush.getElements().add(line1BrushElement);

        gElement.setPen(line1Pen);
		gElement.setBrush(line1Brush);

        graphElements.add(gElement);

        // Predefined points.
        List<PointSignVisual.AbstractPredefinedPoint> predefinedPoints = pointSign.getPredefinedPoints();

        // 0 - absolute predefined point, center
        predefinedPoints.add(SignVisualFactory.createAbsolutePredefinedPoint(false, 10.0, 0.0));

        // 1
        predefinedPoints.add(SignVisualFactory.createDisplacementPredefinedPoint(false, pointSign, 0, 0.0, 1.0));
        // 2
        predefinedPoints.add(SignVisualFactory.createDisplacementPredefinedPoint(false, pointSign, 0, 1.0, 0.0));

        // 3
        predefinedPoints.add(SignVisualFactory.createRelativePredefinedPoint(true, pointSign, 0, 1, 32.0));

        // 4
        predefinedPoints.add(SignVisualFactory.createXYRelativePredefinedPoint(true, pointSign, 3, 2, 32.0, 0.5));
        // 5
        predefinedPoints.add(SignVisualFactory.createXYRelativePredefinedPoint(false, pointSign, 3, 4, 1.0, 0.0));
        // 6
        predefinedPoints.add(SignVisualFactory.createXYRelativePredefinedPoint(false, pointSign, 3, 4, 0.0, 1.0));

        // 7
        predefinedPoints.add(SignVisualFactory.createRelativePredefinedPoint(false, pointSign, 4, 5, 0.5));
        // 8
        predefinedPoints.add(SignVisualFactory.createRelativePredefinedPoint(false, pointSign, 6, 3, 0.5));
        // 9
        predefinedPoints.add(SignVisualFactory.createRelativePredefinedPoint(true, pointSign, 7, 8, 0.5));

        // 10
        predefinedPoints.add(SignVisualFactory.createXYRelativePredefinedPoint(false, pointSign, 0, 5, -1.0, -0.25));
        // 11
        predefinedPoints.add(SignVisualFactory.createXYRelativePredefinedPoint(false, pointSign, 0, 5, 2.0, 1.25));

        // Dressing the graph elements onto the predefined points.
        List<List<Integer>> predefinedPointIndices = pointSign.getPredefinedPointIndices();
        predefinedPointIndices.add(Arrays.asList(10, 11));
        predefinedPointIndices.add(Arrays.asList(3, 5, 9, 4, 6));
        predefinedPointIndices.add(Arrays.asList(0, 3));

        return pointSign;
    }

    /** Main app entry point. */
    public static void main(String args[]) {

        log.info("VGraphics starting.");
        new VGraphics();

    }

}
