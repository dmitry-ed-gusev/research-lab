package vg.draw.vobject;

import vg.draw.painting.IPainter;
import vg.geometry.primitives.BasePoint2D;

public class VGPoint extends VGAbstractObject {

    private BasePoint2D point = new BasePoint2D();


    public VGPoint() {
    }

    public VGPoint(BasePoint2D point) {
        //this.point.init(point);
        this.point = point;
    }

    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj))
            return false;
        VGPoint other = (VGPoint) obj;

        return point.equals(other.point);
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result ^= point.hashCode();
        return result;
    }

    public BasePoint2D getPoint() {
        return new BasePoint2D(point);
    }

    public void setPoint(BasePoint2D point) {
        //this.point.init(point);
        this.point = point;
    }

    @Override
    public void calculate() {
        bounds.init(point.getX(), point.getY(), 0.0, 0.0, angle);
    }

    @Override
    public boolean containsPoint(BasePoint2D point, double delta) {
        // todo: !!!
        //return this.point.equals(point, delta);
        return this.point.equals(point);
    }

    @Override
    public void paint(IPainter painter) {
    }

}
