package vg.draw.painting;

import vg.geometry.primitives.BasePoint2D;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract class AbstractPainter implements IPainter {

    @Override
    public void drawLine(List<? extends BasePoint2D> points) {
        drawLine(false, points);
    }

    @Override
    public void drawLine(boolean closed, double... pointCoordinates) {
        List<BasePoint2D> points = new ArrayList<BasePoint2D>();
        for (int i = 0; i + 1 < pointCoordinates.length; i += 2)
            points.add(new BasePoint2D(pointCoordinates[i], pointCoordinates[i + 1]));
        drawLine(closed, points);
    }

    @Override
    public void drawLine(double... pointCoordinates) {
        drawLine(false, pointCoordinates);
    }

    @Override
    public void fillShape(double... pointCoordinates) {
        List<BasePoint2D> points = new ArrayList<BasePoint2D>();
        for (int i = 0; i + 1 < pointCoordinates.length; i += 2)
            points.add(new BasePoint2D(pointCoordinates[i], pointCoordinates[i + 1]));
        fillShape(points);
    }


    @Override
    public Object createCache(Runnable painter) {
        return null;
    }

    @Override
    public void paintCache(Object cacheId) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void deleteCache(Object cacheId) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void deleteAllCaches() {
        throw new UnsupportedOperationException();
    }

}
