package vg.draw.vobject;

import vg.draw.painting.IPainter;
import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BasePoint2D;
import vg.geometry.primitives.BaseRectangle2D;

import java.util.ArrayList;
import java.util.List;

public class VGLinearGradientBrush implements VGBrush {

    private int color1;
    private int color2;
    private double angle;


    public VGLinearGradientBrush() {
        this.color1 = 0xFFFFFFFF;
        this.color2 = 0xFFFFFFFF;
        this.angle = 0;
    }

    public VGLinearGradientBrush(int color1, int color2) {
        this.color1 = color1;
        this.color2 = color2;
        this.angle = 0;
    }

    public VGLinearGradientBrush(int color1, int color2, double angle) {
        this.color1 = color1;
        this.color2 = color2;
        this.angle = angle;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (obj == null)
            return false;
        if (obj.getClass() != getClass())
            return false;
        VGLinearGradientBrush other = (VGLinearGradientBrush) obj;

        return color1 == other.color1 &&
                color2 == other.color2 &&
                angle == other.angle;
    }

    @Override
    public int hashCode() {
        int result = 13;
        result ^= color1;
        result = GeometryUtils.cyclicShift(result, 17);
        result ^= color2;
        result ^= GeometryUtils.hashCode(angle);
        return result;
    }


    public int getColor1() {
        return color1;
    }

    public void setColor1(int color) {
        this.color1 = color;
    }

    public int getColor2() {
        return color2;
    }

    public void setColor2(int color) {
        this.color2 = color;
    }

    public double getAngle() {
        return angle;
    }

    public void setAngle(double angle) {
        this.angle = angle;
    }

    @Override
    public void paint(IPainter painter, List<BasePoint2D> points) {
        // Сохраняем маску и задаём новую.
        painter.pushClip();
        painter.setClip(points);

        List<BasePoint2D> list = new ArrayList<BasePoint2D>();
        for (BasePoint2D p : points) {
            list.add(new BasePoint2D(p).rotate(-angle, 0, 0));
        }

        // Расчитываем квадрат вокруг области заливки.
        BaseRectangle2D rc = new BaseRectangle2D(GeometryUtils.createBoundingFrame(list));
        double width = rc.getWidth();
        double height = rc.getHeight();
        double x = rc.getTLP().getX();
        double y = rc.getTLP().getY();

        painter.pushTransform();
        painter.rotate(angle);
        painter.drawLinearGradient(x, y, width, height, color1, color2);
        painter.popTransform();

        // Восстанавливаем маску.
        painter.popClip();
    }

}
