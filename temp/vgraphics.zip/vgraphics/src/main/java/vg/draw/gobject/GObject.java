package vg.draw.gobject;

import vg.draw.painting.IPainter;

public interface GObject {

    public void paint(IPainter painter);

}
