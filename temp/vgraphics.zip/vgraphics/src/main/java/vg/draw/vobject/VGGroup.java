package vg.draw.vobject;

import vg.draw.painting.IPainter;
import vg.draw.vobject.VGObject;
import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BaseFrame2D;
import vg.geometry.primitives.BasePoint2D;
import vg.geometry.primitives.BaseRectangle2D;

import java.util.ArrayList;
import java.util.List;

public class VGGroup extends VGAbstractObject {
    private List<VGObject> children = new ArrayList<VGObject>();


    public VGGroup() {
    }

    public VGGroup(List<VGObject> children) {
        this.children.addAll(children);
    }

    public VGGroup(VGObject... children) {
        for (VGObject c : children)
            this.children.add(c);
    }

    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj))
            return false;
        VGGroup other = (VGGroup) obj;

        return children.equals(other.children);
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        for (VGObject child : children) {
            result = GeometryUtils.cyclicShift(result, 3);
            result ^= child.hashCode();
        }
        return result;
    }

    public List<VGObject> getChildren() {
        return children;
    }

    public void addAngle(double addAngle) {
        for (VGObject vgo : children)
            if (vgo instanceof VGGroup)
                ((VGGroup) vgo).addAngle(addAngle);
            else
                vgo.setAngle(vgo.getAngle() + addAngle);
        angle += addAngle;
    }

    @Override
    public synchronized void calculate() {
        for (VGObject vgo : getChildren())
            vgo.calculate();

        BaseFrame2D frame = new BaseFrame2D();
        for (VGObject vgo : getChildren())
            frame.union(new BaseRectangle2D(vgo.getBounds()).rotate(-angle, 0, 0).getBounds());
        bounds.init(frame).rotate(angle, 0, 0);
    }

    @Override
    public void paint(IPainter painter) {
        for (VGObject vgo : getChildren())
            vgo.paint(painter);
    }

    @Override
    public boolean containsPoint(BasePoint2D point, double delta) {
        if (!bounds.clone().extend(delta).contains(point)) return false;
        for (VGObject vgo : getChildren())
            if (vgo.containsPoint(point, delta)) return true;
        return false;
    }

}
