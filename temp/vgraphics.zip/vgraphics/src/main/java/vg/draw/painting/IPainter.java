package vg.draw.painting;

import vg.geometry.primitives.BaseFrame2D;
import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;

import java.util.List;
import java.util.Map;

public interface IPainter {

    public void initialize();
    public Map<String, Object> getExtra();
    public int getColor();
    public void setColor(int color);
    public LineParams getLineParams();
    public void setLineParams(LineParams params);
    public void lockAttribute();
    public void unlockAttribute();
    public void drawLine(boolean closed, List<? extends BasePoint2D> points);
    public void drawLine(List<? extends BasePoint2D> points);
    public void drawLine(boolean closed, double... pointCoordinates);
    public void drawLine(double... pointCoordinates);
    public void fillShape(List<? extends BasePoint2D> points);
    public void fillShape(double... pointCoordinates);
    public void setFont(String name, int style, double size);
    public void drawString(String txt, double x, double y);
    public BaseFrame2D getStringBounds(String txt, String name, int style, int size);
    public void drawLinearGradient(
            double x, double y, double width, double height,
            int color1, int color2);
    public void getClip(List<BasePoint2D> points);
    public void setClip(List<? extends BasePoint2D> points);
    public void pushClip();
    public void popClip();
    public BaseMatrix2D getTransform();
    public void setTransform(BaseMatrix2D matrix);
    public void pushTransform();
    public void popTransform();
    public void transform(BaseMatrix2D matrix);
    public BaseMatrix2D getBaseTransform();
    public void translate(double x, double y);
    public void scale(double kx, double ky);
    public void rotate(double angle);
    public Object createCache(Runnable painter);
    public void paintCache(Object cacheId);
    public void deleteCache(Object cacheId);
    public void deleteAllCaches();

}