package vg.draw.vobject;

import vg.draw.gobject.GObject;
import vg.geometry.primitives.BasePoint2D;
import vg.geometry.primitives.BaseRectangle2D;

public interface VGObject extends GObject {

    public double getAngle();

    public void setAngle(double angle);

    public void calculate();

    public BaseRectangle2D getBounds();

    public boolean containsPoint(BasePoint2D point, double delta);

}
