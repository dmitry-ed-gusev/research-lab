package vg.draw;

import vg.geometry.GeometryUtils;

public class Colors {

    public static final int INDEX_ALPHA = 3;
    public static final int INDEX_RED = 2;
    public static final int INDEX_GREEN = 1;
    public static final int INDEX_BLUE = 0;
    public static final int OFFSET_ALPHA = 24;
    public static final int OFFSET_RED = 16;
    public static final int OFFSET_GREEN = 8;
    public static final int OFFSET_BLUE = 0;

    public static final int MASK_ALPHA = 0xFF000000;
    public static final int MASK_RED = 0x00FF0000;
    public static final int MASK_GREEN = 0x0000FF00;
    public static final int MASK_BLUE = 0x000000FF;
    public static final int MASK_RGB = 0x00FFFFFF;
    public static final int MASK_ARGB = 0xFFFFFFFF;

    public static int getComponent(int color, int index) {
        if (index < 0 || index > 3) return 0x00000000;
        int offset = index * 8;
        int mask = 0xFF << offset;
        return ((color & mask) >> offset) & 0xFF;
    }

    public static int setComponent(int color, int index, int value) {
        if (index < 0 || index > 3) return color;
        value = value < 0x00 ? 0x00 : value > 0xFF ? 0xFF : value;
        int offset = index * 8;
        int mask = 0xFF << offset;
        return (color & ~mask) | (value << offset);
    }

    public static double getFloatComponent(int color, int index) {
        return getComponent(color, index) / 255.0;
    }

    public static int setFloatComponent(int color, int index, double value) {
        return setComponent(color, index, (int) Math.round(value * 255.0));
    }

    public static int getAlpha(int color) {
        return getComponent(color, INDEX_ALPHA);
    }

    public static int setAlpha(int color, int value) {
        return setComponent(color, INDEX_ALPHA, value);
    }

    public static double getFloatAlpha(int color) {
        return getFloatComponent(color, INDEX_ALPHA);
    }

    public static int setFloatAlpha(int color, double value) {
        return setFloatComponent(color, INDEX_ALPHA, value);
    }

    public static double getFloatRed(int color) {
        return getFloatComponent(color, INDEX_RED);
    }

    public static double getFloatBlue(int color) {
        return getFloatComponent(color, INDEX_BLUE);
    }

    public static double[] splitColor(int color, double[] components) {
        if (components == null) components = new double[4];
        components[0] = getFloatComponent(color, 0);
        components[1] = getFloatComponent(color, 1);
        components[2] = getFloatComponent(color, 2);
        components[3] = getFloatComponent(color, 3);
        return components;
    }

    public static int joinColor(double[] components) {
        int color = 0;
        color = setFloatComponent(color, 0, components[0]);
        color = setFloatComponent(color, 1, components[1]);
        color = setFloatComponent(color, 2, components[2]);
        color = setFloatComponent(color, 3, components[3]);
        return color;
    }

    public static int setColor(int srcColor, int newColor, int mask) {
        return GeometryUtils.set(srcColor, mask, newColor);
    }

    public static int mid(int color1, double weight1, int color2, double weight2) {
        double[] components1 = splitColor(color1, (double[]) null);
        double[] components2 = splitColor(color2, (double[]) null);

        double div = weight1 + weight2;
        if (div == 0.0) div = 0.5;
        div = 1.0 / div;

        components1[0] = (components1[0] * weight1 + components2[0] * weight2) * div;
        components1[1] = (components1[1] * weight1 + components2[1] * weight2) * div;
        components1[2] = (components1[2] * weight1 + components2[2] * weight2) * div;
        components1[3] = (components1[3] * weight1 + components2[3] * weight2) * div;

        return joinColor(components1);
    }

}