package vg.draw.vobject;

import vg.draw.painting.IPainter;
import vg.draw.painting.LineParams;
import vg.geometry.GeometryDefaults;
import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BasePoint2D;

import java.util.List;

public class VGBasicPen implements VGPen {

    private int color;
    private double width;
    private GeometryDefaults.LineCapType cap = GeometryDefaults.LineCapType.BUTT;
    private GeometryDefaults.LinesJoinType join = GeometryDefaults.LinesJoinType.MITTER;
    private double miterLimit = 4;


    public VGBasicPen() {
        this(0xFF000000, 1.0);
    }

    public VGBasicPen(int color, double width) {
        this.color = color;
        this.width = width;
    }

    public VGBasicPen(int color, double width, GeometryDefaults.LineCapType cap, GeometryDefaults.LinesJoinType join, double miterLimit) {
        this.color = color;
        this.width = width;
        if (cap != null) this.cap = cap;
        if (join != null) this.join = join;
        this.miterLimit = miterLimit;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (obj == null)
            return false;
        if (obj.getClass() != getClass())
            return false;
        VGBasicPen other = (VGBasicPen) obj;

        return other.color == color &&
                other.width == width &&
                other.cap == cap &&
                other.join == join &&
                other.miterLimit == miterLimit;
    }

    @Override
    public int hashCode() {
        int result = 19;
        result ^= color;
        result ^= GeometryUtils.hashCode(width);
        result ^= cap.ordinal();
        result ^= join.ordinal() << 11;
        result = GeometryUtils.cyclicShift(result, 19);
        result ^= GeometryUtils.hashCode(miterLimit);
        return result;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    @Override
    public void paint(IPainter painter, List<BasePoint2D> points) {
        painter.setColor(color);
        painter.setLineParams(new LineParams(width, cap, join, miterLimit >= 0 ? miterLimit : 1e6));
        painter.drawLine(points);

//		painter.setColor(0xFF000000);
//		painter.setLineParams(new IPainter.LineParams(0.1));
//		for (IPoint2D p: points) {
//			painter.fillShape(PlaneGeomProcessor.createCircle(p, 0.25));
//		}
    }

}
