package vg.draw;

import org.apache.log4j.Logger;
import vg.geometry.primitives.BaseFrame2D;
import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;

import java.awt.*;

import static vg.geometry.GeometryDefaults.INC_TO_MM;

public class ViewParams {

    private static final Logger log = Logger.getLogger(ViewParams.class);

    public static int DEFAULT_BASE_SCALE = 100000;

    private double scale;
    private double scaleFactor;
    private BasePoint2D viewSize;
    private BasePoint2D resolution;
    private BasePoint2D viewCenter;
    private BaseMatrix2D mmToPx;
    private BaseMatrix2D pxToMm;
    private BaseFrame2D viewFrame;

    private static double screenResolutionDPI;

    static {
        try {
            ViewParams.screenResolutionDPI = Toolkit.getDefaultToolkit().getScreenResolution();
        } catch (HeadlessException ex) {
            ViewParams.screenResolutionDPI = 300;
            log.warn("Headless mode! Used screen resolution default value: 300 dpi!");
        }
    }

    public ViewParams(double scale, double scaleFactor, BasePoint2D viewSize, BasePoint2D resolution, BasePoint2D viewCenter) {
        this.scale = scale;
        this.scaleFactor = scaleFactor;
        this.viewSize = new BasePoint2D(viewSize);
        this.resolution = new BasePoint2D(resolution);
        this.viewCenter = new BasePoint2D(viewCenter);
        calculate();
    }

    public ViewParams() {
        this(DEFAULT_BASE_SCALE, 1.0, new BasePoint2D(64, 64), new BasePoint2D(0, 0), new BasePoint2D(0, 0));
    }

    public void calculate() {
        double resolutionX = (resolution != null && resolution.getX() > 0) ? resolution.getX() : ViewParams.screenResolutionDPI;
        double resolutionY = (resolution != null && resolution.getY() > 0) ? resolution.getY() : ViewParams.screenResolutionDPI;

        mmToPx = new BaseMatrix2D()
                .translate(new BasePoint2D(viewCenter).mul(-1, -1))
                .scale(resolutionX / INC_TO_MM * scaleFactor,
                        resolutionY / INC_TO_MM * scaleFactor, 0, 0)
                .translate(new BasePoint2D(viewSize).mul(0.5, 0.5));
        pxToMm = new BaseMatrix2D(mmToPx).invert();
        viewFrame = new BaseFrame2D(
                new BasePoint2D(0, 0).transform(pxToMm),
                new BasePoint2D(viewSize).transform(pxToMm));
    }

    public BaseMatrix2D getMmToPx() {
        return new BaseMatrix2D(mmToPx);
    }

    public BaseMatrix2D getPxToMm() {
        return new BaseMatrix2D(pxToMm);
    }

    public double getBaseScale() {
        return scale;
    }

    public double getWorkScale() {
        return scale / scaleFactor;
    }

    public void setWorkScale(double workScale) {
        this.scaleFactor = workScale / scale;
        calculate();
    }

    public double getScaleFactor() {
        return scaleFactor;
    }

    public void setScaleFactor(double scaleFactor) {
        this.scaleFactor = scaleFactor;
        calculate();
    }

    public void scale(double scale, BasePoint2D scaleCenter) {
        if (scaleCenter == null)
            scaleCenter = viewCenter;
        scaleFactor *= scale;
        viewFrame.scale(1.0 / scale, 1.0 / scale, scaleCenter.getX(), scaleCenter.getY());
        viewCenter = viewFrame.getCenter();
        calculate();
    }

    public BaseFrame2D getViewFrame() {
        return new BaseFrame2D(viewFrame);
    }

    public BasePoint2D getViewSize() {
        return new BasePoint2D(viewSize);
    }

    public void setViewSize(BasePoint2D viewSize) {
        this.viewSize = new BasePoint2D(viewSize);
        calculate();
    }

    public BasePoint2D getViewCenter() {
        return new BasePoint2D(viewCenter);
    }

    public void setViewCenter(BasePoint2D viewCenter) {
        this.viewCenter = new BasePoint2D(viewCenter);
        calculate();
    }

    public BasePoint2D getResolution() {
        return this.resolution;
    }

    public void setResolution(BasePoint2D resolution) {
        //this.resolution.init(resolution);
        this.resolution = resolution;
    }

    public void translate(BasePoint2D translation) {
        this.viewCenter.translate(translation.getX(), translation.getY());
        calculate();
    }

}
