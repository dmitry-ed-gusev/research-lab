package vg.draw.vobject;

import vg.draw.painting.IPainter;
import vg.geometry.primitives.BasePoint2D;

import java.util.List;

public class VGBasicBrush implements VGBrush {

    private int color;



    public VGBasicBrush() {
        this(0xFF000000);
    }

    public VGBasicBrush(int color) {
        this.color = color;
    }


    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (obj == null)
            return false;
        if (obj.getClass() != getClass())
            return false;
        VGBasicBrush other = (VGBasicBrush) obj;

        return other.color == color;
    }

    @Override
    public int hashCode() {
        return 19 + color;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    @Override
    public void paint(IPainter painter, List<BasePoint2D> points) {
        painter.setColor(color);
        painter.fillShape(points);
    }

}
