package vg.draw.vobject;


import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BaseRectangle2D;

public abstract class VGAbstractObject implements VGObject {

    protected double angle = 0.0;
    protected BaseRectangle2D bounds = new BaseRectangle2D();


    @Override
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (obj == this)
            return true;
        if (obj.getClass() != getClass())
            return false;
        VGAbstractObject other = (VGAbstractObject) obj;

        BaseRectangle2D otherBounds = other.bounds;
        return angle == other.angle &&
                (bounds != null ? bounds.equals(otherBounds) : otherBounds == null);
    }

    @Override
    public int hashCode() {
        int result = 17;
        result ^= GeometryUtils.hashCode(angle);
        result ^= bounds.hashCode();
        return result;
    }


    @Override
    public double getAngle() {
        return angle;
    }

    @Override
    public void setAngle(double angle) {
        this.angle = angle;
    }

    @Override
    public BaseRectangle2D getBounds() {
        return bounds;
    }

}
