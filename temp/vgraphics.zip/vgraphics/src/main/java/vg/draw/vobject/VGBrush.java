package vg.draw.vobject;

import vg.draw.painting.IPainter;
import vg.geometry.primitives.BasePoint2D;

import java.util.List;

public interface VGBrush {

    public void paint(IPainter painter, List<BasePoint2D> points);

}