package vg.draw.vobject;

import vg.draw.painting.IPainter;
import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BasePoint2D;

import java.util.ArrayList;
import java.util.List;

public class VGGroupBrush implements VGBrush {

    private List<VGBrush> children = new ArrayList<VGBrush>();


    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (obj == null)
            return false;
        if (obj.getClass() != getClass())
            return false;
        VGGroupBrush other = (VGGroupBrush) obj;

        return children.equals(other.children);
    }

    @Override
    public int hashCode() {
        int result = 23;
        for (VGBrush child : children) {
            result = GeometryUtils.cyclicShift(result, 13);
            result ^= child.hashCode();
        }
        return result;
    }

    public List<VGBrush> getChildren() {
        return children;
    }

    @Override
    public void paint(IPainter painter, List<BasePoint2D> points) {
        for (VGBrush c : children)
            c.paint(painter, points);
    }

}
