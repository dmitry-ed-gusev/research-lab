package vg.draw.painting;


import vg.geometry.GeometryUtils;

import java.util.Arrays;

import static vg.geometry.GeometryDefaults.LineCapType;
import static vg.geometry.GeometryDefaults.LinesJoinType;

// TODO redesign this class (equals/hashcode) and existence of it.
public class LineParams {

    private double width;
    private LineCapType cap;
    private LinesJoinType join;
    private double miterLimit;
    private double[] dash;
    private double dashPhase;

    public LineParams(double width, LineCapType cap, LinesJoinType join, double mitterLimit, double[] dash, double dashPhase) {
        this.width = width;
        this.cap = cap;
        this.join = join;
        this.miterLimit = mitterLimit;
        this.dash = dash;
        this.dashPhase = dashPhase;
    }

    public LineParams() {
        this(1.0, LineCapType.BUTT, LinesJoinType.MITTER, 5.0, null, 0.0);
    }

    public LineParams(double width) {
        this(width, LineCapType.BUTT, LinesJoinType.MITTER, 5.0, null, 0.0);
    }

    public LineParams(double width, LineCapType cap, LinesJoinType join, double mitterLimit) {
        this(width, cap, join, mitterLimit, null, 0.0);
    }

    public LineParams(LineParams lineParams) {
        if (lineParams != null) {
            this.width = lineParams.width;
            this.cap = lineParams.cap;
            this.join = lineParams.join;
            this.miterLimit = lineParams.miterLimit;
            if (lineParams.getDash() != null && lineParams.getDash().length > 0) {
                double[] dashArray = new double[lineParams.getDash().length];
                System.arraycopy(lineParams.getDash(), 0, dashArray, 0, lineParams.getDash().length);
                this.setDash(dashArray);
            }
            this.dashPhase = lineParams.dashPhase;
        }
    }

    public double getMiterLimit() {
        return miterLimit;
    }

    public void setMiterLimit(double miterLimit) {
        this.miterLimit = miterLimit;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double[] getDash() {
        return dash;
    }

    public void setDash(double[] dash) {
        this.dash = dash;
    }

    public double getDashPhase() {
        return dashPhase;
    }

    public void setDashPhase(double dashPhase) {
        this.dashPhase = dashPhase;
    }

    public LineCapType getCap() {
        return cap;
    }

    public void setCap(LineCapType cap) {
        this.cap = cap;
    }

    public LinesJoinType getJoin() {
        return join;
    }

    public void setJoin(LinesJoinType join) {
        this.join = join;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (obj == null)
            return false;
        if (obj.getClass() != getClass())
            return false;
        LineParams other = (LineParams) obj;

        return other.width != width &&
                other.cap != cap &&
                other.join != join &&
                other.miterLimit != miterLimit &&
                Arrays.equals(other.dash, dash) &&
                other.dashPhase != dashPhase;
    }

    @Override
    public int hashCode() {
        int result = 67;
        result ^= GeometryUtils.hashCode(width);
        result ^= cap.ordinal() + (join.ordinal() << 8);
        result = GeometryUtils.cyclicShift(result, 7) ^ GeometryUtils.hashCode(miterLimit);
        if (dash != null) {
            result ^= dash.length;
            for (double d : dash)
                result = GeometryUtils.cyclicShift(result, 3) ^ GeometryUtils.hashCode(d);
        } else {
            result ^= 8123717;
        }
        result = GeometryUtils.cyclicShift(result, 5) ^ GeometryUtils.hashCode(dashPhase);
        return result;
    }

    @Override
    public String toString() {
        return String.format(
                "LineParams: {width: %f, cap: %s, join: %s, mitterLimit: %f, dash: [%s], dashPhase: %f}",
                width, cap, join, miterLimit, Arrays.toString(dash), dashPhase);
    }

}