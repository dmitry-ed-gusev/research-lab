package vg.draw.vobject;

import vg.draw.painting.IPainter;
import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BasePoint2D;

import java.util.ArrayList;
import java.util.List;

public class VGGroupPen implements VGPen {

    private List<VGPen> children = new ArrayList<VGPen>();


    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (obj == null)
            return false;
        if (obj.getClass() != getClass())
            return false;
        VGGroupPen other = (VGGroupPen) obj;

        return children.equals(other.children);
    }

    @Override
    public int hashCode() {
        int result = 11;
        for (VGPen child : children) {
            result = GeometryUtils.cyclicShift(result, 11);
            result ^= child.hashCode();
        }
        return result;
    }

    public List<VGPen> getChildren() {
        return children;
    }

    @Override
    public void paint(IPainter painter, List<BasePoint2D> points) {
        for (VGPen c : children)
            c.paint(painter, points);
    }

}
