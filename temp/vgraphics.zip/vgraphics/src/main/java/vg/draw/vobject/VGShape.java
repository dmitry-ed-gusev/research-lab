package vg.draw.vobject;

import vg.draw.painting.IPainter;
import vg.geometry.GeometryProcessor;
import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BaseFrame2D;
import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;

import java.util.ArrayList;
import java.util.List;

public class VGShape extends VGAbstractObject {
    private VGPen pen = null;
    private VGBrush brush = null;
    private List<BasePoint2D> points = new ArrayList<BasePoint2D>();


    public VGShape() {
    }

    public VGShape(VGPen pen, VGBrush brush, List<? extends BasePoint2D> points) {
        this.pen = pen;
        this.brush = brush;
        this.points.addAll(points);
    }

    public VGShape(VGPen pen, VGBrush brush, BasePoint2D... points) {
        this.pen = pen;
        this.brush = brush;
        for (BasePoint2D p : points)
            this.points.add(p);
    }

    public VGShape(VGPen pen, VGBrush brush, double... points) {
        this.pen = pen;
        this.brush = brush;
        for (int i = 0, n = points.length; i < n - 1; i += 2)
            this.points.add(new BasePoint2D(points[i], points[i + 1]));
    }

    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj))
            return false;
        VGShape other = (VGShape) obj;

        return (pen != null ? pen.equals(other.pen) : other.pen == null) &&
                (brush != null ? brush.equals(other.brush) : other.brush == null) &&
                points.equals(other.points);
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result ^= pen != null ? pen.hashCode() : 173;
        result ^= brush != null ? brush.hashCode() : 71634;
        for (BasePoint2D point : points) {
            result = GeometryUtils.cyclicShift(result, 23);
            result ^= point.hashCode();
        }
        return result;
    }

    public List<BasePoint2D> getPoints() {
        return points;
    }

    public VGPen getPen() {
        return pen;
    }

    public void setPen(VGPen pen) {
        this.pen = pen;
    }

    public VGBrush getBrush() {
        return brush;
    }

    public void setBrush(VGBrush brush) {
        this.brush = brush;
    }

    @Override
    public synchronized void calculate() {
        BaseFrame2D frame = new BaseFrame2D();
        BaseMatrix2D matrix = new BaseMatrix2D().rotate(-angle, 0, 0);
        //BasePoint2D point = new BasePoint2D();
        BasePoint2D point;
        for (BasePoint2D p : points) {
            point = p.transform(matrix);
            //frame.union(point.init(p).transform(matrix));
            frame.union(point);
        }
        bounds.init(frame).rotate(angle, 0, 0);
    }

    @Override
    public boolean containsPoint(BasePoint2D point, double delta) {
        if (brush != null) return GeometryProcessor.isPointInsidePolygon(point, points);
        return GeometryProcessor.isPointOnPolyline(point, delta, points);
    }

    @Override
    public void paint(IPainter painter) {
        List<BasePoint2D> pointsToPaint = points;

        if (brush != null)
            brush.paint(painter, pointsToPaint);
        if (pen != null)
            pen.paint(painter, pointsToPaint);
    }

}
