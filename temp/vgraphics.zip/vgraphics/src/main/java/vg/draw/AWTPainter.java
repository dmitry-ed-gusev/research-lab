package vg.draw;

import vg.draw.painting.AbstractPainter;
import vg.draw.painting.LineParams;
import vg.geometry.GeometryDefaults;
import vg.geometry.GeometryUtils;
import vg.geometry.primitives.BaseFrame2D;
import vg.geometry.primitives.BaseMatrix2D;
import vg.geometry.primitives.BasePoint2D;

import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.*;
import java.util.*;
import java.util.List;

public class AWTPainter extends AbstractPainter {

    public static Path2D awtPolyline(boolean closed, List<? extends BasePoint2D> points) {
        Path2D path = new Path2D.Double();

        Iterator<? extends BasePoint2D> pointsIterator = points.iterator();
        BasePoint2D point;
        if (pointsIterator.hasNext()) {
            point = pointsIterator.next();
            path.moveTo(point.getX(), point.getY());
        } else {
            path.moveTo(0.0, 0.0);
        }
        while (pointsIterator.hasNext()) {
            point = pointsIterator.next();
            path.lineTo(point.getX(), point.getY());
        }
        if (closed) {
            path.closePath();
        }

        return path;
    }


    public static List<List<BasePoint2D>> getLineOutline(List<? extends BasePoint2D> points, double width) {
        List<List<BasePoint2D>> outlines = new ArrayList<List<BasePoint2D>>();

        if (points.isEmpty()) return outlines;
        boolean closed = points.size() > 1 && points.get(0).equals(points.get(points.size() - 1));
        if (closed) points.remove(points.size() - 1);

        Path2D path = new Path2D.Double();
        BasePoint2D p = points.get(0);
        path.moveTo(p.getX(), p.getY());
        for (int i = 0, n = points.size(); i < n; i++) {
            p = points.get(i);
            path.lineTo(p.getX(), p.getY());
        }
        if (closed) path.closePath();

        Stroke stroke = new BasicStroke((float) width, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
        Shape shape = stroke.createStrokedShape(path);

        List<BasePoint2D> shapePoints = new ArrayList<BasePoint2D>();
        PathIterator pathIterator = new Area(shape).getPathIterator(new AffineTransform());
        double[] segmentPoints = new double[6];
        while (!pathIterator.isDone()) {
            int segmentType = pathIterator.currentSegment(segmentPoints);
            switch (segmentType) {
                case PathIterator.SEG_MOVETO:
                    if (shapePoints.size() >= 2) {
                        outlines.add(shapePoints);
                        shapePoints = new ArrayList<BasePoint2D>();
                    } else {
                        shapePoints.clear();
                    }
                    shapePoints.add(new BasePoint2D(segmentPoints[0], segmentPoints[1]));
                    break;
                case PathIterator.SEG_LINETO:
                    shapePoints.add(new BasePoint2D(segmentPoints[0], segmentPoints[1]));
                    break;
                case PathIterator.SEG_QUADTO:
                    shapePoints.add(new BasePoint2D(segmentPoints[2], segmentPoints[3]));
                    break;
                case PathIterator.SEG_CUBICTO:
                    shapePoints.add(new BasePoint2D(segmentPoints[4], segmentPoints[5]));
                    break;
                case PathIterator.SEG_CLOSE:
                    outlines.add(shapePoints);
                    shapePoints = new ArrayList<BasePoint2D>();
                    break;
            }
            pathIterator.next();
        }
        if (shapePoints.size() >= 2) {
            outlines.add(shapePoints);
            shapePoints = new ArrayList<BasePoint2D>();
        }

        return outlines;
    }

    public AffineTransform toAwt(BaseMatrix2D matrix) {
        double[] mArray = matrix.getMatrix();
        return new AffineTransform(mArray[0], mArray[3], mArray[1], mArray[4], mArray[2], mArray[5]);
    }


    private Graphics2D graphics2D;
    private Stack<Shape> clipStack = new Stack<Shape>();
    private Stack<BaseMatrix2D> transformsStack = new Stack<BaseMatrix2D>();
    private LineParams lockAttribute = null;
    private LineParams currAttribute = null;
    private Map<String, Object> extra = new HashMap<String, Object>();
    private BaseMatrix2D baseTransform;



    public AWTPainter(Graphics2D graphics2D) {
        this.graphics2D = graphics2D;
        extra.put("g2d", graphics2D);
        baseTransform = getTransform();
    }


    @Override
    public void initialize() {
    }


    @Override
    public Map<String, Object> getExtra() {
        return extra;
    }


    @Override
    public void setColor(int color) {
        graphics2D.setColor(new Color(color, (color & 0xFF000000) != 0xFF000000));
    }

    @Override
    public int getColor() {
        return graphics2D.getColor().getRGB();
    }


    @Override
    public LineParams getLineParams() {
        BasicStroke stroke = (BasicStroke) graphics2D.getStroke();
        // создание объекта LineParams
        LineParams lineParams = new LineParams();
        lineParams.setMiterLimit(stroke.getMiterLimit());
        lineParams.setWidth(stroke.getLineWidth());
        lineParams.setDash(GeometryUtils.floatToDouble(stroke.getDashArray()));
        lineParams.setDashPhase(stroke.getDashPhase());
        lineParams.setCap(GeometryDefaults.LineCapType.getCapTypeByValue(stroke.getEndCap()));
        lineParams.setJoin(GeometryDefaults.LinesJoinType.getJoinTypeByValue(stroke.getLineJoin()));
        // результат
        return lineParams;
    }

    @Override
    public void setLineParams(LineParams params) {
        currAttribute = params;
        setLockAttribute();
        BasicStroke basic = null;
        int capStyle = BasicStroke.CAP_BUTT;
        switch (currAttribute.getCap()) {
            case BUTT:
                capStyle = BasicStroke.CAP_BUTT;
                break;
            case SQUARE:
                capStyle = BasicStroke.CAP_SQUARE;
                break;
            case ROUND:
                capStyle = BasicStroke.CAP_ROUND;
                break;
        }

        int joinStyle = BasicStroke.JOIN_MITER;
        switch (currAttribute.getJoin()) {
            case BEVEL:
                joinStyle = BasicStroke.JOIN_BEVEL;
                break;
            case MITTER:
                joinStyle = BasicStroke.JOIN_MITER;
                break;
            case ROUND:
                joinStyle = BasicStroke.JOIN_ROUND;
                break;
        }

        if (currAttribute.getDash() == null) {
            basic = new BasicStroke(
                    (float) (Math.abs(currAttribute.getWidth())),
                    capStyle, joinStyle, (float) Math.abs(currAttribute.getMiterLimit()));
        } else {
            basic = new BasicStroke(
                    (float) (Math.abs(currAttribute.getWidth())),
                    capStyle, joinStyle, (float) Math.abs(currAttribute.getMiterLimit()),
                    GeometryUtils.doubleToFloat(currAttribute.getDash()), (float) currAttribute.getDashPhase());
        }
        graphics2D.setStroke(basic);
    }


    @Override
    public void lockAttribute() {
        lockAttribute = currAttribute;
    }

    @Override
    public void unlockAttribute() {
        lockAttribute = null;
    }

    // TODO Разобраться с этой ерундой.

    /**
     * Неизвестный метод.
     */
    private void setLockAttribute() {
        if (lockAttribute == null)
            return;
        if (lockAttribute.getWidth() != -1)
            currAttribute.setWidth(lockAttribute.getWidth());
    }


    @Override
    public void drawLine(boolean closed, List<? extends BasePoint2D> points) {
        Path2D polyline = awtPolyline(closed, points);
        graphics2D.draw(polyline);
    }

    @Override
    public void fillShape(List<? extends BasePoint2D> points) {
        Path2D polyline = awtPolyline(true, points);
        graphics2D.fill(polyline);
    }


    @Override
    public void setFont(String name, int style, double size) {
        graphics2D.setFont(new Font(name, style & 0x03, (int) Math.round(size)));
    }

    @Override
    public void drawString(String txt, double x, double y) {
        graphics2D.drawString(txt, (float) x, (float) y);
    }

    @Override
    public BaseFrame2D getStringBounds(String txt, String name, int style, int size) {
        FontRenderContext fontRenderer = graphics2D.getFontRenderContext();
        return getStringBounds(fontRenderer, txt, name, style, size);
    }

    public static BaseFrame2D getStringBounds(FontRenderContext fontRenderer, String txt, String name, int style, int size) {
        if (fontRenderer == null)
            fontRenderer = new FontRenderContext(new AffineTransform(), null, null);
        Font tempFont = new Font(name, style, size);
        Rectangle2D bounds = tempFont.getStringBounds(txt, fontRenderer);
        BaseFrame2D frame = new BaseFrame2D(
                new BasePoint2D(bounds.getMinX(), bounds.getMinY()),
                new BasePoint2D(bounds.getMaxX(), bounds.getMaxY()));
        return frame;
    }

    @Override
    public void drawLinearGradient(double x, double y, double width,
                                   double height, int color1, int color2) {
        GradientPaint gradient = new GradientPaint(
                new java.awt.geom.Point2D.Double(x, y), new Color(color1, true),
                new java.awt.geom.Point2D.Double(x + width, y), new Color(color2, true));
        graphics2D.setPaint(gradient);
        graphics2D.fill(new Rectangle2D.Double(x, y, width, height));
    }


//	public void drawEllipse(SignPoint2D center, double width, double height) {
//		graphics2D.draw(new Ellipse2D.Double(center.getX(), center.getY(),
//				width, height));
//	}


    @Override
    public void getClip(List<BasePoint2D> points) {
        Shape shape = graphics2D.getClip();
        PathIterator it = shape.getPathIterator(null);
        for (; !it.isDone(); it.next()) {
            double[] coords = new double[6];
            int type = it.currentSegment(coords);
            switch (type) {
                case PathIterator.SEG_LINETO:
                    points.add(new BasePoint2D(coords[0], coords[1]));
                    break;
                case PathIterator.SEG_QUADTO:
                    points.add(new BasePoint2D(coords[0], coords[1]));
                    points.add(new BasePoint2D(coords[2], coords[3]));
                    break;
                case PathIterator.SEG_CUBICTO:
                    points.add(new BasePoint2D(coords[0], coords[1]));
                    points.add(new BasePoint2D(coords[2], coords[3]));
                    points.add(new BasePoint2D(coords[4], coords[5]));
                    break;
            }
        }
    }

    @Override
    public void setClip(List<? extends BasePoint2D> points) {
        Path2D polyline = awtPolyline(true, points);
        graphics2D.clip(polyline);
    }

    @Override
    public void pushClip() {
        clipStack.push(graphics2D.getClip());
    }

    @Override
    public void popClip() {
        if (!clipStack.isEmpty())
            graphics2D.setClip(clipStack.pop());
    }


    @Override
    public BaseMatrix2D getTransform() {
        double[] arg = new double[6];
        graphics2D.getTransform().getMatrix(arg);
        BaseMatrix2D matrix = new BaseMatrix2D(arg[0], arg[2], arg[4], arg[1], arg[3], arg[5]);
        return matrix;
    }

    @Override
    public void setTransform(BaseMatrix2D matrix) {
        graphics2D.setTransform(toAwt(matrix));
    }

    @Override
    public void pushTransform() {
        transformsStack.push(getTransform());
    }

    @Override
    public void popTransform() {
        setTransform(transformsStack.pop());
    }

    @Override
    public void transform(BaseMatrix2D matrix) {
        graphics2D.transform(toAwt(matrix));
    }

    @Override
    public BaseMatrix2D getBaseTransform() {
        return baseTransform;
    }

    @Override
    public void translate(double x, double y) {
        graphics2D.translate(x, y);
    }

    @Override
    public void scale(double kx, double ky) {
        graphics2D.scale(kx, ky);
    }

    @Override
    public void rotate(double angle) {
        graphics2D.rotate(angle);
    }

}
