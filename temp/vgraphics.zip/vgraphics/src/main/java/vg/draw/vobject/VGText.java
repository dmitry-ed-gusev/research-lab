package vg.draw.vobject;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import vg.draw.painting.IPainter;
import vg.draw.painting.LineParams;
import vg.geometry.GeometryDefaults;
import vg.geometry.GeometryProcessor;
import vg.geometry.GeometryUtils;
import vg.geometry.primitives.*;
import vg.utils.PlaneText;

import java.awt.*;
import java.awt.geom.Point2D;
import java.util.*;
import java.util.List;

/**
 * Text. Consists of:
 *  - field - rectangle with two points and angle
 *  - background - polygon, created by text strings
 *  - text
 */
public class VGText extends VGAbstractObject {

    private final static double BASE_FONT_SIZE = 16.0;
    public static final int HA_LEFT = 0x01;
    public static final int HA_RIGHT = 0x02;
    public static final int HA_CENTER = 0x03;
    public static final int VA_TOP = 0x04;
    public static final int VA_BOTTOM = 0x08;
    public static final int VA_CENTER = 0x0C;
    public static final int FS_BOLD = 0x01;
    public static final int FS_ITALIC = 0x02;
    public static final int FS_UNDERLINE = 0x04;
    public static final int FS_OVERLINE = 0x08;
    public static final int FS_LINETHROUGH = 0x10;

    private BasePoint2D p1 = new BasePoint2D();
    private BasePoint2D p2 = new BasePoint2D();
    private int alignment;
    private String fontName;
    private int fontStyle;
    private double fontSize;
    private VGShape textField = new VGShape();
    private VGShape textBackground = new VGShape();
    private int textForeground = 0xFF000000;
    private List<BasePoint2D> textLines = new ArrayList<BasePoint2D>();
    private String text;

    private PlaneText planeText = new PlaneText();
    private PlaneText altPlaneText = null;
    private BaseMatrix2D positionMatrix = new BaseMatrix2D();
    private static Map<String, String> fontMap = new HashMap<String, String>();

    static {
        // todo: comment tmp!!!
        /*
        try {
            //Document fontConfig = Xml.readXML(VGText.class.getResourceAsStream("/org/radar/common/grasy/vobject/resources/fonts/fontmap.xml"));
            Document fontConfig = Xml.readXML(VGText.class.getResourceAsStream("/vector/graphics/fonts/fontmap.xml"));
            Element rootElement = Xml.getRootElement(fontConfig);
            List<Element> entries = Xml.getChildren(rootElement, "map");
            for (Element entry : entries) {
                String os = entry.getAttribute("os");
                if (os == null ||
                        System.getProperty("os.name").toLowerCase().contains(os.toLowerCase())
                        //SignUtils.contains(System.getProperty("os.name"), false, os)
        ) {
                    String key = entry.getAttribute("in");
                    String value = entry.getAttribute("out");
                    fontMap.put(key, value);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        */
    }

    public VGText(
            String text,
            String fontName, int fontStyle, double fontSize,
            int alignment,
            VGPen fieldPen, VGBrush fieldBrush,
            VGPen backgroundPen, VGBrush backgroundBrush,
            int foregroundColor,
            BasePoint2D p1, BasePoint2D p2) {

        this.text = text;

        this.fontName = fontName != null ? fontName : Font.SANS_SERIF;
        this.fontStyle = fontStyle;
        this.fontSize = fontSize;

        this.alignment = alignment;

        this.textField.setPen(fieldPen);
        this.textField.setBrush(fieldBrush);
        this.textBackground.setPen(backgroundPen);
        this.textBackground.setBrush(backgroundBrush);
        this.textForeground = foregroundColor;

        //this.p1.init(p1);
        this.p1 = p1;
        //this.p2.init(p2);
        this.p2 = p2;

    }


    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj))
            return false;
        VGText other = (VGText) obj;

        VGPen textFieldPen = textField.getPen();
        VGBrush textFieldBrush = textField.getBrush();
        VGPen textBackgroundPen = textBackground.getPen();
        VGBrush textBackgroundBrush = textBackground.getBrush();
        VGPen otherTextFieldPen = other.textField.getPen();
        VGBrush otherTextFieldBrush = other.textField.getBrush();
        VGPen otherTextBackgroundPen = other.textBackground.getPen();
        VGBrush otherTextBackgroundBrush = other.textBackground.getBrush();
        return (text != null ? text.equals(other.text) : other.text == null) &&
                (fontName != null ? fontName.equals(other.fontName) : other.fontName == null) &&
                other.fontStyle == fontStyle &&
                other.fontSize == fontSize &&
                other.alignment == alignment &&
                (textFieldPen != null ? textFieldPen.equals(otherTextFieldPen) : otherTextFieldPen == null) &&
                (textFieldBrush != null ? textFieldBrush.equals(otherTextFieldBrush) : otherTextFieldBrush == null) &&
                (textBackgroundPen != null ? textBackgroundPen.equals(otherTextBackgroundPen) : otherTextBackgroundPen == null) &&
                (textBackgroundBrush != null ? textBackgroundBrush.equals(otherTextBackgroundBrush) : otherTextBackgroundBrush == null) &&
                textForeground == other.textForeground &&
                p1.equals(other.p1) &&
                p2.equals(other.p2);
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result ^= text.hashCode();
        result = GeometryUtils.cyclicShift(result, 3);
        result ^= fontName.hashCode();
        result ^= fontStyle;
        result ^= GeometryUtils.hashCode(fontSize);

        // При значениях выранвнивания. Могут быть одни нули.
        // В то время как перечень значений битов следующий
        // **01 - left
        // **10 - right
        // **11 - center
        // 01** - top
        // 10** - bottom
        // 11** - center
        // При значении 0000 по умолчанию в импортерах считается как center.
        // При вычислении hash необходимо привести все к одному числу.
        // В случае нулей в соответсвующих битах значение будет преведно к следующему виду:
        // **00 -> **11
        // 00** -> 11**

        int modifAlign = alignment & 0x0000000F;
        int hCenterVal = modifAlign & 0x03;
        if (hCenterVal == 0)
            modifAlign = modifAlign | 0x03;
        int wCenterVal = modifAlign & 0x0c;
        if (wCenterVal == 0)
            modifAlign = modifAlign | 0x0c;

        result ^= modifAlign << 13;

        result ^= textField.getPen() != null ? textField.getPen().hashCode() : 5243;
        result ^= textField.getBrush() != null ? textField.getBrush().hashCode() : 9971;
        result = GeometryUtils.cyclicShift(result, 29);
        result ^= textBackground.getPen() != null ? textBackground.getPen().hashCode() : 1173;
        result ^= textBackground.getBrush() != null ? textBackground.getBrush().hashCode() : 37751;
        result ^= textForeground;
        result ^= p1.hashCode();
        result = GeometryUtils.cyclicShift(result, 11);
        result ^= p2.hashCode();
        return result;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getFontName() {
        return fontName;
    }

    public void setFontName(String fontName) {
        this.fontName = fontName;
    }

    public int getFontStyle() {
        return fontStyle;
    }

    public void setFontStyle(int fontStyle) {
        this.fontStyle = fontStyle;
    }

    public double getFontSize() {
        return fontSize;
    }

    public void setFontSize(double fontSize) {
        this.fontSize = fontSize;
    }

    public VGPen getFieldPen() {
        return textField.getPen();
    }

    public void setFieldPen(VGPen pen) {
        textField.setPen(pen);
    }

    public VGBrush getFieldBrush() {
        return textField.getBrush();
    }

    public void setFieldBrush(VGBrush brush) {
        textField.setBrush(brush);
    }

    public List<BasePoint2D> getFieldShape() {
        List<BasePoint2D> points = new ArrayList<BasePoint2D>(textField.getPoints().size());
        for (BasePoint2D p : textField.getPoints())
            points.add(new BasePoint2D(p));
        return points;
    }

    public VGPen getBackgroundPen() {
        return textBackground.getPen();
    }

    public void setBackgroundPen(VGPen pen) {
        textBackground.setPen(pen);
    }

    public VGBrush getBackgroundBrush() {
        return textBackground.getBrush();
    }

    public void setBackgroundBrush(VGBrush brush) {
        textBackground.setBrush(brush);
    }

    public List<BasePoint2D> getBackgroundShape() {
        List<BasePoint2D> points = new ArrayList<BasePoint2D>(textBackground.getPoints().size());
        for (BasePoint2D p : textBackground.getPoints())
            points.add(new BasePoint2D(p));
        return points;
    }

    public int getTextColor() {
        return textForeground;
    }

    public void setTextColor(int color) {
        this.textForeground = color;
    }

    public int getAlignment() {
        return alignment;
    }

    public void setAlignment(int alignment) {
        this.alignment = alignment;
    }

    public BasePoint2D getP1() {
        return new BasePoint2D(p1);
    }

    public void setP1(BasePoint2D p1) {
        //this.p1.init(p1);
        this.p1 = p1;
    }

    public BasePoint2D getP2() {
        return new BasePoint2D(p2);
    }

    public void setP2(BasePoint2D p2) {
        //this.p2.init(p2);
        this.p2 = p2;
    }

    @Override
    public synchronized void calculate() {
        double fontSizeCoefficient = fontSize / BASE_FONT_SIZE;
        int ptAlign = alignment & 0x03;
        GeometryDefaults.ElementHAlignment hAlignment =
                ptAlign == HA_LEFT ? GeometryDefaults.ElementHAlignment.LEFT :
                        ptAlign == HA_RIGHT ? GeometryDefaults.ElementHAlignment.RIGHT :
                                GeometryDefaults.ElementHAlignment.CENTER;
        ptAlign = alignment & 0x0C;
        GeometryDefaults.ElementVAlignment vAlignment =
                ptAlign == VA_TOP ? GeometryDefaults.ElementVAlignment.TOP :
                        ptAlign == VA_BOTTOM ? GeometryDefaults.ElementVAlignment.BOTTOM :
                                GeometryDefaults.ElementVAlignment.CENTER;

        String altFontName = fontMap.get(fontName);
        if (altFontName != null) {
            altPlaneText = new PlaneText();
            Font altFont = new BaseFont2D(altFontName, fontStyle, Math.abs((int) BASE_FONT_SIZE));
            altPlaneText.setFont(altFont);
            altPlaneText.setHAlign(hAlignment);
            altPlaneText.setVAlign(vAlignment);
            altPlaneText.setText(text);
            altPlaneText.calculate();
        } else {
            altPlaneText = null;
        }

        planeText.setFont(new Font(fontName, fontStyle, Math.abs((int) BASE_FONT_SIZE)));
        planeText.setHAlign(hAlignment);
        planeText.setVAlign(vAlignment);
        planeText.setText(text);

        planeText.calculate();

        PlaneText ptInstance = altPlaneText != null ? altPlaneText : planeText;

        BaseRectangle2D fieldRectangle = new BaseRectangle2D(new BaseFrame2D(
                new BasePoint2D(p1).rotate(-angle, 0, 0),
                new BasePoint2D(p2).rotate(-angle, 0, 0))
        ).rotate(angle, 0, 0);
        textField.getPoints().clear();
        textField.getPoints().addAll(GeometryProcessor.createRectangleR(fieldRectangle));
        textField.setAngle(angle);
        textField.calculate();

        List<BasePoint2D> textBackgroundPoints = new ArrayList<BasePoint2D>(ptInstance.getLines().size() * 4);
        for (int i = 0, n = ptInstance.getLines().size(); i < n; i++) {
            PlaneText.Line line = ptInstance.getLines().get(i);
            java.awt.geom.Rectangle2D lineBounds = line.getBounds();
            double x0 = lineBounds.getX();
            double x1 = (x0 + lineBounds.getWidth());
            double y0 = lineBounds.getY();
            double y1 = (y0 + lineBounds.getHeight());
            textBackgroundPoints.add(i * 2, new BasePoint2D(x1, y0));
            textBackgroundPoints.add(i * 2, new BasePoint2D(x1, y1));
            textBackgroundPoints.add(i * 2, new BasePoint2D(x0, y1));
            textBackgroundPoints.add(i * 2, new BasePoint2D(x0, y0));
        }
        if (!textBackgroundPoints.isEmpty()) {
            textBackgroundPoints.add(new BasePoint2D(textBackgroundPoints.get(0)));
            textBackgroundPoints = GeometryUtils.simplifyPolyline(textBackgroundPoints, 1e-3);
        }
        textBackground.getPoints().clear();
        textBackground.getPoints().addAll(textBackgroundPoints);

        textLines.clear();
        for (int i = 0, n = ptInstance.getLines().size(); i < n; i++) {
            PlaneText.Line line = ptInstance.getLines().get(i);

            java.awt.geom.Rectangle2D lineBounds = line.getBounds();
            double x0 = lineBounds.getX();
            double x1 = x0 + lineBounds.getWidth();
            double y = lineBounds.getY() + ptInstance.getAscent();

            if (GeometryUtils.isOn(fontStyle, FS_UNDERLINE)) {
                double ly = y + ptInstance.getUnderlineOffset();
                textLines.add(new BasePoint2D(x0, ly));
                textLines.add(new BasePoint2D(x1, ly));
            }
            if (GeometryUtils.isOn(fontStyle, FS_OVERLINE)) {
                double ly = y + ptInstance.getOverlineOffset();
                textLines.add(new BasePoint2D(x0, ly));
                textLines.add(new BasePoint2D(x1, ly));
            }
            if (GeometryUtils.isOn(fontStyle, FS_LINETHROUGH)) {
                double ly = y + ptInstance.getStrikethroughOffset();
                textLines.add(new BasePoint2D(x0, ly));
                textLines.add(new BasePoint2D(x1, ly));
            }
        }
        Point2D point2D = ptInstance.getRelativeAnchor();
        BasePoint2D offset = fieldRectangle.getPoint(new BasePoint2D(point2D.getX(), point2D.getY()));
        positionMatrix = new BaseMatrix2D().scale(fontSizeCoefficient, fontSizeCoefficient, 0, 0)
                .rotate(angle, 0, 0).translate(offset);

        for (BasePoint2D p : textBackgroundPoints)
            ((BasePoint2D) p).transform(positionMatrix);
        for (BasePoint2D p : textLines)
            ((BasePoint2D) p).transform(positionMatrix);

        textBackground.setAngle(angle);
        textBackground.calculate();

        bounds.init(textBackground.getBounds());
    }

    @Override
    public boolean containsPoint(BasePoint2D point, double delta) {
        if (!bounds.contains(point)) return false;
        return GeometryProcessor.isPointInsidePolygon(point, textBackground.getPoints());
    }

    @Override
    public void paint(IPainter painter) {
        double fontSizeCoefficient = fontSize / BASE_FONT_SIZE;
        textField.paint(painter);
        textBackground.paint(painter);

        painter.setColor(textForeground);

        PlaneText ptInstance = altPlaneText != null ? altPlaneText : planeText;
        painter.setFont(ptInstance.getFont().getName(), fontStyle, Math.abs(BASE_FONT_SIZE));
        painter.setLineParams(new LineParams(ptInstance.getLineThickness() * fontSizeCoefficient));

//		IMatrix2D curTransform = painter.getTransform();
        painter.pushTransform();
        painter.transform(positionMatrix);


        for (int i = 0, n = ptInstance.getLines().size(); i < n; i++) {
            PlaneText.Line line = ptInstance.getLines().get(i);
            java.awt.geom.Rectangle2D lineBounds = line.getBounds();
            double x0 = lineBounds.getX();
            double y = lineBounds.getY() + ptInstance.getAscent();
            painter.drawString(line.getText(), x0, y);
        }

//		painter.setTransform(curTransform);
        painter.popTransform();

        for (int i = 0, n = textLines.size() - 1; i < n; i += 2)
            painter.drawLine(Arrays.asList(textLines.get(i), textLines.get(i + 1)));
    }

}
