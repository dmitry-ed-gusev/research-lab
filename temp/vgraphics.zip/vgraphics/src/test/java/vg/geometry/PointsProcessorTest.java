package vg.geometry;

/**
 * @author Gusev Dmitry (vinnypuhh)
 * @version 1.0 (DATE: 15.05.2016)
 */

// todo: implementation!!!

public class PointsProcessorTest {
}
