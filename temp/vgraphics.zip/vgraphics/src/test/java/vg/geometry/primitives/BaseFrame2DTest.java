package vg.geometry.primitives;

import org.junit.Assert;
import org.junit.Test;


/**
 * Class for BaseFrame2D tests.
 * @author DG.
 */
public class BaseFrame2DTest {

    @Test
    public void testNormalize() {
        Assert.assertEquals(new BaseFrame2D(0, 0, -1, -1).normalize().getSize(), new BasePoint2D(1, 1));
        Assert.assertEquals(new BaseFrame2D(0, 0, 1, 1).normalize().getSize(), new BasePoint2D(1, 1));
        Assert.assertEquals(new BaseFrame2D().normalize().getSize(), new BasePoint2D());
    }

    @Test
    public void testIntersects() {
        Assert.assertTrue(new BaseFrame2D().intersects(new BaseFrame2D()));
        Assert.assertTrue(new BaseFrame2D(0, 0, 1, 1).intersects(new BaseFrame2D(1, 1, -1, -1)));
        Assert.assertTrue(new BaseFrame2D(1, 1, 2, 2).intersects(new BaseFrame2D(1, 1, -1, -1)));

        Assert.assertFalse(new BaseFrame2D(Double.MIN_VALUE, Double.MIN_VALUE, 0, 0)
                .intersects(new BaseFrame2D(0.1, 0.1, Double.MAX_VALUE, Double.MAX_VALUE)));
    }

    @Test
    public void testContainsPoint() {
        Assert.assertTrue(new BaseFrame2D().containsPoint(new BasePoint2D()));
        Assert.assertTrue(new BaseFrame2D(0, 0, 1, 1).containsPoint(new BasePoint2D(0.5, 0.5)));
        Assert.assertTrue(new BaseFrame2D(0, 0, 1, 1).containsPoint(new BasePoint2D(1, 0.5)));

        Assert.assertFalse(new BaseFrame2D(0, 0, 1, 1).containsPoint(new BasePoint2D(2, 0.5)));
    }

    @Test
    public void testGetPointsSimple() {
        final BasePoint2D p1 = new BasePoint2D(1, 1);
        final BasePoint2D p2 = new BasePoint2D(2, 2);
        final BaseFrame2D baseFrame2D = new BaseFrame2D(p1, p2);
        Assert.assertTrue(p1 == baseFrame2D.getP1());
        Assert.assertEquals(p2, baseFrame2D.getP2());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateWithNull1() {
        new BaseFrame2D(null, new BasePoint2D());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateWithNull2() {
        new BaseFrame2D(null, new BasePoint2D());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateWithNull3() {
        new BaseFrame2D(null, new BasePoint2D());
    }

    @Test
    public void testGetSize() {
        Assert.assertEquals(new BaseFrame2D().getSize(), new BasePoint2D());
        Assert.assertEquals(new BaseFrame2D(0, 0, 1, 1).getSize(), new BasePoint2D(1, 1));
        Assert.assertEquals(
                new BaseFrame2D(0, 0, Double.MAX_VALUE, Double.MAX_VALUE).getSize(),
                new BasePoint2D(Double.MAX_VALUE, Double.MAX_VALUE));

        Assert.assertEquals(new BaseFrame2D(0, 0, -1, -1).getSize(), new BasePoint2D(-1, -1));
    }
}