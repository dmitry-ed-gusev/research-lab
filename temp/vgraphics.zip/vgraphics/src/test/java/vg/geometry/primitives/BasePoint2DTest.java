package vg.geometry.primitives;

import org.junit.*;

import static org.junit.Assert.*;
import static vg.geometry.GeometryDefaults.GEOMETRY_PRECISION;

/**
 * Tests for primitive - BasePoint2D.
 * @author Gusev Dmitry (vinnypuhh)
 * @version 1.0 (DATE: 23.05.2016)
 */
public class BasePoint2DTest {

    private static BasePoint2D zeroPoint = new BasePoint2D(0, 0);

    @BeforeClass // runs before all tests
    public static void setUp() {}

    @AfterClass // runs after all tests
    public static void tearDown() {}

    @Before // runs before every test
    public void beforeEveryTest() {}

    @After // runs after every test
    public void afterEveryTest() {}

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorWithNull() {
        new BasePoint2D(null);
    }

    @Test (expected = IllegalArgumentException.class)
    public void testConstructorWithPositiveInf() {
        new BasePoint2D(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
    }

    @Test (expected = IllegalArgumentException.class)
    public void testConstructorWithNegativeInf() {
        new BasePoint2D(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
    }

    @Test (expected = IllegalArgumentException.class)
    public void testConstructorWithNaN() {
        new BasePoint2D(Double.NaN, Double.NaN);
    }

    @Test
    public void testDefaultConstructor() {
        BasePoint2D pointDefault = new BasePoint2D();
        BasePoint2D zeroPoint = new BasePoint2D(0, 0);
        assertTrue("defConstr1", pointDefault.equals(zeroPoint));
        assertTrue("defConstr2", zeroPoint.equals(pointDefault));
        assertTrue("defConstr3", pointDefault.hashCode() == zeroPoint.hashCode());
    }

    @Test
    public void testCopyingConstructor() {
        BasePoint2D point = new BasePoint2D(4.0, 5.0);
        BasePoint2D copy = new BasePoint2D(point);
        assertTrue("copyConstr1", point.equals(copy));
        assertTrue("copyConstr2", copy.equals(point));
        assertTrue("copyConstr3", point.hashCode() == copy.hashCode());
    }

    @Test
    @SuppressWarnings({"EqualsWithItself", "ObjectEqualsNull"})
    public void testEquals() {
        // sources for test
        BasePoint2D point1 = new BasePoint2D(0, 0);
        BasePoint2D point2 = new BasePoint2D(0.9, 0.9);
        BasePoint2D point3 = new BasePoint2D(0.90000, 0.90000);
        // case #1
        assertTrue("eq1", zeroPoint.equals(zeroPoint));
        assertTrue("hash1", zeroPoint.hashCode() == zeroPoint.hashCode());
        // case #2
        assertTrue("eq2", zeroPoint.equals(point1));
        assertTrue("eq3", point1.equals(zeroPoint));
        assertTrue("hash2", zeroPoint.hashCode() == point1.hashCode());
        // case #3
        assertTrue("eq4", point2.equals(point3));
        assertTrue("eq5", point3.equals(point2));
        assertTrue("hash3", point2.hashCode() == point3.hashCode());
        // case #4
        assertFalse(point1.equals(null));
    }

    @Test
    public void testNotEquals() {
        BasePoint2D point1 = new BasePoint2D(2, 3);
        BasePoint2D point2 = new BasePoint2D(4, 5);
        // case #1
        assertFalse("notEq1", point1.equals(point2));
        assertFalse("notEq2", point2.equals(point1));
        assertFalse("notHash1", point1.hashCode() == point2.hashCode());
    }

    @Test
    public void testHashCode() {
        BasePoint2D pointXY = new BasePoint2D(12.34, 56.78);
        BasePoint2D pointYX = new BasePoint2D(56.78, 12.34);
        // case #1
        assertTrue("hash1", pointXY.hashCode() != pointYX.hashCode());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testPointsAdditionWithNull() {
        zeroPoint.add(null);
    }

    @Test
    public void testPointsAddition() {
        // sources for tests
        double x = 12.34;
        double y = 56.78;
        double deltaX = 0.06;
        double deltaY = 0.02;
        BasePoint2D point = new BasePoint2D(x, y);
        BasePoint2D pointForAddition = new BasePoint2D(deltaX, deltaY);
        BasePoint2D additionResult = new BasePoint2D(x + deltaX, y + deltaY);
        // case #1
        BasePoint2D added1 = point.add(deltaX, deltaY);
        assertTrue("addition1", added1.equals(additionResult));
        assertTrue("addition2", additionResult.equals(added1));
        assertTrue("addition3", added1.hashCode() == additionResult.hashCode());
        // case #2
        BasePoint2D added2 = point.add(pointForAddition);
        assertTrue("addition4", added2.equals(additionResult));
        assertTrue("addition5", additionResult.equals(added2));
        assertTrue("addition6", added2.hashCode() == additionResult.hashCode());
        // case #3
        BasePoint2D added3 = point.add(zeroPoint);
        assertTrue("addition7", point.equals(added3));
        assertTrue("addition8", added3.equals(point));
        assertTrue("addition9", added3.hashCode() == point.hashCode());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testPointsSubstractionWithNull() {
        zeroPoint.sub(null);
    }

    @Test
    public void testPointsSubstraction() {
        // sources for tests
        double x = 12.40;
        double y = 56.80;
        double deltaX = 0.06;
        double deltaY = 0.02;
        BasePoint2D point = new BasePoint2D(x, y);
        BasePoint2D pointForSubstraction = new BasePoint2D(deltaX, deltaY);
        BasePoint2D substractionResult = new BasePoint2D(x - deltaX, y - deltaY);
        // case #1
        BasePoint2D substracted1 = point.sub(deltaX, deltaY);
        assertTrue("substraction1", substracted1.equals(substractionResult));
        assertTrue("substraction2", substractionResult.equals(substracted1));
        assertTrue("substraction3", substracted1.hashCode() == substractionResult.hashCode());
        // case #2
        BasePoint2D substracted2 = point.sub(pointForSubstraction);
        assertTrue("substraction4", substracted2.equals(substractionResult));
        assertTrue("substraction5", substractionResult.equals(substracted2));
        assertTrue("substraction6", substracted2.hashCode() == substractionResult.hashCode());
        // case #3
        BasePoint2D substracted3 = point.sub(zeroPoint);
        assertTrue("substraction7", point.equals(substracted3));
        assertTrue("substraction8", substracted3.equals(point));
        assertTrue("substraction9", substracted3.hashCode() == point.hashCode());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testPointsMultiplicationWithNull() {
        zeroPoint.mul(null);
    }

    @Test
    public void testPointsMultiplication() {
        // sources for tests
        double x = 12.50;
        double y = 34.50;
        double mulX = 2.00;
        double mulY = 2.00;
        BasePoint2D point = new BasePoint2D(x, y);
        BasePoint2D pointForMultiplication = new BasePoint2D(mulX, mulY);
        BasePoint2D multiplicationResult = new BasePoint2D(x * mulX, y * mulY);
        // case #1
        BasePoint2D mul1 = point.mul(mulX, mulY);
        assertTrue("multiplication1", mul1.equals(multiplicationResult));
        assertTrue("multiplication2", multiplicationResult.equals(mul1));
        assertTrue("multiplication3", mul1.hashCode() == multiplicationResult.hashCode());
        // case #2
        BasePoint2D mul2 = point.mul(pointForMultiplication);
        assertTrue("multiplication4", mul2.equals(multiplicationResult));
        assertTrue("multiplication5", multiplicationResult.equals(mul2));
        assertTrue("multiplication6", mul2.hashCode() == multiplicationResult.hashCode());
        // case #3
        BasePoint2D mul3 = point.mul(zeroPoint);
        assertTrue("multiplication7", zeroPoint.equals(mul3));
        assertTrue("multiplication8", mul3.equals(zeroPoint));
        assertTrue("multiplication9", mul3.hashCode() == zeroPoint.hashCode());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testPointsDivisionWithNull() {
        zeroPoint.div(null);
    }

    @Test (expected = IllegalArgumentException.class)
    public void testPointsDivisionWithZero() {
        new BasePoint2D().div(zeroPoint);
    }

    @Test
    public void testPointsDivision() {
        // sources for tests
        double x = 12.50;
        double y = 34.50;
        double divX = 2.00;
        double divY = 2.00;
        BasePoint2D point = new BasePoint2D(x, y);
        BasePoint2D pointForDivision = new BasePoint2D(divX, divY);
        BasePoint2D divisionResult = new BasePoint2D(x / divX, y / divY);
        // case #1
        BasePoint2D div1 = point.div(divX, divY);
        assertTrue("division1", div1.equals(divisionResult));
        assertTrue("division2", divisionResult.equals(div1));
        assertTrue("division3", div1.hashCode() == divisionResult.hashCode());
        // case #2
        BasePoint2D div2 = point.div(pointForDivision);
        assertTrue("division4", div2.equals(divisionResult));
        assertTrue("division5", divisionResult.equals(div2));
        assertTrue("division6", div2.hashCode() == divisionResult.hashCode());
    }

    @Test
    public void testRotateOrthoAroundZeroPoint() {
        BasePoint2D point = new BasePoint2D(12, 34);
        BasePoint2D rotated1 = new BasePoint2D(-34, 12);
        BasePoint2D rotated2 = new BasePoint2D(-rotated1.getY(), rotated1.getX());
        BasePoint2D rotated3 = new BasePoint2D(-rotated2.getY(), rotated2.getX());

        BasePoint2D tmp = point.rotateOrtho();
        assertTrue("rotateOrtho1", rotated1.equals(tmp));
        assertTrue("rotateOrtho2", tmp.equals(rotated1));
        assertTrue("rotateOrtho3", rotated1.hashCode() == tmp.hashCode());

        tmp = tmp.rotateOrtho();
        assertTrue("rotateOrtho4", rotated2.equals(tmp));
        assertTrue("rotateOrtho5", tmp.equals(rotated2));
        assertTrue("rotateOrtho6", rotated2.hashCode() == tmp.hashCode());

        tmp = tmp.rotateOrtho();
        assertTrue("rotateOrtho7", rotated3.equals(tmp));
        assertTrue("rotateOrtho8", tmp.equals(rotated3));
        assertTrue("rotateOrtho9", rotated3.hashCode() == tmp.hashCode());

        tmp = tmp.rotateOrtho();
        assertTrue("rotateOrtho10", tmp.equals(point));
        assertTrue("rotateOrtho11", point.equals(tmp));
        assertTrue("rotateOrtho12", point.hashCode() == tmp.hashCode());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRotateOrthoAroundNullPoint() {
        zeroPoint.rotateOrtho(null);
    }

    @Test
    public void testRotateOrthoAroundPoint() {
        BasePoint2D point = new BasePoint2D(3, 1);
        BasePoint2D rotateCenter = new BasePoint2D(1, 1);
        BasePoint2D rotated1 = new BasePoint2D(1, 3);
        BasePoint2D rotated2 = new BasePoint2D(-1, 1);
        BasePoint2D rotated3 = new BasePoint2D(1, -1);

        BasePoint2D tmp = point.rotateOrtho(rotateCenter);
        assertTrue("rotateOrtho1", rotated1.equals(tmp));
        assertTrue("rotateOrtho2", tmp.equals(rotated1));
        assertTrue("rotateOrtho3", rotated1.hashCode() == tmp.hashCode());

        tmp = tmp.rotateOrtho(rotateCenter);
        assertTrue("rotateOrtho4", rotated2.equals(tmp));
        assertTrue("rotateOrtho5", tmp.equals(rotated2));
        assertTrue("rotateOrtho6", rotated2.hashCode() == tmp.hashCode());

        tmp = tmp.rotateOrtho(rotateCenter);
        assertTrue("rotateOrtho7", rotated3.equals(tmp));
        assertTrue("rotateOrtho8", tmp.equals(rotated3));
        assertTrue("rotateOrtho9", rotated3.hashCode() == tmp.hashCode());

        tmp = tmp.rotateOrtho(rotateCenter);
        assertTrue("rotateOrtho10", point.equals(tmp));
        assertTrue("rotateOrtho11", tmp.equals(point));
        assertTrue("rotateOrtho12", point.hashCode() == tmp.hashCode());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRotateAroundNullPoint() {
        zeroPoint.rotate(0, null);
    }

    @Test
    // todo: add more tests cases.
    public void testRotateAroundPoint() {
        BasePoint2D point = new BasePoint2D(3, 1);
        // case #1 - no rotation
        BasePoint2D result1 = point.rotate(0, 0, 0);
        assertTrue("rotate1", point.equals(result1));
        assertTrue("rotate2", result1.equals(point));
        assertTrue("rotate3", point.hashCode() == result1.hashCode());
    }

    @Test
    // todo: add more tests cases.
    public void testScale() {
        BasePoint2D point = new BasePoint2D(12.34, 56.78);
        // case #1 - no scale at [0; 0]
        BasePoint2D result1 = point.scale(1, 1, 0, 0);
        assertTrue("scale1", result1.equals(point));
        assertTrue("scale2", point.equals(result1));
        assertTrue("scale3", result1.hashCode() == point.hashCode());
        // case #2 - zero scale at [0; 0]
        BasePoint2D result2 = point.scale(0, 0, 0, 0);
        assertTrue("scale4", result2.equals(zeroPoint));
        assertTrue("scale5", zeroPoint.equals(result2));
        assertTrue("scale6", result2.hashCode() == zeroPoint.hashCode());
        // case #3 - 10x scale at [0; 0]
        BasePoint2D result3 = point.scale(10, 10, 0, 0);
        BasePoint2D result4 = new BasePoint2D(123.4, 567.8);
        assertTrue("scale7", result3.equals(result4));
        assertTrue("scale8", result4.equals(result3));
        assertTrue("scale9", result3.hashCode() == result4.hashCode());
    }

    @Test (expected = IllegalArgumentException.class)
    public void testTranslateOrthoWithNull() {
        zeroPoint.translateOrtho(0, null);
    }

    @Test (expected = IllegalStateException.class)
    public void testTranslateOrthoToItSelf() {
        zeroPoint.translateOrtho(0, zeroPoint);
    }

    @Test
    // todo: add more test cases.
    public void testTranslateOrtho() {
        BasePoint2D directionPoint = new BasePoint2D(2, 0);
        BasePoint2D point = new BasePoint2D(3, 0);
        BasePoint2D expected = new BasePoint2D(3, -1);
        BasePoint2D result = point.translateOrtho(1, directionPoint);
        // #case
        assertTrue("translateOrtho1", result.equals(expected));
        assertTrue("translateOrtho2", expected.equals(result));
        assertTrue("translateOrtho3", result.hashCode() == expected.hashCode());
    }

    @Test
    public void testInvert() {
        // #case for ZERO point
        BasePoint2D result1 = zeroPoint.invert();
        assertTrue("invert1", result1.equals(zeroPoint));
        assertTrue("invert2", zeroPoint.equals(result1));
        assertTrue("invert3", result1.hashCode() == zeroPoint.hashCode());

        // #case for usual point
        BasePoint2D result2 = new BasePoint2D(2, 2).invert();
        BasePoint2D expected = new BasePoint2D(0.5, 0.5);
        assertTrue("invert4", result2.equals(expected));
        assertTrue("invert5", expected.equals(result2));
        assertTrue("invert6", result2.hashCode() == expected.hashCode());
    }

    @Test (expected = IllegalArgumentException.class)
    public void testDistanceToPointWithNull() {
        zeroPoint.distanceToPoint(null);
    }

    @Test
    public void testDistanceToPoint() {
        assertEquals("distanceToPoint1", 0, zeroPoint.distanceToPoint(zeroPoint), GEOMETRY_PRECISION);
        assertEquals("distanceToPoint2", 1, zeroPoint.distanceToPoint(1, 0), GEOMETRY_PRECISION);
        assertEquals("distanceToPoint3", 2, new BasePoint2D(-1, 1).distanceToPoint(1, 1), GEOMETRY_PRECISION);
        assertEquals("distanceToPoint4", 2 * Math.sqrt(2), new BasePoint2D(-1, -1).distanceToPoint(1, 1), GEOMETRY_PRECISION);
    }

    @Test (expected = IllegalStateException.class)
    public void testNormalizeWithZeroVector() {
        zeroPoint.normalize();
    }

    @Test
    public void testNormalize() {
        BasePoint2D point = new BasePoint2D(0, 5);
        BasePoint2D result = point.normalize();
        BasePoint2D expected = new BasePoint2D(0, 1);
        // #case
        assertTrue("normalize1", result.equals(expected));
        assertTrue("normalize2", expected.equals(result));
        assertTrue("normalize3", result.hashCode() == expected.hashCode());
    }

    @Test (expected = IllegalArgumentException.class)
    public void testProjectOnTwoPointsBeginException() {
        zeroPoint.project(null, new BasePoint2D(10, 10));
    }

    @Test (expected = IllegalArgumentException.class)
    public void testProjectOnTwoPointsEndExceptiion() {
        zeroPoint.project(new BasePoint2D(10, 10), null);
    }

    @Test (expected = IllegalArgumentException.class)
    public void testAngleWrongStart() {
        zeroPoint.angle(new BasePoint2D(1, 2), null);
    }

    @Test (expected = IllegalArgumentException.class)
    public void testAngleWrongEnd() {
        zeroPoint.angle(null, new BasePoint2D(1, 2));
    }

    @Test (expected = IllegalArgumentException.class)
    public void testAngleWrongOnePoint() {
        zeroPoint.angle(null);
    }

    @Test
    public void testAngle() {
        //System.out.println("-> " + new BasePoint2D(2, 0).angle(new BasePoint2D(0, 2), new BasePoint2D(0, 0)));
        // todo: implement test cases!
    }

}
