package vg.geometry;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class GeometryUtilsTest {

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public final void stringToBooleanTestTrue() {
        assertTrue("Should be TRUE!", GeometryUtils.stringToBoolean("true"));
        assertTrue("Should be TRUE!", GeometryUtils.stringToBoolean("on"));
        assertTrue("Should be TRUE!", GeometryUtils.stringToBoolean("yes"));
        assertTrue("Should be TRUE!", GeometryUtils.stringToBoolean("1"));
    }

    @Test
    public final void stringToBooleanTestFalse() {
        assertFalse("Should be FALSE!", GeometryUtils.stringToBoolean("false"));
        assertFalse("Should be FALSE!", GeometryUtils.stringToBoolean(""));
        assertFalse("Should be FALSE!", GeometryUtils.stringToBoolean(null));
        assertFalse("Should be FALSE!", GeometryUtils.stringToBoolean("-1"));
    }

}