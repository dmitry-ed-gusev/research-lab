package ontiConfirm.dataModel;

/**
 * DTO-��������� �������.
 * @author Gusev Dmitry (019gus)
 * @version 2.0 (DATE: 20.07.2011)
*/

public final class OntiConfirmDTO
 {
  private final String documentNumber;
  private final String documentType;
  private final String mailingDate;

  public OntiConfirmDTO(String documentNumber, String documentType, String mailingDate)
   {
    this.documentNumber = documentNumber;
    this.documentType   = documentType;
    this.mailingDate    = mailingDate;
   }

  public String getDocumentNumber() {return documentNumber;}
  public String getDocumentType()   {return documentType;}
  public String getMailingDate()    {return mailingDate;}
 }