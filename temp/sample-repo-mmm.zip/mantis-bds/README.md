Mantis 1.1 Scripts
==================

# Project Information
**Project Owner**:
* Jan Becicka

**Gate Keepers**:
* Jan Becicka
* Pavel Benes
* Martin Bohacek
* Anton Chechel
* Jaromir Martinasek

**Code Review Approvals**:
* Pull Request must have 2 approvals. At least one from project Gate Keeper.

# Description
This repository holds scripts for Mantis 1.1 processing pipelines

# File structure is following:
```
├─ lib (shared scripts)
├─ model (scripts generated from the model)
|  └─ <source system location>-<source system name>
|     └─ <environment> (i.e. dev, test, prod)
|         └─ <pipeline step> (e.g. create-curated, eim-scd1, ...)
├─ pipeline (implementation of runtime pipeline steps)
|  ├─ raw (steps between 'landing' and 'raw' zones)
|  |  └─ <pipeline-step>
|  ├─ curated (steps between 'raw' and 'curated' zones)
|  |  └─ <pipeline-step>
|  └─ customer (steps between 'curated' and 'customer' zones)
|     └─ <pipeline-step>
└─ test_pipeline (implementation of test pipeline steps used for data verification/validation
   └─ <test_pipeline-step> (verification test for some pipeline step)
```

