/*
 * Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.csvgenerator;
import java.io.IOException;
import java.io.StringWriter;

import joptsimple.OptionParser;
import joptsimple.OptionSet;
import joptsimple.OptionSpec;

/**
 * 
 * @author Nickolay Gogolev
 *
 */

public class Main {
    
    public static void main(String[] args) throws IOException {
        
        OptionParser parser = new OptionParser();
        parser.allowsUnrecognizedOptions();
        parser.posixlyCorrect(true);

        // asking for help screen
        parser.accepts(CommandLineOption.OPTION_HELP.getParamName(),
                        CommandLineOption.OPTION_HELP.getParamDesc()).forHelp();
        // required options
        OptionSpec<String> sizeFile = parser
                        .accepts(CommandLineOption.OPTION_SIZE.getParamName(),
                                        CommandLineOption.OPTION_SIZE.getParamDesc())
                        .withRequiredArg().ofType(String.class).required();
   
        OptionSet optionSet = parser.parse(args);
        
        if (optionSet.has(CommandLineOption.OPTION_HELP.getParamName())) { // show help in case of asked for it
            StringWriter stringWriter = new StringWriter();
            parser.printHelpOn(stringWriter);
            System.out.println(stringWriter.toString());
            return;
        }
        
        CSVGenerator csvGenerator = new CSVGenerator();
        try {
            csvGenerator.generateData(optionSet.valueOf(sizeFile));
        } catch (InterruptedException e) {
            System.err.println("Thread was interrupted "+ e);
        }
        
    }

}
