/*
 * Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.csvgenerator;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.hive.hcatalog.data.schema.HCatFieldSchema;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.io.Writer;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicLong;

/**
 * CSV Generator. Generation CSV file with different size
 * @author Nikolay Gogolev
 *
 */

public class CSVGenerator {
    private static final String OUTPUT_CSV = "output.csv";
    private static final int OFFSET = 2;
    private static final int MAX_STRING_LENGTH = 10;
    private static final int CHAR_LENGTH = 10;
    private static final long ROW_SIZE = 210;
    private static final int SIZE = 1024;
    private static final int MAX_NANOS = 999999999;
    private static final Random RANDOM = new Random();
    private static AtomicLong atomicLong = new AtomicLong();
    private static final String EXTRACT_DTTM= "2016-12-05-18-49-23";
    private static final long LOAD_ID = 10;
   
    private static Writer writer;

    public void generateData(String input) throws InterruptedException, IOException {
        HCatFieldSchema.Type[] typesToGenerate = getSchema();

        long start = System.currentTimeMillis();
        int threadSize = Runtime.getRuntime().availableProcessors() * 2;
        CountDownLatch latch = new CountDownLatch(threadSize);
        long countBySize = getCountBySize(input);
        final Writer writer = getWriter();
        
        for(int i=0; i<threadSize; i++) {
            Thread thread = new Thread(new Runnable() {
                public void run() {
                    try {
                        generateCSV(typesToGenerate, (int) (countBySize/(threadSize*ROW_SIZE)), writer);
                        latch.countDown();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
            
            thread.start();
        }
        long currentFileSize = 0;
        
        while (countBySize >= currentFileSize) {
            File file = new File(OUTPUT_CSV);
            currentFileSize = file.length();
            long status = currentFileSize  * 100 / countBySize;
            
            if(status >= 100L) {
                status = 100L;
                System.out.println("Generation finished on " + status  + "%");
            }
            
            System.out.println("Generation finished on " + status  + "%");
            Thread.sleep(2000);
        }
        
        latch.await();
        writer.close();
        long l = System.currentTimeMillis() - start;
        System.out.println("Time generation were " + l/1000 + "seconds");
    }

    private HCatFieldSchema.Type[] getSchema() {
        HCatFieldSchema.Type[] typesToGenerate = new HCatFieldSchema.Type[]{
                HCatFieldSchema.Type.BOOLEAN, HCatFieldSchema.Type.TINYINT, HCatFieldSchema.Type.SMALLINT,
                HCatFieldSchema.Type.INT, HCatFieldSchema.Type.BIGINT, HCatFieldSchema.Type.FLOAT,
                HCatFieldSchema.Type.DOUBLE, HCatFieldSchema.Type.DECIMAL, HCatFieldSchema.Type.STRING,
                HCatFieldSchema.Type.CHAR, HCatFieldSchema.Type.VARCHAR, HCatFieldSchema.Type.DATE,
                HCatFieldSchema.Type.TIMESTAMP};
        return typesToGenerate;
    }

    private void generateCSV(HCatFieldSchema.Type[] typesToGenerate, int rowsCount, Writer writer) throws IOException {
            for (int rowNum = 0; rowNum < rowsCount; rowNum++) {
                String row = generateRow(typesToGenerate);
                writer.write(row);
            }
            writer.flush();
    }
    
    private Writer getWriter() throws IOException {
        if (writer == null) {
            writer = new BufferedWriter(new FileWriter(OUTPUT_CSV, true));
        }
        return writer;
    }
    
  
    private String generateRow(HCatFieldSchema.Type[] typesToGenerate) {
        StringBuilder row = new StringBuilder("\"" + String.valueOf(atomicLong.incrementAndGet()) + "\"");
        for (HCatFieldSchema.Type hiveType : typesToGenerate) {
            row.append(",").append("\"").append(generateValue(hiveType)).append("\"");
        }
        boolean deleteInd = RANDOM.nextBoolean();
     
        row.append(",").append("\"").append(deleteInd).append("\"").
            append(",").append("\"").append(EXTRACT_DTTM).append("\"").
            append(",").append("\"").append(LOAD_ID).append("\"");

        row.append("\n");
        return row.toString();
    }
    
    private long getCountBySize(String inputSizeValue) {
        int inputSize = inputSizeValue.length();
        String measure = inputSizeValue.substring(inputSize - OFFSET, inputSize);
        String value = inputSizeValue.substring(0, inputSize - OFFSET);
        long result = Long.parseLong(value);
        
        switch (measure.toUpperCase()) {
        case "KB":
            result = result * SIZE;
            break;
        case "MB":
            result = result * SIZE * SIZE;
            break;
        case "GB":
            result = result * SIZE * SIZE * SIZE;
            break;
        case "TB":
            result = result * SIZE * SIZE * SIZE * SIZE;
            break;
        case "PB":
            result = result * SIZE * SIZE * SIZE * SIZE;
            break;
        default:
            throw new IllegalArgumentException("Illegal measure parameter. Should be in list KB, MB, GB, TB or PB");
        }
        
        return result;
    }

    private String generateValue(HCatFieldSchema.Type type) {
        switch (type) {
            case BOOLEAN:
                return String.valueOf(RANDOM.nextBoolean());
            case TINYINT:
                return generateInteger(Byte.MAX_VALUE);
            case SMALLINT:
                return generateInteger(Short.MAX_VALUE);
            case INT:
                return generateInteger(Integer.MAX_VALUE);
            case BIGINT:
                return String.valueOf(RANDOM.nextLong());
            case FLOAT:
                return String.valueOf(Float.MAX_VALUE * RANDOM.nextFloat());
            case DOUBLE:
                return String.valueOf(Double.MAX_VALUE * RANDOM.nextDouble());
            case DECIMAL:
                return String.format("%.5f", ((Math.random() * 900000) + 1000) / 1000.0 );
            case STRING:
                return RandomStringUtils.randomAlphanumeric(RANDOM.nextInt(MAX_STRING_LENGTH));
            case CHAR:
                return RandomStringUtils.randomAlphanumeric(CHAR_LENGTH);
            case VARCHAR:
                return RandomStringUtils.randomAlphanumeric(RANDOM.nextInt(MAX_STRING_LENGTH));
            case DATE:
                return generateDate();
            case TIMESTAMP:
                Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                timestamp.setNanos(RANDOM.nextInt(MAX_NANOS));
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return  formatter.format(new Date(timestamp.getTime()));
            default:
                throw new IllegalStateException("Unsupported Hive type " + type);
        }
    }
    
    public int randBetween(int start, int end) {
        return start + (int)Math.round(Math.random() * (end - start));
    }
    
    public String generateDate() {
        GregorianCalendar gc = new GregorianCalendar();
        int year = randBetween(1900, 2010);
        gc.set(gc.YEAR, year);
        int dayOfYear = randBetween(1, gc.getActualMaximum(gc.DAY_OF_YEAR));
        gc.set(gc.DAY_OF_YEAR, dayOfYear);
        return gc.get(gc.YEAR) + "-" + (gc.get(gc.MONTH) + 1) + "-" + gc.get(gc.DAY_OF_MONTH);
    }


    private String generateInteger(int upperBound) {
        boolean negative = RANDOM.nextBoolean();
        int value = RANDOM.nextInt(upperBound);
        int signedValue = negative ? -value : value;
        return String.valueOf(signedValue);
    }

}
