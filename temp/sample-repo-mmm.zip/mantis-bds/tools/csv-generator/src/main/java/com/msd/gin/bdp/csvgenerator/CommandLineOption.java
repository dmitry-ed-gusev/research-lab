/*
 * Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.csvgenerator;
/**
 * Command Line options 
 * @author Nikolay Gogolev
 */

public enum CommandLineOption {
    
    OPTION_HELP("help", "Print help/usage for the tool."),
    OPTION_SIZE("size", "Size of data, which should be generated. Available as KB, MB, GB, TB, PB");
    
    private final String paramName;
    private final String paramDesc;

    CommandLineOption(String paramName, String paramDesc) {
        this.paramName = paramName;
        this.paramDesc = paramDesc;
    }

    public String getParamName() {
        return paramName;
    }
   
    public String getParamDesc() {
        return paramDesc;
    }

}
