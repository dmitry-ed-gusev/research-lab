/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.client;

/**
 * Names of all verify steps
 * @author Mikhail Lipkovich
 */
public enum PipelineStep {
    VERIFY_SQOOP_TO_RAW,
    VERIFY_LANDING_TO_RAW,
    VERIFY_RAW_TO_CURATED,
    VERIFY_CURATED_TO_LATEST,
    VERIFY_HIVE_TO_DELTA_CSV,
    VERIFY_HIVE_TO_TERADATA_CSV,
    VERIFY_CLEANUP_OBSOLETE_PARTITIONS,
    VERIFY_CLEANUP_OBSOLETE_RECORDS,
    VERIFY_CSV_TO_ABSTRACT,
    VERIFY_CSV_TO_ASSEMBLY;
}
