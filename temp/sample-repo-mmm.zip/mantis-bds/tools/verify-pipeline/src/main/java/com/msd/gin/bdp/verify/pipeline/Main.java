/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline;

import com.msd.gin.bdp.verify.pipeline.client.DataExportException;
import com.msd.gin.bdp.verify.pipeline.client.VerifyPipelineConfig;
import com.msd.gin.bdp.verify.pipeline.client.VerifyPipelineDefaults;
import com.msd.gin.bdp.verify.pipeline.client.ConfigurationProvider;
import joptsimple.OptionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Entry point for all verify steps.
 *
 * @author Mikhail Lipkovich
 */
public final class Main {

    private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);

    private Main(){}

    public static void main(String[] args) {
        Runtime runtime = Runtime.getRuntime();
        ConfigParser configParser = new ConfigParser();

        try {
            VerifyPipelineConfig config = configParser.parseConfig(args);
            ConfigurationProvider.initialize(configParser.getRemainingOptions());

            LOGGER.info("Starting Verify-pipeline with following config: " + config);
            boolean verifyPassed = PipelineVerifier.verify(config);
            if (verifyPassed) {
                LOGGER.info("Verification PASSED");
                runtime.exit(VerifyPipelineDefaults.ExitStatus.PASSED.getValue());
            } else {
                LOGGER.error("Verification FAILED");
                runtime.exit(VerifyPipelineDefaults.ExitStatus.NOT_PASSED.getValue());
            }
        } catch (OptionException | IllegalArgumentException e) {
            LOGGER.error(e.getMessage(), e);
            LOGGER.info(String.format("Try '%s --%s' for more information.", Main.class.getName(),
                    ConfigParser.CmdLineOption.HELP.getParamName()));
            runtime.exit(VerifyPipelineDefaults.ExitStatus.MISUSE.getValue());
        } catch (IOException | DataExportException | RuntimeException e) {
            LOGGER.error("Unexpected exception", e);
            runtime.exit(VerifyPipelineDefaults.ExitStatus.GENERAL_ERROR.getValue());
        }
    }
}
