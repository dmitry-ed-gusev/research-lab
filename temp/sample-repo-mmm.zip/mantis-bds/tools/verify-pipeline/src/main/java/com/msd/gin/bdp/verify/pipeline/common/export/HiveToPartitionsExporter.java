/*
 * Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.common.export;

import com.msd.gin.bdp.verify.pipeline.client.DataExportException;

import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hive.hcatalog.api.HCatClient;
import org.apache.hive.hcatalog.api.HCatPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import au.com.bytecode.opencsv.CSVWriter;

/**
 * Exports partitions only from Hive(all partitions inside table) to CSV file
 * @author Nickolay Gogolev
 */

public class HiveToPartitionsExporter extends AbstractHiveExporter{
    
    private static final Logger LOGGER = LoggerFactory.getLogger(HiveToPartitionsExporter.class);
    
    private String hiveDatabase;
    private String hiveTable;
        
    public HiveToPartitionsExporter(String hiveDatabase, String hiveTable) {
        this.hiveDatabase = hiveDatabase;
        this.hiveTable = hiveTable;
    }

    @Override
    public void export(String outputFile) throws DataExportException {
        Path outputCSVPath = new Path(outputFile);
        
        try(FileSystem fileSystem = outputCSVPath.getFileSystem(hadoopConf); 
                        FSDataOutputStream fin = fileSystem.create(outputCSVPath);
                        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fin, StandardCharsets.UTF_8));
                        CSVWriter csvWriter = new CSVWriter(writer)) {
            HCatClient hiveClient = HCatClient.create(hiveConf);
            List<HCatPartition> partitions = hiveClient.getPartitions(hiveDatabase, hiveTable);
            List<String[]> csvResult = new ArrayList<>();
            for (HCatPartition hCatPartition : partitions) {
                List<String> tempList = new ArrayList<>();
                for(String value: hCatPartition.getValues()) {
                    tempList.add(value);
                }
                String[] stockArr = new String[tempList.size()];
                csvResult.add(tempList.toArray(stockArr));
            }
            
            csvWriter.writeAll(csvResult);
        } catch (IOException e) {
            String errorMsg = "Failed to create hive client from configuration.Database " + hiveDatabase + " hive table " + hiveTable
                            + " to file " + outputFile;
            LOGGER.error(errorMsg, e);
            throw new DataExportException(errorMsg, e);
        }
    } 
}
