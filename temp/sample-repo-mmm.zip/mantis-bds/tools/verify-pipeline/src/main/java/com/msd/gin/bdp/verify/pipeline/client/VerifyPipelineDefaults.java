/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.client;

/**
 * Holds some common constants/utility classes
 * @author Mikhail Lipkovich
 */
public class VerifyPipelineDefaults {

    private VerifyPipelineDefaults(){}

    /** Cmd line tool exit statuses enum. */
    public enum ExitStatus {
        NOT_PASSED(-1), PASSED(0), GENERAL_ERROR(1), MISUSE(2);

        private final int value;

        ExitStatus(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }
}
