/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline;

import com.msd.gin.bdp.verify.pipeline.client.PipelineStep;
import com.msd.gin.bdp.verify.pipeline.client.VerifyPipelineConfig;
import com.msd.gin.bdp.verify.pipeline.client.VerifyPipelineDefaults;
import joptsimple.OptionParser;
import joptsimple.OptionSet;
import joptsimple.OptionSpec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.List;

/**
 * Parses command line arguments for verify-pipeline tool
 * @author Mikhail Lipkovich
 */
public class ConfigParser {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigParser.class);
    private OptionSet optionSet;

    public VerifyPipelineConfig parseConfig(String[] args) throws IOException {
        OptionParser parser = new OptionParser();
        parser.allowsUnrecognizedOptions();
        parser.posixlyCorrect(true);

        OptionSpec<Void> help = parser
                .accepts(CmdLineOption.HELP.paramName, CmdLineOption.HELP.paramDesc).forHelp();

        OptionSpec<String> pipelineStep = parser
                .accepts(CmdLineOption.PIPELINE_STEP.paramName, CmdLineOption.PIPELINE_STEP.paramDesc)
                .withRequiredArg().ofType(String.class).required();
        OptionSpec<String> verifyCSV = parser
                .accepts(CmdLineOption.VERIFY_CSV.paramName, CmdLineOption.VERIFY_CSV.paramDesc)
                .withRequiredArg().ofType(String.class).required();
        OptionSpec<String> outputCSV = parser
                .accepts(CmdLineOption.OUTPUT_CSV.paramName, CmdLineOption.OUTPUT_CSV.paramDesc)
                .withRequiredArg().ofType(String.class).required();

        OptionSpec<String> exportDir = parser
                .accepts(CmdLineOption.EXPORT_DIR.paramName, CmdLineOption.EXPORT_DIR.paramDesc)
                .withRequiredArg().ofType(String.class);
        OptionSpec<String> hiveDatabase = parser
                .accepts(CmdLineOption.HIVE_DATABASE.paramName, CmdLineOption.HIVE_DATABASE.paramDesc)
                .withRequiredArg().ofType(String.class);
        OptionSpec<String> hiveTable = parser
                .accepts(CmdLineOption.HIVE_TABLE.paramName, CmdLineOption.HIVE_TABLE.paramDesc)
                .withRequiredArg().ofType(String.class);
        OptionSpec<String> partitionColumn = parser
                .accepts(CmdLineOption.PARTITION_COLUMN.paramName, CmdLineOption.PARTITION_COLUMN.paramDesc)
                .withRequiredArg().ofType(String.class);
        OptionSpec<String> partitionValue = parser
                .accepts(CmdLineOption.PARTITION_VALUE.paramName, CmdLineOption.PARTITION_VALUE.paramDesc)
                .withRequiredArg().ofType(String.class);
        OptionSpec<String> consumerCSV = parser
                .accepts(CmdLineOption.CONSUMER_CSV.paramName, CmdLineOption.CONSUMER_CSV.paramDesc)
                .withRequiredArg().ofType(String.class);
        OptionSpec<String> datasetName = parser
                        .accepts(CmdLineOption.ABSTRACT_DATASET.paramName, CmdLineOption.ABSTRACT_DATASET.paramDesc)
                        .withRequiredArg().ofType(String.class);
        OptionSpec<String> abstractKey = parser
                        .accepts(CmdLineOption.ABSTRACT_KEY.paramName, CmdLineOption.ABSTRACT_KEY.paramDesc)
                        .withRequiredArg().ofType(String.class);
        OptionSpec<String> assemblyKey = parser
                .accepts(CmdLineOption.ASSEMBLY_KEY.paramName, CmdLineOption.ASSEMBLY_KEY.paramDesc)
                .withRequiredArg().ofType(String.class);
        OptionSpec<String> abstractEnv = parser
                        .accepts(CmdLineOption.ABSTRACT_ENV.paramName, CmdLineOption.ABSTRACT_ENV.paramDesc)
                        .withRequiredArg().ofType(String.class);

        optionSet = parser.parse(args);

        if (optionSet.has(help)) {
            StringWriter stringWriter = new StringWriter();
            parser.printHelpOn(stringWriter);
            LOGGER.info(stringWriter.toString());
            Runtime.getRuntime().exit(VerifyPipelineDefaults.ExitStatus.PASSED.getValue()); // NOSONAR
        }

        return new VerifyPipelineConfig.Builder()
                .setPipelineStep(parsePipelineStep(optionSet.valueOf(pipelineStep)))
                .setVerifyCSV(optionSet.valueOf(verifyCSV))
                .setOutputCSV(optionSet.valueOf(outputCSV))
                .setExportDir(optionSet.valueOf(exportDir))
                .setHiveDatabase(optionSet.valueOf(hiveDatabase))
                .setHiveTable(optionSet.valueOf(hiveTable))
                .setPartitionColumn(optionSet.valueOf(partitionColumn))
                .setPartitionValue(optionSet.valueOf(partitionValue))
                .setConsumerCSV(optionSet.valueOf(consumerCSV))
                .setDatasetName(optionSet.valueOf(datasetName))
                .setAbstractKey(optionSet.valueOf(abstractKey))
                .setAssemblyKey(optionSet.valueOf(assemblyKey))
                .setDomain(optionSet.valueOf(abstractEnv))
                .build();
    }

    /**
     * Returns options that doesn't fit into {@link VerifyPipelineConfig}.
     * For example they can be hadoop-specific options
     * @return command line arguments that are not related to {@link VerifyPipelineConfig}.
     */
    public String[] getRemainingOptions() {
        if (optionSet == null) {
            throw new IllegalStateException("This method should be run after parseConfig method");
        }
        List<String> specificOptions = (List<String>) optionSet.nonOptionArguments();
        return specificOptions.toArray(new String[specificOptions.size()]);
    }

    enum CmdLineOption {
        HELP("help", "Print help/usage for the tool."),
        PIPELINE_STEP("pipeline-step", "Name of the pipeline step to perform. " +
                "Possible values: " + Arrays.toString(PipelineStep.values())),
        VERIFY_CSV("verify-csv", "CSV used for verification"),
        EXPORT_DIR("export-dir", "Directory which can be used for data exporting."),
        OUTPUT_CSV("output-csv", "CSV for exporting."),
        HIVE_DATABASE("database", "Hive database used for exporting CSV."),
        HIVE_TABLE("table", "Hive table used for exporting CSV."),
        PARTITION_COLUMN("partition-column", "Hive table's partition column name."),
        PARTITION_VALUE("partition-value", "Value of the Hive table partition column."),
        ABSTRACT_ENV("abstract-env", "Type of abstract environment"),
        ABSTRACT_KEY("abstract-key", "Key for abstract environment"),
        ASSEMBLY_KEY("assembly-key", "Key for assembly environment"),
        ABSTRACT_DATASET("dataset", "Abstract dataset name"),
        CONSUMER_CSV("consumer-csv", "CSV from consumer layer");

        private final String paramName;
        private final String paramDesc;

        CmdLineOption(String paramName, String paramDesc) {
            this.paramName = paramName;
            this.paramDesc = paramDesc;
        }

        public String getParamName() {
            return paramName;
        }

        public String getParamDesc() {
            return paramDesc;
        }

        /** Method used in unit testing. */
        public String getFullParamName() {
            return "--" + getParamName();
        }
    }

    private static PipelineStep parsePipelineStep(String step) {
        return PipelineStep.valueOf(step.replaceAll("-", "_").toUpperCase());
    }
}
