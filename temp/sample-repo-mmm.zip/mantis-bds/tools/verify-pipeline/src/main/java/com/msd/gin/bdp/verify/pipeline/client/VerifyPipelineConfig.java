/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.client;

import org.apache.commons.lang.StringUtils;

import java.util.Objects;

/**
 * Holds necessary configuration for all verify steps
 * @author Mikhail Lipkovich
 */
public class VerifyPipelineConfig {

    private final PipelineStep pipelineStep;
    private final String hiveDatabase;
    private final String hiveTable;
    private final String exportDir;
    private final String outputCSV;
    private final String consumerCSV;
    private final String verifyCSV;
    private final String partitionColumn;
    private final String partitionValue;
    private final String abstractKey;
    private final String assemblyKey;
    private final String dataset;
    private final String domain;

    private VerifyPipelineConfig(Builder builder) {
        this.pipelineStep = builder.pipelineStep;
        this.hiveDatabase = builder.hiveDatabase;
        this.hiveTable = builder.hiveTable;
        this.exportDir = builder.exportDir;
        this.outputCSV = builder.outputCSV;
        this.consumerCSV = builder.consumerCSV;
        this.verifyCSV = builder.verifyCSV;
        this.partitionColumn = builder.partitionColumn;
        this.partitionValue = builder.partitionValue;
        this.domain = builder.domain;
        this.abstractKey = builder.abstractKey;
        this.assemblyKey = builder.assemblyKey;
        this.dataset = builder.dataset;
    }

    public static class Builder {
        private PipelineStep pipelineStep;
        private String hiveDatabase;
        private String hiveTable;
        private String exportDir;
        private String outputCSV;
        private String consumerCSV;
        private String verifyCSV;
        private String partitionColumn;
        private String partitionValue;
        private String abstractKey;
        private String assemblyKey;
        private String dataset;
        private String domain;

        public Builder setPipelineStep(PipelineStep pipelineStep) {
            this.pipelineStep = pipelineStep;
            return this;
        }

        public Builder setHiveDatabase(String hiveDatabase) {
            this.hiveDatabase = hiveDatabase;
            return this;
        }

        public Builder setHiveTable(String hiveTable) {
            this.hiveTable = hiveTable;
            return this;
        }

        public Builder setExportDir(String exportDir) {
            this.exportDir = exportDir;
            return this;
        }

        public Builder setOutputCSV(String outputCSV) {
            this.outputCSV = outputCSV;
            return this;
        }

        public Builder setConsumerCSV(String consumerCSV) {
            this.consumerCSV = consumerCSV;
            return this;
        }

        public Builder setVerifyCSV(String verifyCSV) {
            this.verifyCSV = verifyCSV;
            return this;
        }

        public Builder setPartitionColumn(String partitionColumn) {
            this.partitionColumn = partitionColumn;
            return this;
        }

        public Builder setPartitionValue(String partitionValue) {
            this.partitionValue = partitionValue;
            return this;
        }
        
        public Builder setAbstractKey(String enigmaKey) {
            this.abstractKey = enigmaKey;
            return this;
        }

        public Builder setAssemblyKey(String enigmaKey) {
            this.assemblyKey = enigmaKey;
            return this;
        }
        
        public Builder setDatasetName(String collection) {
            this.dataset = collection;
            return this;
        }
        
        public Builder setDomain(String domain) {
            this.domain = domain;
            return this;
        }

        public VerifyPipelineConfig build() {
            Objects.requireNonNull(pipelineStep, "Pipeline pipelineStep is not set");
            Builder.requireNotEmpty(outputCSV, "Output CSV is not set");
            Builder.requireNotEmpty(verifyCSV, "Verify CSV is not set");

            switch (pipelineStep) {
                case VERIFY_LANDING_TO_RAW:
                case VERIFY_SQOOP_TO_RAW:
                case VERIFY_RAW_TO_CURATED:
                case VERIFY_CURATED_TO_LATEST:
                case VERIFY_CLEANUP_OBSOLETE_RECORDS:
                    Builder.requireNotEmpty(hiveDatabase, "Hive database is not set");
                    Builder.requireNotEmpty(hiveTable, "Hive table is not set");
                    Builder.requireNotEmpty(exportDir, "Export directory is not set");
                    break;
                case VERIFY_CLEANUP_OBSOLETE_PARTITIONS:
                    Builder.requireNotEmpty(hiveDatabase, "Hive database is not set");
                    Builder.requireNotEmpty(hiveTable, "Hive table is not set");
                    break;
                case VERIFY_HIVE_TO_DELTA_CSV:
                case VERIFY_HIVE_TO_TERADATA_CSV:
                    Builder.requireNotEmpty(consumerCSV, "Consumer CSV is not set");
                    break;
                    
                case VERIFY_CSV_TO_ABSTRACT:
                    Builder.requireNotEmpty(abstractKey, "Enigma key is not set");
                    Builder.requireNotEmpty(domain, "Abstract domain is not set");
                    Builder.requireNotEmpty(dataset, "Dataset name is not set");
                    break;
                case VERIFY_CSV_TO_ASSEMBLY:
                    Builder.requireNotEmpty(assemblyKey, "Enigma key is not set");
                    Builder.requireNotEmpty(domain, "Assembly domain is not set");
                    Builder.requireNotEmpty(dataset, "Dataset name is not set");
                    break;
                default:
                    throw new IllegalArgumentException("Unknown pipeline step: " + pipelineStep);
            }

            if (!StringUtils.isBlank(partitionColumn)) {
                Builder.requireNotEmpty(partitionValue, "Partition value should be set, because partition column is set");
            } else if (!StringUtils.isBlank(partitionValue)) {
                throw new IllegalArgumentException("Partition value shouldn't be set because partition column isn't set");
            }

            return new VerifyPipelineConfig(this);
        }

        private static void requireNotEmpty(String paramValue, String errorMsg) {
            if (StringUtils.isBlank(paramValue)) {
                throw new IllegalArgumentException(errorMsg);
            }
        }
    }

    public PipelineStep getPipelineStep() {
        return pipelineStep;
    }

    public String getHiveDatabase() {
        return hiveDatabase;
    }

    public String getHiveTable() {
        return hiveTable;
    }

    public String getExportDir() {
        return exportDir;
    }

    public String getOutputCSV() {
        return outputCSV;
    }

    public String getConsumerCSV() {
        return consumerCSV;
    }

    public String getVerifyCSV() {
        return verifyCSV;
    }

    public String getPartitionColumn() {
        return partitionColumn;
    }

    public String getPartitionValue() {
        return partitionValue;
    }
    
    public String getAbstractKey() {
        return abstractKey;
    }

    public String getAssemblyKey() {
        return assemblyKey;
    }

    public String getDataset() {
        return dataset;
    }

    public String getDomain() {
        return domain;
    }

    @Override
    public String toString() {
        return "VerifyPipelineConfig{" +
                "pipelineStep=" + pipelineStep +
                ", hiveDatabase='" + hiveDatabase + '\'' +
                ", hiveTable='" + hiveTable + '\'' +
                ", exportDir='" + exportDir + '\'' +
                ", outputCSV='" + outputCSV + '\'' +
                ", consumerCSV='" + consumerCSV + '\'' +
                ", verifyCSV='" + verifyCSV + '\'' +
                ", partitionColumn='" + partitionColumn + '\'' +
                ", partitionValue='" + partitionValue + '\'' +
                ", domain ='" + domain + '\'' +
                ", dataset ='" + dataset + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        VerifyPipelineConfig config = (VerifyPipelineConfig) o;

        if (pipelineStep != config.pipelineStep) {
            return false;
        }
        if (hiveDatabase != null ? !hiveDatabase.equals(config.hiveDatabase) : config.hiveDatabase != null) {
            return false;
        }
        if (hiveTable != null ? !hiveTable.equals(config.hiveTable) : config.hiveTable != null) {
            return false;
        }
        if (exportDir != null ? !exportDir.equals(config.exportDir) : config.exportDir != null) {
            return false;
        }
        if (!outputCSV.equals(config.outputCSV)) {
            return false;
        }
        if (consumerCSV != null ? !consumerCSV.equals(config.consumerCSV) : config.consumerCSV != null) {
            return false;
        }
        if (!verifyCSV.equals(config.verifyCSV)) {
            return false;
        }
        if (domain != null ? !domain.equals(config.domain) : config.domain != null) {
            return false;
        }
        if (dataset != null ? !dataset.equals(config.dataset) : config.dataset != null) {
            return false;
        }
        if (partitionColumn != null ? !partitionColumn.equals(config.partitionColumn) : config.partitionColumn != null) {
            return false;
        }
        return partitionValue != null ? partitionValue.equals(config.partitionValue) : config.partitionValue == null;
    }

    @Override
    public int hashCode() {
        int result = pipelineStep.hashCode();
        result = 31 * result + (hiveDatabase != null ? hiveDatabase.hashCode() : 0);
        result = 31 * result + (hiveTable != null ? hiveTable.hashCode() : 0);
        result = 31 * result + (exportDir != null ? exportDir.hashCode() : 0);
        result = 31 * result + outputCSV.hashCode();
        result = 31 * result + (consumerCSV != null ? consumerCSV.hashCode() : 0);
        result = 31 * result + verifyCSV.hashCode();
        result = 31 * result + (partitionColumn != null ? partitionColumn.hashCode() : 0);
        result = 31 * result + (partitionValue != null ? partitionValue.hashCode() : 0);
        result = 31 * result + (dataset != null ? dataset.hashCode() : 0);
        result = 31 * result + (domain != null ? domain.hashCode() : 0);
        return result;
    }

 
}
