/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.common.export;


import com.msd.gin.bdp.csv2hive.client.CSV2HiveException;
import com.msd.gin.bdp.csv2hive.job.HiveQueryExecutor;
import com.msd.gin.bdp.verify.pipeline.client.DataExportException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.metastore.HiveMetaStoreClient;
import org.apache.hadoop.hive.metastore.api.FieldSchema;
import org.apache.hadoop.hive.metastore.api.Table;
import org.apache.thrift.TException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Exports data from Hive to CSV file
 * @author Mikhail Lipkovich
 */
public class HiveToCSVExporter extends AbstractHiveExporter {

    private static final Logger LOGGER = LoggerFactory.getLogger(HiveToCSVExporter.class);
    private static final String EXPORT_QUERY =
            "INSERT OVERWRITE DIRECTORY '%s' ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde' " +
                    "WITH SERDEPROPERTIES ('serialization.encoding'='UTF-8')\n" +
                    "STORED AS TEXTFILE SELECT %s FROM `%s`.`%s`";
    private static final String PARTITION_FILTER = " WHERE `%s` = '%s'";

    private String hiveDatabase;
    private String hiveTable;
    private String exportDir;
    private String partitionColumn;
    private String partitionValue;

    public HiveToCSVExporter(String hiveDatabase, String hiveTable, String exportDir,
                             String partitionColumn, String partitionValue) {
        this.hiveDatabase = hiveDatabase;
        this.hiveTable = hiveTable;
        this.exportDir = exportDir;
        this.partitionColumn = partitionColumn;
        this.partitionValue = partitionValue;
    }

    @Override
    public void export(String outputFile) throws DataExportException {
        LOGGER.info("Exporting data from Hive table " + hiveDatabase + "." + hiveTable + ", partition " +
                        partitionColumn + "=" + partitionValue + " to file " + outputFile);     // NOSONAR

        Path exportPath = new Path(exportDir);
        Path outputCSVPath = new Path(outputFile);

        HiveQueryExecutor queryExecutor = new HiveQueryExecutor(hiveConf);
        try {
            preClean(exportPath, outputCSVPath);

            queryExecutor.execute(getExportQuery(exportPath));

            mergeFilesFromDir(exportPath, outputCSVPath, hadoopConf);
        } catch (CSV2HiveException | IOException | TException e) {
            String errorMsg = "Failed to export data from Hive database " + hiveDatabase +
                    " hive table " + hiveTable + " to file " + outputFile;
            LOGGER.error(errorMsg, e);
            throw new DataExportException(errorMsg, e);
        } finally {
            try {
                queryExecutor.close();
            } catch (IOException e) {
                LOGGER.warn("Failed to close query executor for hive database " + hiveDatabase +
                        " hive table " + hiveTable, e);
            }
        }
    }


    private String getExportQuery(Path outputDir) throws TException {
        HiveMetaStoreClient hiveClient = new HiveMetaStoreClient(hiveConf);
        Table table = hiveClient.getTable(hiveDatabase, hiveTable);
        StringBuilder cols = new StringBuilder();
        //Due to https://issues.apache.org/jira/browse/HIVE-15416
        //Decimal columns had to be cast to varchar before export
        table.getSd().getCols().forEach(col -> appendColumnName(cols, col));
        table.getPartitionKeys().forEach(col -> appendColumnName(cols, col));
        String exportQuery = String.format(EXPORT_QUERY, outputDir, cols.toString(), hiveDatabase, hiveTable);
        if (partitionColumn != null) {
            exportQuery = exportQuery + String.format(PARTITION_FILTER, partitionColumn, partitionValue);
        }
        return exportQuery;
    }

    private static void appendColumnName(StringBuilder sb, FieldSchema col) {
        if (sb.length() > 0) {
            sb.append(", ");
        }
        if (col.getType().toLowerCase(Locale.ENGLISH).startsWith("decimal")) {
            sb.append("cast(`").append(col.getName()).append("` as varchar(41))");
        } else {
            sb.append("`").append(col.getName()).append("`");
        }
    }

    private static void mergeFilesFromDir(Path filesToMergeDir, Path outputFile, Configuration hadoopConf)
            throws IOException {
        FileSystem fileSystem = outputFile.getFileSystem(hadoopConf);
        FileStatus[] filesToMerge = fileSystem.listStatus(filesToMergeDir, path -> !path.getName().startsWith("."));

        List<Path> filesToMergePaths = new ArrayList<>(filesToMerge.length);
        for (FileStatus fileStatus : filesToMerge) {
            if (fileStatus.getLen() != 0) {     // NOSONAR
                filesToMergePaths.add(fileStatus.getPath());  // NOSONAR
            }
        }

        if (filesToMergePaths.isEmpty()) {
            LOGGER.info("No data from Hive. Creating empty file " + outputFile);
            fileSystem.createNewFile(outputFile);
            return;
        }

        if (filesToMergePaths.size() == 1) {
            LOGGER.info("Only one file to merge. Renaming Hive output to file " + outputFile);
            fileSystem.rename(filesToMergePaths.get(0), outputFile);
            return;

        }

        LOGGER.info("Merging files " + filesToMergePaths + " to file " + outputFile);
        Path firstFile = filesToMergePaths.get(0);
        Path[] remainingFiles = filesToMergePaths.subList(1, filesToMergePaths.size()).
                toArray(new Path[filesToMergePaths.size() - 1]);
        fileSystem.concat(firstFile, remainingFiles);
        fileSystem.rename(firstFile, outputFile);
    }
}
