/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline;

import com.msd.gin.bdp.verify.pipeline.client.CSVExporterProvider;
import com.msd.gin.bdp.verify.pipeline.client.DataExportException;
import com.msd.gin.bdp.verify.pipeline.client.VerifyPipelineConfig;
import com.msd.gin.bdp.verify.pipeline.common.compare.FilesComparator;
import com.msd.gin.bdp.verify.pipeline.common.export.DataExporter;

import java.io.IOException;


/**
 * Main logic goes here. Checks that exported from source data is the same as data in some provided file.
 * @author Mikhail Lipkovich
 */
public class PipelineVerifier {

    private PipelineVerifier(){}

    /**
     * Runs verify process. Exports data from some source to CSV and compares it with verify CSV
     * @return true if verify succeed
     * @throws DataExportException if failed to export data to CSV
     * @throws IOException if error occurred during CSVs comparing
     */
    public static boolean verify(VerifyPipelineConfig config) throws DataExportException, IOException { // NOSONAR
        DataExporter exporter = CSVExporterProvider.getExporter(config);
        exporter.export(config.getOutputCSV());
        return FilesComparator.compare(config.getVerifyCSV(), config.getOutputCSV());
    }
}
