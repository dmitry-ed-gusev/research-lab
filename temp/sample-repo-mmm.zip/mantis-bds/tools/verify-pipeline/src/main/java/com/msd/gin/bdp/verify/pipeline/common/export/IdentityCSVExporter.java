/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.common.export;

import com.msd.gin.bdp.verify.pipeline.client.DataExportException;
import com.msd.gin.bdp.verify.pipeline.client.ConfigurationProvider;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Copies data from one path to another. Paths can belong both to local or distributed file system.
 * @author Mikhail Lipkovich
 */
public class IdentityCSVExporter implements DataExporter {

    private static final Logger LOGGER = LoggerFactory.getLogger(IdentityCSVExporter.class);

    private String inputCSV;
    private Configuration hadoopConf;

    public IdentityCSVExporter(String inputCSV) {
        this.inputCSV = inputCSV;
        this.hadoopConf = ConfigurationProvider.getHadoopConf();
    }

    @Override
    public void export(String outputFile) throws DataExportException {
        LOGGER.info("Exporting data from file " + inputCSV + " to file " + outputFile);

        Path inputFilePath = new Path(inputCSV);
        Path outputFilePath = new Path(outputFile);

        try (FileSystem inputFileFileSystem = inputFilePath.getFileSystem(hadoopConf);
             FileSystem outputFileFileSystem = outputFilePath.getFileSystem(hadoopConf)) {

            FileUtil.copy(inputFileFileSystem, inputFilePath,
                    outputFileFileSystem, outputFilePath, false, true, hadoopConf);
        } catch (IOException e) {
            String errorMsg = "Failed to export data from path " + inputCSV + " to path " + outputFile;
            LOGGER.error(errorMsg, e);
            throw new DataExportException(errorMsg, e);
        }
    }
}
