/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.common.export;


import com.msd.gin.bdp.verify.pipeline.client.DataExportException;

/**
 * Common interface for exporting data from some source to a file.
 * File can belong both to local or distributed file system and can be in any format.
 * Potential sources are Hive/HDFS/Abstract/RDBMS
 * @author Mikhail Lipkovich
 */
public interface DataExporter {

    /**
     * Exports data to specified path
     */
    void export(String outputFile) throws DataExportException;
}
