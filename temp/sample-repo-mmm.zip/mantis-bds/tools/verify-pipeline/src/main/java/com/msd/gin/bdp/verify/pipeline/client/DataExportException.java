package com.msd.gin.bdp.verify.pipeline.client;

/**
 * Exception indicates that some error occurred during files export
 * @author Mikhail Lipkovich
 */
public class DataExportException extends Exception {
    public DataExportException() {
        super();
    }

    public DataExportException(String message) {
        super(message);
    }

    public DataExportException(String message, Throwable cause) {
        super(message, cause);
    }

    public DataExportException(Throwable cause) {
        super(cause);
    }
}
