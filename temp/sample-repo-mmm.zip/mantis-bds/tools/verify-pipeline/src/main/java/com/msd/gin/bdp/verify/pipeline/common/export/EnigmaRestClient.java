/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.common.export;

import com.msd.gin.bdp.csv2abstract.model.RestResponse;
import com.msd.gin.bdp.csv2abstract.rest.RestClient;
import com.msd.gin.bdp.verify.pipeline.client.ConfigurationProvider;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.apache.commons.lang.ArrayUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.compress.CompressionCodec;
import org.apache.hadoop.io.compress.CompressionCodecFactory;
import org.apache.hadoop.io.compress.GzipCodec;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import au.com.bytecode.opencsv.CSVParser;
import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

import javax.ws.rs.core.Cookie;
import javax.ws.rs.core.MediaType;


/**
 * Download CSV file from Enigma and save it to path specified directory
 *
 * @author Gogolev Nickolay
 */

public class EnigmaRestClient extends RestClient {

    private String domain;

    private String collection;

    private String accessKey;
    private final Client jerseyClient = Client.create();
    private static final String ABSTRACT_PATTERN = "/v2/export/%s/";
    private static final String ASSEMBLY_PATTERN = "/api/export/";

    private static final String URL_ABSTRACT_PATTERN = "https://api.%s.abstract.merck.com";
    private static final String URL_ASSEMBLY_PATTERN = "https://%s.assembly.merck.com";

    private static final int HEADER_LINE_NUMBER = 1;
    private final EnigmaEngine engineType;
    public EnigmaRestClient(String domain, String accessKey, String collection, EnigmaEngine type) {
        this.domain = domain;
        this.accessKey = accessKey;
        this.collection = collection;
        this.engineType = type;
    }

    @Override
    protected String getPath() {
        switch (engineType) {
            case ASSEMBLY:
                return String.format(URL_ASSEMBLY_PATTERN, domain) + ASSEMBLY_PATTERN;
            default:
                return String.format(URL_ABSTRACT_PATTERN, domain) + String.format(ABSTRACT_PATTERN, accessKey);
        }
    }

    /**
     * Save content from Enigma to output CSV file
     *
     * @param path path to output CSV file
     * @throws IOException
     */

    public void writeCSVByPath(String path) throws IOException {
        RestResponse collectionInfo = executeGet(collection);
        String exportUrl = (String) collectionInfo.getBody().get("export_url");

        Path filePath = new Path(path);
        Configuration hadoopConf = ConfigurationProvider.getHadoopConf();
        FileSystem fileSystem = filePath.getFileSystem(hadoopConf);

        URL url = new URL(exportUrl);
        CompressionCodecFactory factory = new CompressionCodecFactory(new Configuration());
        CompressionCodec codec = factory.getCodecByClassName(GzipCodec.class.getName());
        InputStream is = codec.createInputStream(url.openStream());
        try (CSVReader reader = new CSVReader(new InputStreamReader(is, StandardCharsets.UTF_8),
                CSVParser.DEFAULT_SEPARATOR, CSVParser.DEFAULT_QUOTE_CHARACTER, HEADER_LINE_NUMBER);
             FSDataOutputStream fin = fileSystem.create(filePath);
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fin, StandardCharsets.UTF_8));
             CSVWriter csvWriter = new CSVWriter(writer)) {

            List<String[]> rows = reader.readAll();
            //Create array without serialId column. Always last column in export csv file
            List<String[]> modifiedRows = new ArrayList<>(rows.size());
            for (String[] row : rows) {
                modifiedRows.add((String[]) ArrayUtils.remove(row, row.length - 1));
            }

            csvWriter.writeAll(modifiedRows);
        }
    }

    public void writeAssemblyCSVByPath(String path) throws IOException {
        ClientResponse collectionInfo = executeAssemblyGetGet(collection);
        String entity = collectionInfo.getEntity(String.class);
        Path filePath = new Path(path);
        Configuration hadoopConf = ConfigurationProvider.getHadoopConf();
        FileSystem fileSystem = filePath.getFileSystem(hadoopConf);
        try (CSVReader reader = new CSVReader(new StringReader(entity),
                CSVParser.DEFAULT_SEPARATOR, CSVParser.DEFAULT_QUOTE_CHARACTER, HEADER_LINE_NUMBER);
             FSDataOutputStream fin = fileSystem.create(filePath);
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fin, StandardCharsets.UTF_8));
             CSVWriter csvWriter = new CSVWriter(writer)) {

            List<String[]> rows = reader.readAll();
            //Create array without serialId column. Always last column in export csv file
            /*List<String[]> modifiedRows = new ArrayList<>(rows.size());
            for (String[] row : rows) {
                modifiedRows.add((String[]) ArrayUtils.remove(row, row.length - 1));
            }
*/
            csvWriter.writeAll(rows);
        }
    }

    public RestResponse executeGet(String resource) {
        ClientResponse response;
        response = this.buildClient(resource, MediaType.APPLICATION_JSON_TYPE, null).get(ClientResponse.class);
        return this.buildResponse(null, response);
    }

    public ClientResponse executeAssemblyGetGet(String resource) {
        ClientResponse response = this.buildClient(resource, MediaType.APPLICATION_JSON_TYPE).get(ClientResponse.class);
        return response;
    }

    protected WebResource.Builder buildClient(String resource, MediaType mediaType) {

        String pathWithResource = this.getPath();
        if (resource != null) {
            pathWithResource = pathWithResource + resource;
        }

        return this.jerseyClient.resource(pathWithResource).accept(mediaType).header("Authorization", "Bearer " + accessKey);
    }
}

enum EnigmaEngine {
    ABSTRACT, ASSEMBLY;
}
