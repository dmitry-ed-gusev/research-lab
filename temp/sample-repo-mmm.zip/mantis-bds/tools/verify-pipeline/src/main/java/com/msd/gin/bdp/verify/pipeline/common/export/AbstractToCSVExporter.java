/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.common.export;

import com.msd.gin.bdp.verify.pipeline.client.DataExportException;

import java.io.IOException;

/**
 * Exports data from Abstract to CSV file
 * @author Mikhail Lipkovich
 * @author Nickolay Gogolev
 */
public class AbstractToCSVExporter implements DataExporter {
    
    private final String key;
    
    private final String domain;
    
    private final String collection;

    public AbstractToCSVExporter(String key, String domain, String collection) {
        this.key = key;
        this.domain = domain;
        this.collection = collection;
    }

    @Override
    public void export(String outputFile) throws DataExportException {
        try {
            EnigmaRestClient client = new EnigmaRestClient(domain, key, collection, EnigmaEngine.ABSTRACT);
            client.writeCSVByPath(outputFile);
        } catch (IOException e) {
            throw new DataExportException(e);
        }
    }
}
