/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.common.compare;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/**
 * Compares files line by line. Does not require that lines should be in the same order.
 * Keeps files in memory, so files should be small enough to fit into memory.
 * @author Mikhail Lipkovich
 */
public class FilesComparator {

    private static final Logger LOGGER = LoggerFactory.getLogger(FilesComparator.class);
    private static Configuration hadoopConf = new Configuration();

    private FilesComparator(){}

    /**
     * Compares two files line by line
     * @return true if files have the same data up to permutation of files lines.
     * @throws IOException if exception occurred during files reading
     */
    public static boolean compare(String expectedFile, String actualFile) throws IOException {
        LOGGER.info("Comparing file " + expectedFile + " with " + actualFile);
        Map<String, Integer> expectedLinesToCount = readFileLineByLine(expectedFile);
        Map<String, Integer> actualLinesToCount = readFileLineByLine(actualFile);

        return expectedLinesToCount.equals(actualLinesToCount);
    }

    /**
     * Reads file line by line and stores its content in map which maps line to number of its occurrences
     * @throws IOException if exception occurred during file reading
     */
    private static Map<String, Integer> readFileLineByLine(String file) throws IOException {
        Path filePath = new Path(file);
        Map<String, Integer> lineToCount = new HashMap<>();

        try (FileSystem fileSystem = filePath.getFileSystem(hadoopConf);
             BufferedReader fileReader = new BufferedReader(new InputStreamReader(fileSystem.open(filePath)))) {

            String line;
            while ((line = fileReader.readLine()) != null) {
                Integer previousValue = lineToCount.get(line);
                int newValue = 1;
                if (previousValue != null) {
                    newValue += previousValue;
                }
                lineToCount.put(line, newValue);
            }
        } catch (IOException e) {
            LOGGER.error("Failed to read data from file " + file, e);
            throw e;
        }

        return lineToCount;
    }
}
