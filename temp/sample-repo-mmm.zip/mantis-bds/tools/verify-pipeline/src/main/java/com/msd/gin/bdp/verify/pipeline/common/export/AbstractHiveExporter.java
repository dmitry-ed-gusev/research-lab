/*
 * Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.common.export;

import com.msd.gin.bdp.verify.pipeline.client.ConfigurationProvider;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.conf.HiveConf;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Abstract class for Hive Exporters. Common logic for those classes should be here
 * @author Gogolev Nicolay
 *
 */
public abstract class AbstractHiveExporter implements DataExporter {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractHiveExporter.class);
    
    protected Configuration hadoopConf = ConfigurationProvider.getHadoopConf();
    
    protected HiveConf hiveConf =  ConfigurationProvider.getHiveConf();
    
    /**
     * Cleans export directory and output file.
     * For some reason sometimes Hive fails to write output to directory if it is not empty so do it explicitly
     */
    
    protected void preClean(Path outputDir, Path outputFile) throws IOException {
        FileSystem fileSystem = outputFile.getFileSystem(hadoopConf);
        if(outputDir != null) {
            LOGGER.info("Cleaning directory " + outputDir);
            fileSystem.delete(outputDir, true);
        }
        
        LOGGER.info("Cleaning output file " + outputFile);
        fileSystem.delete(outputFile, false);
    }
}
