/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.common.export;

import com.msd.gin.bdp.verify.pipeline.client.DataExportException;

import java.io.IOException;

/**
 * Exports data from Assembly to CSV file
 * @author Konstantin Barzilovich
 */
public class AssemblyToCSVExporter implements DataExporter {

    private final String key;

    private final String domain;

    private final String dataset;

    public AssemblyToCSVExporter(String key, String domain, String dataset) {
        this.key = key;
        this.domain = domain;
        this.dataset = dataset;
    }

    @Override
    public void export(String outputFile) throws DataExportException {
        try {
            EnigmaRestClient client = new EnigmaRestClient(domain, key, dataset, EnigmaEngine.ASSEMBLY);
            client.writeAssemblyCSVByPath(outputFile);
        } catch (IOException e) {
            throw new DataExportException(e);
        }
    }
}
