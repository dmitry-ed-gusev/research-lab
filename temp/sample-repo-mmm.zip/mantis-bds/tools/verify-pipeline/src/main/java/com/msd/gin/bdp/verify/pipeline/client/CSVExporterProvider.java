/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.client;

import com.msd.gin.bdp.verify.pipeline.common.export.AbstractToCSVExporter;
import com.msd.gin.bdp.verify.pipeline.common.export.AssemblyToCSVExporter;
import com.msd.gin.bdp.verify.pipeline.common.export.DataExporter;
import com.msd.gin.bdp.verify.pipeline.common.export.HiveToCSVExporter;
import com.msd.gin.bdp.verify.pipeline.common.export.IdentityCSVExporter;
import com.msd.gin.bdp.verify.pipeline.common.export.HiveToPartitionsExporter;

/**
 * Returns appropriate {@link DataExporter} based on configuration
 * @author Mikhail Lipkovich
 */
public class CSVExporterProvider {

    private CSVExporterProvider(){}

    public static DataExporter getExporter(VerifyPipelineConfig config) {
        switch (config.getPipelineStep()) {
            case VERIFY_LANDING_TO_RAW:
            case VERIFY_SQOOP_TO_RAW:
            case VERIFY_RAW_TO_CURATED:
            case VERIFY_CURATED_TO_LATEST:
            case VERIFY_CLEANUP_OBSOLETE_RECORDS:
                return new HiveToCSVExporter(config.getHiveDatabase(), config.getHiveTable(), config.getExportDir(),
                        config.getPartitionColumn(), config.getPartitionValue());
            case VERIFY_HIVE_TO_DELTA_CSV:
            case VERIFY_HIVE_TO_TERADATA_CSV:
                return new IdentityCSVExporter(config.getConsumerCSV());
            case VERIFY_CLEANUP_OBSOLETE_PARTITIONS:
                return new HiveToPartitionsExporter(config.getHiveDatabase(), config.getHiveTable());
            case VERIFY_CSV_TO_ABSTRACT:
                return new AbstractToCSVExporter(config.getAbstractKey(), 
                            config.getDomain(), config.getDataset());
            case VERIFY_CSV_TO_ASSEMBLY:
                return new AssemblyToCSVExporter(config.getAssemblyKey(),
                        config.getDomain(), config.getDataset());
            default:
                throw new IllegalArgumentException("Unknown pipeline step: " + config.getPipelineStep());
        }
    }
}
