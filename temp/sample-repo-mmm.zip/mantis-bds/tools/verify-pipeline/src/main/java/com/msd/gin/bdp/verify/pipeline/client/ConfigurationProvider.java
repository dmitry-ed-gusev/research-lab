/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.client;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hive.conf.HiveConf;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.IOException;

/**
 * Class used for parsing input args for some specific sources like Hadoop/Hive.
 * Potentially can be used for parsing parameters for RDBMS or other sources
 * Does not thread-safe
 * @author Mikhail Lipkovich
 */
public class ConfigurationProvider {

    private static Configuration hadoopConf = new Configuration();
    private static HiveConf hiveConf = new HiveConf();

    private ConfigurationProvider(){}

    /**
     * Parses args and initializes configs for all sources
     */
    public static void initialize(String[] args) throws IOException {
        if (args == null) {
            hadoopConf = new Configuration();
            hiveConf = new HiveConf();
        }
        GenericOptionsParser parser = new GenericOptionsParser(hadoopConf, args);
        hadoopConf = parser.getConfiguration();
        hiveConf = new HiveConf(hadoopConf, Configuration.class);
    }

    /**
     * @return configuration for Hadoop
     */
    public static Configuration getHadoopConf() {
        return hadoopConf;
    }

    /**
     * @return configuration for Hive
     */
    public static HiveConf getHiveConf() {
        return hiveConf;
    }
}
