/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline;

import com.msd.gin.bdp.verify.pipeline.client.PipelineStep;
import com.msd.gin.bdp.verify.pipeline.client.VerifyPipelineConfig;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by Mikhail Lipkovich on 12/1/2016.
 */
public class ConfigParserTest {
    private static final ConfigParser CONFIG_PARSER = new ConfigParser();

    // sample config
    private static final VerifyPipelineConfig SAMPLE_CONFIG = new VerifyPipelineConfig.Builder()
            .setPipelineStep(PipelineStep.VERIFY_RAW_TO_CURATED)
            .setExportDir("export")
            .setOutputCSV("output.csv")
            .setVerifyCSV("verify.csv")
            .setHiveDatabase("database")
            .setHiveTable("table")
            .setConsumerCSV("consumer.csv")
            .setDomain("test")
            .setAbstractKey("key")
            .setDatasetName("dataset")
            .build();

    // correct full config
    private static final String[] CMD_LINE_OK  = {
            ConfigParser.CmdLineOption.PIPELINE_STEP.getFullParamName(), "verify_raw_to_curated",
            ConfigParser.CmdLineOption.EXPORT_DIR.getFullParamName(),    "export",
            ConfigParser.CmdLineOption.OUTPUT_CSV.getFullParamName(),    "output.csv",
            ConfigParser.CmdLineOption.VERIFY_CSV.getFullParamName(),    "verify.csv",
            ConfigParser.CmdLineOption.HIVE_DATABASE.getFullParamName(), "database",
            ConfigParser.CmdLineOption.HIVE_TABLE.getFullParamName(),    "table",
            ConfigParser.CmdLineOption.ABSTRACT_DATASET.getFullParamName(),    "dataset",
            ConfigParser.CmdLineOption.ABSTRACT_ENV.getFullParamName(),    "test",
            ConfigParser.CmdLineOption.ABSTRACT_KEY.getFullParamName(),    "key",
            ConfigParser.CmdLineOption.CONSUMER_CSV.getFullParamName(),  "consumer.csv"
    };

    // invalid (empty) config
    private static final String[] CMD_LINE_ERR = {
            ConfigParser.CmdLineOption.PIPELINE_STEP.getFullParamName(), "",
            ConfigParser.CmdLineOption.OUTPUT_CSV.getFullParamName(),    "",
            ConfigParser.CmdLineOption.VERIFY_CSV.getFullParamName(),    "",
            ConfigParser.CmdLineOption.HIVE_DATABASE.getFullParamName(), "",
            ConfigParser.CmdLineOption.HIVE_TABLE.getFullParamName(),    "",
            ConfigParser.CmdLineOption.CONSUMER_CSV.getFullParamName(),  ""
    };

    // config with missed dependency between parameters
    private static final String[] CMD_LINE_ERR_DEPENDENCY1  = {
            ConfigParser.CmdLineOption.PIPELINE_STEP.getFullParamName(), "verify_raw_to_curated",
            ConfigParser.CmdLineOption.OUTPUT_CSV.getFullParamName(),    "output.csv",
            ConfigParser.CmdLineOption.VERIFY_CSV.getFullParamName(),    "verify.csv",
            ConfigParser.CmdLineOption.CONSUMER_CSV.getFullParamName(),  "consumer.csv"
    };

    // config with missed dependency between parameters
    private static final String[] CMD_LINE_ERR_DEPENDENCY2  = {
            ConfigParser.CmdLineOption.PIPELINE_STEP.getFullParamName(), "verify_hive_to_delta_csv",
            ConfigParser.CmdLineOption.EXPORT_DIR.getFullParamName(),    "export",
            ConfigParser.CmdLineOption.OUTPUT_CSV.getFullParamName(),    "output.csv",
            ConfigParser.CmdLineOption.VERIFY_CSV.getFullParamName(),    "verify.csv",
            ConfigParser.CmdLineOption.HIVE_DATABASE.getFullParamName(), "database",
            ConfigParser.CmdLineOption.HIVE_TABLE.getFullParamName(),    "table"
    };

    @Test
    public void parseConfigOk() throws Exception {
        VerifyPipelineConfig config = CONFIG_PARSER.parseConfig(CMD_LINE_OK);
        assertEquals(config, SAMPLE_CONFIG);
    }

    @Test (expected = IllegalArgumentException.class)
    public void parseConfigErr() throws Exception {
        CONFIG_PARSER.parseConfig(CMD_LINE_ERR);
    }

    @Test (expected = IllegalArgumentException.class)
    public void parseConfigDependency1() throws Exception {
        CONFIG_PARSER.parseConfig(CMD_LINE_ERR_DEPENDENCY1);
    }

    @Test (expected = IllegalArgumentException.class)
    public void parseConfigDependency2() throws Exception {
        CONFIG_PARSER.parseConfig(CMD_LINE_ERR_DEPENDENCY2);
    }
}
