/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.client.common.export;

import com.msd.gin.bdp.verify.pipeline.client.DataExportException;
import com.msd.gin.bdp.verify.pipeline.common.export.DataExporter;
import com.msd.gin.bdp.verify.pipeline.common.export.IdentityCSVExporter;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;

/**
 * Created by Mikhail Lipkovich on 12/1/2016.
 */
public class IdentityCSVExporterTest {

    private static final String CSV_RESOURCE = "/csv";

    private static final String ORIGINAL_CSV = "events_original.csv";
    private static final String OUTPUT_CSV = "output.csv";

    private static final String SEPARATOR = File.separator;

    private String originalCSVFullPath;
    private String outputCSVFullPath;

    @Before
    public void setUp() throws DataExportException {
        String csvPath = getClass().getResource(CSV_RESOURCE).getPath();

        originalCSVFullPath = csvPath + SEPARATOR + ORIGINAL_CSV;
        outputCSVFullPath = csvPath + SEPARATOR + OUTPUT_CSV;

        DataExporter exporter = new IdentityCSVExporter(originalCSVFullPath);
        exporter.export(outputCSVFullPath);
    }

    @Test
    public void testFilesTheSame() throws IOException {
        FileUtils.contentEquals(new File(originalCSVFullPath), new File(outputCSVFullPath));
    }
}
