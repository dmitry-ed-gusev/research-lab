/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.client.common.compare;

import com.msd.gin.bdp.verify.pipeline.common.compare.FilesComparator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;

/**
 * Created by Mikhail Lipkovich on 12/1/2016.
 */
public class FilesComparatorTest {

    private static final String CSV_RESOURCE = "/csv";

    private static final String ORIGINAL_CSV = "events_original.csv";
    private static final String SHUFFLED_CSV = "events_shuffled.csv";
    private static final String WRONG_LENGTH_CSV = "events_wrong_length.csv";
    private static final String WRONG_ROW_CSV = "events_wrong_row";

    private static final String SEPARATOR = File.separator;

    private String originalCSVFullPath;
    private String shuffledCSVFullPath;
    private String wrongLengthCSVFullPath;
    private String wrongRowCSVFullPath;

    @Before
    public void setUp() {
        String csvPath = getClass().getResource(CSV_RESOURCE).getPath();

        originalCSVFullPath = csvPath + SEPARATOR + ORIGINAL_CSV;
        shuffledCSVFullPath = csvPath + SEPARATOR + SHUFFLED_CSV;
        wrongLengthCSVFullPath = csvPath + SEPARATOR + WRONG_LENGTH_CSV;
        wrongRowCSVFullPath = csvPath + SEPARATOR + WRONG_ROW_CSV;
    }

    @Test
    public void testShuffled() throws IOException {
        Assert.assertTrue(FilesComparator.compare(originalCSVFullPath, shuffledCSVFullPath));
    }

    @Test
    public void testWrongLength() throws IOException {
        Assert.assertFalse(FilesComparator.compare(originalCSVFullPath, wrongLengthCSVFullPath));
    }

    @Test
    public void testWrongRow() throws IOException {
        Assert.assertFalse(FilesComparator.compare(originalCSVFullPath, wrongRowCSVFullPath));
    }
}
