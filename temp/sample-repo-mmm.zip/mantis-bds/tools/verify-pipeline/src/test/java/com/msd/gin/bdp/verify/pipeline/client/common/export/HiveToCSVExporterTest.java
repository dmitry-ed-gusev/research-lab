/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.client.common.export;

import com.msd.gin.bdp.csv2hive.job.HiveQueryExecutor;
import com.msd.gin.bdp.verify.pipeline.client.DataExportException;
import com.msd.gin.bdp.verify.pipeline.common.export.HiveToCSVExporter;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;

/**
 * Hive To CSV exporter integration test
 * 
 * @author Nickolay Gogolev
 *
 */

public class HiveToCSVExporterTest  extends AbstractTestHiveExporter{
  
    private static final String PRTVALUE = "2016-12-12";
    private static final String EXPORTED_CSV = "output.csv";
    private static final String EXPECTED_CSV = "hive2csv.csv";
    private static final String DEST_PATH = "/tmp/verifystep1/";

    private String expectedCSVFullPath;
  
    @Before
    public void setUp() throws Exception {
        init();
        
        try(HiveQueryExecutor queryExecutor = new HiveQueryExecutor(hiveConf)) {
            queryExecutor.execute(String.format(IMPORT_QUERY_TEMPLATE, DATABASE_NAME, TABLE_NAME, PRTCOL, PRTVALUE));
            queryExecutor.execute(String.format(IMPORT_QUERY_TEMPLATE1, DATABASE_NAME, TABLE_NAME, PRTCOL, PRTVALUE));
            queryExecutor.execute(String.format(IMPORT_QUERY_TEMPLATE2, DATABASE_NAME, TABLE_NAME, PRTCOL, PRTVALUE));
            queryExecutor.execute(String.format(IMPORT_QUERY_TEMPLATE3, DATABASE_NAME, TABLE_NAME, PRTCOL, PRTVALUE));
            queryExecutor.execute(String.format(IMPORT_QUERY_TEMPLATE4, DATABASE_NAME, TABLE_NAME, PRTCOL, PRTVALUE));
        } catch (Exception e) {
            String errorMsg = "Failed to insert data to the Hive database " + DATABASE_NAME + ", hive table "
                            + TABLE_NAME;
            e.printStackTrace();
            throw new DataExportException(errorMsg, e);
        } 
    }

    @After
    public void cleanResources() throws IOException {
        cleanup();
    }

    @Test
    public void testHiveToCSV() throws IOException {

        String csvPath = getClass().getResource(CSV_RESOURCE).getPath();
        expectedCSVFullPath = csvPath + SEPARATOR + EXPECTED_CSV;
        String outputFilePath = DEST_PATH + EXPORTED_CSV;
        
        
        HiveToCSVExporter hiveToCSVExporter = new HiveToCSVExporter(DATABASE_NAME, TABLE_NAME, DEST_PATH, PRTCOL, PRTVALUE);
        try {
            hiveToCSVExporter.export(outputFilePath);
        } catch (DataExportException e) {
            e.printStackTrace();
        }
        
        File expected = new File(expectedCSVFullPath);
        File exported = new File(outputFilePath);
        Assert.assertTrue(expected.exists());
        Assert.assertTrue(exported.exists());
        
        FileUtils.contentEquals(expected, exported);
    }
}
