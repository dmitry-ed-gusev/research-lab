/*
 * Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.client.common.export;

import com.msd.gin.bdp.csv2hive.job.HiveQueryExecutor;
import com.msd.gin.bdp.verify.pipeline.client.DataExportException;
import com.msd.gin.bdp.verify.pipeline.common.export.HiveToPartitionsExporter;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;

/**
 * Hive to partitions integration test. Check that list of partitions should exactly the same as exported 
 * @author Nickolay Gogolev
 *
 */

public class HiveToPartitionsExporterTest extends AbstractTestHiveExporter{
    
    @Before
    public void start() throws Exception {
        init();
        
        try(HiveQueryExecutor queryExecutor = new HiveQueryExecutor(hiveConf)) {
            queryExecutor.execute(String.format(IMPORT_QUERY_TEMPLATE, DATABASE_NAME, TABLE_NAME, PRTCOL, "2016-12-10"));
            queryExecutor.execute(String.format(IMPORT_QUERY_TEMPLATE1, DATABASE_NAME, TABLE_NAME, PRTCOL, "2016-12-11"));
            queryExecutor.execute(String.format(IMPORT_QUERY_TEMPLATE2, DATABASE_NAME, TABLE_NAME, PRTCOL, "2016-12-12"));
            queryExecutor.execute(String.format(IMPORT_QUERY_TEMPLATE3, DATABASE_NAME, TABLE_NAME, PRTCOL, "2016-12-13"));
            queryExecutor.execute(String.format(IMPORT_QUERY_TEMPLATE4, DATABASE_NAME, TABLE_NAME, PRTCOL, "2016-12-14"));
        } catch (Exception e) {
            String errorMsg = "Failed to insert data to the Hive database " + DATABASE_NAME + ", hive table "
                            + TABLE_NAME;
            e.printStackTrace();
            throw new DataExportException(errorMsg, e);
        }
    }
    
    @Test
    public void checkPartitionsExport() throws DataExportException, IOException {
        String csvPath = getClass().getResource(CSV_RESOURCE).getPath();
        String expectedCSVFullPath = csvPath + SEPARATOR + "partitions_original.csv";
        String outputFilePath = "/tmp/partitions/output.csv";
        
        HiveToPartitionsExporter exporter = new HiveToPartitionsExporter(DATABASE_NAME, TABLE_NAME);
        exporter.export(outputFilePath);
        
        File expected = new File(expectedCSVFullPath);
        File exported = new File(outputFilePath);
        
        Assert.assertTrue(FileUtils.contentEquals(expected, exported));
    }
    
    @After
    public void clenup() throws IOException {
        cleanup();
    }

}
