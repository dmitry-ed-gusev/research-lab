/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline;

import com.msd.gin.bdp.verify.pipeline.client.DataExportException;
import com.msd.gin.bdp.verify.pipeline.client.PipelineStep;
import com.msd.gin.bdp.verify.pipeline.client.VerifyPipelineConfig;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;

/**
 * Created by Mikhail Lipkovich on 12/1/2016.
 */
public class PipelineVerifierTest {

    private static final String CSV_RESOURCE = "/csv";

    private static final String VERIFY_CSV = "events_original.csv";
    private static final String CONSUMER_CSV = "events_original.csv";
    private static final String OUTPUT_CSV = "output.csv";

    private static final String SEPARATOR = File.separator;

    private VerifyPipelineConfig config;

    @Before
    public void setUp() {
        String csvPath = getClass().getResource(CSV_RESOURCE).getPath();

        String outputCSVFFullPath = csvPath + SEPARATOR + OUTPUT_CSV;
        String verifyCSVFullPath = csvPath + SEPARATOR + VERIFY_CSV;
        String consumerCSVFullPath = csvPath + SEPARATOR + CONSUMER_CSV;

        config = new VerifyPipelineConfig.Builder()
                .setPipelineStep(PipelineStep.VERIFY_HIVE_TO_DELTA_CSV)
                .setOutputCSV(outputCSVFFullPath)
                .setVerifyCSV(verifyCSVFullPath)
                .setConsumerCSV(consumerCSVFullPath)
                .build();
    }

    @Test
    public void testHiveToDeltaCSV() throws IOException, DataExportException {
        Assert.assertTrue(PipelineVerifier.verify(config));
    }
}
