/*
 * Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.verify.pipeline.client.common.export;

import com.msd.gin.bdp.csv2hive.job.HiveQueryExecutor;
import com.msd.gin.bdp.verify.pipeline.client.DataExportException;
import com.msd.gin.bdp.verify.pipeline.common.export.HiveToCSVExporter;

import org.apache.commons.io.FileUtils;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.hdfs.HdfsConfiguration;
import org.apache.hadoop.hdfs.MiniDFSCluster;
import org.apache.hadoop.hive.conf.HiveConf;
import org.apache.hadoop.hive.metastore.HiveMetaStoreClient;
import org.apache.hadoop.hive.metastore.TableType;
import org.apache.hadoop.hive.metastore.api.FieldSchema;
import org.apache.hadoop.hive.metastore.api.SerDeInfo;
import org.apache.hadoop.hive.metastore.api.StorageDescriptor;
import org.apache.hadoop.hive.metastore.api.Table;
import org.apache.hadoop.hive.ql.io.orc.OrcSerde;
import org.apache.hadoop.hive.serde.serdeConstants;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public abstract class AbstractTestHiveExporter {

    protected static final String DATABASE_NAME = "default";

    protected static final String TABLE_NAME = "person";

    protected MiniDFSCluster miniCluster;

    protected FileSystem fileSystem;

    protected HiveConf hiveConf;

    protected static final String CSV_RESOURCE = "/csv";

    protected static final String PRTCOL = "percol";

    protected static final String SEPARATOR = File.separator;

    protected static final String IMPORT_QUERY_TEMPLATE = "INSERT INTO TABLE %s.%s PARTITION (%s='%s') VALUES "
                    + "('1',"
                    + "'Zoubir',"
                    + "'Stanton',"
                    + "'Zoubir Stanton',"
                    + "'127-32-4794',"
                    + "'F',"
                    + "'29.10.1956',"
                    + "'+2(771)598-51-21',"
                    + "'+3(805)801-37-52',"
                    + "'Bachelor of Arts (B.A.)',"
                    + "'12.09.1996',"
                    + "'866555543480',"
                    + "'Latvia',"
                    + "'Dominican Republic, Schumacher',"
                    + "'25 4690814','25.12.1997',"
                    + "'Al1957@mail.ru',"
                    + "'Kris1954@mail.ru')";

    protected static final String IMPORT_QUERY_TEMPLATE1 = "INSERT INTO TABLE %s.%s PARTITION (%s='%s') VALUES "
                    + "('2',"
                    + "'Zoubir',"
                    + "'Stanton',"
                    + "'Zoubir Stanton',"
                    + "'127-32-4794',"
                    + "'F',"
                    + "'29.10.1956',"
                    + "'+2(771)598-51-21',"
                    + "'+3(805)801-37-52',"
                    + "'Bachelor of Arts (B.A.)',"
                    + "'12.09.1996',"
                    + "'866555543480',"
                    + "'Latvia',"
                    + "'Dominican Republic, Schumacher',"
                    + "'25 4690814','25.12.1997',"
                    + "'Al1957@mail.ru',"
                    + "'Kris1954@mail.ru')";

    protected static final String IMPORT_QUERY_TEMPLATE2 = "INSERT INTO TABLE %s.%s PARTITION (%s='%s') VALUES "
                    + "('3',"
                    + "'Zoubir',"
                    + "'Stanton',"
                    + "'Zoubir Stanton',"
                    + "'127-32-4794',"
                    + "'F',"
                    + "'29.10.1956',"
                    + "'+2(771)598-51-21',"
                    + "'+3(805)801-37-52',"
                    + "'Bachelor of Arts (B.A.)',"
                    + "'12.09.1996',"
                    + "'866555543480',"
                    + "'Latvia',"
                    + "'Dominican Republic, Schumacher',"
                    + "'25 4690814','25.12.1997',"
                    + "'Al1957@mail.ru',"
                    + "'Kris1954@mail.ru')";

    protected static final String IMPORT_QUERY_TEMPLATE3 = "INSERT INTO TABLE %s.%s PARTITION (%s='%s') VALUES "
                    + "('4',"
                    + "'Zoubir',"
                    + "'Stanton',"
                    + "'Zoubir Stanton',"
                    + "'127-32-4794',"
                    + "'F',"
                    + "'29.10.1956',"
                    + "'+2(771)598-51-21',"
                    + "'+3(805)801-37-52',"
                    + "'Bachelor of Arts (B.A.)',"
                    + "'12.09.1996',"
                    + "'866555543480',"
                    + "'Latvia',"
                    + "'Dominican Republic, Schumacher',"
                    + "'25 4690814','25.12.1997',"
                    + "'Al1957@mail.ru',"
                    + "'Kris1954@mail.ru')";

    protected static final String IMPORT_QUERY_TEMPLATE4 = "INSERT INTO TABLE %s.%s PARTITION (%s='%s') VALUES "
                    + "('5',"
                    + "'Zoubir',"
                    + "'Stanton',"
                    + "'Zoubir Stanton',"
                    + "'127-32-4794',"
                    + "'F',"
                    + "'29.10.1956',"
                    + "'+2(771)598-51-21',"
                    + "'+3(805)801-37-52',"
                    + "'Bachelor of Arts (B.A.)',"
                    + "'12.09.1996',"
                    + "'866555543480',"
                    + "'Latvia',"
                    + "'Dominican Republic, Schumacher',"
                    + "'25 4690814','25.12.1997',"
                    + "'Al1957@mail.ru',"
                    + "'Kris1954@mail.ru')";


    protected void init() throws Exception {
        miniCluster = new MiniDFSCluster.Builder(new HdfsConfiguration()).numDataNodes(2).build();
        miniCluster.waitActive();
        fileSystem = miniCluster.getFileSystem();
     
        String location = new File(System.getProperty("test.hive.data.dir"), TABLE_NAME).getAbsolutePath();
        new File(location).delete();
        hiveConf = new HiveConf(miniCluster.getClass());
    
        // create test table
        HiveMetaStoreClient hiveClient = new HiveMetaStoreClient(hiveConf);
        hiveClient.dropTable(DATABASE_NAME, TABLE_NAME, true, true);

        String inputFormat = "org.apache.hadoop.hive.ql.io.orc.OrcInputFormat";
        String outputFormat = "org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat";
        int numBuckets = 16;
        Map<String, String> orcProps = new HashMap<String, String>();
        orcProps.put("orc.compress", "NONE");
        SerDeInfo serDeInfo = new SerDeInfo(OrcSerde.class.getSimpleName(), OrcSerde.class.getName(), orcProps);

        StorageDescriptor sd = new StorageDescriptor();
        sd.setCols(getPersonShema());
        sd.setLocation(location);
        sd.setInputFormat(inputFormat);
        sd.setOutputFormat(outputFormat);
        sd.setNumBuckets(numBuckets);
        sd.setSerdeInfo(serDeInfo);
        sd.setParameters(new HashMap<String, String>());

        Table tbl = getTable(sd, TABLE_NAME);

        // Add partition column
        List<FieldSchema> partitions = new ArrayList<FieldSchema>();
        partitions.add(new FieldSchema(PRTCOL, serdeConstants.STRING_TYPE_NAME, ""));
        tbl.setPartitionKeys(partitions);
        hiveClient.createTable(tbl);
    }

    protected void cleanup() throws IOException {
        fileSystem.close();
        miniCluster.shutdown();
    }

    protected List<FieldSchema> getPersonShema() {
        List<FieldSchema> cols = new ArrayList<FieldSchema>();
        cols.add(new FieldSchema("ID", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("FIRST_NAME", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("LAST_NAME", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("FULL_NAME", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("SSN", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("GENDER", serdeConstants.CHAR_TYPE_NAME + "(1)", ""));
        cols.add(new FieldSchema("DOB", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("PHONE1", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("PHONE2", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("EDUCATION", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("GRADUATEDATE", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("TAX_ID", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("CITIZENSHIP", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("BIRTHPLACE", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("PASSPORT", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("PASS_DATE", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("EMAIL1", serdeConstants.STRING_TYPE_NAME, ""));
        cols.add(new FieldSchema("EMAIL2", serdeConstants.STRING_TYPE_NAME, ""));
        return cols;
    }

    protected Table getTable(StorageDescriptor sd, String tableName) {
        Table tbl = new Table();
        tbl.setDbName(DATABASE_NAME);
        tbl.setTableName(TABLE_NAME);
        tbl.setSd(sd);
        tbl.setOwner(System.getProperty("user.name"));
        tbl.setParameters(new HashMap<String, String>());
        tbl.setViewOriginalText("");
        tbl.setViewExpandedText("");
        tbl.setTableType(TableType.EXTERNAL_TABLE.name());
        return tbl;
    }
}
