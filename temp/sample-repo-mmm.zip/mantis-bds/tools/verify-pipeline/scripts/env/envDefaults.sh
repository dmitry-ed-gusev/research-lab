#!/usr/bin/env bash
#Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
#All rights reserved.

export JAVA_CMD=${JAVA_CMD:-java}

export VERIFY_YARN_CMD="${VERIFY_YARN_CMD:-yarn}"
export VERIFY_YARN_QUEUE="${VERIFY_YARN_QUEUE:-}"

export HIVE_CLASSPATH=${HIVE_CLASSPATH:-/usr/hdp/current/hive-metastore/lib/*\
:/usr/hdp/current/hive-client/*:/usr/hdp/current/hive-client/conf/\
:/usr/hdp/current/hive-webhcat/share/hcatalog/*:/usr/hdp/current/hive-webhcat/share/webhcat/java-client/*}

export HADOOP_CLASSPATH=${HADOOP_CLASSPATH:-$(hadoop classpath)}