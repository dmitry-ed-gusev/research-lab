#!/usr/bin/env bash
#Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
#All rights reserved.

set -e

# Discover BASEDIR and LIBDIR
BASEDIR=$(dirname $0)/..
BASEDIR=$(cd ${BASEDIR} && pwd)
# @REPO@ will be replaced by maven
LIBDIR=$BASEDIR/@REPO@

# Invoke env setup
@ENV_SETUP@
[ -f "${BASEDIR}/bin/env/envDefaults.sh" ] && source "${BASEDIR}/bin/env/envDefaults.sh"

export HADOOP_CLASSPATH=${HADOOP_CLASSPATH}:${HIVE_CLASSPATH}:${LIBDIR}/*

# Prepare yarn command arguments. @jar.name@ will be replaced by maven
YARN_CMD_ARGS=("jar" "$LIBDIR/@jar.name@.jar" "$@")
if [ "$VERIFY_YARN_QUEUE" != "" ]
then
  YARN_CMD_ARGS=("${YARN_CMD_ARGS[@]}" "-Dmapreduce.job.queuename=$VERIFY_YARN_QUEUE" "-Dtez.queue.name=$VERIFY_YARN_QUEUE")
fi

echo "Executing yarn command:"
echo "  ${VERIFY_YARN_CMD} ${YARN_CMD_ARGS[@]}"
"${VERIFY_YARN_CMD}" "${YARN_CMD_ARGS[@]}"