/*
 * Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
 * All rights reserved.
 */
package com.msd.gin.bdp.remote.yarn.runner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.yarn.api.ApplicationConstants;
import org.apache.hadoop.yarn.api.records.ApplicationAttemptId;
import org.apache.hadoop.yarn.api.records.ContainerId;
import org.apache.hadoop.yarn.api.records.FinalApplicationStatus;
import org.apache.hadoop.yarn.client.api.AMRMClient;
import org.apache.hadoop.yarn.conf.YarnConfiguration;
import org.apache.hadoop.yarn.exceptions.YarnException;
import org.apache.hadoop.yarn.util.ConverterUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.apache.hadoop.net.NetUtils.getHostname;

import static java.nio.charset.Charset.defaultCharset;

/**
 * ApplicationMaster launching shell command in the same container.
 * Stops launched process if it spawns new job
 */
public class ShellRunnerAppMaster {

    private static final Log LOG = LogFactory.getLog(ShellRunnerAppMaster.class);
    private static final String RUN_JOB_LOG_MSG = "Running job: job_";
    private static final String EXTERNAL_JOB_MSG_PREFIX = "EXTERNAL_JOB_ID=";
    private static final String RUN_COMMAND_ENV = "REMOTE_COMMAND";
    private static final String RUN_USER_ENV = "REMOTE_USER";

    // Configuration
    private Configuration conf;

    // Handle to communicate with the Resource Manager
    private AMRMClient<?> amRMClient;

    private String resultMessage;
    private String user;
    private String command;
    private List<String> failedEnvs = new ArrayList<>();

    public ShellRunnerAppMaster() {
        // Nothing to do in constructor
    }

    /**
     * Initialize app master
     */
    public void init() {
        this.conf = new YarnConfiguration();
        Map<String, String> envs = System.getenv();

        assertEnvProperty(envs, ApplicationConstants.Environment.CONTAINER_ID.toString());
        assertEnvProperty(envs, ApplicationConstants.APP_SUBMIT_TIME_ENV);
        assertEnvProperty(envs, ApplicationConstants.Environment.NM_HOST.toString());
        assertEnvProperty(envs, ApplicationConstants.Environment.NM_HTTP_PORT.toString());
        assertEnvProperty(envs, ApplicationConstants.Environment.NM_PORT.toString());

        assertEnvProperty(envs, RUN_USER_ENV);
        assertEnvProperty(envs, RUN_COMMAND_ENV);

        user = envs.get(RUN_USER_ENV);
        command = envs.get(RUN_COMMAND_ENV);
        if (failedEnvs.isEmpty()) {
            ContainerId
                containerId =
                ConverterUtils.toContainerId(envs.get(ApplicationConstants.Environment.CONTAINER_ID.toString()));
            ApplicationAttemptId appAttemptID = containerId.getApplicationAttemptId();
            LOG.info("Application master for app" + ", appId="
                     + appAttemptID.getApplicationId().getId() + ", clustertimestamp="
                     + appAttemptID.getApplicationId().getClusterTimestamp()
                     + ", attemptId=" + appAttemptID.getAttemptId());
        } else {
            throw new IllegalArgumentException(
                String.format("Initialization failed, env variables not set:%s", failedEnvs.toString()));
        }

    }

    /**
     * Start app master (send start message to RM)
     *
     * @throws YarnException in case of error during registration
     */
    public void start() throws YarnException {
        LOG.info("Starting ApplicationMaster");
        try {
            amRMClient = AMRMClient.createAMRMClient();
            amRMClient.init(conf);
            amRMClient.start();
            // Register self with ResourceManager
            // This will start heart-beating to the RM
            amRMClient.registerApplicationMaster(getHostname(), -1, "");
        } catch (YarnException | IOException e) {
            throw new YarnException("Failed to register AM with RM", e);
        }
        LOG.info("ApplicationMaster registered");
    }

    /**
     * Stops app master as succeed or failed
     *
     * @param appStatus - resulting app status
     */
    public void finish(FinalApplicationStatus appStatus) {
        // When the application completes, it should send a finish application signal to the RM
        LOG.info("Application completed. Signalling finish to RM");
        if (appStatus == FinalApplicationStatus.FAILED) {
            LOG.error("App failed with message: " + resultMessage);
        }
        try {
            amRMClient.unregisterApplicationMaster(appStatus, resultMessage, null);
        } catch (YarnException | IOException ex) {
            LOG.error("Failed to unregister application", ex);
        }
        amRMClient.stop();
    }

    /**
     * Executes shell command
     *
     * @param args shell command
     * @return execution status (is success)
     * @throws IOException in case of shell process error
     */
    public FinalApplicationStatus execute(String[] args) throws IOException {
        if (args.length > 0) {
            throw new IllegalArgumentException("Arguments are not expected there");
        }
        LOG.info("Start remote command: " + command);
        ProcessBuilder pb = new ProcessBuilder();
        Process p = pb.command("bash").start();
        try (OutputStreamWriter writer = new OutputStreamWriter(p.getOutputStream());
             BufferedReader sout = new BufferedReader(new InputStreamReader(p.getInputStream(), defaultCharset()))) {
            writer.write("kinit -kt ./keytab " + user + "@MERCK.COM\n");
            writer.flush();
            writer.write(command);
            writer.close();
            while (p.isAlive()) {
                String line = sout.readLine();
                if (line == null) {
                    continue;
                }
                LOG.debug(line);
                if (line.contains(RUN_JOB_LOG_MSG)) {
                    LOG.info("Found external Job submit. Terminating shell runner.");
                    String id = line.substring(line.indexOf(RUN_JOB_LOG_MSG) + RUN_JOB_LOG_MSG.length());
                    LOG.info("External job ID: " + id);
                    this.resultMessage = EXTERNAL_JOB_MSG_PREFIX + id;
                    p.destroyForcibly();
                    return FinalApplicationStatus.SUCCEEDED;
                }
            }
        }
        if (p.exitValue() == 0) {
            return FinalApplicationStatus.SUCCEEDED;
        } else {
            StringBuilder sb = new StringBuilder("Remote command execution error:\n");
            try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getErrorStream(), defaultCharset()))) {
                br.lines().forEach(line -> sb.append(line).append("\n"));
            } catch (IOException | RuntimeException e) {
                LOG.error(e);
                sb.append("Can't read error stream: \n").append(e.toString());
            }
            resultMessage = sb.toString();
            return FinalApplicationStatus.FAILED;
        }
    }

    /**
     * Doesn't throw error. Collects all envs not properly set in the collection for more comprehensive log in the
     * coming. Don't forget to do something with it.
     *
     * @param env  env map taken from system
     * @param name env to check
     */
    private void assertEnvProperty(Map<String, String> env, String name) {
        if (!env.containsKey(name)) {
            failedEnvs.add(name);
        }
    }

    public static void main(String[] args) {
        ShellRunnerAppMaster appMaster = new ShellRunnerAppMaster();
        FinalApplicationStatus appStatus = FinalApplicationStatus.FAILED;
        appMaster.init();
        try {
            appMaster.start();
            appStatus = appMaster.execute(args);
        } catch (YarnException | IOException e) {
            LOG.error(e);
            appMaster.resultMessage = e.toString();
            System.exit(1);
        } finally {
            appMaster.finish(appStatus);
        }
    }
}
