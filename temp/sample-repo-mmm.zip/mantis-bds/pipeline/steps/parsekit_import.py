#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os
import time
import json
import base64
import requests
import warnings

from lib.common.errors import ArgumentError
from lib.common.errors import RestError

from pipeline.steps.base import MantisPipelineStep


class ParsekitImport(MantisPipelineStep):
    def setup(self):
        self.__setup_common()
        if self.args.cmd == "start":
            self.__setup_start()
        elif self.args.cmd == "progress":
            self.__setup_progress()

    def __setup_common(self):
        self.parsekit_url = self.configuration.get("parsekit_credentials.parsekit_url")
        self.parsekit_time_to_run = self.configuration.get("parsekit_settings.parsekit_time_to_run")

        self.pasekit_user = self.configuration.get("parsekit_credentials.parsekit_user")
        self.pasekit_password = self.configuration.get("parsekit_credentials.parsekit_password")
        self.wait_counter = self.configuration.get("parsekit_settings.parsekit_wait_counter")

        if self.args.enableWarnings == 'false':
            warnings.simplefilter('ignore', Warning)


    def __setup_start(self):
        self.verify_parameter_set("ingestType", "Argument 'ingestType' is not set.")
        self.verify_parameter_set("filePath", "Argument 'filePath' is not set.")
        self.verify_parameter_set("loadID", "Argument 'loadID' is not set.")
        self.verify_parameter_set("extractDTTM", "Argument 'extractDTTM' is not set.")
        self.verify_parameter_set("parserOrganization", "Argument 'parserOrganization' is not set.")
        self.verify_parameter_set("parserTagPrefix", "Argument 'parserTagPrefix' is not set.")
        self.verify_parameter_set("parserID", "Argument 'parserID' is not set.")

        if self.args.ingestType == 'delta':
            self.verify_parameter_set("sourceTableDeltaColumn", "Argument 'sourceTableDeltaColumn' is not set.")
            self.verify_parameter_set("deltaLowerBound", "Argument 'deltaLowerBound' is not set.")
            self.verify_parameter_set("deltaUpperBound", "Argument 'deltaUpperBound' is not set.")

        self.context_object_filename = "context-%s-%s.json" % (self.args.parserOrganization, self.args.parserID)
        self.parsers_url = "%s/%s/%s/%s" % (self.parsekit_url, "orgs", self.args.parserOrganization, "parsers")

    def __setup_progress(self):
        self.verify_parameter_set("parserRunURL", "Parser run URL is requered to get progress")

    def execute(self):
        if self.args.cmd == "start":
            self.__start_parsekit_import()
        elif self.args.cmd == "progress":
            self.__get_parsekit_import_progress()
        elif self.args.cmd == "test":
            self.logger.info("Test run of parsekit-import pipeline completed")
        else:
            raise ArgumentError(self.args.cmd,
                                "Missing or invalid subcommand. Please use -cmd switch to provide one.")

    def parsekit(self, command, url, data=None):
        """ Send REST request and return JSON response
        
            :type command: str
            :type url: str
            :type data: str
            :rtype: list[dict]
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        self.logger.debug("Executing command: %s" % command)
        self.logger.debug("Executing header: %s" % headers)
        self.logger.debug("Executing url: %s" % url)
        self.logger.debug("Executing data: %s" % data)
        if command == "GET":
            response = requests.get(url=url,
                                    auth=("%s@merck.com" % self.pasekit_user, self.pasekit_password),
                                    headers=headers,
                                    verify=False)
        elif command == "PUT":
            bin_dat = bytes(data)
            response = requests.put(url=url,
                                    data=bin_dat,
                                    auth=("%s@merck.com" % self.pasekit_user, self.pasekit_password),
                                    headers=headers,
                                    verify=False)
        elif command == "POST":
            bin_dat = bytes(data)
            response = requests.post(url=url,
                                     data=bin_dat,
                                     auth=("%s@merck.com" % self.pasekit_user, self.pasekit_password),
                                     headers=headers,
                                     verify=False)
        else:
            raise RuntimeError("Unknown command for curl request: %s" % command)

        if not response:
            raise RestError(response, "Rest error in parsekit request.")
        return response.json()

    def __start_parsekit_import(self):
        """
            :rtype: int
        """
        self.logger.debug("Getting list of available parsers from %s" % self.parsers_url)

        parser_list = self.parsekit(command="GET", url=self.parsers_url)
        self.logger.debug("Parser list: %s" % parser_list)

        parser_tag = str(self.args.parserTagPrefix) + str(self.args.parserID)
        self.logger.debug("Looking for parser with tag %s" % parser_tag)

        for key in parser_list:
            parser_tags = key["tags"]
            self.logger.debug("Tags: %s %s" % (key, parser_tags))

            if parser_tag in json.dumps(parser_tags):
                parser_info = key
                parser_id = parser_info["id"]
                parser_name = parser_info["name"]
                parser_state = parser_info["state"]
                self.logger.debug(
                    "Available parser found: %s with id: %s is %s" % (parser_name, parser_id, parser_state))

                parser_url = "%s/%s" % (self.parsers_url, parser_id)

                if parser_state != "enabled":
                    self.logger.debug("Getting state of the suspended parser %s" % parser_url)
                    parser_info = self.parsekit(command="GET", url=parser_url)

                    context_object = parser_info
                    context_object["state"] = "enabled"

                    self.logger.debug("Enabling the parser %s" % parser_url)
                    self.parsekit(command="PUT", url=parser_url, data=json.dumps(context_object))

                    while parser_state != "enabled":
                        self.logger.debug("Waiting for parsekit to become enabled #%s" % self.wait_counter)

                        if self.wait_counter > 0:
                            self.wait_counter -= 1
                        else:
                            raise RuntimeError("Could not enable the suspended ParseKit")

                        time.sleep(1)
                        parser_info = self.parsekit(command="GET", url=parser_url)
                        parser_state = parser_info["state"]

                        self.logger.debug("ParseKit state: %s" % parser_state)

                    self.logger.debug("ParseKit enabled again.")

                context_object = {
                    "context": {
                        "division": self.args.sourceSystemDivision,
                        "env": self.args.sourceSystemEnv,
                        "system": self.args.sourceSystem,
                        "location": self.args.sourceSystemLocation,
                        "tables": [
                            {
                                "table-schema": self.args.sourceTableSchema,
                                "table-name": self.args.sourceTable,
                                "ingest-type": self.args.ingestType,
                                "delta-column": self.args.sourceTableDeltaColumn,
                                "delta-lower-bound": self.args.deltaLowerBound,
                                "delta-upper-bound": self.args.deltaUpperBound,
                                "target-hdfs-file-path": self.args.filePath,
                                "load-id": self.args.loadID,
                                "extract-dttm": self.args.extractDTTM
                            }
                        ]
                    },
                    "ttr": self.parsekit_time_to_run
                }

                parser_run_url = "%s/%s" % (parser_url, "runs")
                self.logger.debug("Starting a parser run at %s" % parser_run_url)
                context_object = json.dumps(context_object)
                self.logger.debug("Context: \n %s" % context_object)

                parser_run_response = self.parsekit(command="POST", url=parser_run_url, data=context_object)
                self.logger.debug("Parser run response: %s" % json.dumps(parser_run_response))
                parser_run_id = parser_run_response["id"]

                if len(parser_run_id) == 0 or parser_run_id is None:
                    raise RuntimeError("Could not obtain the parser run id")
                else:
                    self.logger.info("Parsekit import started,\nParseKitRunID: \"%s\"" % os.path.join(parser_run_url, parser_run_id))
                    return 0

        raise RuntimeError("No suitable parsekit parser found (search for tag '%s'); exiting" % parser_tag)

    def __get_parsekit_import_progress(self):
        self.logger.debug("Getting the state of the the parser run at: %s" % self.args.parserRunURL)

        parser_run_response = self.parsekit(command="GET", url=self.args.parserRunURL)

        if "state" not in parser_run_response:
            self.logger.error("Could not obtain the parser run status, the response was: \n %s" % parser_run_response)
            raise RuntimeError("parsekit-import-progress pipeline step failed")
        else:
            parser_run_state = parser_run_response["state"]
            self.logger.info("Run state returned,\nParseKitRunState: \"%s\"" % parser_run_state)

            # Remove the properties stdout and stderr from the context object and write it to the console
            ctx_temp = parser_run_response
            ctx_temp.pop("stdout", "")
            ctx_temp.pop("stderr", "")
            self.logger.debug("\nContext: \n %s \n" % ctx_temp)

            # Write the Base64 encoded content of the stdout property to the stdout
            if "stdout" in parser_run_response:
                parser_run_stdout = parser_run_response["stdout"]

                if parser_run_stdout is not None:
                    self.logger.debug(base64.decodestring(parser_run_stdout))

            # Write the Base64 encoded content of the stderr property to the stderr
            if "stderr" in parser_run_response:
                parser_run_stderr = parser_run_response["stderr"]

                if parser_run_stderr is not None:
                    self.logger.debug(base64.decodestring(parser_run_stderr))
