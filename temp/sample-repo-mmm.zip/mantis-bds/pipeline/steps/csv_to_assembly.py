#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.
import json
import os
import warnings
import requests
import time
from lib.common.configuration import Configuration
from lib.common.errors import DBTestError, RestError
from lib.hdfs.count_rows import RowCounter

from pipeline.steps.base import MantisPipelineStep
from lib.enigma_clients.assembly import AssemblyClient
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class CsvToAssembly(MantisPipelineStep):

    assembly_url = "https://54.40.187.76/"
    schema_extension = ".json"
    java_base_dir = "/usr/jdk64"
    java_version_exp = "jdk1.8*"
    credentials_file_name = "enigma-credentials.yml"

    def setup(self):
        self.resolve_model_properties()
        self.consumer_file = self.args.consumerCSV
        self.schema_file = os.path.splitext(self.consumer_file)[0] + self.schema_extension
        self.csv2abstract_script = os.path.join(self.configuration.get('landing_dir'),
                                                self.configuration.get('csv2abstract_script'))
        self.__export_assembly_credentials()
        self.client = AssemblyClient(self.assembly_url, self.api_key)

    def execute(self):
        schema_content = self.get_hdfs_client().cat(hdfs_path=self.schema_file)\
            .replace('"type":', '"data_type":').replace('"data_type": "date"', '"data_type": "datetime"')
        schema_ready = json.loads(schema_content)
        schema_json = self.make_schema_json(self.args.consumerCSV, schema_ready)
        arr = self.args.abstractDatasetName.replace('-', '_').rsplit('.', 1)
        collection = arr[0]
        dataset = arr[1]
        print 'Execute: Collection %s, dataset %s' % (collection, dataset)
        dataset_id =  self.client.find_dataset_id(collection, dataset)
        self.snapshot_info = self.client.create_snapshot(dataset_id, schema_json)
        snapshot_id = self.snapshot_info['id']
        for i in range(10, 0, -1):
            print 'Waiting for indexing snapshot. %s intervals left...' % i
            time.sleep(20)
            self.snapshot_info = self.client.review_snapshot(snapshot_id)
            if long(self.snapshot_info['row_count']) != 0:
                break
            print
        print 'Snapshot info:\n%s' % self.snapshot_info

    def setup_db_test(self):
        if self.args.enableWarnings == 'false':
            warnings.simplefilter('ignore', Warning)

    def run_db_test(self):
        snap_info = self.client.review_snapshot(self.snapshot_info['id'] + '?row_limit=1')
        actual_record_count = long(snap_info['table_rows']['count'])
        expected_record_count = RowCounter.count_rows_hdfs(self.get_hdfs_client(), self.args.consumerCSV)
        if actual_record_count != expected_record_count:
            raise DBTestError("Number of records on HDFS: %s \n and in Metabase : %s \n are not equal. Db-test failed"
                              % (expected_record_count, actual_record_count))

    def __export_assembly_credentials(self):
        config_dir = self.configuration.get("config_location")
        credentials_file = os.path.join(config_dir, self.credentials_file_name)
        self.api_key = Configuration.parse_yaml(credentials_file)['assembly_credentials']['assembly_api_key']

    def make_schema_json(self, hdfs_url, schema):
        raw_json = {'fields': schema, 'data_url': (self.configuration.get("hdfs.knox_hdfs_uri") + hdfs_url + '?op=OPEN')}
        return json.dumps(raw_json)

