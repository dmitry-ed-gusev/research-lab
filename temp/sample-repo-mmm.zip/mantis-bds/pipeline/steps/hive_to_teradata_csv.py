#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

from pipeline.steps.export_step import ExportCsvStep


class HiveToTeradataCsv(ExportCsvStep):

    step_constants = {
        "full": "export-full.hql",
        "delta": "export-delta.hql",
        "full_count": "total-count-full.hql",
        "delta_count": "total-count-delta.hql"
    }

    def setup(self):
        super(HiveToTeradataCsv,self).setup()

        export_type = self.args.exportType.lower()

        self.export_script_name = self.step_constants[export_type]
        self.count_script_name = self.step_constants["%s_count" % export_type]

        self.resolve_export_dirs("idw")

        self.hive_vars = {
            "LOAD_DTTM_VAL": self.args.loadDTTM,
            "EXPORT_OUTPUT_DIRECTORY": "'%s'" % self.export_folder,
            "SOURCE_SYSTEM_ENV": self.args.sourceSystemEnv
        }
        if export_type == "delta":
            self.verify_parameter_set("exportFrom", "Lower bound for delta export is required")
            self.verify_parameter_set("exportTo", "Upper bound for delta export is required")
            self.hive_vars["EXPORT_FROM"]="'%s'" % self.args.exportFrom
            self.hive_vars["EXPORT_TO"]="'%s'" % self.args.exportTo


    def execute(self):
        self.delete_if_exist(self.export_csv_file)
        self.export_hive_to_csv()


