#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import abc
import os

from lib.common.shell_executor import ShellExecutor

from pipeline.steps.base import MantisPipelineStep


class MantisVerifyPipelineStep(MantisPipelineStep):
    """Base class for all mantis verify pipeline steps"""

    def setup(self):
        self.resolve_model_properties()
        self.verify_pipeline_script = os.path.join(self.configuration.get('landing_dir'),
                                                   self.configuration.get('verify_pipeline_script'))

    def execute(self):
        ShellExecutor.execute_shell(self._get_verify_args(), logger=self.logger)

    @abc.abstractmethod
    def _get_verify_args(self):
        """
            :rtype: list[str]
        """
        return