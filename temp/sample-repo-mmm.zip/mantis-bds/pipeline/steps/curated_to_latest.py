#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.
import os

from lib.common.errors import DBTestError

from pipeline.steps.base import MantisPipelineStep


class CuratedToLatest(MantisPipelineStep):
    def setup(self):
        self.resolve_model_properties()
        self.execution_script = os.path.join(self.configuration.get("model_step_dir"), "consumer-latest-layer.hql")
        self.verify_file_exist(self.execution_script)
        self.hive_vars = {
            "LOAD_DTTM_VAL": self.args.loadDTTM,
            "SOURCE_SYSTEM_ENV": self.args.sourceSystemEnv
        }

    def setup_db_test(self):
        dbtest_dir = os.path.join(self.configuration.get("model_step_dir"), "db-test")
        self.count_script_curated = os.path.join(dbtest_dir, "row-count-curated.hql")
        self.verify_file_exist(self.count_script_curated)
        self.count_script_latest = os.path.join(dbtest_dir, "row-count-latest.hql")
        self.verify_file_exist(self.count_script_latest)

    def execute(self):
        self.get_hive_client().execute(q_type="file", q_value=self.execution_script, vars=self.hive_vars)

    def run_db_test(self):
        count_curated = self.get_hive_client().execute(q_type="file", q_value=self.count_script_curated, vars=self.hive_vars, ret_val=True)[0]
        count_latest = self.get_hive_client().execute(q_type="file", q_value=self.count_script_latest, vars=self.hive_vars, ret_val=True)[0]
        if count_curated != count_latest:
            raise DBTestError("Row count in latest (%s) and curated (%s) layers are different" % (count_latest, count_curated))
