#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os
import json
import re

from pipeline.steps.export_step import ExportCsvStep


class HiveToDeltaCsv(ExportCsvStep):

    step_constants = {
        "definition_script_name": "definition-hive-to-delta.hql",
        "count_script_name": "total-hive-to-delta.hql",
        "export_script_name": "export-hive-to-delta.hql",
        "exported_file_user_permissions": "rwx",
        "exported_file_group_permissions": "r-x",
        "exported_file_other_permissions": "--x",
        "exported_file_abstract_permissions": "r-x"
    }

    def setup(self):
        super(HiveToDeltaCsv, self).setup()

        self.definition_script_name = self.step_constants["definition_script_name"]
        self.export_script_name = self.step_constants["export_script_name"]

        self.exported_file_abstract_permissions = self.step_constants["exported_file_abstract_permissions"]
        self.exported_file_other_permissions = self.step_constants["exported_file_other_permissions"]
        self.exported_file_group_permissions = self.step_constants["exported_file_group_permissions"]
        self.exported_file_user_permissions = self.step_constants["exported_file_user_permissions"]

        self.count_script_name = self.step_constants["count_script_name"]
        self.resolve_export_dirs("latest")

        self.abstract_user = self.configuration.get("abstract_user")
        self.hive_vars = {
            "LOAD_DTTM_VAL": self.args.loadDTTM,
            "EXPORT_OUTPUT_DIRECTORY": "'%s'" % self.export_folder,
            "SOURCE_SYSTEM_ENV": self.args.sourceSystemEnv
        }


    def execute(self):
        self.delete_if_exist(self.export_csv_file)
        self.delete_if_exist(self.export_json_file)

        self.export_hive_to_csv()
        self.__export_to_json()
        self.__set_acl(self.export_csv_file)
        pass

    def resolve_export_dirs(self, layer_name):
        super(HiveToDeltaCsv, self).resolve_export_dirs(layer_name)
        self.export_json_file = "%s.json" % os.path.splitext(self.export_csv_file)[0]

    def __export_to_json(self):
        self.logger.debug("Export schema to json is starting")
        hive_columns = self.__get_table_meta()
        definition = self.__map_columns(hive_columns)
        json_path = os.path.join(self.export_json_file)
        self.get_hdfs_client().write(hdfs_path=json_path, data=definition)

        self.logger.debug("Exported table schema definition :\n %s \nsaved in %s" %
                          (definition, self.export_json_file))
        self.logger.debug("Export schema to json finished")

    def __set_acl(self, file_path):
        """
        
        :param file_path: path to file
        :type file_path: str
        """
        self.logger.debug("Start processing ACLs for file %s" % file_path)

        owner_user_acl = "user::%s" % self.exported_file_user_permissions
        owner_group_acl = "group::%s" % self.exported_file_group_permissions
        other_acl = "other::%s" % self.exported_file_other_permissions
        extended_user_acl = "user:%s:%s" % \
                            (self.abstract_user, self.exported_file_abstract_permissions)

        general_acl = "%s,%s,%s" %(owner_user_acl, owner_group_acl, other_acl)

        self.logger.debug("Adding permissions %s for directory %s and its parent directories" %
                          (general_acl, os.path.dirname(file_path)))

        parent_dir = os.path.dirname(file_path)
        while os.path.dirname(parent_dir) != "/":
            self.get_hdfs_client().set_acl(hdfs_path = parent_dir, acl_spec = general_acl, clear=False)
            parent_dir = os.path.dirname(parent_dir)

        self.logger.debug("Setting permissions %s for file %s" % (extended_user_acl, file_path))
        self.get_hdfs_client().set_acl(hdfs_path = file_path, acl_spec = "%s,%s" % (general_acl, extended_user_acl), clear=False)
        self.logger.debug("ACLs processing for file %s was finished" % file_path)

    def __get_table_meta(self):
        """
            :return: meta info about table
            :rtype: list
        """
        definition_script = os.path.join(self.model_step_dir, self.definition_script_name)
        self.verify_file_exist(definition_script)
        table_meta = self.get_hive_client().execute(q_type="file", q_value=definition_script, ret_val=True)
        return table_meta

    def __map_columns(self, columns):
        """
            :type columns: list
            :rtype: str
        """
        table_definition = []
        for column in columns:
            column_parts = re.split('[,\(]', column)
            column_name = column_parts[0]
            column_type = column_parts[1]

            abstract_column_type = ""
            if column_type in ["tinyint", "bigint", "smallint", "int"]:
                abstract_column_type = "integer"
            elif column_type in ["decimal", "float", "double"]:
                abstract_column_type = "decimal"
            elif column_type == "date":
                abstract_column_type = "date"
            elif column_type == "timestamp":
                abstract_column_type = "datetime"
            elif column_type == "boolean":
                abstract_column_type = "boolean"
            elif column_type in ["string", "char", "varchar"]:
                abstract_column_type = "string"
            else:
                self.logger.error("Unknown column type: %s  for column %s" % (column_name, abstract_column_type))
            table_definition.append({"name": '%s' % column_name, "type": '%s' % abstract_column_type})

        return json.dumps(table_definition)
