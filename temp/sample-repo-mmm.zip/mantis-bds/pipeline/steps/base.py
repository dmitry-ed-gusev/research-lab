#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os

from lib.common.errors import ArgumentError
from lib.hadoop.hdfs_config import HdfsConfig
from lib.hadoop.mapreduce_config import MapreduceConfig
from lib.hadoop.yarn_config import YarnConfig
from lib.hdfs.hdfs_client import HdfsClient
from lib.hive.hive_client import HiveClient
from lib.yarn.yarn_client import YarnClient


class MantisPipelineStep(object):
    """Base class for all mantis pipeline steps"""

    def __init__(self, configuration, logger, args):
        self.configuration = configuration
        self.logger = logger
        self.args = args

    def resolve_model_properties(self):
        """ Resolve model-specific properties\n
            Properties are stored as (name, template) in self.model_properties list
        """
        for prop in self.model_properties:
            self.configuration.resolve_and_set(*prop)

    def verify_file_exist(self, file_name):
        """Verify file existing
        
            :type file_name: str
            :raise: IOError
        """
        if not os.path.isfile(file_name):
            raise IOError("File '%s' not found" % file_name)

    def verify_parameter_set(self, parameter_name, description):
        """Verify that parameter is set

            :type parameter_name: str
            :type description: str
            :raise: ArgumentError
        """
        if self.args.__getattribute__(parameter_name) is None:
            raise ArgumentError(parameter_name, description)

    def get_hive_client(self):
        """Hive client lazy-init
        
            :rtype: HiveClient 
        """
        if not self.hive_client:
            self.hive_client = HiveClient(configuration=self.configuration, logger=self.logger)
            self.hive_client.connect()
        return self.hive_client

    def get_hdfs_client(self):
        """HDFS client lazy-init
        
            :rtype: HdfsClient
        """
        if not self.hdfs_client:
            self.hdfs_client = HdfsClient(HdfsConfig(self.configuration, self.logger), self.logger)
        return self.hdfs_client

    def get_yarn_client(self):
        """YARN client lazy-init
        
            :rtype: YarnClient
        """
        if not self.yarn_client:
            self.yarn_client = YarnClient(config=self.configuration, logger=self.logger,
                                          hdfs_client=self.get_hdfs_client(),
                                          yarn_config=YarnConfig(self.configuration, self.logger),
                                          mapred_config=MapreduceConfig(self.configuration))
        return self.yarn_client

    def setup(self):
        """Additional arguments validation and other setup actions"""

    def setup_db_test(self):
        """Specific initialization for db-tests"""

    def execute(self):
        """Actual step execution"""

    def run_db_test(self):
        """Execution of db-test checks"""

    def cleanup(self):
        """Cleanup step leftovers. Close hive client (if initialized) by default"""
        if self.hive_client:
            try:
                self.hive_client.close()
                self.hive_client = None
            except Exception as e:
                self.logger.warn("Can't close hive client, reason: " + str(e))

    hive_client = None

    hdfs_client = None

    yarn_client = None

    model_properties = [
        ('model_system_dir', '${landing_dir}/mantis-systems-${source_system}/rel/${source_system}/${source_system_location}/datasets'),
        ('model_table_dir', '${model_system_dir}/${source_table}'),
        ('model_step_dir', '${model_table_dir}/${step_name}'),
        ('abstract_schemas_path', '${aux_hdfs_dir_base}/${source_system_env}/${source_system}/${source_system_location}/consumer/abstract/.abstract-schemas'),
        ('source_system_hdfs_base', '${aux_hdfs_dir_base}/${source_system_env}/${source_system}/${source_system_location}'),
        ('hdfs_tmp_dir', '${source_system_hdfs_base}/temp'),
        ('verify_steps_export_dir', '${source_system_hdfs_base}/verify/tmp'),
        ('verify_steps_base_file', '${source_system_hdfs_base}/verify/export.csv')
    ]
