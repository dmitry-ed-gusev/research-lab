#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

from pipeline.steps.verify_base import MantisVerifyPipelineStep
from lib.enigma_clients.assembly import AssemblyClient

class VerifyCsvToAssembly(MantisVerifyPipelineStep):

    def _get_verify_args(self):
        """
            :rtype: list[str]
        """
        arr = self.args.abstractDatasetName.replace('-', '_').rsplit('.', 1)
        collection = arr[0]
        dataset = arr[1]
        client = AssemblyClient(self.configuration.get("assembly_credentials.assembly_url"), self.configuration.get("assembly_credentials.assembly_api_key"))
        dataset_id = client.find_dataset_id(collection, dataset)
        snap_info = client.review_dataset(dataset_id)
        snap_id = snap_info['current_snapshot']['id']
        return [self.verify_pipeline_script,
                "--pipeline-step", self.args.stepName,
                "--verify-csv", self.args.verifyCSV,
                "--output-csv", self.configuration.get("verify_steps_base_file"),
                "--dataset", snap_id,
                "--abstract-env", self.configuration.get("abstract_env"),
                "--assembly-key", self.configuration.get("assembly_credentials.assembly_api_key")]
