#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os

from lib.common.errors import DBTestError

from pipeline.steps.base import MantisPipelineStep


class RawToCurated(MantisPipelineStep):
    """Raw to Curated pipeline step"""

    script_names = {
        "full_initial": "full-initial-ingest.hql",
        "full": "full-ingest.hql",
        "delta": "delta-ingest.hql",
        "increment": "incremental-ingest.hql"
    }

    def setup(self):
        """Verify existence of necessary hql scripts, setup hive variables for queries"""
        self.resolve_model_properties()
        model_step_dir = self.configuration.get("model_step_dir")
        self.execution_script = os.path.join(model_step_dir, self.script_names[self.args.ingestType])
        self.verify_file_exist(self.execution_script)
        self.partition_script = os.path.join(model_step_dir, "update-last-partition-view.hql")
        self.verify_file_exist(self.partition_script)
        self.hive_vars = {
            "LOAD_DTTM_VAL": self.args.loadDTTM,
            "EXTRACT_DTTM_VAL": self.args.extractDTTM,
            "LOAD_ID_VAL": self.args.loadID,
            "SOURCE_SYSTEM_ENV": self.args.sourceSystemEnv
        }

    def setup_db_test(self):
        """Verify existence of all db-test scripts, save row count from previous curated partition"""
        db_test_script_dir = os.path.join(self.configuration.get("model_step_dir"), "db-test")
        self.count_raw_script = os.path.join(db_test_script_dir, "row-count-raw-partition.hql")
        self.verify_file_exist(self.count_raw_script)
        self.count_cur_script = os.path.join(db_test_script_dir, "row-count-last-partition-view.hql")
        self.verify_file_exist(self.count_cur_script)
        self.empty_scd1_columns_script = os.path.join(db_test_script_dir, "empty-scd1-columns-curated.hql")
        self.verify_file_exist(self.empty_scd1_columns_script)
        self.load_dttm_script = os.path.join(db_test_script_dir, "load-dttm-last-partition-view.hql")
        self.verify_file_exist(self.load_dttm_script)
        self.logger.debug("Selecting row count from latest partition")
        row_count_res = self.get_hive_client().execute(q_type="file", q_value=self.count_cur_script, vars=self.hive_vars, ret_val=True)
        self.previous_row_count = long(row_count_res[0])
        self.logger.debug("DB-test setup completed")

    def execute(self):
        """Execute ingest and update last partition"""
        self.logger.debug("Executing raw-to-curated ingest script")
        self.get_hive_client().execute(q_type="file", q_value=self.execution_script, vars=self.hive_vars, ret_val=False)
        self.logger.debug("Ingest completed. Updating last partition view")
        self.get_hive_client().execute(q_type="file", q_value=self.partition_script, vars=self.hive_vars, ret_val=False)
        self.logger.debug("Last partition view updated")

    def run_db_test(self):
        """Run db-test checks. Verify curated row count, ensure no empty scd1 columns, check latest partition"""
        self.logger.debug("Check row count")
        row_count_raw_res = self.get_hive_client().execute(q_type="file", q_value=self.count_raw_script, vars=self.hive_vars, ret_val=True)
        row_count_raw = long(row_count_raw_res[0])
        row_count_cur_res = self.get_hive_client().execute(q_type="file", q_value=self.count_cur_script, vars=self.hive_vars, ret_val=True)
        row_count_cur = long(row_count_cur_res[0])
        curated_rows_diff = (row_count_cur - self.previous_row_count)
        if curated_rows_diff > row_count_raw:
            raise DBTestError("The difference between partition sizes (%s) exceeds the batch size %s" % (curated_rows_diff, row_count_raw))
        if row_count_cur < row_count_raw:
            raise DBTestError("Row count in curated layer (%s) is less then batch size %s" % (row_count_cur, row_count_raw))
        self.logger.debug("Check empty SCD1 columns")
        empty_columns_res = self.get_hive_client().execute(q_type="file", q_value=self.empty_scd1_columns_script, vars=self.hive_vars, ret_val=True)
        if long(empty_columns_res[0]) != 0:
            raise DBTestError("Found empty SCD1 columns for %s rows" % empty_columns_res[0])
        if row_count_cur > 0:
            self.logger.debug("Check partition value of last partition view")
            actual_dttm = self.get_hive_client().execute(q_type="file", q_value=self.load_dttm_script, vars=self.hive_vars, ret_val=True)[0]
            if actual_dttm != self.args.loadDTTM:
                raise DBTestError("Last partition view has invalid partition value (%s)" % actual_dttm)
        else:
            self.logger.debug("Curated layer has no data. Check that last partition is empty")
            last_dttm = self.get_hive_client().execute(q_type="file", q_value=self.load_dttm_script, vars=self.hive_vars, ret_val=True)
            if len(last_dttm) != 0:
                raise DBTestError("Curated layer is empty, but last partition has some data")
