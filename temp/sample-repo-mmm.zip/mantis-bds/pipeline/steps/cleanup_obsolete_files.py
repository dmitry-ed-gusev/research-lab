#!/usr/bin/env python
# coding=utf-8
# Copyright 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import time

import datetime

from hdfs.client import HdfsError

from pipeline.steps.base import MantisPipelineStep


class CleanupObsoleteFiles(MantisPipelineStep):

    MILLISECONDS_IN_SECOND = 1000

    def execute(self):
        obsolete_files_max_date = datetime.datetime.now() - datetime.timedelta(days=self.args.retentionPeriod)
        obsolete_files_max_time = self._datetime_to_unix_timestamp(obsolete_files_max_date)

        obsolete_files = []
        file_statuses = self.get_hdfs_client().list(hdfs_path=self.args.layerDirectory, status=True)
        directory = self.get_hdfs_client().resolve(self.args.layerDirectory)
        for file_name, status in file_statuses:
            if status["modificationTime"] <= obsolete_files_max_time:
                obsolete_files.append(directory + "/" + file_name)
        if len(obsolete_files) > 0:
            self.logger.debug("Selected for removal the following obsolete files: " + str(obsolete_files))
            for obsolete_file in obsolete_files:
                if not self.get_hdfs_client().delete(obsolete_file):
                    raise HdfsError("Failed to delete obsolete file " + obsolete_file)
        else:
            self.logger.info("No obsolete files were selected for removal")

    def _datetime_to_unix_timestamp(self, datetime_value):
        """
            :param datetime_value: time to convert
            :type datetime_value: datetime
            :return: unix timestamp
            :rtype: float
        """
        return time.mktime(datetime_value.timetuple()) * self.MILLISECONDS_IN_SECOND
