#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

from lib.common.errors import ArgumentError

from pipeline.steps.base import MantisPipelineStep


class CleanupObsoleteData(MantisPipelineStep):

    def setup(self):
        self.resolve_model_properties()
        if self.args.targetLayer == "raw":
            setattr(self.args, "cleanupType", "partitions")
        elif not self.args.cleanupType:
            raise ArgumentError("--cleanupType", "Cleanup type is required for cleanup of curated layer")
        # Resolve and verify HQL scripts
        model_step_dir = self.configuration.get("model_step_dir")
        if self.args.cleanupType == "partitions":
            self.select_script = "%s/select-%s-partitions.hql" % (model_step_dir, self.args.targetLayer)
            self.verify_file_exist(self.select_script)
            self.cleanup_script = "%s/cleanup-%s-partitions.hql" % (model_step_dir, self.args.targetLayer)
        else:
            self.cleanup_script = "%s/hard-delete-from-curated.hql" % model_step_dir
        self.verify_file_exist(self.cleanup_script)
        self.hive_vars = {
            "LOAD_DTTM_VAL": self.args.loadDTTM,
            "RETENTION_PERIOD": self.args.retentionPeriod,
            "SOURCE_SYSTEM_ENV": self.args.sourceSystemEnv
        }

    def execute(self):
        self.logger.info("Applying retention rules for %s in %s layer with retention period of %s days"
                          % (self.args.cleanupType, self.args.targetLayer, self.args.retentionPeriod))

        if self.args.cleanupType == "partitions":
            partitions = self.get_hive_client().execute(q_type="file", q_value=self.select_script, vars=self.hive_vars, ret_val=True)
            self.logger.debug("Found obsolete partitions: " + str(partitions))
            for partition in partitions:
                if partition != self.args.loadDTTM:
                    self.logger.debug("Drop partition: " + partition)
                    hive_var = {"PARTITION_VALUE": partition}
                    self.get_hive_client().execute(q_type="file", q_value=self.cleanup_script, vars=hive_var, ret_val=False)
                else:
                    self.logger.warn("Leaving obsolete partition '%s' since it is the current one" % partition)
        else:
            self.logger.debug("Drop obsolete hard-deleted records from curated layer")
            self.get_hive_client().execute(q_type="file", q_value=self.cleanup_script, vars=self.hive_vars, ret_val=False)
        self.logger.info("Retention rules has been applied")
