#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

from pipeline.steps.verify_base import MantisVerifyPipelineStep


class VerifyRawToCurated(MantisVerifyPipelineStep):

    def _get_verify_args(self):
        return [self.verify_pipeline_script,
                "--pipeline-step", self.args.stepName,
                "--verify-csv", self.args.verifyCSV,
                "--export-dir", self.configuration.get("verify_steps_export_dir"),
                "--output-csv", self.configuration.get("verify_steps_base_file"),
                "--database", self.args.curatedDB,
                "--table", self.args.curatedTable,
                "--partition-column", self.configuration.get('load_dttm_col'),
                "--partition-value", self.args.loadDTTM]
