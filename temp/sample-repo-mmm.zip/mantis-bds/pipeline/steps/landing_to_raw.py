#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

from lib.common.errors import DBTestError

from pipeline.steps.base import MantisPipelineStep


class LandingToRaw(MantisPipelineStep):
    """Landing to Raw pipeline step"""

    def setup(self):
        self.yarn_client = self.get_yarn_client()
        self.app_context = self.yarn_client.create_application()
        self.app_context.app_name = "LandingToRawRunner"
        self.app_context.add_local_resource("yarn.tools.csv2hive")
        # Add step args into env vars
        self.app_context.add_container_env("C2H_DATABASE", self.args.rawDB)
        self.app_context.add_container_env("C2H_TABLE", self.args.rawTable)
        self.app_context.add_container_env("C2H_CSV", self.args.filePath)
        self.app_context.add_container_env("C2H_PARTITION_COLUMN", self.configuration.get('load_dttm_col'))
        self.app_context.add_container_env("C2H_PARTITION_VALUE", self.args.loadDTTM)
        self.app_context.add_container_env("C2H_MODE", self.args.mode)
        self.app_context.add_container_env("C2H_YARN_QUEUE", self.configuration.get("yarn_queue"))
        # Always disable remote db-test. Runtime check will be performed externally if needed
        self.app_context.add_container_env("C2H_DISABLE_DB_TEST", "true")

    def setup_db_test(self):
        self.previous_count = 0
        if self.args.mode == "append":
            self.previous_count = self._get_hive_counter()
            self.logger.debug("Previous records counter: " + str(self.previous_count))

    def execute(self):
        self.app_context.exec_cmd = "./csv2hive/" + self.configuration.get("csv2hive_tool_script")
        self.app_context.exec_dir = self.args.loadDTTM.replace(":", "%3A")
        self.yarn_client.submit_app(self.app_context)
        self.yarn_client.wait_for_finish(self.app_context, expect_external=True)

    def run_db_test(self):
        job_count = self._get_job_counter()
        self.logger.debug("Job counter: " + str(job_count))
        expected_count = self.previous_count + job_count
        hive_count = self._get_hive_counter()
        self.logger.debug("Hive counter: " + str(hive_count))
        if hive_count != expected_count:
            raise DBTestError("Unexpected record count in target partition. Expected %s but was %s"
                              % (expected_count, hive_count))

    def _get_job_counter(self):
        """
            :rtype: int
        """
        counters = self.yarn_client.get_mr_job_counters(self.app_context)
        csv_group = None
        for group in counters["counterGroup"]:
            if group["counterGroupName"] == "csv_group":
                csv_group = group
        if csv_group:
            return csv_group["counter"][0]["totalCounterValue"]
        else:
            # On empty file, custom counter might not be initialized
            return 0

    def _get_hive_counter(self):
        """
            :rtype: long
        """
        query = "select count(*) from `%s`.`%s` where `%s`='%s'" % (
            self.args.rawDB, self.args.rawTable, self.configuration.get('load_dttm_col'), self.args.loadDTTM)
        res = self.get_hive_client().execute("query", query, ret_val=True)
        return long(res[0])
