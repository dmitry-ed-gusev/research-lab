#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.
import fnmatch
import json
import os
import warnings
from tempfile import NamedTemporaryFile

import requests
from lib.common.errors import DBTestError, RestError
from lib.hdfs.count_rows import RowCounter
from lib.common.shell_executor import ShellExecutor

from pipeline.steps.base import MantisPipelineStep

class CsvToAbstract(MantisPipelineStep):

    schema_extension = ".json"
    java_base_dir = "/usr/jdk64"
    java_version_exp = "jdk1.8*"
    credentials_file_name = "enigma-credentials.yml"

    def setup(self):
        self.resolve_model_properties()
        self.consumer_file = self.args.consumerCSV
        self.schema_file = os.path.splitext(self.consumer_file)[0] + self.schema_extension
        self.previous_schema_file = self.__resolve_schema_path()
        self.schema_local_file = NamedTemporaryFile(mode='w')
        self.reindex_collection = False
        self.csv2abstract_script = os.path.join(self.configuration.get('landing_dir'),
                                                self.configuration.get('csv2abstract_script'))
        self.__set_java_home()
        self.__export_abstract_credentials()

    def execute(self):
        self.logger.debug("Checking if schema was changed")

        schema_content = self.get_hdfs_client().cat(hdfs_path=self.schema_file)
        previous_schema_status = self.get_hdfs_client().status(hdfs_path=self.previous_schema_file, strict=False)
        if previous_schema_status is not None:
            self.logger.debug("Previous schema file exists. Compare it with current schema")
            previous_schema_content = self.get_hdfs_client().cat(hdfs_path=self.previous_schema_file)
            if schema_content == previous_schema_content:
                self.logger.debug("Schema wasn't changed")
            else:
                self.logger.debug("Schema was changed. Reindex collection")
                self.reindex_collection = True
        else:
            self.logger.debug("Previous schema file does not exist. Reindex collection")
            self.reindex_collection = True

        self.schema_local_file.write(schema_content)
        self.schema_local_file.flush()

        abstract_cmd = [self.csv2abstract_script, "--dataset", self.args.abstractDatasetName, "--csv", self.args.consumerCSV,
                         "--schema", self.schema_local_file.name, "--credentials", self.credentials_file]

        if self.args.abstractLogLevel is not None:
            abstract_cmd.extend(["--log-level", self.args.abstractLogLevel])
        if self.reindex_collection:
            abstract_cmd.append("--reindex")
        ShellExecutor.execute_shell(abstract_cmd, logger=self.logger, log_level="DEBUG")

        if self.reindex_collection:
            self.logger.debug("Updating schema file %s" % self.previous_schema_file)
            schema_dir = os.path.dirname(self.previous_schema_file)
            self.get_hdfs_client().makedirs(schema_dir)
            self.get_hdfs_client().copy_file(self.schema_file, self.previous_schema_file, True)
            self.logger.debug("Schema file was updated")

    def setup_db_test(self):
        if self.args.enableWarnings == 'false':
            warnings.simplefilter('ignore', Warning)

    def run_db_test(self):
        url = "%s/v2/meta/%s/%s" % (self.configuration.get("abstract_credentials.abstract_url"),
                                    self.configuration.get("abstract_credentials.abstract_api_key"),
                                    self.args.abstractDatasetName)
        response = requests.get(url=url, verify=False)
        if not response:
            raise RestError(response, "Rest error in csv2abstract step.")
        json_response = json.loads(response.content)
        actual_record_count = long(json_response["result"]["metadata"][0]["value"])
        expected_record_count = RowCounter.count_rows_hdfs(self.get_hdfs_client(), self.args.consumerCSV)
        if actual_record_count != expected_record_count:
            raise DBTestError("Number of records on HDFS: %s \n and in Metabase : %s \n are not equal. Db-test failed"
                              % (expected_record_count, actual_record_count))

    def cleanup(self):
        """Quietly close schema file"""
        try:
            self.schema_local_file.close()
        except Exception:
            pass

    def __set_java_home(self):
        if os.environ.get("JAVA_HOME") is None:
            for dir in os.listdir(self.java_base_dir):
                if fnmatch.fnmatch(dir, self.java_version_exp):
                    os.environ["JAVA_HOME"] = os.path.join(self.java_base_dir, dir)
                    return

    def __export_abstract_credentials(self):
        config_dir = self.configuration.get("config_location")
        self.credentials_file = os.path.join(config_dir, self.credentials_file_name)
        os.environ["RIVER_TIMEOUT_SECONDS"] = str(self.args.RIVER_TIMEOUT_SECONDS)
        os.environ["RIVER_TIMEOUT_ATTEMPTS"] = str(self.args.RIVER_TIMEOUT_ATTEMPTS)
        os.environ["KNOX_HDFS_URI"] = self.configuration.get("hdfs.knox_hdfs_uri")

    def __resolve_schema_path(self):
        return os.path.join(self.configuration.get("abstract_schemas_path"),
                            self.args.abstractDatasetName, "schema", "schema.json")