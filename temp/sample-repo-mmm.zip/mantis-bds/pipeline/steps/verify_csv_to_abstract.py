#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

from pipeline.steps.verify_base import MantisVerifyPipelineStep


class VerifyCsvToAbstract(MantisVerifyPipelineStep):

    def _get_verify_args(self):
        """
            :rtype: list[str]
        """
        return [self.verify_pipeline_script,
                "--pipeline-step", self.args.stepName,
                "--verify-csv", self.args.verifyCSV,
                "--output-csv", self.configuration.get("verify_steps_base_file"),
                "--dataset", self.args.abstractDatasetName,
                "--abstract-env", self.configuration.get("abstract_env"),
                "--abstract-key", self.configuration.get("abstract_credentials.abstract_api_key")]
