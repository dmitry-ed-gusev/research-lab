#!/usr/bin/env python
# coding=utf-8
# Copyright 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os

from lib.common.errors import ArgumentError, DBTestError

from pipeline.steps.base import MantisPipelineStep


class SqoopToRaw(MantisPipelineStep):
    def setup(self):
        self.yarn_client = self.get_yarn_client()
        self.app_context = self.yarn_client.create_application()
        self.app_context.app_name = "SqoopToRawRunner"
        if self.args.ingestType == "delta":
            if not self.args.deltaLowerBound:
                raise ArgumentError("--deltaLowerBound", "Delta lower bound is required for 'delta' ingest")
            if not self.args.deltaUpperBound:
                raise ArgumentError("--deltaUpperBound", "Delta upper bound is required for 'delta' ingest")
        self.resolve_model_properties()
        self.model_step_dir = self.configuration.get("model_step_dir")
        self.ingest_script_path = os.path.join(self.model_step_dir, self.args.ingestType + "-ingest.sh")
        self.logger.debug("Ingest script path:%s" % self.ingest_script_path)
        self.verify_file_exist(self.ingest_script_path)
        self.logger.debug("Ingest script path found")
        self.cleanup_script_path = os.path.join(self.model_step_dir, "drop-raw-partition.hql")
        self.verify_file_exist(self.cleanup_script_path)
        self.hive_vars = {
            "PARTITION_VALUE": self.args.loadDTTM,
            "SOURCE_SYSTEM_ENV": self.configuration.get("source_system_env")
        }
        source_credentials_prefix = "source_system_credentials.%s.%s.%s." % (
            self.configuration.get("source_system"),
            self.configuration.get("source_system_env"),
            self.configuration.get("source_system_location")
        )

        self.logger.debug("source_credentials_prefix:%s" % source_credentials_prefix)

        (driver_name, driver_entry, driver_properties) = self._resolve_jdbc_driver(source_credentials_prefix)
        self.logger.debug("Driver name:%s Driver entry:%s" % (driver_name, driver_entry))
        # Upload drivers
        self.app_context.add_local_resource(driver_entry)
        self.logger.debug("Driver uploaded")
        # Upload sqoop distr
        self.app_context.add_local_resource("yarn.tools.sqoop-msd")
        # Driver name after res. upload is the same its path
        driver_path = self.configuration.get(driver_entry)["path"]
        self._setup_environment(source_credentials_prefix, driver_name, driver_path, driver_properties)
        # Upload executable file
        self.app_context.upload_local_resource(local_path=self.ingest_script_path, remote_path="/ingest.sh",
                                               name="ingest.sh", force=True)

    def setup_db_test(self):
        self.raw_row_count_script = os.path.join(self.model_step_dir, "db-test", "row-count-raw.hql")
        self.verify_file_exist(self.raw_row_count_script)

    def run_db_test(self):
        job_count = self._get_job_counter()
        self.logger.debug("Job counter: " + str(job_count))
        hive_vars = {
            "LOAD_DTTM_VAL": self.args.loadDTTM
        }
        hive_count = self.get_hive_client().execute(q_type="file", q_value=self.raw_row_count_script,
                                                    vars=hive_vars, ret_val=True)[0]
        self.logger.debug("Hive counter: " + str(hive_count))
        if long(hive_count) != long(job_count):
            raise DBTestError("Unexpected record count in target partition. Expected %s but was %s"
                              % (job_count, hive_count))

    def _get_job_counter(self):
        """
            :rtype: int 
        """
        counters = self.yarn_client.get_mr_job_counters(self.app_context)
        counter_group = None
        self.logger.debug("Counters: %s" % counters)
        for group in counters["counterGroup"]:
            if group["counterGroupName"] == "org.apache.hadoop.mapreduce.TaskCounter":
                counter_group = group
                break
        if counter_group:
            for group in counter_group["counter"]:
                if group["name"] == "MAP_INPUT_RECORDS":
                    return group["totalCounterValue"]
            raise DBTestError("Could not find counter from job:%s" % group)
        else:
            return 0

    def execute(self):
        self.get_hive_client().execute(q_type="file", q_value=self.cleanup_script_path, vars=self.hive_vars,
                                       ret_val=False)
        # ShellExecutor.execute_shell(self.ingest_script_path, logger=self.logger, log_level="DEBUG")
        self.app_context.exec_cmd = "./ingest.sh"
        self.app_context.exec_dir = self.args.loadDTTM.replace(":", "%3A")
        self.yarn_client.submit_app(self.app_context)
        self.yarn_client.wait_for_finish(self.app_context, True)

    def _resolve_jdbc_driver(self, source_credentials_prefix):
        """
        :type source_credentials_prefix: str
        :return: tuple of (driver_name, driver_entry, driver_properties)
        :rtype: (str, str, str)
        """
        driver_type = self.configuration.get(source_credentials_prefix + "jdbc_driver")
        driver_name = self.configuration.get('sqoop.source_system.%s.jdbc_driver_name' % driver_type)
        driver_entry = 'sqoop.source_system.%s' % driver_type
        driver_properties = self.configuration.get(source_credentials_prefix + "jdbc_driver_properties", default="-Ddummy=value")
        return (driver_name, driver_entry, driver_properties)

    def _setup_environment(self, source_credentials_prefix, driver_name, driver_path, driver_properties):
        """Export predefined and custom environment variables

            :type source_credentials_prefix: str
            :type driver_name: str
            :type driver_path: str
            :type driver_properties: str 
        """
        self._setup_general_env(driver_name, driver_path, driver_properties, source_credentials_prefix)
        self._setup_custom_env(source_credentials_prefix)

    def _setup_general_env(self, driver_name, driver_path, driver_properties, source_credentials_prefix):
        """Export predefined environment variables

            :type source_credentials_prefix: str
            :type driver_name: str
            :type driver_path: str
            :type driver_properties: str 
        """
        self._set_env("HADOOP_CLASSPATH",
                      driver_path)
        self._set_env("HCAT_HOME", self.configuration.get('webhcat_home'))
        self._set_env("HIVE_HOME", self.configuration.get('hive_client_home'))
        self._set_env("HADOOP_HOME", self.configuration.get('hadoop_client_home'))
        self._set_env("SQOOP_CMD", os.path.join("sqoop-msd", self.configuration.get('sqoop_script')))
        self._set_env("SQOOP_PARAMS", '-Dmapreduce.job.queuename=%s' % self.configuration.get('yarn_queue'))
        self._set_env("SQOOP_MAPPER_PARAMS", driver_properties)
        self._set_env("JDBC_CONNECTION_STRING",
                      self.configuration.get(source_credentials_prefix + "jdbc_connection_string"))
        self._set_env("JDBC_DRIVER", driver_name)
        self._set_env("JDBC_USER_NAME", self.configuration.get(source_credentials_prefix + "username"))
        self._set_env("JDBC_PASSWORD", self.configuration.get(source_credentials_prefix + "password"))
        self._set_env("EXTRACT_DTTM_VAL", self.args.extractDTTM)
        self._set_env("LOAD_ID_VAL", self.args.loadID)
        self._set_env("LOAD_DTTM_VAL", self.args.loadDTTM)
        self._set_env("SOURCE_SYSTEM_ENV", self.args.sourceSystemEnv)

        if self.args.ingestType == 'delta':
            self._set_env("DELTA_LOWER_BOUND", self.args.deltaLowerBound)
            self._set_env("DELTA_UPPER_BOUND", self.args.deltaUpperBound)

    def _setup_custom_env(self, source_credentials_prefix):
        """Export custom environment variables

            :type source_credentials_prefix: src
        """
        env_dict = self.configuration.get(source_credentials_prefix + 'environment', {})
        for key in env_dict:
            self._set_env(key, env_dict[key])

    def _set_env(self, var_name, value):
        """
            :type var_name: str
            :type value: str
        """
        self.app_context.add_container_env(var_name, value)
