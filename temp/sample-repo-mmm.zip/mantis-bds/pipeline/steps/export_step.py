#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import datetime
import os

from lib.common.errors import DBTestError
from lib.hdfs.count_rows import RowCounter

from pipeline.steps.base import MantisPipelineStep


class ExportCsvStep(MantisPipelineStep):

    step_constants = {}

    def __init__(self, configuration, logger, args):
        super(ExportCsvStep, self).__init__(configuration, logger, args)

    def setup(self):
        self.resolve_model_properties()

        self.model_step_dir = self.configuration.get("model_step_dir")
        self.force_enabled = self.args.forceExport
        self.hive_vars = None
        self.layer_name = None
        self.export_folder = None
        self.target_folder = None
        self.export_csv_file = None
        self.export_script_name = None
        self.count_script_name = None

    def setup_db_test(self):
        self.db_test_dir_name = "db-test"

    def run_db_test(self):
        count_script=os.path.join(self.model_step_dir, self.db_test_dir_name, self.count_script_name)
        self.verify_file_exist(count_script)

        row_count = self.get_hive_client().execute(q_type="file", q_value=count_script, vars=self.hive_vars, ret_val=True)
        row_count_res = long(row_count[0])
        self.logger.debug("Records from hive table: %s" % row_count_res)

        file_row_count_res = RowCounter.count_rows_hdfs(self.get_hdfs_client(), self.export_csv_file)
        self.logger.debug("Records from hdfs location: %s" % file_row_count_res)

        if file_row_count_res != row_count_res:
            raise DBTestError("Number of records in hive table: %s \n and exported CSV: %s \n are not equal. Db-test failed"
                              % (row_count_res, file_row_count_res))

    def resolve_export_dirs(self, layer_name):
        if self.args.exportCSV is not None:
            self.export_csv_file = self.args.exportCSV
            self.target_folder = os.path.dirname(self.export_csv_file)
        else:
            self.verify_parameter_set("loadID", "Argument 'exportCSV' is not set. Argument 'loadID' is required")
            self.verify_parameter_set("extractDTTM", "Argument 'exportCSV' is not set. Argument 'extractDTTM' is required")

            self.target_folder = os.path.join(self.configuration.get("source_system_hdfs_base"),
                                              "consumer", layer_name,
                                              self.configuration.get("source_table"))
            load_id = self.args.loadID
            extract_dttm = self.args.extractDTTM
            self.export_csv_file = os.path.join(self.target_folder, "%s-%s-%s-%s-%s-%s.csv" % (
                self.configuration.get("source_system_env"), self.configuration.get("source_system"),
                self.configuration.get("source_system_location"), self.configuration.get("source_table"),
                load_id, extract_dttm))

        export_folder_base = os.path.join(self.configuration.get("hdfs_tmp_dir"),
                                          "consumer", layer_name,
                                          self.configuration.get("source_table"))
        self.export_folder = os.path.join(export_folder_base, self.args.loadDTTM.replace(":", "%3A"))


    def delete_if_exist(self, target_dir):
        """ Deletes specified directory in HDFS
        
            :type target_dir: str
        """
        if self.get_hdfs_client().status(hdfs_path=target_dir, strict=False) is not None:
            if self.args.forceExport == "true":
                self.logger.debug("Force mode: ON")
                self.logger.debug("Removing target dir: %s" % target_dir)
                self.get_hdfs_client().delete(hdfs_path=target_dir, recursive=True)
            else:
                self.logger.error("Force mode: OFF")
                self.logger.error("Target folder exists: %s" % target_dir)
                self.logger.error("Use '--forceExport true' to override it.")
                raise RuntimeError("Target folder is not empty and force mode is not enabled.")

    def export_hive_to_csv(self):
        """ Exports Hive table to csv in HDFS
        
        """
        self.logger.debug("Export to csv is starting")
        csv_exp_date = datetime.datetime.now()

        export_script = os.path.join(self.model_step_dir, self.export_script_name)
        self.verify_file_exist(export_script)

        self.logger.debug("Ensure temp directory '%s' is created and empty" % self.export_folder)
        self.get_hdfs_client().delete(hdfs_path=self.export_folder, recursive=True)
        self.get_hdfs_client().makedirs(hdfs_path=self.export_folder)

        self.logger.debug("Export CSV to '%s'" % self.export_folder)
        self.get_hive_client().execute(q_type="file", q_value=export_script, vars=self.hive_vars)

        self.logger.debug("Start merging of resulting CSV files")
        csv_merge_date = datetime.datetime.now()

        self.get_hdfs_client().makedirs(hdfs_path=self.target_folder)

        self.get_hdfs_client().merge_files(hdfs_dir=self.export_folder, target_file=self.export_csv_file)

        self.logger.debug("Cleanup export folder '%s'" % self.export_folder)
        self.get_hdfs_client().delete(hdfs_path=self.export_folder, recursive=True)

        self.logger.debug("Merge duration: %s" % (datetime.datetime.now() - csv_merge_date))
        self.logger.debug("Export duration: %s" % (datetime.datetime.now() - csv_exp_date))

        self.logger.debug("Export to csv is finished")