#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import getpass
import importlib
import re
import subprocess
import sys
from traceback import extract_tb

from lib.common import configuration
from lib.common.argparser import ArgParser
from lib.common.errors import ArgumentError, MantisError
from lib.common.logger import MantisLogger


def init_config(config, args):
    """Store logger-required and hive-conf parsed arguments in configuration
    
        :param config: Config object, where all args will be added
        :type config: lib.common.configuration.Configuration
        :param args: arguments to add to config
        :type args: argparse.Namespace
        :rtype: lib.common.configuration.Configuration
    """
    config.set('step_name', args.stepName)
    config.set('source_system', args.sourceSystem)
    config.set('source_system_location', args.sourceSystemLocation)
    config.set('source_system_env', args.sourceSystemEnv)
    config.set('source_table', args.sourceTable)
    hive_conf = config.get("hive_config", {}) # Reading hive conf from yaml file
    for conf_line in args.hiveconf: # Adding hive conf from command line arguments
        arr = conf_line.split('=')
        if len(arr) > 1:
            hive_conf[arr[0]] = arr[1]
    if len(hive_conf) > 0:
        config.set("hive_config", hive_conf)
    return config


def add_parser_arguments(parser, arg_list):
    """Add arguments description from config to arg parser
    
        :type parser: ArgParser
        :type arg_list: dict
        :rtype: ArgParser
    """
    for arg in arg_list:
        arg_name = arg.pop('name')
        parser.add_argument(arg_name, **arg)
    return parser


def get_step_by_name(step_name, conf, logger, args):
    """ Load step class. Naming convention is:\n
        file name - step name with all '-' replaced by '_'\n
        class name - step name in CamelCase without '-'\n
        i.e. test-step => test_step.py, TestStep(..)
        
        :type step_name: str
        :type conf: lib.common.configuration.Configuration
        :type logger: MantisLogger
        :type args: argparse.Namespace
        :rtype: pipeline.steps.base.MantisPipelineStep
    """
    module_name = step_name.replace('-', '_')
    class_name = re.sub(r'(?:^|-)([a-z])', lambda match: match.group(0).upper(), step_name)
    class_name = class_name.replace('-', '')
    step_module = importlib.import_module('pipeline.steps.' + module_name)
    step_class = getattr(step_module, class_name)
    return step_class(conf, logger, args)


def renew_kerberos_ticket():
    """Renew kerberos ticket for cluster env"""
    username = getpass.getuser()
    keytab = '/home/%s/%s.headless.keytab' % (username, username)
    kinit_args = ['kinit', '-kt', keytab, username + '@MERCK.COM']
    subprocess.check_call(kinit_args)


if __name__ == '__main__':
    renew_kerberos_ticket()

    # Load config
    conf = configuration.load_config()
    steps_registry = conf.get('steps')

    # Create simple step name parser
    parser = ArgParser(conf=conf, prog="mdc.sh")
    parser.add_argument('--stepName', type=str, required=True, choices=steps_registry.keys())
    args, unknown = parser.parse_known_args()

    # Setup the parser for given step, including general options
    parser = add_parser_arguments(parser, conf.get('general-mdc-arguments'))
    parser = add_parser_arguments(parser, steps_registry[args.stepName].get('arguments', []))
    parser.add_argument('--hiveconf', type=str, action='append', default=[])
    args, unknown = parser.parse_known_args()

    conf = init_config(config=conf, args=args)
    logger = MantisLogger()
    logger.configure(conf)

    try:
        step = get_step_by_name(args.stepName, conf, logger, args)
    except Exception as e:
        logger.error("Unable to initialize step: " + str(e))
        sys.exit(2)

    # Execute given step
    exit_status = 1
    try:
        logger.info("Starting pipeline step '%s'" % args.stepName)
        logger.trace("Step arguments: " + str(args))
        step.setup()
        db_test_enabled = 'disableDBTest' in args and args.disableDBTest == "false"
        if db_test_enabled:
            logger.debug("DB-test checks pre-execution setup")
            step.setup_db_test()
        logger.debug("Execute step")
        step.execute()
        logger.debug("Step execution completed")
        if db_test_enabled:
            logger.debug("Run DB-test runtime checks")
            step.run_db_test()
            logger.debug("DB-test checks passed")
        exit_status = 0
    except ArgumentError as arg_error:
        parser.error(str(arg_error), logger=logger)
    except MantisError as err:
        logger.error(str(err))
    except Exception as e:
        etype, value, tb = sys.exc_info()
        msg = MantisError.base_error_message(etype, str(value))
        logger.error(MantisError.format(msg, extract_tb(tb)))
    finally:
        if step:
            logger.debug("Cleanup after step execution")
            step.cleanup()

    if exit_status == 0:
        logger.info("Pipeline step '%s' completed successfully" % args.stepName)
    else:
        logger.error("Pipeline step '%s' failed. See execution logs for details" % args.stepName)
    sys.exit(exit_status)
