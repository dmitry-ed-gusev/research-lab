#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e

BASEDIR="$(dirname $0)"

# Enabling python virtualenv for further processing
if [ -d "${BASEDIR}/../../../mantis-virtualenv" ]; then
    . ${BASEDIR}/../../../mantis-virtualenv/bin/activate
fi


# Current process ID
export MDC_PID=$$

# Add mantis-pipeline root dir as Python Path for proper module resolving
export PYTHONPATH="${BASEDIR}/.."
# Mantis config location
export CONFIG_LOCATION="${CONFIG_LOCATION:-${BASEDIR}/../../../mantis-config}"

# Execute mdc.py
"${BASEDIR}/mdc.py" "$@"
exit $?
