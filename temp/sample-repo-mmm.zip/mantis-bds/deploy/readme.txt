artifact_id :
                                    mantis-pipeline
groupd_id : com.msd.gin.bdp
version
                                    : 2.3.0-SNAPSHOT
classifier : 
build_date : 2017-09-08 05:14:30 +0300