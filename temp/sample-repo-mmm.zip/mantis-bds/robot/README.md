# Docker CORE IMAGE for Robot Framework
Image name:  **`robot-framework.dock.merck.com/core`**.

----

## About

**Robot Framework CORE image** with full acceptance test.
Used to Qualify and ensure control of Robot Framework Core and base images.
This image will be used to build additional images with expanded libraries and feature sets.
The acceptance test should be re-run after every change.
