#!/usr/bin/env bash
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

#Usage:
# hard-deleted-flag.sh --database-name database-name --table-name table-name
set -e

source pipeline/env.sh

export SCRIPT_LIB_DIR=${SCRIPT_LIB_DIR:-lib}
export SCRIPT_MODEL_DIR=${SCRIPT_MODEL_DIR:-model}
export SCRIPT_PIPELINE_DIR=${SCRIPT_PIPELINE_DIR:-pipeline}

#Loading libs
for file in $(ls ${SCRIPT_LIB_DIR}/*.sh); do
    source ${file}
done

#Argument parsing
get_argument_by_name DATABASE_NAME --database-name required "$@"
get_argument_by_name TABLE_NAME --table-name required "$@"

#Variable creation
BASEDIR="$(dirname $0)"
HARD_DELETED_SCRIPT_NAME="add-hard-deleted-flag.hql"

##Main part
HIVE_SCRIPT="${BASEDIR}/${HARD_DELETED_SCRIPT_NAME}"
verify_file_exists "${HIVE_SCRIPT}"
execute_hive --hivevar DATABASE_NAME=${DATABASE_NAME} --hivevar TABLE_NAME=${TABLE_NAME} --silent=false --showHeader=true \
 --fastConnect=true --verbose=true --showWarnings=true --showNestedErrs=true -f "${HIVE_SCRIPT}" --call
if [ "$?" = "0" ]; then
    echo "Table ${TABLE_NAME} in database ${DATABASE_NAME} was updated with hard-deleted-flag successfully"
fi