#!/usr/bin/env bash
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

#This file should be located on root directory of mantis before run
#Usage:
# materialized_view.sh --targetdb database-name --view view-name --tempdb temp-database-name --loadDTTM load-dttm
#   --sourceSystem source-system --sourceSystemLocation source-system-location --sourceSystemEnv source-system-env
#   --sourceTable source-table

set -e
source pipeline/env.sh

export SCRIPT_LIB_DIR=${SCRIPT_LIB_DIR:-lib}
export SCRIPT_MODEL_DIR=${SCRIPT_MODEL_DIR:-model}
export SCRIPT_PIPELINE_DIR=${SCRIPT_PIPELINE_DIR:-pipeline}
echo ${SCRIPT_LIB_DIR}

#Loading libs
for file in $(ls ${SCRIPT_LIB_DIR}/*.sh); do
    source ${file}
done

#Argument parsing
get_argument_by_name DB_TARGET --targetdb required "$@"
get_argument_by_name VIEW --view required "$@"
get_argument_by_name TEMP --tempdb required "$@"
get_argument_by_name SOURCE_SYSTEM --sourceSystem required "$@"
get_argument_by_name SOURCE_SYSTEM_LOCATION --sourceSystemLocation required "$@"
get_argument_by_name SOURCE_SYSTEM_ENV --sourceSystemEnv required "$@"
get_argument_by_name SOURCE_TABLE --sourceTable required "$@"
get_argument_by_name LOAD_DTTM --loadDTTM required "$@"

#Variable creation
BASEDIR="$(dirname $0)"
RENAME_VIEW_SCRIPT_NAME="rename-view-latest.hql"
CREATE_MATERIALIZED_VIEW="create-consumer-latest-layer.hql"
INSERT_MATERIALIZED_VIEW="consumer-latest-layer.hql"
REMOVE_VIEW_SCRIPT_NAME="remove-view-latest.hql"
MODEL_DIR="model/${SOURCE_SYSTEM}/${SOURCE_SYSTEM_LOCATION}/${SOURCE_SYSTEM_ENV}/datasets/${SOURCE_TABLE}"

##Main part
#Renaming
HIVE_SCRIPT="${BASEDIR}/${RENAME_VIEW_SCRIPT_NAME}"
verify_file_exists "${HIVE_SCRIPT}"
execute_hive --hivevar DB_TARGET=${DB_TARGET} --hivevar VIEW=${VIEW} --hivevar TEMP_DB=${TEMP} -f "${HIVE_SCRIPT}" --call

#Creating materialized view
HIVE_SCRIPT="${MODEL_DIR}/create-consumer-latest/${CREATE_MATERIALIZED_VIEW}"
verify_file_exists "${HIVE_SCRIPT}"
execute_hive -f "${HIVE_SCRIPT}" --call

#Insert data into materialized view
pipeline/mdc.sh --stepName curated-to-latest "$@"

#Remove temp view
HIVE_SCRIPT="${BASEDIR}/${REMOVE_VIEW_SCRIPT_NAME}"
verify_file_exists "${HIVE_SCRIPT}"
execute_hive --hivevar TEMP_DB=${TEMP} --hivevar VIEW=${VIEW} -f "${HIVE_SCRIPT}" --call