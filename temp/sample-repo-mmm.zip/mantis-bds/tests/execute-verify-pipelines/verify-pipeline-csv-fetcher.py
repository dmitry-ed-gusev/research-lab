#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import argparse
import logging
import os
import re
import subprocess

from lib.common.configuration import Configuration, load_config
from lib.hadoop.hdfs_config import HdfsConfig
from lib.hdfs.hdfs_client import HdfsClient


def _getHdfsClient():
    configuration = Configuration()
    configuration.load(os.environ["CONFIG_LOCATION"])
    return HdfsClient(HdfsConfig(load_config(), logging.getLogger()))


def __call_step(step, load_id):
    print "Executing step %s load_id %d" % (step, load_id)
    exec_cmd = 'python execute-verify-pipelines.py --landing_dir %s --step_name %s --table_name %s --load_id %d' % (
        landing_dir, step, table_name, load_id)
    proc = subprocess.Popen(exec_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
    return proc.communicate()[0]


def execute_step(step, load_id):
    output = __call_step(step, load_id)
    if (output.find("completed successfully") == -1):
        raise Exception("Step execution failed:%s" % output)


def verify_step(step, load_id):
    output = __call_step(step, load_id)
    print output
    try:
        m = re.search('Comparing file (.*) with (.*?)\r?\n', output)
        csv = m.group(1)
        export = m.group(2)
        return csv, export
    except Exception as e:
        return (None, None)


def __clean_call(table_name):
    proc = subprocess.Popen(
        'python execute-verify-pipelines.py --clean_tables --table_name %s' % table_name,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, shell=True)
    if proc.wait() != 0:
        raise Exception("Clean has failed!")
    else:
        print("Table successfully cleaned: %s" % table_name)


if __name__ == "__main__":
    all_tables = ['verify_increment', 'verify_full_ingest']
    all_load_ids = [10, 11, 12, 13]
    # the second bool param is if we want run verify step for that step
    all_steps_verify = [
        ("landing-to-raw", True),
        ("raw-to-curated", True),
        ("curated-to-latest", True),
        ("hive-to-delta-csv", True),
        ("hive-to-teradata-csv", True),
      #  ("csv-to-abstract", True),
        ("cleanup-raw-partitions", True),
        ("cleanup-curated-records", True),
        ("cleanup-curated-partitions", True)
    ]
    parser = argparse.ArgumentParser()
    parser.add_argument('--table_name', type=str, action='append', default=[], required=False)
    parser.add_argument('--load_ids', type=str, nargs='*', default=[], required=False)
    parser.add_argument('--step_name', type=str, action='append', default=[], required=False)
    args = parser.parse_args()
    args.load_ids = map(lambda x: int(x), args.load_ids)
    # checks
    if args.step_name and not set(args.step_name).issubset([step[0] for step in all_steps_verify]):
        raise Exception("Step %s is not known" % args.step_name)
    if args.load_ids and not set(args.load_ids).issubset(all_load_ids):
        raise Exception("Load ids %s is not known" % args.load_ids)
    if args.table_name and not set(args.table_name).issubset(all_tables):
        raise Exception("Tables %s is not known" % args.table_name)

    table_names = args.table_name if args.table_name else all_tables
    load_ids = args.load_ids if args.load_ids else all_load_ids
    steps_verify = [(step, True) for step in args.step_name] if args.step_name else all_steps_verify

    landing_dir = os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir, os.pardir))
    os.environ['CONFIG_LOCATION'] = os.path.join(landing_dir, "mantis-config")
    hdfs_client = _getHdfsClient()
    csv_output_folder = "csv_output"

    for table_name in table_names:
        __clean_call(table_name)
        for load_id in load_ids:
            for step in steps_verify:
                execute_step(step[0], load_id)
                if step[1]:
                    verify_step_name = "verify-" + step[0]
                    csv, export = verify_step(verify_step_name, load_id)
                    if csv is not None:
                        hdfs_client.download(export, ("./%s/" % csv_output_folder) + os.path.basename(csv), True)
                        print "Step %s load id %d completed with verification" % (verify_step_name, load_id)
                        print "Copied: %s" % export
                    else:
                        print "Step %s load id %d completed without comparing results" % (verify_step_name, load_id)
                else:
                    print "Step %s load id %d completed without verification" % (step[0], load_id)
