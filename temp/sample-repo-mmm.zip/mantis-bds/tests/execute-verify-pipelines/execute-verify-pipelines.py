#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import argparse
import getpass
import logging
import os
import subprocess
import sys
import re
from datetime import datetime
from functools import partial

import sqlparse
from lib.common.configuration import load_config, Configuration, ConfigError
from lib.hadoop.hdfs_config import HdfsConfig
from lib.hdfs.hdfs_client import HdfsClient
from lib.hive.hive_client import HiveClient
from lib.common.logger import MantisLogger


def execute_mdc(args):
    pipes = subprocess.Popen(args)
    pipes.communicate()
    if pipes.returncode != 0:
        err_msg = "Error code: %s" % pipes.returncode
        raise Exception(err_msg)


def build_mdc_arguments(params, landing_dir):
    command = ['/bin/bash', landing_dir + '/mantis-pipeline/rel/pipeline/mdc.sh',
               '--stepName', params['step_name'],
               '--sourceSystem', params['source_system'],
               '--sourceSystemLocation', params['ss_location'],
               '--sourceTable', params['table_name'],
               '--sourceSystemEnv', params['source_system_env'],
               '--disableDBTest', str(params['disable_runtime_checks'])]
    specific_command = {'landing-to-raw': ['--rawDB', params['raw_db'],
                                           '--rawTable', params['table_name'],
                                           '--loadDTTM', '' + str(params['load_dttm']),
                                           '--CSV2HIVE_MODE', 'override',
                                           '--filePath', params['landing_csv']],
                        'verify-landing-to-raw': ['--verifyCSV', params['verify_csv'],
                                                  '--rawDB', params['raw_db'],
                                                  '--rawTable', params['table_name'],
                                                  '--loadDTTM', '' + str(params['load_dttm'])],
                        'sqoop-to-raw': ['--rawDB', params['raw_db'],
                                         '--rawTable', params['table_name'],
                                         '--loadDTTM', '' + str(params['load_dttm']),
                                         '--loadID', str(params['load_id']),
                                         '--ingestType', str(params['sqoop_ingest_type']), '--extractDTTM',
                                         params['extract_dttm_raw']],
                        'verify-sqoop-to-raw': ['--verifyCSV', params['verify_csv'],
                                                '--rawDB', params['raw_db'],
                                                '--rawTable', params['table_name'],
                                                '--loadDTTM', '' + str(params['load_dttm'])],
                        'raw-to-curated': ['--loadDTTM', '' + str(params['load_dttm']),
                                           '--loadID', str(params['load_id']),
                                           '--extractDTTM', params['extract_dttm_raw'],
                                           '--ingestType', params['ingest_type']],
                        'verify-raw-to-curated': ['--verifyCSV', params['verify_csv'],
                                                  '--curatedDB', params['curated_db'],
                                                  '--curatedTable', params['table_name'],
                                                  '--loadDTTM', '' + str(params['load_dttm'])],
                        'curated-to-latest': ['--loadDTTM', '' + str(params['load_dttm'])],
                        'verify-curated-to-latest': ['--verifyCSV', params['verify_csv'],
                                                     '--latestDB', params['latest_db'],
                                                     '--latestTable', params['table_name']],
                        'hive-to-delta-csv': ['--loadDTTM', '' + str(params['load_dttm']),
                                              '--exportCSV', params['consumer_csv'],
                                              '--forceExport', 'true'],
                        'verify-hive-to-delta-csv': ['--consumerCSV', params['consumer_csv'],
                                                     '--verifyCSV', params['verify_csv']],
                        'hive-to-teradata-csv': ['--loadDTTM', '' + str(params['load_dttm']),
                                                 '--exportType', params['extract_type'],
                                                 '--exportCSV', str(params['export_csv']),
                                                 '--exportFrom', params['extract_from'],
                                                 '--exportTo', params['extract_to'],
                                                 '--forceExport', 'true'],
                        'verify-hive-to-teradata-csv': ['--consumerCSV', str(params['export_csv']),
                                                        '--verifyCSV', str(params['verify_csv']),
                                                        '--forceExport', 'true'],
                        'csv-to-abstract': ['--abstractDatasetName', params['abstract_dataset'],
                                            '--consumerCSV', params['consumer_csv']],
                        'csv-to-assembly': ['--abstractDatasetName', params['abstract_dataset'],
                                            '--consumerCSV', params['consumer_csv']],
                        'verify-csv-to-abstract': ['--verifyCSV', str(params['verify_csv']),
                                                   '--abstractDatasetName', params['abstract_dataset']],
                        'verify-csv-to-assembly': ['--verifyCSV', str(params['verify_csv']),
                                                   '--abstractDatasetName', params['abstract_dataset']],
                        'cleanup-obsolete-data': ['--targetLayer', params['layer'],
                                                  '--retentionPeriod', params['retention_period'],
                                                  '--loadDTTM', '' + str(params['load_dttm']),
                                                  '--cleanupType', params['cleanup_type']],
                        'verify-cleanup-obsolete-partitions': ['--verifyCSV', str(params['verify_csv']),
                                                               '--targetDB',
                                                               params['db_template'] + ('_%s' % params['layer']),
                                                               '--targetTable', params['table_name']],
                        'verify-cleanup-obsolete-records': ['--verifyCSV', str(params['verify_csv']),
                                                            '--targetDB',
                                                            params['db_template'] + ('_%s' % params['layer']),
                                                            '--targetTable', params['table_name'],
                                                            '--loadDTTM', '' + str(params['load_dttm'])]
                        }
    return command + specific_command.get(params['step_name'], [])


def get_sql_path(params, landing_dir):
    pth = '%s/mantis-pipeline/rel/test-data/%s/%s/test/%s/db/' \
          % (landing_dir, params['source_system'], params['ss_location'], params['table_name']) \
          + params['file_template'] + '%s-%s-%s' % (
        params['table_name'], str(params['load_id']), params['extract_dttm']) + '.sql'
    return pth


def credentials_config_key(env):
    return 'source_system_credentials.%s.%s' %(params['source_system'], env)

def get_db_credentials():
    params['credentials'] = config.get(credentials_config_key(params['source_system_env']) + '.' + params['ss_location'])
    user = params['credentials']['username']
    password = params['credentials']['password']
    hostname = params['credentials']['jdbc_connection_string']
    hostname = re.sub(r'.*(\@|\/\/)', '', hostname)
    database = 'none'
    conn = [user, password, hostname, database]
    return conn

def load_pipeline_config(landing_dir, env):
    cfg = Configuration()
    cfg.load("%s/mantis-config" % landing_dir)
    try:
        cfg.get(credentials_config_key(env))
    except ConfigError:
        print "Augmenting configuration with credentials for %s" % env
        cfg_add = Configuration()
        cfg.set(credentials_config_key(env), cfg.get(credentials_config_key('test')))
        cfg_add.set(credentials_config_key(env), cfg.get(credentials_config_key('test')))
        import yaml
        with open("%s/mantis-config/creds_%s.yaml" % (landing_dir, env), 'w') as f:
            yaml.dump(cfg_add.config_dict, f)
    return cfg

def is_sql_ended(s):
    if re.search(r'^\s*(?:DECLARE|BEGIN)\b', s, re.IGNORECASE) is None:
        return True
    return re.search(r'\bEND\s*$', s, re.IGNORECASE) is not None

def split_oracle_sql(sql):
    statements = []
    cur = ''
    sts = [str(x) for x in list(sqlparse.parse(sql))]
    for s in sts:
        s = re.sub(r'\;$', '', s)
        if re.match(r'^\s+$', s):
            continue
        cur += s
        if is_sql_ended(cur):
            cur = re.sub(r'end$', 'end;', cur, 1, re.IGNORECASE)
            statements.append(cur)
            cur = ''
    return statements

def execute_sql_from_file(cursor, file):
    print "Executing SQL statements from file " + file
    with open(file) as f:
        full_sql = f.read()
        sql_commands = split_oracle_sql(full_sql)
        for sql_command in sql_commands:
            try:
                cursor.execute(sql_command)
            except Exception as E:
                print "Error while executing SQL script:%s \nStatement: %s \nError: %s" % (file, sql_command, E)
                raise E


def load_all_parameters(table_name, load=None, step=None):
    date_format = '%Y-%m-%d'
    params['table_name'] = table_name
    params['load_id'] = load
    params['step_name'] = step
    params['ss_location'] = params['source_system_location'][params['table_name']]
    params['sqoop'] = params['sqoop_source'][params['table_name']]
    params['hdfs_template'] = params['hdfs_prefix'] + '/%s/%s/%s' % (
    params['source_system_env'], params['source_system'], params['ss_location'])
    params['file_template'] = 'test-%s-%s-' % (params['source_system'], params['ss_location'])
    params['db_template'] = 'mmd_%s_%s_%s' % (params['source_system_env'], params['source_system'], params['ss_location'])
    params['raw_db'] = params['db_template'] + '_raw'
    params['curated_db'] = params['db_template'] + '_curated'
    params['latest_db'] = params['db_template'] + '_consumer_latest'

    if step is not None:
        params.update(yaml_load['steps'].get(step, {}))
        retain_date = datetime.strptime(str(params['loads'][params['load_id']]['retain_date']), date_format)
        daydiff = datetime.today() - retain_date
        params['retention_period'] = str(daydiff.days)
        params['load_dttm'] = params['loads'][params['load_id']]['load_dttm'][params['table_name']]
        params['extract_from'] = str(params['loads'][params['load_id']]['extract_from'][params['table_name']])
        params['extract_to'] = str(params['loads'][params['load_id']]['extract_to'][params['table_name']])
        params['extract_dttm_raw'] = str(params['loads'][params['load_id']]['extract_dttm'][params['table_name']])
        params['extract_dttm'] = re.sub('[\:\s]', '-', params['extract_dttm_raw'])
        params['ingest_type'] = params['loads'][params['load_id']]['ingest_type'][params['table_name']]
        params['extract_type'] = params['loads'][params['load_id']]['extract_type']
        params['export_csv'] =  '%s/consumer/idw/%s/%s%s-%s-%s.csv' \
                                % ( params['hdfs_template'], params['table_name'], \
                                   params[ 'file_template'], params['table_name'], \
                                    str(params['load_id']),params['extract_dttm'])
        params['consumer_csv'] =  '%s/consumer/abstract/%s/%s%s-%s-%s.csv' \
                            % ( params['hdfs_template'], params['table_name'], \
                                params[ 'file_template'], params['table_name'], \
                                str(params['load_id']),params['extract_dttm'])
        params['verify_csv'] = '%s/test/%s/verify/%s-%s-%s.csv' % ( params['hdfs_template'], params['table_name'], \
                               step.replace('verify-', ''), str(params['load_id']),  \
                               params['extract_dttm'])
        #we need to keep 'test' here cause test data corresponds to 'test' source_system_env
        params['landing_csv'] =  '%s/test/%s/landing/' % (params['hdfs_template'], params['table_name']) \
                                + params['file_template'] + '%s-%s-%s' % (
            params['table_name'], str(params['load_id']), params['extract_dttm']) + '.csv'
        params['abstract_dataset'] = 'mantis.%s.%s.%s' % (
            params['source_system_env'], params['source_system'].replace('_', '-'), params['ss_location']) + \
                                     params['user'] + '.' + params['table_name'].replace('_', '-')
    return params


def _getHdfsClient():
    client = HdfsClient(HdfsConfig(load_config(), logging.getLogger()))
    return client


def deploy_test_data(landing_dir, tables_to_proccess):
    print "Deploying test data to HDFS..."
    hdfs_client = _getHdfsClient()
    deploy = partial(_upload, hdfs_client)
    re_create = partial(_recreate_deploy_dir, hdfs_client)

    for table in tables_to_proccess:
        params = load_all_parameters(table)
        local_prefix = "mantis-pipeline/rel/test-data/%s" % (params['source_system'])
        #we need to keep 'test' here cause test data corresponds to 'test' source_system_env
        local_path = os.path.join(landing_dir, local_prefix, params['ss_location'], 'test', table)
        hdfs_path = os.path.join(params['hdfs_template'], 'test', table)
        re_create(hdfs_path)
        if not sqoop_source(table, params):
            deploy(local_path + "/landing", hdfs_path)
        deploy(local_path + "/verify", hdfs_path)
    print "Deploying test data to HDFS finished"


def _recreate_deploy_dir(hdfs_client, deploy_dir):
    print "Re-create HDFS deployment directory %s" % deploy_dir
    hdfs_client.delete(deploy_dir, True)
    hdfs_client.makedirs(deploy_dir, permission="0700")


def _upload(hdfs_client, local_path, deploy_dir):
    print "Deploying data for test environment from %s to %s" % (local_path, deploy_dir)
    hdfs_client.upload(local_path=local_path, hdfs_path=deploy_dir, overwrite=True, cleanup=True)


def deploy_sqoop_data(landing_dir, table_name, load_id, step):
    if step == "sqoop-to-raw":
        print
        print "----------------------------------------------------------------------------------------------"
        print "Before sqoop-to-raw: Deploying external database test data for table %s for load %s" % (str(
            table_name), str(load_id))
        print "----------------------------------------------------------------------------------------------"
        params = load_all_parameters(table_name, load_id, step)
        uri = get_db_credentials()
        sql_path = get_sql_path(params, landing_dir)
        if sqoop_source(table, params):
            print 'Connecting to Oracle database \"%s\"' % (uri[2])
            cx_oracle = import_cx_oracle()
            with cx_oracle.connect('%s/%s@%s' % (uri[0], uri[1], uri[2])) as con:
                cursor = con.cursor()
                execute_sql_from_file(cursor, sql_path)
                cursor.close()
                print 'Successfully'


def import_cx_oracle():
    if 'cx_Oracle' in sys.modules and not os.environ["NLS_LANG"] ==".AL32UTF8":
            raise ImportError("Have you imported cx_Oracle before set up NLS_LANG = .AL32UTF8?")
    else:
        os.environ["NLS_LANG"] = ".AL32UTF8"
        import cx_Oracle
        return cx_Oracle


# execute one step from the pipeline
def exec_step(landing_dir, table, load, step):
    params = load_all_parameters(table, load, step)
    args = build_mdc_arguments(params, landing_dir)
    print
    print "=============================================================================================="
    print "Executing step %s for table %s for load %s" %(str(step), str(table), str(load))
    print "=============================================================================================="
    print
    print args
    execute_mdc(args)


def exec_all(landing_dir, loads, step_name):
    for load_id in loads:
        for step in step_name:
            if sqoop_source(table):
                deploy_sqoop_data(landing_dir, table, load_id, step)
            exec_step(landing_dir, table, load_id, step)


def hive_client_execute_cleanup(landing_dir, query):
    os.environ['PYTHONPATH'] =  '%s/mantis-pipeline/rel' % landing_dir
    os.environ['MDC_PID'] = str(os.getpid())

    os.environ['SOURCE_SYSTEM'] = params['source_system']
    os.environ['SOURCE_SYSTEM_ENV'] = params['source_system_env']

    os.environ['STEP_NAME'] = 'cleanup'

    config = Configuration()
    config.load("%s/mantis-config" % landing_dir)

    logger = MantisLogger()
    logger.configure(config)

    hive_client = HiveClient(configuration=config, logger=logger)
    hive_client.connect()
    hive_client.execute('query', query)
    hive_client.close()

def clean_tables(tables, landing_dir):
    renew_kerberos_ticket()

    def _clean_by_load_dttm(db, table):
            hive_client_execute_cleanup(landing_dir,
                "alter table %s.%s drop partition (load_dttm > '')" % (db, table))

    def _clean_with_truncate(db, table):
            hive_client_execute_cleanup(landing_dir, "truncate table %s.%s" % (db, table))

    print "Purging tables %s in all layers" % str(tables)

    for table in tables:
        os.environ['source_system_location'] = load_all_parameters(table)['ss_location']
        os.environ['SOURCE_TABLE'] = table
        for layer in ['raw_db', 'curated_db']:
            _clean_by_load_dttm(load_all_parameters(table)[layer], table)
        for layer in ['latest_db']:
            _clean_with_truncate(load_all_parameters(table)[layer], table)
    print "Cleanup completed"


def drop_databases(landing_dir):
    renew_kerberos_ticket()

    def _drop(db):
        hive_client_execute_cleanup(landing_dir, "drop database if exists %s cascade" % db)

    print "Dropping databases for Source System %s ..." %source_system

    os.environ['SOURCE_TABLE'] = ''

    for loc in get_yaml_values(params,'source_system_location'):
        for db in ['consumer_latest', 'curated', 'operational', 'raw']:
            os.environ['source_system_location'] = loc
            _drop('mmd_%s_%s_%s_%s' % (params['source_system_env'], params['source_system'], loc, db))
    print "Cleanup completed"


def immediate_action(args, tables_to_proccess):
    if args.clean_tables:
        clean_tables(tables_to_proccess, args.landing_dir)
    elif args.drop_databases:
        drop_databases(args.landing_dir)
    elif args.deploy_test_data:
        deploy_test_data(args.landing_dir, tables_to_proccess)
    else:
        return False
    return True


def renew_kerberos_ticket():
    username = getpass.getuser()
    keytab = '/home/%s/%s.headless.keytab' % (username, username)
    kinit_args = ['kinit', '-kt', keytab, username + '@MERCK.COM']
    subprocess.check_call(kinit_args)


def sqoop_source(table, params = None):
    if params is None:
        params = load_all_parameters(table)
    if params['sqoop_source'][table].lower() == 'oracle':
        return True
    else:
        return False


# get list of Key Values that are nested from the specified key
# used to all get source system tables and all load ids
def get_yaml_keys(parameters, key):
    returnlist = []
    if key in parameters:
        keydata = parameters[key]
        for k, v in keydata.items():
            returnlist.append(k)
        return returnlist

# get list of Values that are nested from the specified key
# used to return all locations of SS
def get_yaml_values(parameters, key):
    returnlist = []
    if key in parameters:
        keydata = parameters[key]
        for k, v in keydata.items():
            returnlist.append(v)
        return returnlist


# filter out wrong command line parameters if any
# used for tables and loads processing
def filter_out(ss_values, args_values, name):
    # filter out possible wrong tables that are non in SS
    retlist = []
    for entity in args_values:
        if entity in ss_values:
            retlist.append(entity)
        else:
            print '%s \"' % name + str(entity) + '\" does not exist at the configuration file and will be skipped'

    if retlist:
        print '%ss to process: ' % name + str(retlist)
        return retlist
    else:
        print 'Error. No %ss to process.' %name
        sys.exit(1)

if __name__ == "__main__":

    landing_to_raw = ['landing-to-raw', 'verify-landing-to-raw']
    sqoop_to_raw = ['sqoop-to-raw', 'verify-sqoop-to-raw']
    other_steps = ['raw-to-curated', 'verify-raw-to-curated',
                   'curated-to-latest', 'verify-curated-to-latest',
                   'hive-to-delta-csv', 'verify-hive-to-delta-csv',
                   'hive-to-teradata-csv', 'verify-hive-to-teradata-csv',
                   'csv-to-assembly', 'verify-csv-to-assembly',
                   'cleanup-raw-partitions', 'verify-cleanup-raw-partitions',
                   'cleanup-curated-partitions', 'verify-cleanup-curated-partitions',
                   'cleanup-curated-records', 'verify-cleanup-curated-records']

    # if source is csv file
    landing_steps = landing_to_raw + other_steps
    # if source is sqoop
    sqoop_steps = sqoop_to_raw + other_steps

    parser = argparse.ArgumentParser()
    parser.add_argument('--landing_dir', type=str, default="/home/mantisetld")
    parser.add_argument('--load_id', type=str, nargs='*', default=[], required=False)
    parser.add_argument('--step_name', type=str, action='append', default=[], required=False)
    parser.add_argument('--clean_tables', action='store_true')
    parser.add_argument('--drop_databases', action='store_true')
    parser.add_argument('--deploy_test_data', action='store_true')
    parser.add_argument('--skip_verify', action='store_true')
    parser.add_argument('--source_system', type=str, default="test_pipeline")
    parser.add_argument('--table_name', type=str, action='append', default=[])
    parser.add_argument('--ss_env', type=str, required=True)
    args = parser.parse_args()
    os.environ['CONFIG_LOCATION'] = args.landing_dir + "/mantis-config"

    ss_env = args.ss_env
    print "----------------------------------------------------------------------------------------------"
    print 'Source System Environment to process: \"%s\"' % ss_env

    # we will load parameters for specified Source System only
    source_system = args.source_system
    print "----------------------------------------------------------------------------------------------"
    print 'Source System to process: \"%s\"' % source_system

    # initial parameters
    params = {
        'source_system': source_system,
        'table_name': None,
        'load_id': None,
        'step_name': None,
        'source_system_env': ss_env
    }
    
    config = load_pipeline_config(args.landing_dir, params['source_system_env'])

    # load parameters from config file
    yaml_load = Configuration.parse_yaml("verify-pipeline-config.yml")
    params.update(yaml_load['common'])
    try:
        params.update(yaml_load['source_systems'][source_system])
    except KeyError:
        print  'Error. Source System \"' + source_system + '\" does not exist at the config file.'
        sys.exit(1)

    # get list of all tables from Source System
    ss_tables = get_yaml_keys(params, 'source_system_location')
    print 'Source system contains the following tables : ' + str(ss_tables)

    # get list of all loads from Source System
    ss_loads = get_yaml_keys(params, 'loads')
    print 'Source system contains the following loads : ' + str(ss_loads)

    # use command-line parameters if table arguments were specified else use all tables from SS
    table_names = args.table_name if args.table_name else ss_tables
    # use command-line parameters if load arguments were specified else use all loads from config
    loads = map(int, args.load_id) if args.load_id else ss_loads

    # filter out possible wrong tables that are non in SS
    tables_to_proccess = filter_out (ss_tables,table_names,'table')
    # filter out possible wrong loads that are non in SS
    loads_to_proccess = filter_out (ss_loads,loads,'load')

    if immediate_action(args, tables_to_proccess):
        sys.exit(0)

    for table in tables_to_proccess:
        if sqoop_source(table):
            steps = args.step_name if args.step_name else sqoop_steps
        else:
            steps = args.step_name if args.step_name else landing_steps
        if args.skip_verify:
            steps = [step for step in steps if not step.startswith('verify')]
        # execute pipeline steps
        exec_all(args.landing_dir, loads_to_proccess, steps)
