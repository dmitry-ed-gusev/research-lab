# coding=utf-8
# Copyright (c) 2017 Merck Sharp & Hohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os
import re
import sqlparse
import sys

from lib.common.configuration import load_config, Configuration, ConfigError

def this_file_dir():
    return os.path.dirname(os.path.abspath(__file__))

def get_db_credentials(cred_key):
    cfg = Configuration()
    cfg.load("%s/../../../mantis-config" % this_file_dir())
    params = cfg.get(cred_key)
    user = params['username']
    password = params['password']
    hostname = params['jdbc_connection_string']
    hostname = re.sub(r'.*(\@|\/\/)', '', hostname)
    database = 'none'
    conn = [user, password, hostname, database]
    return conn

def import_cx_oracle():
    if 'cx_Oracle' in sys.modules and not os.environ["NLS_LANG"] ==".AL32UTF8":
            raise ImportError("Have you imported cx_Oracle before set up NLS_LANG = .AL32UTF8?")
    else:
        os.environ["NLS_LANG"] = ".AL32UTF8"
        import cx_Oracle
        return cx_Oracle

def is_sql_ended(s):
    if re.search(r'^\s*(?:DECLARE|BEGIN)\b', s, re.IGNORECASE) is None:
        return True
    return re.search(r'\bEND\s*$', s, re.IGNORECASE) is not None

def split_oracle_sql(sql):
    statements = []
    cur = ''
    sts = [str(x) for x in list(sqlparse.parse(sql))]
    for s in sts:
        s = re.sub(r'\;$', '', s)
        if re.match(r'^\s+$', s):
            continue
        cur += s
        if is_sql_ended(cur):
            cur = re.sub(r'end$', 'end;', cur, 1, re.IGNORECASE)
            statements.append(cur)
            cur = ''
    return statements

def execute_sql_from_file(cursor, file):
    print "Executing SQL statements from file " + file
    with open(file) as f:
        full_sql = f.read()
        sql_commands = split_oracle_sql(full_sql)
        for sql_command in sql_commands:
            try:
                cursor.execute(sql_command)
            except Exception as E:
                print "Error while executing SQL script:%s \nStatement: %s \nError: %s" % (file, sql_command, E)
                raise E


def main():
    creds = get_db_credentials(sys.argv[1]) #source_system_credentials.test_pipeline.test.global
    ora = import_cx_oracle()
    with ora.connect(creds[0] + '/' + creds[1] + '@' + creds[2]) as con:
        cursor = con.cursor()
        execute_sql_from_file(con.cursor(), sys.argv[2])
        cursor.close()
        print 'SQL executed successfully'

if __name__ == '__main__':
    main()
