# coding=utf-8
# Copyright (c) 2017 Merck Sharp & Hohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os
import sys
import yaml

from lib.common.configuration import load_config, Configuration, ConfigError

def this_file_dir():
    return os.path.dirname(os.path.abspath(__file__))

def amend_config(key_test, key_user):
    cfg_path = this_file_dir() + '/../../../mantis-config'
    cfg = Configuration()
    cfg.load(cfg_path)
    try:
        cfg.get(key_user)
        print "Config needs no patching"
    except ConfigError:
        cfg_add = Configuration()
        cfg_add.set(key_user, cfg.get(key_test))
        import yaml
        with open("%s/db_creds_amended.yaml" % cfg_path, 'w') as f:
            yaml.dump(cfg_add.config_dict, f)
        print "Config amended"
    return cfg

if __name__ == '__main__':
    amend_config(sys.argv[1], sys.argv[2])