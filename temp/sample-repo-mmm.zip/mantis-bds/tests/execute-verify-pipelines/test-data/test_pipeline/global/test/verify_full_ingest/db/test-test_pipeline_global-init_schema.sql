create user TEST_PIPELINE_GLOBAL identified by "TEST_PIPELINE_GLOBAL";

grant connect to TEST_PIPELINE_GLOBAL;
grant resource to TEST_PIPELINE_GLOBAL;
