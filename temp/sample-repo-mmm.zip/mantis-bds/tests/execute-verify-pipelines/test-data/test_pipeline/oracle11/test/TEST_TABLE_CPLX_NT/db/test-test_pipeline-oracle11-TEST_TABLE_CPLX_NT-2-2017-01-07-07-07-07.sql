alter session set current_schema = TEST_PIPELINE;

delete from TEST_TABLE_CPLX_NT where COL_NUM = 15;

update TEST_TABLE_CPLX_NT 
set COL_CT = CT_2(2343243, DATE'1963-06-11', 'afxwfzada'),
	COL_NT = TT_1( CT_2(-4, DATE'1988-09-04', 'axrez4wrqdw'))
where COL_NUM = 111;

insert into TEST_TABLE_CPLX_NT (COL_NUM, COL_CT, COL_NT, COL_LR) values (123, CT_2(1232134, DATE'2008-07-23', 'WET3WSRF42R32EA3E'), TT_1( CT_2(324, DATE'2015-09-18', 'S3QA3EQE')), NULL);
