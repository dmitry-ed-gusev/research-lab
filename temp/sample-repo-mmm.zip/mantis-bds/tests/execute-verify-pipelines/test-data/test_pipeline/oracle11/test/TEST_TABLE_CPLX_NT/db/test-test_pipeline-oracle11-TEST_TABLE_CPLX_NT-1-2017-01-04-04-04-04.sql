alter session set current_schema = TEST_PIPELINE;

delete from TEST_TABLE_CPLX_NT where COL_NUM = 14;

update TEST_TABLE_CPLX_NT 
set COL_CT = CT_2(21321321434, DATE'1993-07-12', 'fwqxw4zr32qrez	12qEezwexf wrcf!@'),
	COL_NT = TT_1( CT_2(0, DATE'1945-09-14', 'dx2qr3esxfryc53wt43wr32a1a'), CT_2(-666, DATE'1998-11-22', 'z23ezwdez13qe3qddzewqdxdsadzsd'))
where COL_NUM = 5;

insert into TEST_TABLE_CPLX_NT (COL_NUM, COL_CT, COL_NT, COL_LR) values (111, CT_2(77, DATE'2028-10-28', '33zrzqewrx3ze2qedqwdz3qwexde'), TT_1( CT_2(897, DATE'2013-04-13', 'e3edaer32qed3eaqwesaw')), NULL);
