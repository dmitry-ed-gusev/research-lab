create user TEST_PIPELINE_ORACLE11 identified by "TEST_PIPELINE_ORACLE11";

grant connect to TEST_PIPELINE_ORACLE11;
grant resource to TEST_PIPELINE_ORACLE11;
