alter session set current_schema = TEST_PIPELINE;

insert into TEST_TABLE_D_CPLX (COL_NUM, COL_DT, COL_CT, COL_LONG) values (999, DATE'2099-04-13', CT_1D('qqwrfqwsafasfvadhyrdhrb', 579, DATE'1955-03-21', TIMESTAMP'2030-01-21 14:51:13'), NULL);
