alter session set current_schema = TEST_PIPELINE;

delete from TEST_TABLE_CPLX where COL_NUM = 9;

insert into TEST_TABLE_CPLX (COL_NUM, COL_DT, COL_CT, COL_BFILE) values (55, DATE'2014-11-23', CT_1('fdctxarqzderwzf4dersfae543534', 0.21321413432, DATE'2015-12-14', TIMESTAMP'2024-03-21 12:22:33.1'), NULL);

update TEST_TABLE_CPLX 
set COL_CT = CT_1('wqtrx24rs4tvcafxrx2q3', 1313143, DATE'1955-12-13', TIMESTAMP'2014-07-11 02:45:56.1')
where COL_NUM = 50;
