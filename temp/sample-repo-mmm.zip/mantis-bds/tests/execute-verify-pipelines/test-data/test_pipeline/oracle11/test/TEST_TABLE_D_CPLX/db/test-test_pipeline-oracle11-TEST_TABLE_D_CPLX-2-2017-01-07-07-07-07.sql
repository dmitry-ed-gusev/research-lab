alter session set current_schema = TEST_PIPELINE;

insert into TEST_TABLE_D_CPLX (COL_NUM, COL_DT, COL_CT, COL_LONG) values (1001, DATE'2100-11-03', CT_1D('scwxwxresz', 312579, DATE'1995-03-21', TIMESTAMP'2035-11-11 14:51:13'), NULL);
