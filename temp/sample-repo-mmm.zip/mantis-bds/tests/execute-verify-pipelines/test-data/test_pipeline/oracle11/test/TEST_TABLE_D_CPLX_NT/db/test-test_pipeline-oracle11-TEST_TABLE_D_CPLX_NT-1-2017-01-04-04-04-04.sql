alter session set current_schema = TEST_PIPELINE;

insert into TEST_TABLE_D_CPLX_NT (COL_NUMPK, COL_CT, COL_TT, COL_RAW) values (999, CT_2D(213, DATE'1913-02-21', 'fwfsadfdvfzvsav'), TT_1D( CT_2D(325, DATE'1968-08-10', 'wefwqwf3d31'), CT_2D(31, DATE'2040-09-04', 'asdfasf')), UTL_RAW.CAST_TO_RAW('dwqd32d2	vdsfcdd'));
