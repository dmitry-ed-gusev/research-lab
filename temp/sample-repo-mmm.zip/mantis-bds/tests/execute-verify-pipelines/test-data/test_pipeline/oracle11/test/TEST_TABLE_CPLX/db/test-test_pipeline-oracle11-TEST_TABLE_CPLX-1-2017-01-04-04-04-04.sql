alter session set current_schema = TEST_PIPELINE;

delete from TEST_TABLE_CPLX where COL_NUM = 11;

insert into TEST_TABLE_CPLX (COL_NUM, COL_DT, COL_CT, COL_BFILE) values (50, DATE'2012-09-07', CT_1('csdwgcec RSFGSDG 543534', -999, DATE'2025-02-04', TIMESTAMP'2014-03-21 12:22:33.1'), NULL);

update TEST_TABLE_CPLX 
set COL_CT = CT_1('выфаыпвыарвам', 333, DATE'1925-12-13', TIMESTAMP'2004-07-11 02:45:56.1')
where COL_NUM = 3;
