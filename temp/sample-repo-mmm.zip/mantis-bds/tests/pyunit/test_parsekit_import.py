#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import logging
from argparse import Namespace

from lib.common.configuration import Configuration
from lib.common.errors import ArgumentError
from pymocks.mocks import mock
from tests.pyunit.config_aware_test_case import ConfigAwareTestCase

from pipeline.steps.parsekit_import import ParsekitImport


class ParsekitImportTest(ConfigAwareTestCase):
    def test_SetupStart(self):
        conf = self._loadConfig()
        args = Namespace()
        setattr(args, "cmd", "start")
        step = mock(ParsekitImport, configuration=conf, logger=logging.getLogger(), args=args)
        step._ParsekitImport__setup_common.when()
        step._ParsekitImport__setup_start.when()
        step.setup()
        self.assertTrue(len(step._ParsekitImport__setup_start.calls) == 1)

    def test_ExecutionTest(self):
        conf = Configuration()
        args = Namespace()
        setattr(args, "cmd", "test")
        step = ParsekitImport(configuration=conf, logger=logging.getLogger(), args=args)
        step.execute()

    def test_ExecutionProgress(self):
        conf = Configuration()
        args = Namespace()
        setattr(args, "cmd", "progress")
        step = mock(ParsekitImport, configuration=conf, logger=logging.getLogger(), args=args)
        step._ParsekitImport__get_parsekit_import_progress.when()
        step.execute()

    def test_ExecutionWithError(self):
        conf = Configuration()
        args = Namespace()
        setattr(args, "cmd", "wrong")
        step = mock(ParsekitImport, configuration=conf, logger=logging.getLogger(), args=args)
        step._ParsekitImport__get_parsekit_import_progress.when()
        with self.assertRaises(ArgumentError):
            step.execute()
