#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import logging
from argparse import Namespace

from lib.common.configuration import Configuration
from lib.common.errors import HiveError
from lib.hive.hive_client import HiveClient
from pymocks.mocks import mock
from tests.pyunit.config_aware_test_case import ConfigAwareTestCase

from pipeline.steps.curated_to_latest import CuratedToLatest


class CuratedToLatestTest(ConfigAwareTestCase):

    def setUp(self):
        pass

    def test_SetupHiveVarsFromArgs(self):

        conf = self._loadConfig()
        args = Namespace()
        setattr(args, "loadDTTM", "test")
        setattr(args, "sourceSystemEnv", "test")
        step = mock(CuratedToLatest, configuration=conf, logger=logging.getLogger(), args=args)
        step.verify_file_exist.when().add_return(True)
        step.setup()
        self.assertEqual(step.hive_vars["LOAD_DTTM_VAL"], "test")

    def test_Execution(self):

        conf = Configuration()
        step = mock(CuratedToLatest, configuration=conf, logger=logging.getLogger(), args=None)
        hive_client = mock(HiveClient, configuration=step.configuration, logger=step.logger)
        hive_client.execute.when()
        step.get_hive_client.when().add_return(hive_client)
        step.execution_script = 'test_dir/test_file'
        step.hive_vars = {}
        step.execute()
        self.assertEqual(hive_client.execute.calls[0]["q_value"], "test_dir/test_file")

    def test_ExecutionWithError(self):

        conf = Configuration()
        step = mock(CuratedToLatest, configuration=conf, logger=logging.getLogger(), args=None)
        hive_client = mock(HiveClient, configuration=step.configuration, logger=step.logger)
        hive_client.execute.when().add_raise(HiveError("Err"))
        step.get_hive_client.when().add_return(hive_client)
        step.execution_script = 'test_dir/test_file'
        step.hive_vars = {}
        with self.assertRaises(HiveError):
            step.execute()

