#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import ConfigParser
import os
import re

import yaml

from tests.pyunit.config_aware_test_case import ConfigAwareTestCase


class EnvironmentConfigurationsTest(ConfigAwareTestCase):
    env_list = ["dev", "test", "stg", "prod"]
    env_uris = ["BDPDEV", "BDPTEST", "BDPSTG", "BDP"]
    env_users = ["mantisetld", "mantisetls", "mantisetlu", "mantisetl"]

    def test_EnvConfigFiles(self):
        configs = {}
        for env in self.env_list:
            configs[env] = self.__load_yml(env)
        self.__compare_yml_configs(**configs)

    def test_ODBC_Configs(self):
        options = None
        last_env = None
        self.config_dir = os.path.join(os.path.abspath(""), "config")
        for env in self.env_list:
            env_options = self.__load_ini_options(env)
            if last_env is None:
                options = env_options
            else:
                self.assertListEqual(options, env_options,
                                     "%s and %s ODBC configs have different entries" % (last_env, env))
            last_env = env

    def test_EnvURIs(self):
        for i in range(len(self.env_list)):
            self.__verify_env_uri(self.env_uris[i], os.path.join("odbc", self.env_list[i] + ".ini"))
            self.__verify_env_uri(self.env_uris[i], self.env_list[i] + ".yml")

    def test_Username(self):
        for i in range(len(self.env_list)):
            file = self.env_list[i] + ".yml"
            with open(os.path.join(self.config_dir, file), 'r') as f:
                cont = f.read()
                all_entries = re.findall("(mantisetl[A-Za-z0-9_]*)", cont, flags=re.IGNORECASE)
                for entry in all_entries:
                    self.assertEqual(entry, self.env_users[i], "Unexpected Username in %s config file" % file)

    def __compare_yml_configs(self, **configs):
        keys = None
        cfg_type = None
        last_env = None
        for env in configs:
            cfg = configs[env]
            if last_env is None:
                last_env = env
                cfg_type = type(cfg)
                if isinstance(cfg, dict):
                    keys = cfg.keys()
            else:
                self.assertEqual(cfg_type, type(cfg), "Different value types of %s and %s" % (last_env, env))
                if isinstance(cfg, dict):
                    self.assertListEqual(keys, cfg.keys(), "%s and %s have different entries" % (last_env, env))
        if keys:
            for key in keys:
                new_args = {}
                for env in configs:
                    new_args["%s.%s" % (env, key)] = configs[env][key]
                self.__compare_yml_configs(**new_args)

    def __load_ini_options(self, env):
        cfp = ConfigParser.RawConfigParser(allow_no_value=True)
        cfp.read(os.path.join(self.config_dir, "odbc", env + ".ini"))
        self.assertTrue(cfp.has_section("ODBC"))
        yml = self.__load_yml(env)
        dsn = yml["odbc_dsn_name"]
        self.assertEqual(cfp.get("ODBC Data Sources", dsn), "Hortonworks Hive ODBC Driver 64-bit",
                         "Unexpected ODBC driver name")
        self.assertTrue(cfp.has_section(dsn), "DSN config is missing or names are mismatched")
        return cfp.options(dsn)

    def __load_yml(self, env):
        with open(os.path.join(self.config_dir, env + ".yml"), 'r') as f:
            return yaml.load(f)

    def __verify_env_uri(self, expected, file_name):
        with open(os.path.join(self.config_dir, file_name), 'r') as f:
            cont = f.read()
            all_entries = re.findall("(BDP[A-Z0-9_]*)", cont, flags=re.IGNORECASE)
            for entry in all_entries:
                env_entry = entry.upper()
                if env_entry.endswith("NN"):
                    env_entry = env_entry[:-2]
                if env_entry.endswith("PROD"):
                    # There are cases when it's named bdpprod instead of bdp
                    env_entry = env_entry[:-4]
                self.assertEqual(env_entry, expected, "Unexpected URI part in %s config file" % file_name)
