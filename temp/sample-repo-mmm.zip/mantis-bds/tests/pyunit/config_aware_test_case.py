# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os
import unittest

from lib.common.configuration import Configuration


class ConfigAwareTestCase(unittest.TestCase):

    longMessage = True
    config_dir = os.path.abspath("config")

    def _loadConfig(self):
        conf = Configuration()
        conf.merge_dict(Configuration.parse_yaml(os.path.join(self.config_dir, "dev.yml")))
        conf.merge_dict(Configuration.parse_yaml(os.path.join(self.config_dir, "common.yml")))
        conf.set("config_location", self.config_dir)
        conf.set("source_system", "test_system")
        conf.set("source_system_env", "dev")
        conf.set("source_system_location", "global")
        conf.set("source_table", "test_table")
        conf.set("step_name", "test_step")
        conf.set("mdc_pid", "123")
        conf.set("hadoop_client_home", "tests/pyunit/ut-sample-data")
        return conf
