#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import logging
from argparse import Namespace

from hdfs.client import HdfsError
from lib.common.configuration import Configuration
from pymocks.mocks import mock
from tests.pyunit.config_aware_test_case import ConfigAwareTestCase

from pipeline.steps.cleanup_obsolete_files import CleanupObsoleteFiles


class CleanupObsoleteFilesTest(ConfigAwareTestCase):

    def test_Execution(self):

        conf = Configuration()
        args = Namespace()
        setattr(args, "layerDirectory", "test")
        setattr(args, "retentionPeriod", 10)
        step = mock(CleanupObsoleteFiles, configuration=conf, logger=logging.getLogger(), args=args)
        hdfs_client = mock().with_method("list", ["hdfs_path", "status"]).with_method("resolve", ["hdfs_path"]).with_method("delete", ["hdfs_path", "recursive=False"])
        hdfs_client.list.when().add_return([("test1", {"modificationTime" : 12}), ("test2", {"modificationTime" : 13})])
        hdfs_client.resolve.when().add_return("test")
        hdfs_client.delete.when().add_return(True)
        step.get_hdfs_client.when().add_return(hdfs_client)
        step.execute()
        self.assertTrue(len(hdfs_client.delete.calls) > 0)

    def test_ExecutionWithError(self):
        conf = Configuration()
        args = Namespace()
        setattr(args, "layerDirectory", "test")
        setattr(args, "retentionPeriod", 10)
        step = mock(CleanupObsoleteFiles, configuration=conf, logger=logging.getLogger(), args=args)
        hdfs_client = mock().with_method("list", ["hdfs_path", "status"]).with_method("resolve", ["hdfs_path"]).with_method("delete", ["hdfs_path", "recursive=False"])
        hdfs_client.list.when().add_return([("test1", {"modificationTime" : 12}), ("test2", {"modificationTime" : 13})])
        hdfs_client.resolve.when().add_return("test")
        hdfs_client.delete.when().add_return(False)
        step.get_hdfs_client.when().add_return(hdfs_client)
        with self.assertRaises(HdfsError):
            step.execute()


