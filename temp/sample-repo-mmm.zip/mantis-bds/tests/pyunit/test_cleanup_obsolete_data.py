#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import logging
from argparse import Namespace

from lib.common.configuration import Configuration
from lib.common.errors import HiveError
from pymocks.mocks import mock
from tests.pyunit.config_aware_test_case import ConfigAwareTestCase

from pipeline.steps.cleanup_obsolete_data import CleanupObsoleteData


class CleanupObsoleteDataTest(ConfigAwareTestCase):
    def test_SetupHiveVarsFromArgs(self):
        conf = self._loadConfig()
        args = Namespace()
        setattr(args, "targetLayer", "raw")
        setattr(args, "loadDTTM", "test")
        setattr(args, "retentionPeriod", 10)
        setattr(args, "sourceSystemEnv", "test")
        step = mock(CleanupObsoleteData, configuration=conf, logger=logging.getLogger(), args=args)
        step.verify_file_exist.when().add_return(True)
        step.setup()
        self.assertEqual(step.hive_vars["LOAD_DTTM_VAL"], "test")

    def test_Execution(self):
        conf = Configuration()
        args = Namespace()
        setattr(args, "loadDTTM", "test")
        setattr(args, "cleanupType", "partitions")
        setattr(args, "targetLayer", "raw")
        setattr(args, "retentionPeriod", 10)
        setattr(args, "sourceSystemEnv", "test")
        step = mock(CleanupObsoleteData, configuration=conf, logger=logging.getLogger(), args=args)
        hive_client = mock().with_method("execute", ["q_type", "q_value", "vars", "ret_val"])
        hive_client.execute.when({"ret_val": True}).add_return(["1", "2", "3", "4"])
        step.get_hive_client.when().add_return(hive_client)
        step.select_script = ""
        step.cleanup_script = ""
        step.hive_vars = {
            "LOAD_DTTM_VAL": "test",
            "RETENTION_PERIOD": 10}
        step.execute()
        self.assertTrue(len(hive_client.execute.calls) > 0)

    def test_ExecutionWithError(self):
        conf = Configuration()
        args = Namespace()
        setattr(args, "loadDTTM", "test")
        setattr(args, "cleanupType", "partitions")
        setattr(args, "targetLayer", "raw")
        setattr(args, "retentionPeriod", 10)
        setattr(args, "sourceSystemEnv", "test")
        step = mock(CleanupObsoleteData, configuration=conf, logger=logging.getLogger(), args=args)
        hive_client = mock().with_method("execute", ["q_type", "q_value", "vars", "ret_val"])
        hive_client.execute.when({"ret_val": True}).add_return(["1", "2", "3", "4"])
        hive_client.execute.when({"ret_val": False}).add_raise(HiveError("Err"))
        step.get_hive_client.when().add_return(hive_client)
        step.select_script = ""
        step.cleanup_script = ""
        step.hive_vars = {
            "LOAD_DTTM_VAL": "test",
            "RETENTION_PERIOD": 10}
        with self.assertRaises(HiveError):
            step.execute()
