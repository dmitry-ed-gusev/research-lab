#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os
import unittest
from lib.hdfs.count_rows import RowCounter


class CountRowsTest(unittest.TestCase):
    def setUp(self):
        self.csvs = [("\"a\",2\n\"3,4\n", 2),
                     ("\"a\",2\n\"3,4", 2),
                     ("\"a\"\"\",2\n\"3,4\n", 2),
                     ("\"a\"\"\n\"\"b\n\", 2|\n\"3\",4\n7u,44", 3)]

    def test_CountRowsCsvLines(self):
        for csv in self.csvs:
            result = RowCounter.count_rows_csv_lines(csv[0])
            self.assertEqual(result, csv[1],
                             "Csv counter failed: expected %d, got %d on\n%s" % (csv[1], result, csv[0]))


if __name__ == '__main__':
    unittest.main()
