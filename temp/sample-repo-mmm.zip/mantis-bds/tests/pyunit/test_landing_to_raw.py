#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import logging
from argparse import Namespace

from lib.common.errors import YarnError
from lib.hadoop.yarn_config import YarnConfig
from lib.yarn.app_context import AppContext
from lib.yarn.yarn_client import YarnClient
from pymocks.mocks import mock
from tests.pyunit.config_aware_test_case import ConfigAwareTestCase

from pipeline.steps.landing_to_raw import LandingToRaw


class LandingToRawTest(ConfigAwareTestCase):

    def setUp(self):
        self.conf = self._loadConfig()
        self.args = Namespace()
        setattr(self.args, "loadDTTM", "test")
        yarn_config = mock(YarnConfig, self.conf, logging.getLogger())
        yarn_config.get_resource_manager_nodes.when().add_return(["rm1"])
        self.yarn_client = mock(YarnClient, config=self.conf, logger=logging.getLogger(), hdfs_client=None,
                                yarn_config=yarn_config, mapred_config=None)

    def test_SetupHiveVarsFromArgs(self):
        setattr(self.args, "rawDB", "test")
        setattr(self.args, "rawTable", "test")
        setattr(self.args, "filePath", "test")
        setattr(self.args, "mode", "test")
        step = mock(LandingToRaw, configuration=self.conf, logger=logging.getLogger(), args=self.args)
        application = mock(AppContext, config=step.configuration, logger=step.logger, hdfs_client=None)
        application.add_local_resource.when()
        application.add_container_env.when()
        self.yarn_client.create_application.when().add_return(application)
        step.get_yarn_client.when().add_return(self.yarn_client)
        step.setup()
        self.assertIsNotNone(application.app_name)
        self.assertIsNotNone(len(application.add_local_resource.calls) > 0)
        self.assertTrue(len(application.add_container_env.calls) > 0)

    def test_Execution(self):
        step = mock(LandingToRaw, configuration=self.conf, logger=logging.getLogger(), args=self.args)
        application = mock(AppContext, config=step.configuration, logger=step.logger, hdfs_client=None)
        self.yarn_client.submit_app.when()
        self.yarn_client.wait_for_finish.when()
        step.app_context = application
        step.yarn_client = self.yarn_client
        step.execute()
        self.assertTrue(len(self.yarn_client.submit_app.calls) > 0)

    def test_ExecutionWithError(self):
        step = mock(LandingToRaw, configuration=self.conf, logger=logging.getLogger(), args=self.args)
        application = mock(AppContext, config=step.configuration, logger=step.logger, hdfs_client=None)
        self.yarn_client.submit_app.when().add_raise(YarnError("Err"))
        self.yarn_client.wait_for_finish.when()
        step.app_context = application
        step.yarn_client = self.yarn_client
        with self.assertRaises(YarnError):
            step.execute()

