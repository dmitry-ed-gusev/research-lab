#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import logging
from argparse import Namespace

from lib.common.configuration import Configuration
from lib.common.shell_executor import ShellExecutor
from pymocks.mocks import mock
from tests.pyunit.config_aware_test_case import ConfigAwareTestCase

from pipeline.steps.csv_to_abstract import CsvToAbstract


class CsvToAbstractTest(ConfigAwareTestCase):

    def test_SetupHiveVarsFromArgs(self):

        conf = self._loadConfig()
        args = Namespace()
        setattr(args, "abstractDatasetName", "test")
        setattr(args, "consumerCSV", "test")
        step = mock(CsvToAbstract, configuration=conf, logger=logging.getLogger(), args=args)
        step._CsvToAbstract__export_abstract_credentials.when()
        step.setup()

    def test_Execution(self):

        @staticmethod
        def execute_shell_mock(command, logger, log_level="TRACE", shell=False):
            pass
        conf = Configuration()
        args = Namespace()
        setattr(args, "abstractDatasetName", "test")
        setattr(args, "consumerCSV", "test")
        setattr(args, "abstractLogLevel", "test")
        step = mock(CsvToAbstract, configuration=conf, logger=logging.getLogger(), args=args)
        hdfs_client = mock().with_method("cat").with_method("status")
        hdfs_client.cat.when().add_return("test") # Same return for schema and previous_schema
        hdfs_client.status.when().add_return("test") # Status is not None
        schema = mock().with_method("write").with_method("flush").with_field("name", "test")
        ShellExecutor.execute_shell = execute_shell_mock
        step.get_hdfs_client.when().add_return(hdfs_client)
        step.export_csv_file = 'test_dir/test_file'
        step.csv2abstract_script = "test"
        step.previous_schema_file = ""
        step.schema_file = ""
        step.schema_local_file = schema
        step.reindex_collection = None
        step.credentials_file = "cred"
        step.execute()

    def test_ExecutionWithError(self):

        @staticmethod
        def execute_shell_mock(command, logger, log_level="TRACE", shell=False):
            raise Exception

        conf = Configuration()
        args = Namespace()
        setattr(args, "abstractDatasetName", "test")
        setattr(args, "consumerCSV", "test")
        setattr(args, "abstractLogLevel", "test")
        step = mock(CsvToAbstract, configuration=conf, logger=logging.getLogger(), args=args)
        hdfs_client = mock().with_method("cat").with_method("status")
        hdfs_client.cat.when().add_return("test") # Same return for schema and previous_schema
        hdfs_client.status.when().add_return("test") # Status is not None
        schema = mock().with_method("write").with_method("flush").with_field("name", "test")
        ShellExecutor.execute_shell = execute_shell_mock
        step.get_hdfs_client.when().add_return(hdfs_client)
        step.export_csv_file = 'test_dir/test_file'
        step.csv2abstract_script = "test"
        step.previous_schema_file = ""
        step.schema_file = ""
        step.schema_local_file = schema
        step.reindex_collection = None
        with self.assertRaises(Exception):
            step.execute()
