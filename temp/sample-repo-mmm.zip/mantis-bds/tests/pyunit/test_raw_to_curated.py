#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import logging
from argparse import Namespace

from lib.common.configuration import Configuration
from lib.common.errors import HiveError
from pymocks.mocks import mock
from tests.pyunit.config_aware_test_case import ConfigAwareTestCase

from pipeline.steps.raw_to_curated import RawToCurated


class RawToCuratedTest(ConfigAwareTestCase):

    def test_SetupHiveVarsFromArgs(self):

        conf = self._loadConfig()
        args = Namespace()
        setattr(args, "loadID", 1)
        setattr(args, "loadDTTM", "test")
        setattr(args, "ingestType", "full")
        setattr(args, "extractDTTM", "test")
        setattr(args, "sourceSystemEnv", "test")
        step = mock(RawToCurated, configuration=conf, logger=logging.getLogger(), args=args)
        step.verify_file_exist.when().add_return(True)
        step.setup()
        self.assertEqual(step.hive_vars["LOAD_DTTM_VAL"], "test")

    def test_Execution(self):
        conf = Configuration()
        step = mock(RawToCurated, configuration=conf, logger=logging.getLogger(), args=None)
        hive_client = mock().with_method("execute", ["q_type", "q_value", "vars", "ret_val"])
        step.get_hive_client.when().add_return(hive_client)
        step.execution_script = 'test_dir/test_file'
        step.partition_script = 'test_dir1/test_file1'
        step.hive_vars = {}
        step.execute()
        self.assertEqual(hive_client.execute.calls[0]["q_value"], "test_dir/test_file")
        self.assertEqual(hive_client.execute.calls[1]["q_value"], 'test_dir1/test_file1')

    def test_ExecutionWithError(self):
        conf = Configuration()
        step = mock(RawToCurated, configuration=conf, logger=logging.getLogger(), args=None)
        hive_client = mock().with_method("execute", ["q_type", "q_value", "vars", "ret_val"])
        hive_client.execute.when().add_raise(HiveError("Err"))
        step.get_hive_client.when().add_return(hive_client)
        step.execution_script = 'test_dir/test_file'
        step.partition_script = 'test_dir1/test_file1'
        step.hive_vars = {}
        with self.assertRaises(HiveError):
            step.execute()
