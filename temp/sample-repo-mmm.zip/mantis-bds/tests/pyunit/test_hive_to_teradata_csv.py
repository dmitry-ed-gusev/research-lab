#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import logging
from argparse import Namespace

from lib.common.configuration import Configuration
from lib.common.errors import HiveError
from pymocks.mocks import mock
from tests.pyunit.config_aware_test_case import ConfigAwareTestCase

from pipeline.steps.hive_to_teradata_csv import HiveToTeradataCsv


class HiveToTeradataCsvTest(ConfigAwareTestCase):

    def test_SetupHiveVarsFromArgs(self):

        conf = self._loadConfig()
        args = Namespace()
        setattr(args, "loadDTTM", "test")
        setattr(args, "forceExport", "True")
        setattr(args, "exportCSV", "test")
        setattr(args, "exportType", "full")
        setattr(args, "sourceSystemEnv", "test")
        step = mock(HiveToTeradataCsv, configuration=conf, logger=logging.getLogger(), args=args)
        step.verify_file_exist.when().add_return(True)
        step.setup()
        self.assertEqual(step.hive_vars["LOAD_DTTM_VAL"], "test")

    def test_Execution(self):

        conf = Configuration()
        step = mock(HiveToTeradataCsv, configuration=conf, logger=logging.getLogger(), args=None)
        step.delete_if_exist.when()
        step.export_hive_to_csv.when()
        step.export_csv_file = 'test_dir/test_file'
        step.execute()
        self.assertTrue(len(step.export_hive_to_csv.calls) > 0)

    def test_ExecutionWithError(self):
        conf = Configuration()
        step = mock(HiveToTeradataCsv, configuration=conf, logger=logging.getLogger(), args=None)
        step.delete_if_exist.when()
        step.export_hive_to_csv.when().add_raise(HiveError("Err"))
        step.export_csv_file = 'test_dir/test_file'
        with self.assertRaises(HiveError):
            step.execute()

