#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import logging
from argparse import Namespace

from lib.common.configuration import Configuration
from lib.common.errors import HiveError
from pymocks.mocks import mock

from pipeline.steps.hive_to_delta_csv import HiveToDeltaCsv
from tests.pyunit.config_aware_test_case import ConfigAwareTestCase


class HiveToDeltaCsvTest(ConfigAwareTestCase):

    def test_SetupHiveVarsFromArgs(self):

        conf = self._loadConfig()
        args = Namespace()
        setattr(args, "loadID", 1)
        setattr(args, "loadDTTM", "test")
        setattr(args, "ingestType", "full")
        setattr(args, "extractDTTM", "test")
        setattr(args, "forceExport", "True")
        setattr(args, "exportCSV", "test")
        setattr(args, "sourceSystemEnv", "test")
        step = mock(HiveToDeltaCsv, configuration=conf, logger=logging.getLogger(), args=args)
        step.verify_file_exist.when().add_return(True)
        step.setup()
        self.assertEqual(step.hive_vars["LOAD_DTTM_VAL"], "test")

    def test_Execution(self):

        conf = Configuration()
        step = mock(HiveToDeltaCsv, configuration=conf, logger=logging.getLogger(), args=None)
        step.delete_if_exist.when()
        step.export_hive_to_csv.when()
        step._HiveToDeltaCsv__export_to_json.when()
        step._HiveToDeltaCsv__set_acl.when()
        step.export_csv_file = 'test_dir/test_file'
        step.target_folder = ''
        step.export_json_file = ''
        step.hive_vars = {}
        step.execute()
        self.assertTrue(len(step.export_hive_to_csv.calls) > 0)

    def test_ExecutionWithError(self):
        conf = Configuration()
        step = mock(HiveToDeltaCsv, configuration=conf, logger=logging.getLogger(), args=None)
        step.delete_if_exist.when()
        step.export_hive_to_csv.when().add_raise(HiveError("Err"))
        step._HiveToDeltaCsv__export_to_json.when()
        step._HiveToDeltaCsv__set_acl.when()
        step.export_csv_file = 'test_dir/test_file'
        step.target_folder = ''
        step.export_json_file = ''
        step.hive_vars = {}
        with self.assertRaises(HiveError):
            step.execute()
