# coding=utf-8
# Copyright (c) 2017 Merck Sharp & Hohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import robot
import sys
import os

def get_root_path():
    return os.path.dirname(os.path.abspath(__file__))

def get_env_file_path():
    return 'environments/' + os.environ.get('ROBOT_ENV', 'dev_env') + '.py'

def print_help():
    print "USAGE: python run-robot.py <folder-path> [specific-test]"
    print "\texamples:"
    print "\tpython run-robot.py test_pipeline/oracle11"
    print "\tpython run-robot.py test_pipeline/oracle11 test_table_cplx"

def run_robot(root, folder, suite, testcase):
    args = {
        'variable': 'ROOTDIR:' + root,
        'variablefile': root + '/' + get_env_file_path(),
        'outputdir': root + '/reports/' + folder,
    }
    if suite is not None:
        args['suite'] = suite
    if testcase is not None:
        args['test'] = testcase.split(',')

    robot.run(root + '/' + folder, **args)

def check_env_vars():
    if 'ROBOT_RSA_KEY' not in os.environ:
        print 'Env var ROBOT_RSA_KEY should point to file with ssh key'
        return False
    if 'ROBOT_USER' not in os.environ:
        print 'Env var ROBOT_USER should have deploy username'
        return False
    return True

def main():
    if not check_env_vars():
        return
    if len(sys.argv) < 2:
        print_help()
    	return
    root = get_root_path()
    folder = sys.argv[1]
    suite = None if len(sys.argv) < 3 else sys.argv[2]
    testcase = None if len(sys.argv) < 4 else sys.argv[3]
    run_robot(root, folder, suite, testcase)

if __name__ == '__main__':
    main()
