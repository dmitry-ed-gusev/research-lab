# coding=utf-8
# Copyright (c) 2017 Merck Sharp & Hohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

SSH_HOST = 'mantis-01.bdpdev.gin.merck.com'
SSH_PORT = '22'
SSH_USER = 'mantisetld'
USER = 'nightly'
activate_command = 'source /home/mantisetld/' + USER + '/mantis-virtualenv/bin/activate;'
cd_command = 'cd /home/mantisetld/' + USER + '/mantis-pipeline/rel;'
set_ldlp_command = 'export LD_LIBRARY_PATH=/home/mantisetld/' + USER +'/instantclient_12_2:$LD_LIBRARY_PATH;'
execute_step_command ='python execute-verify-pipelines.py --landing_dir /home/mantisetld/' + USER
clean_tables_success_msg = "Cleanup completed"
SUCCESS_MSG =  " completed successfully"
RSAKEY = '/secret_key'
ROOTDIR = '/robot'
