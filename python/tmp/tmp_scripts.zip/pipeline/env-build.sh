#!/usr/bin/env bash

CDIR="$(dirname $0)"
#General directory properties
export ROOT_DIR=${CDIR}/..
export LIB_DIR=${ROOT_DIR}/lib

#Command executor wrapper
export CMD_EXECUTOR="${ROOT_DIR}/deploy/test_echo.sh "

# Hive/MR basic execution parameters
export BEELINE_CMD="${ROOT_DIR}/deploy/test_echo.sh "

#ParseKit basic execution parameters
export CURL_CMD="${ROOT_DIR}/deploy/test_echo.sh "
export JQ_CMD="${ROOT_DIR}/deploy/test_echo.sh "
export PARSEKIT_URL=" "
export PARSEKIT_USER=${PARSEKIT_USER:-dummy}
export PARSEKIT_PASSWORD=${PARSEKIT_PASSWORD:-dummy}

export CSV2HIVE_TOOL_SCRIPT="${ROOT_DIR}/deploy/test_echo.sh "
export CSV2ABSTRACT_SCRIPT="${ROOT_DIR}/deploy/test_echo.sh "
export VERIFY_PIPELINE_SCRIPT="${ROOT_DIR}/deploy/test_echo.sh "

export HIVE_CONNECTION_URL=" "
export YARN_QUEUE=" "

# HDFS parameters
export KNOX_HDFS_URI=" "

export ABSTRACT_CREDENTIALS_FILE="${ROOT_DIR}/deploy/test_echo.sh "
export LANDING_DIR='.'
