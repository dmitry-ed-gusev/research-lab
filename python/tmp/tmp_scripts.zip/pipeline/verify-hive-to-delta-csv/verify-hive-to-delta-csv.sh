#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e
${CMD_EXECUTOR} --echo "Executing verify-hive-to-delta-csv pipeline step"

BASEDIR="$(dirname $0)"

# Import libs
for file in $(ls ${LIB_DIR}/*.sh); do
    source ${file}
done

get_argument_by_name CONSUMER_CSV --consumerCSV required "$@"
get_argument_by_name VERIFY_CSV --verifyCSV required "$@"

resolve_verify_csv_export_path TMP_PATH OUTPUT_CSV

${CMD_EXECUTOR} --call ${VERIFY_PIPELINE_SCRIPT} \
    --pipeline-step="${STEP_NAME}" \
    --verify-csv="${VERIFY_CSV}" \
    --export-dir="${TMP_PATH}" \
    --output-csv="${OUTPUT_CSV}" \
    --consumer-csv="${CONSUMER_CSV}" --level TRACE

${CMD_EXECUTOR} --echo "Verify-hive-to-delta-csv pipeline step executed successfully"
