#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e

# Enabling python virtualenv for further processing
USERNAME_PROCESSED=$(whoami)
if [ -d "/home/${USERNAME_PROCESSED}/mantis-virtualenv" ]; then
    . /home/${USERNAME_PROCESSED}/mantis-virtualenv/bin/activate
fi


# Current process ID
export MDC_PID=$$

BASEDIR="$(dirname $0)"
# Add mantis-pipeline root dir as Python Path for proper module resolving
export PYTHONPATH="${BASEDIR}/.."
# Mantis config location
export CONFIG_LOCATION="${CONFIG_LOCATION:-${BASEDIR}/../../../mantis-config}"

# Execute mdc.py
"${BASEDIR}/mdc.py" "$@"
exit $?
