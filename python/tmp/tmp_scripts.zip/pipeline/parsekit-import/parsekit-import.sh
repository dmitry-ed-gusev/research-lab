#!/usr/bin/env bash
# Copyright  2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

function parsekit() {
  #TEMPORARY. The -k option should be removed when the issue https://issues.merck.com/browse/ENIGMA-258 is fixed.
  ${CURL_CMD} -v -k -u "${PARSEKIT_USER}@merck.com:${PARSEKIT_PASSWORD}" -H "Content-Type: application/json" -H "Accept: application/json" "$@"
}

function getParseKitImportProgress() {
    ${CMD_EXECUTOR} --echo "Getting progress of parsekit-import step" --level DEBUG
    get_argument_by_name PARSER_RUN_URL '--parserRunURL' 'required' "$@"

    ${CMD_EXECUTOR} --echo "Getting the state of the the parser run at ${PARSER_RUN_URL}" --level DEBUG

    PARSER_RUN_RESPONSE=$(parsekit -X GET "${PARSER_RUN_URL}")
    PARSER_RUN_STATE=$(echo "${PARSER_RUN_RESPONSE}" | ${JQ_CMD} -r ".state")

    if [[ -z "${PARSER_RUN_STATE}" || "${PARSER_RUN_STATE}" == 'null' ]]; then
        ${CMD_EXECUTOR} --echo "Could not obtain the parser run status, the response was:\n${PARSER_RUN_RESPONSE}" --level ERROR
        ${CMD_EXECUTOR} --echo "parsekit-import-progress pipeline step failed" --level ERROR
        exit 1
    else
        echo 'ParseKitRunState: "'${PARSER_RUN_STATE}'"'

        #Remove the properties stdout and stderr from the context object and write it to the console
        CTX_TEMP=$(echo "${PARSER_RUN_RESPONSE}" | ${JQ_CMD} -r "del(.stdout)")
        CTX_TEMP=$(echo "${CTX_TEMP}" | ${JQ_CMD} -r "del(.stderr)")
        echo -e "\nContext: \n ${CTX_TEMP}\n"

        #Write the Base64 encoded content of the stdout property to the stdout
        PARSER_RUN_STDOUT=$(echo "${PARSER_RUN_RESPONSE}" | ${JQ_CMD} -r ".stdout")
        if [[ "${PARSER_RUN_STDOUT}" != 'null' ]]; then
            echo `echo ${PARSER_RUN_STDOUT} | base64 --decode`
        fi

        #Write the Base64 encoded content of the stderr property to the stderr
        PARSER_RUN_STDERR=$(echo "${PARSER_RUN_RESPONSE}" | ${JQ_CMD} -r ".stderr")
        if [[ "${PARSER_RUN_STDERR}" != 'null' ]]; then
           >&2 echo `echo ${PARSER_RUN_STDERR} | base64 --decode`
        fi

        ${CMD_EXECUTOR} --echo "parsekit-import-progress pipeline step executed successfully"
        exit 0
    fi
}

function startParseKitImport() {
    get_argument_by_name ARG_INGEST_TYPE --ingestType required "$@"
    get_argument_by_name ARG_FILEPATH --filePath required "$@"
    get_argument_by_name ARG_LOAD_ID --loadID required "$@"
    get_argument_by_name ARG_EXTRACT_DTTM --extractDTTM required "$@"

    get_argument_by_name ARG_PARSEKIT_ORG_ID --parserOrganization required "$@"
    get_argument_by_name ARG_PARSER_TAG_PREFIX --parserTagPrefix required "$@"
    get_argument_by_name ARG_PARSER_ID --parserID required "$@"

    get_argument_by_name ARG_DELTA_COLUMN --sourceTableDeltaColumn optional "$@"
    get_argument_by_name ARG_LOWER_BOUND --deltaLowerBound optional "$@"
    get_argument_by_name ARG_UPPER_BOUND --deltaUpperBound optional "$@"

    CONTEXT_OBJECT_FILENAME="context-${ARG_PARSEKIT_ORG_ID}-${ARG_PARSER_ID}.json"

    PARSERS_URL="${PARSEKIT_URL}/orgs/${ARG_PARSEKIT_ORG_ID}/parsers"
    ${CMD_EXECUTOR} --echo "Getting list of available parsers from ${PARSERS_URL}" --level DEBUG

    PARSER_LIST=$(parsekit -X GET "${PARSERS_URL}")
    ${CMD_EXECUTOR} --echo "${PARSER_LIST}" --level DEBUG


    PARSER_TAG="${ARG_PARSER_TAG_PREFIX}${ARG_PARSER_ID}"
    ${CMD_EXECUTOR} --echo "Looking for parser with tag ${PARSER_TAG}" --level DEBUG

    while read key ; do
        PARSER_TAGS=$(echo "${PARSER_LIST}" | ${JQ_CMD} ".[$key].tags")
        ${CMD_EXECUTOR} --echo "Tags: ${key} ${PARSER_TAGS}" --level DEBUG

        if [[ ${PARSER_TAGS} =~ ${PARSER_TAG} ]]; then
            PARSER_INFO=$(echo "${PARSER_LIST}" | ${JQ_CMD} -r ".[$key]")
            PARSER_ID=$(echo "${PARSER_INFO}" | ${JQ_CMD} -r ".id")
            PARSER_NAME=$(echo "${PARSER_INFO}" | ${JQ_CMD} -r ".name")
            PARSER_STATE=$(echo "${PARSER_INFO}" | ${JQ_CMD} -r ".state")
            ${CMD_EXECUTOR} --echo "Available parser found: ${PARSER_NAME} with id: ${PARSER_ID} is ${PARSER_STATE}" --level DEBUG

            PARSER_URL="${PARSERS_URL}/${PARSER_ID}"

            if [[ ${PARSER_STATE} != "enabled" ]]; then
                ${CMD_EXECUTOR} --echo "Getting state of the suspended parser ${PARSER_URL}" --level DEBUG
                PARSER_INFO=$(parsekit -X GET "${PARSER_URL}")
                #TODO This should be more robust, but unfortunately the following jq command modifies the JSON response so that it cannot be used to PUT changes
                #echo "${PARSER_INFO}" | ${JQ_CMD} --ascii-output '.state="enabled"' > parser_context.json
                CONTEXT_OBJECT="${PARSER_INFO/suspended/enabled}"
                CONTEXT_OBJECT="${CONTEXT_OBJECT}/aborted/enabled}"
                echo ${CONTEXT_OBJECT} > "${CONTEXT_OBJECT_FILENAME}"
                ${CMD_EXECUTOR} --echo "Enabling the parser ${PARSER_URL}" --level DEBUG
                parsekit -X PUT --data-binary "@${CONTEXT_OBJECT_FILENAME}" "${PARSER_URL}"
                rm -f "${CONTEXT_OBJECT_FILENAME}"
                echo
                WAIT_COUNTER=30
                while [  ${PARSER_STATE} != "enabled" ] ; do
                    ${CMD_EXECUTOR} --echo "Waiting for parsekit to become enabled #${WAIT_COUNTER}" --level DEBUG
                    if [[ ${WAIT_COUNTER} > 0 ]]; then
                        WAIT_COUNTER=$((WAIT_COUNTER-1))
                    else
                        ${CMD_EXECUTOR} --echo "Could not enable the suspended ParseKit" --level ERROR
                        exit 2
                    fi
                    sleep 1
                    PARSER_INFO=$(parsekit -X GET "${PARSER_URL}")
                    PARSER_STATE=$(echo "${PARSER_INFO}" | ${JQ_CMD} -r ".state")
                    ${CMD_EXECUTOR} --echo "ParseKit state: ${PARSER_STATE}" --level DEBUG
                done

                 ${CMD_EXECUTOR} --echo "ParseKit enabled egain." --level DEBUG
            fi

            cat <<EOF > "${CONTEXT_OBJECT_FILENAME}"
{
 "context": {
   "division": "${ARG_DIVISION}",
   "env": "${ARG_ENV}",
   "system": "${ARG_SYSTEM}",
   "location": "${ARG_LOCATION}",
   "tables": [
     {
       "table-schema": "${ARG_TABLE_SCHEMA}",
       "table-name": "${ARG_TABLE}",
       "ingest-type": "${ARG_INGEST_TYPE}",
       "delta-column": "${ARG_DELTA_COLUMN}",
       "delta-lower-bound" : "${ARG_LOWER_BOUND}",
       "delta-upper-bound" : "${ARG_UPPER_BOUND}",
       "target-hdfs-file-path": "${ARG_FILEPATH}",
       "load-id": "${ARG_LOAD_ID}",
       "extract-dttm": "${ARG_EXTRACT_DTTM}"
     }
   ]
 },
 "ttr": "${PARSEKIT_TIME_TO_RUN}"
}
EOF

          PARSER_RUN_URL="${PARSER_URL}/runs"
          ${CMD_EXECUTOR} --echo "Starting a parser run at ${PARSER_RUN_URL}" --level DEBUG
          PARSER_RUN_RESPONSE=$(parsekit -X POST --data-binary "@${CONTEXT_OBJECT_FILENAME}" "${PARSER_RUN_URL}")
          rm -f "${CONTEXT_OBJECT_FILENAME}"

          ${CMD_EXECUTOR} --echo "Parser run response: ${PARSER_RUN_RESPONSE}" --level DEBUG

          PARSER_RUN_ID=$(echo "${PARSER_RUN_RESPONSE}" | ${JQ_CMD} -r ".id")

          if [[ -z "${PARSER_RUN_ID}" || "${PARSER_RUN_ID}" == 'null' ]]; then
             ${CMD_EXECUTOR} --echo "Could not obtain the parser run id" --level ERROR
             exit 1
          else
             echo 'ParseKitRunID: "'${PARSER_RUN_URL}/${PARSER_RUN_ID}'"'
             ${CMD_EXECUTOR} --echo "parsekit-import-start pipeline step executed successfully"
             exit 0
          fi
        fi
    done < <(echo "${PARSER_LIST}" | ${JQ_CMD} -r 'keys[]')

    ${CMD_EXECUTOR} --echo "No suitable parsekit parser found; exiting" --level ERROR
    exit 1
}

set -e
${CMD_EXECUTOR} --echo "Executing parsekit-import pipeline step"

BASEDIR="$(dirname $0)"

# Set up local environment
[ -f "${BASEDIR}/env.sh" ] && . "${BASEDIR}/env.sh"

#Import libs
for file in $(ls ${LIB_DIR}/*.sh)
do
    source ${file}
done

get_argument_by_name ARG_SUB_COMMAND --cmd required "$@"
get_argument_by_name ARG_DIVISION --sourceSystemDivision required "$@"
get_argument_by_name ARG_ENV --sourceSystemEnv required "$@"
get_argument_by_name ARG_SYSTEM --sourceSystem required "$@"
get_argument_by_name ARG_LOCATION --sourceSystemLocation required "$@"
get_argument_by_name ARG_TABLE_SCHEMA --sourceTableSchema required "$@"
get_argument_by_name ARG_TABLE --sourceTable required "$@"

case "${ARG_SUB_COMMAND}" in
        start)
            startParseKitImport "$@"
            ;;

        progress)
            getParseKitImportProgress "$@"
            ;;

        test)
            ${CMD_EXECUTOR} --echo "Test run of parsekit-import pipeline completed"
            exit 0
            ;;

        *)
            ${CMD_EXECUTOR} --echo "Missing or invalid subcommand: ${ARG_SUB_COMMAND}. Please use -cmd switch to provide one." --level ERROR
            exit 1

esac

