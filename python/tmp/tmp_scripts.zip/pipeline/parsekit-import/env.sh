#!/usr/bin/env bash
# Copyright  2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

#Set maximum import time to one week (i.e. 1000 * 60 * 60 * 24 * 7)
export PARSEKIT_TIME_TO_RUN=${PARSEKIT_TIME_TO_RUN:-604800000}
