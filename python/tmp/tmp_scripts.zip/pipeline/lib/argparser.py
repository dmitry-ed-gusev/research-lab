#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

from argparse import ArgumentParser

from pipeline.lib.logger import MantisLogger


class ArgParser(ArgumentParser):
    """Extend standard arg parser to save error messages to logs"""

    def __init__(self, conf, **kwargs):
        self.conf = conf
        super(ArgParser, self).__init__(**kwargs)

    def error(self, message, logger=None):
        if not logger:
            logger = MantisLogger()
            logger.configure(self.conf)
        logger.error(self.format_usage())
        logger.error('%s: error: %s\n' % (self.prog, message))
        self.exit(2)
