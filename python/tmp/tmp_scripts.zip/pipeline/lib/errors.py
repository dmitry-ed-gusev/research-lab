#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.


class DBTestError(Exception):

    def __init__(self, reason):
        super(DBTestError, self).__init__("DB-test runtime check failed:  %s" % reason)


class ArgumentError(Exception):
    """Indicate failure of additional arguments validation"""

    def __init__(self, arg_name, message):
        super(ArgumentError, self).__init__('argument %s: %s' % (arg_name, message))
