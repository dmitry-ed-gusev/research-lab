#!/usr/bin/env python
# coding=utf-8
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import argparse
import logging
import os
import sys

from pipeline.lib.configuration import Configuration


class MantisLogger(object):

    TRACE=8
    DATEFORMAT='%Y-%m-%d %H-%M-%S'
    LOG_FILE_LOCATION="/var/log/mantis"
    FORMAT = "[%(asctime)-11s] - [%(levelname)s] - [%(mdc_pid)s] - [%(source_system)s] - [%(system_location)s] - [%(system_env)s] - [%(source_table)s] - [%(step)s] - %(message)s"

    def __init__(self):
        logging.addLevelName(self.TRACE, 'TRACE')
        self.logger = logging.getLogger(__name__)
        self.caption = None

    def configure(self, config):
        try:
            caption = {'step': config.get("step_name"),
                       'source_system': config.get("source_system"),
                       'system_location': config.get("source_system_location"),
                       'system_env': config.get("source_system_env"),
                       'source_table': config.get("source_table"),
                       'mdc_pid': config.get("mdc_pid")}
        except KeyError as err:
            print("Log configuration failed, extra entry is absent: %s" % err)
            sys.exit(1)

        formatter = logging.Formatter(self.FORMAT, datefmt=self.DATEFORMAT)
        self.logger.setLevel(self.TRACE)
        try:
            if config.get("logging.log_file_location"):
                self.LOG_FILE_LOCATION = config.get("logging.log_file_location")

            file_handler = logging.FileHandler('%s/%s-%s.log' % (self.LOG_FILE_LOCATION, config.get("source_system"), config.get("source_system_env")))
            file_handler.setLevel(config.get("logging.file_log_level"))

            console_handler = logging.StreamHandler()
            console_handler.setLevel(config.get("logging.console_log_level"))

            file_handler.setFormatter(formatter)
            console_handler.setFormatter(formatter)
        except KeyError as err:
            print("Handler configuration failed: %s" % err)
            sys.exit(1)

        self.logger.addHandler(console_handler)
        self.logger.addHandler(file_handler)

        self.caption = caption

    def debug(self, msg):
        self.logger.debug(msg, extra=self.caption)

    def info(self, msg):
        self.logger.info(msg, extra=self.caption)

    def warn(self, msg):
        self.logger.warning(msg, extra=self.caption)

    def error(self, msg):
        self.logger.error(msg, extra=self.caption)

    def trace(self, msg):
        self.logger.log(self.TRACE, msg, extra=self.caption)


if __name__ == "__main__":
    #Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--level', type=str, default='INFO', required=False)
    args = parser.parse_args()

    config = Configuration()
    config.load(os.environ["CONFIG_LOCATION"])

    logger = MantisLogger()
    logger.configure(config)

    line = sys.stdin.read().rstrip()
    if args.level == "DEBUG":
        logger.debug(line)
    elif args.level == "INFO":
        logger.info(line)
    elif args.level == "WARN":
        logger.warn(line)
    elif args.level == "ERROR":
        logger.error(line)
    elif args.level == "TRACE":
        logger.trace(line)
    else:
        logger.error("LogLevel: %s not found, redirected to WARN" % args.level)
        logger.warn(line)

    sys.exit(0)