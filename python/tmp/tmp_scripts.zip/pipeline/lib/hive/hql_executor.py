#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

from pipeline.lib.hive.hive_client import hive_client


class HQLExecutor:

    def __init__(self, logger, config):
        self.config = config
        self.logger = logger

    def execute(self, type, value, ret_val, vars={}):

        client = hive_client(configuration=self.config, logger=self.logger)
        client.connect()
        result = client.execute(q_type=type, q_value=value, vars=vars, ret_val=ret_val)
        client.close()
        return result
