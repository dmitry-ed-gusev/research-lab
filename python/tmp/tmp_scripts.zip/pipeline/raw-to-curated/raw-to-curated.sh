#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e

${CMD_EXECUTOR} --echo "Raw to Curated step execution"

#Define script name for Raw2Curated step by mode
#Usage: get_script_name_by_mode
function get_script_name_by_mode() {
   ${CMD_EXECUTOR} --echo "Ingest type: ${INGEST_TYPE}" --level DEBUG
   case "${INGEST_TYPE}" in
        "FULL_INITIAL")
            export SCRIPT_NAME="full-initial-ingest.hql"
            return 0
            ;;
        "FULL")
            export SCRIPT_NAME="full-ingest.hql"
            return 0
            ;;
        "INCREMENT")
            export SCRIPT_NAME="incremental-ingest.hql"
            return 0
            ;;
        "DELTA")
            export SCRIPT_NAME="delta-ingest.hql"
            return 0
            ;;
    esac
    ${CMD_EXECUTOR} --echo "Unknown ingest type: ${INGEST_TYPE}" --level ERROR
}

# Execute env script
# Define sources
BASEDIR="$(dirname $0)"

[ -f "${BASEDIR}/env.sh" ] && . "${BASEDIR}/env.sh"
source ${BASEDIR}/db-test.sh

for file in $(ls ${LIB_DIR}/*.sh)
do
    source ${file}
done

get_argument_by_name LOAD_DTTM '--loadDTTM' 'required' "$@"
get_argument_by_name LOAD_ID '--loadID' 'required' "$@"
get_argument_by_name EXTRACT_DTTM '--extractDTTM' 'required' "$@"
get_argument_by_name INGEST_TYPE '--ingestType' 'required' "$@"

get_argument_by_name DISABLE_DB_TEST '--disableDBTest' 'optional' "$@"


resolve_model_path
get_script_name_by_mode

HIVE_SCRIPT="${MODEL_STEP_DIR}/${SCRIPT_NAME}"
${CMD_EXECUTOR} --echo "Verifying existence: ${HIVE_SCRIPT}" --level DEBUG
verify_file_exists ${HIVE_SCRIPT}

PARTITION_VIEW_SCRIPT="${MODEL_STEP_DIR}/${PARTITION_VIEW_SCRIPT_NAME}"
${CMD_EXECUTOR} --echo "Verifying existence: ${PARTITION_VIEW_SCRIPT}" --level DEBUG
verify_file_exists ${PARTITION_VIEW_SCRIPT}

if ! is_flag_argument_set ${DISABLE_DB_TEST}; then

  export STEP_DB_TEST_DIR="${MODEL_STEP_DIR}/${DB_TEST_DIR_NAME}"
  LOAD_DTTM_LAST_PARTITION_VIEW_FILE="${STEP_DB_TEST_DIR}/${LOAD_DTTM_LAST_PARTITION_VIEW_FILE_NAME}"
  ${CMD_EXECUTOR} --echo "Verifying existence: ${LOAD_DTTM_LAST_PARTITION_VIEW_FILE}" --level DEBUG
  verify_file_exists ${LOAD_DTTM_LAST_PARTITION_VIEW_FILE}

  ROW_COUNT_LAST_PARTITION_VIEW_FILE="${STEP_DB_TEST_DIR}/${ROW_COUNT_LAST_PARTITION_VIEW_FILE_NAME}"
  ${CMD_EXECUTOR} --echo "Verifying existence: ${ROW_COUNT_LAST_PARTITION_VIEW_FILE}" --level DEBUG
  verify_file_exists ${ROW_COUNT_LAST_PARTITION_VIEW_FILE}

  ROW_COUNT_RAW_PARTITION_FILE="${STEP_DB_TEST_DIR}/${ROW_COUNT_RAW_PARTITION_FILE_NAME}"
  ${CMD_EXECUTOR} --echo "Verifying existence: ${ROW_COUNT_RAW_PARTITION_FILE}" --level DEBUG
  verify_file_exists ${ROW_COUNT_RAW_PARTITION_FILE}

  EMPTY_SCD1_COLUMNS_CURATED_FILE="${STEP_DB_TEST_DIR}/${EMPTY_SCD1_COLUMNS_CURATED_FILE_NAME}"
  ${CMD_EXECUTOR} --echo "Verifying existence ${EMPTY_SCD1_COLUMNS_CURATED_FILE}" --level DEBUG
  verify_file_exists ${EMPTY_SCD1_COLUMNS_CURATED_FILE}

  ${CMD_EXECUTOR} --echo "Running setup for DB-Test"
  setup
fi

${CMD_EXECUTOR} --echo "Executing script: ${HIVE_SCRIPT}" --level DEBUG


execute_hive --hql ${HIVE_SCRIPT} --call

${CMD_EXECUTOR} --echo "Raw to curated was performed"

execute_hive --hql ${PARTITION_VIEW_SCRIPT} --call

${CMD_EXECUTOR} --echo "Last partition view was updated"

if ! is_flag_argument_set ${DISABLE_DB_TEST}; then
  ${CMD_EXECUTOR} --echo "Running DB-Test"
  db_test
  ${CMD_EXECUTOR} --echo "DB-Test passed successfully"
fi