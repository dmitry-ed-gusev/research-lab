#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

export PARTITION_VIEW_SCRIPT_NAME=${PARTITION_VIEW_SCRIPT_NAME:-update-last-partition-view.hql}

export DB_TEST_DIR_NAME=${DB_TEST_DIR_NAME:-db-test}

export LOAD_DTTM_LAST_PARTITION_VIEW_FILE_NAME=${LOAD_DTTM_LAST_PARTITION_VIEW_FILE_NAME:-load-dttm-last-partition-view.hql}
export ROW_COUNT_LAST_PARTITION_VIEW_FILE_NAME=${ROW_COUNT_LAST_PARTITION_VIEW_FILE_NAME:-row-count-last-partition-view.hql}
export ROW_COUNT_RAW_PARTITION_FILE_NAME=${ROW_COUNT_RAW_PARTITION_FILE_NAME:-row-count-raw-partition.hql}
export EMPTY_SCD1_COLUMNS_CURATED_FILE_NAME=${EMPTY_SCD1_COLUMNS_CURATED_FILE_NAME:-empty-scd1-columns-curated.hql}

export DISABLE_DB_TEST=${DISABLE_DB_TEST:-true}