#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.
#
# Test database after raw-to-curated step.
#
#   1. The difference between the last two partition sizes should not exceed the batch size.
#   2. Table sample should not contain empty SCD1 columns
#   3. The operational view pointing to the last partition should be updated

set -e

readonly OPT_HELP="--help"

for file in $(ls ${LIB_DIR}/*.sh)
do
    source ${file}
done

# The environment variables the script depends on:
# export LOAD_DTTM_LAST_PARTITION_VIEW_FILE
# export ROW_COUNT_LAST_PARTITION_VIEW_FILE
# export ROW_COUNT_RAW_PARTITION_FILE
# export EMPTY_SCD1_COLUMNS_CURATED_FILE
# export LOAD_DTTM

# get_row_count --- get the number of rows:
# Arguments:
# 1 - the name of the variable to assign the result to
# 2 - the SELECT script to execute
get_row_count() {
    local count=$(execute_hive --hql "$2" --execute)
    # Empty count or status code returned by execute_hive is not 0.
    if [ -z ${count} ]; then
        ${CMD_EXECUTOR} --echo "Could not determine row count in: $2" --level ERROR
    fi
    local result=$1
    eval ${result}='${count}'
}

# check_row_counts --- ensure the difference between the last two partitions does
# not exceed the batch size:
check_row_counts() {
    # TODO: Special case for increment and full?
    ${CMD_EXECUTOR} --echo "Checking row counts"
    get_row_count "last_partition_size" ${ROW_COUNT_LAST_PARTITION_VIEW_FILE}
    get_row_count "batch_size" ${ROW_COUNT_RAW_PARTITION_FILE}

    ${CMD_EXECUTOR} --echo "Rows in last partition:       ${last_partition_size}" --level DEBUG
    ${CMD_EXECUTOR} --echo "Rows in previous partition:   ${PREVIOUS_PARTITION_SIZE}" --level DEBUG
    ${CMD_EXECUTOR} --echo "Batch size:                   ${batch_size}" --level DEBUG

    # For some reason, bash arithmetics does not always work here.
    local diff=$(awk "BEGIN {print ${last_partition_size}-${PREVIOUS_PARTITION_SIZE}; exit}")
    if [ ${diff} -gt ${batch_size} ]; then
        ${CMD_EXECUTOR} --echo "The difference between partition sizes exceeds the batch size" --level ERROR
    fi
    ${CMD_EXECUTOR} --echo "Check passed"
}

# check_scd1_columns --- check SCD1 columns exist in the Curated table:
check_scd1_columns() {
    ${CMD_EXECUTOR} --echo "Checking SCD1 columns"
    get_row_count "empty_scd1_columns_count" ${EMPTY_SCD1_COLUMNS_CURATED_FILE}
    if [[ ${empty_scd1_columns_count} -ne 0 ]]; then
        ${CMD_EXECUTOR} --echo "Empty SCD1 columns found in Curated table" --level ERROR
    fi
    ${CMD_EXECUTOR} --echo "Check passed"
}

# check_operational_latest_view --- check operational latest view is up-to-date:
check_operational_latest_view() {
    ${CMD_EXECUTOR} --echo "Checking operational last partition"
    local actual_load_dttm=$(execute_hive --hql "${LOAD_DTTM_LAST_PARTITION_VIEW_FILE}" --execute)

    # This case is possible when previous partition from curated layer has no data
    if [[ -z ${actual_load_dttm} ]]; then
        ${CMD_EXECUTOR} --echo "Last partition view doesn't contain partition value. Check if the view is empty" --level DEBUG
        get_row_count "last_partition_size" ${ROW_COUNT_LAST_PARTITION_VIEW_FILE}
        if [[ ${last_partition_size} -ne 0 ]]; then
            ${CMD_EXECUTOR} --echo "Last partition view is not empty but does not contain partition value" --level ERROR
        fi
    else
        ${CMD_EXECUTOR} --echo "Expected partition value:     \"${LOAD_DTTM}\"" --level DEBUG
        ${CMD_EXECUTOR} --echo "Actual partition value:       \"${actual_load_dttm}\"" --level DEBUG

        # If actual PARTITION_COLUMN was extracted and it does not equal the value parameter, fail.
        if [[ ${actual_load_dttm} != ${LOAD_DTTM} ]]; then
            ${CMD_EXECUTOR} --echo "The operational view pointing to the last partition is not up-to-date" --level ERROR
        fi
    fi

    ${CMD_EXECUTOR} --echo "Check passed"
}

# export_previous_partition_count --- export PREVIOUS_PARTITION_SIZE variable
export_previous_partition_size() {
    ${CMD_EXECUTOR} --echo "Exporting previous partition count" --level DEBUG
    get_row_count "previous_partition_size" ${ROW_COUNT_LAST_PARTITION_VIEW_FILE}
    export PREVIOUS_PARTITION_SIZE=${previous_partition_size}
    ${CMD_EXECUTOR} --echo "Done" --level DEBUG
}

# setup -- perform db-test setup:
setup() {
    export_previous_partition_size
}

# db_test --- perform db-test checks:
db_test() {
    check_row_counts
    check_scd1_columns
    check_operational_latest_view
}
