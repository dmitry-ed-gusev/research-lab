#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e
${CMD_EXECUTOR} --echo "Executing curated-to-latest pipeline step"

BASEDIR="$(dirname $0)"

#Set up local environment
[ -f "${BASEDIR}/env.sh" ] && . "${BASEDIR}/env.sh"

#Import libs
for file in $(ls $LIB_DIR/*.sh)
do
    source ${file}
done

#Read step-specific arguments (general parameters are parsed in mdc.sh)
get_argument_by_name LOAD_DTTM --loadDTTM required "$@"
get_argument_by_name DISABLE_DB_TEST --disableDBTest optional "$@"

HIVE_SCRIPT="${MODEL_STEP_DIR}/${HQL_SCRIPT_NAME}"
verify_file_exists "${HIVE_SCRIPT}"

#Execute main script
execute_hive --hql "${HIVE_SCRIPT}" --call

#Execute db test if enabled
if ! is_flag_argument_set ${DISABLE_DB_TEST}; then
    source "${BASEDIR}/db-test.sh"
fi

${CMD_EXECUTOR} --echo "Curated-to-latest pipeline step executed successfully"
