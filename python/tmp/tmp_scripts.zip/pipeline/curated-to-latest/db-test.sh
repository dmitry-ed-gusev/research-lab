#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e

# Environment variables the script depends on:
# export MODEL_COMMON
# export LOAD_DTTM_COL
# export LOAD_DTTM


# main --- script entry point:
main() {
    ${CMD_EXECUTOR} --echo "Starting db-test step"
    local FULL_COUNT_CURATED_SCRIPT="${MODEL_STEP_DIR}/${DB_TEST_DIR_NAME}/${COUNT_CURATED_NAME}"
    verify_file_exists "${FULL_COUNT_CURATED_SCRIPT}"

    COUNT_CURATED=$(execute_hive --hql "${FULL_COUNT_CURATED_SCRIPT}" --execute)
    ${CMD_EXECUTOR} --echo "Records from curated table: ${COUNT_CURATED}" --level DEBUG

    local FULL_COUNT_LATEST_SCRIPT="${MODEL_STEP_DIR}/${DB_TEST_DIR_NAME}/${COUNT_LATEST_NAME}"
    verify_file_exists "${FULL_COUNT_LATEST_SCRIPT}"

    COUNT_LATEST=$(execute_hive --hql "${FULL_COUNT_LATEST_SCRIPT}" --execute)
    ${CMD_EXECUTOR} --echo "Records from latest table: ${COUNT_LATEST}" --level DEBUG

    if [ "${COUNT_CURATED}" -ne "${COUNT_LATEST}" ]; then
        ${CMD_EXECUTOR} --echo "Value are non-equal. Db-test failed" --level ERROR
        return 1
    fi
    ${CMD_EXECUTOR} --echo "Db-test passed successfully"
}
main "$@"
