#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

export HQL_SCRIPT_NAME=${HQL_SCRIPT_NAME:-consumer-latest-layer.hql}

export DB_TEST_DIR_NAME=${DB_TEST_DIR_NAME:-db-test}
export COUNT_CURATED_NAME=${COUNT_CURATED_NAME:-row-count-curated.hql}
export COUNT_LATEST_NAME=${COUNT_LATEST_NAME:-row-count-latest.hql}

export DISABLE_DB_TEST=${DISABLE_DB_TEST:-true}