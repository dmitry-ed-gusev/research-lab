#!/usr/bin/env python
# coding=utf-8
# Copyright 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os
import argparse
import sys
import time
import datetime

python_lib_path = sys.path.append(os.path.join(os.path.dirname(sys.argv[0]), '../../lib/python'))
sys.path.append(python_lib_path)

from configuration import Configuration
from logger import MantisLogger
from hdfs_client import HdfsClient

MILLISECONDS_IN_SECOND = 1000

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--layerDirectory', type=str, required=True)
    parser.add_argument('--retentionPeriod', type=int, required=True)

    args, unknown = parser.parse_known_args()
    return args

def datetime_to_unix_timestamp(datetime):
    return time.mktime(datetime.timetuple()) * MILLISECONDS_IN_SECOND

if __name__ == "__main__":
    # TODO: Remove after full refactoring
    CONFIG_LOCATION=os.environ['CONFIG_LOCATION']

    configuration = Configuration()
    configuration.load(CONFIG_LOCATION)
    logger = MantisLogger()
    logger.configure(configuration)

    logger.info('Cleanup-obsolete-csv step is starting')

    logger.debug('Parsing input arguments')
    args = parse_args()

    try:
        obsolete_files_max_date = datetime.datetime.now() - datetime.timedelta(days=args.retentionPeriod)
        obsolete_files_max_time = datetime_to_unix_timestamp(obsolete_files_max_date)

        obsolete_files = []
        client = HdfsClient(config=configuration, logger=logger)

        file_statuses = client.list(hdfs_path=args.layerDirectory, status=True)
        directory = client.resolve(args.layerDirectory)
        for file, status in file_statuses:
            if status["modificationTime"] <= obsolete_files_max_time:
                obsolete_files.append(directory + "/" + file)

        if len(obsolete_files) > 0:
            logger.debug("Selected for removal the following obsolete files: " + str(obsolete_files))
            for file in obsolete_files:
                if not client.delete(file):
                    logger.error("Failed to delete obsolete file " + file)
                    sys.exit(1)
        else:
            logger.warn("No obsolete files were selected for removal")

        logger.info("Cleanup-obsolete-csv step has finished")
    except Exception as e:
        logger.error("%s: %s" % (e.__class__.__name__, e.message))
        sys.exit(1)
