#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e
${CMD_EXECUTOR} --echo "Executing landing-to-raw pipeline step"

BASEDIR="$(dirname $0)"

# Import libs
for file in $(ls ${LIB_DIR}/*.sh); do
    source ${file}
done

# Set up local environment
[ -f "${BASEDIR}/env.sh" ] && . "${BASEDIR}/env.sh"

get_argument_by_name CSV_FILE --filePath required "$@"
get_argument_by_name LOAD_DTTM --loadDTTM required "$@"
get_argument_by_name RAW_DB --rawDB required "$@"
get_argument_by_name RAW_TABLE --rawTable required "$@"

get_argument_by_name DISABLE_DB_TEST --disableDBTest optional "$@"

if is_flag_argument_set ${DISABLE_DB_TEST}; then
    disable_db_test=--disable-db-test
fi

${CMD_EXECUTOR} --call ${CSV2HIVE_TOOL_SCRIPT} \
    --csv="${CSV_FILE}" \
    --database="${RAW_DB}" \
    --table="${RAW_TABLE}" \
    --partition-column="${LOAD_DTTM_COL}" \
    --partition-value="${LOAD_DTTM}" \
    --mode="${CSV2HIVE_MODE}" \
    ${disable_db_test} --level TRACE

${CMD_EXECUTOR} --echo "Landing-to-raw pipeline step executed successfully"
