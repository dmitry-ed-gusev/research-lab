#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

export CSV2HIVE_MODE=${CSV2HIVE_MODE:-safe}

export DISABLE_DB_TEST=${DISABLE_DB_TEST:-true}
