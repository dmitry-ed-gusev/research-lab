#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e

# Setting global environment variables
BASEDIR="$(dirname $0)"
[ -f "${BASEDIR}/env.sh" ] && . "${BASEDIR}/env.sh"

for file in $(ls ${LIB_DIR}/*.sh)
do
    source ${file}
done

# Enabling python virtualenv for further processing
USERNAME_PROCESSED=$(whoami)
if [ -d "/home/${USERNAME_PROCESSED}/mantis-virtualenv" ]; then
    . /home/${USERNAME_PROCESSED}/mantis-virtualenv/bin/activate
fi

function export_variables() {
    ${CMD_EXECUTOR} --echo "Export cmd line parameters into environment" --level DEBUG
    while [[ $# -gt 0 ]]; do
    key=${1}
    case $key in
        --*=*)
        export "${key/--}"
        ${CMD_EXECUTOR} --echo "Exported ${key/--}" --level TRACE
        ;;
        --*)
        if [ -n "${2}" ]; then
            export "${key/--}=$2"
            ${CMD_EXECUTOR} --echo "Exported ${key/--}=$2" --level TRACE
            shift
        fi
        ;;
    esac
    shift
    done
}

function renew_kerberos_ticket() {
    if [ -z ${PROCESS_PHASE+x} ]
    then
        ${CMD_EXECUTOR} --echo "Initializing security" --level DEBUG
        USERNAME_PROCESSED=$(whoami)
        ${CMD_EXECUTOR} --call kinit -kt /home/${USERNAME_PROCESSED}/${USERNAME_PROCESSED}.headless.keytab ${USERNAME_PROCESSED}@MERCK.COM --level DEBUG
    else
        if [ "${PROCESS_PHASE}" != "build" ]
        then
            ${CMD_EXECUTOR} --echo "Initializing security" --level DEBUG
            USERNAME_PROCESSED=$(whoami)
            ${CMD_EXECUTOR} --call kinit -kt /home/${USERNAME_PROCESSED}/${USERNAME_PROCESSED}.headless.keytab ${USERNAME_PROCESSED}@MERCK.COM --level DEBUG
        fi
    fi
}


# Current process ID
export MDC_PID=$$

# Setup stub values for propper logging
export SOURCE_SYSTEM="ERROR"
export SOURCE_SYSTEM_ENV="ERROR"
export SOURCE_SYSTEM_LOCATION="ERROR"
export SOURCE_TABLE="ERROR"
export STEP_NAME="ERROR"

get_argument_by_name SOURCE_SYSTEM '--sourceSystem' 'required' "$@"
get_argument_by_name SOURCE_SYSTEM_ENV '--sourceSystemEnv' 'required' "$@"
get_argument_by_name SOURCE_SYSTEM_LOCATION '--sourceSystemLocation' 'required' "$@"
get_argument_by_name SOURCE_TABLE '--sourceTable' 'required' "$@"
get_argument_by_name STEP_NAME '--stepName' 'required' "$@"

export_variables "$@"
renew_kerberos_ticket

if  [ -f ${ABSTRACT_CREDENTIALS_FILE} ] ; then
    ${CMD_EXECUTOR} --echo "Deployment-specific abstract credentials found. Importing..." --level DEBUG
    source ${ABSTRACT_CREDENTIALS_FILE}
    ${CMD_EXECUTOR} --echo "Abstract credentials imported" --level DEBUG
elif [ "${STEP_NAME}" = "csv-to-abstract" ] || [ "${STEP_NAME}" = "verify-csv-to-abstract" ]; then
    ${CMD_EXECUTOR} --echo "Abstract credentials not found " --level ERROR
    exit 1
fi


#Resolve model paths and set up model environments
resolve_model_path

echo "Checking if pipeline step passed is valid one."
${CMD_EXECUTOR} --echo "Checking if pipeline step passed is valid one." --level DEBUG
STEPS='csv-to-abstract sqoop-to-raw curated-to-latest hive-to-delta-csv landing-to-raw raw-to-curated hive-to-teradata-csv parsekit-import cleanup-obsolete-data cleanup-obsolete-files'

VERIFY_STEPS='verify-csv-to-abstract verify-curated-to-latest verify-hive-to-delta-csv verify-hive-to-teradata-csv verify-landing-to-raw verify-raw-to-curated verify-cleanup-obsolete-partitions verify-cleanup-obsolete-records'


for STEP in $(echo ${STEPS} ${VERIFY_STEPS}); do
    if [ "${STEP_NAME}" = "${STEP}" ]; then
        ${CMD_EXECUTOR} --echo "MDC is running ${STEP_NAME} pipeline step" --level DEBUG
        "${CDIR}/${STEP_NAME}/${STEP_NAME}.sh" "$@"
        exit $?
    fi
done

${CMD_EXECUTOR} --echo "Unknown Mantis pipeline step ${STEP_NAME};" --level ERROR
exit 1
