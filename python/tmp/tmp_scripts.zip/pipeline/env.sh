#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

## Stub parameters for integrity tests

#Get system hadoop env
HADOOP_ENV_FILE=${HADOOP_ENV_FILE:-'/etc/hadoop/conf/hadoop-env.sh'}
if [ -f "${HADOOP_ENV_FILE}" ];
then
    source ${HADOOP_ENV_FILE}
fi

## Parameters that are common for all environments (dev/test/prod)
CDIR="$(dirname $0)"

#General directory properties
export ROOT_DIR=${CDIR}/..
export LIB_DIR=${ROOT_DIR}/lib

# Dir names of corresponding artifacts after deploy
export PIPELINE_ARTIFACT_DIR=${PIPELINE_ARTIFACT_DIR:-mantis-pipeline/rel}
export CSV2HIVE_TOOL_ARTIFACT_DIR=${CSV2HIVE_TOOL_ARTIFACT_DIR:-csv2hive-tool/rel}
export CSV2ABSTRACT_ARTIFACT_DIR=${CSV2ABSTRACT_ARTIFACT_DIR:-csv2abstract/rel}
export VERIFY_PIPELINE_ARTIFACT_DIR=${VERIFY_PIPELINE_ARTIFACT_DIR:-verify-pipeline/rel}
export SQOOP_ARTIFACT_DIR=${SQOOP_ARTIFACT_DIR:-sqoop-msd-bin/rel}
export SQOOP_VERSION=${SQOOP_VERSION:-sqoop-msd-1.4.6.5.bin__hadoop-2.1.0-beta}

# Base directory for all files on HDFS
export AUX_HDFS_DIR_BASE=${AUX_HDFS_DIR_BASE:-/data/mmd}

# Partition column
export LOAD_DTTM_COL=${LOAD_DTTM_COL:-load_dttm}

# Export path which comes from MDC should have this extension
export EXPORT_FILE_EXTENSION=${EXPORT_FILE_EXTENSION:-csv}
export EXPORT_FILE_SCHEMA_EXTENSION=${EXPORT_FILE_SCHEMA_EXTENSION:-json}
export HQL_FILE_EXTENSION=${HQL_FILE_EXTENSION:-hql}

# Suffix for Hive options for particular step/system/table/script set through mdc
export HIVE_OPTS_SUFFIX=${HIVE_OPTS_SUFFIX:-_hive_opts}

# Enigma River timeout settings
export RIVER_TIMEOUT_SECONDS="${RIVER_TIMEOUT_SECONDS:-5}"
export RIVER_TIMEOUT_ATTEMPTS="${RIVER_TIMEOUT_ATTEMPTS:-10}"

