#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e
${CMD_EXECUTOR} --echo "Executing verify-csv-to-abstract pipeline step"

for file in $(ls ${LIB_DIR}/*.sh); do
    source ${file}
done

 

get_argument_by_name VERIFY_CSV --verifyCSV required "$@"
get_argument_by_name ABSTRACT_DATASET_NAME --abstractDatasetName required "$@"

resolve_verify_csv_export_path OUTPUT_DIR OUTPUT_CSV


${CMD_EXECUTOR} --call ${VERIFY_PIPELINE_SCRIPT} \
    --pipeline-step="${STEP_NAME}" \
    --verify-csv="${VERIFY_CSV}" \
    --output-csv="${OUTPUT_CSV}" \
    --dataset="${ABSTRACT_DATASET_NAME}" \
    --abstract-env="${ABSTRACT_ENV}" \
    --abstract-key="${ABSTRACT_API_KEY}" --level TRACE

${CMD_EXECUTOR} --echo "Verify-csv-to-abstract pipeline step executed successfully"