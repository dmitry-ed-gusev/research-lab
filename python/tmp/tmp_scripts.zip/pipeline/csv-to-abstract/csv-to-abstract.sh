#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e
${CMD_EXECUTOR} --echo "Executing csv-to-abstract pipeline step"

BASEDIR="$(dirname $0)"

# Import libs
for file in $(ls ${LIB_DIR}/*.sh); do
    source ${file}
done

# Set up local environment
[ -f "${BASEDIR}/env.sh" ] && . "${BASEDIR}/env.sh"

get_argument_by_name ABSTRACT_DATASET_NAME --abstractDatasetName required "$@"
get_argument_by_name CONSUMER_CSV --consumerCSV required "$@"

get_argument_by_name DISABLE_DB_TEST --disableDBTest optional "$@"
get_argument_by_name LOG_LEVEL --abstractLogLevel optional "$@"

export CONSUMER_DIR=$(dirname ${CONSUMER_CSV})
get_file_name CONSUMER_FILENAME ${CONSUMER_CSV} ${EXPORT_FILE_EXTENSION}
export CONSUMER_SCHEMA_FILE=${CONSUMER_DIR}/${CONSUMER_FILENAME}.${EXPORT_FILE_SCHEMA_EXTENSION}

if is_flag_argument_set ${DISABLE_DB_TEST}; then
    disable_db_test=--disable-db-test
fi

${CMD_EXECUTOR} --echo "Checking if schema was changed" --level DEBUG

REINDEX_COLLECTION=true

resolve_export_schema_file PREVIOUS_SCHEMA_FILE ${ABSTRACT_DATASET_NAME}

${CMD_EXECUTOR} --echo "Previous schema: ${PREVIOUS_SCHEMA_FILE}" --level DEBUG
${CMD_EXECUTOR} --echo "Consumer schema: ${CONSUMER_SCHEMA_FILE}" --level DEBUG

schema_file_exists=$(${CMD_EXECUTOR} --hdfs test_exist ${PREVIOUS_SCHEMA_FILE}; echo $?)
if [ ${schema_file_exists} -eq 0 ]; then
  ${CMD_EXECUTOR} --echo "Previous schema file exists. Compare it with current schema" --level DEBUG
  files_the_same=$(cmp -s <(${CMD_EXECUTOR} --hdfs cat ${PREVIOUS_SCHEMA_FILE}) <(${CMD_EXECUTOR} --hdfs cat ${CONSUMER_SCHEMA_FILE}); echo $?)
  if [ ${files_the_same} -eq 0 ]; then
      ${CMD_EXECUTOR} --echo "Schema wasn't changed" --level DEBUG
      REINDEX_COLLECTION=false
  else
      ${CMD_EXECUTOR} --echo "Schema was changed. Reindex collection" --level DEBUG
  fi
else
    ${CMD_EXECUTOR} --echo "Previous schema file does not exist. Reindex collection" --level DEBUG
fi

${CMD_EXECUTOR} --echo "Executing csv2abstract tool"

if is_flag_argument_set ${REINDEX_COLLECTION}; then
    reindex_collection=--reindex
fi

${CMD_EXECUTOR} --call ${CSV2ABSTRACT_SCRIPT} \
  --dataset=${ABSTRACT_DATASET_NAME} \
  --csv=${CONSUMER_CSV} \
  --schema=${CONSUMER_SCHEMA_FILE} \
  ${reindex_collection} \
  ${disable_db_test} \
  --log-level ${LOG_LEVEL} \
  --level TRACE

${CMD_EXECUTOR} --echo "Csv2abstract tool was executed"


if is_flag_argument_set ${REINDEX_COLLECTION}; then
    ${CMD_EXECUTOR} --echo "Updating schema file ${PREVIOUS_SCHEMA_FILE}" --level DEBUG
    export SCHEMA_DIR=$(${CMD_EXECUTOR} --execute --level TRACE dirname ${PREVIOUS_SCHEMA_FILE})
    ${CMD_EXECUTOR} --hdfs makedirs ${SCHEMA_DIR} 
    ${CMD_EXECUTOR} --hdfs copy_file ${CONSUMER_SCHEMA_FILE} ${PREVIOUS_SCHEMA_FILE} TRUE
    ${CMD_EXECUTOR} --echo "Schema file was updated" --level DEBUG
fi


${CMD_EXECUTOR} --echo "Csv-to-abstract pipeline step executed successfully"
