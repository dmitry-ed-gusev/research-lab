#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -E
#Ensure proper exit if error occurred in command substitution
function reexit() {
    exit $?
}
trap reexit ERR EXIT

${CMD_EXECUTOR} --echo "Hive to Teradata Csv step execution"

${CMD_EXECUTOR} --echo "Local env import" --level TRACE
BASEDIR="$(dirname $0)"
[ -f "${BASEDIR}/env.sh" ] && . "${BASEDIR}/env.sh"

${CMD_EXECUTOR} --echo "Library import" --level TRACE
for file in $(ls ${LIB_DIR}/*.sh)
do
    source ${file}
done

${CMD_EXECUTOR} --echo "Reading arguments" --level DEBUG
#Read arguments
get_argument_by_name LOAD_DTTM --loadDTTM required "$@"
get_argument_by_name EXPORT_TYPE --exportType required "$@"
get_argument_by_name EXPORT_CSV_FILE --exportCSV optional "$@"

export EXPORT_FOLDER="${EXPORT_FOLDER_BASE}/${LOAD_DTTM}"

if [[ -n "${EXPORT_CSV_FILE}" ]]; then
    export TARGET_FOLDER=$(dirname "${EXPORT_CSV_FILE}")
    get_file_name TARGET_FILE "${EXPORT_CSV_FILE}" "${EXPORT_FILE_EXTENSION}"
else
    get_argument_by_name LOAD_ID --loadID required "$@"
    get_argument_by_name EXTRACT_DTTM --extractDTTM required "$@"
    export TARGET_FILE="${TARGET_FILE_BASE}-${LOAD_ID}-${EXTRACT_DTTM}"
    export EXPORT_CSV_FILE="${TARGET_FOLDER}/${TARGET_FILE}.csv"
fi


if [ "${EXPORT_TYPE}" == "FULL" ]; then
    export EXPORT_SCRIPT_NAME=export-full.hql
    export COUNT_SCRIPT_NAME=total-count-full.hql
elif [ "${EXPORT_TYPE}" == "DELTA" ]; then
    get_argument_by_name EXPORT_FROM --exportFrom required "$@"
    get_argument_by_name EXPORT_TO --exportTo required "$@"
    export EXPORT_SCRIPT_NAME=export-delta.hql
    export COUNT_SCRIPT_NAME=total-count-delta.hql
    export HIVE_EXECUTION_PARAMS=("--hivevar" "EXPORT_FROM='${EXPORT_FROM}'" "--hivevar" "EXPORT_TO='${EXPORT_TO}'")
else
    ${CMD_EXECUTOR} --echo "Unknown export type: ${EXPORT_TYPE}" --level ERROR
    exit 1
fi

get_argument_by_name DISABLE_DB_TEST --disableDBTest optional "$@"
get_argument_by_name FORCE_EXPORT --forceExport optional "$@"


delete_if_exist "${EXPORT_CSV_FILE}" ${FORCE_EXPORT}

#Exporting to csv-file
export_hive_to_csv

#Execute DB-test
if ! is_flag_argument_set ${DISABLE_DB_TEST}; then
  ${CMD_EXECUTOR} --echo "Running DB-Test" --level DEBUG
  hive_export_db_test
fi

${CMD_EXECUTOR} --echo "Hive to Teradata Csv step executed successfully"