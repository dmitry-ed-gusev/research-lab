#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

export DB_TEST_DIR_NAME=${DB_TEST_DIR_NAME:-db-test}

export DISABLE_DB_TEST=${DISABLE_DB_TEST:-true}
export FORCE_EXPORT=${FORCE_EXPORT:-false}

export EXPORT_FOLDER_BASE="${HDFS_TMP_DIR}/consumer_teradata/${SOURCE_TABLE}"
export TARGET_FOLDER="${SOURCE_SYSTEM_HDFS_BASE}/consumer_teradata/${SOURCE_TABLE}"
export TARGET_FILE_BASE="${SOURCE_SYSTEM_ENV}-${SOURCE_SYSTEM}-${SOURCE_SYSTEM_LOCATION}-${SOURCE_TABLE}"
