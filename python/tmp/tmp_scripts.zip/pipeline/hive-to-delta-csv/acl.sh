#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -E

# Sets ACL for directory recursively and for its subdirectories
function set_acl() {
    local file_path=$1
    local directory_path=$(dirname "${file_path}")
    ${CMD_EXECUTOR} --echo "Start processing ACLs for file ${file_path}"

    local owner_user_acl=user::${EXPORTED_FILE_USER_PERMISSIONS}
    local owner_group_acl=group::${EXPORTED_FILE_GROUP_PERMISSIONS}
    local other_acl=other::${EXPORTED_FILE_OTHER_PERMISSIONS}
    local extended_user_acl=user:${ABSTRACT_USER}:${EXPORTED_FILE_ABSTRACT_PERMISSIONS}

    local general_acl=${owner_user_acl},${owner_group_acl},${other_acl}

    ${CMD_EXECUTOR} --echo "Adding permissions ${general_acl} for directory ${directory_path} and its parent directories" --level DEBUG
    local root_directory="/"
    parent_directory=${directory_path}
    # Add permissions for all parent directories except of top level directory since its owned by super user
    while [[ $(dirname ${parent_directory}) != ${root_directory} ]]; do
        ${CMD_EXECUTOR} --hdfs set_acl ${parent_directory} ${general_acl} FALSE
        parent_directory=$(dirname ${parent_directory})
    done

    ${CMD_EXECUTOR} --echo "Setting permissions ${extended_user_acl} for file ${file_path}" --level DEBUG

    ${CMD_EXECUTOR} --hdfs set_acl ${file_path} ${general_acl},${extended_user_acl} FALSE

    ${CMD_EXECUTOR} --echo "ACLs processing for file ${file_path} was finished"
}
