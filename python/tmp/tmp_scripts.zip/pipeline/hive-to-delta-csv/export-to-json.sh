#!/usr/bin/env bash
# Copyright Â© 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -E

function get-table-meta {
    DEFINITION_SCRIPT="${MODEL_STEP_DIR}/${DEFINITION_SCRIPT_NAME}"
    verify_file_exists "${DEFINITION_SCRIPT}"
    echo $(execute_hive --hql "${DEFINITION_SCRIPT}" --execute | awk -F',' '{print $1","$2}')
}

function export-to-json {
    ${CMD_EXECUTOR} --echo "Export schema to json is starting"
    HIVE_COLUMNS=($(get-table-meta))

    TABLE_DEF='['
    for COLUMN in "${HIVE_COLUMNS[@]}"; do
        COLUMN_NAME=${COLUMN%,*}
        COLUMN_TYPE=${COLUMN:${#COLUMN_NAME}+1}
        COLUMN_TYPE=${COLUMN_TYPE%(*}
        case "${COLUMN_TYPE}" in
            "tinyint" | "bigint" | "smallint" | "int")
            ABSTRACT_TYPE="integer"
            ;;
            "decimal" | "float" | "double")
            ABSTRACT_TYPE="decimal"
            ;;
            "date")
            ABSTRACT_TYPE="date"
            ;;
            "timestamp")
            ABSTRACT_TYPE="datetime"
            ;;
            "boolean")
            ABSTRACT_TYPE="boolean"
            ;;
            "string" | "char" | "varchar")
            ABSTRACT_TYPE="string"
            ;;
            *)
            ${CMD_EXECUTOR} --echo "Unknown column type ${COLUMN_TYPE} for column ${COLUMN}" --level ERROR
            return 2
        esac

        TABLE_DEF+='{ "name" : "'"${COLUMN_NAME}"'", "type": "'"${ABSTRACT_TYPE}"'" },'
    done
    #strip the last comma
    TABLE_DEF="${TABLE_DEF::-1}]"

    #store the table structure into JSON file
    ${CMD_EXECUTOR} --execute echo "${TABLE_DEF}" | ${CMD_EXECUTOR} --hdfs put "${TARGET_FOLDER}/${TARGET_FILE}.json"
    ${CMD_EXECUTOR} --echo "Exported table schema definition :\n${TABLE_DEF}\nsaved in ${TARGET_FOLDER}/${TARGET_FILE}.json" --level DEBUG
    ${CMD_EXECUTOR} --echo "Export schema to json finished"
}
