#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -E
#Ensure proper exit if error occurred in command substitution
function reexit() {
    exit $?
}
trap reexit ERR EXIT

BASEDIR="$(dirname $0)"
#Call local env setup
[ -f "${BASEDIR}/env.sh" ] && . "${BASEDIR}/env.sh"

#Import libs
for file in $(ls ${LIB_DIR}/*.sh)
do
    source ${file}
done

#Import step internal functions
. "$BASEDIR/export-to-json.sh"
. "$BASEDIR/acl.sh"

${CMD_EXECUTOR} --echo "Hive to delta step is starting"

#Read arguments
get_argument_by_name LOAD_DTTM --loadDTTM required "$@"
get_argument_by_name EXPORT_CSV_FILE --exportCSV optional "$@"

get_argument_by_name DISABLE_DB_TEST --disableDBTest optional "$@"
get_argument_by_name FORCE_EXPORT --forceExport optional "$@"

export EXPORT_FOLDER="${EXPORT_FOLDER_BASE}/${LOAD_DTTM}"

if [[ -n "${EXPORT_CSV_FILE}" ]]; then
    export TARGET_FOLDER=$(dirname "${EXPORT_CSV_FILE}")
    get_file_name TARGET_FILE "${EXPORT_CSV_FILE}" "${EXPORT_FILE_EXTENSION}"
else
    get_argument_by_name LOAD_ID --loadID required "$@"
    get_argument_by_name EXTRACT_DTTM --extractDTTM required "$@"
    export TARGET_FILE="${TARGET_FILE_BASE}-${LOAD_ID}-${EXTRACT_DTTM}"
    export EXPORT_CSV_FILE="${TARGET_FOLDER}/${TARGET_FILE}.csv"
fi

delete_if_exist "${EXPORT_CSV_FILE}" ${FORCE_EXPORT}
delete_if_exist "${TARGET_FOLDER}/${TARGET_FILE}.json" ${FORCE_EXPORT}

export_hive_to_csv
export-to-json

# Set acl for exported file and directory
set_acl ${EXPORT_CSV_FILE}

#Execute db test if enabled
if ! is_flag_argument_set ${DISABLE_DB_TEST}; then
    hive_export_db_test
fi

${CMD_EXECUTOR} --echo "Hive to delta step is finished"
