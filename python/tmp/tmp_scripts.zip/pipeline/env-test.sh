#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

export ABSTRACT_ENV=test
export ABSTRACT_USER=abstract

CDIR="$(dirname $0)"
#General directory properties
export ROOT_DIR=${CDIR}/..
export LIB_DIR=${ROOT_DIR}/lib

# Hive/MR basic execution parameters
export BEELINE_CMD=${BEELINE_CMD:-beeline}
export HIVE_CONNECTION_URL=${HIVE_CONNECTION_URL:-'jdbc:hive2://hive-01.bdptest.gin.merck.com:10000/;httpPath=cliservice;transportMode=http;auth=kerberos;principal=hive/hive-01.bdptest.gin.merck.com@BDPTEST.GIN.MERCK.COM'}
export YARN_JAR_CMD=${YARN_JAR_CMD:-yarn jar}
export YARN_QUEUE=${YARN_QUEUE:-mantis}
export C2H_YARN_QUEUE=${C2H_YARN_QUEUE:-${YARN_QUEUE}}
export VERIFY_YARN_QUEUE=${VERIFY_YARN_QUEUE:-${YARN_QUEUE}}

#ParseKit basic execution parameters
export CURL_CMD=${CURL_CMD:-curl}
export JQ_CMD=${JQ_CMD:-jq}
export PARSEKIT_URL=${PARSEKIT_URL:-'https://test.parsekit.merck.com'}

# HDFS parameters
export KNOX_HDFS_URI=${KNOX_HDFS_URI:-https://knox-01.bdptest.gin.merck.com:8443/gateway/default/webhdfs/v1/}

# Directory where Mantis is deployed (LANDING_DIR) is resolved during install

# Mantis configuration directory
export CONFIG_LOCATION=${CONFIG_LOCATION:-${LANDING_DIR}/mantis-config}
# ODBC config files
export HORTONWORKSHORTONWORKSHIVEODBCINI=${HORTONWORKSHORTONWORKSHIVEODBCINI:-${CONFIG_LOCATION}/hortonworks.hiveodbc.ini}
export ODBCINI=${ODBCINI:-${CONFIG_LOCATION}/odbc.ini}

export CSV2HIVE_TOOL_DIR=${CSV2HIVE_TOOL_DIR:-${LANDING_DIR}/${CSV2HIVE_TOOL_ARTIFACT_DIR}}
export CSV2HIVE_TOOL_SCRIPT=${CSV2HIVE_TOOL_SCRIPT:-${CSV2HIVE_TOOL_DIR}/bin/csv2hive-tool}

export CSV2ABSTRACT_DIR=${CSV2ABSTRACT_DIR:-${LANDING_DIR}/${CSV2ABSTRACT_ARTIFACT_DIR}}
export CSV2ABSTRACT_SCRIPT=${CSV2ABSTRACT_SCRIPT:-${CSV2ABSTRACT_DIR}/bin/csv2abstract}

export VERIFY_PIPELINE_DIR=${VERIFY_PIPELINE_DIR:-${LANDING_DIR}/${VERIFY_PIPELINE_ARTIFACT_DIR}}
export VERIFY_PIPELINE_SCRIPT=${VERIFY_PIPELINE_SCRIPT:-${VERIFY_PIPELINE_DIR}/bin/verify-pipeline}

# Java8 home
export JAVA_HOME=${JAVA_HOME:-"$(find /usr/jdk64/ -maxdepth 1 -name "jdk1.8*" -print -quit)"}

#Path to abstract credentials file
export ABSTRACT_CREDENTIALS_FILE=${ABSTRACT_CREDENTIALS_FILE:-${LANDING_DIR}/.abstract-credentials.sh}

#Command executor wrapper
export CMD_EXECUTOR=${CMD_EXECUTOR:-"${LANDING_DIR}/mantis-pipeline/rel/lib/python/executor.py"}
