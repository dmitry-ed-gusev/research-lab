#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

from base import MantisPipelineStep
from pipeline.lib.errors import DBTestError


class TestStep(MantisPipelineStep):
    """Simple test step with only logs and failing DBTest. Should be removed after actual steps implementations"""

    def setup(self):
        self.logger.debug("Test step setup")

    def execute(self):
        self.logger.debug("Test step execute")

    def setup_db_test(self):
        self.logger.debug("Test step db-test-setup")

    def run_db_test(self):
        self.logger.debug("Test step db-test-execute")
        raise DBTestError('Values are not equal')

    def cleanup(self):
        self.logger.debug("Test step cleanup")