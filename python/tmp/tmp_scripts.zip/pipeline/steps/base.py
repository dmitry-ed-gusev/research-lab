#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os


class MantisPipelineStep(object):
    """Base class for all mantis pipeline steps"""

    def __init__(self, configuration, logger, args):
        self.configuration = configuration
        self.logger = logger
        self.args = args

    def resolve_model_properties(self):
        """ Resolve model-specific properties\n
            Properties are stored as (name, template) in self.model_properties list
        """
        for prop in self.model_properties:
            self.configuration.resolve_and_set(*prop)

    def verify_file_exist(self, file_name):
        """Verify file existing"""
        if not os.path.isfile(file_name):
            raise IOError("File '%s' not found" % file_name)

    def wrap_quote(self, string):
        return "'%s'" % string

    def setup(self):
        """Additional arguments validation and other setup actions"""

    def setup_db_test(self):
        """Specific initialization for db-tests"""

    def execute(self):
        """Actual step execution"""

    def run_db_test(self):
        """Execution of db-test checks"""

    def cleanup(self):
        """Cleanup step leftovers if any"""

    model_properties = [
        ('model_system_dir', '${landing_dir}/mantis-systems-${source_system}/rel/${source_system}/${source_system_location}/${source_system_env}/datasets'),
        ('model_table_dir', '${model_system_dir}/${source_table}'),
        ('model_step_dir', '${model_table_dir}/${step_name}'),
        ('abstract_schemas_path', '${aux_hdfs_dir_base}/abstract-schemas'),
        ('source_system_hdfs_base', '${aux_hdfs_dir_base}/${source_system_env}/${source_system}/${source_system_location}'),
        ('verify_steps_base_path', '${source_system_hdfs_base}/verify'),
        ('hdfs_tmp_dir', '${source_system_hdfs_base}/temp')
    ]
