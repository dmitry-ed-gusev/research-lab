#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

export RAW_PARTITIONS_SELECT_SCRIPT=${RAW_PARTITIONS_SELECT_SCRIPT:-select-raw-partitions.hql}
export RAW_PARTITIONS_CLEANUP_SCRIPT=${RAW_PARTITIONS_CLEANUP_SCRIPT:-cleanup-raw-partitions.hql}
export CURATED_PARTITIONS_SELECT_SCRIPT=${CURATED_PARTITIONS_SELECT_SCRIPT:-select-curated-partitions.hql}
export CURATED_PARTITIONS_CLEANUP_SCRIPT=${CURATED_PARTITIONS_CLEANUP_SCRIPT:-cleanup-curated-partitions.hql}
export CURATED_RECORDS_CLEANUP_SCRIPT=${CURATED_RECORDS_CLEANUP_SCRIPT:-hard-delete-from-curated.hql}
