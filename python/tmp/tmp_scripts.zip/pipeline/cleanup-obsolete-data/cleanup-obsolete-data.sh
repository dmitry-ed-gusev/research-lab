#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e
${CMD_EXECUTOR} --echo "Executing cleanup-obsolete-data pipeline step"

BASEDIR="$(dirname $0)"

#Set up local environment
[ -f "${BASEDIR}/env.sh" ] && . "${BASEDIR}/env.sh"

#Import libs
for file in $(ls ${LIB_DIR}/*.sh)
do
    source ${file}
done

#Read step-specific arguments (general parameters are parsed in mdc.sh)
get_argument_by_name TARGET_LAYER --targetLayer required "$@"
get_argument_by_name LOAD_DTTM --loadDTTM required "$@"

if [ "${TARGET_LAYER}" == "raw" ]; then
    HIVE_SCRIPT=${RAW_PARTITIONS_CLEANUP_SCRIPT}
    SELECTION_SCRIPT=${RAW_PARTITIONS_SELECT_SCRIPT}
    CLEANUP_TYPE=partitions
elif [ "${TARGET_LAYER}" == "curated" ]; then
    get_argument_by_name CLEANUP_TYPE --cleanupType required "$@"
    if [ "${CLEANUP_TYPE}" == "partitions" ]; then
        HIVE_SCRIPT=${CURATED_PARTITIONS_CLEANUP_SCRIPT}
        SELECTION_SCRIPT=${CURATED_PARTITIONS_SELECT_SCRIPT}
    elif [ "${CLEANUP_TYPE}" == "records" ]; then
        HIVE_SCRIPT=${CURATED_RECORDS_CLEANUP_SCRIPT}
    else
        ${CMD_EXECUTOR} --echo "Unknown cleanup type: '${CLEANUP_TYPE}'. Supported types are ['partitions', 'records']." --level ERROR
        exit 2
    fi
else
    ${CMD_EXECUTOR} --echo "Unsupported target layer: '${TARGET_LAYER}'. Supported layers are ['raw', 'curated']." --level ERROR
    exit 2
fi

get_argument_by_name RETENTION_PERIOD --retentionPeriod required "$@"

${CMD_EXECUTOR} --echo "Applying retention rules for ${CLEANUP_TYPE} in ${TARGET_LAYER} layer with retention period of ${RETENTION_PERIOD} days"

HIVE_SCRIPT=${MODEL_STEP_DIR}/${HIVE_SCRIPT}
SELECTION_SCRIPT=${MODEL_STEP_DIR}/${SELECTION_SCRIPT}

${CMD_EXECUTOR} --echo "Verifying existence of HQL scripts" --level DEBUG
verify_file_exists ${HIVE_SCRIPT}

if [ "${CLEANUP_TYPE}" == "partitions" ]; then
    verify_file_exists ${SELECTION_SCRIPT}
    ${CMD_EXECUTOR} --echo "Selecting obsolete partitions" --level DEBUG
    PARTITIONS_STRING=`execute_hive --hivevar "RETENTION_PERIOD=${RETENTION_PERIOD}" --hql ${SELECTION_SCRIPT} --execute`
    PARTITIONS=()
    while read -r partition; do
        PARTITIONS+=("$partition")
    done <<< "$PARTITIONS_STRING"

    ${CMD_EXECUTOR} --echo "Found obsolete partitions: ${PARTITIONS[@]}" --level DEBUG
    for partition in "${PARTITIONS[@]}"; do
        if [ "$partition" != "$LOAD_DTTM" ]; then
            ${CMD_EXECUTOR} --echo "Drop obsolete partition: $partition" --level DEBUG
            execute_hive --hivevar "PARTITION_VALUE=${partition}" --hql ${HIVE_SCRIPT} --call
        else
            ${CMD_EXECUTOR} --echo "Leaving obsolete partition $LOAD_DTTM since it is the current one" --level WARN
        fi
    done
else
    ${CMD_EXECUTOR} --echo "Drop obsolete hard-deleted records from curated layer"
    execute_hive --hivevar "RETENTION_PERIOD=${RETENTION_PERIOD}" --hql ${HIVE_SCRIPT} --call
fi

${CMD_EXECUTOR} --echo "Retention rules has been applied"