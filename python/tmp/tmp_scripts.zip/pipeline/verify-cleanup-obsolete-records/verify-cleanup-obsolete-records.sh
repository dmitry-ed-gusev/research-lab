#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e

echo "Executing verify-cleanup-obsolete-records pipeline step"

BASEDIR="$(dirname $0)"

# Import libs
for file in $(ls ${LIB_DIR}/*.sh); do
    source ${file}
done

get_argument_by_name VERIFY_CSV --verifyCSV required "$@"
get_argument_by_name DB_NAME --targetDB required "$@"
get_argument_by_name TABLE_NAME --targetTable required "$@"
get_argument_by_name LOAD_DTTM --loadDTTM required "$@"

resolve_verify_csv_export_path TMP_PATH OUTPUT_CSV

${VERIFY_PIPELINE_SCRIPT} \
    --pipeline-step="${STEP_NAME}" \
    --verify-csv="${VERIFY_CSV}" \
    --export-dir="${TMP_PATH}" \
    --output-csv="${OUTPUT_CSV}" \
    --database="${DB_NAME}" \
    --table="${TABLE_NAME}" \
    --partition-column="${LOAD_DTTM_COL}" \
    --partition-value="${LOAD_DTTM}"

echo "Verify-cleanup-obsolete-records pipeline step executed successfully"