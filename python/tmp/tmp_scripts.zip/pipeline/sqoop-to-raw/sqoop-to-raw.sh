#!/usr/bin/env python
# coding=utf-8
# Copyright 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os
import argparse
import sys
import re

python_lib_path = sys.path.append(os.path.join(os.path.dirname(sys.argv[0]), '../../lib/python'))
sys.path.append(python_lib_path)

from configuration import Configuration
from logger import MantisLogger
from executor import execute
from hql_executor import HQLExecutor

# TODO: Perhaps move to common libs
def read_credentials(configuration, source_system, source_system_location, source_system_env):
    username = configuration.get('source_system_credentials.%s.%s.%s.username' %
                                 (source_system, source_system_env, source_system_location))
    password = configuration.get('source_system_credentials.%s.%s.%s.password' %
                                 (source_system, source_system_env, source_system_location))
    jdbc_connection_string = configuration.get('source_system_credentials.%s.%s.%s.jdbc_connection_string' %
                                 (source_system, source_system_env, source_system_location))
    jdbc_driver_type = configuration.get('source_system_credentials.%s.%s.%s.jdbc_driver' %
                                 (source_system, source_system_env, source_system_location))

    return username, password, jdbc_connection_string, jdbc_driver_type

# TODO: Move to common libs
def resolve_model_path(landing_dir, source_system, source_sysem_location, source_system_env, source_table, step_name):
    return os.path.join(landing_dir, 'mantis-systems-%s' % source_system, 'rel', source_system, source_sysem_location,
                        source_system_env, 'datasets', source_table, step_name)


def resolve_jdbc_driver_by_type(configuration, jdbc_driver_type):
    landing_dir = configuration.get('landing_dir')
    jdbc_driver_name = configuration.get('sqoop.source_system.%s.jdbc_driver_name' % jdbc_driver_type)
    jdbc_driver_jar_relative_path = configuration.get('sqoop.source_system.%s.jdbc_driver_jar_relative_path' %
                                                      jdbc_driver_type)

    jdbc_driver_jar_path = os.path.join(landing_dir, jdbc_driver_jar_relative_path)

    return jdbc_driver_name, jdbc_driver_jar_path


def prepare_sqoop_env(args, configuration):
    (user_name, user_password, jdbc_connection_string, jdbc_driver_type) = \
        read_credentials(configuration, args.sourceSystem, args.sourceSystemLocation, args.sourceSystemEnv)

    (jdbc_driver_name, jdbc_driver_jar_path) = resolve_jdbc_driver_by_type(configuration, jdbc_driver_type)

    yarn_params = '-Dmapreduce.job.queuename=%s' % configuration.get('yarn_queue')
    sqoop_path = os.path.join(configuration.get('landing_dir'), configuration.get('sqoop_artifact_relative_dir'), 'bin/sqoop')

    os.environ['HADOOP_CLASSPATH']= execute(['hcat', '-classpath'], "debug", logger).strip()
    os.environ["HADOOP_CLASSPATH"] += os.pathsep + jdbc_driver_jar_path

    os.environ['HCAT_HOME']= configuration.get('webhcat_home')
    os.environ['HIVE_HOME']= configuration.get('hive_client_home')
    os.environ['HADOOP_HOME']= configuration.get('hadoop_client_home')

    os.environ['SQOOP_CMD'] = sqoop_path
    os.environ['SQOOP_PARAMS'] = yarn_params
    os.environ['JDBC_CONNECTION_STRING'] = jdbc_connection_string
    os.environ['JDBC_DRIVER'] = jdbc_driver_name
    os.environ['JDBC_USER_NAME'] = user_name
    os.environ['JDBC_PASSWORD'] = user_password
    os.environ['EXTRACT_DTTM_VAL'] = args.extractDTTM
    os.environ['LOAD_ID_VAL'] = args.loadID
    os.environ['LOAD_DTTM_VAL'] = args.loadDTTM

    if args.ingestType == 'DELTA':
        os.environ['DELTA_LOWER_BOUND'] = args.deltaLowerBound
        os.environ['DELTA_UPPER_BOUND'] = args.deltaUpperBound


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--sourceSystem', type=str, required=True)
    parser.add_argument('--sourceSystemLocation', type=str, required=True)
    parser.add_argument('--sourceSystemEnv', type=str, required=True)
    parser.add_argument('--sourceTable', type=str, required=True)
    parser.add_argument('--ingestType', type=str, required=True)
    parser.add_argument('--loadDTTM', type=str, required=True)
    parser.add_argument('--stepName', type=str, required=True)
    parser.add_argument('--extractDTTM', type=str, required=True)
    parser.add_argument('--loadID', type=str, required=True)
    parser.add_argument('--deltaLowerBound', type=str, required=False)
    parser.add_argument('--deltaUpperBound', type=str, required=False)
    parser.add_argument('--disableDBTest', type=str, default="true", required=False)

    args, unknown = parser.parse_known_args()
    if args.ingestType == 'DELTA' and (args.deltaLowerBound is None or args.deltaUpperBound is None):
        logger.error('For DELTA ingest --deltaLowerBound and --upperLowerBound should be set')
        sys.exit(1)

    return args


if __name__ == "__main__":
    # TODO: Remove after full refactoring
    CONFIG_LOCATION=os.environ['CONFIG_LOCATION']

    configuration = Configuration()
    configuration.load(CONFIG_LOCATION)
    logger = MantisLogger()
    logger.configure(configuration)
    executor_hql = HQLExecutor(logger, configuration)

    logger.info('Sqoop-to-raw step is starting')

    logger.debug('Parsing input arguments')
    args = parse_args()

    logger.debug('Prepare environment for sqoop')
    prepare_sqoop_env(args, configuration)

    model_step_dir = resolve_model_path(configuration.get('landing_dir'), args.sourceSystem, args.sourceSystemLocation,
                                        args.sourceSystemEnv, args.sourceTable, args.stepName)

    row_count_source = '0'
    db_test_enabled = 'disableDBTest' in args and args.disableDBTest == "false"
    if db_test_enabled:
        logger.debug('Running db-test initialization')
        source_row_count_script_path = os.path.join(model_step_dir, 'db-test',
                                                    args.ingestType.lower() + '-ingest-row-count-source.sh')
        
        row_count_source_str = execute(source_row_count_script_path, 'debug', logger)
        result1 = re.findall('\| *([0-9]+ *)\|', row_count_source_str)
        row_count_source = str(result1[0]).strip()

        logger.debug('Db-test initialization has finished. Row number in source system: ' + str(row_count_source))

    logger.debug("Running sqoop script")
    ingest_script_path = os.path.join(model_step_dir, args.ingestType.lower() + '-ingest.sh')
    execute(ingest_script_path, "debug", logger)
    logger.debug("Sqoop script has been executed")

    if db_test_enabled:
        logger.debug('Running db-test check')
        raw_row_count_script_path = os.path.join(model_step_dir, 'db-test', 'row-count-raw.hql')
        row_count_raw = executor_hql.execute(type='file',value=raw_row_count_script_path, vars={'LOAD_DTTM_VAL': "'%s'" % args.loadDTTM},ret_val=True)
        if row_count_source != row_count_raw[0]:
            logger.error('DB-Test failed. Row number in source: ' + str(row_count_source) + '. Row number in Hive: ' + str(row_count_raw))
            sys.exit(1)

    logger.info('Sqoop-to-raw step has finished')