#!/usr/bin/env python
# coding=utf-8
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os
import subprocess

def touch(fname):
    with open(fname, 'a'):
        os.utime(fname, None)


def ensure_dirs(list_of_dirs):
    for dir_item in list_of_dirs:
        try:
            os.makedirs(dir_item)
        except:
            pass
        touch(dir_item+'full-initial-ingest.hql')
        touch(dir_item+'update-last-partition-view.hql')
        touch(dir_item+'consumer-latest-layer.hql')
        touch(dir_item+'export-hive-to-delta.hql')
        touch(dir_item+'export-full.hql')
        touch(dir_item+'select-raw-partitions.hql')
        touch(dir_item+'cleanup-raw-partitions.hql')
        touch(dir_item+'definition-hive-to-delta.hql')
        touch(dir_item+'export-hive-to-delta.hql')


def call_step(cmd_list):
    with open(os.devnull, 'w') as devnull_handle:
        pipes = subprocess.Popen(cmd_list, stderr=subprocess.PIPE)
        std_out_c, std_err = pipes.communicate()

        if pipes.returncode != 0:
            err_msg = "%s. Code: %s" % (std_err.strip(), pipes.returncode)
            raise Exception(err_msg)
        elif len(std_err):
            raise Exception(std_err)


print "[INFO] Creating build-time folder structure"
# TODO: fix to create true path, not 'every file in every path'
listdir = []
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/common/create-raw/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/events/raw-to-curated/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/common/create-operational/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/common/create-curated/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/common/create-consumer-latest/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/person/raw-to-curated/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/person/hive-to-teradata-csv/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/person/hive-to-delta-csv/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/person/curated-to-latest/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/person/create-raw/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/person/create-operational/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/person/create-curated/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/person/create-consumer-latest/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/person/cleanup-obsolete-data/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/events/raw-to-curated/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/events/hive-to-teradata-csv/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/events/hive-to-delta-csv/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/events/curated-to-latest/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/events/create-raw/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/events/create-operational/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/events/create-curated/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/events/create-consumer-latest/")
listdir.append("mantis-systems-test-pipeline/rel/test-pipeline/global/dev/datasets/events/cleanup-obsolete-data/")
ensure_dirs(listdir)



print "[INFO] Testing step 'landing-to-raw' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'landing-to-raw', '--sourceSystem', 'test-pipeline', '--sourceSystemEnv', 'dev',
             '--sourceSystemLocation', 'global', '--sourceTable', 'events', '--rawDB', 'mmd_dev_test_pipeline_raw', '--rawTable', 'events',
             '--filePath', '/tmp/mantis11/data/mmd/dev/test-pipeline/global/landing/events/dev-test-pipeline-global-events-123-2016-10-10-00-00-00.csv',
             '--loadDTTM', '10-10-2016']
call_step(shell_cmd)

print "[INFO] Testing step 'verify-landing-to-raw' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'verify-landing-to-raw', '--sourceSystem', 'test-pipeline', '--sourceSystemEnv', 'dev',
             '--sourceSystemLocation', 'global', '--sourceTable', 'events', '--rawDB', 'mmd_dev_test_pipeline_raw', '--rawTable', 'events',
             '--verifyCSV', '/tmp/mantis11/data/mmd/dev/test-pipeline/global/landing/events/dev-test-pipeline-global-events-123-2016-10-10-00-00-00.csv',
             '--loadDTTM', '10-10-2016']
call_step(shell_cmd)

print "[INFO] Testing step 'raw-to-curated' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'raw-to-curated', '--sourceSystem', 'test-pipeline', '--sourceSystemEnv', 'dev',
             '--sourceSystemLocation', 'global', '--sourceTable', 'events', '--loadDTTM', '10-10-2016', '--loadID', '123',
             '--extractDTTM', '10-10-2016', '--ingestType', 'FULL_INITIAL', '--disableDBTest', 'true']
call_step(shell_cmd)

print "[INFO] Testing step 'verify-raw-to-curated' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'verify-raw-to-curated', '--sourceSystem', 'test-pipeline', '--sourceSystemEnv', 'dev',
             '--sourceSystemLocation', 'global', '--sourceTable', 'events', '--curatedDB', 'mmd_dev_test_pipeline_curated', '--curatedTable', 'events',
             '--verifyCSV', '/tmp/mantis11/data/mmd/dev/test-pipeline/global/landing/events/dev-test-pipeline-global-events-123-2016-10-10-00-00-00.csv',
             '--loadDTTM', '10-10-2016']
call_step(shell_cmd)

print "[INFO] Testing step 'curated-to-latest' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'curated-to-latest', '--sourceSystem', 'test-pipeline', '--sourceSystemEnv', 'dev',
             '--sourceSystemLocation', 'global', '--sourceTable', 'events', '--loadDTTM', '10-31-2016', '--disableDBTest', 'true']
call_step(shell_cmd)

print "[INFO] Testing step 'verify-curated-to-latest' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'verify-curated-to-latest', '--sourceSystem', 'test-pipeline', '--sourceSystemEnv', 'dev',
             '--sourceSystemLocation', 'global', '--sourceTable', 'events', '--latestDB', 'mmd_dev_test_pipeline_latest', '--latestTable', 'events',
             '--verifyCSV', '/tmp/mantis11/data/mmd/dev/test-pipeline/global/landing/events/dev-test-pipeline-global-events-123-2016-10-10-00-00-00.csv']
call_step(shell_cmd)

print "[INFO] Testing step 'verify-hive-to-delta-csv' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'verify-hive-to-delta-csv', '--sourceSystem', 'test-pipeline', '--sourceSystemEnv', 'dev',
             '--sourceSystemLocation', 'global', '--sourceTable', 'events',
             '--consumerCSV', 'consumer.csv',
             '--verifyCSV', '/tmp/mantis11/data/mmd/dev/test-pipeline/global/landing/events/dev-test-pipeline-global-events-123-2016-10-10-00-00-00.csv']
call_step(shell_cmd)

print "[INFO] Testing step 'hive-to-teradata-csv' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh',
             '--stepName', 'hive-to-teradata-csv',
             '--sourceSystem', 'test-pipeline',
             '--sourceSystemEnv', 'dev',
             '--sourceSystemLocation', 'global',
             '--sourceTable', 'events',
             '--exportCSV', '/dir/export.csv',
             '--exportType', 'FULL',
             '--loadDTTM', '2016-12-15',
             '--forceExport', 'true',
             '--disableDBTest', 'true']
call_step(shell_cmd)

print "[INFO] Testing step 'verify-hive-to-teradata-csv' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh',
             '--stepName', 'verify-hive-to-teradata-csv',
             '--sourceSystem', 'test-pipeline',
             '--sourceSystemEnv', 'dev',
             '--sourceSystemLocation', 'global',
             '--sourceTable', 'events',
             '--consumerCSV', 'consumer.csv',
             '--verifyCSV', 'verify.csv']
call_step(shell_cmd)

print "[INFO] Testing step 'csv-to-abstract' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'csv-to-abstract', '--sourceSystem', 'test-pipeline', '--sourceSystemEnv', 'dev',
             '--sourceSystemLocation', 'global', '--sourceTable', 'events', '--consumerCSV', 'consumer.csv',
             '--abstractDatasetName', 'datalake.mmd.dev.glims.global', '--disableDBTest', 'true']
call_step(shell_cmd)


print "[INFO] Testing step 'verify-csv-to-abstract' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'verify-csv-to-abstract', '--sourceSystem', 'test-pipeline', '--sourceSystemEnv', 'dev',
             '--sourceSystemLocation', 'global', '--sourceTable', 'events',
             '--verifyCSV', 'verify.csv', '--abstractDatasetName', 'datalake.mmd.dev.glims.global']
call_step(shell_cmd)


print "[INFO] Testing step 'parsekit-import' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'parsekit-import', '--cmd', 'test', '--sourceSystemDivision', 'mmd', '--sourceSystemEnv', 'dev', '--sourceSystem', 'test-pipeline',
             '--sourceSystemLocation', 'global',  '--sourceTableSchema', 'schema', '--sourceTable', 'events']
call_step(shell_cmd)

print "[INFO] Testing step 'cleanup-obsolete-data' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'cleanup-obsolete-data', '--sourceSystem', 'test-pipeline', '--sourceSystemLocation', 'global',
             '--sourceSystemEnv', 'dev', '--sourceTable', 'events', '--targetLayer', 'raw', '--loadDTTM', '2016-12-15', '--retentionPeriod', '3', '--disableDBTest', 'true']
call_step(shell_cmd)

print "[INFO] Testing step 'verify-cleanup-obsolete-partitions' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'verify-cleanup-obsolete-partitions', '--sourceSystem', 'test-pipeline', '--sourceSystemLocation', 'global',
             '--sourceSystemEnv', 'dev', '--sourceTable', 'events', '--verifyCSV', 'verify.csv', '--targetDB', 'raw_or_cur_db', '--targetTable', 'events']
call_step(shell_cmd)

print "[INFO] Testing step 'verify-cleanup-obsolete-records' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'verify-cleanup-obsolete-records', '--sourceSystem', 'test-pipeline', '--sourceSystemLocation', 'global',
             '--sourceSystemEnv', 'dev', '--sourceTable', 'events', '--verifyCSV', 'verify.csv', '--targetDB', 'cur_db', '--targetTable', 'events', '--loadDTTM', '2016-12-15']
call_step(shell_cmd)

print "[INFO] Testing step 'hive-to-delta-csv' for being callable"
shell_cmd = ['bash', 'pipeline/mdc.sh', '--stepName', 'hive-to-delta-csv', '--sourceSystem', 'test-pipeline', '--sourceSystemEnv', 'dev',
             '--sourceSystemLocation', 'global', '--sourceTable', 'events', '--exportCSV', '/dir/export.csv', '--loadDTTM', '2016-12-15',
             '--forceExport', 'true', '--disableDBTest', 'true']
call_step(shell_cmd)


# TODO: Add integrity test to sqoop-to-raw step.

# Test pipeline integrity
print "Everything is ok"
