#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

#Usage:
# init-hive-layers.sh --system system-name|system-name-1,system-name-2,etc|'*' --target layers|tables --env env-name

set -e

source ${PIPELINE_DIR}/env.sh

export SCRIPT_LIB_DIR=${LANDING_DIR}/mantis-pipeline/rel/lib
export SCRIPT_MODEL_DIR=${LANDING_DIR}
export SCRIPT_PIPELINE_DIR=${LANDING_DIR}/mantis-pipeline/rel/pipeline


function execute_files() {
    file_pattern="$1"
    local files=($(eval ls ${file_pattern}))
    if [ -z ${files} ]; then
        ${CMD_EXECUTOR} --echo "Failed to find files with ACL settings" --level ERROR
        exit 1
    fi
    for file in "${files[@]}"; do
        ${CMD_EXECUTOR} --echo "Executing: ${file}"
        ${CMD_EXECUTOR} --call "${file}" --level DEBUG
    done
}

function execute_hive_scripts() {
    file_pattern="$1"
    tmp="_tmp_script.hql"
    echo -n "" > "${tmp}"
    local files=($(eval ls ${file_pattern}))
        if [ -z ${files} ]; then
        ${CMD_EXECUTOR} --echo "Failed to find files with HQL scripts" --level ERROR
        exit 1
    fi
    for file in "${files[@]}"; do
        ${CMD_EXECUTOR} --echo "Processing Hive script: ${file}"
        cat "${file}" >> "${tmp}"
        echo -e "\n" >> "${tmp}"
    done
    ${CMD_EXECUTOR} --echo "Executing Hive script: ${tmp}"
    execute_hive --hql "${tmp}" --call
    rm "${tmp}"
}

function create_layers() {
    system="$1"
    env="$2"
    execute_hive_scripts "${SCRIPT_MODEL_DIR}/mantis-systems-${system}/${CURRENT_MODEL_LOCATION}/${system}/*/${env}/common/create-*/*.hql"
    execute_files "${SCRIPT_MODEL_DIR}/mantis-systems-${system}/${CURRENT_MODEL_LOCATION}/${system}/*/${env}/common/create-*/set-acl-*.sh"
}

function create_tables() {
    system="$1"
    env="$2"
    execute_hive_scripts "${SCRIPT_MODEL_DIR}/mantis-systems-${system}/${CURRENT_MODEL_LOCATION}/${system}/*/${env}/datasets/*/create-raw/create-raw-layer.hql"
    execute_hive_scripts "${SCRIPT_MODEL_DIR}/mantis-systems-${system}/${CURRENT_MODEL_LOCATION}/${system}/*/${env}/datasets/*/create-curated/create-curated-layer.hql"
    execute_hive_scripts "${SCRIPT_MODEL_DIR}/mantis-systems-${system}/${CURRENT_MODEL_LOCATION}/${system}/*/${env}/datasets/*/create-operational/create-last-partition-view.hql"
    execute_hive_scripts "${SCRIPT_MODEL_DIR}/mantis-systems-${system}/${CURRENT_MODEL_LOCATION}/${system}/*/${env}/datasets/*/create-consumer-latest/create-consumer-latest-layer.hql"
    execute_hive_scripts "${SCRIPT_MODEL_DIR}/mantis-systems-${system}/${CURRENT_MODEL_LOCATION}/${system}/*/${env}/datasets/*/create-operational/create-export-columns-view.hql"

}

for file in $(ls ${SCRIPT_LIB_DIR}/*.sh); do
    source ${file}
done

get_argument_by_name SYSTEM_NAMES --system required "$@"
get_argument_by_name INIT_TARGET --target required "$@"
get_argument_by_name ENV --env required "$@"

${CMD_EXECUTOR} --echo "Running hive ${INIT_TARGET} initialization for systems ${SYSTEM_NAMES} on ${ENV} environment"

# If several source systems were set (separated by commas) add leading and trailing curly braces
if [[ ${SYSTEM_NAMES} == *,* ]]; then
  SYSTEM_NAMES={${SYSTEM_NAMES}}
fi

export CURRENT_MODEL_LOCATION=${CURRENT_MODEL_LOCATION:-rel}

case "${INIT_TARGET}" in
    layers)
        create_layers "${SYSTEM_NAMES}" "${ENV}"
        ;;
    tables)
        create_tables "${SYSTEM_NAMES}" "${ENV}"
        ;;
    *)
        ${CMD_EXECUTOR} --echo "Unknown target ${INIT_TARGET}. Valid targets are ['layers', 'tables']" --level ERROR
        exit 2
esac

${CMD_EXECUTOR} --echo "Initialization completed successfully"
