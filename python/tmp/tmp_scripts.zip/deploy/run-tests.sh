#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

# Import build-time env
. pipeline/env-build.sh


python deploy/test-integrity.py
exit $?
