#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e

# Prepare target environment. Will be called by https://stash.merck.com/projects/MF/repos/app-nexus-deployment/browse
export DEPLOY_ENV=${DEPLOY_ENV:-dev}
export PIPELINE_DIR=${PIPELINE_DIR:-pipeline}
export LANDING_DIR=${LANDING_DIR:-"${HOME}"}

# Source systems with their environments to initialize. By default initialize all prod source systems
export ENV_SYSTEMS_LIST=${ENV_SYSTEMS_LIST:-"prod:*"}

echo "" >> ${PIPELINE_DIR}/env.sh
echo "export LANDING_DIR=\${LANDING_DIR:-${LANDING_DIR}}" >> ${PIPELINE_DIR}/env.sh

if  [ -f ${PIPELINE_DIR}/env-${DEPLOY_ENV}.sh ] ; then
    echo "Deployment-specific env.sh found. Adding it to main."
    echo "" >> ${PIPELINE_DIR}/env.sh
    cat ${PIPELINE_DIR}/env-${DEPLOY_ENV}.sh >> ${PIPELINE_DIR}/env.sh
fi

echo "Deploying pipeline yaml config"
cp lib/python/config/common.yml ${LANDING_DIR}/mantis-config/
cp lib/python/config/steps_registry.yml ${LANDING_DIR}/mantis-config/
cp lib/python/config/${DEPLOY_ENV}.yml ${LANDING_DIR}/mantis-config/
cp lib/python/config/odbc/${DEPLOY_ENV}.ini ${LANDING_DIR}/mantis-config/odbc.ini
cp lib/python/config/odbc/hortonworks.hiveodbc.ini ${LANDING_DIR}/mantis-config/hortonworks.hiveodbc.ini

if [ "${ARTIFACT_ID##*-}" != "pipeline" ] ; then
    echo "[INFO] Changing 'landing_dir' for user-specific deployment"
    sed -i "s%$(dirname ${LANDING_DIR})%$LANDING_DIR%g" ${LANDING_DIR}/mantis-config/dev.yml
fi

find . -name "*.sh" -exec chmod +x {} \;

echo "Deployed successfully"
