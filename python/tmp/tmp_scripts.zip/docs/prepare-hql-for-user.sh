#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e

ROOTDIR="$(cd  && pwd)/mantis-pipeline/rel"
echo "Root dir: ${ROOTDIR}"

source "${ROOTDIR}/pipeline/env.sh"

if [ "$1" ]; then
    USER_NAME="$1"
else
    USER_NAME="$(whoami)"
fi

echo "Patch scripts for user ${USER_NAME}"

DB_NAME_PREFIX=${USER_NAME}_
DB_LOCATION_PREFIX="\/tmp\/${USER_NAME}"

REPLACE="          s/SET RAW_DB=/SET RAW_DB=${DB_NAME_PREFIX}/g"
REPLACE="$REPLACE; s/SET HIVE_RAW_LOCATION=/SET HIVE_RAW_LOCATION=${DB_LOCATION_PREFIX}/g"

REPLACE="$REPLACE; s/SET CURATED_DB=/SET CURATED_DB=${DB_NAME_PREFIX}/g"
REPLACE="$REPLACE; s/SET HIVE_CURATED_LOCATION=/SET HIVE_CURATED_LOCATION=${DB_LOCATION_PREFIX}/g"

REPLACE="$REPLACE; s/SET OPERATIONAL_DB=/SET OPERATIONAL_DB=${DB_NAME_PREFIX}/g"
REPLACE="$REPLACE; s/SET HIVE_OPERATIONAL_LOCATION=/SET HIVE_OPERATIONAL_LOCATION=${DB_LOCATION_PREFIX}/g"

REPLACE="$REPLACE; s/SET LATEST_DB=/SET LATEST_DB=${DB_NAME_PREFIX}/g"
REPLACE="$REPLACE; s/SET HIVE_CONSUMER_LOCATION=/SET HIVE_CONSUMER_LOCATION=${DB_LOCATION_PREFIX}/g"

REPLACE="$REPLACE; s/HIVE_DATABASE_LOCATION=/HIVE_DATABASE_LOCATION=${DB_LOCATION_PREFIX}/g"

echo find -L "${ROOTDIR}" -type f \( -name '*.hql' -o -name '*.sh' \) -exec sed -i.bak -e "$REPLACE" {} +
find -L "${ROOTDIR}" -type f \( -name '*.hql' -o -name '*.sh' \) -exec sed -i.bak -e "$REPLACE" {} +

echo "HQL patching completed successfully"
