#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -e

DATADIR="$(dirname $0)"

DATA_DEPLOY_BASE=${DATA_DEPLOY_BASE:-/data/mmd}
if [ "$1" ]; then
    DATA_DEPLOY_BASE="$1"
fi

function deploy_data() {
    local env=$1
    local dataset=$2
    local layer=$3
    local deploy_dir=$4

    hdfs dfs -mkdir -p "${deploy_dir}"
    hdfs dfs -rm -R -f "${deploy_dir}/${dataset}"
    hdfs dfs -put "${DATADIR}/${layer}/${env}/${dataset}" "${deploy_dir}/"
}

DEV_DEPLOY_LANDING_DIR="${DATA_DEPLOY_BASE}/dev/test-pipeline/global/landing"
echo "Deploying landing data for dev environment into ${DEV_DEPLOY_LANDING_DIR}"

deploy_data dev person landing ${DEV_DEPLOY_LANDING_DIR}
deploy_data dev events landing ${DEV_DEPLOY_LANDING_DIR}

TEST_DEPLOY_LANDING_DIR="${DATA_DEPLOY_BASE}/test/test-pipeline/global/landing"
echo "Deploying landing data for test environment into ${TEST_DEPLOY_LANDING_DIR}"

deploy_data test verify_full_ingest landing ${TEST_DEPLOY_LANDING_DIR}
deploy_data test verify_increment   landing ${TEST_DEPLOY_LANDING_DIR}

TEST_DEPLOY_VERIFY_DIR="${DATA_DEPLOY_BASE}/test/test-pipeline/global/verify"
echo "Deploying verify data for test environment into ${TEST_DEPLOY_VERIFY_DIR}"

deploy_data test verify_full_ingest verify ${TEST_DEPLOY_VERIFY_DIR}
deploy_data test verify_increment   verify ${TEST_DEPLOY_VERIFY_DIR}


echo "Test datasets deployed successfully"
