#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

#Verify that file "$1" exists
function verify_file_exists() {
    if [ ! -f "$1" ]; then
        ${CMD_EXECUTOR} --echo "HQL script doesn't exist: $1" --level ERROR
        return 2
    fi
}

#Resolve paths to model directories
function resolve_model_path() {
    export MODEL_SYSTEM_DIR="${LANDING_DIR}/mantis-systems-${SOURCE_SYSTEM}/rel/${SOURCE_SYSTEM}/${SOURCE_SYSTEM_LOCATION}/${SOURCE_SYSTEM_ENV}/datasets"
    export MODEL_TABLE_DIR="${MODEL_SYSTEM_DIR}/${SOURCE_TABLE}"
    export MODEL_STEP_DIR="${MODEL_TABLE_DIR}/${STEP_NAME}"

    export ABSTRACT_SCHEMAS_PATH=${AUX_HDFS_DIR_BASE}/abstract-schemas
    export SOURCE_SYSTEM_HDFS_BASE=${AUX_HDFS_DIR_BASE}/${SOURCE_SYSTEM_ENV}/${SOURCE_SYSTEM}/${SOURCE_SYSTEM_LOCATION}
    export VERIFY_STEPS_BASE_PATH=${SOURCE_SYSTEM_HDFS_BASE}/verify
    export HDFS_TMP_DIR=${SOURCE_SYSTEM_HDFS_BASE}/temp
}

#Resolves full file for schema of particular source table. Used for detecting schema change during csv2abstract
function resolve_export_schema_file() {
    local schema_file=$1
    local abstract_dataset_name=$2
    export $schema_file=${ABSTRACT_SCHEMAS_PATH}/${abstract_dataset_name}/schema/schema.json
}

#Resolves path to directory were data can be exported during verify step
# and full path for CSV which will be exported
function resolve_verify_csv_export_path() {
    local export_dir=$1
    local export_file=$2

    export $export_dir=${VERIFY_STEPS_BASE_PATH}/tmp
    export $export_file=${VERIFY_STEPS_BASE_PATH}/export.csv
}

#Returns filename by full path. Optionally can exclude file extension
function get_file_name() {
    local file_name=$1
    local full_path=$2
    local extension=$3
    export $file_name=$(basename ${full_path} .${extension})
}

#Set the value of argument with name "$2" into variable "$1"
#Syntax get_argument_by_name 'VAR_NAME' '--argname' 'required'|'optional' "$@"
function get_argument_by_name() {
    local varname=$1
    local argname=$2
    local required=false
    [ "$3" = "required" ] && local required=true

    while [[ $# -gt 3 ]]; do
        key="$4"
        case "$key" in
            $argname)
            export $varname="$5"
            return 0
            ;;
            $argname=*)
            export $varname="${key#*=}"
            return 0
            ;;
        esac
        shift
    done

    if $required; then
        ${CMD_EXECUTOR} --echo "Missing required argument \"$argname\"" --level ERROR
        return 2
    fi
}

#Checks if argument value is equal to "true" or "false"
#Logs error if argument has other value
function is_flag_argument_set() {
  if [ "${1}" == "true" ]; then
    return 0
  fi

  if [ "${1}" == "false" ]; then
    return 1
  fi

  ${CMD_EXECUTOR} --echo "Wrong flag argument value: ${1}" --level ERROR
  return 2
}


