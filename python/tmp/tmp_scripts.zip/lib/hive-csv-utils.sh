#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -E

function export_hive_to_csv {
    ${CMD_EXECUTOR} --echo "Export to csv is starting"
    CSV_CONVERSION_START=$(date +'%s')

    EXPORT_SCRIPT="${MODEL_STEP_DIR}/${EXPORT_SCRIPT_NAME}"
    verify_file_exists "${EXPORT_SCRIPT}"

    ${CMD_EXECUTOR} --echo "Ensure temp directory '${EXPORT_FOLDER}' is created and empty" --level DEBUG
    ${CMD_EXECUTOR} --hdfs delete "${EXPORT_FOLDER}" TRUE
    ${CMD_EXECUTOR} --hdfs makedirs "${EXPORT_FOLDER}" 
    ${CMD_EXECUTOR} --echo "Export CSV to ${EXPORT_FOLDER}" --level DEBUG
    execute_hive --hivevar EXPORT_OUTPUT_DIRECTORY="'${EXPORT_FOLDER}'" "${HIVE_EXECUTION_PARAMS[@]}" --hql "${EXPORT_SCRIPT}" --call

    ${CMD_EXECUTOR} --echo "Start merging of resulting CSV files" --level DEBUG
    CSV_MERGE_START=$(date +'%s')

    #Ensure tagret folder is created
    ${CMD_EXECUTOR} --hdfs makedirs "${TARGET_FOLDER}"

    ${CMD_EXECUTOR} --hdfs merge_files "${EXPORT_FOLDER}" "${EXPORT_CSV_FILE}"
    ${CMD_EXECUTOR} --echo "Cleanup export folder '${EXPORT_FOLDER}'" --level DEBUG
    ${CMD_EXECUTOR} --hdfs delete "${EXPORT_FOLDER}" TRUE

    CSV_MERGE_START=$(($(date +'%s') - ${CSV_MERGE_START}))
    ${CMD_EXECUTOR} --echo "CSV Merge took $(date -u -d @${CSV_MERGE_START} +%T)" --level DEBUG
    CSV_CONVERSION_TIME=$(($(date +'%s') - ${CSV_CONVERSION_START}))
    ${CMD_EXECUTOR} --echo "Hive to CSV export took $(date -u -d @${CSV_CONVERSION_TIME} +%T)" --level DEBUG
    ${CMD_EXECUTOR} --echo "Export to csv is finished"
}

function hive_export_db_test() {
    ${CMD_EXECUTOR} --echo "Starting db-test step"
    COUNT_SCRIPT="${MODEL_STEP_DIR}/${DB_TEST_DIR_NAME}/${COUNT_SCRIPT_NAME}"
    verify_file_exists "${COUNT_SCRIPT}"

    COUNT_FROM_HIVE=$(execute_hive "${HIVE_EXECUTION_PARAMS[@]}" --hql "${COUNT_SCRIPT}" --execute)
    ${CMD_EXECUTOR} --echo "Records from hive table: ${COUNT_FROM_HIVE}" --level DEBUG

    COUNT_EXPORTED_CSV=$(${CMD_EXECUTOR} --execute --level TRACE "${LIB_DIR}/python/count-rows.py" "${EXPORT_CSV_FILE}")
    ${CMD_EXECUTOR} --echo "Records from hdfs location: ${COUNT_EXPORTED_CSV}" --level DEBUG

    if [ "${COUNT_FROM_HIVE}" -ne "${COUNT_EXPORTED_CSV}" ]; then
        ${CMD_EXECUTOR} --echo "Number of records in hive table and exported CSV are not equal. Db-test failed" --level ERROR
        return 1
    fi

    ${CMD_EXECUTOR} --echo "Db-test passed"
}