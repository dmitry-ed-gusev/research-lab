#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.


#Fill default variables for mantis scripts
#Necessary values are expected to be set by caller
function execute_hive() {
    local HIVE_ARGS=()

    #Check if Hive options were set for the step or source system. Table options override source system options,
    #source system options override step options
    get_hive_opts STEP_OPTS   ${STEP_NAME}
    get_hive_opts SYSTEM_OPTS ${SOURCE_SYSTEM}
    get_hive_opts SOURCE_OPTS ${SOURCE_TABLE}

    #Check if Hive options were set for this particular script. They override all other options
    get_argument_by_name SCRIPT_FULL_PATH -f optional "$@"
    if [[ -n ${SCRIPT_FULL_PATH} ]]; then
        get_file_name SCRIPT_NAME ${SCRIPT_FULL_PATH} ${HQL_FILE_EXTENSION}
        get_hive_opts SCRIPT_OPTS ${SCRIPT_NAME}
    fi
    HIVE_ARGS=(${HIVE_ARGS[@]} ${STEP_OPTS} ${SYSTEM_OPTS} ${SOURCE_OPTS} ${SCRIPT_OPTS})

    wrap_with_quotes LOAD_DTTM_WRAPPED "${LOAD_DTTM}"
    wrap_with_quotes EXTRACT_DTTM_WRAPPED "${EXTRACT_DTTM}"
    #The sed command applied to hive output as we don't want empty lines in there.
    ${CMD_EXECUTOR} "${HIVE_ARGS[@]}" --hivevar "LOAD_DTTM_VAL=${LOAD_DTTM_WRAPPED}" --hivevar "LOAD_ID_VAL=${LOAD_ID}" --hivevar "EXTRACT_DTTM_VAL=${EXTRACT_DTTM_WRAPPED}" "$@" | sed -e '/^\s*$/d'
    if [[ ${PIPESTATUS[0]} != 0 ]]; then
        ${CMD_EXECUTOR} --echo "Error occurred during hive command execution. Check execution logs for details" --level ERROR
        return 1
    fi
}

#Gets Hive config from environment variable `source`_hive_opts.
# As example of sources there can be some particular step/system/table/script
function get_hive_opts() {
    local hive_opts=$1
    local source=$2
    source_opts=${source//-/_}${HIVE_OPTS_SUFFIX}
    if [[ -n ${!source_opts} ]]; then
        export $hive_opts="${!hive_opts} ${!source_opts}"
    fi
}

# Wraps hivevar with quotes if it doesn't contain spaces
function wrap_with_quotes() {
    local wrapped_var=$1
    local hive_var=$2
    case ${hive_var} in
        *\ * )
            export $wrapped_var="${hive_var}"
            ;;
        *)
            export $wrapped_var="'${hive_var}'"
            ;;
    esac
}