#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import sys, re, logging
from requests import ConnectionError, ConnectTimeout
from hdfs.ext.kerberos import KerberosClient
from hdfs.client import _Request, HdfsError
from configuration import ConfigError


class _HARequest(_Request):
    """Extended request class that adds support for HA NameNodes"""

    def to_method(self, operation):
        handler = super(_HARequest, self).to_method(operation=operation)

        def ha_handler(client, hdfs_path, data=None, strict=True, **params):
            """Request handler wrapper that execute the request with HA support"""
            fallbacks = set(client.name_nodes) - {client.url}
            while client.url:
                try:
                    return handler(client=client, hdfs_path=hdfs_path, data=data, strict=strict, **params)
                except (ConnectionError, ConnectTimeout, HdfsError) as e:
                    if isinstance(e, HdfsError):
                        if not re.match(r'^Operation category [A-Z]+ is not supported in state standby$', e.message):
                            raise HdfsError(e.message)
                    client.logger.warn("%s: %s" % (e.__class__.__name__, e.message))
                    client.logger.warn("Error connecting to " + client.url)
                    if len(fallbacks) > 0:
                        client.url = fallbacks.pop()
                        client.logger.warn("Fallback to " + client.url)
                    else:
                        raise HdfsError("Failed to connect to all possible NameNodes")
                except Exception as e:
                    raise HdfsError(e.message)

        ha_handler.__name__ = '%s_handler' % operation.lower()
        ha_handler.__doc__ = 'Cf. %s#%s' % (self.doc_url, operation)
        return ha_handler


class HdfsClient(KerberosClient):
    CONF_NAME_NODES = "hdfs.namenodes"
    STDIN_READ_BUFFER = 2 ** 16

    def __init__(self, config, logger=None):
        self.logger = logger if logger else logging.getLogger(__name__)
        name_nodes = config.get(self.CONF_NAME_NODES)
        if not isinstance(name_nodes, list):
            name_nodes = [name_nodes]
        name_nodes = filter(lambda url: url, name_nodes)
        if len(name_nodes) == 0:
            raise ConfigError("No NameNode URLs found in configuration")
        self.name_nodes = name_nodes
        super(HdfsClient, self).__init__(self.name_nodes[0])

    # Override base request mappings to provide HA support
    _append = _HARequest('POST', allow_redirects=False)
    _create = _HARequest('PUT', allow_redirects=False)
    _delete = _HARequest('DELETE')
    _get_acl_status = _HARequest('GET')
    _get_content_summary = _HARequest('GET')
    _get_file_checksum = _HARequest('GET')
    _get_file_status = _HARequest('GET')
    _get_home_directory = _HARequest('GET')
    _list_status = _HARequest('GET')
    _mkdirs = _HARequest('PUT')
    _modify_acl_entries = _HARequest('PUT')
    _open = _HARequest('GET', stream=True)
    _rename = _HARequest('PUT')
    _set_acl = _HARequest('PUT')
    _set_owner = _HARequest('PUT')
    _set_permission = _HARequest('PUT')
    _set_replication = _HARequest('PUT')
    _set_times = _HARequest('PUT')

    # Add support for concat request
    _concat = _HARequest("POST")

    def concat(self, hdfs_path, sources):
        self._concat(hdfs_path, sources=sources)

    def merge_files(self, hdfs_dir, target_file):
        """Concatenate all files in given folder and write result into target_file"""
        file_statuses = self.list(hdfs_dir, status=True)
        files = []
        for file_status in file_statuses:
            if file_status[1]['length'] != 0:
                files.append(hdfs_dir + "/" + file_status[0])
        self.logger.debug("Merging files: " + str(files))
        if len(files) == 0:
            self.touch(target_file)
            return
        if len(files) > 1:
            self.concat(files[0], ",".join(files[1:]))
        self.rename(files[0], target_file)

    def cat(self, hdfs_path):
        """Print whole file content to stdout (useful for bash invocations)"""
        with self.read(hdfs_path) as reader:
            out = 1
            while out:
                out = next(reader, None)
                if out is not None:
                    sys.stdout.write(out)

    def put(self, hdfs_path):
        """Write hdfs file from stdin (useful for bash invocations)"""
        with self.write(hdfs_path) as writer:
            data = 1
            while data:
                data = sys.stdin.read(self.STDIN_READ_BUFFER)
                writer.write(data)

    def touch(self, hdfs_path):
        """Create 0-length file"""
        with self.write(hdfs_path, overwrite=False):
            pass

    def test_exist(self, hdfs_path):
        """Test existing of file in bash style. For bash calls only as it exist the process!"""
        status = self.status(hdfs_path=hdfs_path, strict=False)
        if status is None:
            sys.exit(1)
        sys.exit(0)

    def ls(self, hdfs_path):
        """Print file names in specified path to stdout (for test invocations)"""
        files = self.list(hdfs_path=hdfs_path)
        pref = self.resolve(hdfs_path)
        for f in files:
            sys.stdout.write(pref + "/" + f + "\n")

    def copy_file(self, src, dest, overwrite=False):
        """Copy file on hdfs. Due to API specifics, it is done through client node read/write operations"""
        with self.read(src) as reader:
            with self.write(dest, overwrite=bool(overwrite)) as writer:
                content = 1
                while content:
                    content = next(reader, None)
                    if content is not None:
                        writer.write(content)

    def help(self):
        """Print help doc"""
        help(HdfsClient)
