#!/usr/bin/env python
# Copyright 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.
import argparse
import itertools
import logging
import os
import re
import subprocess
import sys

DEFAULT_USER = 'mantisetl'
DEFAULT_GROUP = 'mmd-admins'
DEFAULT_OWNER_PERMISSIONS = 'rwx'
DEFAULT_GROUP_PERMISSIONS = 'r-x'
DEFAULT_OTHER_PERMISSIONS = '--x'

HDFS_CMD_ENV_VARIABLE = 'HDFS_CMD'
HDFS_CMD_DEFAULT = 'hdfs dfs'
LOG_FORMAT = '%(asctime)s - %(levelname)s - %(message)s'
PERMISSIONS_PATTERN = re.compile('^[rwx-]{3}$')


def permissions(value):
    """Permissions :mod:`argparse` type."""
    if not PERMISSIONS_PATTERN.match(value):
        raise ValueError
    return value


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='test permissions of HDFS path')
    parser.add_argument('path', type=str,
                        help='path to test')
    parser.add_argument('--owner', type=str, default=DEFAULT_USER,
                        help='expected owner')
    parser.add_argument('--group', type=str, default=DEFAULT_GROUP,
                        help='expected group')
    parser.add_argument('--owner-permissions', type=permissions,
                        default=DEFAULT_OWNER_PERMISSIONS,
                        help='expected owner permissions')
    parser.add_argument('--group-permissions', type=permissions,
                        default=DEFAULT_GROUP_PERMISSIONS,
                        help='expected group permissions')
    parser.add_argument('--other-permissions', type=permissions,
                        default=DEFAULT_OTHER_PERMISSIONS,
                        help='expected other permissions')
    parser.add_argument('--no-recursive', dest='recursive', action='store_false',
                        help='do not test dirs and files recursively')
    parser.add_argument('--extended-acls', type=str, nargs='*',
                        help='extended HDFS ACLs to test')
    parser.set_defaults(recursive=True)
    return parser.parse_args()


def build_getfacl_command(path, recursive):
    """
    Build HDFS `-getfacl` command to execute.

    Use environment variable `HDFS_CMD` if available.

    :param path: `-getfacl` path argument
    :param recursive: boolean denoting whether to pass `-R` flag
    :return: command list
    """

    def flatten(struct):
        flat = []

        if isinstance(struct, basestring):
            return [struct]

        for result in iter(struct):
            flat += flatten(result)
        return flat

    hdfs_cmd = os.getenv(HDFS_CMD_ENV_VARIABLE, HDFS_CMD_DEFAULT).split(' ')
    if recursive:
        return flatten([hdfs_cmd, '-getfacl', '-R', path])
    else:
        return flatten([hdfs_cmd, '-getfacl', path])


def run_getfacl(path, recursive):
    """Run HDFS `-getfacl` command and return STDOUT lines."""
    getfacl_command = build_getfacl_command(path, recursive)
    logging.debug('Running: {}'.format(getfacl_command))
    hdfs_process = subprocess.Popen(getfacl_command, stdout=subprocess.PIPE)
    out, _ = hdfs_process.communicate()
    if hdfs_process.returncode:
        logging.error('HDFS command returned: {}'.format(hdfs_process.returncode))
        sys.exit(1)
    return out.splitlines()


class FilePermissions(object):
    """Extended HDFS file permissions."""

    def __init__(self):
        self.file = None
        self.owner = None
        self.group = None
        self.permissions = dict()
        self.extended_acls = []

    def check(self, args):
        """
        Compare the actual values with the expected args.

        :param args: arguments returned by :mod:`argparse`
        """
        logging.debug('Checking: {}'.format(self.file))

        result = True
        if args.owner != self.owner:
            logging.warn('%s: owner mismatch [%s]', self.file, self.owner)
            result = False
        if args.group != self.group:
            logging.warn('%s: group mismatch [%s]', self.file, self.group)
            result = False
        if args.owner_permissions != self.permissions.get('user'):
            logging.warn('%s: owner permissions mismatch [%s]', self.file, self.permissions.get('user'))
            result = False
        if args.group_permissions != self.permissions.get('group'):
            logging.warn('%s: group permissions mismatch [%s]', self.file, self.permissions.get('group'))
            result = False
        if args.other_permissions != self.permissions.get('other'):
            logging.warn('%s: other permissions mismatch [%s]', self.file, self.permissions.get('other'))
            result = False
        if args.extended_acls != self.extended_acls:
            logging.warn('%s: HDFS extended ACLs mismatch %s', self.file, self.extended_acls)
            result = False
        return result

    def _validate(self):
        """Validate the object"""
        if not all([self.file, self.owner, self.group]) or \
                any(key not in self.permissions for key in ('user', 'group', 'other')):
            raise ValueError('Invalid file permissions: {}'.format(self.__dict__))


def parse_file_permissions(facl_lines):
    """
    Parse file permissions list based on the output of `-getfacl` command.

    :param facl_lines: list of `-getfacl` output lines
    :return: list of :class:`FilePermissions` objects
    """
    file_permissions_list = []

    # Files are logically separated with empty lines
    for empty_line, line_iterator in itertools.groupby(facl_lines, key=lambda line: not line):
        if not empty_line:
            file_permissions = FilePermissions()

            for line in line_iterator:
                if line.startswith('# file: '):
                    file_permissions.file = line.split(': ')[1]
                elif line.startswith('# owner: '):
                    file_permissions.owner = line.split(': ')[1]
                elif line.startswith('# group: '):
                    file_permissions.group = line.split(': ')[1]
                elif '::' in line:
                    role, permissions = line.split('::')
                    file_permissions.permissions[role] = permissions
                elif not line.startswith('# '):
                    file_permissions.extended_acls.append(line)

            file_permissions._validate()
            file_permissions_list.append(file_permissions)

    return file_permissions_list


if __name__ == '__main__':
    logging.basicConfig(format=LOG_FORMAT, level=logging.DEBUG)

    args = parse_args()

    logging.info('Checking permissions on: {}'.format(args.path))
    logging.info("""Expecting:
            Owner: {owner}
            Group: {group}
            Owner permissions: {owner_permissions}
            Group permissions: {group_permissions}
            Other permissions: {other_permissions}
            HDFS extended ACL permissions: {extended_acls}""".format(**args.__dict__))

    facl_lines = run_getfacl(args.path, args.recursive)
    file_permissions_list = parse_file_permissions(facl_lines)

    if not all(map(lambda file_permissions: file_permissions.check(args), file_permissions_list)):
        logging.error('Test failed')
        sys.exit(-1)

    logging.info('Test passed')
