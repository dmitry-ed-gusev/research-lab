#!/usr/bin/env python
# coding=utf-8
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import sys
import os
import argparse
import subprocess

from configuration import Configuration
from logger import MantisLogger
from hdfs_client import HdfsClient
from hql_executor import HQLExecutor

# TODO: Remove after full refactoring
CONFIG_LOCATION = os.environ["CONFIG_LOCATION"]


def execute(command, level, logger):
    pipes = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (out, err) = pipes.communicate()

    getattr(logger, level.lower())(out.rstrip())
    if pipes.returncode != 0:
        if level is not None:
            logger.error(err.rstrip())
        sys.exit(pipes.returncode)
    else:
        if err.strip() != "":
            getattr(logger, level.lower())(err.rstrip())

    return out


def log_msg(level, message):
    if level == "DEBUG":
        logger.debug(message)
    elif level == "INFO":
        logger.info(message)
    elif level == "WARN":
        logger.warn(message)
    elif level == "ERROR":
        logger.error(message)
    elif level == "TRACE":
        logger.trace(message)
    elif level is not None:
        logger.error("LogLevel: %s not found, redirected to WARN" % args.level)
        logger.warn(message)


if __name__ == "__main__":
    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--echo', action='store_true')
    parser.add_argument('--level', type=str, default=None, required=False)
    parser.add_argument('--execute', action='store_true')  # call and return
    parser.add_argument('--call', action='store_true')
    parser.add_argument('--hdfs', type=str, default=None, required=False)  # Call hdfs client
    parser.add_argument('--hql', type=str, required=False)  # Call hql executor
    parser.add_argument('--hivevar', type=str, action='append', required=False)
    args, unknown = parser.parse_known_args()

    configuration = Configuration()
    configuration.load(CONFIG_LOCATION)
    logger = MantisLogger()
    logger.configure(configuration)

    if args.hdfs:
        try:
            client = HdfsClient(config=configuration, logger=logger)
            func = getattr(client, args.hdfs)
            func(*unknown)
            sys.exit(0)
        except Exception as e:
            logger.error("%s: %s" % (e.__class__.__name__, e.message))
            sys.exit(1)

    if args.hql:
        try:
            env_var = {}
            if args.hivevar:
                for variable in args.hivevar:
                    arr = variable.split('=')
                    env_var[arr[0]] = arr[1]
            hql_exec = HQLExecutor(config=configuration, logger=logger)
            result = hql_exec.execute(type='file', value=args.hql, vars=env_var, ret_val=True if args.execute else False)
            if args.execute:
                for line in result:
                    sys.stdout.write(line + "\n")
            sys.exit(0)
        except Exception as e:
            logger.error("%s: %s" % (e.__class__.__name__, e.message))
            sys.exit(1)

    if args.call or args.execute:
        if args.hivevar:
            for variable in args.hivevar:
                unknown.append('--hivevar')
                unknown.append(variable)

        pipes = subprocess.Popen(unknown, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        (out, err) = pipes.communicate()

        log_msg(args.level, out.rstrip())
        if pipes.returncode != 0:
            if args.level is not None:
                log_msg("ERROR", err.rstrip())
            sys.exit(pipes.returncode)
        else:
            if err.strip() != "":
                log_msg(args.level, err.strip())

        if args.execute:
            print out

    if args.echo:
        level = "INFO"
        if args.level is not None:
            level = args.level
        log_msg(level, " ".join(unknown))

    sys.exit(0)
