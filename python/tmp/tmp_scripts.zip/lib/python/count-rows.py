#!/usr/bin/env python
# Copyright 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import csv
import sys
import os
from configuration import Configuration
from logger import MantisLogger
from hdfs_client import HdfsClient

configuration = Configuration()
configuration.load(os.environ['CONFIG_LOCATION'])
logger = MantisLogger()
logger.configure(configuration)
client = HdfsClient(config=configuration, logger=logger)

count = 0
file_path = sys.argv[1]
with client.read(file_path) as f:
    reader = csv.reader(f, delimiter=b',', skipinitialspace=True, quoting=csv.QUOTE_MINIMAL, quotechar=b'"', lineterminator="\n")
    for row in reader:
        count = count + 1

print count
