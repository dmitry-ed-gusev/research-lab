#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.
import os, pyodbc, re, argparse

from logger import MantisLogger
from configuration import Configuration


class hive_client(object):

    COMMENT_PATTERN = r"--.*$"

    def __init__(self, logger, configuration):
        self.connection = None
        self.configuration = configuration
        self.logger = logger

    def connect(self):
        try:
            self.connection = pyodbc.connect("DSN=%s" % self.configuration.get("odbc_dsn_name"), autocommit=True)
            self.logger.debug("Hive client is connected to Hive.")
        except Exception as error:
            raise HiveError('Hive connection initialization failed: ' + str(error))

    def execute(self, q_type, q_value, vars={}, ret_val=False):
        if q_type.lower() == "file":
            return self.__execute_file(q_value, ret_val, vars)
        elif q_type.lower() == "query":
            return self.__execute_statement([q_value], ret_val, vars)
        else:
            raise HiveError("Not supported query type: " + str(q_type))

    def __execute_file(self, value, ret_val , vars={}):
        query = self.__read_file(value)
        return self.__execute_statement(query, ret_val, vars)

    def __execute_statement(self, value, ret_val, vars={}):
        queries = []
        for name, val in vars.items():
            var_str = "SET hivevar:%s=%s" % (name,val)
            self.logger.debug("Set hivevar: %s" % var_str)
            queries.append(var_str)

        queries += value
        cursor = self.connection.cursor()
        for query in queries:
            self.logger.debug("Executing: " + query)
            try:
                cursor = cursor.execute(query)
                self.logger.debug("Statement executed: " + query)
            except Exception as error:
                raise HiveError("Query execution error: " + str(error))

        if ret_val:
            output = self.__parse_output(cursor)
            return output

    def __read_file(self, file):
        try:
            with open(file, 'r') as raw_file:
                raw_hql = raw_file.read()
                hql = re.sub(self.COMMENT_PATTERN, "", raw_hql, flags=re.MULTILINE)
                hql = hql.replace("\n", " ")
                statements = hql.split(";")
                statements = map(lambda stmt: stmt.strip(), statements)
                statements = filter(lambda stmt: stmt, statements)
                return statements
        except Exception as error:
            raise HiveError("Reading statements from file error: " + str(error))

    def close(self):
        self.connection.close()
        self.connection = None
        self.logger.debug("Hive client is closed")

    def parse_args(self, args):
        result = {}
        if args:
            for arg in args:
                arr = arg.split("=")
                if len(arr) != 2:
                    raise HiveError("Error in argument parsing: can't parse " + str(arg))
                self.logger.debug("Arr " + arr[0] + " " + arr[1])
                result[arr[0]] = arr[1]
        return result

    def __parse_output(self, cursor):
        result = []
        for row in cursor.fetchall():
            tmp_str = []
            for entry in row:
                tmp_str.append(str(entry))
            result.append(",".join(tmp_str))

        return result


class HiveError(Exception):
    """Hive client execution error"""


if __name__ == "__main__":

    configuration = Configuration()
    configuration.load(os.environ['CONFIG_LOCATION'])

    logger = MantisLogger()
    logger.configure(configuration)

    client = hive_client(logger, configuration)

    parser = argparse.ArgumentParser()
    parser.add_argument('--q_type', type=str, default="file")
    parser.add_argument('--get_output', type=bool, default=False)
    parser.add_argument('--q_value', type=str)
    parser.add_argument('--env_variables', nargs=argparse.REMAINDER)
    args = parser.parse_args()

    client.connect()
    res = client.execute(args.q_type, args.q_value, client.parse_args(args.env_variables), args.get_output)
    if args.get_output:
        print res
    client.close()
