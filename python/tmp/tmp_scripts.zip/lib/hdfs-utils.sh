#!/usr/bin/env bash
# Copyright © 2016 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

set -E

function delete_if_exist() {
    local file=$1
    local force=$2
    #Remove target directory if present and in force mode
    if $(${CMD_EXECUTOR} --hdfs test_exist "${file}"); then
        if is_flag_argument_set ${force}; then
            ${CMD_EXECUTOR} --echo "Force mode is on. Remove target file '${file}'" --level DEBUG
            ${CMD_EXECUTOR} --hdfs delete "${file}" TRUE
        else
            ${CMD_EXECUTOR} --echo "Target file '${file}' already exists and force mode is off. Use '--forceExport true' to override it." --level ERROR
            return 1
        fi
    fi
}