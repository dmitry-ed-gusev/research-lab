class _MockConnection(object):
    def close(self):
        self.closed = True


def connect(dsn, **params):
    con = _MockConnection()
    con.closed = False
    return con
