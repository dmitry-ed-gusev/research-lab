import os
import sys
from cStringIO import StringIO
from contextlib import contextmanager


@contextmanager
def capture_stdout(command, *args, **kwargs):
    out, sys.stdout = sys.stdout, StringIO()
    try:
        command(*args, **kwargs)
        sys.stdout.seek(0)
        yield sys.stdout.read()
    finally:
        sys.stdout = out


class close_mock(object):
    def __init__(self, thing):
        self.thing = thing

    def __enter__(self):
        return self.thing

    def __exit__(self, *exc_info):
        pass


class MockCursor(object):
    def __init__(self):
        self.queries = []

    def execute(self, sql):
        self.queries.append(sql)
        return self


@contextmanager
def tmp_file(name, content):
    try:
        with open(name, 'w') as tf:
            tf.write(content)
        yield name
    finally:
        os.remove(name)