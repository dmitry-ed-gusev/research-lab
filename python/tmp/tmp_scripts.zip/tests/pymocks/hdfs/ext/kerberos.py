
class KerberosClient(object):
    """Mock hdfs-client (lib)"""

    def __init__(self, url, **kwargs):
        self.url = url
