
class _Request(object):
    """Mock request impl"""
    def __init__(self, *args, **kwargs):
        pass

    def __call__(self):
        pass


class HdfsError(Exception):
    """"""
