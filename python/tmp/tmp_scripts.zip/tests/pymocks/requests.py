class ConnectionError(Exception):
    """"""


class ConnectTimeout(Exception):
    """"""
