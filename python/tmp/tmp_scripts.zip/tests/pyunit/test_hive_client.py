#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import unittest
import logging
from lib.python.configuration import Configuration
from lib.python.hive_client import hive_client
from tests.pymocks.mocks import capture_stdout, close_mock, MockCursor, tmp_file


class HiveClientCreationTest(unittest.TestCase):

    @unittest.expectedFailure
    def test_InitNoConfigNoLoggerFail(self):
        hive_client(configuration=None, logger=None)

    @unittest.expectedFailure
    def test_InitNoConfigFail(self):
        hive_client(configuration=None, logger=logging.getLogger())

    def test_InitWithConfigPass(self):
        conf = Configuration()
        client = hive_client(configuration=conf, logger=logging.getLogger())
        self.assertIsNotNone(client)

    @unittest.expectedFailure
    def test_ConnectEmptyConf(self):
        self.conf = Configuration()
        self.client = hive_client(configuration=self.conf, logger=logging.getLogger())
        self.client.connect()


class HiveClientTest(unittest.TestCase):

    def setUp(self):
        self.conf = Configuration()
        self.conf.load('lib/python/config')
        self.client = hive_client(configuration=self.conf, logger=logging.getLogger())
        self.assertIsNotNone(self.client)

    def mock_cursor(self):
        mock = MockCursor()
        self.client.connection.cursor = lambda: mock
        return mock

    @unittest.expectedFailure
    def test_UnknownQueryType(self):
        self.client.connect()
        cur = self.mock_cursor()
        self.client.execute('string', 'val')

    def test_ExecuteStatement(self):
        self.client.connect()
        cur = self.mock_cursor()
        self.client.execute('query', 'sql 1')
        self.assertEqual(cur.queries, ['sql 1'])

    def test_ExecuteSelectStatement(self):
        self.client.connect()
        cur = self.mock_cursor()
        cur.fetchall = lambda: [['row1', 'val1'], ['row2', 'val2']]
        output = self.client.execute('query', 'sql 1', ret_val=True)
        self.assertEqual(cur.queries, ['sql 1'])
        self.assertEqual(output, ['row1,val1', 'row2,val2'])

    def test_ExecuteStatementWithVars(self):
        self.client.connect()
        cur = self.mock_cursor()
        self.client.execute('query', 'sql 1', vars={'var1': 'val1', 'var2': 'val2'})
        self.assertEqual(cur.queries, ['SET hivevar:var1=val1', 'SET hivevar:var2=val2', 'sql 1'])

    def test_ExecuteFileWithVars(self):
        self.client.connect()
        cur = self.mock_cursor()
        sql = "-- Comment \n SET hiveconf:cfg1=val1 ; \n --Comment 1 \n SQL Q \n--COM--\nSEL"
        with tmp_file('test-hive-client-hql', sql):
            self.client.execute('file', 'test-hive-client-hql', vars={'var1': 'val1', 'var2': 'val2'})
            self.assertEqual(cur.queries, ['SET hivevar:var1=val1', 'SET hivevar:var2=val2',
                                           'SET hiveconf:cfg1=val1', 'SQL Q   SEL'])

    def test_ParseArgsValid(self):
        self.client.connect()
        res = self.client.parse_args(['arg1=test', "arg_2='Test with ws'"])
        self.assertEqual(res, {
            'arg1': 'test',
            'arg_2': "'Test with ws'"
        })

    @unittest.expectedFailure
    def test_ParseArgsNoEqual(self):
        self.client.connect()
        self.client.parse_args(['valid=val', 'invalid'])

    @unittest.expectedFailure
    def test_ParseArgsTwoEqual(self):
        self.client.connect()
        self.client.parse_args(['invalid=val=val2'])

    def tearDown(self):
        con = self.client.connection
        self.client.close()
        self.assertTrue(con.closed)
        self.assertIsNone(self.client.connection)
        self.client = None
        self.conf = None
