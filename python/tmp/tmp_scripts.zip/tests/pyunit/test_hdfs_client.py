#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import unittest
from hdfs.client import _Request, HdfsError
from requests import ConnectionError, ConnectTimeout
from lib.python.configuration import Configuration
from lib.python.hdfs_client import HdfsClient, _HARequest
from tests.pymocks.mocks import capture_stdout, close_mock


class HdfsClientCreationTest(unittest.TestCase):

    @unittest.expectedFailure
    def test_InitWithoutConfigFail(self):
        HdfsClient(config=None)

    @unittest.expectedFailure
    def test_InitWithEmptyConfigFail(self):
        conf = Configuration()
        HdfsClient(config=conf)

    @unittest.expectedFailure
    def test_InitWithEmptyNameNodesFail(self):
        conf = Configuration()
        conf.config_dict['hdfs'] = {
            'namenodes': []
        }
        HdfsClient(config=conf)

    def test_InitWithSingleNameNode(self):
        conf = Configuration()
        conf.config_dict['hdfs'] = {
            'namenodes': 'name1'
        }
        client = HdfsClient(config=conf)
        self.assertEqual(client.name_nodes, ['name1'])

    def test_InitWithNameNodeList(self):
        conf = Configuration()
        conf.config_dict['hdfs'] = {
            'namenodes': ['name1', 'name2']
        }
        client = HdfsClient(config=conf)
        self.assertEqual(client.name_nodes, ['name1', 'name2'])


class HdfsClientTest(unittest.TestCase):

    def setUp(self):
        self.conf = Configuration()
        self.conf.load('lib/python/config')
        self.client = HdfsClient(config=self.conf)
        self.assertEqual(len(self.client.name_nodes), 2)

    def test_ls(self):
        self.client.list = lambda hdfs_path: ['p1', 'p2']
        self.client.resolve = lambda hdfs_path: '/' + hdfs_path
        with capture_stdout(self.client.ls, 'tmp') as out:
            self.assertEqual("/tmp/p1\n/tmp/p2\n", out)

    def test_cat(self):
        self.client.read = lambda hdfs_path: close_mock(iter(["OUT1", " OUT2"]))
        with capture_stdout(self.client.cat, 'path') as out:
            self.assertEqual("OUT1 OUT2", out)

    def tearDown(self):
        self.client = None
        self.conf = None


class HARequestTest(unittest.TestCase):

    def mock_handler(self, url_res):
        def mock_method(self, operation, **params):
            def handler(client, hdfs_path, **params):
                res = url_res.get(client.url, None)
                if isinstance(res, Exception):
                    raise res
                else:
                    return res
            return handler
        _Request.to_method = mock_method

    def setUp(self):
        conf = Configuration()
        conf.config_dict['hdfs'] = {
            'namenodes': ['name1', 'name2', 'name3', 'name4']
        }
        self.client = HdfsClient(config=conf)
        self.request = _HARequest('GET')
        self.request.doc_url = "url"

    def test_FirstConnected(self):
        self.mock_handler({'name1': 'output'})
        handler = self.request.to_method('get')
        res = handler(self.client, 'path')
        self.assertEqual(res, 'output')
        self.assertEqual(self.client.url, 'name1')

    def test_FallbackAllErrors(self):
        self.mock_handler({
            'name1': ConnectionError(),
            'name2': ConnectTimeout(),
            'name3': HdfsError('Operation category READ is not supported in state standby'),
            'name4': 'output'
        })
        handler = self.request.to_method(operation='get')
        res = handler(self.client, 'path')
        self.assertEqual(res, 'output')
        self.assertEqual(self.client.url, 'name4')

    @unittest.expectedFailure
    def test_GeneralErrorReported(self):
        self.mock_handler({
            'name1': HdfsError('File not found'),
            'name2': 'output'
        })
        handler = self.request.to_method(operation='get')
        handler(self.client, 'path')

    @unittest.expectedFailure
    def test_SingleNodeErrorReported(self):
        self.client.name_nodes = ['name1']
        self.mock_handler({
            'name1': ConnectionError()
        })
        handler = self.request.to_method(operation='get')
        handler(self.client, 'path')

    @unittest.expectedFailure
    def test_NoFallbackErrorReported(self):
        self.client.name_nodes = ['name1', 'name2']
        self.mock_handler({
            'name1': HdfsError('Operation category READ is not supported in state standby'),
            'name2': ConnectionError()
        })
        handler = self.request.to_method(operation='get')
        handler(self.client, 'path')

    @unittest.expectedFailure
    def test_UnknownError(self):
        self.client.name_nodes = ['name1']
        self.mock_handler({
            'name1': Exception()
        })
        handler = self.request.to_method(operation='get')
        handler(self.client, 'path')

    def tearDown(self):
        delattr(_Request, 'to_method')
        self.client = None
        self.request = None