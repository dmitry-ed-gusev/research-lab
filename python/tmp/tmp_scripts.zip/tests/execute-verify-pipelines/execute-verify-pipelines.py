#!/usr/bin/env python
# coding=utf-8
# Copyright © 2017 Merck Sharp & Dohme Corp., a subsidiary of Merck & Co., Inc.
# All rights reserved.

import os
import subprocess
import yaml
import argparse
from datetime import datetime


def execute_mdc(args):
    pipes = subprocess.Popen(args, stderr=subprocess.PIPE)
    std_out_c, std_err = pipes.communicate()
    if pipes.returncode != 0:
        err_msg = "%s. Error code: %s" % (std_err.strip(), pipes.returncode)
        raise Exception(err_msg)
#    elif len(std_err):
#        raise Exception(std_err)

def build_args(params, landing_dir):
    command = ['/bin/bash', landing_dir + '/mantis-pipeline/rel/pipeline/mdc.sh',
               '--stepName', params['step_name'],
               '--sourceSystem', 'test-pipeline',
               '--sourceSystemLocation', 'global',
               '--sourceTable', params['table_name'],
               '--sourceSystemEnv', 'test',
               '--disableDBTest', 'false']
    specific_command = {'landing-to-raw': ['--rawDB', 'mmd_test_test_pipeline_raw',
                                           '--rawTable', params['table_name'],
                                           '--loadDTTM', '' + str(params['load_dttm']),
                                           '--CSV2HIVE_MODE', 'override',
                                           '--filePath', params['hdfs_prefix'] + '/test/test-pipeline/global/landing/' + params['table_name']
                                           + '/test-test-pipeline-global-' + params['table_name'] + '-' + str(params['load_id']) + '-' + params[
                                               'extract_dttm'] + '.csv'],
                        'verify-landing-to-raw': ['--verifyCSV', params['hdfs_prefix'] + '/test/test-pipeline/global/verify/' + params['table_name']
                                                  + '/' + params['step_name'].replace('verify-', '') + '-' + str(params['load_id']) + '-' + params['extract_dttm'] + '.csv',
                                                  '--rawDB', 'mmd_test_test_pipeline_raw',
                                                  '--rawTable', params['table_name'],
                                                  '--loadDTTM', '' + str(params['load_dttm'])],
                        'raw-to-curated': ['--loadDTTM', '' + str(params['load_dttm']),
                                           '--loadID', str(params['load_id']),
                                           '--extractDTTM', params['extract_dttm'],
                                           '--ingestType', params['ingest_type'][params['table_name']]],
                        'verify-raw-to-curated': ['--verifyCSV', params['hdfs_prefix'] + '/test/test-pipeline/global/verify/' + params['table_name']
                                                  + '/' + params['step_name'].replace('verify-', '') + '-' + str(params['load_id']) + '-' + params['extract_dttm'] + '.csv',
                                                  '--curatedDB', 'mmd_test_test_pipeline_curated',
                                                  '--curatedTable', params['table_name'],
                                                  '--loadDTTM', '' + str(params['load_dttm'])],
                        'curated-to-latest': ['--loadDTTM', '' + str(params['load_dttm'])],
                        'verify-curated-to-latest': ['--verifyCSV', params['hdfs_prefix'] + '/test/test-pipeline/global/verify/' + params['table_name']
                                                     + '/' + params['step_name'].replace('verify-', '') + '-' + str(params['load_id']) + '-' + params['extract_dttm'] + '.csv',
                                                     '--latestDB', 'mmd_test_test_pipeline_consumer_latest',
                                                     '--latestTable', params['table_name']],
                        'hive-to-delta-csv': ['--loadDTTM', '' + str(params['load_dttm']),
                                              '--exportCSV', params['hdfs_prefix'] + '/test/test-pipeline/global/consumer_abstract/' + params['table_name'] + '/'
                                              + 'test-test-pipeline-global-' + params['table_name'] + '-' + str(params['load_id']) + '-' + params['extract_dttm'] + '.csv',
                                              '--forceExport', 'true'],
                        'verify-hive-to-delta-csv': ['--consumerCSV', params['hdfs_prefix'] + '/test/test-pipeline/global/consumer_abstract/' + params['table_name'] + '/'
                                                     + 'test-test-pipeline-global-' + params['table_name'] + '-' + str(params['load_id']) + '-' + params['extract_dttm'] + '.csv',
                                                     '--verifyCSV', params['hdfs_prefix'] + '/test/test-pipeline/global/verify/' + params['table_name']
                                                     + '/' + params['step_name'].replace('verify-', '') + '-' + str(params['load_id']) + '-' + params['extract_dttm'] + '.csv',],
                        'hive-to-teradata-csv': ['--loadDTTM', '' + str(params['load_dttm']),
                                                 '--exportType', params['extract_type'],
                                                 '--exportCSV', params['hdfs_prefix'] + '/test/test-pipeline/global/consumer_teradata/' + params['table_name'] + '/'
                                                 + 'test-test-pipeline-global-' + params['table_name'] + '-' + str(params['load_id']) + '-' + params['extract_dttm'] + '.csv',
                                                 '--exportFrom', params['extract_from'],
                                                 '--exportTo', params['extract_to'],
                                                 '--forceExport', 'true'],
                        'verify-hive-to-teradata-csv': ['--consumerCSV', params['hdfs_prefix'] + '/test/test-pipeline/global/consumer_teradata/' + params['table_name'] + '/'
                                                        + 'test-test-pipeline-global-' + params['table_name'] + '-' + str(params['load_id']) + '-' + params['extract_dttm'] + '.csv',
                                                        '--verifyCSV', params['hdfs_prefix'] + '/test/test-pipeline/global/verify/' + params['table_name']
                                                        + '/' + params['step_name'].replace('verify-', '') + '-' + str(params['load_id']) + '-' + params['extract_dttm'] + '.csv',
                                                        '--forceExport', 'true'],
                        'csv-to-abstract': ['--abstractDatasetName',
                                            'mantis.test-pipeline.global.test.' + params['user'] + '.' + params['table_name'].replace('_', '-'),
                                            '--consumerCSV', params['hdfs_prefix'] + '/test/test-pipeline/global/consumer_abstract/' + params['table_name'] + '/'
                                            + 'test-test-pipeline-global-' + params['table_name'] + '-' + str(params['load_id']) + '-' + params['extract_dttm'] + '.csv'],
                        'verify-csv-to-abstract': ['--verifyCSV', params['hdfs_prefix'] + '/test/test-pipeline/global/verify/' + params['table_name']
                                                   + '/' + params['step_name'].replace('verify-', '') + '-' + str(params['load_id']) + '-' + params['extract_dttm'] + '.csv',
                                                   '--abstractDatasetName',
                                                   'mantis.test-pipeline.global.test.' + params['user'] + '.' + params['table_name'].replace('_', '-')],
                        'cleanup-obsolete-data': ['--targetLayer', params['layer'],
                                                  '--retentionPeriod', params['retention_period'],
                                                  '--loadDTTM', '' + str(params['load_dttm']),
                                                  '--cleanupType', params['cleanup_type']],
                        'verify-cleanup-obsolete-partitions': ['--verifyCSV', params['hdfs_prefix'] + '/test/test-pipeline/global/verify/' + params['table_name']
                                                               + '/' + params['step_name'].replace('verify-', '') + '-' + str(params['load_id']) + '-' + params['extract_dttm'] + '.csv',
                                                               '--targetDB', 'mmd_test_test_pipeline_' + params['layer'],
                                                               '--targetTable', params['table_name']],
                        'verify-cleanup-obsolete-records': ['--verifyCSV', params['hdfs_prefix'] + '/test/test-pipeline/global/verify/' + params['table_name']
                                                            + '/' + params['step_name'].replace('verify-', '') + '-' + str(params['load_id']) + '-' + params['extract_dttm'] + '.csv',
                                                            '--targetDB', 'mmd_test_test_pipeline_' + params['layer'],
                                                            '--targetTable', params['table_name'],
                                                            '--loadDTTM', '' + str(params['load_dttm'])]
                        }
    return command + specific_command.get(params['step_name'], [])


def setup(table, load, step):
    config_path = "verify-pipeline-config.yml"
    date_format = '%Y-%m-%d'
    # pass parameters to 'params'
    params = {'step_name': step,
                'table_name': table,
                'load_id': load}
    # load other parameters from yaml configuration file
    with open(config_path, 'r') as stream:
        yaml_load = yaml.load(stream)
        params.update(yaml_load['common'])
        params.update(yaml_load['steps'].get(step, {}))
        params.update(yaml_load['loads'][load])
    retain_date = datetime.strptime(str(params['retain_date']), date_format)
    daydiff = datetime.today() - retain_date
    params['retention_period'] = str(daydiff.days)
    return params

# execute one step from the pipeline
def exec_step(landing_dir, table, load, step):
    params = setup(table, load, step)
    args = build_args(params, landing_dir)
    print args
    execute_mdc(args)


def exec_all(landing_dir, table_name, load_ids, step_name):
    for tab_name in table_name:
        for load_id in load_ids:
            for step in step_name:
                exec_step(landing_dir, tab_name, load_id, step)



if __name__ == "__main__":

    all_tables = ['verify_increment', 'verify_full_ingest']
    all_steps = ["landing-to-raw", "verify-landing-to-raw", "raw-to-curated", "verify-raw-to-curated", "curated-to-latest",
                 "verify-curated-to-latest", "hive-to-delta-csv", "verify-hive-to-delta-csv", "hive-to-teradata-csv",
                 "verify-hive-to-teradata-csv", "csv-to-abstract", "verify-csv-to-abstract", "cleanup-raw-partitions",
                 "verify-cleanup-raw-partitions", "cleanup-curated-partitions", "verify-cleanup-curated-partitions",
                 "cleanup-curated-records", "verify-cleanup-curated-records"]
    all_loads = [10, 11, 12, 13]

    parser = argparse.ArgumentParser()
    parser.add_argument('--landing_dir', type=str, default="/home/mantisetld")
    parser.add_argument('--table_name', type=str, action='append', default=[], required=False)
    parser.add_argument('--load_ids', type=str, nargs='*', default=[], required=False)
    parser.add_argument('--step_name', type=str, action='append', default=[], required=False)
    args = parser.parse_args()

    table_names = args.table_name if args.table_name else all_tables
    steps = args.step_name if args.step_name else all_steps
    loads = map(int, args.load_ids) if args.load_ids else all_loads

    exec_all(args.landing_dir, table_names, loads, steps)
