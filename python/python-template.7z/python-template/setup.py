###############################################################################
#
#   Simple (dummy) setup file. Used for compatibility with old versions
#   of python setuptools.
#
#   Created:  Dmitrii Gusev, 30.01.2022
#   Modified: 
#
###############################################################################

from distutils.core import setup

setup()
