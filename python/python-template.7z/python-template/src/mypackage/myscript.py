#!/usr/bin/env python3
# coding: utf–8

"""
    <your script description goes here...>

    Created:  Dmitrii Gusev, 21.04.2022
    Modified:

"""


def check(i: int) -> int:
    return i + 10


def main():
    print("Hello World!")


if __name__ == '__main__':
    main()
