E-Commerce Auction infrastructure project
=

Requirements:
=

- Ansible 2.9 and higher
- SSH connection to target hosts

List if inventories
=

- **Prod (Production environment)**
- **Preprod (Release-candidate)**
- **Test (Testing environment)**
- **Dev (Dev environment)**

List of roles
=

- *db*
- *bitrix*
- *deploy_app*
- *maildev*
- *managers*
- *memcached*
- *nfs*
- *pcs*
- *proxy*
- *redis*

Roles description
=

- *db*: role used for installation db percona application, dump must be placed in role files directory
- *bitrix*: role used for application bitrix, nginx and php-fpm deployment and setup
- *deploy_app*: role used for ci/cd
- *maildev*: role used for install maildev on dev, test and preprod
- *managers*: role used for install nodejs managers, archives must be placed in role files directory
- *memcached*: role used for installation memcache
- *nfs*: role used for installation drbd and nfs server and clients
- *pcs*: role used for installation pcsd, corosync, pacemaker and install pacemaker clusters for db and nfs
- *proxy*: role used for install haproxy
- *redis*: role used for install redis and redis-sentinel
