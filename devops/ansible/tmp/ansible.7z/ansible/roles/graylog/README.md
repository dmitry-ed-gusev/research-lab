Роль Graylog
=========

Роль устанавливает Graylog, Elasticsearch, MongoDB

-----

Описание
---

При стандартном запуске плейбука будут произведены следующие действия:
* Устанавливается только Graylog

------
Запуск роли
---
Перед запуском Playbook необходимо в файле `defaults/main.yml` выставить переменным значение `true`, для ПО, которое необходимо установить.
Пароль для запуска подключать не нужно.
```bash
ansible-playbook -i <inventory> -l <host/group> graylog.yml
```

Пример использования:
---

В файле `default/main.yml` заменяем переменную `mongodb: false` на `mongodb: true`, чтобы помимо Graylog была установлена MongoDB.
После, выполняем запуск в стандартном режиме
```bash
ansible-playbook -i <inventory> -l <host/group> graylog.yml
```