### Kubernetes ansible role
1. Развертывание кластера с нуля
Для развертывания кластера необходимо заполнить сведения для работы роли в рамках соответствующего инфраструктурного проекта:
   1. Заполнение ansible inventory:
      ```yaml
        all:
          hosts:
            children:
              masters:
                hosts:
                  cladtst-k8s-01:
                  cladtst-k8s-02:
                  cladtst-k8s-03:
              workers:
                hosts:
              etcd:
                hosts:
                  cladtst-k8s-01:
                  cladtst-k8s-02:
                  cladtst-k8s-03:
              k8s:
                children:
                etcd:
                masters:
                workers:
      ```
   2. файл переменных для каждой инсталляции:
     ```yaml
     cluster_name: "test-cluster"
     dns_domain: "cluster.local"
     lb:
       vip: "10.10.10.10"
       port: 16443
     ```

2. Добавление ноды в существующий кластер. Работы необходимо проводить с существующим инфраструктурным проектом:
   1. Необходимо обогатить существующее ansible inventory, добавив в него сведения о новом узле:
      ```yaml
      all:
        hosts:
          children:
            masters:
              hosts:
                cladtst-k8s-01:
                cladtst-k8s-02:
                cladtst-k8s-03:
            workers:
              hosts:
                cladtst-k8s-04:
            etcd:
              hosts:
                cladtst-k8s-01:
                cladtst-k8s-02:
                cladtst-k8s-03:
            k8s:
              children:
              etcd:
              masters:
              workers:
      ```
   2. Для добавления узла необходимо запустить роль с применением обогащенного ansible inventory и ранее созданнм vars файлом:
   ```bash
   ansible-playbook -i <infra_project_path>/ansible/inventory k8s.yml -e @<infra_project_path>/ansible/all.yml -b
   ```
   В случае, если требуется повторно вызвать функционал добавления узла, необходимо зачистить каталог `/etc/kubernetes/` на целевом хосте.
