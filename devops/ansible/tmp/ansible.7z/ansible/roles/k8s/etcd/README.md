*Install ETCD cluster for k8s*

ansible-playbook -i <inventory file> k8s.yml -t install_etcd

*Install ETCD cluster*

ansible-playbook -i <inventory file> k8s.yml -t update_etcd

