Role Bootstrap
=========

Роль устанавливает базовый набор пакетов для работы системы. При необходимости можно доустановить антивирус Касперского и Node-exporter.

-----

Description
--------------

При стандартном запуске плейбука будут произведены следующие действия:
* Добавится в систему пользователь Ansible с публичным ключом.
* Установятся пакеты необходимые для работы.
* Установится агент TMDS.
* Отключится доступ SSH по логин/паролю для всех пользователей.
* Добавится корпоративный репозиторий.

------
Install Role
------------
При запуске Playbook необходимо использовать ключ (**--ask-vault-pass**), т.к. есть зашифрованные чувствительные данные.   
Пароль для запуска можно взять в [Vault](https://vault.kube.severstal.severstalgroup.com/ui/vault/secrets/devops/show/infrastructure/ssh) .  
```bash
ansible-playbook -i <inventory> bootstrap.yml --ask-vault-pass
``` 
При необходимости установить дополнительные пакеты нужно использовать теги:
* **kes** - устанавливает Kesl и Klnagent
* **node_exporter** - устанавливает в контейнере экспортер метрик

Пример использования:
```bash
ansible-playbook -i <inventory> bootstrap.yml --tags=kes,node_exporter --ask-vault-pass
```
------
Author Information
------------------

SV.Bortnikov (16.10.2023)